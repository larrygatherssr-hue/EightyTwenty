# The Sustainable Living Masterclass — Companion Workbook

**Format note:** This workbook accompanies a complete written course manual, NOT a video course. There are no videos included. Print these worksheets or copy them into a notebook or spreadsheet, and fill them in with your own household's numbers.

## Education-Only Disclaimer

This workbook is provided for general education and information only. It is not financial, legal, tax, medical, engineering, or professional advice. All savings figures you calculate from it are estimates based on your own bills and usage, and actual results will vary with household size, climate, home construction, appliance age, utility rates, and habits. Before making electrical, plumbing, gas, or structural changes to your home, consult a licensed professional where required and follow local building codes and safety rules.

---

## How to Use This Workbook

Work through the worksheets in order the first time. Worksheet 1 is the household sustainability audit — do it first, because everything else builds on it. Worksheets 2 to 11 follow the ten modules of the manual. Worksheet 12 is the 30-day challenge tracker, and Worksheet 13 is your one-page household sustainability plan. Keep the completed workbook with your utility bills so you can compare your numbers over time.

---

## Worksheet 1 — Household Sustainability Audit

Complete this first, before making any changes. It is your baseline.

**Your household:** Number of people living in the home: ______ Adults: ______ Children: ______ Pets: ______

**Your home:** Type of home (house / flat / apartment): ______ Number of bedrooms: ______ Approximate age of home: ______ Heating type (gas boiler / electric / heat pump / oil / other): ______ Water heating type: ______

**Your bills — find these on your last bills and write them in:**

| Item | Usage per month | Rate per unit | Monthly cost |
|---|---|---|---|
| Electricity | ______ kWh | $______ per kWh | $______ |
| Gas (if used) | ______ kWh / therms | $______ | $______ |
| Water | ______ litres / gallons | $______ | $______ |
| Total utilities per month | | | $______ |

**Meter readings — read all meters on the same day, then again one month later:**

| Meter | Reading today (date: ______) | Reading in one month (date: ______) | Usage in the month |
|---|---|---|---|
| Electricity | | | |
| Gas | | | |
| Water | | | |

**Fridge and freezer:** Fridge temperature: ______ °C / °F. Freezer temperature: ______ °C / °F. Door seal test (paper slides out easily? yes / no): ______. Coils last cleaned (date): ______.

**Shower flow:** Bucket volume: ______ litres. Time to fill: ______ seconds. Flow rate: ______ litres per minute. (Flow = bucket volume ÷ minutes to fill.)

**Toilet check:** Food-colouring test done (date): ______. Colour appeared in the bowl? yes / no. Toilet type (single / dual flush / age if known): ______.

**Leak check:** Meter reading with all water off: ______. Reading one hour later: ______. Changed? yes / no. Dripping taps found: ______.

**Food waste diary — one week:** Record each item thrown away, the amount, the cost at shop prices, and the reason.

| Day | Item thrown away | Amount | Cost | Reason (cooked too much / went off / impulse buy / forgotten) |
|---|---|---|---|---|
| Mon | | | | |
| Tue | | | | |
| Wed | | | | |
| Thu | | | | |
| Fri | | | | |
| Sat | | | | |
| Sun | | | | |
| **Total for the week** | | | **$______** | Main cause: __________________ |

**Your audit summary — the three biggest findings:**

1. ________________________________________________________________________
2. ________________________________________________________________________
3. ________________________________________________________________________

---

## Worksheet 2 — Module 1: Kitchen

**My template week — five dinners I know how to cook and my household will eat:**

1. ________________________ 2. ________________________ 3. ________________________
4. ________________________ 5. ________________________

Flexible nights: Leftovers night: ______ day. Simple / takeaway night: ______ day.

**Shopping list habit:** I will check the fridge, freezer, and cupboards before shopping on: ______ day each week.

**Fridge organisation:** My "eat first" shelf or box is: ________________________. Leftovers are labelled with date and contents: yes / no.

**Freezer inventory — keep this list on the freezer door and update it:**

| Item | Date frozen | Portion size | Date used |
|---|---|---|---|
| | | | |
| | | | |
| | | | |

**Kitchen energy actions taken:** Lid on pans: yes / no. Pan matched to ring: yes / no. Dishwasher run full on eco: yes / no. Fridge seal fixed: yes / no.

**My kitchen saving estimate:** Food waste per week now: $______. Food waste per week after changes: $______. Saving per year: $______ (weekly saving × 52). Kitchen electricity saving per year: ______ kWh × $______ per kWh = $______.

---

## Worksheet 3 — Module 2: Bathroom

**Shower flow before:** ______ litres per minute. **After fitting a low-flow head:** ______ litres per minute. **Shower length before:** ______ minutes. **After:** ______ minutes.

**My shower saving:** Litres saved per shower: ______. Showers per week in my household: ______. Litres saved per year: ______. Water cost saving per year: $______ (use your own water rate). Hot-water energy saving — estimate with your own rate: $______.

**Tap habits:** Tap off while brushing teeth: yes / no. Tap aerators fitted: yes / no. Number of taps fitted: ______.

**Toilet:** Displacement device fitted: yes / no. Flush valve checked: yes / no. Half flush used for liquid waste: yes / no.

**Bathroom cabinet audit:** Products I own that do the same job: ______. Products finished before opening a new one: yes / no. One product I will not repurchase: ________________________.

---

## Worksheet 4 — Module 3: Laundry

**Loads per week:** ______. **Loads per year:** ______ (weekly × 52).

**Temperature:** Everyday loads now washed at: ______ °C / cold. Loads that genuinely need hot water: ________________________.

**Detergent:** Brand and dose used: ________________________. Dose measured: yes / no. Water hardness in my area: soft / medium / hard.

**Drying:** Loads air-dried per week: ______. Loads tumble-dried per week: ______. Dryer lint filter cleaned after every load: yes / no.

**My laundry saving estimate:** Dryer loads avoided per week: ______ × ______ kWh per load × $______ per kWh × 52 = $______ per year. Detergent saved per year: $______.

**Clothes repaired this month:** ________________________. Clothes bought second-hand this month: ________________________.

---

## Worksheet 5 — Module 4: Living Room

**Heating setpoint:** Before: ______ °C / °F. After lowering by one degree: ______ °C / °F. Schedule set for occupied hours: yes / no.

**Curtains:** Closed at dusk: yes / no. Opened on sunny mornings: yes / no. Curtains clear of radiators: yes / no.

**Draughts found and sealed:** 1. ________________________ 2. ________________________ 3. ________________________

**Lighting:** Bulbs replaced with LEDs: ______ of ______ total. Bulbs still to replace: ______.

**Standby power:** Devices on a switched power strip: ________________________. Power strip switched off at night: yes / no.

**My living-room saving estimate:** Heating saving per year: $______. Lighting saving per year: $______. Standby saving per year: $______.

---

## Worksheet 6 — Module 5: Bedroom

**Night temperature:** Bedroom heating setting at night: ______. Bedding used for warmth: ________________________.

**Air and light:** Bedroom aired daily: yes / no. Phone charged away from the bed: yes / no.

**Wardrobe audit:** Items worn regularly: ______. Items worn occasionally: ______. Items not worn in a year: ______. Items passed on (sold / donated): ______. Items repaired: ______.

**Bedding and towels:** Bedding washed every: ______ weeks. Towels washed after: ______ uses.

---

## Worksheet 7 — Module 6: Home Office

**Equipment:** Computer type (laptop / desktop): ______. Monitor(s): ______. Sleep after: ______ minutes. Screen off after: ______ minutes. Computer switched off at night: yes / no.

**Power strip:** Workstation on a switched strip: yes / no. Strip switched off at end of day: yes / no.

**Heating the office:** Office heated separately on workdays: yes / no. Office door closed while working: yes / no.

**Paper:** Printer set to double-sided: yes / no. Printer set to draft mode: yes / no. Reuse tray for single-sided paper: yes / no. Pages printed per week before: ______. After: ______.

**Equipment maintenance:** Computer vents cleaned (date): ______. Old equipment recycled or passed on: ________________________.

---

## Worksheet 8 — Module 7: Garden and Outdoors

**Watering:** Method used now (sprinkler / soaker hose / watering can): ________________________. Time of watering: morning / evening. Water butt fitted: yes / no. Number of butts: ______.

**Mulch:** Beds mulched: yes / no. Mulch material: ________________________.

**Compost:** Compost bin or heap started: yes / no. Greens and browns balanced: yes / no. Food-waste collection used: yes / no.

**Peat-free:** Compost bought is peat-free: yes / no.

**Food grown:** Crops grown this season: ________________________. Approximate value at shop prices: $______.

**Transport:** Journeys walked or cycled this week: ______. Journeys combined into one trip: ______. Tyre pressures checked (date): ______.

---

## Worksheet 9 — Module 8: Energy

**My energy bill — from the last bill:** Electricity used: ______ kWh. Rate: $______ per kWh. Fixed charge: $______ per month. Gas used: ______ kWh / therms. Rate: $______ per unit.

**Loft insulation:** Current depth: ______ mm / inches. Recommended depth for my area: ______. Topped up (date): ______.

**Heating service:** Last service (date): ______. Next service due: ______. Flow temperature discussed with engineer: yes / no.

**Hot water cylinder:** Jacket fitted: yes / no. Pipes insulated: yes / no.

**Windows:** Draught-proofed: yes / no. Replacement needed: yes / no. Quotes obtained (number): ______.

**Large investment considered:** ________________________. Cost: $______. Estimated annual saving: $______. Payback: ______ years (cost ÷ annual saving). Quotes obtained: ______ of 3.

---

## Worksheet 10 — Module 9: Water

**Weekly meter readings for one month:**

| Week ending | Meter reading | Usage that week |
|---|---|---|
| | | |
| | | |
| | | |
| | | |

**Leak tests:** Meter test done (date): ______. Result: ________________________. Toilet colour test done (date): ______. Result: ________________________.

**Leaks fixed:** 1. ________________________ 2. ________________________ 3. ________________________

**Simple reuse:** Bowl for vegetable water: yes / no. Bucket for warming-up shower water: yes / no. Water reused for: ________________________.

**Water hardness:** Soft / medium / hard (source: water provider). Softener needed: yes / no.

**My water saving estimate:** Litres saved per day: ______. Litres saved per year: ______. Cost saving per year at my rate: $______.

---

## Worksheet 11 — Module 10: Shopping and Daily Habits

**Pause rule:** My threshold for a 48-hour pause: $______. Items on my pause list this month: ________________________. Items I still wanted after 48 hours: ________________________. Items I did not buy: ________________________.

**One-in-one-out:** Category chosen: ________________________. Items in: ______. Items out: ______.

**Marketing lists:** Unsubscribed from: 1. ________________________ 2. ________________________ 3. ________________________ 4. ________________________ 5. ________________________

**Monthly spending — before and after:**

| Category | Before (per month) | After (per month) | Saving per month |
|---|---|---|---|
| Groceries | $______ | $______ | $______ |
| Household goods | $______ | $______ | $______ |
| Clothing | $______ | $______ | $______ |
| **Total** | **$______** | **$______** | **$______** |

**Daily habits I have built:** 1. ________________________ 2. ________________________ 3. ________________________

---

## Worksheet 12 — 30-Day Green Habits Challenge Tracker

Tick each day as you complete it. If you miss a day, do it the next day.

| Day | Action | Done |
|---|---|---|
| 1 | Read electricity, gas, and water meters; record readings | ☐ |
| 2 | Start the one-week food-waste diary | ☐ |
| 3 | Measure shower flow with a bucket and timer | ☐ |
| 4 | Check fridge temperature and door seals | ☐ |
| 5 | Check the toilet for leaks with food colouring | ☐ |
| 6 | List every device on standby in the living room | ☐ |
| 7 | Rest day — review the week; choose your first three changes | ☐ |
| 8 | Build your template week of five dinners; write the shopping list | ☐ |
| 9 | Create the "eat first" box; label leftovers | ☐ |
| 10 | Fit a low-flow showerhead or tap aerators | ☐ |
| 11 | Shorten every shower by two minutes | ☐ |
| 12 | Switch the washing machine to cold washes | ☐ |
| 13 | Set up the three kitchen bins | ☐ |
| 14 | Rest day — cook a meal from what is already in the fridge and cupboards | ☐ |
| 15 | Lower the heating setpoint by one degree; set a schedule | ☐ |
| 16 | Replace the five most-used bulbs with LEDs | ☐ |
| 17 | Put entertainment electronics on a switched power strip | ☐ |
| 18 | Find and seal the worst draught | ☐ |
| 19 | Set up a drying rack; air-dry a full load | ☐ |
| 20 | Wardrobe audit; pass on one bag of clothes | ☐ |
| 21 | Rest day — walk or cycle for a journey you would normally drive | ☐ |
| 22 | Unsubscribe from five marketing lists | ☐ |
| 23 | Weekly shop from a list, with a 48-hour pause on anything not on it | ☐ |
| 24 | Start a compost bin or sign up for food-waste collection | ☐ |
| 25 | Mulch a bed or water the garden with a can instead of a sprinkler | ☐ |
| 26 | Write your household sustainability plan (Worksheet 13) | ☐ |
| 27 | Share the plan with the household; agree who does what | ☐ |
| 28 | Read your meters again; compare with Day 1 | ☐ |
| 29 | Calculate your savings so far using the tracker | ☐ |
| 30 | Choose the next three changes; set a review date | ☐ |

**Notes on the challenge — what worked, what did not, what I will keep doing:**

________________________________________________________________________
________________________________________________________________________
________________________________________________________________________

---

## Worksheet 13 — My One-Page Household Sustainability Plan

**My baseline (from Worksheet 1):** Electricity: ______ kWh/month. Gas: ______ /month. Water: ______ /month. Food waste: $______ /week.

**My three priorities:**

1. ________________________________________________________________________
2. ________________________________________________________________________
3. ________________________________________________________________________

**My next three actions:**

| Action | Who | By when | Done |
|---|---|---|---|
| | | | ☐ |
| | | | ☐ |
| | | | ☐ |

**My review dates:** One-month review: ______. Three-month review: ______.

**What I will measure at each review:** Meter readings, food-waste diary for one week, and spending for the month — compared with this baseline.

---

## Room-by-Room Checklists

Copy these onto a single sheet and keep them on the fridge.

**Kitchen:** ☐ Food-waste diary done. ☐ Fridge 1–4°C, freezer −18°C or below. ☐ "Eat first" box in use. ☐ Template week planned. ☐ Dishwasher full, on eco. ☐ Three bins set up.

**Bathroom:** ☐ Shower flow measured. ☐ Low-flow head fitted. ☐ Showers two minutes shorter. ☐ Tap off while brushing. ☐ Toilet leak-checked. ☐ Dripping taps fixed.

**Laundry:** ☐ Cold washes. ☐ Full loads. ☐ Detergent measured. ☐ Half of loads air-dried. ☐ Lint filter cleaned.

**Living room:** ☐ Heating down one degree, on a schedule. ☐ Curtains closed at dusk. ☐ Worst draughts sealed. ☐ LEDs in most-used lights. ☐ Electronics on a switched strip.

**Bedroom:** ☐ Heating down at night. ☐ Bedroom aired daily. ☐ Wardrobe audit done. ☐ Bedding and towel routine set.

**Home office:** ☐ Computer sleeps and switches off at night. ☐ Workstation on a switched strip. ☐ Only the office heated on workdays. ☐ Printer double-sided, draft mode.

**Garden and outdoors:** ☐ Water butt fitted. ☐ Mulch down. ☐ Compost started. ☐ Peat-free compost. ☐ Sprinkler replaced by soaker hose or can. ☐ Car journeys combined; tyre pressures checked.

**Energy and water:** ☐ Monthly usage tracked. ☐ Loft insulation checked. ☐ Heating serviced. ☐ Cylinder and pipes insulated. ☐ Meter leak test done.

**Shopping and habits:** ☐ 48-hour pause rule in use. ☐ Shopping lists used. ☐ One-in-one-out in one category. ☐ Five marketing lists unsubscribed.

---

*End of workbook. Keep your completed worksheets with your utility bills, and bring them to each review date in Worksheet 13.*
