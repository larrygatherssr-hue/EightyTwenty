# The Sustainable Living Masterclass: Lower Bills, Less Waste, Greener Home

## A Complete Written Course Manual

**Format note:** This is a complete written course manual, NOT a video course. There are no videos included. Everything you need is in this written manual, the companion workbook, and the templates. Read it at your own pace, work through one module at a time, and use the workbook to turn each lesson into action in your own home.

---

## Education-Only Disclaimer

This manual is provided for general education and information only. It is not financial, legal, tax, medical, engineering, or professional advice, and it does not replace advice from a qualified professional for your specific situation. All savings figures in this manual are illustrative ranges only. Actual savings depend on your household size, climate, home construction and age, appliances, utility rates, water rates, and daily habits, and they will vary — sometimes substantially — from the examples given. Figures are provided so you can see how the maths works and estimate your own potential savings using your own bills; they are not promises or guarantees of any particular result. Before making electrical, plumbing, gas, or structural changes to your home, consult a licensed professional where required and follow local building codes and safety rules. Always switch off power at the breaker before touching electrical fittings, and never attempt work you are not qualified to do. Product and service names are mentioned only as general examples of categories, not as endorsements. Prices, utility rates, and rebate programmes change over time; verify current figures with your own utility provider and local authorities before spending money.

---

## How to Use This Manual

This masterclass is built around a simple idea: sustainability works best when it is practical, room by room, and when it saves you money at the same time. You do not need to change everything at once, buy expensive equipment, or live a perfect zero-waste life. You need a plan, a baseline, and a sequence of small changes that add up.

Work through the modules in order the first time. Module 1 gives you the foundations — how to read your bills, run a household audit, and choose changes by impact and payback. Modules 2 to 7 take you room by room: kitchen, bathroom, laundry, living room, bedroom, home office, and garden and outdoors. Modules 8 and 9 go deeper on the two biggest household systems, energy and water, so you can make confident decisions about heating, cooling, lighting, and water use. Module 10 brings it together with shopping and daily habits, and the manual closes with a 30-day green habits challenge that turns the plan into routine.

Each module follows the same structure: what matters in this room and why, the quick wins you can do this week for little or no money, the medium investments worth considering, the habits that lock in the savings, a worked example with real numbers, and a short checklist. The worked examples use a fictional household — a family of four in a three-bedroom house — and every figure is labelled illustrative. Your numbers will differ. The workbook that accompanies this manual gives you blank versions of every worksheet so you can run the same maths on your own bills.

Set aside about an hour a week for ten weeks, or work faster if you prefer. The 30-day challenge at the end is designed to be started after Module 10, but you can also start it after Module 1 and use it as a companion while you read. Either way, the goal is the same: by the end, you will have a written household plan, a measured baseline, and a set of changes already in place.

---

## Table of Contents

- How to Use This Manual
- Module 1 — The Kitchen: Food, Fridges, and the Biggest Waste Stream in the House
- Module 2 — The Bathroom: Water, Heat, and the Products You Use Every Day
- Module 3 — The Laundry Room: Cold Water, Full Loads, and Longer-Lasting Clothes
- Module 4 — The Living Room: Heating, Cooling, Lighting, and Electronics
- Module 5 — The Bedroom: Sleep, Air, Textiles, and Quiet Consumption
- Module 6 — The Home Office: Power, Paper, and the Work-From-Home Footprint
- Module 7 — The Garden and Outdoors: Water, Soil, Transport, and the Space Outside Your Door
- Module 8 — Energy: Heating, Cooling, Insulation, and Your Electricity Bill Explained
- Module 9 — Water: Where Your Water Goes, Leaks, and How to Use Less Without Noticing
- Module 10 — Shopping and Daily Habits: Buying Less, Buying Better, and Making It Stick
- The 30-Day Green Habits Challenge
- Your Household Sustainability Plan: Putting It All Together
- Appendix A — How to Read Your Utility Bills
- Appendix B — Glossary
- Appendix C — Further Reading and Where to Check Local Rules

---

## A Note on Numbers in This Manual

Every savings estimate in this manual is an illustrative range, clearly labelled as such, with the assumptions stated alongside it. The ranges are based on typical household patterns — for example, a household paying roughly $0.15 to $0.30 per kilowatt-hour for electricity, or $2 to $6 per 1,000 gallons for water — but rates vary widely by region and provider, and your home may use more or less than the example household. Two households in the same street can have very different bills because of household size, working hours, insulation, appliance age, climate, and habits.

Use the worked examples to learn the method: find your own usage from your bills, multiply by your own rate, and you will get your own answer. That answer is the only one that matters for your decisions. Where a payback period is given, it is calculated from the stated illustrative assumptions and will change if your prices or usage differ. No figure in this manual is a guarantee.

---

# Module 1 — The Kitchen: Food, Fridges, and the Biggest Waste Stream in the House

The kitchen is where sustainability starts for most households, because it is where three of the biggest household impacts meet: food, energy, and waste. Food that is bought and thrown away wastes the money spent on it and all the resources that went into producing, transporting, and refrigerating it. The fridge and freezer run twenty-four hours a day, every day of the year. And the kitchen produces more waste — packaging, food scraps, grease, and single-use items — than any other room.

That is the bad news. The good news is that the kitchen is also where the fastest, cheapest wins live. Most households can cut their food waste substantially within a month without eating differently, and can cut kitchen energy use with a handful of free adjustments. This module works through food planning, storage, cooking, the fridge and freezer, dishwashing, and kitchen waste, in that order — because food waste is usually worth more than energy in this room, and it deserves to go first.

## 1.1 Food waste: the money you are throwing away

Start with a simple measurement. For one week, keep a small notebook or a sheet of paper on the kitchen counter and write down everything that goes in the bin or down the disposal: the item, the rough amount, and why it was thrown away — cooked too much, went off before it was used, bought on impulse, leftovers nobody ate, or simply forgotten at the back of the fridge. Do not change your behaviour during this week; you are collecting a baseline, not performing.

Most households are surprised by the result. A common pattern is that a family of four throws away food worth roughly $25 to $50 a week at retail prices — an illustrative range, not a fact about your household. Over a year that is $1,300 to $2,600. Even if your household wastes half that amount, it is still one of the largest avoidable expenses in the home, and it is money you have already spent. The environmental point matters too, but the financial point is usually what changes behaviour: this is not a sacrifice, it is a refund you give yourself.

Once you have your week of data, sort it by cause. The four causes above point to four different fixes. "Cooked too much" is a portion problem: cook the amount you actually eat, save the rest the same evening in a labelled container, and plan one "leftovers night" a week. "Went off before it was used" is a buying and storage problem: buy less of the perishable items, store them correctly, and use a "use first" shelf. "Bought on impulse" is a planning problem: shop from a list built from a meal plan, and avoid shopping when hungry. "Forgotten at the back" is a visibility problem: keep the fridge organised so everything is seen at a glance.

## 1.2 Meal planning that actually works

Meal planning fails when it is too ambitious. A plan that requires seven new recipes a week, a two-hour Sunday cooking session, and ingredients from three shops will collapse by Wednesday. A plan that works is a small, repeatable structure with room for real life.

Begin with a template week rather than a new plan every week. Choose five dinners you know how to cook, that your household will eat, and that use overlapping ingredients. Repeat them weekly, with two flexible nights — one for leftovers and one for eating out, takeaway, or a simple meal such as eggs on toast or soup and bread. Breakfasts and lunches can be even simpler: two or three standard options each, rotated. This is not boring; it is how most efficient households actually eat, and it cuts both waste and decision fatigue.

Build the shopping list from the plan, and check the fridge, freezer, and cupboards before you write it. This single step — a five-minute check before shopping — prevents the most common form of waste: buying a second bottle of something you already have while the first one goes off. Keep a running list on the fridge or on a phone, and add items as they run out during the week, so the list is always ready.

Shop with the list, and treat anything not on it as a deliberate decision rather than a reflex. That does not mean never buying something extra; it means noticing when you do, and asking whether you have a plan to use it before it spoils. Fresh herbs, salad leaves, soft fruit, and bread are the items most often wasted, because they spoil fast and are bought in quantities larger than a household uses. Buy these in smaller amounts, more often, or choose longer-lasting alternatives — frozen vegetables, hardier greens, whole fruit rather than pre-cut — for the days when you cannot shop again.

## 1.3 Storage: the difference between fresh and forgotten

Good storage is worth more than a bigger fridge. Food goes off because of temperature, air, moisture, and time, and each of those can be managed with simple habits.

Keep the fridge at 1 to 4 degrees Celsius (34 to 40 degrees Fahrenheit). Most fridges have a dial rather than a display; if you are unsure of the actual temperature, a small fridge thermometer costs little and removes the guesswork. A fridge that is too warm spoils food faster; a fridge that is too cold wastes energy and freezes lettuce. Keep the freezer at minus 18 degrees Celsius (0 degrees Fahrenheit) or below.

Organise the fridge by visibility and by use-by date. Put new items at the back and older items at the front — the "first in, first out" rule used by every professional kitchen. Dedicate one shelf, or one clear container, as the "eat first" box: anything that needs using in the next day or two goes there, and anyone looking for a snack checks it first. Store leftovers in clear containers, labelled with the date and contents, so nobody has to open a mystery tub to find out what is inside. Wrap or cover food to prevent drying and cross-contamination, and keep raw meat on the lowest shelf where drips cannot fall onto ready-to-eat food.

In the cupboards, the same principle applies: bring older items forward, keep opened packets sealed with clips or jars, and keep a small inventory of what you have. Dry goods — rice, pasta, flour, tinned food — last a long time, but they still get wasted when they are bought in duplicate and forgotten. A twice-yearly cupboard clear-out, cooking from what is already there for a week, is one of the most satisfying exercises in this whole manual.

Freezing is your best tool against waste. Bread, cooked rice, soups, stews, sauces, and most cooked meals freeze well. Freeze in portion sizes you will actually use, label with the contents and the date, and keep a simple list on the freezer door of what is inside. A freezer full of unlabelled bags is almost as wasteful as an empty one, because nobody knows what is in it. Defrost in the fridge overnight, which is both safer and helps keep the fridge cold.

## 1.4 Cooking: energy, portions, and the humble lid

Cooking energy is smaller than heating or hot water, but the habits are free and they add up. The single most effective cooking habit is also the simplest: put a lid on the pan. A lid traps heat and moisture, brings water to the boil faster, and can cut cooking time and energy noticeably — an illustrative saving of roughly 10 to 20 percent on hob energy for boiling and simmering, depending on the pan and the food.

Match the pan to the burner or hob ring: a small pan on a large ring wastes heat around the sides. Use the residual heat of an electric hob or oven by switching it off a few minutes before the food is done. Use the microwave for reheating and for small portions, where it is generally more efficient than heating a full oven. Use a slow cooker, pressure cooker, or air fryer for the meals they suit; each uses less energy than a large oven for the same job, and a pressure cooker can cut cooking time dramatically for beans, stews, and tough cuts.

Batch cooking is the kitchen equivalent of buying in bulk: cook double, eat once, freeze once. It saves energy per meal, saves time on busy nights, and turns leftovers from a problem into a plan. Keep a list of five meals that freeze well and rotate them. And when you do cook, cook the amount your household actually eats. Weighing portions for a week — rice, pasta, potatoes — is a revealing exercise; most people cook 20 to 30 percent more than they eat, and the excess goes straight into the bin.

## 1.5 The fridge and freezer: the appliances that never sleep

Your fridge and freezer together are among the largest continuous electricity users in the home, running day and night. Two habits matter most: keeping them at the right temperature, and keeping them efficient.

First, check the door seals. Close the door on a piece of paper; if the paper slides out easily, the seal is letting cold air escape. Clean the seals regularly with warm soapy water, and replace them if they are cracked or loose — a cheap repair that pays for itself. Second, keep the coils at the back or underneath clean and dust-free, with space around the appliance for air to circulate. Dusty coils and blocked ventilation make the compressor work harder. Third, let hot food cool before putting it in the fridge, and do not leave the door open while you decide what to eat — decide first, then open.

A full fridge is more efficient than an empty one, because the cold food helps hold the temperature, but it should not be so packed that air cannot circulate. A full freezer is efficient too, and if yours is half empty, fill the gaps with containers of water (leaving room for expansion) to act as cold mass. Defrost a manual-defrost freezer when ice builds up beyond about half a centimetre; thick ice makes the freezer work harder and reduces usable space.

When the time comes to replace a fridge, size matters more than features. A fridge that is too large for your household wastes energy cooling empty space, and a second fridge in the garage — often an old, inefficient one kept for drinks — can cost more to run than it is worth. Check its energy use with a plug-in energy monitor, or simply unplug it for a month and see whether anyone misses it. If you do replace, look for the energy rating, compare running costs rather than just purchase price, and check whether your utility offers a rebate for recycling the old appliance.

## 1.6 Dishwashing, water, and kitchen waste

A modern dishwasher, run full, generally uses less water and less energy than washing the same load by hand under a running tap — but only when it is full, and only on an eco or normal cycle rather than a heavy or heated-dry cycle. Scrape plates rather than rinsing them under the tap before loading; modern detergents are designed to work on soiled dishes. Run the dishwasher only when full, use the eco setting, and let dishes air-dry by opening the door at the end of the cycle instead of using heated drying.

If you wash by hand, use a bowl or a plugged sink rather than a running tap, and wash in one batch. A running tap can use 6 to 12 litres a minute — an illustrative range — so even a few minutes of running water adds up to a substantial volume over a week.

Kitchen waste sorting is a habit, not a project. Set up three containers that are easy to reach: recycling, compost or food scraps, and general waste. If your area offers food-waste collection, use it; if it does not, a small countertop caddy with compostable liners keeps scraps out of general waste without smell. If you have a garden, a compost bin turns scraps and garden waste into soil improver — Module 7 covers this in detail. Rinse containers lightly before recycling if your local rules ask for it, but do not waste large volumes of hot water washing recycling; a quick scrape is usually enough.

Reduce single-use items in stages rather than all at once. Reusable shopping bags, a reusable water bottle, beeswax wraps or reusable containers instead of cling film, and cloths instead of paper towels are each small changes. Pick the one you will actually use, make it easy — keep the bags by the door, the bottle filled in the fridge — and add another when the first is automatic.

## 1.7 Worked example: the kitchen numbers

Take a fictional household of four. Suppose their food-waste diary shows they throw away food worth $35 a week at retail prices — an illustrative figure for this example. Cutting that waste by half saves $17.50 a week, or about $910 a year. Suppose they also fix a fridge seal, set the temperature correctly, and run the dishwasher full on eco, saving an illustrative 150 kilowatt-hours a year on kitchen electricity. At an illustrative rate of $0.20 per kilowatt-hour, that is $30 a year. The food saving is thirty times the energy saving. That is the lesson of this module: in the kitchen, food is the money.

Your household will be different. Run the same maths with your own diary and your own electricity rate, using the worksheet in the workbook. The point is not the exact number; it is the order of priorities. Start with food, then the fridge, then the dishwasher, then the single-use items.

## 1.8 Module 1 checklist

- [ ] Kept a one-week food-waste diary and identified the main cause.
- [ ] Set the fridge to 1–4°C and the freezer to −18°C or below.
- [ ] Created an "eat first" shelf or box in the fridge.
- [ ] Built a template week of five repeatable dinners plus two flexible nights.
- [ ] Checked the fridge door seals and cleaned the coils.
- [ ] Switched to running the dishwasher only when full, on eco.
- [ ] Set up recycling, compost, and general-waste containers in the kitchen.

---

# Module 2 — The Bathroom: Water, Heat, and the Products You Use Every Day

The bathroom is the wettest room in the house and the one where water and hot water dominate. Showers, baths, toilet flushing, hand washing, and teeth brushing account for a large share of household water use, and heating that water accounts for a large share of household energy use. The bathroom is also where small, cheap fittings — a low-flow showerhead, a tap aerator — can make a measurable difference without changing how you live.

This module covers showers and baths, toilets, taps, hot water habits, and the personal-care products that fill bathroom cabinets. The tone throughout is practical: nobody is asked to take cold showers or to give up comfort. The goal is the same comfort with less water and less heat.

## 2.1 Showers: the biggest single use of water in most homes

For most households, the shower is the largest single indoor use of water. An older showerhead can flow at 12 to 20 litres a minute; a modern low-flow showerhead flows at 6 to 9 litres a minute, and many people cannot tell the difference once it is fitted, because the design mixes air into the spray. The maths is straightforward: a ten-minute shower at 15 litres a minute uses 150 litres; the same shower at 8 litres a minute uses 80 litres. That is a saving of 70 litres per shower — an illustrative example, not a measurement of your shower. Multiply by the number of showers in your household each week, and the volume becomes substantial.

Shortening the shower matters too, and it is free. Cutting two minutes from a daily ten-minute shower saves roughly 20 percent of that shower's water and of the energy used to heat it, at whatever flow rate you have. A simple shower timer — a small waterproof timer or a favourite song of a known length — is enough. You do not need to rush; you need to notice. Navy showers, where the water is turned off while soaping, save more, but they are not for everyone; try them as an experiment rather than a rule.

Measure your own shower flow before you change anything. Put a bucket of known volume under the showerhead, run the shower for one minute at your normal setting, and measure how much water you collected. Write the number in the workbook. Then, after fitting a low-flow head, measure again. The before-and-after comparison is the most convincing evidence you will get, and it tells you your actual saving rather than a generic claim.

## 2.2 Baths, taps, and the small leaks that add up

A bath typically uses 80 to 150 litres of water, depending on the size of the bath and how full you fill it — an illustrative range. A short shower usually uses less than a bath; a long, high-flow shower can use more. If you love baths, keep them, but treat them as a pleasure rather than a daily default, and fill the bath a few centimetres lower than usual. That small change alone saves several litres each time without changing the experience.

Taps are the quiet wasters. A tap left running while brushing teeth can waste 6 litres a minute or more; turning it off while brushing and turning it on only to rinse is a habit that costs nothing and saves water every single day. The same applies to shaving and face washing: fill the basin, or use a cup of water, rather than letting the tap run. Fitting tap aerators — small screw-on fittings that mix air into the flow — can cut tap flow by roughly a third to a half while keeping the water feeling full. They cost little, fit in minutes, and are one of the best-value fittings in this whole manual.

Leaks deserve attention out of proportion to their size. A tap that drips once a second wastes roughly 10,000 litres a year — an illustrative figure that surprises most people, because a drip looks trivial. A leaking toilet can waste far more, silently, because the water runs straight into the bowl and is never seen. Check for toilet leaks by putting a few drops of food colouring in the cistern and waiting fifteen minutes without flushing; if colour appears in the bowl, the valve is leaking and needs a simple repair or replacement. Check your water meter when no water is being used; if the dial is moving, you have a leak somewhere. Fixing a leak is almost always cheaper than paying for the water it wastes.

## 2.3 The toilet: old, thirsty, and easy to improve

Toilets are the second-largest indoor water user in many homes, and older toilets are the thirstiest. A toilet installed before the mid-1990s can use 13 litres or more per flush; a modern dual-flush toilet uses about 3 litres for a half flush and 6 litres for a full flush. If your toilet is old and you flush four times a day per person, the difference between 13 litres and an average of 4 litres is about 36 litres per person per day — an illustrative calculation, and one that shows why a toilet replacement, when the old one needs replacing anyway, is worth considering.

You do not need to replace a working toilet immediately. Cheaper steps come first. If your toilet has a single flush and a large cistern, a displacement device — a sealed bag or bottle of water placed in the cistern — reduces the volume used per flush by the volume it displaces. Do not use a brick, which can crumble and damage the mechanism. Check that the water level in the cistern is set correctly and that the flush valve seals properly; a toilet that runs on after flushing is wasting water continuously. And use the half flush for liquid waste when a dual-flush is available; many households use the full flush out of habit for every flush.

## 2.4 Hot water in the bathroom

Heating water is expensive because water holds a great deal of heat. Every litre of hot water you do not use is energy saved as well as water saved, which is why the shower and tap habits in this module count twice. Beyond that, check the temperature of your hot water. If your water heater is set above 60 degrees Celsius (140 degrees Fahrenheit), you may be heating water hotter than you need and then mixing it with cold water at the tap — wasting energy to create heat you immediately dilute. A setting around 50 to 60 degrees Celsius is typical for many systems, but follow the manufacturer's guidance and local safety advice, because water stored too cool can carry health risks. If you are unsure, ask a qualified plumber rather than guessing.

Insulate exposed hot-water pipes in the bathroom and on the way to it, especially in unheated spaces. Insulation is cheap, and it means the water arrives hot sooner, so you run the tap for less time waiting. If your bathroom is far from the water heater and you wait a long time for hot water, consider whether a point-of-use solution or a recirculation system is worth it — but get professional advice and compare the cost against the water and energy saved before spending.

## 2.5 Personal-care products: less, simpler, longer-lasting

Bathroom cabinets accumulate products: half-used bottles, samples, duplicates, and items bought for a single use. The sustainable approach here is not to buy a whole new set of "eco" products; it is to use what you have, buy less, and choose better when you do buy.

Start with an audit. Take everything out of the cabinet, group it by type, and discard anything expired or unusable. Keep one of each product you actually use, and finish it before opening the next. This alone can save a surprising amount of money, because many households own three or four of the same product at once.

When you buy, choose larger sizes or refillable options where they are genuinely cheaper per unit and you will use them before they expire. Choose bars over bottles where you like them — shampoo bars, soap bars — because they use less packaging and often last longer. Avoid single-use items where a reusable alternative works for you: a washcloth instead of disposable wipes, a safety razor with replaceable blades instead of disposable razors, a menstrual cup or reusable pads if they suit you. None of these is a moral requirement; each is an option to try, keep if it works, and drop if it does not.

Read labels with a practical eye. "Natural" and "eco" are marketing words, not guarantees. Look for the specific claims that matter to you — for example, a short ingredient list you recognise, a refill option, or a certification you trust — and be sceptical of vague green claims. Buy the smallest size when trying a new product, so a product you dislike does not become waste.

## 2.6 Worked example: the bathroom numbers

Take a household of four, each showering once a day for ten minutes. Suppose their showerheads flow at 15 litres a minute — an illustrative assumption. That is 600 litres a day for showers. Fitting low-flow heads at 8 litres a minute cuts that to 320 litres a day, a saving of 280 litres a day, or about 102,000 litres a year — an illustrative figure. At an illustrative water rate of $4 per 1,000 gallons (about $1.06 per 1,000 litres), the water saving alone is roughly $108 a year. The energy saving is larger, because much of that water was heated: heating 280 litres a day by about 25 degrees Celsius takes roughly 8 kilowatt-hours a day, and at an illustrative $0.20 per kilowatt-hour that is about $1.60 a day, or roughly $580 a year — if all the saved water was hot water, which it is not, since some shower water is cold. A more cautious illustrative estimate, assuming about two-thirds of the saved water was heated, is roughly $380 a year in energy. Combined with water, the illustrative total is around $490 a year. Your rates, climate, and shower habits will change this number substantially, and the workbook helps you calculate your own version. The point is the direction: in the bathroom, water and energy are the same saving counted twice.

## 2.7 Module 2 checklist

- [ ] Measured shower flow rate with a bucket and a timer.
- [ ] Fitted a low-flow showerhead and tap aerators, or noted the fitting sizes needed.
- [ ] Shortened showers by two minutes, or set a shower timer.
- [ ] Turned off the tap while brushing teeth and shaving.
- [ ] Checked the toilet for leaks with food colouring.
- [ ] Fixed any dripping taps.
- [ ] Audited the bathroom cabinet and finished one product before opening the next.

---

# Module 3 — The Laundry Room: Cold Water, Full Loads, and Longer-Lasting Clothes

Laundry is a routine most households do without thinking, and that is exactly why it is a good place to save. The three levers are temperature, load size, and drying. Wash colder, wash full loads, and dry with air where you can, and you will use less energy and water, spend less on detergent, and make your clothes last longer.

## 3.1 Wash cold, wash full

Heating the water is the largest part of a washing machine's energy use. Modern detergents are designed to work in cold water for most everyday loads, and washing at 30 degrees Celsius (86 degrees Fahrenheit) or cold cleans most clothes perfectly well. Reserve hot water for the loads that genuinely need it — heavily soiled items, bedding when someone has been ill, cloth nappies or cleaning cloths — and wash everything else cold. The saving per load is small, but over a household's 200 to 300 loads a year it adds up, and cold water is also gentler on fabrics and colours.

Load size matters as much as temperature. A half-full machine uses almost as much water and energy as a full one, so two half loads cost roughly twice as much as one full load. Wait until you have a full load, sort by colour and fabric so you can fill the machine confidently, and avoid overfilling — clothes need room to move and rinse properly. If your machine has a half-load or eco setting, use it for the smaller loads you cannot avoid, but a full load on a normal cycle is usually the most efficient choice.

Choose the shortest cycle that gets the job done. Many machines default to a long cycle; the eco or quick cycle is often enough for everyday clothes. Skip the extra rinse unless you need it for sensitive skin or detergent residue. Use the spin speed your machine offers — a faster spin removes more water, which shortens drying time — but balance that against wear on delicate fabrics.

## 3.2 Detergent: less is more

Most people use more detergent than they need. Modern machines and detergents are concentrated, and excess detergent does not make clothes cleaner; it leaves residue, can irritate skin, and requires more water to rinse out. Follow the dosage on the packet for your water hardness and load size, and measure it rather than pouring freely. If your water is soft, you need less; if it is hard, you need more — check your water provider's hardness information or use a simple test strip.

Choose a detergent format that suits you — liquid, powder, or sheets — and consider the packaging. Larger packs are usually cheaper per wash and use less packaging per wash. Avoid single-dose pods if you prefer to control the dose, and keep all detergent out of reach of children. For stain treatment, a simple pre-treatment — a paste of bicarbonate of soda, a little white vinegar, or a dedicated stain remover applied before washing — is usually more effective than adding extra detergent to the whole load.

## 3.3 Drying: air first, machine second

Tumble dryers are among the most energy-hungry appliances in the home. A typical dryer uses roughly 2 to 3 kilowatt-hours per load — an illustrative range depending on the machine and the load. At an illustrative $0.20 per kilowatt-hour, that is $0.40 to $0.60 per load, or $80 to $180 a year for a household drying 200 to 300 loads. Line drying or using a drying rack costs nothing and is gentler on clothes.

Dry outdoors when the weather allows, even in cooler weather — wind dries clothes as well as sun. Indoors, use a rack near a window or in a well-ventilated room, and open a window slightly or use a dehumidifier in a damp room to prevent condensation and mould. Hang clothes with space between them so air can circulate. If you must use the dryer, use it for the items that need it — towels, bedding — and air-dry the rest. Clean the lint filter after every load; a clogged filter makes the dryer work harder and longer. Dry similar fabrics together, and do not over-dry; taking clothes out slightly damp and letting them finish on a rack saves energy and reduces creasing.

## 3.4 Making clothes last longer

The most sustainable item of clothing is the one you already own. Washing less often, washing colder, and drying with air all extend the life of clothes, because heat, agitation, and tumbling wear fibres out. Many items — jeans, jumpers, outer layers — do not need washing after every wear. Air them, spot-clean marks, and wash them when they are actually dirty. This is not about being unclean; it is about washing for need rather than habit.

Repair before replacing. A missing button, a loose hem, a small tear, or a worn sole can be fixed in minutes or by a local repair shop for far less than a replacement costs. Keep a small sewing kit and learn the two or three basic stitches that cover most repairs. When you do buy, buy for durability and fit rather than for the lowest price, and consider second-hand first for items where it makes sense — children's clothes, which are outgrown quickly, are an obvious example. When clothes are truly worn out, check whether your area offers textile recycling; do not put textiles in general waste if a recycling option exists.

## 3.5 Worked example: the laundry numbers

Take a household doing five loads a week, or 260 loads a year. Suppose switching from warm to cold washing saves an illustrative 0.3 kilowatt-hours per load, or 78 kilowatt-hours a year — about $16 a year at $0.20 per kilowatt-hour. Suppose they also cut dryer use from four loads a week to one, air-drying the rest, saving three dryer loads a week at an illustrative 2.5 kilowatt-hours each: 390 kilowatt-hours a year, or about $78 a year. Suppose using the correct detergent dose saves one bottle of detergent every two months, about $30 a year. The illustrative total is roughly $124 a year, plus longer-lasting clothes. Your numbers will differ with your machine, your rates, and your drying habits; the workbook lets you calculate your own.

## 3.6 Module 3 checklist

- [ ] Switched everyday loads to cold or 30°C washing.
- [ ] Waited for full loads, or used the eco setting for smaller loads.
- [ ] Measured detergent instead of pouring freely.
- [ ] Set up a drying rack and air-dried at least half of all loads.
- [ ] Cleaned the dryer lint filter after every load.
- [ ] Repaired one item of clothing instead of replacing it.

---

# Module 4 — The Living Room: Heating, Cooling, Lighting, and Electronics

The living room is where the household gathers, and where heating, cooling, lighting, and electronics all run at once. It is the room where comfort matters most, and where the thermostat, the curtains, and the television compete for energy. The approach in this module is the same as elsewhere: comfort first, waste second. Nobody is asked to sit in the cold or in the dark. The savings come from heating and cooling the people and the room you are actually using, lighting it efficiently, and stopping the quiet drain of electronics left on standby.

## 4.1 Heating and cooling: the thermostat is the budget

Space heating and cooling are, for most households, the largest single use of energy in the home — larger than water heating, appliances, and lighting combined in many climates. That makes the thermostat the most powerful single control in the house. Lowering the heating setpoint by one degree Celsius (about two degrees Fahrenheit) can cut heating energy by roughly 5 to 10 percent — an illustrative range that depends on your climate, insulation, and heating system. That is a large saving for a change most people barely notice, especially if it is paired with warmer clothing indoors and a blanket for evenings on the sofa.

Set a schedule that matches your life rather than heating an empty house. Use a programmable or smart thermostat to lower the temperature when everyone is out or asleep, and to bring it back up shortly before people return or wake. A common pattern is 18 to 20 degrees Celsius (65 to 68 degrees Fahrenheit) when the house is occupied and awake, 15 to 17 degrees when asleep, and lower still when the house is empty for the day — adjusted for the needs of babies, older people, and anyone with a health condition, who need warmer rooms. Do not turn the heating off entirely in very cold weather if pipes could freeze; a low background temperature is safer.

Zone your heating where you can. Close doors to rooms you are not using, close vents or radiators in unused rooms where your system allows it, and heat the room you are in rather than the whole house. A portable heater for one room can be cheaper than heating the whole house for one person, but only if the rest of the heating is turned down — otherwise you are paying twice. Check that radiators are not blocked by furniture or heavy curtains, and bleed them if the top is cold while the bottom is hot; trapped air stops them working properly.

In summer, the same logic applies in reverse. Cooling is expensive, and the cheapest cooling is shade. Close curtains or blinds on sunny windows during the day, especially south- and west-facing windows, and open them in the evening when the air cools. Open windows on opposite sides of the house in the evening to create a cross-breeze. Use fans before air conditioning: a fan uses a fraction of the energy of an air conditioner and makes a room feel several degrees cooler by moving air over skin. When you do use air conditioning, set it to 24 to 26 degrees Celsius (75 to 78 degrees Fahrenheit) rather than the lowest setting, keep doors and windows closed while it runs, and clean or replace the filter regularly — a dirty filter makes the system work harder for less cooling.

## 4.2 Draughts, curtains, and the free insulation you already own

Draughts are cold air leaking in through gaps around doors, windows, letterboxes, and floorboards. They make a house feel cold at a temperature that should be comfortable, and they push people to turn the thermostat up. Sealing them is one of the cheapest energy improvements available. Draught-proofing strips for doors and windows, a brush or flap for the letterbox, and sealant for gaps around skirting boards and pipework cost little and can be fitted in an afternoon. You can find draughts by holding a lit candle or a strip of tissue near a suspected gap on a windy day and watching for movement — taking care with the flame, and never leaving it unattended.

Curtains are insulation you already own. Heavy curtains, closed at dusk, add a layer of insulation to windows, which are the coldest part of a room. Open them in the morning on sunny days to let in free heat and light, and close them as the light fades. Make sure curtains do not hang in front of radiators, which would trap the heat behind them. If your curtains are thin, a thermal lining or a second layer makes a noticeable difference. Rugs on bare floors add warmth underfoot and a little insulation, and they make a room feel cosier at the same temperature.

## 4.3 Lighting: the easiest swap in the house

Lighting is the simplest energy upgrade in the home, because it requires no change in behaviour. If you still have incandescent or halogen bulbs, replace them with LEDs as they fail — or all at once in the rooms you use most. An LED uses roughly 75 to 80 percent less energy than an incandescent bulb for the same brightness, and lasts many times longer. The illustrative maths: a 60-watt incandescent replaced by a 9-watt LED, used four hours a day, saves about 74 kilowatt-hours a year, or about $15 a year at $0.20 per kilowatt-hour, for one bulb. A house with twenty bulbs saves several hundred kilowatt-hours a year — an illustrative total that depends on how many lights you have and how long they are on.

Choose the right brightness and colour for each room. Brightness is measured in lumens, not watts: a living-room bulb of 800 lumens is roughly equivalent to the old 60-watt bulb. Colour temperature is measured in kelvin: warm white (around 2,700 kelvin) suits living rooms and bedrooms, while cooler white (around 4,000 kelvin) suits kitchens and workspaces. Buy dimmable LEDs if you have dimmers, and check compatibility, because not all LEDs dim smoothly with older dimmer switches.

Habits matter too, and they cost nothing. Turn lights off when you leave a room, use task lighting — a single lamp where you are reading — instead of lighting the whole room, and make the most of daylight by keeping windows clean and arranging seating near natural light. Motion sensors or timers are useful in hallways, porches, and rooms where lights are often left on by mistake.

## 4.4 Electronics and standby power

Televisions, games consoles, set-top boxes, speakers, and chargers all draw power, and many of them keep drawing it when they appear to be off. This standby or "vampire" power is small per device — often 1 to 10 watts — but across a house full of devices running twenty-four hours a day, it adds up to an illustrative 5 to 10 percent of household electricity use in some homes. The fix is simple: switch devices off at the wall or at a power strip when they are not in use, and unplug chargers when they are not charging anything. A power strip with a switch makes this a one-flick habit for a whole group of devices — television, console, sound system — and a smart strip can cut power automatically when the main device is switched off.

Check the settings on your television and console: many have an eco mode, an automatic power-off after a period of inactivity, and a brightness setting that can be turned down without affecting enjoyment. A television at full brightness in a dim room wastes energy and strains eyes; a moderate brightness is usually more comfortable. When buying new electronics, compare the energy rating and the typical annual running cost, not just the purchase price, and choose the size that fits the room rather than the largest available.

## 4.5 Furniture, stuff, and the living room's hidden consumption

The living room accumulates things: books, games, decorations, gadgets, and furniture bought on impulse. The sustainable approach is not to empty the room; it is to buy deliberately and to keep what you have in use longer. Before buying a new item, ask three questions: do I need it, do I have space for it, and will I still want it in a year? If the answer to any of them is no, wait a week and see whether you still want it. Most impulse purchases fade within a week.

Buy second-hand where it makes sense — solid wood furniture, books, games, and many electronics are available used in good condition for a fraction of the new price, and they have already paid their manufacturing cost. Repair rather than replace where you can: a wobbly chair, a torn cushion cover, or a scratched table can often be fixed in an afternoon. When you do replace something, pass the old item on — sell it, give it away, or donate it — rather than sending it to landfill if it still has life in it.

## 4.6 Worked example: the living room numbers

Take a household that lowers its heating setpoint by one degree Celsius for the winter. Suppose their annual heating energy is 10,000 kilowatt-hours — an illustrative figure for a moderately insulated house in a temperate climate. A 7 percent saving (the middle of the illustrative 5 to 10 percent range) is 700 kilowatt-hours. At an illustrative $0.20 per kilowatt-hour, that is $140 a year. Suppose they also replace ten 60-watt incandescent bulbs with 9-watt LEDs, each used four hours a day: an illustrative saving of about 740 kilowatt-hours a year, or about $148 a year. Suppose switching off standby power saves an illustrative 200 kilowatt-hours a year, or $40. The illustrative total is roughly $328 a year, from three changes that do not reduce comfort. Your heating fuel, climate, and insulation will change these numbers substantially — a house heated with gas will have different costs, and a well-insulated house will save less in absolute terms because it uses less to begin with — and the workbook helps you work with your own bills.

## 4.7 Module 4 checklist

- [ ] Lowered the heating setpoint by one degree and set a schedule for occupied hours.
- [ ] Closed curtains at dusk and opened them on sunny mornings.
- [ ] Found and sealed the worst draughts.
- [ ] Replaced the most-used bulbs with LEDs.
- [ ] Put entertainment electronics on a switched power strip and turned it off at night.
- [ ] Set the television and console to eco mode with automatic switch-off.

---

# Module 5 — The Bedroom: Sleep, Air, Textiles, and Quiet Consumption

The bedroom is the quietest room in the house, and its consumption is quiet too: heating at night, bedding and clothing stored and washed, a phone charging by the bed, and a wardrobe full of clothes that are rarely worn. This module is short by design, because the bedroom needs fewer changes than the kitchen or the living room — but the changes it does need are worth making, because you spend a third of your life in this room.

## 5.1 Sleep temperature and night heating

Most people sleep best in a cool room, around 16 to 19 degrees Celsius (61 to 66 degrees Fahrenheit) — a commonly cited comfort range, not a medical prescription. That is cooler than the daytime living temperature, which means the bedroom does not need to be heated as much at night. Turn the bedroom radiator down or off at night, close the door, and use bedding to stay warm rather than heating the whole room. A good duvet, a blanket, and warm sleepwear are cheaper than heating a room to daytime temperature while you are under covers and asleep.

If your heating system allows it, set different temperatures for different zones or times: warm in the evening while you get ready for bed, cooler overnight, and warm again briefly in the morning. A hot water bottle is an old-fashioned, effective way to warm a bed without heating a room. In summer, the reverse applies: keep the bedroom cool by closing curtains during the day, opening windows in the evening, and using a fan rather than cooling the whole house overnight.

## 5.2 Air, light, and sleep quality

Fresh air matters for sleep, and it costs nothing. Open a bedroom window for a short period each day, or leave it slightly open overnight if it is safe and quiet enough to do so. Avoid heavy air fresheners and sprays; they add chemicals to the air you breathe for eight hours and are rarely necessary in a clean, ventilated room. If the air is dry in winter, a bowl of water near a radiator or a simple humidifier can help, but keep humidity in a reasonable range — too much moisture encourages mould, which is covered in Module 8.

Light affects sleep too. Blackout curtains or a sleep mask help if streetlights shine into the room, and they also add insulation in winter. Charge your phone away from the bed if you can, and use an alarm clock instead of the phone, so the bedroom is a place for sleep rather than for screens. This is a wellbeing habit as much as a sustainability one, and it also removes a small standby load from the room.

## 5.3 The wardrobe: what you own, what you wear, what you keep

The average wardrobe contains clothes that are rarely or never worn. A wardrobe audit is a useful exercise: take everything out, try it on or hold it up, and sort it into three groups — wear regularly, wear occasionally, and have not worn in a year. The third group is the interesting one. Some of it can be repaired, altered, or styled differently; some of it no longer fits your life and can be sold, donated, or passed on; and some of it is worn out and belongs in textile recycling.

The goal is not a minimal wardrobe; it is a wardrobe you actually use. A smaller wardrobe of clothes you wear is more sustainable than a large wardrobe of clothes you do not, because every unworn item represents money and resources spent for nothing. When you buy new clothes, apply the same three questions from Module 4 — do I need it, do I have space for it, will I still want it in a year — and choose quality and fit over quantity. Wash clothes according to Module 3, store them clean and dry, and use cedar blocks or lavender sachets rather than chemical mothballs if moths are a problem.

Bedding and towels deserve the same care. Wash bedding every one to two weeks, or more often in hot weather or when someone is ill, and wash towels after three to four uses rather than after every use — hanging them to dry fully between uses prevents the damp smell that makes people wash them more often than necessary. Choose bedding and towels for durability, and replace them when they are worn out rather than when a new colour catches your eye.

## 5.4 Worked example: the bedroom numbers

The bedroom's savings are modest in money but real in comfort. Suppose a household turns the bedroom heating down at night and saves an illustrative 300 kilowatt-hours of heating energy over the winter — about $60 a year at $0.20 per kilowatt-hour. Suppose a wardrobe audit leads to selling or donating unused clothes and avoiding three impulse clothing purchases a year at an illustrative $40 each — $120 a year not spent. The illustrative total is about $180 a year, plus a room that is easier to sleep in and a wardrobe that is easier to use. Small numbers, honestly stated, are better than large numbers invented.

## 5.5 Module 5 checklist

- [ ] Turned the bedroom heating down at night and used bedding for warmth.
- [ ] Aired the bedroom daily and kept the phone charging away from the bed.
- [ ] Completed a wardrobe audit and passed on clothes not worn in a year.
- [ ] Set a washing routine for bedding and towels based on use, not habit.

---

# Module 6 — The Home Office: Power, Paper, and the Work-From-Home Footprint

Working from home saves the energy and emissions of commuting, but it moves energy use into the house: a computer, a monitor, a printer, lighting, and heating or cooling for a room that was empty during the day. This module covers how to keep the home office efficient without making it uncomfortable, and how to manage the paper, equipment, and habits that come with working from home.

## 6.1 The workstation: the computer, the monitor, and the settings that matter

A laptop typically uses far less energy than a desktop computer — an illustrative 30 to 60 watts for a laptop against 100 to 300 watts or more for a desktop with a monitor, depending on the machines. If you have a choice, a laptop is the more efficient option for most office work. Either way, the settings matter. Set the computer to sleep after ten to fifteen minutes of inactivity, and the screen to switch off after five minutes. Use the energy-saving or eco mode, lower the screen brightness to a comfortable level, and switch the computer off at the end of the day rather than leaving it on standby overnight. A computer left on twenty-four hours a day can use several times more energy than one used for eight hours and switched off.

A second monitor adds convenience and adds energy use. If you use one, switch it off when you are not using it, and consider whether a single larger monitor would serve you better than two. Unplug chargers and peripherals when they are not in use, and use a switched power strip for the whole workstation so one flick turns everything off at the end of the day. Keep the computer's vents clear of dust so the fan does not work harder than it needs to, and keep software updated so the machine runs efficiently.

## 6.2 Heating, cooling, and lighting the office

Heating a whole house for one person working in one room is wasteful. If you work from home regularly, heat the room you are in. Close the office door, use a small heater for that room if needed, and turn the central heating down — remembering the caution from Module 4 that a portable heater only saves money if the rest of the heating is turned down. Dress for the room temperature, and use a blanket or a heated pad for your lap rather than heating the air to summer temperatures.

Lighting the office well matters for your eyes and your work. Sit near a window for natural light where you can, and use a desk lamp for task lighting rather than lighting the whole room brightly. Use LED bulbs, as in Module 4, and turn the light off when you leave the room. In summer, keep the office cool with shade and ventilation before reaching for air conditioning, and keep the computer out of direct sunlight, which makes it run hotter.

## 6.3 Paper, printing, and the digital alternative

The paperless office is a myth for most people, but a low-paper office is realistic. Print only what you need on paper, print double-sided by default, and use draft mode for internal documents. Keep a tray for single-sided paper that can be reused for drafts and notes. Before printing a long document, ask whether you need the whole thing on paper or only a few pages.

When you do buy paper, choose recycled paper where it meets your needs, and buy in quantities you will use. Recycle paper that cannot be reused, and shred confidential documents before recycling them. Store documents digitally with a simple filing system — by year, then by topic — and back them up, so you do not print a copy "just in case" and then lose it anyway.

## 6.4 Equipment: buy once, maintain it, pass it on

Office equipment is expensive to make and to buy, so making it last is both sustainable and economical. Maintain your equipment: clean the keyboard and screen, keep the computer free of dust, replace a battery when it no longer holds a charge rather than replacing the whole machine, and add memory or storage to an older machine if that extends its useful life. When you do replace equipment, consider refurbished machines from a reputable seller; they are often substantially cheaper than new and perfectly adequate for office work.

When equipment reaches the end of its life, do not put it in general waste. Electronics contain materials that should be recovered and substances that should not go to landfill. Use your local e-waste collection, a retailer take-back scheme, or a manufacturer recycling programme. Wipe personal data from any device before passing it on or recycling it, and remove batteries where the scheme asks for them separately.

## 6.5 Worked example: the home office numbers

Take a person working from home five days a week. Suppose their desktop computer and monitor use an illustrative 200 watts and run for nine hours a day, five days a week, fifty weeks a year: 450 kilowatt-hours a year. Switching the machine off at night and at weekends instead of leaving it on standby, and using sleep settings during the day, might save an illustrative 150 kilowatt-hours a year — about $30 a year at $0.20 per kilowatt-hour. Suppose heating only the office instead of the whole house on workdays saves an illustrative 500 kilowatt-hours of heating energy over the winter — about $100 a year. Suppose printing half as much saves about $40 a year in paper and ink. The illustrative total is roughly $170 a year. Your equipment, your heating system, and your working pattern will change this; the workbook lets you calculate your own version.

## 6.6 Module 6 checklist

- [ ] Set the computer to sleep after 15 minutes and switch it off at night.
- [ ] Put the workstation on a switched power strip.
- [ ] Heated only the office on workdays, with the door closed.
- [ ] Set the printer to double-sided and draft mode by default.
- [ ] Set up a reuse tray for single-sided paper.

---

# Module 7 — The Garden and Outdoors: Water, Soil, Transport, and the Space Outside Your Door

The garden is where sustainability becomes visible and enjoyable. It is also where water use can be surprisingly high, where chemicals and peat can do quiet damage, and where a few good habits — composting, watering wisely, planting for your climate — make a real difference. This module also covers the space beyond the garden: the driveway, the journey to work and the shops, and the outdoor equipment that fills sheds and garages.

## 7.1 Watering wisely

Outdoor watering can account for a large share of household water use in summer, especially in dry climates. The rules are simple: water the soil, not the leaves; water early in the morning or in the evening, when less water evaporates; and water deeply and less often, so roots grow down rather than staying shallow. A sprinkler left running can use hundreds of litres an hour — an illustrative range of 500 to 1,000 litres an hour for a typical garden sprinkler — so a sprinkler is the most expensive way to water a garden. A watering can or a soaker hose aimed at the base of plants uses far less water for the same result.

Collect rainwater where you can. A water butt connected to a downpipe collects free water for the garden, reduces the load on the mains supply, and gives plants water without the chemicals used to treat drinking water. Even a small butt is useful for pots and containers. Use a lid to keep out leaves and mosquitoes. If you have space for more than one, link them together.

Mulch is the gardener's best friend. A layer of mulch — bark, compost, straw, or wood chips — around plants keeps moisture in the soil, suppresses weeds, and improves the soil as it breaks down. It reduces how often you need to water and how often you need to weed. Choose plants suited to your climate and soil rather than plants that need constant watering to survive; native and drought-tolerant plants are usually the easiest to keep alive and the cheapest to maintain.

## 7.2 Soil, compost, and what not to put on the garden

Compost turns kitchen scraps and garden waste into free, rich soil improver. A compost bin or heap needs a mix of "greens" (kitchen scraps, grass clippings, soft leaves) and "browns" (dry leaves, shredded cardboard, twigs), air, and moisture. Turn it occasionally, keep it damp but not wet, and in a few months you will have dark, crumbly compost. Do not compost meat, dairy, or cooked food in a home heap unless your system is designed for it, because it attracts pests and smells. If your area collects food waste, use that service for those items instead.

Avoid peat-based composts where alternatives are available. Peat is dug from bogs that store large amounts of carbon and support rare wildlife, and it forms so slowly that it is effectively non-renewable on human timescales. Peat-free composts have improved greatly and are widely available; try one and see how your plants respond.

Be cautious with chemicals. Weedkillers, pesticides, and synthetic fertilisers can harm bees, soil life, and waterways, and they are often unnecessary. Pull weeds by hand or with a hoe, encourage birds and beneficial insects, and feed the soil with compost rather than feeding the plant with chemicals. If you do use a product, follow the instructions exactly, use it only where needed, and keep it away from ponds, drains, and children's play areas.

## 7.3 Growing food: start small, grow what you eat

Growing your own food is satisfying, and it can save money — but only if you grow what you actually eat and in quantities you can use. Start with the easy, high-value crops: herbs, salad leaves, tomatoes, beans, and courgettes (zucchini) are productive and forgiving for beginners. Grow in containers if you have no garden; a sunny windowsill or balcony can produce herbs and salad all summer.

Do not try to grow everything in the first year. A small, successful patch that you enjoy tending is better than a large, weedy plot that becomes a chore. Save seeds from open-pollinated varieties where you can, swap plants and seeds with neighbours, and preserve gluts by freezing, bottling, or sharing them before they spoil. A glut of courgettes given away is better than a glut left to rot.

## 7.4 Transport: the journey is part of the household footprint

Transport is often the largest part of a household's overall footprint, and it is the part this manual can only touch on, because it depends on where you live, where you work, and what alternatives exist. The practical approach is to reduce the journeys you do not need, combine the ones you do, and choose the lowest-impact option that works for your situation.

Walk or cycle for short journeys where it is safe and practical; a journey of under two miles is often quicker by bicycle than by car in traffic, and it costs nothing in fuel. Combine errands into one trip rather than making several separate ones, and shop once a week rather than several times. Share lifts with neighbours for school runs and regular journeys. Use public transport where it is reliable and affordable. If you drive, drive smoothly — gentle acceleration, steady speed, and anticipating stops use less fuel than rapid acceleration and braking — keep tyres at the correct pressure, remove roof boxes and unnecessary weight when not in use, and service the car regularly. A car with under-inflated tyres can use several percent more fuel than one with correct pressures — an illustrative range of 2 to 5 percent.

When the time comes to replace a car, consider your actual needs: the size you need, the journeys you make, and the total cost of ownership, including fuel, insurance, maintenance, and depreciation, not just the purchase price. An electric vehicle, a hybrid, or a smaller petrol car may each be the right answer for different households; there is no single right choice, and this manual does not recommend one. What matters is making the decision with full information rather than on habit.

## 7.5 Outdoor equipment and the shed

Sheds and garages fill up with equipment that is used a few times a year: lawnmowers, strimmers, ladders, pressure washers, and tools. Before buying, ask whether you can borrow, hire, or share the item with a neighbour. A tool library, a hire shop, or an informal sharing arrangement with neighbours can save a great deal of money and storage space. When you do buy, choose durable, repairable equipment, maintain it — clean it, oil it, sharpen blades — and store it dry so it lasts. Choose manual or electric tools over petrol ones where they will do the job; they are quieter, need less maintenance, and produce no exhaust fumes in your garden.

## 7.6 Worked example: the garden numbers

Take a household that waters the garden with a sprinkler for two hours a week over a twenty-week summer — an illustrative pattern. At an illustrative 750 litres an hour, that is 30,000 litres a summer. Switching to a soaker hose and watering can, and watering only when the soil is dry, might cut that by half — an illustrative saving of 15,000 litres. At an illustrative water rate of $1.06 per 1,000 litres, that is about $16 a year — a small money saving, but a large water saving, and one that matters more in areas where water is scarce. Suppose they also start composting and stop buying bagged compost, saving an illustrative $50 a year, and grow herbs and salad worth an illustrative $100 a year at shop prices. The illustrative total is roughly $166 a year, plus a healthier garden. Your climate and garden size will change these numbers substantially.

## 7.7 Module 7 checklist

- [ ] Fitted a water butt to a downpipe.
- [ ] Mulched beds and borders.
- [ ] Switched from a sprinkler to a soaker hose or watering can.
- [ ] Started a compost bin or heap.
- [ ] Chose peat-free compost.
- [ ] Combined car journeys and checked tyre pressures.

---

# Module 8 — Energy: Heating, Cooling, Insulation, and Your Electricity Bill Explained

Modules 1 to 7 covered energy room by room. This module goes deeper, so you can understand your energy bill, your heating system, and the bigger investments — insulation, efficient heating, and solar — well enough to make confident decisions and to spot a bad deal.

## 8.1 Reading your energy bill

Start by finding three numbers on your bill: how much energy you used, in kilowatt-hours (kWh) for electricity and in kWh or therms for gas; what rate you pay per unit; and what fixed charges you pay per day or per month. Your total bill is the fixed charges plus the units used multiplied by the rate, plus taxes and any levies. If your bill is estimated rather than based on a meter reading, submit a reading so you are paying for what you actually used.

Track your usage over time, not just your spending. Prices change, so a higher bill does not always mean you used more energy. Write down your usage each month or each quarter in the tracker template, and compare the same period last year. Look for patterns: a sudden jump may mean a faulty appliance, a change in habits, or a meter error. A steady fall after you make changes is the evidence that those changes worked.

Understand the difference between power and energy. Power, measured in watts or kilowatts, is the rate at which an appliance uses energy. Energy, measured in kilowatt-hours, is power multiplied by time: a 1,000-watt appliance running for one hour uses 1 kilowatt-hour. A powerful appliance used briefly can cost less than a modest appliance left on all day. This is why standby power and forgotten lights matter, and why a kettle, which is powerful but brief, is not the villain it is sometimes made out to be.

## 8.2 Heating systems: know what you have

Find out what heats your home: a gas boiler, an electric system, a heat pump, oil, or something else. Each has different running costs, maintenance needs, and efficiency. A modern condensing gas boiler is more efficient than an old non-condensing one, but only if it is set up correctly — condensing boilers need a low return-water temperature to condense, so setting the flow temperature lower (around 55 to 60 degrees Celsius for radiators, if your system and comfort allow) can improve efficiency. Ask a qualified heating engineer about your specific system rather than changing settings blindly.

Heat pumps work differently from boilers: they move heat rather than creating it, and they work best at low flow temperatures with well-insulated homes and large radiators or underfloor heating. They can be an excellent choice in the right house and a poor one in the wrong house. If you are considering one, get an independent assessment of your home's heat loss and insulation first, and get quotes from several installers. Do not sign a contract on the basis of a single sales visit.

Service your heating system annually. A serviced boiler is safer and more efficient, and a service is the time to ask about settings, controls, and whether the system is sized correctly for your home. Bleed radiators, as in Module 4, and check that thermostatic radiator valves work — a valve stuck open overheats a room, and one stuck closed leaves it cold.

## 8.3 Insulation: the investment that pays every year

Insulation is the least glamorous and most effective energy investment in most homes. It reduces heat loss in winter and heat gain in summer, it makes every other heating improvement work better, and it lasts for decades. The priorities, in rough order of cost-effectiveness, are usually: loft or attic insulation, cavity wall insulation where the house has cavity walls, draught-proofing, and then floor insulation and solid wall insulation, which are more expensive and disruptive.

Loft insulation is the classic first step. The recommended depth varies by country and by material, but a common guideline is around 270 millimetres (about 11 inches) of mineral wool in the loft. If your loft has less than 100 millimetres, topping it up is usually a good investment with a payback of a few years — an illustrative range of two to five years depending on your heating costs and the current depth. Keep insulation away from recessed lights unless they are rated for it, do not block ventilation, and do not compress insulation, which reduces its effectiveness.

Cavity wall insulation fills the gap between the inner and outer walls of houses built with cavity walls. It is usually installed by a professional in a day, and it can cut heat loss through the walls substantially. It is not suitable for every house — houses in very exposed, wet locations, or with structural problems, need a survey first. Solid wall insulation, for older houses without cavities, is more expensive and can be fitted inside (losing a little room space) or outside (changing the appearance). Get specialist advice and several quotes before committing.

Do not forget the hot water cylinder and pipes. A cylinder jacket, or a factory-insulated cylinder, and insulated pipes keep hot water hot for longer and reduce the energy needed to reheat it. These are cheap measures with quick paybacks.

## 8.4 Windows, doors, and ventilation

Windows lose more heat per square metre than walls, but replacing them is expensive, and the payback can be long — an illustrative range of ten to twenty years or more, depending on the windows and the climate. Before replacing windows, try the cheaper steps: draught-proofing, heavy curtains, and secondary glazing or window film in the coldest rooms. When windows do need replacing anyway, choose double or triple glazing with a good energy rating, and make sure the installation is airtight.

Ventilation matters as much as insulation. A well-insulated, airtight house without ventilation will develop condensation, damp, and mould, which damage health and the building. Open windows regularly for short periods, use extractor fans in the kitchen and bathroom, and do not block air vents. If you have persistent condensation or mould, the cause is usually a combination of moisture, cold surfaces, and poor ventilation; fix the moisture source and the ventilation before reaching for chemical treatments, and seek professional advice if the problem is severe.

## 8.5 Appliances: what to replace, and when

When an appliance breaks, replace it with the most efficient model you can afford that meets your needs — but do not replace a working appliance solely to save energy, because the manufacturing cost of the new appliance and the money spent on it usually outweigh the energy saving for years. The exception is a very old, very inefficient appliance that runs continuously, such as an old fridge or freezer; there, the running cost can justify an earlier replacement.

Compare appliances by their energy label and by the estimated annual running cost, which is often shown on the label or in the product details. Size the appliance to your household: a washing machine, dishwasher, or fridge that is too large wastes energy and water. Look for repairability — appliances with available spare parts and a good repair network last longer and cost less over their lifetime than cheap appliances that cannot be fixed.

## 8.6 Solar panels and other generation: a careful look

Solar panels can be an excellent investment for some households and a poor one for others. The factors that decide it are: how much sun your roof receives and its orientation; how much electricity you use during the day, when the panels generate; the cost of installation; the price you pay for electricity and the price you receive for electricity you export; and any grants or incentives available in your area. A south-facing roof with little shading, a household that uses electricity during the day, and high electricity prices make the strongest case.

Do not decide on the basis of a sales presentation alone. Get quotes from at least three installers, ask for a written estimate of annual generation and savings based on your roof and your usage, and check the assumptions — especially the assumed electricity price rises, which are often optimistic. Check the warranty on panels and inverters, the expected lifetime of the inverter (usually shorter than the panels), and the reputation of the installer. Consider a battery only after you understand the panel economics on their own; batteries add cost and complexity, and they are not right for every household. This manual does not recommend for or against solar panels; it recommends that you decide with independent information and several quotes.

## 8.7 Worked example: the energy numbers

Take a household using 12,000 kilowatt-hours a year for heating and 3,500 kilowatt-hours for electricity — illustrative figures for a moderately sized house. Suppose loft insulation costing an illustrative $600 saves 15 percent of heating energy: 1,800 kilowatt-hours a year. At an illustrative $0.15 per kilowatt-hour for gas heating, that is $270 a year, a payback of just over two years. Suppose a new, efficient fridge saves an illustrative 200 kilowatt-hours a year of electricity: $40 a year at $0.20 per kilowatt-hour. The insulation is the better investment by a wide margin, and it also makes the house more comfortable. Your house, your fuel, and your prices will change these numbers; the method — cost divided by annual saving equals payback in years — is the same for every decision.

## 8.8 Module 8 checklist

- [ ] Found usage, rate, and fixed charges on the last energy bill.
- [ ] Started tracking monthly energy usage in the tracker.
- [ ] Checked the loft insulation depth.
- [ ] Had the heating system serviced and asked about flow temperature.
- [ ] Insulated the hot water cylinder and exposed pipes.
- [ ] Got three quotes before considering any large energy investment.

---

# Module 9 — Water: Where Your Water Goes, Leaks, and How to Use Less Without Noticing

Module 2 covered water in the bathroom. This module looks at the whole household's water use, so you can see where it goes, find the leaks, and decide which savings are worth pursuing.

## 9.1 Where household water goes

In a typical household, the largest indoor uses are the toilet, the shower and bath, the washing machine, and taps, with the dishwasher and cooking using less. Outdoors, garden watering dominates in summer. The exact split varies by household, and the only way to know yours is to measure it — which is why this module starts with measurement rather than with tips.

If you have a water meter, read it weekly for a month and write the readings in the tracker. Note anything unusual: a week when you were away should show near-zero use; a week with a leak will show higher use than expected. If you do not have a meter, your bill may show estimated usage; ask your provider for actual readings or for a meter if one is available in your area. Some providers offer free water-saving devices — low-flow showerheads, tap aerators, toilet displacement devices — so ask before buying them.

## 9.2 Finding and fixing leaks

Leaks are the most wasteful form of water use, because the water serves no purpose at all. The checks from Module 2 bear repeating here, because they are the most valuable checks in this module: the food-colouring test for the toilet, the paper test for fridge seals (for energy), and the meter test for the whole house. For the meter test, turn off all taps and water-using appliances, read the meter, wait an hour without using any water, and read it again. If the reading has changed, water is leaking somewhere. Check toilets, taps, and visible pipes first, then call a plumber if you cannot find the source.

Outside, check garden taps, hoses, and irrigation systems for leaks and drips, and check that automatic watering systems are not running in the rain. A hose left running can waste hundreds of litres in an hour — an illustrative figure that is easy to verify by timing how long it takes to fill a bucket from the hose.

## 9.3 The washing machine, the dishwasher, and the kitchen tap

The washing machine and dishwasher are covered in Modules 1 and 3, but their water use deserves a summary here: run them full, use eco settings, and choose a machine with a good water-efficiency rating when you replace one. A modern washing machine uses roughly 40 to 60 litres per load — an illustrative range — while an older machine can use twice that. Over 250 loads a year, the difference is thousands of litres.

In the kitchen, the habits from Module 1 apply: wash vegetables in a bowl rather than under a running tap, use the water to water plants afterwards, and fix dripping taps promptly. Keep a jug of water in the fridge rather than running the tap until it is cold, and use the cooking water from vegetables or pasta — once cooled — for watering plants, where it is safe to do so.

## 9.4 Water quality, softeners, and bottled water

Tap water in most developed countries is safe to drink and is tested regularly. Bottled water costs hundreds of times more per litre than tap water and creates plastic waste, so the sustainable and economical choice for most households is tap water, with a reusable bottle for carrying it. If you dislike the taste, a simple filter jug or a tap filter can help; choose one with replaceable cartridges and compare the running cost. A filter is a personal choice, not a necessity, and this manual does not claim tap water is unsafe.

Water softeners are useful in hard-water areas: they reduce limescale, which can damage appliances and make soap less effective. They also use salt and water to regenerate, so they have their own running cost. If you have very hard water and limescale is damaging your appliances, a softener may be worth it; if your water is soft or moderately hard, it probably is not. Check your water hardness with your provider before deciding.

## 9.5 Rainwater, greywater, and reuse

Rainwater harvesting was covered in Module 7 for the garden. Greywater — water from baths, showers, and hand basins, reused for toilet flushing or garden watering — is a larger step, and it needs careful design to be safe and legal. Simple, safe reuse is available to everyone: a bowl in the sink for vegetable washing water, a bucket in the shower to catch the water while it warms up, and using that water for plants or cleaning. More complex greywater systems should be designed and installed by professionals and checked against local regulations. This manual does not recommend a specific system; it recommends starting with the simple reuse habits and seeking professional advice before investing in a system.

## 9.6 Worked example: the water numbers

Take a household of four using an illustrative 400 litres a day indoors, or 146,000 litres a year. Suppose fixing a leaking toilet saves 100 litres a day — an illustrative figure for a moderate leak — or 36,500 litres a year. Suppose low-flow showerheads and shorter showers save a further 100 litres a day, or 36,500 litres a year. The combined saving is 73,000 litres a year, or half of the household's indoor use. At an illustrative combined water and wastewater rate of $2.12 per 1,000 litres (about $8 per 1,000 gallons), the saving is about $155 a year — and the energy saving on the hot water, covered in Module 2, is larger still. Your rates will differ, and in some areas water is metered and charged differently; use your own bill to calculate your own saving.

## 9.7 Module 9 checklist

- [ ] Read the water meter weekly for a month and recorded the readings.
- [ ] Did the meter test for leaks and the food-colouring test for the toilet.
- [ ] Fixed any leaks found.
- [ ] Set up simple water reuse: a bowl for vegetable water, a bucket for the warming-up shower water.
- [ ] Checked water hardness with the provider.

---

# Module 10 — Shopping and Daily Habits: Buying Less, Buying Better, and Making It Stick

The first nine modules changed rooms and systems. This module changes the decisions that fill those rooms: what you buy, how often you buy it, and how you decide. Shopping is where most household consumption begins, and it is where the most durable savings are made — not by buying "green" versions of everything, but by buying less, buying better, and using what you buy for longer.

## 10.1 The hierarchy: refuse, reduce, reuse, repair, recycle

The familiar waste hierarchy is worth stating plainly, in order, because the order matters. Refuse what you do not need. Reduce what you do need. Reuse what you have. Repair what breaks. Recycle what cannot be reused or repaired. Recycling is last, not first: it is better than landfill, but it still uses energy and resources, and it should be the final step for materials that have no other use.

Apply the hierarchy to a purchase before you make it. Can you refuse it — do you actually need it? Can you reduce it — buy a smaller quantity, or share it? Can you reuse something you already have? Can you repair the item you are replacing? Only when the answer to all of those is no should you buy new, and then the question becomes: what is the best version of this to buy?

## 10.2 Buying less: the pause, the list, and the one-in-one-out rule

The most effective shopping habit in this manual is the pause. For any non-essential purchase over a threshold you set — say $30, or whatever fits your budget — wait 48 hours before buying. Put the item on a list, with the date, and revisit it after two days. Most impulse purchases lose their appeal within that time. The ones that survive the pause are the ones worth buying.

Shop with a list for groceries, and with a list for everything else too. A list for clothes, for household goods, and for gifts prevents the duplicate and impulse purchases that fill cupboards. Use the one-in-one-out rule for categories that tend to accumulate: for every new item of clothing, book, or gadget that comes in, one leaves — sold, donated, or recycled. The rule is not a punishment; it is a way to keep the house from filling up faster than you can use what is in it.

Unsubscribe from marketing emails and catalogues that tempt you to buy things you did not plan to buy. This is a small step with a surprisingly large effect, because much impulse buying is triggered by a message arriving at the right moment. Keep the subscriptions that genuinely help you — for example, a reminder to reorder something you use regularly — and remove the rest.

## 10.3 Buying better: quality, durability, and total cost

When you do buy, buy for total cost, not for purchase price. A cheap item that lasts a year and a more expensive item that lasts five years: the expensive item is cheaper per year, and it creates less waste. Look for durability, repairability, and warranty. Check whether spare parts are available, whether the item can be repaired locally, and whether the manufacturer offers a repair service. Read reviews that mention longevity, not just first impressions.

Consider second-hand first for items where it makes sense: furniture, books, children's clothes and toys, sports equipment, and many electronics. Check the item carefully, test it where possible, and buy from a seller you trust. For items where hygiene or safety matters — mattresses, safety equipment, car seats — buy new, or buy second-hand only from a source you trust completely.

Packaging is part of the purchase. Choose products with less packaging where the choice is genuine, choose larger sizes where you will use them, and choose refillable options where they are available and genuinely cheaper. Do not pay a large premium for packaging that claims to be sustainable without evidence; the product inside matters more than the box.

## 10.4 The low-waste shopping guide

The templates folder contains a low-waste shopping guide you can print and keep. Its principles are simple. Bring your own bags, every time, and keep spares in the car and by the door. Bring reusable produce bags or use no bag for items that do not need one. Buy loose fruit and vegetables rather than pre-packaged where the price is fair. Buy staples — rice, pasta, oats, flour, beans — in larger packs or from refill stations where they exist. Choose products in glass, metal, or cardboard over single-use plastic where the product is the same and the price is comparable, but do not assume one material is always better: a heavier glass jar shipped a long distance can have a larger footprint than a light plastic pouch, and the right choice depends on the product, the distance, and whether the container is reused or recycled.

Plan food shopping around the meal plan from Module 1, and shop once a week rather than several times. A weekly shop reduces impulse buying, reduces journeys, and makes the meal plan work. Keep a well-stocked store cupboard of the staples you use every week, so you are not forced into an emergency shop for a single ingredient.

## 10.5 Daily habits: the small routines that hold the savings

Sustainability is not a project with an end date; it is a set of routines. The routines that matter most are the ones you can do without thinking, because they are built into the layout of your home and the shape of your day. Keep the recycling and compost bins where the waste is produced, not in a distant corner. Keep reusable bags by the door. Keep the drying rack set up where it is easy to use. Keep the thermostat schedule set so you do not have to remember to turn the heating down. Keep the shopping list on the fridge so it is always ready.

Build habits in pairs: attach a new habit to an existing one. Check the "eat first" box when you open the fridge to cook. Turn the power strip off when you turn the television off. Put the reusable bags back by the door when you unpack the shopping. Habits attached to a trigger survive; habits that rely on remembering do not.

Expect setbacks. You will forget, you will buy something on impulse, you will have a week where the food waste goes up. That is normal, and it is not a reason to stop. The households that succeed are not the ones that never slip; they are the ones that notice the slip, work out why it happened, and adjust the system — a better list, a more visible bin, a different shopping day — so it is less likely next time.

## 10.6 Talking about it: the household as a team

A household sustainability plan only works if the household is part of it. Share the baseline numbers from Module 1, agree on two or three changes to start with, and divide the tasks fairly. Children can take part in the food-waste diary, the recycling, and the garden; teenagers can take responsibility for their own laundry and their own room. Make the savings visible: a chart on the fridge showing the electricity or water use each month, or a jar where the money saved from not buying something is put aside for something the household wants. Celebrate the wins, however small, and do not turn sustainability into a source of blame. The goal is a household that is proud of what it is doing, not a household that is policed.

## 10.7 Worked example: the shopping numbers

Take a household that spends an illustrative $600 a month on groceries and $200 a month on household goods and clothing. Suppose meal planning and the pause rule cut grocery spending by 10 percent — $60 a month, or $720 a year — mostly by reducing waste and impulse buying. Suppose the one-in-one-out rule and the 48-hour pause cut household and clothing spending by 20 percent — $40 a month, or $480 a year. The illustrative total is $1,200 a year. These are illustrative percentages, not promises; your spending and your habits will differ, and the workbook helps you track your own spending before and after. The point is that shopping habits, like food waste, are worth more than most energy measures in money terms, and they require no investment at all.

## 10.8 Module 10 checklist

- [ ] Set a 48-hour pause threshold for non-essential purchases.
- [ ] Started a shopping list for every category, not just groceries.
- [ ] Applied the one-in-one-out rule to one category.
- [ ] Unsubscribed from five marketing lists that trigger impulse buying.
- [ ] Printed the low-waste shopping guide and kept it with the shopping bags.

---

# The 30-Day Green Habits Challenge

Start this challenge after Module 10, or alongside Module 1 if you prefer. Each day has one small action, taking five to thirty minutes. Tick each day off in the workbook tracker. If you miss a day, do it the next day — the challenge is a structure, not a test.

**Week 1 — Measure and see.** Day 1: Read your electricity, gas, and water meters and write the readings in the tracker. Day 2: Start the one-week food-waste diary. Day 3: Measure your shower flow with a bucket and a timer. Day 4: Check the fridge temperature and the door seals. Day 5: Check the toilet for leaks with food colouring. Day 6: List every device on standby in the living room. Day 7: Rest day — review the week's findings and choose your first three changes.

**Week 2 — The kitchen and the bathroom.** Day 8: Build your template week of five dinners and write the shopping list. Day 9: Create the "eat first" box in the fridge and label leftovers. Day 10: Fit a low-flow showerhead or tap aerators. Day 11: Shorten every shower by two minutes. Day 12: Switch the washing machine to cold washes. Day 13: Set up the three kitchen bins — recycling, compost, and general waste. Day 14: Rest day — cook a meal entirely from what is already in the fridge and cupboards.

**Week 3 — The house.** Day 15: Lower the heating setpoint by one degree and set a schedule. Day 16: Replace the five most-used bulbs with LEDs. Day 17: Put entertainment electronics on a switched power strip. Day 18: Find and seal the worst draught. Day 19: Set up a drying rack and air-dry a full load. Day 20: Do a wardrobe audit and pass on one bag of clothes. Day 21: Rest day — walk or cycle for a journey you would normally drive.

**Week 4 — Shopping and the plan.** Day 22: Unsubscribe from five marketing lists. Day 23: Do a weekly shop from a list, with a 48-hour pause on anything not on it. Day 24: Start a compost bin or sign up for food-waste collection. Day 25: Mulch a bed or water the garden with a can instead of a sprinkler. Day 26: Write your household sustainability plan using the template in the workbook. Day 27: Share the plan with the household and agree who does what. Day 28: Read your meters again and compare with Day 1. Day 29: Calculate your savings so far using the tracker. Day 30: Choose the next three changes for the coming month, and set a date to review them.

---

# Your Household Sustainability Plan: Putting It All Together

You now have the information. The final step is to write it down as a plan, because a plan written down is a plan that gets done. Use the worksheet in the workbook, and keep it to one page.

Write your baseline: your monthly electricity use, gas use, and water use from your bills, and your weekly food-waste cost from your diary. Write your three priorities — the changes that save the most money or matter most to you. Write the next three actions, with a date for each. Write who is responsible for each action. Write the date you will review the plan, in one month and in three months.

Review the plan on those dates. Read the meters, compare with the baseline, and note what worked and what did not. Keep the changes that worked, drop or adjust the ones that did not, and add the next three actions. Repeat. That is the whole system: measure, choose, act, review, repeat. It is not dramatic, and it is not fast, but it is how households actually cut their bills and their waste, year after year.

The outcome this masterclass promises is a modest one, and it is stated honestly. If you work through the modules, complete the audit, and finish the 30-day challenge, you will have a written plan for your home, a measured baseline, and a set of changes already in place. You will know where your energy and water go, how much your food waste costs, and which changes are worth your money and which are not. Your bills and your waste should fall — by how much depends on your household, your climate, and your rates, and no honest manual can promise a number in advance. What it can promise is that you will be making decisions with real information about your own home, rather than with guesswork and conflicting advice. That is the point of the whole course.

---

## Appendix A — How to Read Your Utility Bills

Find the account number, the billing period, and whether the reading is actual or estimated. Find the usage in kilowatt-hours or cubic metres, the rate per unit, and the fixed daily or monthly charge. Find any taxes, levies, or discounts, and check that the discount has actually been applied. If anything is unclear, call your provider and ask them to explain the bill line by line; that is a normal request, and it is the fastest way to understand what you are paying for. Keep the last twelve months of bills, or download them, so you can compare the same month year on year.

## Appendix B — Glossary

**Kilowatt-hour (kWh):** A unit of energy. One kilowatt-hour is the energy used by a 1,000-watt appliance running for one hour. **Flow rate:** The volume of water flowing from a tap or showerhead per minute, usually in litres per minute. **Draught-proofing:** Sealing gaps around doors and windows to stop cold air entering. **Condensing boiler:** A gas boiler that recovers heat from exhaust gases and is more efficient than an older boiler when set up correctly. **Heat pump:** A device that moves heat from outside to inside, rather than creating heat by burning fuel. **Greywater:** Water from baths, showers, and hand basins that can be reused for some purposes. **Payback period:** The time taken for the savings from an investment to equal its cost.

## Appendix C — Further Reading and Where to Check Local Rules

Utility rates, rebates, recycling rules, building codes, and water regulations vary by country, region, and provider. Check your own utility provider's website for current rates, rebates, and free water-saving devices. Check your local authority's website for recycling, food-waste collection, and textile recycling rules. Check your national energy agency for insulation guidance and for any grants available in your area. For electrical, gas, plumbing, and structural work, follow local codes and use licensed professionals where required.

---

*End of the manual. Your next step is the workbook: complete the household sustainability audit in Worksheet 1, then work through the room-by-room checklists as you read each module.*
