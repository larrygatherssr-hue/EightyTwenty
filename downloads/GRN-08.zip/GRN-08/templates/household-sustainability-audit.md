# Household Sustainability Audit

Use this template with Worksheet 1 of the workbook. Complete it before making any changes, so you have a baseline to compare against. All figures are your own household's figures — there are no right answers, only your starting point.

## Your Household

- People in the home: ______
- Adults: ______ Children: ______
- Home type: ______
- Bedrooms: ______
- Approximate age of home: ______
- Heating type: ______
- Water heating type: ______

## Your Bills (from your last bills)

| Item | Usage per month | Rate per unit | Monthly cost |
|---|---|---|---|
| Electricity | ______ kWh | $______ per kWh | $______ |
| Gas | ______ | $______ | $______ |
| Water | ______ litres / gallons | $______ | $______ |
| **Total** | | | **$______** |

## Meter Readings

| Meter | Reading today (date: ______) | Reading in one month (date: ______) | Usage |
|---|---|---|---|
| Electricity | | | |
| Gas | | | |
| Water | | | |

## Fridge and Freezer

- Fridge temperature: ______ °C / °F (aim for 1–4 °C / 34–40 °F)
- Freezer temperature: ______ °C / °F (aim for −18 °C / 0 °F or below)
- Door seal test — paper slides out easily? Yes / No
- Coils last cleaned: ______

## Shower and Taps

- Shower flow rate: ______ litres per minute (bucket test)
- Shower length: ______ minutes
- Tap aerators fitted? Yes / No
- Dripping taps found: ______

## Toilet

- Toilet type: single flush / dual flush
- Food-colouring leak test done: Yes / No — Result: ______
- Displacement device fitted? Yes / No

## Leaks

- Meter test done: Yes / No — Reading before: ______ Reading after one hour: ______ Changed? Yes / No

## Food Waste (one-week diary)

| Day | Item | Amount | Cost | Reason |
|---|---|---|---|---|
| Mon | | | | |
| Tue | | | | |
| Wed | | | | |
| Thu | | | | |
| Fri | | | | |
| Sat | | | | |
| Sun | | | | |
| **Total** | | | **$______** | Main cause: ______ |

## Laundry, Lighting, and Heating (quick check)

- Washing loads per week: ______
- Usual wash temperature: ______
- Loads tumble-dried per week: ______
- Bulbs already LED: ______ of ______
- Heating setpoint: ______ °C / °F
- Loft insulation depth: ______ mm / inches
- Heating last serviced: ______

## Your Three Biggest Findings

1. ________________________________________________________________________
2. ________________________________________________________________________
3. ________________________________________________________________________

## Your First Three Actions

| Action | Who | By when |
|---|---|---|
| | | |
| | | |
| | | |

---

*Education only. All savings you estimate from this audit depend on your household size, climate, home, appliances, utility rates, and habits. Figures in the course manual are illustrative ranges, not promises.*
