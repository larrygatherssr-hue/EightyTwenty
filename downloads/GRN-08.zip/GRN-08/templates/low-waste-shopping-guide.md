# Low-Waste Shopping Guide

Print this guide and keep it with your shopping bags. It is a practical companion to Module 10 of the course manual.

## Before You Leave the House

- Check the fridge, freezer, and cupboards. Write the shopping list from your meal plan, not from memory.
- Bring reusable shopping bags — and keep spares in the car and by the front door so you are never without one.
- Bring reusable produce bags, or plan to buy loose items without a bag where they do not need one.
- Bring a reusable water bottle and, if you buy coffee out, a reusable cup.
- Bring the list. Anything not on it gets a 48-hour pause unless it is an essential you have run out of.

## At the Shop

- Buy loose fruit and vegetables rather than pre-packaged where the price is fair and the quality is the same.
- Buy staples — rice, pasta, oats, flour, beans, lentils — in larger packs or from refill stations where they exist and you will use them before they spoil.
- Buy the size you will actually use. A large pack that goes off is more wasteful than a small pack that gets used.
- Choose products in glass, metal, or cardboard over single-use plastic where the product is the same and the price is comparable. Remember that the right choice depends on the product, the distance it travelled, and whether the container is reused or recycled — a heavier container shipped a long distance is not automatically the better choice.
- Choose bars over bottles where you like them — soap bars and shampoo bars use less packaging and often last longer.
- Avoid single-use items where a reusable alternative works for you: cloths instead of paper towels, a washcloth instead of disposable wipes.
- Read the label for what matters to you — a short ingredient list, a refill option, a certification you trust — and be sceptical of vague words such as "natural" or "eco" with no specific claim behind them.

## Food Shopping — The Items Most Often Wasted

Fresh herbs, salad leaves, soft fruit, and bread spoil fastest. Buy these in smaller amounts, more often, or choose longer-lasting alternatives — frozen vegetables, hardier greens, whole fruit rather than pre-cut — for the days when you cannot shop again. Freeze bread on the day you buy it and take out only what you need.

## Non-Food Shopping

- For any non-essential purchase over your pause threshold (suggested: $30 — set your own), wait 48 hours before buying. Put it on a list with the date, and revisit it after two days.
- Ask the three questions: do I need it, do I have space for it, and will I still want it in a year?
- Consider second-hand first for furniture, books, children's clothes and toys, sports equipment, and many electronics. Check the item carefully and test it where possible.
- Buy for durability, repairability, and warranty — and check that spare parts are available before you buy.
- Use the one-in-one-out rule: for every new item of clothing, book, or gadget that comes in, one leaves.

## When You Get Home

- Put the reusable bags back by the door immediately, so they are ready next time.
- Put new food at the back of the fridge and older food at the front. Put anything that needs using soon in the "eat first" box.
- Freeze anything you will not use before it spoils, in portion sizes, labelled with the contents and the date.
- Update the freezer list on the freezer door.

## Monthly Check

- Unsubscribe from one marketing list that triggers impulse buying.
- Review your pause list: what did you still want after 48 hours, and what did you happily do without?
- Compare this month's grocery spending with last month's, and note what changed.

---

*Education only. This guide offers general suggestions, not guarantees of savings. Your results depend on your household, your shops, and your habits.*
