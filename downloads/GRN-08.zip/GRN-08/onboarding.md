# Onboarding Guide — The Sustainable Living Masterclass

Welcome. This guide tells you what to do first, how to use the materials, and how to work through the course in ten weeks.

**Format note:** This is a complete written course manual, NOT a video course. There are no videos included. Everything you need is in the files listed below.

## What You Received

- **content.md** — the full written course manual (over 16,000 words, 10 modules, plus the 30-day challenge and appendices).
- **workbook.md** — the companion workbook with 13 worksheets.
- **templates/energy-water-savings-tracker.csv** — a twelve-month tracker for electricity, gas, water, and food waste.
- **templates/household-sustainability-audit.md** — a printable audit template.
- **templates/low-waste-shopping-guide.md** — a printable shopping guide to keep with your bags.
- **sales-page.md** — the sales page for this product, kept for reference.
- **cover.png** — the cover image.
- **cover.md** — the cover design brief.
- **README.md** — the file index for this product.

All files are standard formats (Markdown, CSV, PNG) that open in any text editor, word processor, or spreadsheet app. No account, software licence, or special app is required.

## What to Do First (Day 1)

1. Save the files somewhere you can find them, and print the workbook or open it in your word processor.
2. Read the "How to Use This Manual" section at the start of content.md.
3. Complete Worksheet 1 in the workbook — the household sustainability audit. Find your last electricity, gas, and water bills, read your meters, check the fridge temperature, measure your shower flow, and start the one-week food-waste diary. This is your baseline, and everything else builds on it. Do not skip it, and do not change anything until the baseline week is done.
4. Print the low-waste shopping guide and put it with your shopping bags.

## Suggested Schedule (Ten Weeks)

- **Week 1:** Module 1 (Kitchen) + Worksheet 2. Start the food-waste diary.
- **Week 2:** Module 2 (Bathroom) + Worksheet 3. Fit a low-flow showerhead and tap aerators if you plan to.
- **Week 3:** Module 3 (Laundry) + Worksheet 4. Switch to cold washes and set up a drying rack.
- **Week 4:** Module 4 (Living Room) + Worksheet 5. Lower the heating by one degree and replace the most-used bulbs with LEDs.
- **Week 5:** Module 5 (Bedroom) + Worksheet 6. Do the wardrobe audit.
- **Week 6:** Module 6 (Home Office) + Worksheet 7. Set up the workstation power strip and printer defaults.
- **Week 7:** Module 7 (Garden and Outdoors) + Worksheet 8. Fit a water butt and start composting if you can.
- **Week 8:** Module 8 (Energy) + Worksheet 9. Check loft insulation and book a heating service.
- **Week 9:** Module 9 (Water) + Worksheet 10. Do the meter leak test and set up simple water reuse.
- **Week 10:** Module 10 (Shopping and Daily Habits) + Worksheet 11. Set your pause threshold and unsubscribe from five marketing lists.
- **Then:** The 30-day green habits challenge (Worksheet 12), followed by your one-page household sustainability plan (Worksheet 13).

You can work faster if you prefer — two modules a week, or one module a day. The schedule above is a suggestion, not a rule. If you prefer, start the 30-day challenge alongside Week 1 and use it as a companion while you read.

## How to Use the Tracker

Open templates/energy-water-savings-tracker.csv in any spreadsheet app. Each month, enter your meter readings, the usage for the month, your rate per unit, and the cost. Enter your food-waste total for one week each month. Over time, the tracker shows whether your usage and your spending are falling, and by how much. Compare the same month with the same month last year, not with a different season, because heating and garden watering vary by season.

## How to Get Support

Email the marketplace support address with your order number and a description of your question. Support can help with downloads and with using the files — for example, a file that will not open, or a question about how to apply a worksheet. Support cannot provide individualized financial, legal, engineering, tax, or medical advice. For electrical, plumbing, gas, or structural work, consult a licensed professional where required and follow local building codes and safety rules.

## A Note on Expectations

Savings depend on your household size, climate, home, appliances, utility rates, and habits. The manual's figures are illustrative ranges with their assumptions stated, so you can calculate your own numbers from your own bills. No specific saving is promised. What the course does promise is a written plan, a measured baseline, and a set of changes already in place by the end of the challenge — and the knowledge to decide, with real information about your own home, which changes are worth your money and which are not.
