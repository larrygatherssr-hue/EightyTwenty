# GRN-08 — The Sustainable Living Masterclass: Lower Bills, Less Waste, Greener Home

**Price:** $97 (one-time) · **Category:** Green Living & Sustainability · **Billing:** one_time

A broad lifestyle masterclass covering energy saving, waste reduction, sustainable shopping, and low-impact daily habits, for environmentally concerned households wanting a practical, room-by-room plan to live more sustainably and cut household bills.

**Format:** A complete written course manual, NOT a video course. There are no videos included.

## Files

| File | What it is |
|---|---|
| `content.md` | The full written course manual — over 16,000 words, 10 fully written modules (kitchen, bathroom, laundry, living room, bedroom, home office, garden/outdoors, energy, water, shopping/habits), the 30-day green habits challenge, your household plan, and appendices. |
| `workbook.md` | Companion workbook — 13 worksheets: household sustainability audit, one worksheet per module, 30-day challenge tracker, one-page plan, and room-by-room checklists. |
| `templates/energy-water-savings-tracker.csv` | Twelve-month tracker for electricity, gas, water, and food waste. |
| `templates/household-sustainability-audit.md` | Printable household sustainability audit template. |
| `templates/low-waste-shopping-guide.md` | Printable low-waste shopping guide. |
| `sales-page.md` | Full sales page: headline, problem, solution, module list, who it is for / not for, price and guarantee, FAQ, and disclaimers. |
| `listing.json` | Marketplace listing data (SKU, name, category, price_cents 9700, billing, headline, description, delivery note, SEO keywords, refund policy, support). |
| `cover.md` | Cover design brief (black-and-gold luxury, gold-on-black). |
| `cover.png` | Cover image, portrait 1280 × 1920, black-and-gold. |
| `onboarding.md` | Customer onboarding guide: what to do first, how to use the materials, ten-week schedule, support. |

## Notes

- All savings figures are illustrative ranges with explicit caveats; actual results depend on household size, climate, home, appliances, utility rates, and habits.
- Education only — not financial, legal, engineering, or professional advice.
- All content is original. No testimonials, sales figures, certifications, or reviews are claimed.
