# Spa & Wellness Business Builder — Companion Workbook

Use this workbook alongside the course text. Each exercise turns a module into a decision or a document you can use in your spa. Print it, or copy the tables into your own files. Fill in your real numbers — guesses are fine as a first pass, but replace them with actual figures within 30 days.

> **Disclaimer:** This workbook is education only. It does not provide medical, legal, tax, or financial advice. Licensing, scope of practice, and health and safety rules vary by state, province, and country. Confirm the requirements that apply where you operate with your state licensing board, local health department, and a qualified attorney or accountant before you open, expand, or advertise any service.

---

## Exercise 1.1 — Your Three Numbers (Module 1)

| Number | Current | Target (month 6) | Target (month 12) |
|---|---|---|---|
| Utilisation (%) | | 60% | 65–70% |
| Revenue kept per treatment hour ($) | | | |
| Rebooking rate (%) | | 50% | 60% |

**How to calculate utilisation:** Booked treatment hours this month ÷ bookable treatment hours this month × 100.

**How to calculate revenue kept per treatment hour:** (Treatment revenue − product cost − therapist cost) ÷ treatment hours delivered.

**How to calculate rebooking rate:** Clients who booked their next appointment before leaving or within 30 days ÷ all clients seen this month × 100.

**My weakest number is:** ____________________
**The first action I will take on it is:** ____________________

---

## Exercise 1.2 — The Seasonal Map

| Month | Expected demand (High / Medium / Low) | What will smooth it? (membership, gift cards, packages, retail push) |
|---|---|---|
| January | | |
| February | | |
| March | | |
| April | | |
| May | | |
| June | | |
| July | | |
| August | | |
| September | | |
| October | | |
| November | | |
| December | | |

---

## Exercise 2.1 — Competitor Map (Module 2)

Research five competitors within a 20-minute drive. Record facts, not opinions.

| Competitor | Top 5 treatments | Price range | Booking experience (easy / hard) | One weakness I can beat |
|---|---|---|---|---|
| 1. | | | | |
| 2. | | | | |
| 3. | | | | |
| 4. | | | | |
| 5. | | | | |

**My positioning sentence:** "We help ____________________ get ____________________ through ____________________."

Test it on three people who match your target client. Could they repeat it back? Yes / No — notes: ____________________

**My lane (circle one):** Day spa / Wellness studio / Results-driven skin studio / Med-spa-adjacent practice / Mobile or home-based

---

## Exercise 3.1 — Revenue Mix Targets (Module 3)

| Revenue stream | Month 1 target ($) | Month 6 target ($) | Month 12 target ($) |
|---|---|---|---|
| Single treatments | | | |
| Memberships | | | |
| Packages / series | | | |
| Retail (kept margin) | | | |
| Gift cards | | | |
| **Total** | | | |

**My capacity ceiling:** ______ rooms × ______ hours/day × ______ days/week = ______ bookable hours/month.
At ______% utilisation and $______ average price, my maximum monthly treatment revenue is $______.

---

## Exercise 4.1 — Menu Draft (Module 4)

List 12–18 treatments. Each needs an outcome line, a duration (30/60/90), and a price (validate in Exercise 5.1).

| # | Treatment name | Outcome line (how the client will feel) | Duration | Price ($) | Box (Star / Workhorse / Hidden gem / Dog) |
|---|---|---|---|---|---|
| 1 | | | | | |
| 2 | | | | | |
| 3 | | | | | |
| 4 | | | | | |
| 5 | | | | | |
| 6 | | | | | |
| 7 | | | | | |
| 8 | | | | | |
| 9 | | | | | |
| 10 | | | | | |
| 11 | | | | | |
| 12 | | | | | |

**My signature treatment:** ____________________
**Its special ritual (foot soak, scalp massage, take-home product, etc.):** ____________________
**My entry-point treatment:** ____________________ — conversion goal: ______% rebook a full treatment within 30 days.

---

## Exercise 5.1 — Pricing Build-Up (Module 5)

Cost out your top 8 treatments. Use the pricing calculator CSV in templates/ for the full version.

| Treatment | Price ($) | Product cost ($) | Therapist cost ($) | Overhead/hour ($) | Total cost ($) | Profit ($) | Profit % | Action (keep / raise / change / remove) |
|---|---|---|---|---|---|---|---|---|
| 1. | | | | | | | | |
| 2. | | | | | | | | |
| 3. | | | | | | | | |
| 4. | | | | | | | | |
| 5. | | | | | | | | |
| 6. | | | | | | | | |
| 7. | | | | | | | | |
| 8. | | | | | | | | |

**My overhead per treatment hour:** $______ (monthly overhead $______ ÷ ______ realistic monthly treatment hours).
**My annual price-review date:** ____________________

---

## Exercise 6.1 — Membership Tiers (Module 6)

Fill in your three tiers using your own treatment costs. Test the margin with the membership template before publishing.

| | Tier 1 — The Ritual | Tier 2 — The Renewal | Tier 3 — The Sanctuary |
|---|---|---|---|
| Monthly price ($) | | | |
| Included treatments | | | |
| Discount on extras | | | |
| Retail discount | | | |
| Guest passes | | | |
| Rollover rule | | | |
| Other perks | | | |

**Membership maths check:** ______ members × average $______ = $______ monthly membership revenue.
Average delivery cost per member per month: $______. Monthly membership margin: $______.

**My membership terms:** Minimum term ______ months. Freeze: ______. Cancellation notice: ______ days. Unused credits on cancellation: expire / other ______.

**Target:** ______ members by month 12 (20% of active clients).

---

## Exercise 7.1 — Client Journey Audit (Module 7)

Book an appointment on your own system as a stranger would, then answer honestly:

- Could I book online in under 3 minutes without calling? Yes / No — what got in the way? ____________________
- Did I receive a confirmation immediately? Yes / No
- Did I receive a reminder 24 hours before? Yes / No
- Is my cancellation policy stated at booking? Yes / No — wording: ____________________
- Does my intake form ask about health conditions, allergies, pregnancy, skin sensitivities, and medications? Yes / No — missing: ____________________

**My rebooking script (write it word for word):** "____________________"

**My three automated messages:** (1) Confirmation — set up? Yes / No. (2) 24-hour reminder — Yes / No. (3) 24-hour thank-you — Yes / No.

**Lapsed-client rule:** Clients who have not visited in ______ days receive a personal message. My message: "____________________"

---

## Exercise 8.1 — Operations Manual Starter (Module 8)

Write the first version of each procedure in one or two sentences of clear steps. Expand them in the operations manual template.

- **Opening procedure:** ____________________
- **Room reset procedure:** ____________________
- **Closing procedure:** ____________________
- **Handling a complaint:** ____________________
- **Refund procedure:** ____________________

**Weekly team meeting day/time:** ____________________
**Monthly numbers review day:** ____________________
**My fixed monthly pay (owner's draw):** $______

---

## Exercise 9.1 — Supplier and Equipment Checklist (Module 9)

| Item | Supplier | Cost ($) | Cost per treatment ($) | Delivery date | Notes |
|---|---|---|---|---|---|
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |

**Five improvements to my space under $100 each:**
1. ____________________
2. ____________________
3. ____________________
4. ____________________
5. ____________________

---

## Exercise 10.1 — Grand-Opening Plan (Module 10)

| When | Action | Owner | Budget ($) | Done? |
|---|---|---|---|---|
| 8 weeks before | | | | |
| 6 weeks before | | | | |
| 4 weeks before | | | | |
| 2 weeks before | | | | |
| Opening week | | | | |
| 4 weeks after | | | | |

**Referral programme:** Referrer receives ____________________. Referred friend receives ____________________. Terms: ____________________

**My year-one milestones:** Month 1: ______ clients, ______% rebooking. Month 3: ______ members. Month 6: ______% utilisation. Month 12: ______ members, ______% of revenue from returning clients.

---

## Monthly Numbers Review — Copy This Page Each Month

| Month: __________ | This month | Last month | Target |
|---|---|---|---|
| Utilisation (%) | | | |
| Sessions delivered | | | |
| Revenue per treatment hour ($) | | | |
| Rebooking rate (%) | | | |
| Active clients | | | |
| Members (total / Tier 1 / Tier 2 / Tier 3) | | | |
| Membership revenue ($) | | | |
| Retail sales ($) | | | |
| Gift-card sales ($) | | | |
| Total revenue ($) | | | |
| Total costs ($) | | | |
| Surplus / (shortfall) ($) | | | |

**One thing that worked this month:** ____________________
**One thing to fix next month:** ____________________
**One thing to stop doing:** ____________________

---

## 30-Day Action Plan

| Days | Actions | Done? |
|---|---|---|
| 1–7 | Exercises 1.1, 2.1, 5.1 — know your numbers, competitors, and true costs | |
| 8–14 | Draft menu and price it; build three membership tiers | |
| 15–21 | Operations manual starter, supplier checklist, grand-opening plan | |
| 22–30 | Set launch/relaunch date; set price-review date; book first weekly numbers review | |

---

*Spa & Wellness Business Builder — companion workbook. Education only; licensing and regulations vary by state and country.*
