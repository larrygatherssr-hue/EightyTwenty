# BEA-07 — Spa & Wellness Business Builder

**Price:** $497 (one-time) · **Category:** Beauty & Health · **SKU:** BEA-07

A business-development programme for launching and growing a spa or wellness studio — concept, menu design, pricing, memberships, and operations — for licensed massage therapists, estheticians, and wellness practitioners.

## Files

| File | What it is |
|---|---|
| `content.md` | Full 10-module course text with worked examples (treatment pricing build-ups, 100-member revenue model, complete 12-month projection), glossary, and 30-day plan |
| `workbook.md` | Companion workbook — exercises, worksheets, and checklists for every module, plus a monthly numbers review sheet |
| `templates/spa-menu-pricing-calculator.csv` | Spa menu and treatment-pricing calculator (10 example treatments + 8 blank rows) |
| `templates/membership-model-templates.csv` | Membership model templates — 3 tiers (The Ritual $79, The Renewal $139, The Sanctuary $219) |
| `templates/membership-model-templates.md` | Worked 100-member revenue model, membership terms, and sensitivity check |
| `templates/operations-manual-template.md` | Fill-in operations manual template |
| `templates/supplier-equipment-checklist.csv` | Supplier and equipment checklist |
| `templates/grand-opening-marketing-plan.md` | Grand-opening marketing plan (8-week timeline, weekly rhythm, referral programme, budget) |
| `sales-page.md` | Full sales page — headline, problem, solution, module list, who it is for/not for, $497 + 14-day guarantee, 8 FAQs, disclaimers |
| `listing.json` | Marketplace listing data (sku BEA-07, price_cents 49700, billing one_time) |
| `cover.md` | Cover design brief (black-and-gold luxury branding) |
| `cover.png` | Generated cover image (1280 × 1920 PNG) |
| `onboarding.md` | Customer onboarding guide — what to do first, suggested 4-week schedule, support |
