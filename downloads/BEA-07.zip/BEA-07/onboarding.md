# Customer Onboarding — Spa & Wellness Business Builder

Welcome. You have the complete programme: the course, the workbook, and every template. This guide tells you what to do first and how to use the materials.

## What you received

| File | What it is |
|---|---|
| `content.md` | The full 10-module course text, plus a 12-month projection worked example and glossary |
| `workbook.md` | Companion workbook — exercises and worksheets for every module |
| `templates/spa-menu-pricing-calculator.csv` | Cost out every treatment and see your true profit per session |
| `templates/membership-model-templates.csv` | The 3 membership tiers (The Ritual, The Renewal, The Sanctuary) |
| `templates/membership-model-templates.md` | Worked 100-member revenue model and membership terms |
| `templates/operations-manual-template.md` | Fill-in operations manual: opening, closing, complaints, hygiene, contacts |
| `templates/supplier-equipment-checklist.csv` | Supplier and equipment checklist with costs and delivery dates |
| `templates/grand-opening-marketing-plan.md` | 8-week launch timeline, weekly rhythm, referral programme, budget |
| `sales-page.md` | The sales page for this product (for your reference) |
| `cover.png` | Product cover image |

## What to do first (Day 1)

1. Read the disclaimer at the top of `content.md`. This programme is business education only — it does not teach treatment techniques and does not replace professional legal, tax, or licensing advice. Confirm the licensing and regulatory requirements that apply where you operate.
2. Read Module 1 and complete Workbook Exercise 1.1: write down your three numbers (utilisation, revenue kept per treatment hour, rebooking rate) or your targets if you are pre-launch.
3. Open the pricing calculator and cost out your top 5 treatments. This one step usually changes what you charge.

## Suggested schedule

- **Week 1:** Modules 1–3 + Workbook Exercises 1.1, 2.1, 3.1. Know your numbers, your competitors, and your revenue mix.
- **Week 2:** Modules 4–6 + Exercises 4.1, 5.1, 6.1. Draft your menu, price it from your costs, and build your three membership tiers. Test the membership maths in the template before you publish anything.
- **Week 3:** Modules 7–9 + Exercises 7.1, 8.1, 9.1. Audit your booking flow, write your operations manual starter, and complete your supplier checklist.
- **Week 4:** Module 10 + Exercise 10.1. Complete your grand-opening plan, set your launch or relaunch date, and set your annual price-review date.
- **Days 22–30:** Put the plan into action using the 30-day action plan at the end of the workbook.
- **Ongoing:** Use the monthly numbers review sheet in the workbook every month. One page, once a month, keeps the business honest.

## How to use the templates

- **CSV files** open in Excel, Google Sheets, or any spreadsheet app. The pricing calculator has example rows filled in — replace them with your own treatments and costs. The "YOUR TREATMENT" rows are blank and ready for your numbers.
- **Markdown templates** open in any text editor or notes app. Fill in the bracketed fields and save a copy for your spa.
- Keep a master copy of the blank templates. Work on copies, so you can start fresh for a new location or a menu refresh.

## How to get support

For help with your order or the course files, email the marketplace support address with your order number and a description of the issue, and the support team will respond. For questions about your spa's licensing, regulations, or taxes, contact your state licensing board or a qualified local professional — the support team cannot advise on those.

## A note on the numbers

Every worked example in the course uses illustrative numbers to show the method. Your costs, prices, and results will differ. Replace the example numbers with your own as you work through the exercises — that is when the programme starts paying for itself.

---

*Spa & Wellness Business Builder — $497, one-time. 14-day money-back guarantee.*
