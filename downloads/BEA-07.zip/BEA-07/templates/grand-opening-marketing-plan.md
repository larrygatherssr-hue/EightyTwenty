# Grand-Opening Marketing Plan — Template

## Opening date: ____________________

## 8 Weeks Before

- [ ] Confirm opening date, menu, and prices
- [ ] Set up booking system (online booking, card capture, reminders)
- [ ] Set up Google Business Profile
- [ ] Set up social media profiles (Instagram, Facebook)
- [ ] Start email list (goal: ______ names by opening day)

## 6 Weeks Before

- [ ] Announce the opening to past clients, friends, local businesses, and email list
- [ ] Launch founding-member offer: first 30 members at ______ (state the benefit and end date)
- [ ] Order signage, gift cards, and retail stock

## 4 Weeks Before

- [ ] Open bookings for opening week
- [ ] Launch offer on selected treatments only (max 15% off; never the signature treatment)
- [ ] Confirm referral partners (hairdressers, gyms, bridal shops, offices nearby)

## 2 Weeks Before

- [ ] Host a preview evening for local businesses and referral partners
- [ ] Give each partner a gift card to try a treatment + referral terms in writing
- [ ] Confirm staffing, stock, and room setup for opening week

## Opening Week

- [ ] Full book target: ______ appointments
- [ ] Ask every client to rebook before leaving
- [ ] Ask happy clients to leave a review (Google + booking platform)
- [ ] Post opening-week photos and stories daily

## 4 Weeks After

- [ ] Review: clients seen ______, rebooking rate ______%, members ______, reviews ______
- [ ] Identify where bookings came from (online / referral / walk-in / social)
- [ ] Keep what worked; stop what did not

## Year-One Weekly Rhythm

- 2 social posts per week (1 educational, 1 human/behind the scenes)
- 1 email per month (1 tip, 1 treatment to try, 1 offer with an end date)
- 1 local partnership per month
- Ask every happy client for a review; reply to every review

## Referral Programme

- Referrer receives: ____________________
- Referred friend receives: ____________________
- Terms: ____________________

## Budget

| Item | Budget ($) | Actual ($) |
|---|---|---|
| Signage | | |
| Google Business Profile / listings | | |
| Social media | | |
| Preview evening | | |
| Launch offer cost | | |
| Printed materials / gift cards | | |
| Other | | |
| **Total** | | |
