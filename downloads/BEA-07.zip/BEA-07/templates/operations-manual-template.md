# Operations Manual Template — [Your Spa Name]

Fill in each section for your spa. Keep the manual where every team member can reach it, and review it every quarter.

## 1. Opening Procedure

1. Arrive 30 minutes before the first booking.
2. Disarm the alarm and check the premises.
3. Turn on lights, heating/cooling, and music. Set treatment rooms to 21–23°C.
4. Start the laundry and check towel and linen stock for the day.
5. Review the day's bookings and client notes (birthdays, first visits, preferences, allergies).
6. Check product and consumable stock for the day's treatments.
7. Confirm the reception area is clean, water is available, and the booking system is online.

## 2. Room Setup and Reset Standard

**Setup (before each client):**
- Fresh linen, towels, and blanket; table warmed if applicable.
- Products and oils for the booked treatment laid out and checked.
- Room temperature 21–23°C, lighting dimmed, music on, water available.

**Reset (after each client, allow 10 minutes):**
- Strip the bed; place used linen in the designated bag.
- Wipe the table and surfaces with disinfectant.
- Lay a fresh set of linen and towels.
- Replace the towel warmer stock and check oil/product levels.
- Remove rubbish, reset the room to the setup standard, and note any maintenance issues.

## 3. Booking, Cancellation, and No-Show Policy

- Bookings: online, by phone, or in person. First-time clients provide a card to hold the booking.
- Cancellation: free up to 24 hours before the appointment; 50% charge inside 24 hours; full charge for a no-show.
- Reminders: automatic confirmation at booking and a reminder 24 hours before.
- Waitlist: offer the waitlist when a requested time is full; contact waitlisted clients in order.

## 4. Payment and Refunds

- Accept [card / cash / gift card — list your methods].
- Reconcile the till at close every day.
- Refunds: [state your policy — e.g. treatments are non-refundable once delivered; unused gift cards and packages are refundable within 14 days of purchase]. Record every refund with the reason.

## 5. Client Intake and Records

- Every new client completes an intake form (health conditions, allergies, pregnancy, skin sensitivities, medications, areas to focus on or avoid, desired outcome).
- Therapists read the intake form before the client arrives.
- Update intake forms at least once a year.
- Store client records securely and confidentially, in line with data-protection rules in your jurisdiction.

## 6. Hygiene and Safety

- Wash hands before and after every treatment.
- Disinfect surfaces and equipment between clients.
- Launder linen at the required temperature; never reuse linen between clients.
- Follow local health-department rules for your services and premises.
- First-aid kit location: ____________________. Nearest hospital/urgent care: ____________________.
- Report any incident (injury, allergic reaction, equipment failure) to the owner the same day and record it.

## 7. Complaints

1. Listen without interrupting.
2. Apologise for the experience.
3. Move the conversation to a private space.
4. Offer a remedy (for example, a complimentary redo of the treatment).
5. Record the complaint and the remedy; follow up with the client within 48 hours.

## 8. Ordering and Stock

- Stock check: weekly, on [day].
- Reorder point for each core product: [list].
- Core suppliers: [name, contact, order minimum, delivery time, payment terms].
- Retail stock is counted monthly.

## 9. Closing Procedure

1. Reset all rooms to the setup standard.
2. Finish and fold laundry; start the final load if needed.
3. Confirm the next day's bookings and send reminders.
4. Reconcile the till and lock cash takings away.
5. Turn off equipment, lights, and music; set the alarm.
6. Lock up.

## 10. Key Contacts

| Role | Name | Phone | Email |
|---|---|---|---|
| Owner / manager | | | |
| Landlord | | | |
| Insurance | | | |
| Main product supplier | | | |
| Linen supplier | | | |
| Equipment repair | | | |
| Accountant | | | |
| Attorney | | | |
| Emergency | | | |

---

*Review date: __________ Next review: __________*
