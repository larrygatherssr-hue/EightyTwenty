# Membership Model — Worked Example (100 Members)

Use this sheet to test your own tiers before you publish them. Replace every number with your own costs and prices.

## Assumptions

- Average delivery cost per treatment session (therapist + product + overhead share): $62
- Average usage of included credits: 85%
- Tier 1 delivers 1 treatment per member per month; Tier 2 delivers 1.5 on average; Tier 3 delivers 2.5 on average

## Example: 100 members (50 / 35 / 15)

| Tier | Members | Price | Monthly revenue | Credits delivered/month | Delivery cost/month |
|---|---|---|---|---|---|
| The Ritual | 50 | $79 | $3,950 | 42.5 | $2,635 |
| The Renewal | 35 | $139 | $4,865 | 44.6 | $2,767 |
| The Sanctuary | 15 | $219 | $3,285 | 31.9 | $1,977 |
| **Total** | **100** | — | **$12,100** | **119.0** | **$7,379** |

Monthly membership margin in this example: $12,100 − $7,379 = **$4,721**, before incremental retail and add-on spend by members.

## Your numbers

| Tier | Members | Price | Monthly revenue | Delivery cost/month |
|---|---|---|---|---|
| The Ritual | | | | |
| The Renewal | | | | |
| The Sanctuary | | | | |
| **Total** | | — | | |

## Membership terms (fill in and publish)

- Minimum term: 3 months, then month-to-month
- Freeze: 1 freeze per year, up to 30 days
- Cancellation: 30 days' written notice; unused credits expire on cancellation
- Sharing: memberships are for the named member only, except defined guest passes
- Failed payments: membership pauses after 2 failed payments until payment is updated

## Sensitivity check

If your delivery cost per session is $80 instead of $62, the same 100 members cost about $9,520 a month to serve and the margin falls to about $2,580. If your cost per session is $50, the margin rises to about $6,150. Know your cost per session — it decides whether the membership works.
