# Spa & Wellness Business Builder

## Build a Spa That Earns All Year — Menu, Pricing, Memberships, and Operations That Work

---

## Disclaimer — Read First

This programme is education only. It teaches business skills for spa and wellness businesses: concept development, menu design, pricing, memberships, marketing, and operations. It does not teach massage, esthetics, or any treatment technique, and it does not provide medical, legal, tax, or financial advice.

Licensing, scope of practice, health and safety rules, employment law, and tax obligations for spas and wellness businesses vary by state, province, and country, and they change over time. Before you open, expand, or advertise any service, confirm the requirements that apply where you operate with your state licensing board, local health department, and a qualified attorney or accountant. Nothing in this programme replaces professional advice or a license you are required to hold. The worked examples use illustrative numbers, not guarantees; your costs, prices, and results will differ.

---

## Table of Contents

- Module 1 — The Spa Business, Honestly: What Makes Money and What Does Not
- Module 2 — Your Concept: Choosing a Lane You Can Win
- Module 3 — The Business Model: Revenue Streams Beyond the Treatment Room
- Module 4 — The Menu: Designing a Treatment Menu That Sells
- Module 5 — Pricing: Building Prices From Costs, Not Competitors
- Module 6 — Memberships: Turning One-Time Guests Into Recurring Revenue
- Module 7 — The Client Journey: Booking, Intake, and Retention
- Module 8 — Operations: The Manual, the Team, and the Daily Rhythm
- Module 9 — Suppliers, Equipment, and Your Space
- Module 10 — Grand Opening and Year-One Marketing That Fills the Book
- Appendix A — Worked Example: A Complete 12-Month Projection
- Appendix B — Glossary

---

## Module 1 — The Spa Business, Honestly: What Makes Money and What Does Not

Most spas do not fail because the treatments are bad. They fail because the business underneath the treatments was never built. A talented therapist opens a beautiful room, charges what the spa down the road charges, fills the first month with friends and family, and then discovers the quiet truth of this industry: a treatment room earns money only while a pair of hands is in it, and a pair of hands can only be in one room at a time.

That is the central constraint of the spa business, and everything in this programme is organised around managing it. Your revenue has a ceiling set by three numbers: how many treatment hours you can sell, what each hour earns, and how often clients return. If any one of those three is weak, the business wobbles. If all three are strong, the business earns all year, including in the slow months.

### The three numbers that run your spa

**1. Utilisation.** If you have two treatment rooms open 8 hours a day, 6 days a week, you have 96 bookable hours per week. If 55 of those hours are filled, your utilisation is 57%. Most new spas run at 40–55% in year one. A healthy, established spa runs at 65–75%. Above 80% you need more rooms, more therapists, or longer hours — or you are turning away money.

**2. Revenue per treatment hour.** This is not your headline price. It is the money you actually keep per hour after product cost, therapist pay (if you employ or contract), and payment processing. A $120 facial that costs $14 in product and $48 in therapist pay keeps $58 before rent and overhead. A $90 massage with $4 in product and $45 in therapist pay keeps $41. Same hour, very different business.

**3. Rebooking rate.** The percentage of clients who book their next appointment before they leave, or within 30 days. A spa with a 25% rebooking rate must constantly find new clients, which is the most expensive way to run this business. A spa with a 60% rebooking rate grows on its own momentum.

Write these three numbers down for your spa, or for the spa you plan to open, before you read further. If you do not know them, that is your first job: find them. Everything else in this programme improves one of the three.

### Why revenue is seasonal — and why that is fixable

Spa demand rises and falls with the calendar. December is strong (gift cards, holiday self-care). January is often slow. Summer can dip as clients travel. A spa that sells only single treatments feels every dip in full. A spa with memberships, packages, retail, and gift-card sales smooths the curve, because money arrives in months when the rooms are quiet.

That is the real purpose of a membership programme. It is not a discount scheme. It is a revenue-smoothing device. A member paying $89 a month pays in February whether she books or not. Multiply that by 120 members and you have $10,680 of predictable monthly revenue before a single walk-in arrives. Module 6 builds this in full, with three tiers and real numbers.

### The five mistakes that sink new spas

**Mistake 1: Copying a competitor's prices.** The spa down the road may own its building, pay its therapists differently, or be losing money. Its prices tell you nothing about your costs. Module 5 shows you how to build every price from your own numbers.

**Mistake 2: A bloated menu.** Thirty-seven treatments look impressive and confuse everyone. Clients cannot choose, therapists cannot master the protocols, and you stock products for services nobody books. A strong menu has 12–18 treatments, each with a reason to exist.

**Mistake 3: No retention system.** If nobody asks a client to rebook, most clients do not. Retention is a system — a script, a prompt at checkout, a follow-up message — not a personality trait.

**Mistake 4: Under-pricing the first year.** New owners price low "to get people in the door" and then discover they cannot raise prices without losing the very clients the low prices attracted. It is far easier to open with a launch offer on a correct price than to open at the wrong price and fix it later.

**Mistake 5: Treating the business as a job.** If the spa only earns when you are in the room, you bought yourself a job with rent attached. The goal of this programme is a business that earns when you are not in the room: other therapists, memberships, retail, and systems that run without you.

### Your first implementation step

Before Module 2, complete Exercise 1.1 in the workbook: write your current (or target) utilisation, revenue per treatment hour, and rebooking rate. If you are pre-launch, write your targets: 60% utilisation by month 6, a rebooking rate of 50% by month 6, and a revenue-per-hour figure you will calculate in Module 5. A target you have written down is a decision. A target in your head is a wish.

---

## Module 2 — Your Concept: Choosing a Lane You Can Win

A spa is not one business. It is at least five different businesses wearing similar towels, and they succeed in different ways.

**The day spa.** Broad menu, relaxation focus, gift-driven. Wins on volume, packages, and memberships. Needs a strong local population and good parking or foot traffic.

**The wellness studio.** Smaller, focused — massage, breathwork, sauna, or stretch. Wins on a loyal niche and recurring visits. Lower build-out cost, but the audience is narrower.

**The results-driven skin studio.** Facials, peels, LED, and skin-health programmes. Wins on expertise, visible results, and series packages. Requires advanced training and careful scope-of-practice compliance.

**The med-spa-adjacent practice.** Works alongside or under medical direction for services that need it. Wins on high ticket values. This lane carries the heaviest licensing and supervision requirements — confirm them with your state board and an attorney before you spend a dollar. This programme does not teach medical services.

**The mobile or home-based practice.** Lowest overhead, highest flexibility. Wins on convenience and low fixed costs, but growth is capped by your own hours until you add therapists.

You do not need to pick forever. You need to pick for the next 18 months, and pick a lane where you have a genuine edge: a skill, a local gap, an audience you already reach, or a cost advantage.

### The concept test: five questions

1. **Who is the client, specifically?** "Women 30–55" is not a client. "Busy professional women within 15 minutes of downtown who book a monthly facial and buy skincare" is a client. Name her. Know where she works, what she earns, and what she already spends on self-care.
2. **What problem does she pay to solve?** Stress, skin concerns, pain, time for herself, a gift that feels thoughtful. A spa sells an outcome, not a treatment. Your menu and marketing must name the outcome.
3. **What is already available to her?** List every competitor within a 20-minute drive, plus the at-home and online substitutes. If three day spas already serve your area well, your lane is not "another day spa" — it is a sharper version of one thing they do poorly.
4. **What can you deliver better than they can?** One clear advantage is enough: better skin results, easier booking, a genuinely calm space, a membership that makes sense, or a therapist team that stays.
5. **Can the numbers work?** A concept that needs 80% utilisation to break even is a fragile concept. Module 3 and Appendix A will test this with real numbers. Do the test before signing a lease.

### Positioning in one sentence

Write your positioning as one sentence: "We help [specific client] get [specific outcome] through [your distinctive approach]." Example: "We help busy professional women keep their skin healthy and their stress low through monthly 60-minute rituals they can book in under a minute." That sentence now governs your menu, your prices, your hiring, and your marketing. If a decision does not serve the sentence, it does not happen.

### Implementation steps

1. Complete Workbook Exercise 2.1: the competitor map. Visit (or research online) five competitors. Record their top 5 treatments, prices, booking experience, and one weakness each.
2. Write your one-sentence positioning and test it on three people who match your target client. If they cannot repeat it back, it is not clear enough yet.
3. Choose your lane and write it down with a start date. A concept chosen late is a launch delayed.

---

## Module 3 — The Business Model: Revenue Streams Beyond the Treatment Room

A treatment-only spa has one revenue stream and one point of failure. A resilient spa has four or five, and the non-treatment streams are what carry the slow months.

### The five revenue streams

**1. Single treatments.** Your core. Price them correctly (Module 5) and protect the margin.

**2. Memberships.** Predictable monthly revenue. The backbone of year-round income. Module 6.

**3. Packages and series.** A series of 6 facials or 10 massages, paid in advance. This is cash in the bank today for work delivered over months, and it commits the client to returning. Price a series at a genuine but modest saving — 10–15% off the single price — so the margin survives.

**4. Retail.** Skincare, candles, bath products, supplements where your license allows. Retail in a spa should earn 40–50% gross margin and should be recommended, not merely displayed. A therapist who says "the serum I used today is the one on the shelf by the door, and it will last you about six weeks" sells more than any display ever will. Start with 8–12 products you genuinely use in treatments.

**5. Gift cards.** Sold in December, redeemed in January and February — exactly when you need them. Gift cards are an interest-free loan from your clients. Promote them hard in November and December, and make them easy to buy online.

### A worked example: the revenue mix

Consider a two-room spa in its second year, open 6 days a week:

- Treatments: 210 sessions a month at an average kept revenue of $62 per session = $13,020
- Memberships: 110 members at an average of $95 a month = $10,450
- Packages: $1,800 a month in series sales
- Retail: $2,400 a month in sales at 45% margin = $1,080 kept (the rest is product cost)
- Gift cards: $1,500 a month averaged across the year

Total monthly revenue in this example is about $28,750, and $10,450 of it — more than a third — arrives whether the rooms are full or not. That is the difference between a spa that panics in February and one that plans in February.

Your mix will differ. The principle will not: never let one stream carry the whole business.

### Capacity math: know your ceiling before you dream

Two rooms, 8 hours a day, 6 days a week = 96 bookable hours a week, about 416 a month. At 70% utilisation that is 291 sessions a month. At an average price of $110, gross treatment revenue is about $32,000 a month. That is your ceiling with two rooms at that price and utilisation. If your rent, payroll, and overhead need $35,000 a month, the model does not work at two rooms and $110 — you need a third room, higher prices, memberships, or lower costs. Do this math before you sign anything. It takes ten minutes and saves years.

### Implementation steps

1. List your five revenue streams and set a month-12 target for each.
2. Decide your retail starter range: 8–12 products, all used in treatments, all with at least 40% margin.
3. Set a gift-card target for November–December and a promotion plan (Module 10).

---

## Module 4 — The Menu: Designing a Treatment Menu That Sells

Your menu is a sales tool, not a catalogue. Its job is to help a client choose quickly and confidently, and to guide her toward the treatments that are best for her and most profitable for you.

### The rules of a strong menu

**12–18 treatments.** Fewer than 10 and you look thin; more than 20 and clients freeze. Every treatment must earn its place: it is popular, profitable, or strategically important (for example, the entry-level treatment that brings new clients in).

**Three lengths, not seven.** Offer 30, 60, and 90 minutes. Odd lengths (45, 75) complicate scheduling and confuse clients. Price the 60-minute as the anchor — it should be your best value per minute and your most-booked length.

**Name the outcome, then the treatment.** "The Reset Ritual — 60 minutes of deep relaxation for tired bodies and busy minds" sells better than "Swedish Massage — 60 minutes." The client buys how she will feel. The treatment name tells her what happens; the outcome line tells her why she wants it.

**One signature treatment.** A treatment only you offer, with a name only you use, priced at a premium. It is your flagship, your gift-card star, and your social-media story. Build it from things you already do well, packaged with a small ritual — a foot soak, a scalp massage, a take-home product — that makes it feel special without adding much cost.

**A clear entry point.** One treatment priced to make a first visit easy — a 30-minute express facial or a 30-minute targeted massage. Its job is not profit; it is conversion. The profit comes when that client rebooks a 60-minute treatment.

### Menu engineering: the four boxes

Sort every treatment into one of four boxes:

- **Stars:** popular and profitable. Feature them. Put them first on the menu and first in your marketing.
- **Workhorses:** popular but thin margin. Raise the price slightly, reduce the product cost, or shorten the session.
- **Hidden gems:** profitable but rarely booked. Rename them, describe the outcome better, or bundle them into a package.
- **Dogs:** rarely booked and thin margin. Remove them. A treatment nobody books still costs you shelf space, training time, and menu clutter.

Review the boxes every quarter with real booking data. A menu is a living document, not a laminated monument.

### Writing treatment descriptions that sell

Every description needs four elements in two or three sentences: who it is for, what happens, how she will feel after, and the duration and price. Example: "For skin that looks tired and feels tight. A 60-minute facial with deep cleansing, gentle exfoliation, and a hydrating mask, finished with a relaxing scalp massage. You leave glowing, not greasy. 60 minutes — $120."

Avoid jargon. Avoid listing every oil and technique. The client does not care what you do with your hands; she cares what changes for her.

### Implementation steps

1. Draft your 12–18 treatment menu using the workbook template. Every treatment gets an outcome line, a duration (30/60/90), and a price you will validate in Module 5.
2. Name your signature treatment and define its ritual.
3. Identify your entry-point treatment and its conversion goal: what percentage of first-time express clients should rebook a full treatment within 30 days? (Start with 40%.)

---

## Module 5 — Pricing: Building Prices From Costs, Not Competitors

This is the module that pays for the programme many times over. Price from your costs, your time, and your market — in that order. Competitor prices are a sanity check at the end, not a starting point.

### The pricing build-up

Every treatment price is built from four layers:

**Layer 1 — Direct product cost.** Everything consumed in the treatment: oils, creams, masks, disposables, laundry. Track it per treatment, not as a monthly guess. A facial may cost $12–$18 in product; a massage $3–$6. If you do not know the number, cost out five treatments this week by weighing and pricing what you use.

**Layer 2 — Therapist cost.** What the therapist earns for that hour, including payroll taxes and benefits if employed, or the contractor rate if contracted. This is a real cost even if the therapist is you — your time has a value, and pricing as if it were free is how owners burn out while the business "breaks even."

**Layer 3 — Overhead per treatment hour.** Rent, utilities, insurance, software, marketing, and admin, divided by your realistic monthly treatment hours. Example: $6,000 a month in overhead divided by 240 treatment hours = $25 per treatment hour. This is the number most spa owners never calculate, and it is the number that quietly eats their margin.

**Layer 4 — Profit.** The margin that lets you reinvest, survive a slow month, and pay yourself. Aim for 15–20% profit on each treatment after layers 1–3.

### Worked example: pricing a 60-minute facial

- Price target to test: $120
- Product cost: $14
- Therapist cost (employed, including taxes): $38
- Overhead per hour: $25
- Total cost: $77
- Profit: $43, or 36% of the price

That is a healthy treatment. Now the same method on a 60-minute massage priced at $85 because "that is what everyone charges":

- Product cost: $4
- Therapist cost: $42
- Overhead per hour: $25
- Total cost: $71
- Profit: $14, or 16% of the price

The massage looks busy and earns little. Two options: raise the price to $100 (profit becomes $29, or 29%), or shorten it, reduce the therapist cost structure, or make it a members-only price. The numbers decide; habit does not.

### Worked example: the full build-up for a 90-minute signature treatment

- Product cost: $22 (includes the take-home mini product, $6)
- Therapist cost: $57
- Overhead per 1.5 hours: $37.50
- Total cost: $116.50
- Target profit 25%: price = $116.50 ÷ 0.75 = $155.33, rounded to $155

Round prices to clean numbers clients remember: $55, $75, $95, $120, $155. Avoid $97-style charm pricing in a premium spa — it signals discount retail, not calm luxury.

### When and how to raise prices

Raise prices once a year, by 3–5%, and tell clients why in one sentence: "Our prices adjust each January to reflect the quality of our products and the training of our therapists." Give 30 days' notice. Protect members: honour their current rate for 60 days after a rise, or grandfather them for a year if they joined early — loyalty rewarded is retention earned. Never apologise for a price rise; explain it once, confidently, and move on.

### Discounting rules

Discounts are a tool, not a habit. Rules that protect you:

- Never discount your signature treatment.
- Never discount more than 15%.
- Always give a discount an end date and a reason (launch, birthday, referral).
- A discount that brings a client in once but trains her to wait for the next discount has cost you more than it earned.

### Implementation steps

1. Cost out your top 8 treatments using the pricing calculator in templates/. Fill in product cost, therapist cost, and overhead per hour.
2. Reprice anything earning under 20% profit. Decide: raise the price, change the cost, or remove it.
3. Set your annual price-review date and write it in your calendar now.

---

## Module 6 — Memberships: Turning One-Time Guests Into Recurring Revenue

A membership is a simple promise: the client pays a fixed monthly amount and receives a defined set of benefits. Done well, it is the single most valuable system in your spa. Done badly — too generous, too complicated, too discounted — it fills your book with your least profitable clients.

### The three-tier model

Offer three tiers. Three is the number that works: one entry tier, one middle tier (where most members should land), and one premium tier. Two tiers force a hard choice; four tiers create confusion.

**Tier 1 — The Ritual, $79 a month.** One 60-minute treatment a month (massage or facial from a defined list), 10% off additional treatments and retail, and rollover of one unused treatment for one month. This tier is your entry point. Its job is to convert single-visit clients into members.

**Tier 2 — The Renewal, $139 a month.** One 90-minute treatment or two 60-minute treatments a month, 15% off additional treatments and retail, one guest pass per quarter, priority booking, and rollover of one unused treatment for one month. This is your anchor tier — price it and describe it so that it is clearly the best value, and most members choose it.

**Tier 3 — The Sanctuary, $219 a month.** Two 90-minute treatments or three 60-minute treatments a month, 20% off additional treatments and retail, two guest passes per quarter, priority booking, a complimentary upgrade each quarter (scalp treatment, foot ritual, or LED add-on), and a birthday treatment upgrade. This tier is for your most committed clients and your highest lifetime value.

These prices are illustrative starting points. Run them through your own pricing build-up from Module 5 before you publish them. The templates folder contains a membership model template with all three tiers, so you can plug in your own costs and test the margins.

### Membership math that protects you

A membership only works if the member's monthly payment covers the cost of what she uses, plus margin, on average across the whole membership base. Two facts make this work in your favour:

**Breakage.** Not every member uses every credit every month. Industry experience across service businesses shows a meaningful share of members skip a month. Rollover rules (one month, one credit) limit your liability while still feeling generous.

**Incremental spend.** Members buy more add-ons, more retail, and more gift cards than non-members, because the membership has already made the spa "their place." The discount you give a member is repaid by the extra visits and purchases she makes.

### Worked example: 100 members

Assume 50 members on Tier 1 ($79), 35 on Tier 2 ($139), and 15 on Tier 3 ($219):

- Monthly membership revenue: (50 × $79) + (35 × $139) + (15 × $219) = $3,950 + $4,865 + $3,285 = $12,100
- Annual membership revenue: $145,200

Now the cost side, assuming members use on average 85% of their included treatments, and the average delivered treatment costs you $62 in therapist pay, product, and overhead share:

- Tier 1 delivers 50 treatments a month at 85% usage = 42.5 treatments × $62 = $2,635
- Tier 2 delivers 35 members × 1.5 average treatments = 52.5 credits, at 85% = 44.6 × $62 = $2,767
- Tier 3 delivers 15 members × 2.5 average treatments = 37.5 credits, at 85% = 31.9 × $62 = $1,977
- Total monthly delivery cost: about $7,379
- Gross margin on memberships: $12,100 − $7,379 = $4,721 a month, before incremental retail and add-on spend

That margin is before the extra revenue members generate. The model works — provided your treatment cost per session is honest and your rollover rules are tight. If your cost per session is $80 instead of $62, the same 100 members cost $9,520 a month to serve and the margin falls to $2,580. Know your cost per session. It decides everything.

### Membership rules that prevent trouble

- **Minimum term:** 3 months, then month-to-month. This stops the client who joins, uses a premium treatment, and cancels.
- **Freeze:** one freeze per year, up to 30 days, for travel or illness. Freezes longer than that become cancellations in disguise.
- **Cancellation:** 30 days' written notice. Unused credits expire on cancellation — state this plainly at sign-up.
- **No sharing:** memberships are for the named member, except for the defined guest passes. Sharing a membership across a household quietly halves your revenue.
- **Payment failures:** two failed payments and the membership pauses until payment is updated. Automate this in your booking software; do not chase it by hand.

### Selling memberships without being pushy

The best membership conversation happens at checkout, after a good treatment, and takes thirty seconds: "You loved the facial today. If you came once a month, the membership would save you $41 a month on this treatment alone, and you would get 10% off anything else. Would you like me to set that up for next month?" That is it. No pressure, no script longer than a sentence, and the offer is tied to something the client just enjoyed.

Set a target: 20% of your active clients should be members by month 12. Track it monthly. A spa with 300 active clients and 60 members has a foundation; a spa with 300 active clients and 10 members has a leak.

### Implementation steps

1. Build your three tiers in the membership template, using your own treatment costs.
2. Write your membership terms in plain language (minimum term, freeze, cancellation, rollover) and put them on your website and at reception.
3. Train every therapist on the thirty-second checkout conversation, and track membership sign-ups weekly.

---

## Module 7 — The Client Journey: Booking, Intake, and Retention

A client's experience of your spa begins before she arrives and continues after she leaves. Every step is either building loyalty or quietly losing it.

### Booking: make it effortless

Most clients now book online, often late at night. If your booking system needs a phone call, an email, or more than three taps, you are losing bookings to spas that do not. Your booking system must: show real availability, take payment or a card to hold the booking, send an automatic confirmation and a reminder 24 hours before, and let the client reschedule without calling you.

Take a card at booking for first-time clients. A no-show costs you the treatment, the room, and the therapist's hour. A clear cancellation policy — free up to 24 hours before, 50% charge inside 24 hours, full charge for a no-show — stated at booking and confirmed in the reminder, cuts no-shows sharply. Enforce it kindly and consistently; a policy enforced sometimes is a policy that creates arguments.

### Intake: the five minutes that change the treatment

A good intake form asks about health conditions, allergies, pregnancy, skin sensitivities, medications that affect the skin, areas to focus on or avoid, and the outcome the client wants today. The therapist reads it before the client walks in. The form protects the client, protects you, and makes the treatment better — a therapist who knows the client has a sore shoulder and a nut allergy gives a better massage and a safer facial.

Keep intake forms on file securely and review them at each visit. Update them at least once a year. Where your jurisdiction requires consent forms for specific treatments, use them every time, without exception.

### The treatment hour: small things, large loyalty

The treatment itself is your product, and its quality is set by training, not talent alone. Every treatment needs a written protocol: steps, timing, products, and the finish. A client who receives a wonderful facial on Tuesday and a different, weaker facial on Friday from another therapist will not come back to find out which one she gets next time. Consistency is the product.

Small rituals matter more than grand gestures: a warm towel, water offered without being asked, a quiet room, a therapist who remembers the client's name and her preferences. Note preferences in the client record — pressure, room temperature, music, areas to avoid — and use them next time. Remembering is a retention strategy.

### Checkout and rebooking: the moment that decides everything

The most valuable sentence in your spa is spoken at checkout: "Shall we book your next visit now? The same time in four weeks is open." Clients who rebook before they leave return at far higher rates than clients who leave intending to book later. Offer the next appointment while the experience is fresh, and make it specific — a date and a time, not "sometime next month."

At checkout, also do three things: recommend one retail product used in the treatment, mention the membership saving if the client is not a member, and confirm the follow-up message she will receive. Then send it: a thank-you message within 24 hours, and a check-in at 7 days ("How is your skin feeling after the facial?"). Both are automated; neither takes your time.

### Retention: the numbers and the habits

Track these monthly: rebooking rate, percentage of clients who return within 90 days, average visits per client per year, and the percentage of revenue from returning clients. A healthy spa earns at least 70% of its revenue from returning clients.

Win back lapsed clients with a simple system: any client who has not visited in 90 days receives a personal message — not a generic discount blast, but a short note from the spa, ideally mentioning her last treatment. "We miss you at the spa — your therapist asked after you, and we have a quiet afternoon next Thursday if you would like to come back." A third of lapsed clients respond to a message that feels personal.

### Implementation steps

1. Audit your booking flow as a stranger would: book an appointment on your own system tonight. Fix every point of friction you find.
2. Write your rebooking script and put it at every checkout station.
3. Set up the three automated messages: confirmation, 24-hour reminder, and 24-hour thank-you.

---

## Module 8 — Operations: The Manual, the Team, and the Daily Rhythm

A spa that depends on its owner's memory is a spa that cannot grow, cannot be sold, and collapses when the owner is ill for a week. The operations manual is what turns a practice into a business.

### The operations manual: what goes in it

Your manual does not need to be long; it needs to be used. It covers: opening and closing procedures, room setup and reset standards, laundry and hygiene routines, booking and cancellation handling, payment and refund procedures, client complaints, health and safety, product ordering, and who to call when something breaks. The templates folder contains an operations manual template you can fill in for your spa.

Write each procedure as steps a new hire can follow on day one. "Reset the room" is not a procedure. "Strip the bed, place used linen in the blue bag, wipe the table with disinfectant, lay a fresh set, replace the towel warmer, check the oil stock, and set the room to 22°C" is a procedure.

### Hiring: skills, attitude, and retention

Hire for attitude and train for skill. A therapist can learn a new protocol in a week; a therapist who is careless with time, rough with clients, or unreliable cannot be trained into caring. In interviews, ask about a difficult client and listen for empathy, not blame. Check references properly — a five-minute call to a former employer tells you more than a polished CV.

Pay matters. Therapists leave for better pay, better hours, and better treatment. A clear pay structure, predictable schedules published two weeks ahead, and a small commission on retail and rebooking will keep good people longer than any team-building day. If you use contractors, confirm the arrangement complies with employment and tax rules in your jurisdiction — misclassification is a common and expensive mistake, so get advice before you set it up.

### The daily rhythm

A well-run spa day has a shape. Before opening: rooms checked, laundry started, the day's bookings reviewed, and any special notes (a birthday, a first visit, a returning client) shared with the team. During the day: a 10-minute gap between treatments for room reset and notes, a short team check-in at midday, and no therapist double-booked. At close: rooms reset, laundry finished, the next day's bookings confirmed, and the till reconciled. Write this rhythm down. When it is written, it happens even when you are not there.

### The weekly and monthly rhythm

Weekly: review bookings and utilisation for the coming week, check stock levels, and hold a 20-minute team meeting — wins, problems, and one thing to improve. Monthly: review the numbers (utilisation, revenue per hour, rebooking rate, membership count, retail sales), review the menu boxes from Module 4, and pay yourself. Yes — pay yourself a fixed amount monthly, even if it is modest. A business that never pays its owner is a hobby with overheads.

### Handling complaints: the recovery that builds loyalty

A client who complains and is handled well becomes more loyal than a client who never had a problem. The rule is simple: listen without interrupting, apologise for the experience (not for a fault you have not established), fix it if you can, and follow up. A complimentary redo of the treatment, a sincere call from the owner, and a note in the client file cost little and recover a client worth hundreds a year. Never argue with a client in the treatment room or at reception. Take it to a private space, take it seriously, and record what happened.

### Implementation steps

1. Fill in the operations manual template this week — start with opening, closing, and room reset.
2. Write your hiring checklist and your pay structure, and confirm the employment or contractor setup with a qualified adviser.
3. Put the weekly team meeting and the monthly numbers review in your calendar as recurring events.

---

## Module 9 — Suppliers, Equipment, and Your Space

Your suppliers and your space are long-term decisions disguised as shopping. Choose them with the same care you give your menu.

### Suppliers: fewer, better, negotiated

A spa needs reliable suppliers for: professional skincare and treatment products, oils and consumables, disposables, linen, retail stock, and cleaning supplies. The mistake is having twelve suppliers, none of whom knows you. Choose two or three core suppliers, order regularly, pay on time, and negotiate: volume discounts, free training, display stands, and payment terms of 30 days instead of payment up front.

Before you commit to a product line, ask: what is the professional cost per treatment (not per bottle)? What training is included? What is the minimum order? What is the retail margin? A product that costs $40 a bottle and delivers 20 facials costs $2 per treatment; a product that costs $25 a bottle and delivers 8 facials costs $3.13. The cheaper bottle is the more expensive product. Work it out per treatment, every time.

Keep a supplier list with contact names, order minimums, delivery times, and payment terms, and review it twice a year. A supplier who delivers late twice is a supplier you replace before the third time costs you a booking.

### Equipment: buy once, buy well

Treatment beds, facial steamers, hot towel cabinets, LED devices, and laundry equipment are capital purchases. Buy quality on the items clients touch and therapists use all day — a cheap treatment bed that wobbles or a steamer that breaks in month four costs more than the saving. For technology (LED, microcurrent, skin analysis), confirm the device is appropriate for your license and scope of practice, get training from the supplier, and check whether your insurance covers it.

Budget for maintenance: set aside 2–3% of equipment value per year for repairs and replacement. A hot towel cabinet that fails on a Saturday is a small disaster; a spare, or a supplier who delivers in 24 hours, turns it into a footnote.

### Your space: the room is the product

Clients judge a spa in the first thirty seconds: the smell, the light, the sound, the temperature, and whether the reception area feels calm or chaotic. You do not need luxury finishes; you need calm, clean, warm, and quiet. Soundproofing between rooms matters more than expensive tiles. A treatment room should be warm (21–23°C), dimmable, quiet, and free of clutter. The reception area should be uncluttered, with water available and a place to sit that is not a plastic chair under fluorescent light.

When choosing a location, weigh: rent as a percentage of expected revenue (aim for rent under 15% of gross revenue), visibility and parking, the population within 15 minutes, and the lease terms — length, break clause, and who pays for what. A five-year lease with no break clause on an unproven concept is a risk you should negotiate down before you sign.

### The supplier and equipment checklist

Use the checklist in templates/ before you order anything: every item, its supplier, its cost, its cost per treatment where relevant, and its delivery date. Order in waves — rooms first, consumables second, retail last — so that a delay in one area does not hold up the whole opening.

### Implementation steps

1. Cost every product line per treatment before you commit.
2. Complete the supplier and equipment checklist for your spa.
3. Walk your space as a first-time client would, and list five improvements under $100 each. Do them this week.

---

## Module 10 — Grand Opening and Year-One Marketing That Fills the Book

Marketing for a spa is not one big launch. It is a steady system that brings in new clients every week and brings existing clients back. The grand opening is the loud start of a quiet, consistent engine.

### The grand-opening plan (8 weeks before to 4 weeks after)

**8 weeks before:** confirm your opening date, your menu, and your prices. Set up your booking system, your Google Business Profile, and your social media profiles. Begin a simple email list — even 50 names is a start.

**6 weeks before:** announce the opening to everyone you know: past clients, friends, local businesses, and your email list. Offer a founding-member rate on memberships for the first 30 members — a real benefit for early trust, with a clear end date.

**4 weeks before:** start taking bookings for opening week. Offer opening-week appointments at a launch price on a small number of treatments (not your signature treatment, and not more than 15% off). The goal is a full book in week one, because a full book creates word of mouth and a busy room creates energy.

**2 weeks before:** invite local businesses to a preview evening — hairdressers, gyms, bridal shops, and offices nearby. These are referral partners, not just guests. Give each one a gift card to try a treatment and a simple referral arrangement.

**Opening week:** open the doors, deliver excellent treatments, ask every client to rebook, and ask happy clients to leave a review. Reviews in the first month matter enormously: they are the first thing a stranger reads before booking.

**4 weeks after:** review the numbers — how many clients, how many rebooked, how many joined as members, where bookings came from. Keep what worked, stop what did not, and settle into the weekly rhythm below.

### Year-one marketing: the weekly rhythm

Your marketing should take about 5 hours a week, not 25. The rhythm is:

- **Two social posts a week.** One educational (how to care for skin in winter, why regular massage helps desk workers), one human (your team, your room, a client's words with permission). No stock-photo spam, no daily noise.
- **One email a month.** A short note to your list: one useful tip, one treatment to try, one offer with an end date. An email list you own is worth more than followers you rent.
- **One local partnership a month.** A gym, a bridal shop, a corporate office, a hotel. Offer their people something specific and track the bookings that come from it.
- **Reviews, always.** Ask every happy client. Respond to every review, including the unhappy ones, calmly and promptly. A thoughtful reply to a bad review reassures the next hundred readers more than the review itself worries them.

### Referrals: your cheapest new clients

A referred client costs you almost nothing and books at higher rates than a stranger from an advert. Build a simple referral programme: when a client refers a friend who books, both receive a defined benefit — for example, $15 off their next treatment, or a complimentary add-on. State the terms plainly, track it in your booking system, and thank the referrer by name. One referral a week from your existing clients is 52 new clients a year.

### What not to do

Do not spend your first marketing budget on expensive adverts before your booking flow, your reviews, and your rebooking system work — adverts that send people to a confusing booking page waste money. Do not discount constantly; it trains clients to wait. Do not copy another spa's social media; your clients book you, not a generic spa. And do not measure marketing by likes. Measure it by bookings, rebooking rate, and membership sign-ups.

### The year-one milestones

- Month 1: 100 clients through the door, 40% rebooking rate.
- Month 3: 50 members, 50% rebooking rate, 20 reviews.
- Month 6: 60% utilisation, 100 members, retail at 8–10% of revenue.
- Month 12: 65–70% utilisation, 120+ members, 70% of revenue from returning clients, and a price review completed.

If you miss a milestone, the answer is never "spend more on adverts." It is to ask which of the three numbers from Module 1 is weak — utilisation, revenue per hour, or rebooking — and fix that one first.

### Implementation steps

1. Complete the grand-opening marketing plan template in templates/, with dates, owners, and budgets.
2. Set up your Google Business Profile and your review request routine before opening day.
3. Write your referral programme terms and put them at reception and on your website.

---

## Appendix A — Worked Example: A Complete 12-Month Projection

This example shows a two-room spa in its first year. The numbers are illustrative — replace every one with your own costs and prices — but the structure is the one to use: start with capacity, apply utilisation, price the hours, add memberships and other streams, then subtract costs.

**Assumptions**

- 2 treatment rooms, open 6 days a week, 8 hours a day: 416 bookable hours a month
- Average treatment price: $105; average kept revenue per session after product and therapist cost: $58
- Rent and utilities: $3,200 a month; insurance: $180; software and booking: $120; marketing: $400; other overhead: $600
- Total fixed overhead: $4,500 a month
- Owner's salary: $3,000 a month (paid as a fixed draw, included in the projection)

**Months 1–3 (building)**

- Utilisation: 40%, so 166 sessions a month
- Treatment revenue: 166 × $105 = $17,430 gross; kept revenue after direct costs: 166 × $58 = $9,628
- Memberships: growing from 15 to 40 members, averaging $2,800 a month
- Retail and gift cards: $1,200 a month
- Total monthly income: about $13,628
- Total monthly costs: $4,500 overhead + $3,000 owner's draw = $7,500 (direct treatment costs are already reflected in the kept-revenue figure)
- Monthly surplus: about $6,128 before tax — but remember the build-out and opening costs sit outside this monthly view, and months 1–3 also carry launch marketing.

**Months 4–8 (growing)**

- Utilisation: 55%, so 229 sessions a month; kept revenue: 229 × $58 = $13,282
- Memberships: 60–90 members, averaging $6,500 a month
- Retail and gift cards: $1,800 a month
- Total monthly income: about $21,582
- Costs: $7,500
- Monthly surplus: about $14,082 before tax

**Months 9–12 (established)**

- Utilisation: 68%, so 283 sessions a month; kept revenue: 283 × $58 = $16,414
- Memberships: 110–130 members, averaging $10,500 a month
- Retail and gift cards: $2,600 a month
- Total monthly income: about $29,514
- Costs: $7,500
- Monthly surplus: about $22,014 before tax

**The lesson of the projection:** the spa does not become comfortable because treatments alone grow. It becomes comfortable because membership revenue grows from $2,800 to $10,500 a month while treatment utilisation rises steadily. Both levers matter, and the membership lever is the one that protects the quiet months.

Build your own version of this projection with the pricing calculator and membership templates, and revisit it quarterly against your real numbers. A projection you update is a management tool. A projection you file away is decoration.

---

## Appendix B — Glossary

- **Utilisation:** the percentage of bookable treatment hours that are actually booked.
- **Revenue per treatment hour:** the money kept per hour of treatment after product and therapist costs.
- **Rebooking rate:** the percentage of clients who book their next appointment before leaving or within 30 days.
- **Breakage:** membership credits that members pay for but do not use.
- **Menu engineering:** sorting treatments by popularity and profitability to decide what to feature, fix, or remove.
- **Scope of practice:** the treatments and services a licensed professional is legally permitted to perform in a given jurisdiction.
- **Series/package:** a set of treatments bought in advance at a modest saving.

---

## Your Next 30 Days

1. **Days 1–7:** complete Workbook Exercises 1.1, 2.1, and 5.1. Know your three numbers, your competitors, and your true treatment costs.
2. **Days 8–14:** draft your menu (Module 4) and price it (Module 5). Build your three membership tiers (Module 6).
3. **Days 15–21:** write your operations manual starter, your supplier checklist, and your grand-opening plan.
4. **Days 22–30:** set your launch or relaunch date, put your price-review date in the calendar, and book your first weekly numbers review.

A spa that earns all year is not built in a weekend. It is built in thirty days of decisions, then kept by a weekly rhythm. Start with the numbers, keep the menu tight, price from your costs, and let memberships carry the quiet months. That is the whole programme, and it works if you work it.

---

*Spa & Wellness Business Builder — education only. Licensing and regulations vary by state and country; confirm the requirements that apply to you with your licensing board and a qualified professional before you act.*
