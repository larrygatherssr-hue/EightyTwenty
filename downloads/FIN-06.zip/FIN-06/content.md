# The Passive Income Builder

## Build Your First Income Stream — Choose a Model, Validate It, and Launch in 90 Days

---

## Introduction: What This Course Is, and What It Is Not

This course is a practical, honest guide to building a first income stream outside your salary. It is designed for someone who works full time, has roughly five to ten hours a week to spare, and wants a second source of income that is real, legal, and built on work they actually do — not on a secret, a shortcut, or a promise.

Let us start with the plainest statement in this course, because everything else depends on it: **there is no income that is fully passive from day one.** Every income stream that later runs with little day-to-day effort was built with a large amount of upfront effort. A digital product that sells while you sleep took weeks to write, record, design, and launch. A rental property that pays monthly rent took months to find, finance, and set up. A content library that earns advertising revenue took a year or more of regular publishing before it earned anything meaningful. The word "passive" describes what the income looks like *after* the building is done — not what it costs to build.

That is not a reason to avoid the goal. It is a reason to approach it with clear eyes. People fail at this not because they are lazy or unlucky, but because they start with the wrong expectation. They expect money in the first month, choose a model because someone online made it look easy, build something nobody asked for, price it by guessing, and then quit when the first launch earns very little. This course is built to prevent each of those specific mistakes, in that order.

### Who this course is for

This course is for side-hustlers and employed professionals, roughly aged 28 to 45, who have five to ten hours a week and want a second income stream beyond their salary. You do not need a large amount of capital. You do not need an audience. You do not need to quit your job, and this course will never ask you to. You do need patience, a willingness to talk to real potential customers before you build anything, and the discipline to finish a small launch even when it is imperfect.

### Who this course is not for

It is not for someone looking for a guaranteed return, a get-rich-quick method, or a way to replace a full-time salary in ninety days. It is not investment advice, and it will not tell you which stocks, cryptocurrencies, properties, or funds to buy. It is not a substitute for advice from a qualified accountant, tax adviser, or lawyer about your own situation. If you are in serious debt, behind on essential bills, or facing a financial emergency, your first priority should be stabilising your household finances — not starting a side business. The budgeting and debt work comes first; this course will still be here afterwards.

### What you will be able to do by the end

By the end of the ninety days this course maps out, you will have:

1. Chosen one income model that fits your actual time, skills, and capital — and be able to explain why you rejected the others.
2. Validated that real people want what you plan to offer, using conversations and small tests rather than guesses.
3. Set a price based on costs, value, and comparable offers — not on a feeling.
4. Built a minimum viable product: the smallest version that a real customer can pay for.
5. Launched it to your first ten customers and learned from what actually happened.
6. Set up the basic systems, records, and routines that keep the stream running without consuming your evenings.
7. A clear, honest picture of what you earned, what it cost, and what the next ninety days should look like.

That is the outcome. It is modest, and it is real. A first launch that earns a few hundred dollars and teaches you exactly what your customers want is a success. A first launch that earns nothing but teaches you the same lesson cheaply is also a success, if you learn from it instead of repeating it.

### How to use this course

The course has ten modules. Modules 1 to 4 are thinking work: understanding passive income honestly, choosing a model, validating demand, and pricing. Modules 5 and 6 are building and launching. Modules 7 and 8 are systems and record-keeping — the unglamorous work that decides whether a stream survives. Module 9 is a catalogue of the failure patterns that end most first attempts, so you can recognise them early. Module 10 pulls everything into a day-by-day ninety-day plan.

The format is a written course manual of ten modules, and this text is the full course: every concept, example, worksheet instruction, and worked number is written here in complete form, so you can follow the course from this text alone. Work through the modules in order the first time. Do the exercises at the end of each module before moving on — they are short, and they are where the learning becomes a decision. The companion workbook and templates in this product give you the forms to do that work on paper: the income-model selector, the validation worksheets, the pricing worksheet, the ninety-day launch plan, the launch checklist, and the income-and-cost tracker.

A note on numbers in this course: every worked example uses illustrative figures that are clearly labelled as examples. They are there to show you *how* to do the arithmetic, not to predict what you will earn. Your numbers will be different. That is expected. The method is the point; the example numbers are only a demonstration of the method.

### A note on honesty

You will notice a tone in this course that is deliberately different from most passive-income content. There are no screenshots of earnings, no claims that a particular model earns a particular amount, and no testimonials. That is intentional. Earnings screenshots prove nothing about what you will earn, testimonials are easy to fabricate, and market-wide income statistics for side hustles are unreliable because most sellers do not publish honest figures and most surveys suffer from survivorship bias — the people who failed do not answer the survey. Where this course gives a range, it says so, explains why the range is wide, and shows you how to estimate your own range from your own costs and prices. Where it does not know, it says so.

---

## Module 1: What Passive Income Really Is (and What It Is Not)

### 1.1 The definition that matters

Passive income is income you receive that is not directly tied to an hour you work in that same moment. Rent arrives whether or not you worked that day. A digital product sells while you are at your day job. A dividend is paid whether or not you checked your portfolio. That is the useful definition — and it is also the definition that misleads people, because it describes the income after the asset exists, and says nothing about what it took to create the asset.

A better way to think about it is in three stages:

- **Stage 1 — Build.** You spend time, and sometimes money, creating something: a product, a body of content, a system, a property, a licence. You are paid nothing, or almost nothing, during this stage.
- **Stage 2 — Launch and prove.** You offer it to real customers, learn what is wrong with it, fix it, and make your first sales. Income is small, irregular, and often less than your costs so far.
- **Stage 3 — Maintain.** The asset exists, customers find it, and your ongoing work is maintenance: answering questions, updating the product, keeping the listing live, handling the occasional problem. Income becomes steadier, and the hours per dollar earned fall sharply.

Most content about passive income only shows Stage 3. It shows the rent cheque, the sales notification, the dashboard. It does not show Stages 1 and 2, which is where almost all the work lives. If you plan for Stage 3 effort and get Stage 1 reality, you will feel cheated and quit. If you plan for Stage 1 effort and reach Stage 3, you will feel pleasantly surprised. Plan for Stage 1.

### 1.2 What passive income is not

**It is not money without work.** Every legitimate model requires either a large upfront investment of time, a large upfront investment of money, or both. Models that claim to require neither are, at best, misunderstandings and, at worst, scams. If someone offers you income with no work and no capital, ask who is paying you and why. If there is no clear answer, walk away.

**It is not quick.** A realistic timeline for a first digital-product stream, worked at five to ten hours a week, is: one to two months to choose and validate, one month to build, one month to launch and learn. That is ninety days to a *first* launch, not to a reliable income. A reliable income — one you could count on month to month — typically takes several launches, several rounds of improvement, and six to eighteen months of steady maintenance. Anyone promising a reliable income in thirty days is selling you the promise, not the income.

**It is not risk-free.** The risks are smaller than starting a full business with a lease and staff, but they are real: you can spend money on tools and advertising and earn it back slowly or not at all; you can spend three months building something nobody wants; you can discover that the model you chose needs far more ongoing time than you have. This course reduces those risks by making you validate before you build and by keeping your first launch small and cheap — it does not remove them.

**It is not the same as investing.** Buying shares, funds, or property with the hope that they rise in value is investing, and it carries its own risks and rules. This course is about building an income stream from your skills and effort — a product, a service converted into a product, or a content asset. It does not recommend specific investments, and nothing in it should be read as investment advice. If you want to invest, learn about that separately, from regulated sources, and consider professional advice.

**It is not a replacement for your salary — not at first.** A sensible first goal is an extra £200 to £500 a month (or the equivalent in your currency) from a stream you control, after costs. That is a meaningful second income: it covers a bill, builds savings, or funds the next product. It is not a salary replacement, and treating it as one in the first year creates pressure that leads to bad decisions — overpricing, overspending on ads, or quitting a stable job too early. Keep the job. Let the stream prove itself for a year before you even discuss changing your employment.

### 1.3 The four ingredients of every income stream

Every working income stream, in any model, is made of the same four ingredients. If one is missing, the stream does not work.

1. **An asset.** Something that exists independently of your working hours: a product file, a course, a template, a book, a set of videos, a rented property, a licence, a subscriber list. Without an asset there is nothing to sell while you are not working.
2. **An audience or a channel.** A way for buyers to find the asset: a marketplace listing, a social media account, a search result, an email list, a partnership, a local network. An asset nobody can find earns nothing.
3. **A transaction.** A price, a payment method, and a delivery mechanism. The buyer must be able to pay easily and receive what they paid for without you being present.
4. **Trust.** The buyer must believe the asset is what you say it is, that it will be delivered, and that you will help if something goes wrong. Reviews, clear descriptions, a refund policy, and responsive support all build trust. Without it, the first three ingredients sit idle.

Notice what is not on the list: a large following, a personal brand, or expensive equipment. Those help, but none is required for a first stream. A single useful template sold through a marketplace to strangers who found it by searching is a complete income stream. It has an asset, a channel, a transaction, and enough trust from the marketplace itself.

### 1.4 Active, leveraged, and passive: a spectrum, not a switch

It helps to place income on a spectrum rather than in two boxes:

- **Active income.** You are paid for hours you work. Stop working, income stops the same week. Your salary and most freelance work sit here.
- **Leveraged income.** You are still involved, but one hour of your work reaches many buyers: a live workshop delivered to forty people, a service productised into a fixed-price package, a template that accompanies your consulting. Income continues for a while after the work, but needs regular new effort.
- **Passive income.** The asset earns with only maintenance work. A course recorded once and sold for two years with occasional updates sits here — but note that the recording was active work, and the updates are leveraged work. The "passive" part is only the middle.

Most first streams should aim at leveraged income first and passive income second. A service-to-product offer (Module 2) is leveraged: you do the work once, package what you learned, and sell the package. Pure passive income is the destination, not the starting point. If you aim straight at passive and skip leveraged, you usually end up with an asset nobody wants because you never did the work closely enough with customers to learn what they need.

### 1.5 The maths of a second income

Before choosing a model, it helps to see the arithmetic in plain terms. Suppose your goal is an extra $300 a month after costs. How many sales is that?

- At $10 a sale, you need 30 sales a month — every month.
- At $25 a sale, you need 12 sales a month.
- At $50 a sale, you need 6 sales a month.
- At $100 a sale, you need 3 sales a month.

The same $300 can mean thirty transactions or three. Low-priced products need volume, which needs an audience or a marketplace with search traffic. Higher-priced products need fewer buyers but each buyer needs more trust, more proof, and a stronger reason to choose you over alternatives. Neither is better in general; the right choice depends on what you can realistically reach. A person with no audience and no advertising budget will find three $100 sales harder than thirty $10 sales through a marketplace — but will also find that thirty $10 sales require a product people search for every day. Module 4 works through pricing properly, including costs and fees, so these numbers become your numbers.

There is also the question of what $300 a month costs you in time. If the stream needs twenty hours a month of maintenance, you are earning $15 an hour from it. If it needs five hours a month, you are earning $60 an hour. The point of building an asset is to push that hourly figure up over time — not by working more, but by needing less work per sale. Track this from the start (Module 8 gives you the tracker). If a stream earns well but eats your evenings forever, it is a second job, not a passive stream, and you should either systematise it or stop it.

### 1.6 The honest timeline

Here is a realistic timeline for a first-time builder working five to ten hours a week. It is deliberately unexciting.

- **Weeks 1–2:** Learn the landscape, choose a model, talk to potential customers. No building yet.
- **Weeks 3–4:** Validate demand with a small test. Decide go or no-go on the idea.
- **Weeks 5–8:** Build the minimum viable product. Price it. Set up the listing, payment, and delivery.
- **Weeks 9–12:** Launch to your first ten customers. Collect feedback. Fix the biggest problems. Record what you earned and spent.
- **Months 4–6:** Improve the product, add one channel, and aim for steady small sales.
- **Months 6–12:** Decide, with evidence, whether to grow this stream, improve it, or start a second one.

Most first products earn little in their first ninety days. That is normal, not failure. The purpose of the first ninety days is proof: proof that someone will pay, proof that you can deliver, and proof that you know what to improve next. The income grows in the second and third ninety-day cycles, if the first one proved the idea is sound.

### 1.7 Exercise — Module 1

1. Write down, in one sentence, what "passive income" means to you right now. Then write down how many hours a week you can honestly give this for the next ninety days, and what you will stop doing to make that time.
2. Write down your first financial goal for this stream as a monthly figure *after costs*, and work out how many sales a month that means at three different prices ($10, $50, $100). Which of those feels most achievable for you, and why?
3. List three income claims you have seen online that now look doubtful to you, and write one sentence for each explaining what information was missing.

---

## Module 2: Choosing a Model That Fits Your Time, Skills, and Capital

### 2.1 Start with your constraints, not with the opportunity

Most people choose a model backwards: they hear about a model, get excited, and then try to fit their life around it. The right order is the reverse. Your time, skills, and capital are fixed facts for the next ninety days. The model must fit them. A model that needs twenty hours a week will fail for someone with six, however good the model is. A model that needs $5,000 of capital will fail for someone with $200, however good the returns look on paper.

So before you look at any model, write down your honest constraints:

- **Time:** How many hours a week, every week, for ninety days? Be honest about your worst week, not your best. If your answer changes with the season, use the lower number.
- **Skills:** What can you already do well enough that someone would pay for it? What do you know from your job, your hobbies, or your life experience that other people struggle with? What are you willing to learn, and what will you not learn in ninety days?
- **Capital:** How much money can you spend on this without affecting your household? This is your *risk capital* — money you can afford to lose entirely. If the answer is under $100, that is useful information, not a problem: it rules some models in and others out.
- **Tolerance for people-work:** Some models need constant contact with customers; others need almost none. Be honest about which you prefer. A model that needs daily customer chat will fail for someone who hates customer chat, however profitable it looks.
- **Timeline:** Do you need money in three months, or can you build for a year before expecting much? Content-based models are slow; service-to-product models are faster.

Write these down in the income-model selector in your workbook. You will use them to score every model that follows. A model that scores well on opportunity but badly on fit is a model to reject — and rejecting models is the most valuable skill in this module.

### 2.2 The models, compared honestly

There are many ways to earn outside a salary. Below are the main families, each described with what it really requires, what it can realistically return in the first year, and who it suits. No model here is described as best. Each has a cost.

#### Model A: Digital products

**What it is:** A file or set of files a customer buys and downloads: a template, a spreadsheet, a planner, a guide, a set of presets, a short course, an e-book. You make it once and sell copies.

**What it really requires:** The ability to make something genuinely useful; a marketplace or a simple sales page; time to create the product (typically 20–60 hours for a first product); basic design or formatting skills, or the willingness to learn them; patience, because the first sales are slow.

**Costs:** Low. Often $0–$200 for tools, a marketplace account, and perhaps a domain name. The main cost is your time.

**Realistic first-year range:** Very wide. Many first products earn under $100 in their first year. A useful product in a searched-for niche, priced between $10 and $50, can earn a few hundred to a few thousand dollars in its first year. A small number earn much more, usually because the seller already had an audience or a marketplace presence. Expect the low end; plan for it.

**Ongoing time:** Low after launch — a few hours a month for customer questions, updates, and keeping the listing fresh.

**Suits:** People who can write, design, organise, or teach something specific; people with little capital; people who prefer to work alone.

**Watch out for:** Building something nobody searched for. Digital products fail most often because the seller guessed at demand instead of validating it (Module 3).

#### Model B: Rentals-adjacent and property models

**What it is:** Income connected to property without necessarily buying a property outright: renting out a spare room or a parking space where local rules allow it; managing a short-term rental for someone else for a fee; creating a guide, calculator, or service for landlords or tenants; rent-to-rent arrangements where legal and properly contracted.

**What it really requires:** Capital or access to property for the direct versions; local legal knowledge — tenancy law, planning rules, tax rules, and insurance differ sharply by place and are not optional; a tolerance for dealing with people, maintenance, and occasional problems.

**Costs:** High for direct property models (deposit, fees, furnishing, insurance); low for service and information models built around property.

**Realistic first-year range:** Direct models can produce meaningful monthly income but carry meaningful risk and cost; service models around property earn like any other service. This course does not recommend buying property as a first passive-income project unless you already understand property, have the capital, and have taken proper local advice. That is a separate, larger decision.

**Ongoing time:** Medium to high for direct models. Tenants, maintenance, and regulation do not pause.

**Suits:** People who already own or have access to property, or who already work in property and can productise that knowledge.

**Watch out for:** Anyone who presents property income as passive. It is one of the least passive models at the start. Also: short-term rental rules change frequently in many cities. Check the current rules where you live before spending anything.

#### Model C: Service-to-product offers

**What it is:** You take a service you already sell (or could sell) by the hour and turn the repeatable part into a fixed product: a one-hour service becomes a recorded walkthrough plus templates; a consulting process becomes a paid audit with a written report template; a design service becomes a set of branded templates.

**What it really requires:** A service you already know how to deliver; at least a few clients or former clients to learn from; the discipline to document your process instead of doing it from memory each time.

**Costs:** Very low. You are packaging knowledge you already have.

**Realistic first-year range:** Often the fastest of the models to first revenue, because you already know the customer and the problem. A productised service can earn its first sales within weeks of launch if you offer it to past clients first.

**Ongoing time:** Medium — the product needs updating as your service knowledge grows, and buyers will ask questions.

**Suits:** Freelancers, consultants, tradespeople, coaches, and anyone whose job involves solving the same problem repeatedly.

**Watch out for:** Productising a service nobody wants to do themselves. Some services are hired precisely because the buyer does not want to do the work. A do-it-yourself version of that service may have no buyers. Validate first.

#### Model D: Content and audience models

**What it is:** A blog, newsletter, video channel, or podcast that earns through advertising, sponsorship, affiliate commissions, or selling your own products to the audience. The content is the asset; the audience is the channel.

**What it really requires:** The ability to publish useful content regularly for a long time — typically six to twelve months before meaningful income; a clear topic and a clear reader or viewer; patience with slow growth.

**Costs:** Low in money, high in time. Expect 5–10 hours a week of publishing for many months before revenue.

**Realistic first-year range:** Usually $0–$500 in the first year for a new creator publishing part time. A small number earn more, almost always because they published consistently in a niche with advertisers or because they already had an audience elsewhere. Content income compounds, but it compounds slowly and only if you keep publishing.

**Ongoing time:** High. Content income stops growing — and often declines — when publishing stops.

**Suits:** People who enjoy writing, recording, or teaching; people who can commit to publishing weekly for a year; people building an audience as a long-term asset alongside a faster model.

**Watch out for:** Starting a content model as your only model and expecting income in ninety days. Content is a slow model. It pairs well with a digital product (the content brings the audience, the product earns the money) but it is a poor choice as a standalone first stream if you need income soon.

#### Model E: Affiliate and referral income

**What it is:** Recommending products or services you genuinely use and earning a commission when someone buys through your link. Common through marketplaces, software companies, and course platforms.

**What it really requires:** An audience or a channel where recommendations are trusted; honest disclosure that you earn a commission; the discipline to recommend only products you would recommend without a commission.

**Costs:** Very low.

**Realistic first-year range:** Without an audience, close to $0. With a small engaged audience, tens to a few hundred dollars a month. High affiliate earners have large audiences or high-value products; neither appears in ninety days from zero.

**Ongoing time:** Low per sale, but the audience needs ongoing content.

**Suits:** People who already have an audience, a blog, a channel, or a community where they are a trusted voice.

**Watch out for:** Promoting products you have not used, or choosing products by commission rate instead of quality. That destroys the trust the model depends on. Also be aware that affiliate terms change, commissions are cut, and programmes close. Never build your only income on someone else's programme.

#### Model F: Licensing and royalties

**What it is:** Creating something once — a photograph, a music track, a design, a piece of software, a written work — and licensing it for repeated use.

**What it really requires:** A craft skill and a body of work; an understanding of licensing terms; patience, because royalties accumulate slowly across many small uses.

**Costs:** Low in money; high in time to build a catalogue.

**Realistic first-year range:** Usually small in year one. A large catalogue earns more than a small one; a single item rarely earns much.

**Suits:** Photographers, musicians, designers, writers, and developers with a craft they already practise.

**Watch out for:** Platforms that take a large share or demand exclusivity. Read the terms before uploading a catalogue anywhere.

#### Model G: Small rental and sharing models

**What it is:** Renting out something you already own when you are not using it — a vehicle, equipment, a camera, tools, a storage space — through a platform, where local rules and insurance allow it.

**What it really requires:** An asset worth renting; insurance that covers rental use (your standard policy often does not); time to manage bookings, handovers, and cleaning or maintenance.

**Costs:** Low to start; insurance and platform fees are the main costs.

**Realistic first-year range:** Depends entirely on the asset and local demand. A useful asset in a busy area can earn a meaningful monthly amount; an unusual asset may earn nothing.

**Ongoing time:** Medium — each booking needs handling.

**Suits:** People who own a rentable asset they do not use daily.

**Watch out for:** Insurance gaps and wear on the asset. Check both before your first booking, and factor wear into your price.

### 2.3 Scoring the models against your constraints

Use the income-model selector in the workbook. Score each model from 1 to 5 on five questions:

1. **Time fit.** Can I build this in my available hours within ninety days?
2. **Skill fit.** Can I do the core work well already, or learn it quickly?
3. **Capital fit.** Can I afford the startup cost without strain?
4. **Speed to first sale.** How soon could a real customer pay me?
5. **Enjoyment.** Will I still want to do the maintenance work in six months?

Add the scores. The highest total is your leading candidate — but read the notes before you commit. If your top model scores 5 on opportunity and 1 on enjoyment, it will fail in month four when the novelty wears off. Choose the model with the best *balanced* score, not the highest single score. For most readers of this course, that will be a digital product or a service-to-product offer, often paired with a slow content channel on the side. That is a sensible default, not a rule. If your constraints point elsewhere, follow your constraints.

### 2.4 The decision you should make this week

By the end of this module, write down one sentence: *"I will build [model] for [audience] because [reason tied to my constraints]."* Then write down the two models you rejected and one sentence each for why. Keep that page. In six weeks, when a new model looks tempting, re-read it. The temptation to switch models mid-build is one of the commonest failure patterns in this field (Module 9). A written decision, made calmly, is your defence against it.

### 2.5 Exercise — Module 2

1. Complete the income-model selector for at least four models. Write your one-sentence decision and your two rejections.
2. For your chosen model, list the five most likely ways it could fail for *you specifically* — not in general, but given your time, skills, and capital.
3. Find three real examples of your chosen model being sold today (a marketplace listing, a sales page, a channel). Note the price, what is included, and who it seems to be for. Do not copy them; study them.

---

## Module 3: Validating Demand Before You Build

### 3.1 The most expensive mistake

The most expensive mistake in this field is building something nobody wants. It is expensive not because of the money — a first digital product often costs little in cash — but because of the time. Three months of evenings spent building a product that earns nothing is three months you cannot get back, and it is the experience that makes most people quit and conclude that passive income "does not work". The product did not fail because passive income does not work. It failed because demand was assumed instead of tested.

Validation is the work of testing demand *before* you build. It is not market research in the corporate sense — no surveys of a thousand people, no paid reports. It is a set of small, cheap, honest tests that answer one question: **will real people pay for this, and can I reach them?** If the answer is no, you learn it in two weeks for almost nothing, and you choose a different idea. That is a good outcome. A failed validation is not a failure of the course; it is the course working.

### 3.2 What counts as validation — and what does not

Not everything that feels like validation is validation. Be strict about this.

**What counts:**

- A stranger pays you, or pays a deposit, for the thing (or a clear promise of it).
- A stranger gives you their email address in exchange for a specific promise related to the thing, and then replies when you write to them.
- A stranger spends time answering detailed questions about the problem you solve, and describes a version of the problem you recognise.
- A stranger pre-orders, joins a waiting list with a payment detail, or books a call to discuss buying.
- You find existing products selling steadily in the same area — not one listing with no reviews, but several listings with reviews, questions, and recent activity.

**What does not count:**

- Friends and family saying "that sounds great". They love you; they are not your market.
- Likes, shares, or positive comments on a post. Attention is not demand. People like free content about a problem they will never pay to solve.
- A poll where people say they *would* buy something. Stated intent is a poor predictor of spending. People overstate their willingness to pay by a wide margin.
- A large number of search results for a topic. That shows interest, not willingness to pay.
- Your own certainty that the idea is good. Certainty is not evidence.

The rule is simple: **money, time, or contact details given by a stranger are evidence. Opinions are not.**

### 3.3 The validation sequence

Work through these steps in order. Stop and reconsider if a step fails badly — do not push through to building in the hope that the next step will fix it.

**Step 1 — Describe the customer and the problem in one paragraph.** Write down who the customer is, what specific problem they have, what they do about it today, and what it costs them to leave it unsolved. If you cannot name the customer precisely — "busy parents", "small business owners", and "anyone who wants to save money" are all too vague — you are not ready to validate. Narrow it until you can picture one person. "A self-employed plumber who spends two hours a week on paperwork and hates invoicing" is a customer. "Small business owners" is a category.

**Step 2 — Find ten people who match that description and talk to them.** Not a survey — a conversation, even a short one. Ask about the problem, not about your product. Good questions: "How do you handle this today?" "What is the most annoying part?" "What have you tried?" "What would a good solution be worth to you?" Bad questions: "Would you buy my course?" "Do you like my idea?" People will be polite to the second kind and honest to the first. Where do you find them? In the places they already gather: forums, social media groups, marketplace reviews of competing products (read the complaints — they are a gift), local networks, and your own past clients. Take notes. Look for patterns: if seven of ten people describe the same frustration in similar words, you have found a real problem. If each describes a different problem, you have not found one yet.

**Step 3 — Check that others are already selling a solution.** Competition is evidence of demand, not a reason to stop. If nobody is selling anything in this area, ask why: it may be an undiscovered niche, but more often it is an area where nobody pays. Look at three to five existing products. Read their reviews, especially the three-star reviews — they say what the product does well and what it misses, which is your opening. Note their prices. If they are all free, that tells you buyers in this area expect free, and you will need a different model or a different area.

**Step 4 — Run a small, cheap test.** Choose one of these, depending on your model:

- **The landing page test.** Write a one-page description of the product as if it exists: what it is, who it is for, what it includes, the price. Share it where your customers gather, or send it to the people you interviewed. Count how many people click through, leave an email address, or ask to buy. Ten email addresses from strangers is a meaningful signal; a hundred page views and no addresses is a clear no.
- **The pre-sale test.** Offer the product at a founding price to a small group, with a clear delivery date and a refund promise. If even three to five people pay, you have validated demand and you have your first customers. If nobody pays, you have learned cheaply.
- **The concierge test.** Deliver the outcome manually, once, for one customer, and charge for it. A template seller might build a custom spreadsheet for one client; a course seller might coach one person through the process. The manual version teaches you exactly what the product version must contain, and the payment proves someone values it.
- **The marketplace test.** List a small version of the product — a single template, a short guide — at a low price, and see whether strangers buy it over two to three weeks. A few sales prove the channel works for you; no sales after real listing traffic tells you to change the product or the listing, not to build a bigger version.

**Step 5 — Decide go or no-go, in writing.** Use the validation worksheet. Record how many people you spoke to, what they said, what your test showed, and your decision. If the evidence is weak, the honest decision is to change the idea — narrow the audience, change the problem, or pick a different model — and validate again. Two weeks spent validating a second idea is far cheaper than three months building the first one.

### 3.4 How much validation is enough?

You do not need certainty. You need enough evidence to justify spending the next month building. As a practical standard:

- You have spoken to at least ten people who match your customer description.
- At least half of them describe the same problem in similar terms.
- You have found at least three existing products or services selling in the area.
- At least one small test produced money, email addresses, or booked conversations from strangers.

If you meet three of those four, build. If you meet one or none, do not build yet. Go back and narrow the customer, change the problem, or choose a different idea.

### 3.5 What to do with what you learn

Validation is not only a yes-or-no test; it is your product specification. The words your interviewees used to describe their problem are the words your sales page should use. The workaround they described is the first feature of your product. The price they hesitated at is the top of your price range. Keep your interview notes and bring them to Module 5, when you build. A product built from ten real conversations is almost always better than a product built from one person's assumptions, however expert that person is.

### 3.6 Exercise — Module 3

1. Write your one-paragraph customer and problem description. Then list ten real people or places where you can find people who match it.
2. Interview at least five of them this week using the questions in this module. Record their answers in the validation worksheet.
3. Find three competing products and complete a row for each: price, what is included, what reviewers praise, what reviewers complain about.

---

## Module 4: Pricing Your First Product

### 4.1 Why pricing feels hard — and why guessing fails

Most first-time sellers price by feeling: they pick a round number, copy a competitor, or choose a price that feels "fair" without any arithmetic. All three methods fail in predictable ways. A round number may be far above what your audience will pay or far below what your product is worth. A competitor's price reflects their costs, audience, and reputation, not yours. A price that feels fair to you is usually the price you would pay, and you are not your customer.

Pricing is a calculation with three inputs: your costs, the value to the buyer, and the market. This module works through all three, with worked examples you can copy.

### 4.2 Input 1 — Your costs

List every cost of making and selling one unit, and every fixed cost of the product. For a digital product, the costs are small but not zero:

- **Fixed costs (paid once, however many you sell):** design or formatting tools, stock images or fonts, a domain name, a marketplace listing fee, the time you spend building (value your time at a rate, even if you are not paying yourself yet — it matters for the decision).
- **Variable costs (paid per sale):** the marketplace or payment fee per transaction (often a percentage plus a fixed amount), any delivery or hosting cost per sale, customer support time per sale, refunds.
- **Your time after launch:** support, updates, and maintenance, valued at an hourly rate.

**Worked example — pricing a digital product.** Imagine you build a budgeting template pack and plan to sell it for $29. Your costs look like this:

- Fixed costs: design tool subscription for the build month, $15; stock icons, $12; total fixed costs, $27.
- Per-sale costs: marketplace fee 10% ($2.90) plus payment processing of $0.30 plus 2.9% ($0.84), so about $4.04 per sale; estimated support time of 10 minutes per sale on average, valued at $25 an hour, so about $4.17 per sale. Total variable cost per sale: roughly $8.21.
- Contribution per sale: $29.00 − $8.21 = $20.79.
- Break-even: you need to sell enough units to cover the $27 of fixed costs, so $27 ÷ $20.79 = 1.3, meaning two sales cover your cash costs. But that ignores your build time. If you spent 30 hours building and value your time at $25 an hour, that is $750 of time. To recover that as well, you need ($27 + $750) ÷ $20.79 = about 38 sales. That is the honest break-even: 38 sales before the product has truly paid for itself.

That example is illustrative, not a promise — your fees, time, and price will differ — but the method is the point. Do this arithmetic for your own product before you choose a price. If the break-even number of sales looks unreachable in your market, the price is too low, the costs are too high, or the product is wrong. Change one of those three things before you launch.

A note on valuing your time: if you do not value your build time, every product looks profitable, because the cash costs are tiny. That is how people end up spending 200 hours building a product that earns $300 and calling it a success. It is not a success; it is a hobby that paid $1.50 an hour. Valuing your time does not mean you pay yourself that money from the first sale — it means you make an honest decision about whether the hours are worth it.

### 4.3 Input 2 — Value to the buyer

Value is not what your product cost you to make; it is what the buyer's problem costs them if they do not solve it. A template that saves a small business owner three hours a month is worth more to them than the same template is worth to a student. A guide that helps someone avoid a $500 mistake is worth more than a guide that offers general tips.

To estimate value, go back to your validation interviews and ask: what does this problem cost the customer today — in money, in time, in stress, in missed opportunity? Then ask what a good solution would be worth. You are not looking for a precise number. You are looking for an order of magnitude: is this a $10 problem, a $50 problem, or a $200 problem? If the problem costs the buyer $20 a year, a $97 product will not sell. If it costs them $2,000 a year, a $97 product may be underpriced.

There are two kinds of value to consider. **Functional value** is time saved, money saved, or errors avoided — the easiest to quantify. **Emotional value** is confidence, relief, pride, or belonging — harder to quantify but often the real reason people buy. A course that helps someone feel confident launching their first product sells confidence as much as information. Do not ignore emotional value, but do not use it to justify a price the functional value cannot support.

### 4.4 Input 3 — The market

Look at the prices of the three to five competing products you found in Module 3. You will usually see a range. Your price should sit inside that range unless you have a clear reason to sit outside it:

- **Below the range** makes sense if your product is smaller, simpler, or aimed at a more price-sensitive audience — or if you are deliberately launching at a founding price to get your first customers and reviews, with a stated plan to raise the price later.
- **Above the range** makes sense only if your product clearly includes more, solves the problem more completely, or serves a buyer with more at stake. "Mine is better" is not a clear reason unless you can point to a specific difference a buyer can see before paying.

Never price far outside the market range without a reason you could explain to a buyer in one sentence. And never start a price war: competing on price alone is a race to the bottom that a part-time seller with no scale cannot win.

### 4.5 Choosing your price: a method

1. Calculate your floor: the lowest price at which the product is worth your time after costs. Use the break-even method in section 4.2. The floor is not your price; it is the price below which you should not go.
2. Estimate the value range from your interviews and the market range from competitors. Your price should sit where the value range and the market range overlap, and above your floor.
3. Choose a specific price and write down your reasoning in one paragraph. If you cannot explain the price, you have not finished pricing.
4. Plan one price test after launch: offer the product at your chosen price for the first month, then consider a small change — a founding discount that ends, a bundle, or a higher price for an expanded version — based on real sales data. Do not change the price daily, and do not discount constantly. Constant discounting trains buyers to wait.

Common price points for first digital products are $9–$29 for a single template or short guide, $29–$99 for a fuller toolkit or short course, and $99–$497 for a complete course with support and templates. This course itself is priced at $497 because it is a complete ten-module course with a workbook, templates, and a ninety-day plan — a large product aimed at a buyer whose problem is worth hundreds of dollars to solve. Your product's price should reflect its size in the same way.

### 4.6 Discounts, guarantees, and refunds

**Discounts.** A short founding discount for your first customers is reasonable: it rewards early buyers and gives you reviews. A permanent discount is not a price; it is a lower price with extra steps. If you discount, set a clear end date and a clear reason (launch week, founding members). Never discount below your floor.

**Guarantees.** A money-back guarantee reduces the buyer's risk and increases sales, especially for a new seller with no reviews. This product offers a 14-day money-back guarantee. That is a reasonable standard for a digital course. Make the terms clear and honour them promptly. A guarantee that is hard to claim destroys trust faster than no guarantee at all. Budget for a small refund rate — a few percent is normal — and treat refunds as feedback, not as failure.

**Refunds and fees.** Remember that a refunded sale usually still costs you the payment processing fee, and sometimes the marketplace fee. Factor a small refund allowance into your pricing arithmetic.

### 4.7 Exercise — Module 4

1. Complete the pricing worksheet for your product: fixed costs, variable costs per sale, contribution per sale, and break-even in units (cash only, and including your build time).
2. Write your one-paragraph pricing reasoning: your floor, the value range, the market range, and your chosen price.
3. Decide your guarantee and your founding offer, if any, and write down the exact terms.

---

## Module 5: Building a Minimum Viable Product

### 5.1 What "minimum viable" actually means

A minimum viable product — an MVP — is the smallest version of your product that a real customer can pay for and use to get the promised outcome. It is not a rough draft, and it is not a demo. It is a complete product, just a small one. It must work, it must be delivered as promised, and it must be good enough that a buyer who paid for it feels they received value. The word "minimum" refers to scope, not quality.

The most common mistake at this stage is building too much. The seller adds modules, bonuses, extra templates, and extra chapters — partly from enthusiasm, partly from the fear that the product is not enough. The result is a product that takes three times as long to build, is harder to explain, and is no more likely to sell, because the buyer cannot tell the difference between ten modules and twenty before they buy. Build the smallest version that delivers the outcome, launch it, and let real customers tell you what to add next.

### 5.2 Scoping your MVP

Take your full product idea and cut it down with three questions:

1. **What is the single outcome the buyer wants?** Not three outcomes — one. A budgeting template's outcome is "I know where my money goes each month". A launch course's outcome is "I have launched my first product". Everything in the MVP must serve that one outcome.
2. **What is the smallest set of parts that delivers it?** List every part you planned. For each one, ask: if I removed this, could the buyer still reach the outcome? If yes, remove it from the MVP and put it on a list for version two.
3. **What can I build in four weeks at my available hours?** If your available time is six hours a week, you have about 24 hours. Be realistic about what 24 hours produces. A 20-page guide and three templates is realistic. A 200-page course with video is not.

Write the MVP scope down as a short list — no more than five to seven items — and treat it as a contract with yourself. When you are tempted to add something during the build, check it against the list. If it is not on the list, it waits for version two.

### 5.3 Building in order

Build in this order, because each step depends on the one before it:

1. **The core content.** Write or record the main teaching or tool first. This is the product. Do not start with the logo, the sales page, or the cover — those are packaging, and packaging a product that does not exist yet is procrastination disguised as work.
2. **The worked examples.** Add one or two examples with real numbers that show the buyer exactly how to use the product. A template without an example is a blank form; a template with a completed example is a lesson.
3. **The instructions.** Write a short "start here" guide: what the buyer should do first, second, and third. Assume the buyer has never used a product like this. Test the instructions on someone who has not seen the product before, if you can.
4. **The delivery.** Decide how the buyer receives the product — a download link, an email with attachments, access to a folder — and test the whole path yourself, from payment to download, as if you were the buyer. Test it on a different device if you can. Broken delivery is the fastest way to lose a first customer and earn a bad review.
5. **The packaging.** Now write the product description, choose the title, design the cover or thumbnail, and set the price in the listing. Use the words your validation interviewees used. Be specific about what is included and what is not. Never promise something the product does not contain.

### 5.4 Quality standards for a first product

Your MVP must meet these standards before you launch it:

- **It works.** Every file opens, every link works, every spreadsheet calculates correctly, every video plays. Test each file yourself.
- **It is complete.** A buyer who follows the instructions can reach the promised outcome without needing to buy something else from you.
- **It is honest.** The description matches the contents. The number of pages, modules, templates, and videos stated on the sales page is the number in the product.
- **It is readable and usable.** Clear headings, a readable font size, consistent formatting, and no spelling errors in headings or instructions. You do not need professional design; you need care.
- **It respects the buyer.** No filler, no padding, no repeated content to inflate the page count, and no upsell inside the product that the buyer needs to complete the outcome.

If you are unsure whether your product is good enough, ask one person from your validation interviews to try it before launch and tell you honestly what confused them. One test user who is not a friend will find problems you cannot see, because you know how the product is supposed to work and they only know how it actually works.

### 5.5 Tools and costs

You do not need expensive tools. For most digital products, a word processor, a spreadsheet application, a free design tool for covers and thumbnails, and a marketplace or payment account are enough. Before buying a tool, ask whether a free version does the job for this launch. Before buying a course about building courses, ask whether the money would be better spent on a small test of your own idea. Keep a record of every tool cost — it belongs in your pricing arithmetic from Module 4 and your income tracker from Module 8.

### 5.6 Protecting your work

Your product is your intellectual property. Put your name and the year on it, and include a short statement of what the buyer may do with it (use it themselves; not resell, share, or redistribute it). You do not need a lawyer for a first product, and you should not spend money on formal registration before you know the product sells. Do keep a dated copy of your original files. If you use images, fonts, or music from elsewhere, check the licence: "free to download" does not always mean "free to sell in a commercial product". Use material you created yourself or that is clearly licensed for commercial use, and keep a note of the source.

### 5.7 Exercise — Module 5

1. Write your MVP scope list (five to seven items maximum) and your one-sentence outcome.
2. Build the core content first, then the worked example, then the instructions, then test the full delivery path yourself.
3. Ask one test user to try the product and record the three biggest points of confusion. Fix them before launch.

---

## Module 6: Launching to Your First 10 Customers

### 6.1 What a launch is — and what it is not

A launch is not a single day of excitement. It is a short, planned period — usually one to two weeks — in which you tell the right people, in the right places, that the product exists, and you make it easy for them to buy. The goal of your first launch is not to sell hundreds of copies. It is to sell to your first ten customers, learn from them, and end the launch with a product that is better than the one you started with.

Ten customers is a deliberate target. Ten is enough to learn from — you will see patterns in their questions and feedback — and small enough to serve well. If you aim for a hundred and get twelve, you will feel you failed. If you aim for ten and get twelve, you have succeeded and you have two extra customers' worth of learning. Set the target at ten.

### 6.2 Before launch day: the checklist

Use the launch checklist in the workbook. The essentials are:

- The product files are finished, tested, and uploaded.
- The listing is live and you have bought or tested the full path yourself.
- The price, guarantee, and refund terms are written and visible.
- You have a short description of the product (two or three sentences) and a longer one (one page) ready to paste wherever you post.
- You have a list of the places you will tell people: the people you interviewed, the groups and forums where your customers gather, your email list if you have one, your social accounts, and any marketplace where the product is listed.
- You have decided your launch offer, if any — for example, a founding price for the first week — and its end date.
- You have set aside time each day of the launch week to answer questions and help buyers. The first week is not passive. It is the most active week of the whole stream.

### 6.3 Who to tell first

Tell people in this order, because each group is warmer than the next:

1. **The people you interviewed.** Write to each of them personally. Thank them, tell them the product they helped shape is ready, and offer them the founding price. These are your most likely first buyers, and they are also your best source of honest feedback. Do not send a mass message; write to each person with one detail from your conversation with them.
2. **Past clients or customers, if you have them.** People who have already paid you for related work are far more likely to buy than strangers.
3. **Communities where you are already a member.** Groups, forums, and networks where you have contributed before — not places you join on launch day only to post a link. If you have not contributed to a community, do not launch there. Contribute first, for weeks, and launch later.
4. **Your own channels.** Your social accounts, your email list, your blog or channel. Post about the problem and the outcome, not only about the product. People buy solutions to problems they recognise; a post that describes the problem well will reach more of the right people than a post that only announces a product.
5. **Marketplace search.** If you list on a marketplace, the listing itself is a channel. Make sure the title, description, and keywords describe the problem and the outcome in the words buyers search for. This is slow traffic, but it continues after launch week ends.

Do not pay for advertising for your first launch unless you have already validated demand and you have a clear, small budget you can afford to lose. Advertising amplifies a listing; it does not fix a product or a price that is wrong. Learn from organic sales first.

### 6.4 Launch week: what to do each day

- **Each morning,** check for questions, orders, and problems. Answer questions the same day. A slow reply in launch week loses sales and trust.
- **Each day,** post or write to one group of people from your list. Do not tell everyone on day one and then go quiet. A launch is a sequence, not a single announcement.
- **When someone buys,** thank them personally if you can, and ask them — after they have had a chance to use the product — what they found useful and what confused them. Ask for a review only after they have used the product, and never offer payment for a review.
- **When something goes wrong,** fix it publicly and quickly. A buyer who reports a broken link and sees it fixed within hours becomes a loyal customer. A buyer who reports it and hears nothing tells other people.
- **At the end of each day,** record the numbers: how many people saw the offer, how many clicked, how many bought, and what questions came up. These numbers are your launch data, and they are more valuable than the revenue.

### 6.5 What to do when sales are slow

Slow sales in launch week are normal, and they are information. Do not panic, do not slash the price, and do not rebuild the product on day three. Instead, diagnose:

- **Are the right people seeing it?** If almost nobody saw the offer, the problem is reach, not the product. Tell more of the right people, in more places.
- **Are people seeing it but not clicking?** The problem is the description or the title. It may not describe the problem in the buyer's words, or the outcome may be unclear. Rewrite the description using language from your interviews.
- **Are people clicking but not buying?** The problem may be price, trust, or clarity. Is the price inside the market range? Is the guarantee visible? Is it clear what the buyer receives? Is there anything that makes a stranger hesitate — a vague description, no reviews, no clear delivery?
- **Are people buying but not finishing or not returning?** The problem is the product experience. Ask them what confused them.

Change one thing at a time, and give each change a few days to show a result. Changing the price, the title, and the description all at once tells you nothing about which change mattered.

### 6.6 After the first ten

When you reach ten customers, stop and review before you push for more. Read every piece of feedback. Fix the biggest problem. Update the product and note the change. Ask two or three buyers whether they would recommend it and why. Then decide: is this stream worth growing, or did the launch teach you that a different product or audience would work better? Either answer is a success, as long as it is based on evidence from real customers rather than on a feeling.

### 6.7 Exercise — Module 6

1. Complete the launch checklist and write your list of who to tell, in order.
2. Draft the personal message to your interviewees and the short post for your own channels.
3. Set up a simple daily log for launch week: seen, clicked, bought, questions asked.

---

## Module 7: Systems and Automation That Actually Save Time

### 7.1 The point of systems

A system is a repeatable way of doing a task so that it takes less of your time and produces a more consistent result each time it happens. Automation is a system carried out by a tool instead of by you. The point of both is the same: to reduce the hours your income stream needs from you, so that it moves from leveraged income towards genuinely passive income.

The mistake is to automate too early. If you automate a process you have only done once, you automate your guesses. The right order is: do it manually, notice the pattern, write down the steps, and only then automate the parts that are repetitive and predictable. This module follows that order.

### 7.2 The five systems every first stream needs

You do not need a complicated setup. You need five simple systems, each of which can start as a written checklist and grow into a tool later.

**1. Delivery.** How does a buyer receive the product, every time, without you being involved? The simplest reliable delivery is a marketplace that handles payment and download, or a payment link that sends the files automatically by email. Test it. Write down what happens if it fails — who the buyer contacts, and how you fix it. A delivery system that needs you to send files by hand is not a system; it is a job. Replace it as soon as you can afford the tool that automates it.

**2. Customer support.** Buyers will ask questions, report problems, and request refunds. Decide in advance: where do they contact you, how quickly will you reply, and what are the standard answers to the five most common questions? Write those answers down once, and reuse them. Set a fixed time — for example, thirty minutes each morning, three days a week — for support, rather than answering messages all day. A buyer who receives a helpful reply within a day is satisfied; a seller who answers messages all day is exhausted. A short, honest reply time stated on your sales page ("I reply within one working day") manages expectations better than an instant reply you cannot sustain.

**3. Content and listing maintenance.** Listings go stale. Prices, screenshots, descriptions, and links need occasional updates. Set a monthly reminder — thirty minutes, once a month — to check the listing, fix broken links, update the description with anything you have learned, and check that the product files are still the latest version. A product that is never updated slowly stops selling, not because it is bad, but because it looks abandoned.

**4. Money.** Income and costs must be recorded from the first sale, not reconstructed at the end of the year. Module 8 covers this in detail. The system is simple: every sale and every cost goes into the tracker the same week it happens. That is the whole system. Its value is that it takes five minutes a week and saves hours of reconstruction later, and it gives you the true picture of whether the stream is working.

**5. Improvement.** A regular, short review of what is working and what is not. Once a month, look at the numbers: sales, refunds, questions, and time spent. Ask three questions: what should I keep doing, what should I stop doing, and what is the one change most likely to help next month? Write the answers down. Make the one change. This monthly review is the system that turns a first launch into a growing stream. Without it, you repeat the same month twelve times and call it a year.

### 7.3 What to automate, and what not to automate

**Automate first:** delivery of files after payment; the purchase confirmation and "start here" email; collection of the buyer's email address with their permission; the monthly sales and cost summary if your marketplace or payment tool provides it; reminders for your own monthly review.

**Automate later, once you have done it manually several times:** social media posting on a schedule; email sequences to buyers; upsell offers for a second product; responses to the most common questions, using saved replies rather than a bot.

**Do not automate:** personal replies to a buyer's first question; handling a complaint or a refund request; asking for a review; any message that pretends to be personal when it is not. Buyers can tell, and the loss of trust costs more than the time saved. Automation should make your work invisible where the buyer does not need you, and make you more available where they do.

### 7.4 A time budget for maintenance

Once the product is launched, aim for a maintenance budget of two to four hours a month: one hour for support, one hour for the monthly review and listing check, and one to two hours for a small improvement. If the stream needs more than that every month, ask why. Often the answer is that the product instructions are unclear (so buyers keep asking the same question), the delivery is manual (so every sale needs you), or the listing attracts the wrong buyers (so the questions are about things the product never promised). Fix the cause, not the symptom. Each fix that removes a repeated task is a permanent saving of your time.

### 7.5 Worked example — a time budget for 5 to 10 hours a week

Many readers have five to ten hours a week. Here is how that time can be divided across a typical week during the build and launch phases, and how it shrinks afterwards. This is an example to adapt, not a schedule to follow exactly.

**During the build (weeks 5–8), at 8 hours a week:**

- 5 hours: building the core product — writing, recording, designing.
- 1 hour: the worked example and instructions.
- 1 hour: testing delivery, fixing problems, and preparing the listing.
- 1 hour: reading validation notes and checking the product against them.

**During launch week (week 9), at 8 hours a week:**

- 3 hours: telling people — personal messages, posts, and answering replies.
- 2 hours: customer support and fixing problems the same day.
- 2 hours: recording the daily numbers and noting questions and feedback.
- 1 hour: a short review at the end of the week.

**During maintenance (month 4 onwards), at about 1 hour a week:**

- 20 minutes: support replies, three times a week in a single short session.
- 20 minutes: recording sales and costs in the tracker.
- 20 minutes: one small improvement, or the monthly review in the first week of the month.

If your available time is five hours a week rather than ten, the build takes longer — six to eight weeks instead of four — and that is fine. Stretch the plan; do not compress the work by skipping validation or testing. The ninety-day plan in Module 10 shows how to do that.

### 7.6 Exercise — Module 7

1. Write down your five systems as checklists: delivery, support, maintenance, money, improvement. For each one, note what you will do manually and what you will automate now.
2. Write your five standard support answers: how to download, how to get a refund, what is included, what to do if a file does not open, and how to contact you.
3. Set a monthly reminder for your review, and decide the fixed time you will spend on support each week.

---

## Module 8: Tracking Income and Costs

### 8.1 Why tracking matters more than selling

Selling feels like progress. Tracking feels like administration. But tracking is what tells you whether the selling is progress. Without records, you cannot answer the three questions that decide the future of your stream: how much did I earn, how much did it cost, and how much time did it take? Without answers, you make decisions on feelings — and feelings after a good week say "grow this", while feelings after a bad week say "quit". Neither is evidence.

Tracking is also a practical necessity. In most places, income from a side stream is taxable, and you may need records for a tax return. This course does not give tax advice, and tax rules differ by country and change over time. What it does say is: keep records from the first sale, keep receipts for costs, keep the two separate from your household money where you can, and speak to a qualified tax adviser about your own situation before you file. Good records make that conversation short and cheap. No records make it long and expensive.

### 8.2 What to record

Record every sale and every cost, with the date, the amount, and a short description. Use the income-and-cost tracker in the workbook. The categories are:

**Income:** each sale (date, product, price, marketplace or payment fee, net received). Record the net amount you actually receive, not the headline price — fees are a cost, and recording the headline price as income overstates your earnings.

**Costs:** fixed costs (tools, design, listing fees, domain), variable costs (fees per sale, refunds, support time valued at your hourly rate), and any advertising or promotion spending. Record costs in the week you pay them, not at the end of the month.

**Time:** hours spent on the stream each week, split roughly between building, launching, support, and maintenance. Time is a cost even when no money changes hands. If you do not record it, you cannot see whether the stream is becoming more passive or quietly becoming a second job.

### 8.3 The monthly review: four numbers

Once a month, calculate four numbers from the tracker:

1. **Gross revenue:** the total of all sale prices in the month.
2. **Net income:** gross revenue minus all fees, refunds, and cash costs in the month.
3. **True profit:** net income minus the value of your time in the month (hours × your hourly rate). This number is often negative in the first months, because the build time is large and the sales are small. That is expected. What matters is the direction: is true profit rising month by month as sales grow and build time falls?
4. **Hours per sale:** total hours in the month divided by the number of sales. This is the passivity measure. If it is falling, the stream is becoming more passive. If it is rising, something needs fixing — usually the product, the delivery, or the listing.

Write these four numbers down each month, in the same place, so you can see the trend. A single month's numbers prove little. Six months of numbers tell you the truth.

### 8.4 Worked example — a sample launch budget and revenue projection

This is a complete worked example with honest ranges, using a fictional first digital product. It is illustrative: your figures will be different. The purpose is to show you how to build your own projection, not to predict your results.

**The product:** A small-business invoicing template pack, priced at $39.

**Assumed build:** 30 hours over four weeks at 7–8 hours a week. The seller values their time at $25 an hour, so build time is valued at $750, though no cash is paid.

**Cash costs before launch:**

| Item | Cost |
|---|---|
| Design tool, one month | $15 |
| Stock icons | $12 |
| Marketplace listing fee | $0 (free listing tier) |
| Domain name (optional, first year) | $12 |
| **Total cash costs before launch** | **$39** |

**Per-sale costs at $39:**

| Item | Amount |
|---|---|
| Marketplace fee, 10% | $3.90 |
| Payment processing, 2.9% + $0.30 | $1.43 |
| Support time, 10 minutes at $25/hour | $4.17 |
| **Total variable cost per sale** | **$9.50** |
| **Contribution per sale** | **$29.50** |

**Revenue projection — three scenarios for the first three months after launch.** These are scenarios, not forecasts. They show the range of plausible outcomes for a first product with modest reach.

| Scenario | Sales in 3 months | Gross revenue | Fees and support | Cash profit | True profit (after $750 build time) |
|---|---|---|---|---|---|
| Slow | 8 | $312 | $76 | $197 | −$553 |
| Steady | 25 | $975 | $238 | $698 | −$52 |
| Strong | 60 | $2,340 | $570 | $1,731 | $981 |

Read the table carefully. In the slow scenario, the product covers its cash costs easily but has not yet repaid the build time — that is normal for a first product, and the decision is whether the learning and the asset are worth continuing. In the steady scenario, the product has almost repaid the build time in three months, and the next three months — with no further build time — would be profitable. In the strong scenario, the product has repaid everything and earned a profit, which is a good result but not the expected one for a first product.

The honest conclusion from this example is: **a first product usually earns little in its first three months, covers its cash costs, and repays its build time somewhere between month three and month nine if it keeps selling.** If that timeline is acceptable to you, build. If you need the build time repaid in month one, this model is not for you, and you should choose a faster model — such as a service-to-product offer sold to past clients — or a different goal altogether.

To build your own projection, copy this table into the pricing calculator, replace the price, costs, and hours with your own figures, and fill in three scenarios of your own: slow (a handful of sales), steady (a realistic number based on your reach), and strong (a good result you would be pleased with, not a fantasy). If even the strong scenario does not repay your time within a year, reconsider the price or the product.

### 8.5 Separating business money from household money

As soon as you make your first sale, open a separate record — ideally a separate bank account or at least a separate tracking category — for the stream's money. Do not mix it with household spending. The reasons are practical: it makes the monthly review trivial, it makes tax reporting straightforward, and it stops you from spending income that should be set aside for fees, refunds, or tax. A simple rule that helps many sellers is to leave the first month's net income untouched, as a small reserve for refunds and costs, and only then decide what to do with later income.

### 8.6 Exercise — Module 8

1. Set up your income-and-cost tracker before launch, and record your build costs and hours as you go.
2. Build your own three-scenario projection using the worked example as a template.
3. Decide where the stream's money will be kept, and what you will set aside for refunds and costs.

---

## Module 9: Common Failure Patterns and How to Avoid Them

### 9.1 Why this module exists

Most first income streams do not fail because the idea was impossible. They fail because of a small number of repeatable patterns — mistakes that look different on the surface but share the same cause. This module names the patterns plainly, so you can recognise them in yourself early, when they are still cheap to correct. Read it before you build, and re-read it whenever you feel stuck.

### 9.2 Pattern 1 — Building before validating

**What it looks like:** Three months spent building a product, a website, a logo, and a social media presence, before a single potential customer has been asked whether they want it.

**Why it happens:** Building feels like progress. Talking to strangers feels uncomfortable. It is easier to spend an evening designing a cover than to spend it asking someone about their problem.

**The cost:** The most expensive pattern in this course. You can lose a whole season to a product nobody wants.

**How to avoid it:** Follow Module 3 in order. No building until you have spoken to ten people and run one small test. If you catch yourself building before validating, stop, and go and talk to someone.

### 9.3 Pattern 2 — Choosing a model by hype, not by fit

**What it looks like:** Choosing a model because someone online earned a large amount from it, or because it is popular this year, even though it needs time, capital, or skills you do not have.

**Why it happens:** Success stories are vivid and specific; your own constraints are boring and general. The story wins.

**The cost:** You start a model that cannot work for you, struggle for months, and conclude that you are bad at this — when the real problem was the choice.

**How to avoid it:** Use the selector in Module 2. Score the model against your actual time, skills, and capital. If it scores badly on fit, reject it however good the story is. The right model for someone else is not necessarily the right model for you.

### 9.4 Pattern 3 — Switching models mid-build

**What it looks like:** Two weeks into building a template pack, you read about a different model, get excited, and start that instead. Two weeks later, a third model. Nothing is ever finished.

**Why it happens:** The middle of a build is the least exciting part. The new model is all promise and no problems yet. Switching feels like progress because it restores the excitement of the start.

**The cost:** A collection of half-finished products and no launch. This pattern can consume a year without a single sale.

**How to avoid it:** Keep your written decision from Module 2 where you can see it. Promise yourself that you will not consider a new model until this one has launched and you have the evidence from the launch. New ideas go on a list for later, not into this week's work.

### 9.5 Pattern 4 — Pricing by feeling

**What it looks like:** A price chosen because it "feels right", copied from a competitor without understanding their costs, or set so low that the product can never repay the time spent building it.

**Why it happens:** Pricing requires arithmetic and a willingness to ask people what something is worth. Both feel uncomfortable.

**The cost:** A product that sells but loses money on every sale once time is counted, or a product that never sells because the price signals the wrong thing — too cheap to be trusted, or too expensive for the value offered.

**How to avoid it:** Do the Module 4 arithmetic. Know your floor, your value range, and your market range before you choose. Write the reasoning down.

### 9.6 Pattern 5 — Perfectionism as procrastination

**What it looks like:** The product is never ready. One more chapter, one more redesign, one more tool, one more course about building courses. Launch is always next week.

**Why it happens:** Launching means being judged. As long as the product is unfinished, it cannot fail. Perfectionism protects you from that judgement — and from any income.

**The cost:** The product never reaches a customer, so it never earns and never improves. A product that is 80% ready and launched will teach you more in a week than a product that is 95% ready and unlaunched will teach you in a year.

**How to avoid it:** Define "done" in advance — the MVP scope list from Module 5 — and launch when the list is complete. If a flaw is real, a customer will tell you, and you will fix it. That is the process working, not a failure.

### 9.7 Pattern 6 — Ignoring the numbers

**What it looks like:** No record of sales, costs, or hours. Decisions made on feelings: a good week means the stream is working; a quiet week means it is not.

**Why it happens:** Tracking is boring, and the numbers in the early months are often discouraging.

**The cost:** You cannot tell whether the stream is improving, which change helped, or whether your time is well spent. You may grow a stream that loses money, or abandon a stream that was about to work.

**How to avoid it:** Use the tracker from Module 8. Five minutes a week. Four numbers a month. No exceptions.

### 9.8 Pattern 7 — Spending money to avoid doing the work

**What it looks like:** Buying courses, tools, subscriptions, and advertising before the product exists, in the hope that spending will substitute for building, validating, or talking to customers.

**Why it happens:** Spending feels like commitment. It is also easier than the uncomfortable parts of the work.

**The cost:** Money spent on a product that does not yet have a proven customer is money that cannot be recovered, and the spending creates pressure to earn it back quickly, which leads to rushed decisions.

**How to avoid it:** Set a rule before you start: no spending above a small fixed amount (for example, $50) until you have validated demand and built the MVP. Every purchase above that amount must answer the question, "What specific problem does this solve that I cannot solve without it?"

### 9.9 Pattern 8 — Treating the first launch as the final verdict

**What it looks like:** A first launch earns little, and the seller concludes that the model, the product, or passive income itself does not work — and quits.

**Why it happens:** The first launch is the most visible result, and it is easy to treat it as a judgement on the whole idea.

**The cost:** You abandon an asset that needed one more round of improvement, or a model that needed a different audience, based on a single small test.

**How to avoid it:** Judge the first launch on what you learned, not only on what you earned. Did anyone pay? What did they ask? What confused them? What would you change? If people paid and the feedback points to a clear improvement, the launch was a success, whatever the total was. Only quit a model after two or three launches with clear evidence that the problem is the idea, not the execution.

### 9.10 Pattern 9 — Neglecting trust

**What it looks like:** Vague descriptions, no refund policy, slow replies to buyers, exaggerated claims, or disappearing after the sale.

**Why it happens:** Trust-building is slow and invisible, and its absence is only noticed when sales stop.

**The cost:** The stream depends entirely on trust, especially for a new seller with no reviews. Lose it once, and the marketplace reviews and word of mouth make it very hard to recover.

**How to avoid it:** Be specific about what the product contains, honour your guarantee promptly, reply within a day, and never claim a result you cannot stand behind. Trust is the cheapest marketing you will ever do, and the most expensive thing to rebuild.

### 9.11 Exercise — Module 9

1. Read the nine patterns and mark the three you are most likely to fall into. Write one sentence for each explaining why.
2. For each of those three, write the specific action you will take when you catch yourself doing it — for example, "When I want to switch models, I will re-read my Module 2 decision and add the new idea to the later list."
3. Keep this page with your launch plan. Re-read it at the end of launch week.

---

## Module 10: Your 90-Day Launch Plan

### 10.1 How to use this module

This module turns the previous nine into a dated plan. It assumes five to ten hours a week. If you have five hours, stretch the build phase by two weeks and shorten nothing else. If you have ten, keep the same dates and use the extra time for more validation conversations, which are the highest-value hours in the whole plan.

The plan is also provided as a standalone template (90-day-launch-plan.md) so you can print it, fill in your dates, and check off each week. The dates below are relative — Day 1 is the day you start — so the plan works whenever you begin.

### 10.2 Days 1–14: Choose and validate

**Week 1 (Days 1–7) — Choose.**

- Day 1: Write down your constraints: hours per week, skills, capital, and what you will stop doing to make the time. Read Module 1.
- Day 2: Score four models in the income-model selector. Write your one-sentence decision and your two rejections. Read Module 2.
- Day 3: Write your one-paragraph customer and problem description.
- Day 4: Find three competing products. Record their prices, contents, and reviewer complaints.
- Days 5–7: List ten people or places where your customers gather. Contact the first five and ask for a short conversation about the problem.

**Week 2 (Days 8–14) — Validate.**

- Days 8–10: Interview the remaining five people. Record the answers in the validation worksheet. Look for the pattern: do at least half describe the same problem?
- Days 11–12: Run one small test — a landing page, a pre-sale offer, a concierge delivery, or a small marketplace listing.
- Days 13–14: Decide go or no-go, in writing. If go, write the MVP scope list (five to seven items) and the one-sentence outcome. If no-go, narrow the idea and repeat the validation week once. Do not start building on a no-go.

**End of Day 14 checkpoint:** You have a chosen model, a named customer, a validated problem, and a written MVP scope. If any of those is missing, do not move on. The plan waits for you.

### 10.3 Days 15–28: Price and prepare

**Week 3 (Days 15–21) — Price.**

- Day 15: List your fixed and variable costs. Complete the pricing worksheet.
- Day 16: Calculate your floor, your value range, and your market range. Choose your price and write the one-paragraph reasoning.
- Day 17: Decide your guarantee and any founding offer, with exact terms and an end date.
- Days 18–21: Build your three-scenario revenue projection. Check that even the steady scenario repays your build time within a year. If it does not, adjust the price, the scope, or the model — now, before building.

**Week 4 (Days 22–28) — Prepare to build.**

- Days 22–23: Gather your tools and materials. Set up the income-and-cost tracker and start recording build hours.
- Days 24–25: Outline the product from the MVP scope list. Decide the order of the parts and what the worked example will show.
- Days 26–28: Write your five standard support answers and set up the delivery path (marketplace listing draft, payment link, or file delivery), ready to test.

**End of Day 28 checkpoint:** You have a price, a guarantee, a projection, a tracker, and a build outline. The product itself is not built yet — and that is correct.

### 10.4 Days 29–56: Build

**Weeks 5–8 (Days 29–56) — Build the MVP.**

- Build the core content first, then the worked example, then the instructions, then test the delivery path yourself. Follow Module 5.
- Work in the time budget from Module 7: roughly five hours a week on core content, one hour on the example and instructions, one hour on testing and the listing, one hour checking the product against your validation notes.
- At the end of week 6, show the product to one test user who is not a friend. Record their three biggest points of confusion and fix them.
- At the end of week 8, the product is complete to the MVP scope list. Do not add items from the version-two list. Freeze the scope.

**End of Day 56 checkpoint:** The product is finished, tested, and ready to sell. The listing is written. The launch checklist is complete. If the product is not finished, extend the build by one week rather than launching an unfinished product — but set a firm new date and keep it.

### 10.5 Days 57–70: Launch

**Weeks 9–10 (Days 57–70) — Launch to your first ten customers.**

- Day 57: Tell the people you interviewed, personally, one by one. Offer the founding price.
- Days 58–60: Tell past clients and the communities where you are a member. Post on your own channels about the problem and the outcome.
- Days 61–63: Keep answering questions the same day. Record the daily numbers: seen, clicked, bought, questions asked.
- Day 64: Mid-launch review. If sales are slow, diagnose using Module 6: reach, click, buy, or product experience — and change one thing.
- Days 65–70: Continue telling people, following up once with those who showed interest but did not buy, and helping the buyers who have the product. Do not discount further to force sales.

**End of Day 70 checkpoint:** You have launched. You have a number of customers, a list of their questions and feedback, and daily numbers for the launch. Whether the number is three or thirty, you have evidence. That is the point of the launch.

### 10.6 Days 71–90: Review, fix, and decide

**Weeks 11–12 (Days 71–84) — Fix and improve.**

- Days 71–73: Read every piece of feedback. Fix the biggest problem in the product. Update the listing with anything you have learned.
- Days 74–77: Ask two or three buyers what they found useful and what confused them, and whether they would recommend the product. Record their answers.
- Days 78–84: Make one improvement to the listing or the product based on the feedback, and add one channel if the launch showed that a channel works — for example, improving the marketplace listing, or starting a short series of posts about the problem.

**Week 13 (Days 85–90) — Decide the next ninety days.**

- Day 85: Calculate your four monthly numbers from Module 8: gross revenue, net income, true profit, and hours per sale.
- Day 86: Write a one-page review: what you built, what you earned, what it cost, what you learned, and what you would do differently.
- Days 87–88: Decide, with evidence, one of three options: **grow** (improve this product and add a channel), **improve** (fix the product and relaunch to a narrower audience), or **pivot** (use what you learned to build a different product for the same audience, or the same product for a different audience). Write the decision and the reason down.
- Days 89–90: Set up the next ninety-day plan from that decision, using this module as the template. Set your maintenance time budget and your monthly review date.

**End of Day 90 checkpoint:** You have a launched product, real customers, honest numbers, and a written decision about what happens next. That is the outcome this course promises — and it is a genuine achievement. Most people who start never reach it, not because they cannot, but because they never finish a first launch. You have finished one.

### 10.7 If you have only five hours a week

Stretch the build phase from four weeks to six, and start the launch in week 11 instead of week 9. Keep the validation and pricing phases at two weeks each — they are the highest-value weeks, and shortening them to save time is a false economy. Your ninety days become roughly a hundred days. That is fine. The plan is a sequence, not a deadline. What matters is that each phase is completed before the next begins.

### 10.8 Exercise — Module 10

1. Fill in the 90-day launch plan template with your real start date and your weekly hours.
2. Write your Day 14, Day 28, Day 56, Day 70, and Day 90 checkpoints on one page and keep it visible while you work.
3. Choose your monthly review date now, and put it in your calendar.

---

## Conclusion: What Happens Next

You now have the full method: understand what passive income really is, choose a model that fits your life, validate demand before you build, price from costs and value, build the smallest complete product, launch it to ten real customers, systematise the maintenance, track the money and the time honestly, avoid the nine failure patterns, and run the whole thing on a ninety-day plan.

None of that is glamorous. None of it promises a particular income. All of it works, in the sense that it gives you a real chance: a chance to build something that earns, to learn from real customers, and to improve from evidence instead of guessing. That is what this course offers, and it is all any honest course can offer.

A final word on expectations. Your first product will probably earn little. Your first launch will probably be smaller than you hoped. Your first ninety days will probably teach you more than they earn you. That is not a sign that you have failed. It is the normal shape of building an income stream from nothing, at five to ten hours a week, with no audience and little capital. The people who eventually earn a meaningful second income are, with few exceptions, the people who finished a first launch, learned from it honestly, and did it again — better, and with more evidence. You have the method. The next step is Day 1.

---

## A Note on Advice and Accuracy

This course is educational material. It is not financial, investment, legal, or tax advice, and it does not recommend any specific investment, product, or course of action for your personal circumstances. Income figures in the worked examples are illustrative scenarios created to demonstrate arithmetic; they are not predictions, guarantees, or typical results. Your results will depend on your effort, your market, your pricing, and timing, and most first products earn little. Tax, tenancy, planning, and consumer rules differ by country and change over time; check the current rules where you live and consider advice from a qualified professional before making decisions that depend on them. No testimonials, earnings claims, or reviews are included in this course, and none should be inferred.
