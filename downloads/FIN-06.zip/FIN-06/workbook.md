# The Passive Income Builder — Companion Workbook

Use this workbook alongside the course text. Print it or copy it into your own notes. Each section matches a module. Fill it in as you work — the workbook is where decisions become written commitments.

---

## 1. My Constraints (Module 1)

**What "passive income" means to me, in one sentence:**


**Hours I can honestly give each week for the next 90 days:** ______

**What I will stop doing to make that time:**


**My first monthly income goal, after costs:** $______

**How many sales a month that means:**
- At $10 a sale: ______
- At $50 a sale: ______
- At $100 a sale: ______

**Which of those feels most achievable, and why:**


**Three income claims I have seen online that now look doubtful, and what information was missing:**
1.
2.
3.

---

## 2. Income-Model Selector (Module 2)

My constraints:

- **Time available:** ______ hours/week
- **Skills I already have:** ______
- **Capital I can afford to lose:** $______
- **People-work I enjoy / do not enjoy:** ______
- **Timeline — do I need money in 3 months, or can I build for a year?** ______

Score each model 1–5 (1 = poor fit, 5 = excellent fit).

| Model | Time fit | Skill fit | Capital fit | Speed to first sale | Enjoyment | Total |
|---|---|---|---|---|---|---|
| A. Digital products | | | | | | |
| B. Rentals-adjacent / property | | | | | | |
| C. Service-to-product | | | | | | |
| D. Content and audience | | | | | | |
| E. Affiliate and referral | | | | | | |
| F. Licensing and royalties | | | | | | |
| G. Small rental / sharing | | | | | | |

**My decision, in one sentence:** "I will build ______ for ______ because ______."

**Model I rejected #1:** ______ — Why: ______

**Model I rejected #2:** ______ — Why: ______

**Five ways my chosen model could fail for me specifically:**
1.
2.
3.
4.
5.

**Three real examples of my chosen model being sold today:**
1. Product: ______ Price: ______ Included: ______ For whom: ______
2. Product: ______ Price: ______ Included: ______ For whom: ______
3. Product: ______ Price: ______ Included: ______ For whom: ______

---

## 3. Demand-Validation Worksheets (Module 3)

### 3a. Customer and problem

**My customer, precisely (one person I can picture):**


**Their specific problem:**


**What they do about it today:**


**What leaving it unsolved costs them:**


### 3b. Interview notes (aim for 10 people)

| # | Person / where found | Problem in their words | What they do today | What a solution would be worth |
|---|---|---|---|---|
| 1 | | | | |
| 2 | | | | |
| 3 | | | | |
| 4 | | | | |
| 5 | | | | |
| 6 | | | | |
| 7 | | | | |
| 8 | | | | |
| 9 | | | | |
| 10 | | | | |

**Pattern I noticed (do at least half describe the same problem?):**


### 3c. Competitor check

| Product | Price | Included | Reviewers praise | Reviewers complain about |
|---|---|---|---|---|
| 1 | | | | |
| 2 | | | | |
| 3 | | | | |

### 3d. Small test

**Test I ran (landing page / pre-sale / concierge / small marketplace listing):**


**Result (views, clicks, emails, payments):**


### 3e. Go / no-go decision

**Evidence checklist:**
- [ ] Spoke to at least 10 matching people
- [ ] At least half describe the same problem
- [ ] Found at least 3 existing products selling in the area
- [ ] A small test produced money, emails, or booked conversations from strangers

**Decision:** GO / NO-GO / CHANGE THE IDEA

**Reason, in writing:**


---

## 4. Pricing Worksheet (Module 4)

**Product:** ______ **Chosen price:** $______

### Costs

**Fixed costs (once):**
| Item | Cost |
|---|---|
| | $ |
| | $ |
| | $ |
| **Total fixed costs** | **$** |

**Variable costs (per sale):**
| Item | Cost |
|---|---|
| Marketplace / platform fee | $ |
| Payment processing | $ |
| Support time (minutes × hourly rate) | $ |
| Other | $ |
| **Total variable cost per sale** | **$** |

**Contribution per sale:** Price − variable cost = $______

**Break-even (cash only):** Fixed costs ÷ contribution = ______ sales

**Build time:** ______ hours × $______/hour = $______

**Break-even (including build time):** (Fixed costs + build time value) ÷ contribution = ______ sales

### Pricing reasoning (one paragraph)

**My floor:** $______ **Value range:** $______–$______ **Market range:** $______–$______

**Why I chose this price:**


### Guarantee and founding offer

**Guarantee:** ______

**Founding offer (if any) and end date:** ______

---

## 5. MVP Scope and Build Notes (Module 5)

**The single outcome my buyer wants:**


**MVP scope — five to seven items maximum:**
1.
2.
3.
4.
5.
6.
7.

**Items saved for version 2:**
1.
2.
3.

**Test user:** ______ **Date tested:** ______

**Three biggest points of confusion they found:**
1.
2.
3.

**Fixes made:**


---

## 6. Launch Checklist (Module 6)

- [ ] Product files finished, tested, and uploaded
- [ ] Full purchase path tested by me, as a buyer
- [ ] Price, guarantee, and refund terms written and visible
- [ ] Short description (2–3 sentences) written
- [ ] Long description (one page) written
- [ ] List of who to tell, in order, written
- [ ] Launch offer and end date decided
- [ ] Time set aside daily in launch week for questions and support

**Who to tell, in order:**
1. People I interviewed (personal message each):
2. Past clients / customers:
3. Communities where I am a member:
4. My own channels:
5. Marketplace listing (title, description, keywords checked):

**Personal message to interviewees (draft):**


**Short post for my own channels (draft):**


### Launch week daily log

| Day | Seen | Clicked | Bought | Questions asked |
|---|---|---|---|---|
| 1 | | | | |
| 2 | | | | |
| 3 | | | | |
| 4 | | | | |
| 5 | | | | |
| 6 | | | | |
| 7 | | | | |

**Mid-launch diagnosis (Day 4):** Reach / Click / Buy / Product experience — the problem is: ______

**One change I made:** ______

**Customers at end of launch:** ______ **Target was 10.**

---

## 7. Income-and-Cost Tracker (Module 8)

Record every sale and cost in the week it happens. Record the net amount received, not the headline price.

### Sales

| Date | Product | Price | Fees | Net received |
|---|---|---|---|---|
| | | $ | $ | $ |
| | | $ | $ | $ |
| | | $ | $ | $ |
| | | $ | $ | $ |
| | | $ | $ | $ |

### Costs

| Date | Item | Amount |
|---|---|---|
| | | $ |
| | | $ |
| | | $ |
| | | $ |
| | | $ |

### Time

| Week | Build | Launch | Support | Maintenance | Total hours |
|---|---|---|---|---|---|
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |

### Monthly review — four numbers

| Month | Gross revenue | Net income | True profit (after time) | Hours per sale |
|---|---|---|---|---|
| | $ | $ | $ | |
| | $ | $ | $ | |
| | $ | $ | $ | |
| | $ | $ | $ | |
| | $ | $ | $ | |
| | $ | $ | $ | |

**Trend I notice:**


---

## 8. My Three-Scenario Projection (Module 8)

Copy the method from the worked example in Module 8, using your own price, costs, and hours.

| Scenario | Sales in 3 months | Gross revenue | Fees and support | Cash profit | True profit (after build time) |
|---|---|---|---|---|---|
| Slow | | $ | $ | $ | $ |
| Steady | | $ | $ | $ | $ |
| Strong | | $ | $ | $ | $ |

**What I conclude from this:**


---

## 9. Failure Patterns — My Watch List (Module 9)

**The three patterns I am most likely to fall into:**
1. ______ — Why: ______ — What I will do when I catch it: ______
2. ______ — Why: ______ — What I will do when I catch it: ______
3. ______ — Why: ______ — What I will do when I catch it: ______

---

## 10. 90-Day Launch Plan (Module 10)

**My start date (Day 1):** ______ **Hours per week:** ______

| Phase | Dates | Done? |
|---|---|---|
| Days 1–14: Choose and validate | | ☐ |
| Days 15–28: Price and prepare | | ☐ |
| Days 29–56: Build the MVP | | ☐ |
| Days 57–70: Launch to first 10 | | ☐ |
| Days 71–90: Review, fix, decide | | ☐ |

**Checkpoint dates:**
- Day 14: ______ ☐
- Day 28: ______ ☐
- Day 56: ______ ☐
- Day 70: ______ ☐
- Day 90: ______ ☐

**Monthly review date:** ______

**End-of-90-days decision:** GROW / IMPROVE / PIVOT

**Reason:**


---

## 11. Weekly Review Template

Use once a week during the build and launch, and once a month afterwards.

**Week of:** ______

**What I did this week:**


**What I learned:**


**Numbers this week (sales, costs, hours):**


**What I will keep doing:**


**What I will stop doing:**


**The one change most likely to help next week:**


**Next week's top three tasks:**
1.
2.
3.
