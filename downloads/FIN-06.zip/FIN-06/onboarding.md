# Customer Onboarding — The Passive Income Builder (FIN-06)

Welcome. You have just bought a complete course for building your first income stream in 90 days. This guide tells you what to do first, how to use the materials, and how to get help.

## What you received

Your download contains:

| File | What it is |
|---|---|
| `content.md` | The complete course text — 10 modules, in full. Read it at your own pace and follow the course from this text alone. |
| `workbook.md` | The companion workbook — every worksheet from the course in one place, ready to print or copy into your notes. |
| `templates/pricing-calculator.csv` | Pricing calculator — cost, price, units, revenue, and profit, with example numbers. Open it in any spreadsheet application. |
| `templates/income-model-selector.md` | Income-model selector — score each model against your time, skills, and capital. |
| `templates/validation-worksheet.md` | Demand-validation worksheet — interview notes, competitor check, small-test record, and go / no-go decision. |
| `templates/90-day-launch-plan.md` | 90-day launch plan — the full plan as a printable checklist with dates and checkpoints. |
| `sales-page.md` | The sales page copy, kept here for your reference. |
| `cover.md` / `cover.webp` | The cover design brief and the cover image. |
| `listing.json` | The marketplace listing data for this product. |
| `README.md` | Index of the files in this product. |

If any file is missing or will not open, contact support with your order number (see "How to get support" below) and it will be re-sent.

## What to do first (Day 1)

1. **Read the Introduction and Module 1** in `content.md` (about 30–45 minutes). It sets the honest expectations the rest of the course depends on: what passive income really is, what it is not, and what a realistic timeline looks like.
2. **Write down your constraints** in Section 1 of the workbook: how many hours a week you can honestly give for the next 90 days, what you will stop doing to make that time, and your first monthly income goal after costs.
3. **Do not skip ahead to building.** Modules 1–4 are thinking work, and they come first for a reason. The most expensive mistake in this field is building something nobody wants, and the validation work in Module 3 exists to prevent it.
4. **Set your start date** in the 90-day launch plan template and write your checkpoint dates (Day 14, Day 28, Day 56, Day 70, Day 90) where you will see them.

## How to use the materials

- **Work through the modules in order the first time.** Each module builds on the one before it. Do the exercise at the end of each module before moving on — the exercises are where the learning becomes a decision.
- **Use the workbook as you go.** Each workbook section matches a module. Fill it in as you work rather than all at once at the end; a half-filled workbook from a real week of work is worth more than a blank one.
- **Use the templates as working documents.** The pricing calculator is meant to be edited with your own numbers. The validation worksheet is meant to hold real interview notes. The 90-day plan is meant to be printed and checked off.
- **How to use the text.** Read a module, then do the matching workbook exercises before moving on — whichever order suits how you learn.

## Suggested schedule

The course is designed for 5–10 hours a week over 90 days:

| Phase | Days | What happens |
|---|---|---|
| Choose and validate | 1–14 | Choose a model, describe your customer, interview 10 people, run one small test, decide go or no-go. |
| Price and prepare | 15–28 | Price from costs and value, build a three-scenario projection, set up your tracker. |
| Build | 29–56 | Build the minimum viable product, test it with one user, test the delivery path. |
| Launch | 57–70 | Launch to your first 10 customers, answer questions daily, record the numbers. |
| Review, fix, decide | 71–90 | Fix the biggest problem, ask buyers what they thought, calculate your four monthly numbers, and decide: grow, improve, or pivot. |

If you have five hours a week, stretch the build phase by two weeks and start the launch in week 11. The plan is a sequence, not a deadline — finish each phase before starting the next.

## A note on expectations

Most first products earn little in their first 90 days. That is normal, not failure. The purpose of the first 90 days is proof: proof that someone will pay, proof that you can deliver, and proof that you know what to improve next. Judge your first launch on what you learned, not only on what you earned.

## How to get support

- **Order or download problems:** email the marketplace support address with your order number and a description of the issue, and the support team will respond.
- **Refund requests:** this product carries a 14-day money-back guarantee. If you are not satisfied within 14 days of purchase, contact support with your order number for a full refund, no questions asked.
- **Questions about the course content:** re-read the matching module first — most questions are answered there, especially in the worked examples. If something is still unclear, contact support with the module number and your question.

## A note on advice

This course is educational material only. It is not financial, investment, legal, or tax advice, and it does not recommend any specific investment or course of action for your personal circumstances. Income figures in the worked examples are illustrative scenarios, not predictions or guarantees. Tax, tenancy, and consumer rules differ by country and change over time — check the current rules where you live and consider advice from a qualified professional before making decisions that depend on them.
