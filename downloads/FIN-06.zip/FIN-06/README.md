# The Passive Income Builder (FIN-06)

**Price:** $497 (one-time) · **Category:** Finance & Wealth Building · **Format:** Video course (10 modules, 9 hours) + workbook + templates

**Headline:** Build your first income stream — choose a model, validate it, and launch in 90 days.

## Files

| File | Contents |
|---|---|
| `content.md` | Full course text — 10 modules in complete prose (16,077 words), with worked examples using real numbers. |
| `workbook.md` | Companion workbook — income-model selector, demand-validation worksheets, pricing worksheet, 90-day launch plan, launch checklist, income-and-cost tracker, weekly review template. |
| `templates/pricing-calculator.csv` | Pricing calculator — cost, price, units, revenue, profit, break-even, and a three-scenario projection, with example numbers. |
| `templates/income-model-selector.md` | Income-model selector — score seven model families against your time, skills, and capital. |
| `templates/validation-worksheet.md` | Demand-validation worksheet — interview notes, competitor check, small-test record, go / no-go decision. |
| `templates/90-day-launch-plan.md` | 90-day launch plan — the full plan as a printable checklist with dates and checkpoints. |
| `sales-page.md` | Full sales page — headline, problem, solution, module list, who it is for / not for, price, guarantee, 10 FAQs, disclaimers. |
| `listing.json` | Marketplace listing data (SKU FIN-06, price_cents 49700, billing one_time). |
| `cover.md` | Cover design brief — black-and-gold luxury palette, typography, imagery direction, layout. |
| `cover.webp` | Cover image, generated to the brief. |
| `onboarding.md` | Customer onboarding guide — what to do first, how to use the materials, suggested schedule, how to get support. |

## The course in brief

1. What passive income really is (and what it is not)
2. Choosing a model that fits your time, skills, and capital
3. Validating demand before you build
4. Pricing your first product
5. Building a minimum viable product
6. Launching to your first 10 customers
7. Systems and automation that actually save time
8. Tracking income and costs
9. Common failure patterns and how to avoid them
10. Your 90-day launch plan

Education only — not financial, investment, legal, or tax advice. No guaranteed returns or income claims. 14-day money-back guarantee.
