# Demand-Validation Worksheet

Use this template with Module 3 of the course. Do not build until this worksheet is complete and the go / no-go decision is written down.

## 1. Customer and problem

**My customer, precisely (one person I can picture):**


**Their specific problem:**


**What they do about it today:**


**What leaving it unsolved costs them (money, time, stress):**


## 2. Interviews (aim for 10)

Ask about the problem, not about your product. Good questions: "How do you handle this today?" "What is the most annoying part?" "What have you tried?" "What would a good solution be worth to you?" Do not ask: "Would you buy my product?" or "Do you like my idea?"

| # | Person / where found | Problem in their words | What they do today | What they have tried | What a solution would be worth |
|---|---|---|---|---|---|
| 1 | | | | | |
| 2 | | | | | |
| 3 | | | | | |
| 4 | | | | | |
| 5 | | | | | |
| 6 | | | | | |
| 7 | | | | | |
| 8 | | | | | |
| 9 | | | | | |
| 10 | | | | | |

**Pattern I noticed:**


**Do at least half describe the same problem in similar words?** Yes / No

## 3. Competitor check

Competition is evidence of demand. Find 3–5 existing products. Read the three-star reviews — they say what the product does well and what it misses.

| Product | Price | What is included | Reviewers praise | Reviewers complain about | My opening |
|---|---|---|---|---|---|
| 1 | | | | | |
| 2 | | | | | |
| 3 | | | | | |
| 4 | | | | | |
| 5 | | | | | |

## 4. Small test

Choose one: landing page / pre-sale / concierge delivery / small marketplace listing.

**Test I ran:**


**Where I shared it:**


**Result (views, clicks, email addresses, payments):**


## 5. What counts as validation

Counts: a stranger pays or pays a deposit; a stranger gives an email address for a specific promise and replies; a stranger spends time describing the problem in detail; a stranger pre-orders or books a call to discuss buying; several existing products selling steadily in the area.

Does not count: friends and family saying it sounds great; likes and positive comments; poll answers about what people *would* buy; a large number of search results; your own certainty.

## 6. Go / no-go decision

- [ ] Spoke to at least 10 matching people
- [ ] At least half describe the same problem
- [ ] Found at least 3 existing products selling in the area
- [ ] A small test produced money, email addresses, or booked conversations from strangers

**Decision:** GO / NO-GO / CHANGE THE IDEA

**Reason, in writing:**


**If changing the idea, what changes (narrower audience, different problem, different model)?**


**What the validation taught me about the product (words customers used, workarounds they described, price they hesitated at):**

