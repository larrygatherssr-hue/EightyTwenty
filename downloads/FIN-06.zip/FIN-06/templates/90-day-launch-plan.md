# 90-Day Launch Plan

Use this template with Module 10 of the course. Day 1 is the day you start. Fill in your real dates. Check off each week as you finish it — do not move to the next phase until the checkpoint for this one is met.

**My start date (Day 1):** ______

**Hours I can give each week:** ______

**My chosen model:** ______

**My customer:** ______

**My product (one sentence):** ______

---

## Days 1–14: Choose and validate

### Week 1 — Choose

| Day | Task | Done? |
|---|---|---|
| 1 | Write down constraints: hours, skills, capital, what I will stop doing. Read Module 1. | ☐ |
| 2 | Score four models in the income-model selector. Write my one-sentence decision and two rejections. Read Module 2. | ☐ |
| 3 | Write my one-paragraph customer and problem description. | ☐ |
| 4 | Find three competing products. Record prices, contents, reviewer complaints. | ☐ |
| 5–7 | List ten people or places where my customers gather. Contact the first five for a short conversation. | ☐ |

### Week 2 — Validate

| Day | Task | Done? |
|---|---|---|
| 8–10 | Interview the remaining five people. Record answers in the validation worksheet. | ☐ |
| 11–12 | Run one small test: landing page, pre-sale, concierge delivery, or small marketplace listing. | ☐ |
| 13–14 | Decide go or no-go, in writing. If go, write the MVP scope list (5–7 items) and the one-sentence outcome. | ☐ |

**Day 14 checkpoint:** I have a chosen model, a named customer, a validated problem, and a written MVP scope. ☐

*If any of those is missing, do not move on. Repeat the validation week once with a narrower idea.*

---

## Days 15–28: Price and prepare

### Week 3 — Price

| Day | Task | Done? |
|---|---|---|
| 15 | List fixed and variable costs. Complete the pricing worksheet. | ☐ |
| 16 | Calculate floor, value range, market range. Choose price; write one-paragraph reasoning. | ☐ |
| 17 | Decide guarantee and any founding offer, with exact terms and end date. | ☐ |
| 18–21 | Build my three-scenario revenue projection. Check the steady scenario repays build time within a year. | ☐ |

### Week 4 — Prepare to build

| Day | Task | Done? |
|---|---|---|
| 22–23 | Gather tools and materials. Set up the income-and-cost tracker; start recording build hours. | ☐ |
| 24–25 | Outline the product from the MVP scope list. Decide the worked example. | ☐ |
| 26–28 | Write five standard support answers. Set up the delivery path, ready to test. | ☐ |

**Day 28 checkpoint:** I have a price, a guarantee, a projection, a tracker, and a build outline. ☐

---

## Days 29–56: Build the MVP

### Weeks 5–8 — Build

| Week | Task | Done? |
|---|---|---|
| 5 | Build the core content. | ☐ |
| 6 | Build the worked example and instructions. Show the product to one test user; record their three biggest points of confusion. | ☐ |
| 7 | Fix the confusion points. Test the delivery path as a buyer. Write the listing. | ☐ |
| 8 | Finish to the MVP scope list. Freeze the scope — version-two items wait. Complete the launch checklist. | ☐ |

**Day 56 checkpoint:** The product is finished, tested, and ready to sell. The listing is written. ☐

*If the product is not finished, extend the build by one week with a firm new date — do not launch an unfinished product.*

---

## Days 57–70: Launch

### Weeks 9–10 — Launch to the first 10 customers

| Day | Task | Done? |
|---|---|---|
| 57 | Tell the people I interviewed, personally, one by one. Offer the founding price. | ☐ |
| 58–60 | Tell past clients and the communities where I am a member. Post on my own channels about the problem and the outcome. | ☐ |
| 61–63 | Answer questions the same day. Record daily numbers: seen, clicked, bought, questions asked. | ☐ |
| 64 | Mid-launch review. Diagnose slow sales: reach, click, buy, or product experience. Change one thing. | ☐ |
| 65–70 | Keep telling people. Follow up once with those who showed interest. Help buyers who have the product. | ☐ |

**Day 70 checkpoint:** I have launched. I have a customer count, their questions and feedback, and daily launch numbers. ☐

**Customers at end of launch:** ______ (target: 10)

---

## Days 71–90: Review, fix, and decide

### Weeks 11–12 — Fix and improve

| Day | Task | Done? |
|---|---|---|
| 71–73 | Read every piece of feedback. Fix the biggest problem in the product. Update the listing. | ☐ |
| 74–77 | Ask 2–3 buyers what was useful, what confused them, and whether they would recommend it. | ☐ |
| 78–84 | Make one improvement based on feedback. Add one channel if the launch showed one works. | ☐ |

### Week 13 — Decide the next 90 days

| Day | Task | Done? |
|---|---|---|
| 85 | Calculate the four monthly numbers: gross revenue, net income, true profit, hours per sale. | ☐ |
| 86 | Write a one-page review: what I built, earned, spent, learned, and would do differently. | ☐ |
| 87–88 | Decide: GROW / IMPROVE / PIVOT. Write the decision and the reason. | ☐ |
| 89–90 | Set up the next 90-day plan from that decision. Set the maintenance time budget and monthly review date. | ☐ |

**Day 90 checkpoint:** I have a launched product, real customers, honest numbers, and a written decision about what happens next. ☐

**My decision:** GROW / IMPROVE / PIVOT

**Reason:**


**Monthly review date:** ______

---

## If I have only 5 hours a week

Stretch the build phase from four weeks to six and start the launch in week 11 instead of week 9. Keep validation and pricing at two weeks each. The plan is a sequence, not a deadline — each phase must be completed before the next begins.
