# Income-Model Selector

Use this template with Module 2 of the course. Score each model honestly against your own constraints — not against how good the model sounds in general.

## My constraints

- **Hours I can give each week, every week, for 90 days:** ______
- **Skills I already have that someone would pay for:** ______
- **Things I am willing to learn in 90 days:** ______
- **Things I will not learn in 90 days:** ______
- **Capital I can afford to lose entirely:** $______
- **People-work I enjoy:** ______
- **People-work I do not enjoy:** ______
- **Do I need money in 3 months, or can I build for a year?** ______

## Scoring

Score each model 1–5 on each question (1 = poor fit, 5 = excellent fit). Add the total.

| Model | Time fit: can I build this in my hours within 90 days? | Skill fit: can I do the core work well already? | Capital fit: can I afford the startup cost? | Speed to first sale | Enjoyment: will I still want the maintenance work in 6 months? | Total |
|---|---|---|---|---|---|---|
| A. Digital products | | | | | | |
| B. Rentals-adjacent / property | | | | | | |
| C. Service-to-product | | | | | | |
| D. Content and audience | | | | | | |
| E. Affiliate and referral | | | | | | |
| F. Licensing and royalties | | | | | | |
| G. Small rental / sharing | | | | | | |

## The models at a glance

- **A. Digital products** — make once, sell copies. Low cash cost, slow first sales, low maintenance.
- **B. Rentals-adjacent / property** — income connected to property. High capital or local knowledge needed for direct models; not a first project unless you already understand property.
- **C. Service-to-product** — package a service you already deliver. Often the fastest to first revenue.
- **D. Content and audience** — blog, video, newsletter. Slow: usually 6–12 months before meaningful income. Pairs well with a product.
- **E. Affiliate and referral** — commissions for recommending products. Needs a trusted audience; close to $0 without one.
- **F. Licensing and royalties** — photos, music, designs, writing licensed for reuse. Slow; a catalogue earns more than a single item.
- **G. Small rental / sharing** — rent out an asset you own. Check insurance first; factor in wear.

## My decision

**I will build:** ______

**For (audience):** ______

**Because (tied to my constraints):** ______

**Model I rejected #1:** ______ — Why: ______

**Model I rejected #2:** ______ — Why: ______

## Watch out

Choose the model with the best *balanced* score, not the highest single score. A model that scores 5 on opportunity and 1 on enjoyment will fail in month four. Keep this page: when a new model looks tempting mid-build, re-read it before switching.
