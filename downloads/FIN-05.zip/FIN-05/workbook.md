# Retire on Purpose — Workbook

## How to Use This Workbook

This workbook turns the course into your numbers. Work through it in order, alongside the course modules. Every worksheet asks for your figures, not the example household's. Bring the completed workbook to your professional review in Month 11 of the implementation plan.

**Disclaimer: This workbook is general education, not individualized retirement, tax, or investment advice.** The worksheets help you organize your own information so you can make better decisions and have a more productive conversation with a qualified professional. All projections are illustrative and depend on your assumptions. Actual results will vary. Consult a qualified financial planner, tax professional, or attorney for advice about your specific situation.

---

## Worksheet 1: Retirement Income Gap

*Course reference: Module 1. Complete this first — everything else depends on it.*

**A. Your monthly spending in retirement (before income tax)**

| Category | Current monthly | Retirement monthly | Notes |
|---|---|---|---|
| Housing (mortgage/rent, taxes, insurance, maintenance) | $_____ | $_____ | |
| Food and household | $_____ | $_____ | |
| Utilities and phone | $_____ | $_____ | |
| Insurance (auto, home, umbrella) | $_____ | $_____ | |
| Transportation | $_____ | $_____ | |
| Health care (premiums + out-of-pocket) | $_____ | $_____ | See Worksheet 4 |
| Clothing and personal | $_____ | $_____ | |
| Travel and entertainment | $_____ | $_____ | |
| Gifts and family | $_____ | $_____ | |
| Hobbies | $_____ | $_____ | |
| Other | $_____ | $_____ | |
| **Total monthly spending** | **$_____** | **$_____** | |

**B. Your guaranteed income (at your planned retirement age)**

| Source | Monthly | Annual | Start date |
|---|---|---|---|
| Social Security (you) | $_____ | $_____ | Age _____ |
| Social Security (spouse) | $_____ | $_____ | Age _____ |
| Pension | $_____ | $_____ | Age _____ |
| Annuity income already owned | $_____ | $_____ | Age _____ |
| Other guaranteed income | $_____ | $_____ | |
| **Total guaranteed income** | **$_____** | **$_____** | |

**C. The gap**

- Annual spending need (retirement monthly total × 12): $_____
- Plus estimated annual income tax in retirement: $_____
- Gross annual income need (A + B): $_____
- Less annual guaranteed income: $_____
- **Annual income gap (the portfolio's job): $_____**
- Total portfolio value: $_____
- **Gap as a percentage of portfolio: _____%**

**How to read your result:** Under 4% — your portfolio can likely fund the gap at a conventional withdrawal rate. 4–5% — workable, but your plan needs care and a margin for bad markets. 5–7% — you need one or more levers: work longer, spend less, or delay Social Security. Over 7% — your plan needs several levers, and a professional review is important before you retire.

**Action:** Write your gap percentage here: _____% . Write one lever you will pull first: ______________________________.

---

## Worksheet 2: Social Security Timing

*Course reference: Module 3. Get your estimates at ssa.gov before completing this.*

**Your benefit estimates (from ssa.gov)**

| Claiming age | Your monthly benefit | Spouse's monthly benefit | Combined monthly | Combined annual |
|---|---|---|---|---|
| 62 | $_____ | $_____ | $_____ | $_____ |
| 67 (full retirement age) | $_____ | $_____ | $_____ | $_____ |
| 70 | $_____ | $_____ | $_____ | $_____ |

**Cumulative benefits (illustrative — assumes benefits stay constant in real terms and ignores cost-of-living adjustments)**

| Scenario | Total received by age 80 | Total received by age 85 | Total received by age 90 |
|---|---|---|---|
| Both claim at 62 | $_____ | $_____ | $_____ |
| Both claim at 67 | $_____ | $_____ | $_____ |
| Both claim at 70 | $_____ | $_____ | $_____ |

**Survivor check (the most important row in this workbook)**

- Higher earner: __________________. Their benefit at 62: $_____. At 67: $_____. At 70: $_____.
- If the higher earner claims at 62 and dies first, the survivor receives: $_____ per month.
- If the higher earner claims at 70 and dies first, the survivor receives: $_____ per month.
- Difference: $_____ per month, or $_____ per year, for the rest of the survivor's life.

**Health and longevity notes**

- My health today: ______________________________.
- My parents' ages at death (or current ages): ______________________________.
- My spouse's health today: ______________________________.

**My provisional claiming age:** _____ . **Reason:** ______________________________.

---

## Worksheet 3: Withdrawal-Sequence Planner

*Course reference: Modules 6 and 7. Complete one row per year from retirement to age 73, then summarize the RMD years.*

**Bridge years (retirement to age 73)**

| Age | Spending need | Guaranteed income | Portfolio gap | From taxable | From traditional | From Roth | Roth conversion | Taxable income | Marginal bracket |
|---|---|---|---|---|---|---|---|---|---|
| _____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | _____% |
| _____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | _____% |
| _____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | _____% |
| _____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | _____% |
| _____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | _____% |

**RMD years (age 73 onward) — summary**

| Item | Amount |
|---|---|
| Projected traditional balance at RMD age | $_____ |
| First-year RMD (balance ÷ 26.5, approximately) | $_____ |
| Social Security at that age (annual) | $_____ |
| Estimated total taxable income at 73 | $_____ |
| Estimated marginal bracket at 73 | _____% |

**Checks**

- Is my marginal bracket at 73 higher than in my bridge years? Yes / No. If yes, consider larger Roth conversions in the bridge years.
- Am I converting up to the top of my current bracket without crossing into the next one? Yes / No.
- Can I pay conversion tax from outside the IRA? Yes / No.
- Have I checked the IRMAA thresholds for the year I turn 65? Yes / No.

A full year-by-year version of this planner, with worked example rows, is in `templates/withdrawal-sequence-planner.md`.

---

## Worksheet 4: Healthcare Cost Estimator

*Course reference: Module 9. Prices are illustrative starting points — verify current premiums for your ZIP code and plans.*

**Monthly premiums (per person, then household total)**

| Item | You | Spouse | Household |
|---|---|---|---|
| Medicare Part B | $_____ | $_____ | $_____ |
| Medigap Plan G (or Advantage premium) | $_____ | $_____ | $_____ |
| Medicare Part D | $_____ | $_____ | $_____ |
| Dental / vision | $_____ | $_____ | $_____ |
| **Total monthly premiums** | | | **$_____** |

**Annual out-of-pocket costs**

| Item | Annual estimate |
|---|---|
| Part B deductible | $_____ |
| Part D deductible and copays | $_____ |
| Dental and vision care not covered | $_____ |
| Prescriptions not covered by Part D | $_____ |
| Hearing aids, glasses, other | $_____ |
| **Total annual out-of-pocket** | **$_____** |

**Total annual health-care budget:** (monthly premiums × 12) + annual out-of-pocket = **$_____**.

**Long-term care check**

- Cost of assisted living in my area (monthly): $_____.
- Cost of a nursing home room in my area (monthly): $_____.
- Cost of home health aide care in my area (hourly): $_____.
- Long-term care insurance quote (annual premium): $_____.
- My decision: buy / self-insure / hybrid policy / decide later — with reason: ______________________________.

---

## Worksheet 5: Annual Review Checklist

*Course reference: Module 11. Photocopy this page and use it every year on your review date.*

**Review date:** _______________ **Review year:** _______

- [ ] **Spending check.** Last year's actual spending: $_____. Budget: $_____. Difference: $_____. Explanation: ______________________________.
- [ ] **Income check.** All income sources arrived as expected? Yes / No. Changes: ______________________________.
- [ ] **Portfolio check.** Portfolio value at start of year: $_____. Total withdrawals for spending: $_____. Withdrawal rate: _____%. Within guardrails? Yes / No. Action if not: ______________________________.
- [ ] **Allocation check.** Current stock/bond mix: _____% / _____%. Target: _____% / _____%. Rebalance needed? Yes / No.
- [ ] **Tax check.** Last year's taxable income: $_____. Marginal bracket: _____%. Roth conversion done this year? Yes / No / Amount $_____.
- [ ] **RMD check.** RMD due this year: $_____. Taken? Yes / No. Date taken: _______________.
- [ ] **IRMAA check.** MAGI two years ago: $_____. Above a threshold? Yes / No.
- [ ] **Beneficiary check.** All beneficiary designations reviewed and current? Yes / No. Changes made: ______________________________.
- [ ] **Documents check.** Will, power of attorney, health care proxy, living will all current? Yes / No.
- [ ] **Life check.** What changed this year? ______________________________.
- [ ] **One change for next year:** ______________________________.
- [ ] **Next review date set:** _______________.

---

*End of workbook. Remember: this workbook is general education, not individualized retirement, tax, or investment advice. Consult a qualified professional for advice about your specific situation.*
