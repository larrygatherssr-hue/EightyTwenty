# Retire on Purpose: The Retirement Planning Masterclass — FIN-05

**Price:** $497 (one-time) · **Category:** Finance & Wealth Building · **Tier:** Professional

A retirement planning education course for pre-retirees aged 45–62 with $100k–$1M in savings who need an income plan, not just a balance.

## Files

| File | What it is |
|---|---|
| `content.md` | The full 12-module course text (~14,900 words): the income gap, 401(k)/IRA decisions, Social Security timing, pensions and annuities, the income floor, withdrawal sequencing, tax-aware withdrawals and Roth conversions, RMDs, health care and Medicare, long-term care, the annual review system, and the 12-month implementation plan. Worked examples throughout, with stated assumptions. |
| `workbook.md` | Companion workbook (~1,570 words) with five worksheets: retirement income gap, Social Security timing, withdrawal-sequence planner, health-care cost estimator, and annual review checklist. |
| `templates/retirement-income-calculator.csv` | Spreadsheet: income floor, portfolio draw, monthly income plan, and sensitivity scenarios, with worked example rows. |
| `templates/social-security-timing-worksheet.md` | Claiming-age comparison (62/67/70), cumulative benefit tables, break-even analysis, and survivor check. |
| `templates/withdrawal-sequence-planner.md` | Year-by-year planner for the bridge years and the RMD years, with worked examples and pre-finalization checks. |
| `sales-page.md` | Sales page (~1,400 words): headline, problem, solution, module list, who it is for / not for, $497 price with 14-day guarantee, FAQ, and disclaimers. |
| `listing.json` | Marketplace listing data: SKU FIN-05, price_cents 49700, billing one_time, headline, description, delivery note, SEO keywords, refund policy, support. |
| `cover.md` | Cover design brief (black-and-gold luxury branding, matching the marketplace house style). |
| `cover.png` | Generated premium cover image. |
| `onboarding.md` | Getting-started guide: what to do first, how to use the materials, suggested 8-week schedule, how to get support. |

## Notes

- All content is original. No testimonials, sales figures, certifications, or reviews are claimed anywhere.
- Finance content is education only: disclaimers appear in content.md, workbook.md, and sales-page.md stating this is general education, not individualized retirement, tax, or investment advice. All projections state their assumptions; no returns are guaranteed; Social Security figures are illustrative examples, not promises of any individual's benefit.
