# Withdrawal-Sequence Planner

## How to Use This Planner

This planner maps, year by year, where your retirement spending comes from: taxable accounts, traditional (pre-tax) accounts, or Roth accounts. The order matters because each account type is taxed differently, and the sequence determines your tax bill, your future required minimum distributions (RMDs), and what you leave to heirs.

**The example household** is Maria and James from the course: both retire at 65, both delay Social Security to 70, $500,000 saved ($320,000 traditional 401(k), $110,000 traditional IRA, $45,000 Roth IRA, $25,000 taxable). Spending need: $76,200 a year before tax. **Replace every example figure with your own.**

**Assumptions used in the example (stated explicitly):** standard deduction about $30,000 for married filing jointly (2025 figure); 10% bracket up to about $23,850 of taxable income and 12% bracket up to about $96,950 (2025 figures); 5% average annual portfolio growth (illustrative, not guaranteed); RMD divisor of 26.5 at age 73 (IRS Uniform Lifetime Table). Verify current tax figures and RMD tables before acting. This planner is general education, not individualized retirement, tax, or investment advice.

---

## Part 1: The Bridge Years (Retirement to Social Security)

The bridge years — between retirement and claiming Social Security — are usually your lowest-tax years. That makes them the best years to withdraw from traditional accounts and to do Roth conversions. The example below follows the course plan: $55,000 a year withdrawn from traditional accounts for spending, plus a $30,000 Roth conversion each year, with the rest of spending from taxable and Roth money.

| Age | Spending need | Social Security | Portfolio gap | From taxable | From traditional (spending) | From Roth (spending) | Roth conversion | Taxable income | Marginal bracket |
|---|---|---|---|---|---|---|---|---|---|
| 65 | $76,200 | $0 | $76,200 | $15,000 | $55,000 | $6,200 | $30,000 | $55,000* | 12% |
| 66 | $76,200 | $0 | $76,200 | $10,000 | $55,000 | $11,200 | $30,000 | $55,000* | 12% |
| 67 | $76,200 | $0 | $76,200 | $0 | $55,000 | $21,200 | $30,000 | $55,000* | 12% |
| 68 | $76,200 | $0 | $76,200 | $0 | $55,000 | $21,200 | $30,000 | $55,000* | 12% |
| 69 | $76,200 | $0 | $76,200 | $0 | $55,000 | $21,200 | $30,000 | $55,000* | 12% |

\*Taxable income shown here is the $55,000 traditional withdrawal plus the $30,000 Roth conversion ($85,000 total traditional-account movement) minus the $30,000 standard deduction = $55,000. Federal tax on $55,000 of taxable income is roughly $6,100, an effective rate of about 7% on the $85,000 moved. Check your own figures against the current brackets.

**Notes on the example bridge years:**
- The taxable account ($25,000) is spent down first, in years 65–66, because it is the most flexible money and spending it early lets tax-deferred accounts keep growing.
- The Roth IRA is used sparingly in the bridge years — it is the most valuable money you own (tax-free forever, no RMDs), so it is spent last.
- The $30,000 annual conversion moves $150,000 into the Roth over five years at an average rate under 10%, shrinking the traditional balance that will generate RMDs at 73.
- The conversion tax is paid from cash, not from the converted funds.

**Your bridge years** — copy the table above and fill in your own figures:

| Age | Spending need | Social Security | Portfolio gap | From taxable | From traditional (spending) | From Roth (spending) | Roth conversion | Taxable income | Marginal bracket |
|---|---|---|---|---|---|---|---|---|---|
| _____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | _____% |
| _____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | _____% |
| _____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | _____% |
| _____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | _____% |
| _____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | _____% |

## Part 2: The Steady-State Years (Social Security Onward)

Once Social Security starts, the portfolio's job shrinks — but RMDs begin at 73 and can push you into a higher bracket. The example below assumes the bridge-year plan above was followed: traditional balance at 73 is about $280,000 (illustrative, after withdrawals, conversions, and 5% growth).

| Age | Spending need | Social Security | Portfolio gap | RMD due | From traditional | From Roth | Taxable income | Marginal bracket |
|---|---|---|---|---|---|---|---|---|
| 70 | $76,200 | $62,496 | $13,704 | $0 | $13,704 | $0 | ~$13,700 | 10% |
| 71 | $76,200 | $62,496 | $13,704 | $0 | $13,704 | $0 | ~$13,700 | 10% |
| 72 | $76,200 | $62,496 | $13,704 | $0 | $13,704 | $0 | ~$13,700 | 10% |
| 73 | $76,200 | $62,496 | $13,704 | ~$10,600 | $13,704 | $0 | ~$24,300 | 12% |
| 75 | $76,200 | $62,496 | $13,704 | ~$11,500 | $13,704 | $0 | ~$25,200 | 12% |
| 80 | $76,200 | $62,496 | $13,704 | ~$15,000 | $15,000 | $0 | ~$28,700 | 12% |
| 85 | $76,200 | $62,496 | $13,704 | ~$19,000 | $19,000 | $0 | ~$32,700 | 12% |

**Compare: the same household with no bridge-year plan.** If Maria and James had spent down taxable and Roth first and left traditional accounts untouched, their traditional balance at 73 would be about $620,000 and their first RMD about $23,400 — more than double. By 85, RMDs would be roughly $45,000 a year, stacked on $62,496 of Social Security, pushing much of their income into the 22% bracket and risking Medicare premium surcharges (IRMAA). The bridge years are where that outcome is prevented.

**Your steady-state years:**

| Age | Spending need | Social Security | Portfolio gap | RMD due | From traditional | From Roth | Taxable income | Marginal bracket |
|---|---|---|---|---|---|---|---|---|
| _____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | _____% |
| _____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | _____% |
| _____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | _____% |
| _____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | $_____ | _____% |

## Part 3: Checks Before You Finalize

- [ ] **Bracket jump check:** Is my marginal bracket at 73 higher than in my bridge years? If yes, increase bridge-year conversions or withdrawals.
- [ ] **IRMAA check:** Does any year's income cross an IRMAA threshold (about $212,000 MAGI for a married couple in 2025)? If a conversion crosses a threshold, reduce it.
- [ ] **Cash bucket check:** Do I hold two to five years of portfolio-funded spending in cash or short-term bonds, so I never have to sell investments in a down market?
- [ ] **Before 59½ check:** If I retire before 59½, which penalty-free source funds the gap (taxable account, Roth contributions, Rule 72(t), or the rule of 55)?
- [ ] **Survivor check:** If one spouse dies, does the survivor's bracket jump? If yes, convert more while both spouses are alive.
- [ ] **RMD check:** Is my RMD start age correct for my birth year (73 if born 1951–1959; 75 if born 1960 or later)?

---

*This planner is general education, not individualized retirement, tax, or investment advice. Verify current tax brackets, RMD tables, and IRMAA thresholds before acting, and consult a qualified professional for advice about your specific situation.*
