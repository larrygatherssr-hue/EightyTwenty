# Social Security Timing Worksheet

## How to Use This Worksheet

Get your own benefit estimates first: log in to your account at **ssa.gov** and record your estimated monthly benefit at ages 62, 67 (or your full retirement age), and 70. Do the same for your spouse. Then fill in the tables below. **Do not use the example numbers as your own** — they belong to the example household in the course (Maria, PIA $2,400; James, PIA $1,800) and are shown here only so you can see how the math works.

**Important:** All figures in this worksheet are illustrative examples based on stated assumptions. They are not a promise of any individual's benefit. Your actual benefit depends on your own earnings record and can only be confirmed by the Social Security Administration. This worksheet is general education, not individualized retirement, tax, or investment advice.

---

## Step 1: Your Numbers (from ssa.gov)

| | You | Your spouse |
|---|---|---|
| Full retirement age (FRA) | _____ | _____ |
| Primary Insurance Amount (PIA) — benefit at FRA | $_____ / month | $_____ / month |
| Estimated benefit at 62 | $_____ / month | $_____ / month |
| Estimated benefit at FRA | $_____ / month | $_____ / month |
| Estimated benefit at 70 | $_____ / month | $_____ / month |

## Step 2: The Claiming-Age Comparison (Example Household)

The table below uses the course example: Maria's PIA $2,400, James's PIA $1,800, both with a full retirement age of 67. Assumptions: no earnings after claiming, no cost-of-living adjustments (real COLAs would raise every figure, and would raise the delayed-claiming figures by more, because each adjustment compounds on a larger base). Replace these rows with your own figures from Step 1.

| Claiming age | Maria (monthly) | James (monthly) | Combined (monthly) | Combined (annual) | % of PIA |
|---|---|---|---|---|---|
| 62 | $1,680 | $1,260 | $2,940 | $35,280 | 70% |
| 63 | $1,800 | $1,350 | $3,150 | $37,800 | 75% |
| 64 | $1,920 | $1,440 | $3,360 | $40,320 | 80% |
| 65 | $2,080 | $1,560 | $3,640 | $43,680 | 86.7% |
| 66 | $2,240 | $1,680 | $3,920 | $47,040 | 93.3% |
| 67 (FRA) | $2,400 | $1,800 | $4,200 | $50,400 | 100% |
| 68 | $2,592 | $1,944 | $4,536 | $54,432 | 108% |
| 69 | $2,784 | $2,088 | $4,872 | $58,464 | 116% |
| 70 | $2,976 | $2,232 | $5,208 | $62,496 | 124% |

**Your comparison table** — copy the structure above with your own Step 1 figures:

| Claiming age | You (monthly) | Spouse (monthly) | Combined (monthly) | Combined (annual) |
|---|---|---|---|---|
| 62 | $_____ | $_____ | $_____ | $_____ |
| 67 (FRA) | $_____ | $_____ | $_____ | $_____ |
| 70 | $_____ | $_____ | $_____ | $_____ |

## Step 3: Cumulative Benefits — When Does Delaying Pay Off?

Using the example household's combined annual figures, and ignoring cost-of-living adjustments:

| Claiming scenario | Total by age 75 | Total by age 80 | Total by age 85 | Total by age 90 |
|---|---|---|---|---|
| Both claim at 62 (13 years of payments by 75) | $458,640 | $635,040 | $811,440 | $987,840 |
| Both claim at 67 (8 years by 75) | $403,200 | $655,200 | $907,200 | $1,159,200 |
| Both claim at 70 (5 years by 75) | $312,480 | $624,960 | $937,440 | $1,249,920 |

Reading the table: claiming at 62 pays more if you die before about age 80. Claiming at 67 pulls ahead around age 80. Claiming at 70 pulls ahead around age 82–83 and wins by a wide margin if you live into your late 80s or 90s. Your own break-even ages will differ — compute them from your Step 1 figures by dividing the benefits forgone while waiting by the monthly gain from waiting.

**My break-even ages (from my own figures):**

- Delaying from 62 to 67 breaks even at about age: _____.
- Delaying from 67 to 70 breaks even at about age: _____.
- Delaying from 62 to 70 breaks even at about age: _____.

## Step 4: The Survivor Check

When one spouse dies, the survivor keeps the larger of the two benefits. The higher earner's claiming age therefore sets the survivor's income for the rest of their life.

| | Higher earner claims at 62 | Higher earner claims at 67 | Higher earner claims at 70 |
|---|---|---|---|
| Higher earner's monthly benefit | $_____ | $_____ | $_____ |
| Survivor's monthly benefit after higher earner dies | $_____ | $_____ | $_____ |
| Survivor's annual income from this benefit | $_____ | $_____ | $_____ |

Example household: Maria is the higher earner. If she claims at 62, the survivor benefit is $1,680 a month. If she claims at 70, it is $2,976 a month — a difference of $1,296 a month, or $15,552 a year, for every year the survivor lives.

## Step 5: Other Factors

- [ ] **Working while claiming:** If I claim before full retirement age and keep working, the earnings test reduces my benefit by $1 for every $2 earned above the annual limit (about $23,400 in 2025; verify the current figure). My expected earnings before FRA: $_____.
- [ ] **Spousal benefit:** My spouse's own benefit is $_____. A spousal benefit (up to 50% of my PIA at full retirement age) would be $_____. The larger of the two applies.
- [ ] **Health:** My health today: ____________________. My parents' longevity: ____________________.
- [ ] **Tax:** Up to 85% of Social Security benefits can be taxable depending on total income. My expected tax on benefits: ____________________.

## Step 6: My Decision

**Provisional claiming age — me:** _____ **Provisional claiming age — spouse:** _____

**Reason (one or two sentences):** ______________________________

**Date I will revisit this decision:** _______________

---

*This worksheet is general education, not individualized retirement, tax, or investment advice. Verify your benefit estimates at ssa.gov and consult a qualified professional before making a claiming decision.*
