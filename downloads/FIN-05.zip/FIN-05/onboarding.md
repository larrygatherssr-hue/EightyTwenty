# Welcome to Retire on Purpose

## What You Just Bought

Thank you. You now own the complete **Retire on Purpose: The Retirement Planning Masterclass** — a 12-module retirement income planning course built for pre-retirees with $100,000 to $1,000,000 in savings who need an income plan, not just a balance.

Your download includes:

- **content.md** — the full 12-module course text.
- **workbook.md** — five worksheets: the income-gap worksheet, the Social Security timing worksheet, the withdrawal-sequence planner, the health-care cost estimator, and the annual review checklist.
- **templates/retirement-income-calculator.csv** — a spreadsheet with your income floor, portfolio draw, monthly income plan, and sensitivity scenarios, pre-filled with worked example rows.
- **templates/social-security-timing-worksheet.md** — a claiming-age comparison with cumulative benefit tables and a survivor check.
- **templates/withdrawal-sequence-planner.md** — a year-by-year planner for the bridge years and the RMD years, with worked examples.
- **cover.md** — the cover design brief for this product.
- **onboarding.md** — this guide.

## What to Do First

**Today — read the disclaimer and gather your numbers.** Start with the note at the top of content.md, then log in to your Social Security account at ssa.gov and write down your estimated benefit at ages 62, 67, and 70. Do the same for your spouse. Gather your most recent statement for every retirement account you own. These three things — Social Security estimates, account balances, and one month of tracked spending — are the raw material for the whole course.

**This week — complete Module 1 and Worksheet 1.** Track your spending for a full month using bank and card statements, build your retirement budget, and calculate your income gap. The gap — the annual amount your portfolio must produce, as a percentage of your portfolio — is the single most important number in your retirement plan. Everything else in the course is about managing it.

**Then — work through the modules in order.** Each module ends with action steps. Do them before moving on; the course is designed so each module's output feeds the next one. The Social Security decision in Module 3 feeds the income floor in Module 5, which feeds the withdrawal sequence in Module 6, which feeds the tax plan in Module 7.

## Suggested 8-Week Schedule

- **Week 1:** Module 1 (the income gap) + Worksheet 1. Track spending; gather statements.
- **Week 2:** Module 2 (401(k) and IRA decisions) + Module 3 (Social Security timing). Complete the Social Security timing worksheet with your ssa.gov estimates.
- **Week 3:** Module 4 (pensions and annuities) + Module 5 (income floor). Calculate your floor surplus or gap.
- **Week 4:** Module 6 (withdrawal sequencing) + Module 7 (tax-aware withdrawals and Roth conversions). Build your bridge-year plan in the withdrawal-sequence planner.
- **Week 5:** Module 8 (RMDs) + Module 9 (health care and Medicare). Complete the health-care cost estimator.
- **Week 6:** Module 10 (long-term care planning). Get insurance quotes; start your legal documents.
- **Week 7:** Module 11 (annual review system). Set your annual review date and complete the checklist once, as a rehearsal.
- **Week 8:** Module 12 (12-month implementation plan). Write your one-page plan and book your professional review.

After Week 8, the 12-month implementation schedule in Module 12 takes over — one milestone a month, ending with a professional review and a signed, written plan.

## How to Use the Materials

- **The course text is the teacher.** Read it in order the first time; return to individual modules later as reference when a decision comes up.
- **The workbook is where your numbers live.** Print it or copy it into a document you control. Bring the completed workbook to any meeting with a financial planner or tax professional — it will make that meeting far more productive.
- **The calculator spreadsheet is for testing.** Open it in Excel, Google Sheets, or LibreOffice. Replace every example value with your own, then run the sensitivity scenarios: lower growth, an early market drop, living to 95. A plan that only works in the base case is not a plan.
- **The templates are reusable.** The Social Security worksheet and the withdrawal-sequence planner are designed to be revisited every year at your annual review, with fresh numbers.

## A Note on the Numbers

Every example in this course uses one household — Maria and James, both 58, retiring at 65 with $500,000 saved — so the figures stay consistent and comparable. Your numbers will differ. Where the course states an assumption (a tax bracket, a Medicare premium, a growth rate), it says so, and you should verify the current figure before acting on it. Tax law, Social Security rules, and Medicare premiums change; the Social Security Administration is the only source for your actual benefit.

## How to Get Support

If you have trouble with your order or the course files, email the marketplace support address with your order number and a description of the issue, and the support team will respond. For questions about your personal retirement, tax, or investment decisions, consult a qualified financial planner, tax professional, or attorney — this course is general education, not individualized advice.

## One Last Thing

Do not try to do this all in a weekend. The course is built for eight weeks because the decisions deserve time — and because some of the best work in it is a conversation with your spouse, not a calculation. Start with Module 1 this week. The rest will follow.
