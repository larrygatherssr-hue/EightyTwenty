# Retire on Purpose: The Retirement Planning Masterclass

## A Note Before You Begin — Please Read This First

**This course is general education, not individualized retirement, tax, or investment advice.** Nothing in this course tells you what to do with your money. It teaches you how retirement income planning works so you can have a better conversation with a qualified financial planner, tax professional, or attorney — and so you can spot a bad plan before it costs you.

Every number in this course is an illustration built on stated assumptions. Actual results vary. Tax law changes. Social Security rules change. Markets go up and down. Benefit amounts depend on your own earnings record, which only the Social Security Administration can confirm for you. Where this course cites a dollar figure for a government program — a Medicare premium, a tax bracket, a contribution limit — treat it as an approximate figure for the year stated and verify the current figure before you act on it.

No return is guaranteed anywhere in this course. Any projection is a teaching tool, not a promise.

If a decision in this course feels large, irreversible, or confusing, that is exactly the moment to pay a professional for an hour of their time. This course is designed to make that hour far more productive — not to replace it.

---

## How This Course Works

You are about to build a retirement income plan. Not a balance. A plan: how much income you need, where it comes from, in what order you draw it down, what tax it costs, and how you keep it working for thirty years.

We will work with one running example throughout the course so the numbers stay consistent and comparable. Meet our example household:

**Maria and James, both age 58.** They plan to retire at 65. They have $500,000 saved: $320,000 in a traditional 401(k), $110,000 in a traditional IRA, $45,000 in a Roth IRA, and $25,000 in a taxable brokerage account. Their house is paid off. They expect combined Social Security of about $3,800 a month at their full retirement age of 67, based on their earnings records. They want $5,500 a month of after-tax spending in retirement, in today's dollars. They are in good health and plan for a retirement lasting to at least age 90.

Every assumption is stated where it is used. When we change an assumption, we say so. Your numbers will differ — the workbook that accompanies this course is where you substitute your own.

The course has twelve modules. Each one ends with action steps: concrete things to do before you move on. Work through them in order the first time. Later, return to individual modules as reference.

---

# Module 1: The Retirement Income Gap — Why a Balance Is Not a Plan

## The question nobody asks

Ask a pre-retiree how retirement is going and you will hear a number: "I have $500,000 saved." Or "$750,000." Or "$1.2 million." The number sounds like an answer. It is not. It is the beginning of a question: how much income does that number produce, for how long, after tax, and what happens when the market falls, inflation rises, or one of you lives to 95?

A balance is a pile of wood. An income plan is the fireplace, the chimney, and the schedule for feeding the fire through a long winter. This module is about measuring the gap between the income you need and the income your savings and benefits reliably produce — and about why that gap, not the balance, is the number that matters.

## What "the gap" actually is

The retirement income gap is the difference between the monthly after-tax income you need to live the life you want and the monthly after-tax income your guaranteed and planned sources will produce.

It has three parts:

1. **Your spending need.** Not your salary. Your spending. Most people spend less than they earn while working — no more retirement contributions, no more payroll tax, often no mortgage, often lower commuting and wardrobe costs. But some costs rise: health care, travel in the early years, helping adult children or grandchildren. A realistic retirement budget is built from your actual spending, not from a percentage of your salary.

2. **Your guaranteed income.** Social Security, any pension, and any annuity income you already own. This income is the floor of your plan. It arrives whether the market is up or down. It is the most valuable income you have, dollar for dollar, because it does not depend on your portfolio surviving.

3. **The portfolio's job.** Whatever your guaranteed income does not cover must come from your savings. This is the gap your portfolio has to fill — and the size of the gap determines how much risk your portfolio must take, how long it must last, and how carefully you must sequence your withdrawals.

## The worked example: Maria and James

Let us measure their gap.

**Step 1: Spending need.** Maria and James track their spending for three months and annualize it. Their current household spending is $6,800 a month. In retirement they expect to stop saving for retirement ($900 a month into the 401(k)), stop paying payroll tax on wages, and spend less on commuting and work clothing (about $250 a month). They add $400 a month for health care costs beyond Medicare premiums, and $300 a month for travel in the first ten years. Their planned retirement spending: $6,800 − $900 − $250 + $400 + $300 = $6,350 a month before income tax. They estimate they will owe about $850 a month in income tax in retirement, which means their gross income need is roughly $7,200 a month, or $86,400 a year.

**Step 2: Guaranteed income.** At their full retirement age of 67, their combined Social Security is about $3,800 a month, or $45,600 a year. Neither has a pension. Guaranteed income: $45,600 a year.

**Step 3: The gap.** $86,400 − $45,600 = $40,800 a year, or $3,400 a month, that must come from their $500,000 portfolio.

Now the hard question: can $500,000 reliably produce $40,800 a year?

A common rule of thumb, the "4% rule," suggests a portfolio can support withdrawals of about 4% of its starting value, adjusted for inflation each year, for roughly thirty years. Four percent of $500,000 is $20,000 a year — barely half of the $40,800 they need. Even at a more aggressive 5% withdrawal rate, the portfolio produces $25,000 a year. The gap is real: they need $40,800 and the portfolio, at conventional withdrawal rates, produces $20,000 to $25,000.

That does not mean Maria and James cannot retire. It means they have decisions to make, and the earlier they make them, the better the options. They can:

- **Work longer.** Each additional year of work adds savings, adds Social Security credits, and shortens the retirement the portfolio must fund. Delaying retirement from 65 to 67, for example, also lets them delay Social Security, which raises the benefit (Module 3).
- **Spend less.** Reducing planned spending from $6,350 to $5,500 a month before tax cuts the annual gross need by about $10,200.
- **Delay Social Security.** Claiming at 70 instead of 67 raises their combined benefit by about 24% — from roughly $3,800 to roughly $4,700 a month — which shrinks the portfolio's job by about $10,800 a year.
- **Take more portfolio risk.** This raises expected return but also raises the chance of a bad sequence of returns early in retirement (Module 5), which can permanently damage the plan.
- **Use part of the portfolio to buy guaranteed income.** An annuity converts a lump sum into a monthly check. This trades flexibility and legacy for certainty (Module 4).

Notice what is not on the list: "hope the market does well." Hope is not a plan. Every option above is a lever you can pull deliberately. The rest of this course teaches you how to pull each one, in what order, and at what cost.

## Why the gap usually surprises people

Three reasons.

**First, people anchor on the balance.** $500,000 feels like a lot of money — and it is, as a sum. As an income stream, $500,000 at a 4% withdrawal rate is $20,000 a year, or about $1,667 a month. The conversion from balance to income is the single most misunderstood arithmetic in retirement planning. A useful habit: divide any balance by 25 to get a rough sense of the annual income it supports at a 4% withdrawal rate. $500,000 ÷ 25 = $20,000. $1,000,000 ÷ 25 = $40,000. It is approximate, but it keeps you honest.

**Second, people forget tax.** A dollar in a traditional 401(k) is not a dollar of spending. It is a dollar minus the income tax you will pay when you withdraw it. Maria and James have $430,000 of their $500,000 in traditional pre-tax accounts. At a 22% marginal rate, that $430,000 is worth about $335,000 after tax. The workbook's income-gap worksheet forces you to do this math in after-tax terms, because that is the only terms in which you can spend money.

**Third, people plan for average life expectancy instead of longevity.** Average life expectancy at 65 is about 20 more years for men and 22 for women in the United States — but averages hide the spread. A healthy 65-year-old couple has a meaningful chance that at least one of them lives past 90, and a real chance one reaches 95. A plan that works to age 85 and fails at 92 is not a good plan. Throughout this course we plan to age 90 as a baseline and test to 95.

## The three numbers to carry forward

By the end of this module you should know three numbers for your own household:

1. Your monthly after-tax spending need in retirement.
2. Your monthly guaranteed income at your planned retirement age.
3. The annual gap between them — the portfolio's job.

If the gap is larger than about 5% of your portfolio, your plan needs one of the levers above. If it is larger than 7%, it needs several. If it is under 4%, you have room to breathe — and room to choose.

## Action Steps

1. Track your actual household spending for one full month. Use bank and card statements, not memory. Categorize every dollar.
2. Build a retirement spending budget: start from current spending, remove costs that end at retirement, add costs that begin.
3. Create or log in to your Social Security account at ssa.gov and record your estimated benefit at ages 62, 67, and 70. Write the numbers down.
4. List every pension or annuity you already own, with its monthly amount and start date.
5. Complete the Retirement Income Gap Worksheet in the workbook. Write down your gap in dollars per year and as a percentage of your portfolio. That percentage is the single most important number in your retirement plan.

# Module 2: 401(k) and IRA Decisions — Roth vs. Traditional, Rollovers, and Contribution Strategy

## The accounts you already have

Most pre-retirees hold their savings in a handful of account types, each with its own tax rules. The decisions you make about these accounts in your fifties and early sixties — while you still have earned income and, often, your highest tax years behind you and lower-tax years ahead — shape how much of your money you actually get to spend.

The four account types that matter:

- **Traditional 401(k) / traditional IRA:** Contributions are usually pre-tax; growth is tax-deferred; withdrawals in retirement are taxed as ordinary income. Required minimum distributions (RMDs) eventually force withdrawals.
- **Roth 401(k) / Roth IRA:** Contributions are after-tax; qualified withdrawals in retirement are tax-free. Roth IRAs have no RMDs for the original owner.
- **Taxable brokerage:** Contributions are after-tax; you pay tax on dividends and interest each year and on capital gains when you sell. No RMDs, no withdrawal penalties, full flexibility — and a step-up in cost basis for your heirs.
- **Health Savings Account (HSA):** If you have a high-deductible health plan, the HSA is the only account that is tax-deductible going in, tax-free growing, and tax-free coming out for qualified medical expenses. In retirement it can function as a stealth retirement account.

Maria and James hold $320,000 in a traditional 401(k), $110,000 in a traditional IRA, $45,000 in a Roth IRA, and $25,000 in taxable. That is $430,000 pre-tax, $45,000 Roth, $25,000 taxable. Their tax bill in retirement will be driven almost entirely by the $430,000.

## Roth vs. traditional: the only question that matters

The Roth-vs.-traditional decision reduces to one comparison: **your marginal tax rate now versus your marginal tax rate when you withdraw the money.**

- If your rate now is higher than your rate in retirement, traditional wins: you deduct at a high rate and pay at a low one.
- If your rate now is lower, Roth wins: you pay a low rate now and withdraw tax-free later.
- If the rates are equal, it is roughly a wash, and Roth still has advantages — no RMDs, tax-free growth for heirs, and no tax on withdrawals to push you into higher brackets or trigger Medicare premium surcharges.

Most people in their peak earning years are in a higher bracket while working than they will be in retirement, which is why traditional contributions usually make sense during the working years. But the years between retirement and age 73 — when RMDs begin — are often the lowest-tax years of a person's life. That window is the subject of Module 7.

**The worked example.** Maria earns $78,000 and James earns $64,000, for a household income of $142,000. They are married filing jointly. After the standard deduction, their marginal federal rate is 22%. They contribute $12,000 a year to traditional 401(k)s, saving about $2,640 a year in federal tax. In retirement, they expect their taxable income to put them in the 12% bracket for much of their withdrawals, with some dollars taxed at 22%. Paying 22% now to avoid 12% later would be a bad trade; deducting at 22% and withdrawing at 12% is a good one. Their traditional contributions are the right call — while they are working.

But there is a catch, and it is a big one: RMDs. At age 73, Maria and James will be forced to withdraw a percentage of their traditional balances every year, whether they need the money or not. If their traditional balances grow to $700,000 by age 73, their first RMD is roughly $26,400 — and that income is taxed, can push them into a higher bracket, and can trigger higher Medicare premiums. The time to manage that problem is in your late fifties and sixties, not at 73.

## Rollovers: when you leave a job

When you leave an employer, you generally have four choices for an old 401(k): leave it, roll it into your new employer's plan, roll it into an IRA, or cash it out. Cashing out is almost always a mistake: the distribution is taxed as ordinary income plus a 10% penalty if you are under 59½, and you lose decades of tax-deferred growth. A $100,000 cash-out at a 22% rate plus the penalty can cost $32,000 immediately — and far more in lost growth.

Rolling into an IRA usually gives you more investment choices and often lower fees than an old employer plan, but it has one important drawback: it can block the "backdoor Roth" strategy if your income is above the Roth IRA contribution limits, and IRA assets are not protected from creditors in every state the way 401(k) assets are under federal law. Rolling into a new employer's plan keeps the backdoor Roth path open and keeps the stronger federal creditor protection.

**A common and costly mistake: the indirect rollover.** If a distribution is paid to you directly instead of transferred trustee-to-trustee, the plan must withhold 20% for federal tax. You then have 60 days to deposit the full amount — including the withheld 20%, which you must replace from other funds — into the new account, or the shortfall is treated as a taxable distribution. Always use a direct, trustee-to-trustee rollover. There is no reason to touch the money.

## Contribution strategy in your final working years

If you are 50 or older, you can make catch-up contributions: for 2025, an extra $7,500 a year to a 401(k) on top of the $23,500 standard limit, and an extra $1,000 a year to an IRA on top of the $7,000 limit. (Limits are adjusted for inflation; verify the current year's figures.) If you are behind on savings, catch-up contributions are the most powerful lever you have left, because they are the only way to put large sums into tax-advantaged accounts quickly.

Priorities in the final working years, in order:

1. **Contribute enough to the 401(k) to capture the full employer match.** A match is an immediate, guaranteed return. Never leave it on the table.
2. **Pay off high-interest debt.** A credit card charging 20% is a guaranteed negative return that no investment reliably beats.
3. **Max out the HSA if you are eligible.** Triple tax advantage, and after 65 it can be used for non-medical expenses like a traditional IRA.
4. **Max out the 401(k), traditional or Roth depending on your rate comparison.**
5. **Fund a Roth IRA if you are eligible, or a taxable brokerage account if you are not.**

One more decision that matters: **where your contributions go in the last five years before retirement.** Money you will need in the first few years of retirement should not be sitting in a volatile stock fund the month you retire. As retirement approaches, the portion of the portfolio you will spend in the first three to five years should gradually move toward cash and short-term bonds. This is not market timing; it is matching the money to the date you need it.

## Action Steps

1. List every retirement account you own, its balance, its type (traditional, Roth, taxable, HSA), and its current investment mix.
2. Find your marginal federal tax rate now, and estimate your marginal rate in retirement. Write down which one is higher.
3. If you changed jobs and left a 401(k) behind, decide — leave it, roll it to the new plan, or roll it to an IRA — and do it by direct trustee-to-trustee transfer.
4. Check whether you are capturing your full employer match. If not, fix it this pay period.
5. If you are 50 or older, check your catch-up contribution room for this year and decide whether to use it.

---

# Module 3: Social Security Timing — Claiming at 62, 67, or 70

## The most consequential decision in retirement planning

For most households, Social Security is the largest single source of retirement income — and the claiming decision is the largest single financial decision of retirement. The difference between claiming at 62 and claiming at 70 is roughly a 76% increase in the monthly benefit. For a household, that difference can be worth hundreds of thousands of dollars over a lifetime. And unlike a market return, it is guaranteed, inflation-adjusted, and tax-advantaged.

Yet most people claim early. About a third of retirees claim at 62, the earliest possible age, often because they need the money, because they fear the program will be cut, or because nobody showed them the math. This module shows you the math.

## How the benefit is calculated

Your benefit is based on your highest 35 years of earnings, adjusted for wage inflation. The Social Security Administration computes your Average Indexed Monthly Earnings (AIME), applies a formula to get your Primary Insurance Amount (PIA) — the benefit you receive if you claim at your full retirement age (FRA) — and then adjusts it for the age at which you actually claim.

Your full retirement age depends on your birth year. For anyone born in 1960 or later, it is 67. For those born between 1943 and 1954, it is 66. Between 1955 and 1959, it phases from 66 and 2 months to 66 and 10 months.

**The claiming adjustments, for a full retirement age of 67:**

- Claim at 62: benefit reduced by 30% — you receive 70% of your PIA.
- Claim at 63: 75% of PIA. At 64: 80%. At 65: 86.7%. At 66: 93.3%.
- Claim at 67: 100% of PIA.
- Claim at 68: 108% of PIA. At 69: 116%. At 70: 124% of PIA.

Delayed retirement credits stop at 70. There is no financial reason to delay past 70.

These are permanent adjustments. Claim at 62 and the reduction follows you for life, including cost-of-living adjustments, which are applied to the reduced amount. Delay to 70 and the increase is permanent too.

## The worked example: Maria and James

Maria's PIA at her full retirement age of 67 is $2,400 a month. James's PIA is $1,800 a month. Their combined PIA is $4,200 a month.

**Claiming-age comparison (illustrative, based on a PIA of $2,400 for Maria and $1,800 for James; assumes no earnings after claiming and a constant cost-of-living adjustment, which is not guaranteed):**

| Claiming age | Maria (monthly) | James (monthly) | Combined (monthly) | Combined (annual) |
|---|---|---|---|---|
| 62 | $1,680 | $1,260 | $2,940 | $35,280 |
| 63 | $1,800 | $1,350 | $3,150 | $37,800 |
| 64 | $1,920 | $1,440 | $3,360 | $40,320 |
| 65 | $2,080 | $1,560 | $3,640 | $43,680 |
| 66 | $2,240 | $1,680 | $3,920 | $47,040 |
| 67 (FRA) | $2,400 | $1,800 | $4,200 | $50,400 |
| 68 | $2,592 | $1,944 | $4,536 | $54,432 |
| 69 | $2,784 | $2,088 | $4,872 | $58,464 |
| 70 | $2,976 | $2,232 | $5,208 | $62,496 |

The difference between claiming at 62 and at 70 is $2,268 a month — $27,216 a year — for the rest of their lives. Over a 25-year retirement, that is more than $680,000 in cumulative payments before cost-of-living adjustments, and more after them, because each annual adjustment compounds on a larger base.

**The break-even question.** The cost of delaying is the benefits you give up while you wait. If Maria and James delay from 67 to 70, they forgo three years of $4,200 a month — $151,200. In exchange, they gain $1,008 a month ($5,208 − $4,200) for life. Dividing $151,200 by $1,008 gives a break-even of 150 months, or 12.5 years — roughly age 82½. If they live past 82½, delaying wins. If they die before, claiming earlier wins. For the 62-to-70 comparison, the break-even is similar, around age 80 to 82 depending on assumptions.

This is why the claiming decision is really a longevity bet and a health question. A person in excellent health with long-lived parents has a strong case for delaying. A person with a serious illness and a short life expectancy has a strong case for claiming early. The average break-even near age 80–82 means that for a healthy 62-year-old, delaying is usually the better financial bet — because a healthy 62-year-old has a better-than-even chance of living past 82.

**But there is a second, bigger reason to delay, and it has nothing to do with break-even: survivor protection.** When one spouse dies, the surviving spouse keeps the larger of the two benefits. If Maria delays to 70 and her benefit is $2,976, and James claims at 62 and his is $1,260, then if James dies first, Maria keeps $2,976 a month. If Maria had claimed at 62, the survivor benefit would be only $1,680. For a married couple, the higher earner's claiming decision is really a decision about the surviving spouse's income for the rest of their life — often a decade or more of widowhood. In most couples, the higher earner should delay as long as possible.

## The spousal benefit

A spouse who has little or no earnings record of their own can claim a spousal benefit of up to 50% of the other spouse's PIA — but only if the other spouse has claimed, and only at full retirement age. Claim the spousal benefit early and it is reduced. Note: you cannot claim a spousal benefit before your spouse claims, and there are no delayed retirement credits on spousal benefits — delaying a spousal benefit past full retirement age does not increase it.

## Working while claiming

If you claim before your full retirement age and keep working, the earnings test reduces your benefit by $1 for every $2 you earn above an annual limit (about $23,400 in 2025; the limit is adjusted annually). In the year you reach full retirement age, the reduction is $1 for every $3 above a higher limit (about $62,160 in 2025). The withheld benefits are not lost — they are recalculated into a higher benefit once you reach full retirement age — but the reduction is a strong reason not to claim early while still earning a full salary.

## What about "Social Security will run out"?

The Social Security trust funds are projected to be able to pay about 75–80% of scheduled benefits after the mid-2030s if no changes are made. That is a real policy risk, but it is not a reason to claim at 62: even in a reduced-benefit scenario, a larger base benefit still pays more than a smaller one. Cutting benefits by 20% leaves a $2,976 benefit at $2,381 — still far above the $1,680 you would get by claiming at 62 and then taking the same cut. Fear of cuts argues for delaying, not for claiming early.

## Action Steps

1. Log in to ssa.gov and print or save your benefit estimates at 62, 67, and 70. Do the same for your spouse.
2. Complete the Social Security Timing Worksheet in the templates folder. Compare cumulative benefits at ages 80, 85, and 90 for each claiming age.
3. Identify the higher earner in your household. Discuss explicitly: what does the surviving spouse receive if the higher earner claims at 62 versus at 70?
4. Write down your honest health picture and your parents' longevity. If you are in poor health, early claiming may be right. If you are healthy with long-lived parents, delaying usually is.
5. Do not decide today if you are years away. But do write down a provisional claiming age and the reason for it — and revisit it annually.

# Module 4: Pensions and Annuities Explained

## Pensions: a shrinking but valuable asset

If you have a pension — a defined-benefit plan that pays a monthly amount for life — you hold one of the most valuable retirement assets there is: guaranteed income that you cannot outlive. Pensions are rarer than they used to be, concentrated now in government, education, and some union and legacy corporate plans. If you have one, the decisions around it deserve the same care as the Social Security decision.

**The three pension decisions:**

1. **Lump sum or monthly payments?** Many plans offer a choice. The lump sum gives you control and a legacy for heirs, but it transfers all the longevity and investment risk to you. The monthly payment gives you certainty and, usually, a better deal than you could buy on your own, because the plan's annuity pricing reflects the employer's group rates. A useful test: ask what monthly income the lump sum would buy as a commercial annuity. If the pension's monthly payment is higher than what the lump sum would buy, the monthly option is usually the better value — unless you have a strong reason to want the lump sum, such as poor health or a desire to leave money to heirs.

2. **Single life or joint-and-survivor?** A single-life pension pays more each month but stops when you die. A joint-and-survivor pension pays less — typically 10% to 20% less for a 100% survivor benefit — but continues to your spouse. For a married couple, the joint-and-survivor option is usually the right choice, for the same reason the higher earner should delay Social Security: the surviving spouse's income matters more than a few extra dollars a month while both are alive.

3. **When to start?** Some pensions allow an early start at a reduced amount or a delayed start at an increased amount. The math is the same break-even logic as Social Security: compare the forgone payments against the higher monthly amount, and weigh longevity and survivor needs.

**Check the fine print.** Is your pension adjusted for inflation? Most private pensions are not — a $2,000-a-month pension that never increases will buy roughly half as much after 25 years at 3% inflation. Is it insured? Private pensions are backstopped by the Pension Benefit Guaranty Corporation (PBGC), but only up to annual limits. Government pensions have their own rules, and some government pensions interact with Social Security through the Windfall Elimination Provision (WEP) and Government Pension Offset (GPO) — rules that reduce Social Security benefits for people who also receive a pension from work not covered by Social Security. If you have a government pension, get a benefits estimate that accounts for WEP and GPO before you finalize your Social Security plan.

## Annuities: what they are, what they are not

An annuity is a contract with an insurance company: you pay a lump sum (or a series of payments), and the company pays you income, usually for life. Annuities are the only product besides Social Security and pensions that can guarantee income you cannot outlive. They are also among the most misunderstood and most aggressively sold products in finance. Both facts are true at the same time.

**The three types you are most likely to encounter:**

- **Single-premium immediate annuity (SPIA).** You hand over a lump sum; payments start within a year and continue for life. This is the simplest, most transparent annuity, and the one most often recommended by independent planners for building an income floor. A 65-year-old man might receive roughly $600–$650 a month for life per $100,000 paid in (illustrative; actual rates vary with interest rates, age, and gender). A 65-year-old woman receives less, because women live longer on average.
- **Deferred income annuity (DIA).** You pay now; payments start years later — at 75, say. Because the insurer holds your money longer and some buyers will not live to collect, the payout per dollar is much higher. A DIA is a cost-effective way to insure against living a very long time.
- **Variable and indexed annuities.** These combine an investment account with insurance features — guaranteed minimum income riders, death benefits, caps on gains. They are complex, expensive (fees of 2% to 4% a year are common), and hard to compare. The guarantees are real but limited, and the costs compound over decades. Treat any annuity you cannot explain in two sentences with extreme caution, and never buy one in the same meeting where it is presented to you.

**What an annuity costs you.** When you buy a lifetime annuity, you give up the principal. If you pay $200,000 for an annuity that pays $1,200 a month and die after three years, the insurer keeps the balance (unless you bought a refund or period-certain feature, which lowers the monthly payment). That is the trade: you are pooling your longevity risk with thousands of other buyers. Those who die early subsidize those who live long. That is why annuities can pay more than a safe withdrawal rate — and why they feel uncomfortable. You are buying insurance against outliving your money, and like all insurance, it is a good deal precisely when you need it most.

## Building the income floor

The practical use of annuities in a retirement plan is the **income floor**: cover your essential spending — housing, food, utilities, insurance, basic health care — with guaranteed income (Social Security + pension + annuity), and let your portfolio cover the discretionary spending — travel, gifts, hobbies. If the market falls 30%, your essentials are still paid. That is the difference between a bad year and a crisis.

**The worked example.** Maria and James need $6,350 a month before tax. Their essential spending is $4,600 a month; the rest is discretionary. If they both delay Social Security to 70, their combined benefit is about $5,208 a month — more than their essentials. They may not need an annuity at all. But suppose they claim at 67 instead, receiving $4,200 a month. Their essential gap is $400 a month. Buying a SPIA that pays $400 a month would cost roughly $65,000–$70,000 at age 67 (illustrative). That leaves $430,000 of their $500,000 invested for discretionary spending and growth. The annuity is not an investment decision; it is an insurance decision, sized to the essential-spending gap.

**How much to annuitize?** A common guideline: annuitize enough to cover essentials, but keep at least half your portfolio liquid and invested for growth, inflation protection, and emergencies. Annuitizing everything leaves you with no cushion for a new roof, a health crisis, or a child's emergency. Annuitizing nothing leaves your essentials exposed to market risk. The right amount is the amount that lets you sleep — and it is usually smaller than a salesperson suggests.

## Action Steps

1. If you have a pension, get the written benefit estimate: monthly amount at each available start date, single-life versus joint-and-survivor amounts, and whether it is inflation-adjusted.
2. If you are offered a lump sum versus monthly pension, price the monthly option: ask an annuity quote service what the lump sum would buy as a SPIA, and compare.
3. Calculate your essential monthly spending. Subtract Social Security and pension income. The remainder is the gap an annuity could fill.
4. If you consider an annuity, get quotes from at least three insurers, ask for the total fees in writing, and take the proposal home for a week before deciding. Never buy an annuity in the meeting where it is pitched.
5. Check whether your pension triggers WEP or GPO if you also have Social Security. If you worked in a government job not covered by Social Security, confirm this before finalizing your claiming plan.

---

# Module 5: Building Your Income Floor

## What the floor is and why it comes first

Your income floor is the monthly income you can count on no matter what the market does: Social Security, pension, annuity income, and any other guaranteed source. It pays for the things you cannot skip — housing, food, utilities, insurance, transportation, basic health care. Everything above the floor is funded by your portfolio and can flex with the market.

The floor is the foundation of the whole plan. Get the floor right and a market crash becomes an inconvenience; get it wrong and a market crash becomes a crisis that forces you to sell investments at the worst possible moment.

## Sizing the floor

Work in three steps.

**Step 1: Separate essential from discretionary spending.** Go through your retirement budget line by line and mark each item essential or discretionary. Essentials are the costs of staying housed, fed, healthy, and insured. Discretionary is everything else — travel, dining out, gifts, hobbies, the second car. Be honest but not ascetic: a modest amount of dining out and entertainment belongs in essentials if cutting it would make retirement miserable. The point is to know which dollars are flexible and which are not.

**Step 2: Add up your guaranteed income.** Social Security at your planned claiming age, pension, annuity income you already own. Remember to count Social Security in after-tax terms — up to 85% of Social Security benefits can be taxable depending on your income, so the spendable amount is less than the gross benefit for many households.

**Step 3: Compare.** If guaranteed income covers essentials, your floor is built and your portfolio funds the good life. If it does not, you have a floor gap, and you have three ways to close it: delay Social Security, buy an annuity, or work longer.

## The worked example: Maria and James

Their retirement budget, before tax, is $6,350 a month. Their essentials:

| Category | Monthly |
|---|---|
| Housing (taxes, insurance, maintenance; mortgage paid off) | $950 |
| Food and household | $750 |
| Utilities and phone | $320 |
| Insurance (auto, home, umbrella) | $280 |
| Transportation (one car, gas, maintenance) | $350 |
| Health care (Medicare premiums + out-of-pocket, see Module 9) | $700 |
| Clothing and personal | $200 |
| **Essential total** | **$3,550** |

Their discretionary spending is $2,800 a month: travel $700, dining out $400, gifts and family $350, hobbies $300, home improvements $400, miscellaneous $650.

If they claim Social Security at 67, their combined benefit is about $4,200 a month gross. After tax on benefits (assume roughly 10% effective on the benefit in their situation, leaving about $3,780 spendable), their guaranteed income covers their $3,550 of essentials with about $230 a month to spare. Their floor is essentially built at 67 — tight, but built.

If they claim at 62, their combined benefit is about $2,940 a month gross, roughly $2,650 spendable — $900 a month short of essentials.

If they delay to 70, their combined benefit is about $5,208 gross, roughly $4,700 spendable — $1,150 a month above essentials. That surplus becomes discretionary income the portfolio does not have to provide, which shrinks the portfolio's annual job after 70 to roughly $14,000 a year of spending plus tax. But the bridge years cost money, and an honest plan says so: five years of drawing about $76,000 a year from a $500,000 portfolio leaves roughly $150,000 to $200,000 at age 70, even allowing for investment growth. A $14,000 annual draw on a $175,000 portfolio is an 8% withdrawal rate — too high to sustain for twenty years. That is the real tension in this household's plan, and it is why delaying Social Security alone is not enough for them. They also need a second lever in the bridge years: trimming discretionary spending by about $500 to $800 a month, earning part-time income, or claiming one spouse's benefit at 67 instead of 70. The calculator in the templates folder lets you test each lever and see the result before you commit to any of them.

Notice what happened: the claiming decision, the floor, and the withdrawal rate are not three separate decisions. They are one decision seen from three angles.

## Sequence-of-returns risk: the danger the floor protects against

The greatest risk to a retirement portfolio is not a market crash. It is a market crash **in the first few years of retirement**, while you are withdrawing money. This is sequence-of-returns risk, and it is the reason the floor matters so much.

Consider two retirees, each with $500,000, each withdrawing $25,000 a year adjusted for inflation. Retiree A experiences a 20% market drop in year one, then strong returns. Retiree B experiences strong returns first and the same 20% drop in year ten. Both experience the same average return over thirty years. Retiree A runs out of money years earlier — because in the early years, withdrawals came out of a shrinking portfolio, and the money that was sold at the bottom never recovered.

The defense is not to avoid the market. It is to avoid being forced to sell into a falling market. That is what the floor does: when essentials are covered by guaranteed income, you can leave the portfolio alone during a downturn. It is also what a cash reserve does, which is why the plan below includes one.

## The five-year cash bucket

A practical structure many planners use: keep two to five years of portfolio-funded spending in cash and short-term bonds — money that does not depend on the market at all. Maria and James need about $27,000 a year from the portfolio if they delay Social Security to 70. A three-year cash bucket is about $81,000. The rest of the portfolio stays invested for growth.

When the market is up, you refill the bucket from investment gains. When the market is down, you spend from the bucket and leave the investments alone. The bucket is not an investment strategy; it is a shock absorber. Its cost is the return you forgo by holding cash — modest, and worth it.

## Putting the floor together

Your income floor plan has four lines:

1. **Guaranteed income:** Social Security + pension + annuity = $_____ per month.
2. **Essential spending:** $_____ per month.
3. **Floor surplus or gap:** line 1 minus line 2 = $_____ per month.
4. **Portfolio-funded spending:** discretionary spending minus any floor surplus = $_____ per month.

If line 3 is negative, close the gap before you retire — by delaying Social Security, by annuitizing a portion of the portfolio, or by working longer. Do not retire into a floor gap and hope the market fills it.

## Action Steps

1. Split your retirement budget into essential and discretionary. Total each column.
2. Add up your guaranteed income at your planned claiming age, in after-tax terms.
3. Compute your floor surplus or gap. Write it down in dollars per month.
4. If there is a gap, price the three ways to close it: delaying Social Security, a SPIA quote, and one more year of work. Compare the costs.
5. Decide the size of your cash bucket: two, three, or five years of portfolio-funded spending. Write down where that money will sit.

# Module 6: Withdrawal Sequencing — Which Accounts First, and Why

## The order you withdraw is a tax decision

You have spent decades deciding which accounts to contribute to. Now you must decide the order to withdraw from them. The order matters because each account type is taxed differently, and the sequence determines how much of your money goes to tax, how much your RMDs will be later, and how much you leave to your heirs.

The conventional sequence, taught for years, is:

1. **Taxable accounts first.** You already paid tax on the contributions; you pay capital gains rates (often 0% or 15%) on the growth, and spending down taxable accounts first lets your tax-deferred accounts keep growing.
2. **Tax-deferred accounts next** (traditional 401(k) and IRA). Withdrawals are taxed as ordinary income.
3. **Roth accounts last.** Tax-free growth compounds longest, there are no RMDs, and Roth money is the most valuable legacy you can leave.

This sequence is a good starting point, but it is not always optimal. The smarter approach is **tax-bracket management**: fill up the lower tax brackets every year with withdrawals from tax-deferred accounts, and use Roth and taxable money to cover the rest. The goal is to pay tax at the lowest rate available in each year of retirement, and to avoid years where a large RMD pushes you into a much higher bracket.

## Why the conventional sequence can fail

Imagine Maria and James follow the conventional sequence. They spend down their $25,000 taxable account first, then live on Roth money while leaving their $430,000 of traditional accounts untouched. By age 73, the traditional accounts have grown to roughly $650,000 (assuming 5% annual growth, illustrative). Their first RMD is about $24,400 — and RMDs grow every year as the percentage rises and the balance, hopefully, keeps growing. By their mid-80s, RMDs could be $45,000 or more a year, taxed as ordinary income, pushing them into a higher bracket and increasing their Medicare premiums.

Meanwhile, they spent their Roth money early — the one account that would have grown tax-free forever and passed to their children tax-free.

The better approach is usually a blend: withdraw from traditional accounts deliberately, in measured amounts, during the low-tax years between retirement and RMD age, while using taxable and Roth money to fill the gaps.

## The worked example: the bridge years

Maria and James retire at 65 and delay Social Security to 70. That creates five "bridge years" (65 to 70) with no Social Security income and, therefore, very low taxable income. Those years are a tax-planning opportunity.

Their spending need is $6,350 a month, or $76,200 a year before tax. In the bridge years, their income sources are entirely withdrawals. Here is a year-by-year plan for age 65 (illustrative; assumes the standard deduction for a married couple filing jointly of about $30,000 in 2025, a 10% bracket up to about $23,850 of taxable income, and a 12% bracket up to about $96,950 — verify current figures before acting):

| Source | Amount | Tax treatment |
|---|---|---|
| Traditional 401(k)/IRA withdrawal | $55,000 | Ordinary income |
| Taxable brokerage withdrawal | $15,000 | Mostly return of principal; small capital gain |
| Roth IRA withdrawal | $6,200 | Tax-free |
| **Total** | **$76,200** | |

Taxable income: $55,000 minus the $30,000 standard deduction = $25,000. Federal tax: roughly $2,500 (10% on the first $23,850, 12% on the remaining $1,150). Effective rate on the $55,000 withdrawal: about 4.5%.

Compare that with waiting until 73, when RMDs of $24,000+ stack on top of $62,000 of Social Security, pushing much of that income into the 22% bracket. Drawing $55,000 a year from traditional accounts in the bridge years — at an effective rate under 5% — is far cheaper than drawing it later at 22%. Over five bridge years, they move $275,000 out of traditional accounts at low rates, shrinking the future RMD problem dramatically.

This is the core skill of retirement income planning: **look at your tax bracket in every year of retirement, and move money in the years when the rate is low.**

## The withdrawal-sequence planner

Use the template in this course's templates folder to build your own sequence year by year. For each year from your retirement age to 73, write down:

- Total spending need for the year.
- Guaranteed income (Social Security, pension) for the year.
- The gap the portfolio must fill.
- How much of the gap comes from taxable, traditional, and Roth accounts.
- Your expected taxable income and marginal bracket for the year.

Then do the same for the RMD years, 73 to 90, with RMDs included. If your marginal rate jumps sharply at 73, you are not withdrawing enough from traditional accounts in the bridge years. If your Roth balance is shrinking fast while your traditional balance is growing, you are withdrawing in the wrong order.

## Rules and traps

- **The 59½ rule.** Withdrawals from traditional IRAs and 401(k)s before age 59½ generally trigger a 10% early-withdrawal penalty on top of income tax, with exceptions for disability, certain medical expenses, substantially equal periodic payments (Rule 72(t)), and separation from service at age 55 or later from an employer plan (the "rule of 55"). If you retire before 59½, plan carefully — the bridge from retirement to 59½ needs taxable or Roth contribution money.
- **Roth contributions vs. earnings.** You can withdraw your Roth IRA *contributions* at any time, tax- and penalty-free. Roth *earnings* withdrawn before 59½ and before the account is five years old are taxed and penalized. Keep contributions and earnings straight.
- **The five-year rule.** Each Roth conversion has its own five-year clock for penalty-free withdrawal of the converted amount if you are under 59½. Conversions done after 59½ are simpler, but the five-year rule still matters for earnings.
- **Do not forget state tax.** Some states tax retirement income; some do not tax Social Security or pension income at all. Your withdrawal sequence should account for your state's rules.
- **Spouses are separate taxpayers for RMDs.** Each spouse's RMD is based on their own accounts and their own age. Coordinate, but calculate separately.

## Action Steps

1. List your accounts in withdrawal order: taxable, traditional, Roth. Write down the balance and tax treatment of each.
2. Map your tax brackets year by year from retirement to age 73. Identify your lowest-tax years.
3. Build a bridge-year plan: how much will you withdraw from traditional accounts each year before RMDs begin?
4. Check whether you will need money before 59½, and if so, identify which penalty-free source it will come from.
5. Complete the Withdrawal-Sequence Planner template for at least the first ten years of retirement.

---

# Module 7: Tax-Aware Withdrawals and Roth Conversions

## The goal: pay the lowest total tax over your lifetime, not the lowest tax this year

Most people optimize the wrong thing: they try to minimize this year's tax bill. The right goal is to minimize the **total tax paid over your entire retirement** — including the tax your heirs will pay on inherited accounts. Sometimes that means paying more tax this year on purpose.

The single most powerful tool for lifetime tax management in retirement is the **Roth conversion**: moving money from a traditional IRA to a Roth IRA, paying income tax on the converted amount now, so that all future growth and withdrawals are tax-free.

## How Roth conversions work

You convert a chosen amount from a traditional IRA to a Roth IRA. The converted amount counts as ordinary income in the year of conversion. You pay the tax from outside the IRA if you can — paying the tax from the converted funds reduces the amount that ends up in the Roth and weakens the benefit. Once converted, the money grows tax-free, has no RMDs, and passes to heirs tax-free (though heirs generally must empty inherited Roth IRAs within ten years under current law).

**When conversions make sense:**

- **In the bridge years.** Between retirement and age 73, your income is often at its lowest. Converting up to the top of the 12% bracket each year moves money at a 12% rate that might otherwise be taxed at 22% or more later, via RMDs.
- **When you expect higher rates later.** If RMDs will push you into the 22% or 24% bracket, paying 12% now is a bargain.
- **For the surviving spouse.** When one spouse dies, the survivor files as a single taxpayer, with roughly half the bracket widths and half the standard deduction. Income that was taxed at 12% or 22% as a couple can be taxed at 22% or 24% for the survivor. Converting while both spouses are alive, at married-filing-jointly rates, protects the survivor.
- **For legacy planning.** Roth money is the best money to leave to children in high tax brackets, because they inherit it tax-free.

**When conversions do not make sense:**

- If you are in a high bracket now and expect a lower one later.
- If paying the conversion tax would force you to sell investments or deplete your cash reserve.
- If you need the money soon — converted funds should stay in the Roth for years to justify the upfront tax.
- If the conversion would trigger Medicare premium surcharges (IRMAA) that cost more than the tax saved — see below.

## The worked example: Maria and James convert in the bridge years

Maria and James retire at 65 and delay Social Security to 70. In each bridge year, they need $76,200 of spending. Their plan from Module 6 withdraws $55,000 a year from traditional accounts. Suppose instead they withdraw $40,000 for spending and convert an additional $30,000 to Roth each year. Their taxable income becomes $70,000, minus the $30,000 standard deduction = $40,000 of taxable income. Federal tax on $40,000 is roughly $4,500 — an effective rate of about 6.4% on the $70,000 of traditional money moved. Over five bridge years, they convert $150,000 to Roth at an average rate under 10%, shrinking their traditional balance from $430,000 to roughly $280,000 (after accounting for growth and withdrawals, illustrative). Their RMD at 73 falls from roughly $26,000 to roughly $17,000, and $150,000 of their money now grows tax-free forever.

**The numbers to check before any conversion:**

1. Your marginal bracket this year, and how much room is left in it before the next bracket.
2. Whether the conversion pushes you over an IRMAA threshold (see below).
3. Whether you can pay the tax from cash or taxable funds, not from the IRA.
4. Whether the conversion affects the taxation of your Social Security benefits (more income can make more of your benefit taxable — up to 85%).

A practical rule: convert up to the top of your current bracket, but not into the next one, unless you have a specific reason. And never convert so much in one year that you spike into a higher bracket or trigger a Medicare surcharge that wipes out the benefit.

## IRMAA: the Medicare surcharge nobody warns you about

Medicare Part B and Part D premiums are means-tested. If your modified adjusted gross income (MAGI) from two years ago exceeds a threshold — about $106,000 for an individual and $212,000 for a married couple in 2025, with higher tiers above that — you pay an Income-Related Monthly Adjustment Amount (IRMAA) on top of the standard premium. The surcharges are cliff-based: one dollar over a threshold can cost hundreds of dollars a year in extra premiums.

This matters for Roth conversions because a conversion raises your MAGI. A $40,000 conversion that saves $3,000 in lifetime tax but triggers $2,000 a year in IRMAA surcharges for one year may still be worth it — but a conversion that pushes you over a threshold in multiple years may not be. Check the current IRMAA thresholds before any conversion, and remember the two-year lookback: income in the year you turn 63 determines your Medicare premiums at 65.

If your income drops after retirement — because you stopped working, for example — you can appeal an IRMAA determination using Form SSA-44, citing a life-changing event such as retirement. Many retirees do not know this and overpay for years.

## Tax-aware withdrawal habits

Beyond conversions, a few habits keep your lifetime tax low:

- **Harvest capital gains in low-income years.** In the bridge years, when your taxable income is low, you may be in the 0% capital gains bracket (taxable income up to about $96,700 for married couples in 2025). Selling appreciated investments in a taxable account and immediately rebuying them resets your cost basis at no tax cost.
- **Harvest losses in high-income years.** Sell investments at a loss to offset gains, and carry forward up to $3,000 a year of net losses against ordinary income.
- **Give from the IRA after 70½.** A qualified charitable distribution (QCD) lets you donate up to $108,000 a year (2025 limit, indexed) directly from an IRA to a charity. It counts toward your RMD but is excluded from your taxable income — better than donating cash and taking a deduction, especially if you take the standard deduction.
- **Coordinate with your spouse.** Bracket widths, IRMAA thresholds, and the standard deduction are all roughly doubled for married couples. After one spouse dies, they halve. Plan conversions and withdrawals while both spouses are alive.

## Action Steps

1. Calculate how much room you have in your current tax bracket this year. Write down the dollar amount to the top of the bracket.
2. Model a Roth conversion: convert an amount that fills your current bracket but does not push you into the next one or over an IRMAA threshold.
3. Check your MAGI against the current IRMAA thresholds for the year you turn 65.
4. If you are charitably inclined and over 70½, ask your IRA custodian about qualified charitable distributions.
5. Before executing any conversion, confirm the tax can be paid from outside the IRA. If it cannot, reduce the conversion amount.

# Module 8: Required Minimum Distributions

## What RMDs are

Required minimum distributions are the government's way of collecting the tax it deferred while your money grew in traditional retirement accounts. Starting at a certain age, you must withdraw a minimum amount from your traditional IRAs, 401(k)s, 403(b)s, and similar accounts every year, and pay income tax on it. The penalty for missing an RMD is steep — 25% of the amount not withdrawn (reduced to 10% if corrected promptly) — so this is not a rule to learn about late.

**The RMD age under current law (SECURE 2.0):**

- Born 1950 or earlier: 72 (already in effect for most).
- Born 1951–1959: 73.
- Born 1960 or later: 75.

Verify your own required beginning date; the law has changed twice in recent years and could change again.

**How the amount is calculated.** Each year, you divide your account balance at the end of the previous year by a life-expectancy factor from the IRS Uniform Lifetime Table. At 73, the factor is about 26.5, so the RMD is roughly 3.8% of the balance. At 80, the factor is about 20.2, so the RMD is roughly 5%. At 85, about 6.5%. At 90, about 8.8%. The percentage rises every year, which means RMDs grow even if the balance stays flat — and if the balance grows, RMDs grow faster.

**Which accounts have RMDs.** Traditional IRAs, traditional 401(k)s, 403(b)s, and similar employer plans. Roth IRAs have no RMDs for the original owner. (Roth 401(k)s were subject to RMDs until 2024; under current law they are not, but verify this for your plan.) Inherited IRAs have their own distribution rules, usually requiring the account to be emptied within ten years.

## The worked example: Maria and James at 73

Maria and James retire at 65, delay Social Security to 70, and follow the bridge-year plan from Modules 6 and 7, converting $30,000 a year to Roth. By 73, their traditional balance is about $280,000 (illustrative, after withdrawals, conversions, and assumed 5% growth). Their first RMD: $280,000 ÷ 26.5 = about $10,600.

Now compare the alternative: no conversions, no bridge-year withdrawals. Their traditional balance at 73 is about $620,000. Their first RMD: $620,000 ÷ 26.5 = about $23,400 — more than double. And it grows from there. By age 85, the no-plan scenario produces RMDs of roughly $45,000 a year, stacked on top of $62,000 of Social Security. Much of that income lands in the 22% bracket, and the extra income can trigger IRMAA surcharges on Medicare premiums.

The difference between the two scenarios is not luck. It is the five bridge years, used deliberately.

## Managing RMDs: the strategies

**1. Reduce the balance before RMDs begin.** Roth conversions in the bridge years are the primary tool (Module 7). Every dollar converted before 73 is a dollar that never generates an RMD.

**2. Use qualified charitable distributions (QCDs).** Once you are 70½, you can donate up to $108,000 a year (2025 limit, indexed for inflation) directly from your IRA to a qualified charity. A QCD counts toward your RMD but is excluded from taxable income. If you give to charity anyway, doing it as a QCD instead of writing a check saves tax at your marginal rate — and it keeps the income off your return, which can also reduce the taxation of Social Security and IRMAA surcharges.

**3. Still working at 73?** If you are still employed and do not own more than 5% of the company, you can delay RMDs from your current employer's 401(k) until you retire. This does not apply to IRAs or to 401(k)s from former employers. It is a narrow exception, but a useful one for people who work past 73.

**4. Aggregate IRAs, but not 401(k)s.** You can calculate RMDs for all your traditional IRAs together and take the total from any one IRA. But 401(k) RMDs must be taken separately from each 401(k) plan. If you have multiple old 401(k)s, consider consolidating them into one IRA before RMD age to simplify — while weighing the creditor-protection and backdoor-Roth considerations from Module 2.

**5. Take the RMD early in the year — or late, deliberately.** There is no rule about when in the year you take an RMD, only that you take it. Taking it early gives you cash to spend or invest. Taking it in December lets the money grow tax-deferred for eleven more months. Some retirees take RMDs monthly to smooth their income. What matters is that you take the full amount, every year, on time.

**6. Do not reinvest RMDs you do not need into the same tax trap.** If your RMD exceeds your spending need, invest the surplus in a taxable brokerage account or a Roth IRA if you have eligible earned income. Do not put it back into a traditional IRA — you cannot, in any case, once you are past the contribution rules, and it would only create a larger future RMD.

## The survivor's RMD problem

When one spouse dies, the survivor inherits the deceased spouse's IRA and must take RMDs based on their own life expectancy. The survivor also files as a single taxpayer, with narrower brackets. A couple that managed RMDs comfortably at married-filing-jointly rates can find the survivor pushed into a higher bracket on the same income. This is one more reason to do Roth conversions while both spouses are alive.

## Action Steps

1. Write down your RMD start age based on your birth year. Put a reminder on your calendar for the year you turn that age.
2. Project your traditional account balance at RMD age under two scenarios: with bridge-year conversions and without. Compare the first-year RMD in each.
3. List every account subject to RMDs, and note whether each is an IRA (aggregable) or a 401(k) (separate).
4. If you give to charity, set up a QCD with your IRA custodian for the year you turn 70½.
5. If you are still working past your RMD age, confirm with your plan administrator whether the still-working exception applies to your current employer's plan.

---

# Module 9: Healthcare and Medicare Costs

## The cost most retirement plans underestimate

Health care is the largest unpredictable expense in retirement, and the one most often underestimated. A common estimate — that a 65-year-old couple retiring today may need roughly $300,000 over the course of retirement for health care costs, not including long-term care — is frequently cited in financial planning research, and it surprises almost everyone who hears it. The exact number for your household depends on your health, your location, and your coverage choices. What is certain is that health care deserves its own line in your plan, its own budget, and its own decision process.

## Medicare: the four parts

Medicare begins at 65 for most Americans. It has four parts, and each one costs something.

- **Part A (hospital insurance).** Covers inpatient hospital stays, skilled nursing facility care, hospice, and some home health care. Most people pay no premium for Part A because they paid Medicare taxes during their working years. There is a deductible per benefit period (about $1,676 in 2025) and coinsurance for long stays.
- **Part B (medical insurance).** Covers doctor visits, outpatient care, preventive services, and durable medical equipment. The standard premium is about $185 a month in 2025, deducted from your Social Security benefit. There is an annual deductible (about $257 in 2025) and you generally pay 20% coinsurance on covered services. Part B premiums are subject to IRMAA surcharges for higher-income retirees (Module 7).
- **Part D (prescription drug coverage).** Offered through private insurers. Premiums vary by plan, averaging roughly $40–$50 a month, plus deductibles and copays. Part D is also subject to IRMAA. Under current law, out-of-pocket drug costs are capped at $2,000 a year (2025), which is a significant protection for people on expensive medications.
- **Part C (Medicare Advantage).** Private plans that bundle Parts A, B, and usually D, often with extra benefits such as dental, vision, and hearing. Premiums can be low — some plans charge no premium beyond Part B — but the plans have networks, prior-authorization requirements, and out-of-pocket maximums that vary widely. The trade-off is cost versus flexibility: Advantage plans are usually cheaper month to month but restrict which doctors and hospitals you can use.

## The Medigap decision

Original Medicare (Parts A and B) has no out-of-pocket maximum. A serious illness can generate 20% coinsurance on hundreds of thousands of dollars of care. A Medigap (Medicare Supplement) policy, sold by private insurers, covers most or all of those gaps — deductibles, coinsurance, and copays. Medigap Plan G, the most comprehensive plan available to new enrollees, typically costs $150–$250 a month depending on your state, age, and insurer.

**The timing rule that matters most:** you have a six-month Medigap open-enrollment period that begins the month you turn 65 and enroll in Part B. During that window, insurers must sell you any Medigap policy at the standard rate, regardless of your health. After the window closes, insurers in most states can deny you or charge more based on your health. This is a one-time window. If you choose Medicare Advantage at 65 and want to switch to Original Medicare plus Medigap at 70, you may be medically underwritten and denied. Choose carefully at 65.

**The cost comparison, illustrative.** For Maria and James at 65, one reasonable structure is:

| Item | Monthly (per person) | Monthly (couple) |
|---|---|---|
| Part B premium | $185 | $370 |
| Medigap Plan G | $200 | $400 |
| Part D prescription plan | $45 | $90 |
| Dental/vision (separate policy) | $50 | $100 |
| **Total premiums** | **$480** | **$960** |
| Plus out-of-pocket (deductibles, copays, uncovered care) | ~$100 | ~$200 |
| **Total health care budget** | **~$580** | **~$1,160** |

That is about $13,900 a year for the household — before any major illness, and before long-term care (Module 10). It is also the number that belongs in the retirement budget from Module 1. If your plan budgets $300 a month for health care, it is underfunded by roughly $800 a month, or nearly $10,000 a year. That shortfall has to come from somewhere.

## Enrollment traps

- **Enroll on time.** Your initial enrollment period runs for seven months: the three months before your 65th birthday, your birthday month, and the three months after. If you miss it and do not have creditable employer coverage, Part B premiums rise by 10% for every 12-month period you were eligible but not enrolled — a penalty that lasts for life.
- **The employer-coverage exception.** If you are still working at 65 and covered by an employer plan with 20 or more employees, you can usually delay Part B without penalty. Get this in writing from your employer's benefits office, and keep it. If your employer has fewer than 20 employees, Medicare is generally primary and you should enroll at 65.
- **HSAs and Medicare.** Once you enroll in Medicare — including Part A, which is automatic for most people at 65 if they claim Social Security — you can no longer contribute to an HSA. If you plan to work past 65 and keep contributing to an HSA, delay both Medicare and Social Security. If you enroll in Part A, HSA contributions must stop. You can still spend HSA funds tax-free on qualified medical expenses, including Medicare premiums.
- **COBRA is not creditable coverage for Part B.** If you retire at 63 or 64 and use COBRA to bridge to Medicare, the COBRA period does not count as employer coverage for the purpose of delaying Part B. Enroll in Medicare at 65 regardless of COBRA.

## The HSA as a retirement health-care account

If you have an HSA, it is the best health-care funding tool you have: tax-deductible contributions, tax-free growth, tax-free withdrawals for qualified medical expenses — including Medicare Part B, Part D, and Medigap premiums in retirement. After 65, HSA funds can also be withdrawn for non-medical expenses, taxed as ordinary income like a traditional IRA.

A practical strategy: if you can afford it, pay current medical expenses out of pocket, let the HSA grow, and save your receipts. There is no time limit on reimbursing yourself from an HSA for a qualified expense incurred after the HSA was opened. A $50,000 HSA at retirement is a powerful health-care reserve.

## Action Steps

1. If you are within a year of 65, mark your Medicare initial enrollment period on your calendar and confirm whether your employer coverage is creditable.
2. Price Medigap Plan G and at least two Medicare Advantage plans in your ZIP code during your open-enrollment window. Compare total annual cost, not just the monthly premium.
3. Add a realistic health-care line to your retirement budget: premiums plus an out-of-pocket allowance. Use the table above as a starting point and adjust for your situation.
4. If you have an HSA, decide: spend it now or let it grow as a retirement health-care reserve.
5. Complete the Healthcare Cost Estimator in the workbook with your own premiums, medications, and expected out-of-pocket costs.

---

# Module 10: Long-Term Care Planning

## The risk that breaks plans

About seven in ten people turning 65 will need some form of long-term care in their remaining years — help with bathing, dressing, eating, or other daily activities, whether at home, in assisted living, or in a nursing facility. The average need lasts about three years for women and about two years for men, but averages hide the tail: roughly one in five people will need care for more than five years.

The cost is the problem. National median costs, as commonly reported in industry cost-of-care surveys, are roughly $5,000–$6,000 a month for assisted living, $9,000–$10,000 a month for a semi-private nursing home room, and $25–$35 an hour for home health aide services. A three-year nursing home stay can cost $300,000 or more. Medicare does not cover long-term custodial care — it covers up to 100 days of skilled nursing after a hospital stay, and only under strict conditions. Medicaid covers long-term care, but only after you have spent down most of your assets.

Long-term care is not a remote risk. It is the most common reason a careful retirement plan fails late.

## The four ways to pay

**1. Self-insure.** Pay from savings and income. This works if your portfolio is large enough that a $300,000 care event does not break the surviving spouse's plan. For Maria and James, with $500,000 saved, a three-year care event for one spouse would consume most of the portfolio and leave the survivor with little. Self-insuring is a realistic option for households with $1.5 million or more in assets; below that, it is a hope, not a plan.

**2. Long-term care insurance.** A standalone policy pays a daily or monthly benefit when you cannot perform a set number of activities of daily living. Policies bought in your late fifties typically cost $2,000–$4,000 a year per person for meaningful coverage, and premiums can rise. The trade-offs are real: premiums are expensive, policies have elimination periods (typically 90 days before benefits begin), and if you never need care, the premiums are gone. But for a household with $500,000 to $1.5 million in assets — too much to qualify for Medicaid quickly, too little to self-insure comfortably — insurance is often the right answer. Buy it in your fifties, when you are healthy enough to qualify and premiums are lowest. Waiting until 70 can double the cost or make you uninsurable.

**3. Hybrid policies.** A life insurance policy or annuity with a long-term care rider: if you need care, the policy pays for it; if you do not, your heirs receive a death benefit. Hybrids cost more upfront but solve the "use it or lose it" objection to standalone policies. They are worth pricing alongside standalone coverage.

**4. Medicaid planning.** Medicaid is the payer of last resort. It requires spending down countable assets to roughly $2,000 for an individual (with protections for a spouse who remains at home, including a home exemption and a monthly income allowance). Medicaid planning — the legal restructuring of assets to qualify sooner — is a specialized area of elder law. It is not a do-it-yourself project, and it is not a first choice; it is a safety net. If long-term care costs are a serious concern, consult an elder-law attorney before you need care, not after.

## Planning beyond insurance

Insurance is only part of long-term care planning. The rest is practical:

- **Where will care happen?** Most people want to stay at home. Home care is often cheaper than a facility for part-time needs and more expensive for round-the-clock needs. Know the home-care agencies and assisted-living communities in your area before you need them.
- **Who will provide care?** Adult children often become caregivers, at real cost to their own careers and health. Talk to your children now about what you expect and what you do not expect.
- **Legal documents.** A durable power of attorney, a health care proxy, a living will, and an updated will are not optional. Without a power of attorney, your family may need a court order to manage your finances if you become incapacitated — a slow, expensive process.
- **The surviving spouse.** Long-term care for one spouse often impoverishes the other. Any long-term care plan must answer the question: if one of us needs three years of care, what is left for the other?

## The worked example: Maria and James

Maria and James price standalone long-term care insurance at age 58. A policy paying $6,000 a month for three years, with a 90-day elimination period and 3% compound inflation protection, costs about $3,200 a year for Maria and $2,800 a year for James — $6,000 a year combined. That is a significant cost, roughly 4% of their gross income. But compare it with the alternative: a three-year care event costing $216,000 at today's assisted-living rates, or $324,000 at nursing-home rates, paid from a $500,000 portfolio. The insurance costs $6,000 a year to protect against a $200,000–$300,000 event that has a roughly 70% chance of happening to one of them. They decide to buy a slightly leaner policy — $5,000 a month for three years — at about $4,800 a year combined, and to revisit the coverage at 65. They also complete their powers of attorney and health care proxies this year.

## Action Steps

1. Get quotes for standalone long-term care insurance and at least one hybrid policy. Do this while you are in your fifties and healthy.
2. Price the cost of care in your area: call one home-care agency and one assisted-living community and ask for their current monthly rates.
3. Complete or update your durable power of attorney, health care proxy, living will, and will. Give copies to the people named in them.
4. Have the conversation with your adult children: what care you expect, what you have planned, and where the documents are.
5. Answer the survivor question in writing: if one spouse needs three years of care, what is left for the other? If the answer is "not enough," your long-term care plan is not finished.

---

# Module 11: The Annual Review System

## A plan is not a document; it is a habit

A retirement income plan is not something you write once and file away. Tax law changes. Markets move. Your health changes. Your spending changes. A plan that is never reviewed becomes a guess within a few years. This module builds a review system you can run every year in a single afternoon — the same discipline, repeated annually, that keeps a plan honest for thirty years.

## The annual review: five checks, one afternoon

Set a date. The same date every year — your birthday, the first Saturday in January, the anniversary of your retirement. Put it on the calendar and treat it as an appointment with your future self.

**Check 1: The spending check.** Compare last year's actual spending with the budget. Where did you overspend? Where did you underspend? Is the budget still realistic, or does it need adjusting? Most retirees find that spending in the first years is higher than planned (travel, new hobbies, home projects) and then settles. If your spending is running 10% above plan, adjust the plan — do not ignore the gap and hope it closes.

**Check 2: The income check.** Confirm every income source: Social Security deposits, pension payments, annuity payments, portfolio withdrawals. Did everything arrive as expected? Did any source change? If you turned 73 this year, is your RMD calculated and scheduled? If you are in the bridge years, did your Roth conversions happen as planned?

**Check 3: The portfolio check.** What is the portfolio worth now, and what is the withdrawal rate? Divide this year's total portfolio withdrawals by the portfolio's value at the start of the year. If the rate is under 4%, you are in good shape. Between 4% and 5%, pay attention. Above 5%, you need a decision: spend less, earn more, or accept a higher risk that the portfolio will not last. Also check the asset allocation: has the stock portion drifted far above your target after a strong market? Rebalance back to target once a year.

**Check 4: The tax check.** What was your taxable income last year, and what bracket were you in? Is there room for a Roth conversion this year? Did you cross an IRMAA threshold? Are you on track for next year's RMD? A short meeting with a tax professional every two or three years, timed before year-end, is often worth far more than it costs.

**Check 5: The life check.** Has anything changed that the plan should reflect? A health diagnosis. A move. A grandchild. A parent who needs help. A spouse who wants to work part-time. The plan serves your life, not the other way around. Update the assumptions and re-run the numbers when life changes.

## The withdrawal-rate guardrails

A useful framework for the annual review is the guardrails approach: set a target withdrawal rate (say 4.5%), with an upper guardrail (say 5.5%) and a lower guardrail (say 3.5%). Each year, compute your actual withdrawal rate:

- **Below the lower guardrail (3.5%):** you can afford to spend more. Increase withdrawals, take the trip, give to family.
- **Between the guardrails:** stay the course.
- **Above the upper guardrail (5.5%):** cut spending by about 10% for the next year and re-check. A temporary cut early in a bad stretch is far more effective than a large cut later.

Guardrails turn an emotional decision — "should I spend less?" — into a rule you agreed to in advance, when you were calm. That is their entire value.

## The documents to keep current

Every year, confirm that these are in place and up to date:

- Beneficiary designations on every retirement account, life insurance policy, and annuity. These override your will. An ex-spouse left as a beneficiary on a 401(k) will receive the money, regardless of what your will says.
- Your will, durable power of attorney, health care proxy, and living will.
- Your list of accounts, passwords, and contacts — stored securely, with a trusted person knowing where to find it.
- Your long-term care plan and insurance.
- Your estate plan, including whether your heirs understand the ten-year rule for inherited IRAs.

## The worked example: Maria and James, year three of retirement

Maria and James retired at 65. It is now January of their third year of retirement. Their annual review:

- **Spending:** They spent $79,400 last year against a $76,200 budget — 4% over, driven by a roof repair ($4,500, one-time) and higher travel. Underlying spending is on plan.
- **Income:** Social Security has not started (they are delaying to 70). Portfolio withdrawals were $79,400. Their bridge-year Roth conversions of $30,000 each year happened as planned.
- **Portfolio:** Started the year at $512,000 (after two years of growth and withdrawals). Withdrawal rate: $79,400 ÷ $512,000 = 15.5%? No — wait. That is wrong, and catching the error is the point of the review. Their withdrawals were $79,400, but $30,000 of the traditional-account movement was a Roth conversion, not spending. Spending withdrawals were $49,400 from traditional accounts plus $30,000 from taxable and Roth — total spending withdrawals $79,400, but the portfolio funded only $79,400 of spending, and the conversion moved $30,000 from one pocket to another. The correct withdrawal rate for spending: $79,400 ÷ $512,000 = 15.5% — still far too high. Something is wrong.

They look closer. Their portfolio at the start of the year was $512,000. Their spending need is $76,200 a year, and they have no Social Security yet. $76,200 ÷ $512,000 = 14.9%. That is not sustainable. But wait — their plan was to spend $76,200 a year for five bridge years, funded by a $500,000 portfolio, and then let Social Security take over at 70. Five years at $76,200 is $381,000 — leaving about $119,000 plus growth at 70, when Social Security of $62,496 a year begins and the portfolio's job drops to about $14,000 a year. The bridge years are supposed to be expensive. The withdrawal rate during the bridge years is supposed to be high. The mistake is judging a bridge year by a rule designed for the steady state.

The lesson: the annual review must compare actual results against **the plan for that year**, not against a generic rule. Their plan always called for high withdrawals from 65 to 70 and low withdrawals after. The review confirms they are on plan. It also confirms they should not panic — and it confirms the importance of the cash bucket (Module 5), because a market drop during the bridge years would hurt more than a drop later.

They also check their tax: their bridge-year conversions kept them in the 12% bracket, and their MAGI stayed below the IRMAA threshold. They rebalance the portfolio back to 60% stocks / 40% bonds. They update beneficiaries — James's old 401(k) still lists his brother from before they married. They fix it that afternoon.

## Action Steps

1. Pick your annual review date and put it on the calendar now. Make it the same date every year.
2. Complete the Annual Review Checklist in the workbook. Run through all five checks.
3. Calculate your withdrawal rate for the past year and compare it with your guardrails — and with what your plan expected for this specific year.
4. Check every beneficiary designation. This takes an hour and prevents a disaster.
5. Write down one change to make this year, based on the review. One change. Do it before the review date passes.

---

# Module 12: Your 12-Month Implementation Plan

## From knowledge to action

You now understand the pieces: the gap, the accounts, Social Security timing, pensions and annuities, the income floor, withdrawal sequencing, tax-aware withdrawals, RMDs, health care, long-term care, and the annual review. This final module turns understanding into a schedule — twelve months of specific actions, in order, so that a year from now you have a complete, working retirement income plan.

## The plan, month by month

**Month 1 — Measure.** Track your spending for a full month. Gather every account statement. Log in to ssa.gov and record your benefit estimates at 62, 67, and 70. Complete the Retirement Income Gap Worksheet. You now know your three numbers: spending need, guaranteed income, and the gap.

**Month 2 — Budget.** Build your retirement spending budget: essentials versus discretionary, with a realistic health-care line. Decide your planned retirement age, provisionally. Write it down with the reason.

**Month 3 — Social Security.** Complete the Social Security Timing Worksheet. Decide your provisional claiming age. Identify the higher earner and the survivor benefit under each claiming scenario. If you are married, make this decision together.

**Month 4 — The floor.** Calculate your income floor: guaranteed income versus essential spending. If there is a gap, price the three ways to close it — delaying Social Security, an annuity quote, one more year of work. Decide which you will use.

**Month 5 — Accounts.** List every retirement account. Confirm your employer match, your catch-up contribution room, and your beneficiary designations. If you have an old 401(k), decide on the rollover and execute it by direct transfer.

**Month 6 — Withdrawal sequence.** Build your year-by-year withdrawal plan from retirement to age 73, using the Withdrawal-Sequence Planner. Identify your bridge years and your lowest-tax years. Decide how much you will withdraw from traditional accounts each year before RMDs begin.

**Month 7 — Tax strategy.** Model Roth conversions for your bridge years. Check IRMAA thresholds. Decide whether you will convert, how much, and in which years. If the numbers are close or the situation is complex, book an hour with a tax professional this month.

**Month 8 — Health care.** If you are near 65, confirm your Medicare enrollment window. Price Medigap Plan G and Medicare Advantage plans in your area. If you have an HSA, decide whether to spend it or let it grow.

**Month 9 — Long-term care.** Get quotes for standalone and hybrid long-term care insurance. Price care in your area. Have the conversation with your children. Start or update your legal documents: power of attorney, health care proxy, living will, will.

**Month 10 — The cash bucket.** Decide the size of your cash reserve: two, three, or five years of portfolio-funded spending. Begin moving that money into cash and short-term bonds, gradually, so it is in place before you retire.

**Month 11 — Professional review.** Take your completed workbook, your worksheets, and your plan to a qualified professional — a fee-only financial planner, a tax professional, or both — for a one-time review. Ask them to find the holes. This is the highest-value money you will spend in this entire process. Bring the questions you could not answer yourself.

**Month 12 — Write the plan down.** One page. Your retirement age. Your claiming age. Your spending budget. Your income floor. Your withdrawal sequence. Your conversion plan. Your review date. Sign it, date it, and store it where you will find it. Then set the annual review date on your calendar and start living the plan.

## The worked example: Maria and James, one year later

Twelve months after starting this course, Maria and James have:

- A retirement budget: $6,350 a month before tax, $3,550 essential, $2,800 discretionary.
- A retirement age: 65, both of them, with a written reason (their health is good, their jobs are tiring, and the bridge-year math works).
- A claiming age: 70 for both, to maximize the survivor benefit and close the income floor.
- A floor: Social Security at 70 covers essentials with $1,150 a month to spare.
- A withdrawal sequence: $55,000 a year from traditional accounts in the bridge years, plus taxable and Roth money, with $30,000 a year converted to Roth — and a bridge-year spending trim of $600 a month plus part-time income of $20,000 a year for two years, because the calculator showed the unadjusted bridge years would leave the portfolio too small at 70.
- A tax plan: conversions fill the 12% bracket, stay below the IRMAA threshold, and are paid from cash.
- A health-care budget: $1,160 a month for the household, including Medigap Plan G.
- Long-term care insurance: a $5,000-a-month policy for three years, at $4,800 a year combined.
- Legal documents: powers of attorney, health care proxies, living wills, and updated wills, all signed and filed.
- A cash bucket: three years of portfolio-funded spending, about $81,000, in a high-yield savings account and short-term Treasury ladder.
- A professional review: a fee-only planner confirmed the plan, corrected their RMD projection, and suggested a QCD strategy for their charitable giving.
- A one-page written plan, signed and stored, with an annual review date every January.

Their portfolio is still $500,000. Nothing about their balance changed. Everything about their plan changed. That is the point of this course: the balance was never the plan. The plan is the plan.

## What to do when things change

They will. Markets fall. Tax law changes. A health issue appears. A parent needs help. A child needs help. When something changes, do not throw the plan away. Go back to Module 1 and re-measure the gap. Then walk the modules forward: does the claiming age still make sense? Does the floor still hold? Does the withdrawal sequence still work? Most changes require adjusting one or two levers, not rebuilding the whole plan. The annual review in Module 11 is where you catch the changes early, while the adjustments are still small and cheap.

## A final word

Retirement is not the end of financial planning. It is the beginning of the part where the decisions are irreversible, the stakes are highest, and the margin for error is smallest. You cannot earn your way out of a mistake at 75 the way you could at 45. That is why the planning matters, and why it matters now, while you still have choices.

You have the tools. You have the numbers. You have a schedule. The next step is Month 1, and it starts with a single month of tracking your spending.

Go do it.

---

## Action Steps

1. Copy the 12-month schedule above into your calendar, one milestone per month.
2. Complete every worksheet in the workbook before Month 11, so your professional review is productive.
3. Write your one-page plan in Month 12. Sign it. Date it. Store it.
4. Set your annual review date and put it on the calendar for next year.
5. Tell someone — your spouse, your partner, your adult child — that you have a plan, and where it is. A plan nobody else knows about is a plan that dies with you.

---

## Disclaimer

This course is general education about retirement income planning. It is not individualized retirement, tax, legal, or investment advice, and it does not consider your personal circumstances. All examples, including the example household of Maria and James, are illustrative and based on stated assumptions; actual results will vary. Tax brackets, contribution limits, Medicare premiums, IRMAA thresholds, and Social Security rules change over time — verify current figures with the relevant government agency or a qualified professional before acting. Social Security benefit figures in this course are illustrative examples based on assumed earnings records and are not a promise or estimate of any individual's actual benefit; your own benefit can only be confirmed by the Social Security Administration. No investment return is guaranteed. Consult a qualified financial planner, tax professional, or attorney for advice about your specific situation before making retirement, tax, or investment decisions.

---

*End of course.*
