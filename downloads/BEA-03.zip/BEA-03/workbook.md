# Beauty Brand Launch & Monetization Playbook — Companion Workbook

Use this workbook alongside `content.md`. Complete each worksheet as you finish the matching module. Print it or copy it into your own notes — either way, write your real answers in it. A workbook full of your own numbers and names is worth more than a course you only read.

> **Disclaimer:** This workbook is educational material for business planning. It is not legal, financial, medical, or regulatory advice. Do not make medical or treatment claims about your products. Cosmetics regulations and labeling rules vary by country and state — confirm the requirements that apply where you will sell, and consult a qualified professional where you are unsure. No result, sale, or income is guaranteed.

---

## Worksheet 1 — Positioning (Module 1)

**1. Who is your customer? Describe one specific person, not a demographic.**
Name or persona: ____________________
Age and life situation: ____________________
Daily routine and where the problem shows up: ____________________
Where she spends time online: ____________________

**2. What problem does she already feel and talk about?**
In her own words: ____________________
What has she tried that did not work? ____________________
What does the problem cost her (time, comfort, confidence)? ____________________

**3. Why you, and not what she already uses?**
Your specific difference (formula, ritual, founder story, values, price/size): ____________________
What you will NOT claim (keep this honest): ____________________

**4. Your positioning sentence.**
For [specific person], who [specific problem], [product name] is the [category] that [specific difference], so that [specific outcome].

Your sentence: ____________________

**Stranger test:** Read the sentence to someone who does not know your brand. Could they say who it is for? Yes / No. If no, rewrite it.

**5. Competitive map.** List five brands your customer already buys or considers.

| Brand | Who they target | Price | Hero product | Main claim | Where they sell |
|---|---|---|---|---|---|
| 1. | | | | | |
| 2. | | | | | |
| 3. | | | | | |
| 4. | | | | | |
| 5. | | | | | |

What do they all have in common (the crowded middle)? ____________________
Where is the empty space, and is it empty because nobody wants it? ____________________

**6. Ten customer interviews.** List ten real people who match your customer. Record the date, what they use now, their biggest frustration, and the exact words they used.

| # | Person | Date | Uses now | Biggest frustration | Their exact words |
|---|---|---|---|---|---|
| 1 | | | | | |
| 2 | | | | | |
| 3 | | | | | |
| 4 | | | | | |
| 5 | | | | | |
| 6 | | | | | |
| 7 | | | | | |
| 8 | | | | | |
| 9 | | | | | |
| 10 | | | | | |

---

## Worksheet 2 — Pricing and Margins (Module 2)

Fill in your real costs. Use the calculator in `templates/pricing-margin-calculator.csv` for the arithmetic.

**Landed cost per unit:**
- Formula and ingredients: $______
- Packaging (bottle/jar, cap, pump, label, box): $______
- Filling and assembly: $______
- Freight to you (per unit): $______
- Payment processing per sale: $______
- Shipping to the customer (amount you absorb): $______
- **Total landed cost per unit: $______**

**Candidate prices:**

| Retail price | Gross margin $ | Gross margin % | Wholesale margin $ (50% of retail minus landed cost) | Affiliate margin $ (after 15% commission) |
|---|---|---|---|---|
| $______ | | | | |
| $______ | | | | |
| $______ | | | | |

**My chosen retail price: $______** — because: ____________________

**Discount rules I will follow:**
- I will discount only for this reason: ____________________
- Maximum discount: ______%
- I will never discount below: $______ (the price that keeps my thinnest channel profitable)
- I prefer this value-add instead of a price cut: ____________________

---

## Worksheet 3 — Launch Calendar Checklist (Module 3)

Write your actual dates. Day 1 is the day you start.

| Phase | Dates | Key actions | Done? |
|---|---|---|---|
| Tease (Days 1–21) | ______ to ______ | Problem content 3x/week; waitlist page live; first posts published | ☐ |
| Build (Days 22–56) | ______ to ______ | Lead magnet live; weekly Q&A started; 5–10 testers recruited | ☐ |
| Pre-sell (Days 57–83) | ______ to ______ | 12-email sequence scheduled; founding-member offer set; pre-sell page live | ☐ |
| Launch (Days 84–90) | ______ to ______ | Waitlist early access; public opening; last-call close | ☐ |

**Waitlist promise:** ____________________
**Founding-member offer:** ____________________
**Launch offer end date (no extensions):** ____________________

**Weekly tracking (copy this block each week):**
Week of: ______ | Waitlist size: ______ | New sign-ups: ______ | Email open rate: ______% | Email click rate: ______% | Saves per post: ______ | Notes: ____________________

---

## Worksheet 4 — Influencer Tracker (Module 5)

Add one row per creator. Target: 50 creators contacted for a first launch.

| # | Creator name | Platform / handle | Followers | Audience fit (1–5) | Date contacted | Pitch sent | Follow-up sent | Reply | Product shipped | Posted? | Affiliate code | Sales | Next step |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | | | | | | ☐ | ☐ | | ☐ | ☐ | | | |
| 2 | | | | | | ☐ | ☐ | | ☐ | ☐ | | | |
| 3 | | | | | | ☐ | ☐ | | ☐ | ☐ | | | |
| 4 | | | | | | ☐ | ☐ | | ☐ | ☐ | | | |
| 5 | | | | | | ☐ | ☐ | | ☐ | ☐ | | | |

(Copy the table to add more rows.)

**Pipeline targets:** Contacted: ______ / 50 | Replies: ______ | Products shipped: ______ | Posts: ______ | Ongoing affiliates: ______

**Disclosure reminder:** Every gifted or paid product goes out with a written note asking the creator to disclose the gifted product and any commission clearly. Keep a record of every arrangement.

---

## Worksheet 5 — Email-Sequence Planner (Module 6)

Plan each email before you write it. The full sequence is in `templates/presell-email-sequence.md`.

| # | Job | Send date | Subject line (under 50 characters) | One story or idea | One call to action | Sent? |
|---|---|---|---|---|---|---|
| 1 | Welcome | | | | | ☐ |
| 2 | Founder story | | | | | ☐ |
| 3 | The problem, deepened | | | | | ☐ |
| 4 | Formula and science | | | | | ☐ |
| 5 | Tester story | | | | | ☐ |
| 6 | How to use it | | | | | ☐ |
| 7 | What makes it different | | | | | ☐ |
| 8 | Questions answered | | | | | ☐ |
| 9 | Offer opens | | | | | ☐ |
| 10 | Proof and urgency | | | | | ☐ |
| 11 | Last call | | | | | ☐ |
| 12 | Thank you / what's next | | | | | ☐ |

**Funnel pages checklist:**
- [ ] Waitlist page live (one email field, one promise)
- [ ] Thank-you page live (expectations set, one next action)
- [ ] Pre-sell page live (product, price, benefit, limit, deadline, guarantee)
- [ ] Checkout tested end to end with a real order

**Guarantee wording on the pre-sell page:** ____________________
**Return policy:** ____________________

---

## Worksheet 6 — Launch Metrics (Modules 7–8)

Update weekly during the 90 days, daily during launch week, monthly after.

**Audience:** Waitlist: ______ | Weekly sign-ups: ______ | Open rate: ______% | Click rate: ______% | Followers: ______ | Saves/post: ______

**Funnel:** Waitlist page conversion: ______% | Pre-sell conversion: ______% | Checkout completion: ______%

**Sales (launch week):** Orders: ______ | Revenue: $______ | Average order value: $______ | Units per order: ______ | Refund rate: ______% | Discount cost: $______

**Creators:** Contacted: ______ | Posted: ______ | Sales attributed: ______ | Cost per post: $______

**Customers:** New buyers: ______ | Repeat buyers (90 days): ______ | Repeat rate: ______% | Reviews received: ______ | Average review score: ______ / 5

**Top three customer questions:**
1. ____________________
2. ____________________
3. ____________________

**Top three complaints or issues:**
1. ____________________
2. ____________________
3. ____________________

**What I will fix next week:** ____________________

**90-day review date:** ____________________
