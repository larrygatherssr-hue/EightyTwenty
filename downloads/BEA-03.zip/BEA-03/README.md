# BEA-03 — Beauty Brand Launch & Monetization Playbook ($547)

A launch-and-monetization system for new beauty brands: positioning, pricing, pre-launch audience building, influencer outreach, and first-sale funnels — sequenced over 90 days.

## Files

| File | What it is |
|---|---|
| `content.md` | The full course — 8 modules written out in complete prose (11,163 words), plus a worked launch example, launch metrics dashboard, and compliance checklist. |
| `workbook.md` | Companion workbook — positioning worksheet, pricing worksheet, launch calendar checklist, influencer tracker, email-sequence planner, launch metrics worksheet. |
| `templates/90-day-launch-calendar.md` | Day-by-day plan for all 90 days (Tease, Build, Pre-sell, Launch). |
| `templates/influencer-outreach-scripts.md` | Pitch, follow-up, gifting, affiliate, paid-collaboration brief, and thank-you scripts. |
| `templates/presell-email-sequence.md` | All 12 pre-sell emails written in full. |
| `templates/pricing-margin-calculator.csv` | Pricing and margin calculator with formulas (landed cost, gross margin, wholesale, affiliate, discount impact). |
| `sales-page.md` | Full sales page — headline, problem, solution, module list, who it is for / not for, price $547 + 14-day guarantee, FAQ (8 questions), disclaimers. |
| `listing.json` | Marketplace listing data — SKU BEA-03, price 54700 cents, billing one_time. |
| `cover.png` | Product cover image — premium black-and-gold luxury branding (1280 × 1920). |
| `cover.md` | Cover design brief (palette, typography, imagery, layout). |
| `onboarding.md` | Customer onboarding guide — what to do first, how to use the materials, suggested 8-week schedule, support instructions. |
| `README.md` | This file. |
