# Customer Onboarding Guide — Beauty Brand Launch & Monetization Playbook

Welcome. You have just bought the complete launch system for your beauty brand. This guide tells you what to do first, how to use the materials, and what the next eight weeks look like.

---

## What You Received

| File | What it is |
|---|---|
| `content.md` | The full course — all 8 modules written out in complete prose, plus a worked launch example, a metrics dashboard appendix, and a compliance checklist. |
| `workbook.md` | The companion workbook — six worksheets that match the modules. Print it or copy it into your notes. |
| `templates/90-day-launch-calendar.md` | The day-by-day plan for all 90 days, in four phases. |
| `templates/influencer-outreach-scripts.md` | Pitch, follow-up, gifting, affiliate, paid-brief, and thank-you scripts. |
| `templates/presell-email-sequence.md` | All 12 pre-sell emails written in full. |
| `templates/pricing-margin-calculator.csv` | A spreadsheet with formulas — enter your costs and price, and it computes landed cost, margins, wholesale, affiliate, and discount impact. |
| `sales-page.md` | The full sales page copy for this product (for your reference). |
| `cover.png` / `cover.md` | The product cover image and its design brief. |
| `listing.json` | The marketplace listing data for this product. |

---

## What to Do First (Day 1)

1. **Read the disclaimers at the top of `content.md`.** This course is business education, not legal, medical, or regulatory advice. Cosmetics rules vary by country and state — you are responsible for confirming the rules where you will sell.
2. **Read Module 1 and complete Worksheet 1 in the workbook.** Positioning comes before everything. Do not skip it, even if your product is already finished.
3. **Get your real costs.** Contact your manufacturer or supplier and get per-unit costs in writing. Put them in the pricing calculator before you set a price.
4. **Pick your start date.** Day 1 of the 90-day calendar is the day you start, not the day you feel ready. Put Day 90 on your calendar now.

## How to Use the Materials

- **Read one module, then do its exercise.** Each module ends with an exercise and a matching worksheet. The learning happens in the exercise, not the reading.
- **Customize the templates before you use them.** Every bracketed placeholder — [Product Name], [Your Name], [price], [date] — must be replaced with your real details. Never send a template with placeholders in it.
- **Use the calculator for every price and every promotion.** If the calculator says a price does not work, believe the calculator.
- **Print the 90-day calendar** and keep it where you work. One action per day; if you miss a day, do the next day's action — do not double up.

## Suggested 8-Week Schedule

| Week | Focus | Do |
|---|---|---|
| 1 | Positioning + pricing | Modules 1–2; Worksheets 1–2; ten customer interviews; costs in the calculator; price chosen. |
| 2 | Launch plan + audience | Module 3; Worksheet 3; waitlist page live; lead magnet drafted; Day 1 of the calendar started. |
| 3 | Audience building | Module 4; content pillars running 3–5x/week; first weekly email sent; 5–10 testers recruited. |
| 4 | Audience + creators | Module 4 continued; list of 50 creators built; warm-ups started; weekly live/Q&A running. |
| 5 | Influencer outreach | Module 5; Worksheet 4; first pitches sent; gifting note customized. |
| 6 | Pre-sell funnel | Module 6; Worksheet 5; four funnel pages built; all 12 emails customized and scheduled. |
| 7 | Launch week prep | Module 7; launch-week posts written in advance; customer-service inbox and canned answers ready; review-request email written. |
| 8 | Launch + first-sale systems | Module 8; Worksheet 6; launch week executed; five systems installed; 90-day review date scheduled. |

After week 8, your 90-day calendar continues through launch week and into the first 30 days of sales. The schedule above gets you to the starting line with everything built; the calendar carries you through the launch itself.

## How to Get Support

For help with your order or the course files, email the marketplace support address with your order number and a description of the issue, and the support team will respond. Include the file name you are asking about (for example, `pricing-margin-calculator.csv`) so support can help quickly.

Support can help with file access, downloads, and questions about the materials. Support cannot give legal, medical, financial, or regulatory advice, and cannot set your prices or make launch decisions for you — those are yours, and the course gives you the tools to make them well.

## A Final Note

A launch is not a single brave day. It is ninety small days, done in order. Start on Monday, follow the calendar, and answer your customers. That is the whole system — and it works best when you actually use it.
