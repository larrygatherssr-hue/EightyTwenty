# Beauty Brand Launch & Monetization Playbook

**A 90-day sequenced campaign to launch your beauty brand to buyers, not silence**

---

## Important Disclaimers — Please Read First

This playbook is an educational business course. It teaches brand positioning, pricing, audience building, influencer outreach, email marketing, and launch planning for cosmetics, skincare, and haircare brands. It is not legal advice, financial advice, medical advice, or regulatory advice.

- **No medical or treatment claims.** Nothing in this course tells you how to formulate a product that treats, cures, or prevents any disease or skin condition, and you must not make such claims about your products. Cosmetic claims and drug claims are treated differently by regulators, and the line between them matters.
- **Regulations vary.** Cosmetics labeling, ingredient restrictions, safety substantiation, good manufacturing practice, and registration requirements vary by country and by state. In the United States, the Federal Food, Drug, and Cosmetic Act and the Modernization of Cosmetics Regulation Act (MoCRA) set the federal framework; the European Union, the United Kingdom, Canada, and other markets have their own rules. Before you sell, confirm the requirements that apply in every market where your product will be sold, and consult a qualified regulatory consultant or attorney where you are unsure.
- **No guaranteed results.** This playbook describes systems and strategies that other founders have used. It does not guarantee sales, revenue, followers, press coverage, or any specific income. Your results depend on your product, your market, your execution, and factors outside your control.
- **Numbers in this course are teaching examples.** Every worked example uses illustrative figures to show you how to do the arithmetic. They are not market data, not industry averages, and not promises about what your product will cost or earn. Replace every example number with your own real costs before you make a pricing decision.
- **Influencer and advertising rules apply.** Paid partnerships, gifted product, and affiliate arrangements must be disclosed according to the rules of the Federal Trade Commission in the United States and equivalent bodies elsewhere. This course explains how to structure outreach; it does not replace your obligation to comply with disclosure law.

---

## Table of Contents

- How to Use This Playbook
- Module 1 — Positioning: The One Sentence That Sells Your Brand
- Module 2 — Pricing and Margins: Building a Price That Actually Pays You
- Module 3 — The 90-Day Sequenced Launch: How a Launch Really Works
- Module 4 — Pre-Launch Audience Building: From Zero to a Waitlist That Buys
- Module 5 — Influencer Outreach: A Pipeline, Not a Prayer
- Module 6 — The Pre-Sell Funnel: Turning Attention Into Orders Before Launch Day
- Module 7 — Launch Week and the First 30 Days of Sales
- Module 8 — First-Sale Systems: What Happens After the First Order
- Appendix A — Launch Metrics Dashboard: What to Measure and When
- Appendix B — Compliance Checklist Before You Sell

---

## How to Use This Playbook

This is a complete written course manual. Each module is a full lesson in prose: read it, do the exercise at the end, and fill in the matching section of the companion workbook before moving on.

You do not need to finish all eight modules before you start working. The recommended path is:

1. **Week 1:** Modules 1 and 2. Positioning and pricing first, because every later decision depends on them.
2. **Weeks 2–3:** Modules 3 and 4. Build your 90-day calendar and start audience building.
3. **Weeks 4–5:** Modules 5 and 6. Open your influencer pipeline and build your pre-sell funnel.
4. **Weeks 6–8:** Modules 7 and 8. Run launch week, then install the systems that keep the first sales coming.

If your product is already finished and sitting in boxes, start at Module 1 anyway. A finished product with no positioning is the single most common reason a launch goes quiet.

You will need: your real product costs, a notebook or the workbook, a calendar, and an email tool (any basic email marketing platform will do). You do not need paid ads to run this playbook. Paid advertising is discussed as an optional accelerator in Module 7, never as a requirement.

---

# Module 1 — Positioning: The One Sentence That Sells Your Brand

## The problem positioning solves

Walk into any beauty aisle, physical or digital, and you will see the same wall: hundreds of serums, creams, oils, and shampoos, most of them making the same promises in the same words. "Clean." "Natural." "Glow." "Hydrating." When every brand says the same thing, the customer cannot tell them apart, so she buys the one she already knows, the cheapest one, or the one an influencer told her to buy. A new brand that sounds like every other brand has no reason to be chosen.

Positioning is the decision about who your product is for, what specific problem it solves for them, and why it is different from the alternatives they already have. It is not your logo. It is not your packaging, although packaging should express it. It is the idea in the customer's mind that makes your brand the obvious choice for one specific person in one specific situation.

Most founders skip this step because it feels like narrowing. It feels like turning customers away. The opposite is true. A brand for everyone is a brand for no one, because "everyone" has no shared problem, no shared language, and no shared place where you can reach them. A brand for one clearly defined person can be found, understood, and recommended. That person tells her friends, who are usually like her. Narrow positioning is how small brands grow.

## The three questions

Every positioning decision answers three questions, in this order:

**1. Who is it for?** Not a demographic label alone — a person with a life. "Women 25–40" is not a person. "Maya, 32, a nurse who works twelve-hour shifts, washes her hands fifty times a day, and is tired of hand creams that feel greasy under gloves" is a person. You need to be able to picture her, know where she spends time online, and know what she complains about to her friends.

**2. What problem does it solve?** The problem must be one she already feels and already talks about. You cannot educate a stranger into wanting a product for a problem she does not think she has. If she says "my skin looks dull by 3 p.m.," that is a problem. If she says "I want a 10-step routine," that is a different problem, and a different customer.

**3. Why you, and not the thing she already uses?** This is the difference. It can be an ingredient story, a format, a texture, a scent, a value, a founder story, a price point, or a ritual. It cannot be "better quality" in the abstract, because every brand claims that. It must be specific enough that a customer could repeat it to a friend in one sentence: "It's the only hand cream that sinks in in ten seconds, so I can put gloves back on."

Write your answers down. If you cannot write them, you do not have positioning yet — you have a product looking for a reason to exist.

## The positioning sentence

Once you can answer the three questions, compress them into one sentence with this structure:

**For [specific person], who [specific problem], [product name] is the [category] that [specific difference], so that [specific outcome].**

Here are three worked examples, all fictional, to show how the sentence works:

**Example A — skincare.** "For shift workers who wash their hands constantly, [Brand] is the hand cream that absorbs in under ten seconds with no residue, so they can moisturize between patients without slowing down." The customer is specific. The problem is specific. The difference is measurable — ten seconds, no residue. The outcome is about her work, not about the cream.

**Example B — haircare.** "For women with fine, flat hair who hate heavy oils, [Brand] is the lightweight scalp serum that adds volume at the root without weighing hair down, so second-day hair looks styled instead of limp." Notice what this sentence does: it disqualifies the wrong customer on purpose. Women who love heavy oils are not the customer, and that is fine.

**Example C — cosmetics.** "For makeup wearers with sensitive skin who break out from long-wear foundation, [Brand] is the breathable skin tint that covers redness without clogging pores, so they can wear makeup all day without dreading the mirror at night." The enemy here is not a competing brand. The enemy is the trade-off the customer hates: coverage versus comfort.

Now write yours. Expect it to take several drafts. A good test: read it to someone who does not know your brand and ask them who it is for. If they cannot answer, it is still too vague.

## Finding your difference honestly

Founders usually look for a difference in the formula. Sometimes it is there. Often it is not, and pretending otherwise leads to claims you cannot support. Your difference can live in several places:

- **The formula:** a hero ingredient at an effective level, a texture no one else has, a fragrance profile, a format (a solid serum bar, a refillable compact).
- **The ritual:** how and when it is used. A two-minute morning ritual for people who hate ten-step routines is a real difference.
- **The founder:** your story, your expertise, your community. A founder who is a nurse formulating for nurses carries credibility no lab can buy.
- **The values:** refillable packaging, fragrance-free for sensitive skin, a shade range built for deep skin tones first rather than last. Values only count as positioning if they change the product or the experience, not if they are a line on the website.
- **The price and size:** a travel-size-first brand, a single hero product instead of a range, a price that undercuts the prestige shelf without looking cheap.

What does not count as a difference: "clean," "natural," "luxury," "high quality," "dermatologist approved" (unless you can substantiate it), and any claim about treating a medical condition. If your difference could be printed on any competitor's bottle without anyone noticing, it is not a difference.

## Competitive mapping

Before you finalize positioning, map the five brands your customer already buys or considers. For each one, write down: who they target, their price, their hero product, their main claim, and where they sell. Then write down what they all have in common — that is the crowded middle. Your positioning should sit outside that middle in at least one dimension: a different customer, a different problem, a different price, or a different channel.

A simple way to see this is a two-axis map. Pick the two dimensions that matter most to your customer — for example, price (affordable to prestige) on one axis and routine complexity (minimal to maximal) on the other. Plot your five competitors. If four of them cluster in one quadrant, that quadrant is the crowded middle. The empty quadrant is not automatically your opportunity — it may be empty because no one wants it — but it is where you should look first, and then validate with real conversations.

## Validating with real people

Positioning is a hypothesis until real people confirm it. Before you spend money on packaging or a photoshoot, have ten conversations with people who match your target customer. Not friends who will be polite. People who actually have the problem.

Ask them: What do you use now? What frustrates you about it? What have you tried that did not work? What would the perfect version look like? How much would you pay for it? Where do you discover new beauty products? Then listen for the exact words they use. Your marketing copy should sound like your customers talking, not like a brand talking about itself. If three or more people describe the problem in the same words, you have found your language. Use those words in your positioning sentence, your website, and your emails.

**Module 1 exercise:** Complete the Positioning Worksheet in the workbook. Write your positioning sentence, map five competitors, and list ten people you will interview. Do not move to Module 2 until the sentence passes the stranger test.

---

# Module 2 — Pricing and Margins: Building a Price That Actually Pays You

## Why founders underprice

Almost every first-time beauty founder underprices. The reasons are always the same: fear that no one will buy at a higher price, a guess based on what competitors charge, or a price set by working backward from a "nice round number." The result is a brand that sells and still loses money, because the price never covered the real cost of making, shipping, and selling the product — let alone the cost of acquiring the customer.

Pricing is not a guess. It is arithmetic. This module teaches you the build-up: every cost, in order, from raw materials to the customer's doorstep, and then the margin you need on top to run a business rather than a hobby.

## The cost build-up

Start with the **landed cost per unit**: everything it costs to have one finished, sellable unit in your hands.

1. **Formula and ingredients** — the cost of the formula itself, per unit.
2. **Packaging** — the bottle, jar, cap, pump, label, box, and any insert, per unit.
3. **Filling and assembly** — what the lab or manufacturer charges to fill, cap, label, and pack, per unit.
4. **Freight and duties** — shipping the finished goods to you, divided by the number of units.
5. **Payment processing and platform fees** — what your checkout and marketplace take per sale (often a percentage plus a fixed fee).
6. **Shipping to the customer** — the carrier cost, packaging materials, and any free-shipping subsidy you absorb.

Add those together and you have your landed cost. Everything else — your time, your marketing, your returns — is paid from the margin above that number.

### Worked example: a face serum

These numbers are illustrative teaching figures, not market data. Replace them with your own quotes.

| Cost item | Per unit |
|---|---|
| Formula and ingredients | $4.20 |
| Bottle, pump, label, box | $3.10 |
| Filling and assembly | $1.40 |
| Freight to you (per unit) | $0.85 |
| Payment processing (3% + $0.30 on a $48 price) | $1.74 |
| Shipping to customer (subsidized) | $2.50 |
| **Landed cost per unit** | **$13.79** |

Now look at what different retail prices do to that unit:

| Retail price | Gross margin per unit | Gross margin % |
|---|---|---|
| $28 | $14.21 | 51% |
| $38 | $24.21 | 64% |
| $48 | $34.21 | 71% |
| $58 | $44.21 | 76% |

At $28 you keep $14.21 per sale before marketing, returns, samples, discounts, and your own time. If it costs you $12 to acquire a customer, you have $2.21 left. At $48, the same $12 acquisition cost leaves you $22.21. That is the difference between a business and a treadmill. Price is the single most powerful lever in your business, and it is the one founders are most afraid to pull.

## The margin ladder

Your retail price does not all belong to you. If you ever want to sell wholesale to a retailer, through a distributor, or through an affiliate or influencer who takes a commission, each of those hands takes a cut. Build your price so the ladder works:

- **Direct-to-consumer (your own site):** you keep the full margin above landed cost.
- **Wholesale:** retailers typically expect to buy at roughly 50% of retail. If your retail price is $48 and your landed cost is $13.79, your wholesale margin is $24.00 − $13.79 = $10.21 per unit. Workable.
- **Distributor:** a distributor may take a further cut, leaving you with 30–40% of retail. At $48 retail, that is $14.40–$19.20 against a $13.79 landed cost — barely anything. This is why many brands cannot afford distribution at their launch price.
- **Affiliate or influencer commission:** 10–20% of the sale price. At 15% on $48, that is $7.20, leaving you $27.01 after landed cost.

The rule: **set your retail price so that the thinnest channel you plan to use still leaves you a real margin.** If you plan to wholesale one day, price for wholesale on day one. Raising prices later is far harder than launching at the right price.

## Pricing psychology that is honest

A few principles that work without manipulation:

- **Price signals quality in beauty.** A $12 serum and a $48 serum are judged differently before anyone opens the bottle. If your formula, packaging, and experience are premium, a low price creates suspicion, not excitement.
- **Anchor with a set or bundle.** A single product at $48 feels different next to a three-step ritual at $118 (a genuine saving versus buying separately). Bundles raise average order value and give customers a reason to try more of your range.
- **Charm pricing is optional.** $48 and $47.50 both work. Pick one and be consistent. Do not use fake "was $96, now $48" pricing — it erodes trust and can breach advertising rules.
- **Never compete on price alone.** There is always someone cheaper, and they can always go cheaper than you. Compete on the specific problem you solve (Module 1) and let price reflect that value.

## Discounts: the margin killer

A 20% discount on a $48 serum does not cost you 20% of your profit — it costs you far more, because your costs do not shrink. At a $13.79 landed cost, your margin at $48 is $34.21. At 20% off ($38.40), your margin is $24.61 — a 28% cut in profit for a 20% cut in price. At 40% off, your margin falls to $14.99, more than half gone.

Rules for discounting:

- Discount rarely, with a clear reason (launch week, a genuine seasonal event), and always with an end date.
- Never discount your hero product below the price that keeps your thinnest channel profitable.
- Prefer value-adds over price cuts: a free sample, a travel size, free shipping over a threshold. These cost you less and feel generous rather than desperate.
- Track the margin impact of every promotion in the calculator before you approve it, not after.

## The pricing and margin calculator

The templates folder includes `pricing-margin-calculator.csv`. It is a spreadsheet with formulas: enter your costs and your price, and it computes landed cost, gross margin in dollars and percent, wholesale margin, distributor margin, and affiliate margin, plus the margin impact of a discount. Use it for every product and every promotion. If the calculator says a price does not work, believe the calculator.

**Module 2 exercise:** Fill in the calculator with your real costs. Set three candidate prices and compare the margin ladder for each. Choose the price that keeps your thinnest planned channel profitable, and write down the discount rules you will follow.

---

# Module 3 — The 90-Day Sequenced Launch: How a Launch Really Works

## Launch is a campaign, not a day

The single biggest mistake new beauty founders make is treating launch as a single event: the day the website goes live and the Instagram post goes up. Then the post gets a handful of likes, a few friends buy, and silence follows. The founder concludes the product failed. Usually the product did not fail — the launch did, because nobody knew it was coming.

A launch is a sequenced campaign, typically 90 days, with a job to do in each phase. The customer needs to hear about your brand several times, in different places, before she buys. She needs to understand the problem you solve, believe you can solve it, and be given a clear moment to act. No single post does all of that.

The 90 days break into four phases:

| Phase | Days | Job |
|---|---|---|
| Tease | 1–21 | Make the problem visible; build curiosity |
| Build | 22–56 | Grow the waitlist; prove you understand the customer |
| Pre-sell | 57–83 | Convert waitlist attention into committed buyers |
| Launch | 84–90 | Open the doors; sell, serve, and gather proof |

Each phase has its own content, its own metric, and its own definition of success. The full day-by-day plan is in `templates/90-day-launch-calendar.md`.

## Phase 1 — Tease (Days 1–21)

The job of the tease phase is not to sell. It is to make the problem visible and to attach your name to it. Three weeks of content that talks about the problem your customer already feels, in her words, without revealing the product yet.

What to post: the frustration (hands that crack by mid-shift; hair that falls flat by noon; foundation that breaks you out), the failed solutions you tried, the questions you are asking, behind-the-scenes glimpses of the work without showing the finished product. Short video works well here — a 30-second clip of a real problem beats a polished brand film nobody asked for.

The metric for this phase is not sales. It is **reach and saves**: are strangers stopping, watching, and saving? A save means "I have this problem and I want to come back to this." Track saves per post, not likes. Likes are cheap; saves are intent.

End the phase with a clear next step: a waitlist. One page, one promise, one email field. The promise should be specific: "Join the waitlist and get early access plus 15% off launch day." Do not ask for more than an email address. Every extra field costs you sign-ups.

## Phase 2 — Build (Days 22–56)

Now the audience grows on purpose. The job is to grow the waitlist and prove you understand the customer better than anyone else.

Content shifts from the problem to the process: how you chose the formula, why you rejected the obvious ingredient, what your testers said, the texture, the scent, the packaging decisions. Show your face. Founders who hide behind a logo grow slower than founders who show up — the customer is buying from a person she trusts, especially when the brand is new.

Tactics that work in this phase:

- **A lead magnet with a real payoff.** Not a generic "beauty tips" PDF. Something tied to your problem: "The 7-Day Hand Rescue Routine for Shift Workers," "The Fine-Hair Volume Checklist." It should be genuinely useful even if the reader never buys.
- **A weekly live or Q&A.** Thirty minutes, same time each week, answering real questions. Record it and cut the best minute into a short clip.
- **Early tester stories.** Give the product to five to ten people who match your target customer — not influencers yet, real users — and document their honest experience over two weeks. Their words become your launch copy.
- **A countdown with substance.** "21 days until launch" means nothing on its own. "21 days until launch — today we reveal the texture" gives people a reason to come back.

The metric for this phase is **waitlist growth rate and email open rate**. You want a waitlist that opens your emails, not a large list that ignores you. If your open rate is below 25%, your list is either the wrong people or your subject lines are not speaking their language. Fix that now, while the list is small.

## Phase 3 — Pre-sell (Days 57–83)

This is the phase most founders skip, and it is the one that makes launch day work. Pre-selling means getting commitment — money, or a firm reservation — before the product is available to the general public.

The mechanism is simple: the waitlist gets first access, a limited window, and a reason to act now. A founding-member offer works well: a limited number of units at a launch price, or a bundle that will not be available again. Scarcity must be real — a genuine limited first batch, not a fake countdown timer. Customers can tell the difference, and fake scarcity destroys the trust you spent eight weeks building.

The 12-email pre-sell sequence in this playbook (`templates/presell-email-sequence.md`) runs across this phase and into launch week. It is sequenced deliberately: problem, story, proof, education, offer, reminder, last call. Each email has one job and one call to action. Do not send all twelve in a week; the sequence is paced so the customer hears from you often enough to remember you and rarely enough to stay glad to hear from you.

The metric for this phase is **pre-sell conversion rate**: what percentage of the waitlist takes the pre-sell offer. A healthy range for a warm, well-built waitlist is 5–15%. If you have 500 people on the waitlist and 10% convert, that is 50 orders before launch day — and 50 customers who will post, review, and tell friends.

## Phase 4 — Launch (Days 84–90)

Launch week is the payoff, not the start. The doors open to the waitlist first (usually 24–48 hours early), then to the public. Your job this week is volume of proof: every order, every unboxing, every first impression, shared the same day. Repost customer content with permission. Answer every comment and every direct message within hours, not days. A new brand's customer service is its marketing.

Plan the week day by day (the calendar gives you the full plan): launch-day announcement, founder story, how-to-use, tester results, frequently asked questions, and a final call before the launch offer ends. Then stop. Do not extend the launch offer because sales slowed — extending a deadline teaches your audience that your deadlines are not real.

The metric for launch week is **orders, conversion rate, and average order value**. But the metric that matters most for the next ninety days is **reviews**: how many buyers left a review within two weeks, and what they said. Reviews are the asset that makes the second launch easier than the first.

## What if you have no audience at all?

Start anyway, and start smaller. The 90-day plan works from zero — it is designed for founders with no audience. But be honest about the math: if you start from zero and grow a waitlist of 200 people, a 10% conversion rate is 20 orders. That is a real launch. Twenty customers who love the product are worth more than two thousand followers who never buy. The plan scales with the audience you build; it does not require one to begin.

## The launch calendar as a discipline

Print the 90-day calendar and put it where you work. Each day has one primary action. If you miss a day, do not try to do two days at once — just do the next day's action. Consistency beats intensity. A founder who posts three times a week for ninety days outperforms a founder who posts ten times in launch week and then disappears.

**Module 3 exercise:** Fill in the Launch Calendar Checklist in the workbook with your actual dates. Day 1 is the day you start, not the day you feel ready. Write down your waitlist page promise and your founding-member offer.

---

# Module 4 — Pre-Launch Audience Building: From Zero to a Waitlist That Buys

## The waitlist is the business

Your social following is rented land. The platform decides who sees your posts, and it can change the rules tomorrow. Your email list is land you own. The waitlist is the single most valuable asset a pre-launch brand can build, because it is a list of people who raised their hand and said, "Tell me when this is ready."

A waitlist of 300 people who open your emails is worth more than 10,000 followers who scroll past you. Every module after this one depends on the waitlist: the pre-sell sequence goes to it, the launch offer goes to it, and the first reviews come from it. If you only do one thing in the ninety days before launch, build the waitlist.

## Where the first hundred come from

Founders often ask where to find their first hundred subscribers when they have no audience. The answer is unglamorous: one-to-one conversations, in places your customer already gathers.

- **Your own network, honestly.** Not a mass blast to everyone you know. A personal message to people who actually match your customer: "I'm building a hand cream for people who wash their hands all day — is that you, or do you know someone it would help?" A personal ask converts far better than a broadcast.
- **Communities your customer already trusts.** Nursing forums, hair forums, skincare groups, subreddits, Facebook groups. Join first, contribute second, share third. Read the group's rules; many forbid promotion, and violating them burns the very people you want to reach. Offer something useful — answer a question, share a routine — and let people find the waitlist in your profile.
- **Content that solves a small problem now.** A 60-second video on "how to stop your hands cracking on a twelve-hour shift" earns an email address. A post that says "buy my cream" does not. Give the small win first; the product is the bigger win later.
- **Other people's audiences.** A guest post, a podcast interview, a collaboration with a complementary brand (a glove maker, a salon, a uniform supplier). You borrow trust, you do not buy it.
- **Offline, if your customer is offline.** A card at a salon, a flyer at a nursing station (with permission), a sample at a local market. Beauty is still discovered in person, and a conversation converts better than a click.

Do not buy an email list. Do not run a generic giveaway that attracts people who want free things rather than your product. A giveaway for a $200 gift card will fill your list with people who will never buy a $48 serum. If you run a giveaway at all, give away your own product to people who match your customer — and make entry require an email address and an answer to one qualifying question.

## The waitlist page

Your waitlist page has one job: convert a visitor into an email address. Keep it ruthlessly simple.

- **A headline in the customer's words.** The problem, not the product: "Hands that survive a twelve-hour shift."
- **Three short lines.** Who it is for, what it does, when it launches.
- **One email field and one button.** The button should say what the person gets: "Join the waitlist," "Get early access."
- **The incentive, stated plainly.** Early access plus a launch discount, or a free sample with the first order. State the incentive and the limit if there is one.
- **One image.** The product, the texture, or the founder — something real, not a stock photo.

Do not add navigation, a blog, a shop, or social links to the waitlist page. Every link is an exit. The page should have exactly one path forward.

## Content that builds an audience before you have a product

You can publish for ninety days before your product exists, because the content is about the problem and the process, not the product. A content plan for the pre-launch period uses four repeating pillars:

1. **Problem content.** The frustration, in the customer's words. Short video, a relatable story, a poll asking which problem bothers them most. This content gets saved and shared, because people share content that describes their own life.
2. **Process content.** How the product is being made: choosing the formula, testing textures, rejecting a supplier, designing the label. This builds trust and creates a sense of ownership — followers feel they helped build it.
3. **Proof content.** Tester results, before-and-after stories (with honest, non-medical framing), answers to questions your audience asked. Proof is what turns interest into a waitlist sign-up.
4. **Person content.** You, the founder. Why you started, what you gave up, what you believe. People buy from people, and a founder who shows up is the cheapest competitive advantage a new brand has.

Post three to five times a week across your main channel, and repurpose each piece: a video becomes a short clip, a quote graphic, and an email. One idea, three formats. Do not try to be on every platform. Pick the one where your customer spends time — usually Instagram or TikTok for beauty — and do it well. Add a second platform only when the first is working.

## The weekly rhythm

A sustainable pre-launch week looks like this:

- **Monday:** problem or education post.
- **Wednesday:** process or behind-the-scenes post.
- **Friday:** proof or founder post, plus the weekly email to the waitlist.
- **Daily:** 15 minutes of genuine engagement — reply to comments, answer questions, comment thoughtfully on other people's posts in your niche. Engagement is not a chore to automate; it is how strangers become subscribers.

The weekly email to the waitlist matters more than any single social post. Keep it short: one story, one useful tip, one update on the launch, one call to action. People who open your emails every week are the people who will buy on launch day. Watch your open rate and your click rate; they tell you whether your list is warm or merely large.

## Measuring audience building honestly

Vanity metrics — follower count, likes — feel good and mean little. Track these instead:

| Metric | What it tells you | Healthy sign |
|---|---|---|
| Waitlist sign-ups per week | Whether your content converts | Steady growth, not spikes |
| Email open rate | Whether the list cares | 30%+ on a warm pre-launch list |
| Email click rate | Whether they act | 3%+ |
| Saves per post | Whether content resonates | Rising over time |
| Replies and DMs | Whether people trust you enough to talk | Any genuine conversation |

If sign-ups are flat, the problem is usually the offer or the call to action, not the content. Make the waitlist promise more specific, make the incentive clearer, or ask directly: post "Comment WAITLIST and I'll send you the link" and see who responds.

**Module 4 exercise:** Set up the waitlist page using the structure above. List five communities where your customer gathers and three complementary brands or creators you could collaborate with. Write your first four weeks of content pillars.

---

# Module 5 — Influencer Outreach: A Pipeline, Not a Prayer

## Why most influencer outreach fails

Most founders send the same message to fifty influencers: "Hi! I love your content! I'd love to send you our product!" The influencer, who receives twenty such messages a day, deletes it. Then the founder concludes influencer marketing does not work.

Influencer outreach fails for predictable reasons: the influencer's audience is not your customer, the message is generic, the ask is too big for a first contact, or there is no follow-up. This module replaces hope with a pipeline: find the right people, approach them in the right order, offer something worth their time, and track every conversation until it produces content or a clear no.

## The right influencer is smaller than you think

For a new beauty brand, the most valuable partners are usually not the accounts with a million followers. They are the micro-creators with 2,000 to 50,000 followers whose audience trusts them and matches your customer. A nurse who posts about shift-life skincare to 8,000 followers will sell more of your hand cream than a celebrity with two million followers who posts about everything.

Evaluate a creator on four things:

1. **Audience match.** Read their comments. Do their followers sound like your customer? Do they ask about the problem you solve? A creator whose followers are mostly other creators is not your channel.
2. **Engagement quality.** Look at comments, not likes. Are followers asking questions, tagging friends, saying "I need this"? Ten genuine comments beat a thousand likes.
3. **Content fit.** Does your product fit naturally into what they already post? If they have never talked about hand care, your hand cream will feel like an ad, and their audience will treat it like one.
4. **Consistency and reliability.** Do they post regularly? Do they reply to comments? Do they disclose partnerships properly? A creator who disappears for a month is a risk to your launch timeline.

Build a list of fifty creators who pass these tests before you message anyone. Fifty, because roughly half will not reply, and of those who do, a fraction will be a genuine fit. A pipeline of fifty becomes ten conversations, which becomes three to five pieces of content. That is a realistic funnel.

## The outreach sequence

Never open with the ask. The sequence has four stages, and the templates folder contains a script for each:

**Stage 1 — Warm-up (one week before you pitch).** Follow the creator. Watch their content. Leave two or three genuine comments on their posts — comments that show you actually watched, not "Love this!" A creator notices a name that keeps appearing with thoughtful comments.

**Stage 2 — The pitch.** A short, specific direct message or email. The script structure: one line that proves you know their work (reference a specific post), one line about who you are and what your product does for their audience, one clear ask (would they like to try it?), and one line about what is in it for them. Keep it under 150 words. Long pitches do not get read.

**Stage 3 — The follow-up.** If there is no reply in five to seven days, send one polite follow-up. One. Then move on. Chasing a creator who is not interested wastes your time and annoys them. The follow-up script is in the templates — short, gracious, and easy to answer with a yes or a no.

**Stage 4 — Gifting and the affiliate offer.** If they say yes, send the product with a short handwritten-style note (a card, not a printed flyer), a one-page guide to the product, and no pressure to post. Creators post honestly about products they genuinely like; pressure produces stiff, obviously sponsored content that nobody trusts. After they post — or after they tell you they liked it — offer an affiliate arrangement: a personal discount code or link and a commission on sales. The affiliate offer turns a one-time post into an ongoing partnership, and it aligns incentives: they earn when you earn.

## What to offer, and what not to offer

- **Gifting alone** is appropriate for a first contact with a smaller creator. You are asking them to try something, not to work for free.
- **Paid posts** are appropriate when you want a guaranteed deliverable, a specific timeline, or a larger creator. Agree the deliverable, the timeline, the usage rights, and the fee in writing before the product ships. A simple written agreement protects both sides.
- **Affiliate commission** is appropriate as an ongoing arrangement. A typical range for beauty is 10–20% of the sale price. Give the creator a personal code so their audience gets a benefit and you can track their sales.
- **Do not offer "exposure."** It is not compensation, creators know it, and it signals that you do not value their work.
- **Do not ask for a guaranteed positive review.** You can ask for an honest review. You cannot buy a positive one, and asking for one destroys credibility if it ever comes out.

## Disclosure is not optional

In the United States, the Federal Trade Commission requires creators to disclose a material connection — free product, payment, commission — clearly and conspicuously. A disclosure buried in a hashtag list is not enough. Your outreach should include a plain-language reminder: "Please disclose that the product was gifted and that you may earn a commission." Other countries have equivalent rules. Build disclosure into your process from the first gifted product, and keep a record of every gifted and paid arrangement.

## Tracking the pipeline

The workbook includes an Influencer Tracker, and you should use it from day one. For each creator, record: name, platform, handle, follower count, audience fit notes, date first contacted, pitch sent, follow-up sent, reply, product shipped, posted, affiliate code, sales attributed, and next step. Review the tracker weekly. A pipeline you do not review is a list you forget.

A realistic target for a first launch: fifty creators contacted, fifteen replies, eight products shipped, four to five posts, one or two ongoing affiliate partners. Those numbers are a planning guide, not a promise — your results will vary. The point is that the pipeline is measurable, and when it underperforms you can see exactly where it broke down: too few contacts, too few replies, too few shipments, or too few posts.

**Module 5 exercise:** Build your list of fifty creators using the four evaluation criteria. Send five warm-up engagements this week — no pitches yet. Customize the pitch, follow-up, gifting, and affiliate scripts in the templates folder with your brand's details.

---

# Module 6 — The Pre-Sell Funnel: Turning Attention Into Orders Before Launch Day

## What a pre-sell funnel is

A funnel is simply the path a stranger walks from first hearing about you to buying. The pre-sell funnel has five steps:

1. **Discovery** — they find your content, a creator's post, or a recommendation.
2. **Waitlist** — they give you their email address in exchange for early access.
3. **Education** — the email sequence teaches them the problem, the story, and the proof.
4. **Offer** — they are invited to buy before the general public, at a launch price or with a founding-member benefit.
5. **Purchase** — they check out, and you have a customer before launch day.

Most founders build only steps 1 and 5: content, then a shop. Steps 2, 3, and 4 are where the money is made, because they are where trust is built and commitment is won.

## The funnel pages

You need four pages, and none of them needs to be fancy:

- **The waitlist page** (Module 4): one email field, one promise.
- **The thank-you page:** confirm the sign-up, set expectations ("You'll get one email a week until launch, then first access"), and offer one immediate action — share the waitlist with a friend, or follow you on your main channel. A referral incentive (a small bonus for both parties if a friend joins) can double your list growth, but only offer what you can deliver.
- **The pre-sell page:** this is where the waitlist buys. It shows the product, the price, the founding-member benefit, the number of units available, and the deadline. It must answer the three questions every buyer asks: What is it? Will it work for me? What happens if it does not? The answers are your positioning, your tester proof, and your guarantee.
- **The checkout:** keep it to as few steps as possible, offer the payment methods your customers expect, and confirm the order immediately with an email that tells them exactly what happens next — when it ships, how they will be updated, and how to reach you.

## The 12-email pre-sell sequence

The full sequence, written out, is in `templates/presell-email-sequence.md`. Here is the architecture so you understand why each email exists:

| # | Job | Timing |
|---|---|---|
| 1 | Welcome — the problem, the promise, what happens next | Immediately on sign-up |
| 2 | The founder story — why you built this | Day 2 |
| 3 | The problem, deepened — your customer's words | Day 5 |
| 4 | The science and the formula — what is inside and why | Day 9 |
| 5 | The tester story — real people, honest results | Day 13 |
| 6 | How to use it — the ritual, step by step | Day 17 |
| 7 | The comparison — what makes this different | Day 21 |
| 8 | The questions — answer the objections before they are asked | Day 25 |
| 9 | The offer opens — founding-member access, first batch | Day 29 |
| 10 | Proof and urgency — what early buyers are saying | Day 32 |
| 11 | Last call — the window closes tonight | Day 35 |
| 12 | Thank you and what's next — for buyers and for those who waited | Day 36 |

Notice the shape: eight emails of value before the first offer. If you pitch in email two, you train your list to ignore you. If you deliver value for four weeks and then make a clear, time-limited offer, the offer feels like a reward for paying attention, not an interruption.

Every email follows the same discipline: one story or idea, one useful takeaway, one call to action. Write in the second person, in the customer's language, at a reading level a busy person can follow on her phone. Keep subject lines under fifty characters and honest — a subject line that promises something the email does not deliver is a fast way to lose a subscriber.

## Founding-member offers that work

A founding-member offer gives the earliest buyers something the general public will not get. It must be genuine and deliverable:

- **A launch price** on the first batch, with the regular price stated alongside it. The launch price should still protect your margin (Module 2).
- **A bundle that will not return**, such as the hero product plus a travel size.
- **Early access** — 48 hours before the public launch.
- **A founding-member bonus**, such as a sample of a future product or a handwritten thank-you note.

Pick one or two of these, not all four. An offer with too many pieces is confusing, and confusion kills conversion. And set a real limit: a number of units, or a date. When the limit is reached, close the offer. Your next launch depends on your audience believing your limits.

## Handling objections before they are asked

Every buyer has objections. The sequence answers them before launch day:

- **"Will it work for me?"** Tester stories from people like her, and a clear statement of who the product is for — and who it is not for.
- **"Is it worth the price?"** The cost-per-use framing: a $48 serum used daily for three months costs about fifty cents a day. Use real arithmetic from your own product; do not invent comparisons.
- **"What if I don't like it?"** A clear guarantee and return policy, stated on the pre-sell page and in the email. A 14-day guarantee is standard for this playbook. Make returns easy — a difficult return process costs you more in reputation than the refund costs you in cash.
- **"Is it safe for my skin?"** A full ingredient list, a note about patch testing, and an honest statement that no cosmetic can be guaranteed suitable for every person. Never claim a product is safe for everyone, and never make medical claims.

## The numbers that tell you the funnel works

- **Waitlist-to-offer conversion:** the percentage of the waitlist who buy during pre-sell. A warm list converts at roughly 5–15%.
- **Email-to-purchase rate:** purchases divided by emails delivered in the offer window.
- **Average order value:** total pre-sell revenue divided by orders. Bundles and a free-shipping threshold raise this.
- **Refund rate:** refunds divided by orders. A rate above 5% is a signal to examine the product, the expectation set by your marketing, or both.

If conversion is low, the cause is usually one of three things: the list was built from the wrong people, the offer was unclear, or the emails did not build enough trust before the pitch. The sequence in this playbook is designed to prevent the third problem. The first two are positioning and audience work — Modules 1 and 4 — and they cannot be fixed by a better email.

**Module 6 exercise:** Set up the four funnel pages. Customize all twelve emails in the templates folder with your brand, your tester stories, and your real prices. Send email 1 to yourself and read it on your phone — if it feels long, cut it in half.

---

# Module 7 — Launch Week and the First 30 Days of Sales

## Launch week, day by day

Launch week is the most visible week of your brand's life, and it should be the most planned. Here is the shape of the week; the full day-by-day detail is in the launch calendar.

**Day 84 — Doors open to the waitlist.** Send the launch email first thing in the morning. Post the announcement on your main channel. The message is simple: it is here, this is the price, this is what you get, and the founding-member offer ends on a stated date. Then spend the day answering questions and sharing every order and unboxing that comes in (with the buyer's permission).

**Day 85 — The founder story.** A longer post or video about why you built this. Not a press release — a story with a specific moment: the shift when your hands cracked, the morning your hair would not cooperate, the foundation that broke you out before a big day. Stories are remembered; feature lists are not.

**Day 86 — How to use it.** A demonstration: the texture, the amount, the order of steps, the result. Customers who know exactly how to use a product are more likely to buy it and less likely to return it.

**Day 87 — Tester results and reviews.** Share the first honest reviews. Include a less-than-perfect detail if there is one — "it took me three days to get used to the scent, and then I loved it" — because a review with a small honest caveat is more believable than five perfect ones.

**Day 88 — Questions answered.** The five most common questions from your inbox and comments, answered plainly. This post also serves the people who are close to buying and need one last reassurance.

**Day 89 — The public opening.** If the waitlist window has closed, open to the public with a fresh announcement. Repost the best creator content from the launch.

**Day 90 — Last call.** The founding-member offer ends tonight. One email, one post, one clear deadline. Then close it, as promised.

## Customer service is launch marketing

In launch week, your response time is your reputation. A new brand that answers a question in twenty minutes earns a customer for life; a new brand that answers in three days earns a screenshot in a group chat about brands that ignore people.

Set up before launch week:

- A dedicated email address or inbox for customer questions, checked three times a day during launch week.
- Canned answers for the ten questions you expect (shipping time, ingredients, how to use it, returns, the guarantee), written in your voice so they do not sound canned.
- A plan for problems: a damaged shipment, a wrong item, a reaction to the product. Decide in advance that you will make it right quickly — replace or refund, no argument — and say so publicly when it happens. How a brand handles a problem is remembered longer than the problem itself.

If a customer reports a skin reaction, take it seriously and respond with care: ask them to stop using the product, suggest they consult a healthcare professional if symptoms persist or worsen, and offer a refund or replacement. Do not diagnose, do not minimize, and do not argue about the cause. Keep a record of every such report.

## The first 30 days after launch

Launch week ends. The business begins. The thirty days after launch have three jobs:

**1. Collect proof.** Ask every buyer for a review two weeks after delivery — not the day the order arrives, when they have not used it yet. One email, one link, one question: "What changed for you?" Offer nothing in exchange for a positive review; you may offer a small thank-you for an honest review regardless of what it says, and you must say so plainly if you do. Display reviews prominently, including the critical ones, with your response.

**2. Keep the conversation going.** The waitlist that did not buy is not a failure — it is next month's customers. Send them a weekly email: new reviews, answers to questions, a tip related to the problem you solve. Do not discount immediately to win them back; a brand that discounts the week after launch trains its audience to wait for the next discount.

**3. Watch the numbers.** Every week, update the Launch Metrics Dashboard (Appendix A and the workbook): orders, revenue, conversion rate, average order value, refund rate, waitlist size, email open rate, traffic sources, and the top three questions customers ask. The numbers tell you what to fix. If traffic is high and conversion is low, the offer or the page needs work. If conversion is high and traffic is low, you need more discovery. If refunds cluster around one complaint, the product or the expectation needs work.

## Paid advertising: an optional accelerator, not a rescue

You can run this entire playbook without paid ads. If you choose to advertise, do it after launch week, when you have reviews, a converting page, and a clear picture of who buys. Start small — a modest daily budget on one platform, one creative, one audience — and judge it on cost per acquisition against your margin, not on clicks or impressions. If your margin per order is $34 and your cost per acquisition is $40, the ads are losing money no matter how good the click-through rate looks. Kill the ad, fix the offer or the creative, and test again. Never scale an ad that loses money on the first sale unless you have a proven repeat-purchase rate that justifies it — and as a new brand, you do not have that data yet.

## The post-launch content shift

After launch, your content shifts from "coming soon" to "here is what happens when you use it." The four pillars become: customer stories, education about the problem, new uses and routines, and behind-the-scenes of running the brand. Keep posting three to five times a week. The founders who go quiet after launch week lose the audience they spent ninety days building, and rebuilding it costs more than maintaining it.

**Module 7 exercise:** Write your launch-week posts in advance — all seven days — before Day 84 arrives. Set up your customer-service inbox and your ten canned answers. Decide your review-request timing and write the request email now, while you have time to get the tone right.

---

# Module 8 — First-Sale Systems: What Happens After the First Order

## From launch to business

A launch is a sprint. A business is a system that produces orders, serves customers, and learns — week after week, without the founder working every waking hour. This final module installs the systems that carry you past the first sale.

## The five systems

**1. The order system.** From checkout to doorstep, every step should be written down: order confirmation email, packing, label, tracking email, delivery follow-up. Write the checklist once and follow it every time. As volume grows, the checklist becomes the training document for anyone who helps you. Track your average time from order to shipment; customers forgive a lot, but they do not forgive silence. If a shipment will be late, tell the customer before she has to ask.

**2. The customer system.** Every buyer goes into your email list, tagged by what they bought and when. They receive: a thank-you and usage guide immediately, a check-in at one week ("How is it going? Reply to this email"), a review request at two weeks, and a replenishment reminder timed to when the product should be running low (calculate this from the product size and typical daily use — do not guess). Replenishment reminders are the quiet engine of a beauty brand: a customer who loved the product simply needs to be reminded at the right moment.

**3. The content system.** One idea, three formats, three to five posts a week (Module 4). Keep a running list of content ideas — customer questions, tester stories, ingredient explanations, founder moments — and add to it every time a customer says something interesting. Batch your content: one hour on Sunday to draft the week's posts is more sustainable than inventing a post every morning.

**4. The creator system.** The influencer pipeline from Module 5 does not stop at launch. Each month, add ten new creators to the list, follow up with the ones who posted, and deepen the relationship with the one or two whose audiences actually bought. A creator who sold ten units in launch month is worth more than ten creators who posted once and disappeared. Send your best creators new products first, thank them publicly, and pay them on time — always.

**5. The money system.** Every week, update a simple ledger: revenue, cost of goods, shipping, fees, advertising, refunds, and net. Every month, reconcile it against your bank and payment processor. Set aside money for taxes from the start — talk to a tax professional about what applies to your business structure and location, and do not spend tax money as if it were profit. The margin calculator from Module 2 is a planning tool; the ledger is the truth.

## Repeat purchase: the metric that decides everything

In beauty, a brand lives or dies on whether customers come back. A one-time buyer who never returns costs you the full acquisition cost against a single margin. A customer who buys four times a year is worth four margins against one acquisition cost.

The drivers of repeat purchase are simple and unglamorous: the product works as promised, the reorder is easy, the reminder arrives at the right time, and the customer feels remembered. A short personal note in the second order — "Welcome back, Maya" — costs you a minute and earns you a customer. A subscription or subscribe-and-save option can help, but only offer it when your fulfillment is reliable; a subscription that ships late is worse than no subscription at all.

Track your repeat purchase rate: the percentage of first-time buyers who buy again within 90 days. In your first year, any rate above 20% is a sign the product and the experience are working. If it is below 10%, ask your buyers why — a short survey to past customers ("What stopped you from reordering?") will tell you more than any analytics dashboard.

## Planning the second launch

Your second launch is easier than your first, because you now have customers, reviews, and a list. Plan it 90 days after the first, and make it one of these:

- **A second product** that solves the next problem for the same customer (the companion to your hero product, not a random new idea).
- **A bundle or ritual set** built from what you already sell.
- **A limited edition** — a seasonal scent, a special shade, a holiday set — with a genuine limit.

Use the same 90-day calendar, the same email architecture, and the same creator pipeline. The difference is that this time you start with proof: real reviews, real before-and-after stories, and real customers who will buy on day one.

## When to change course

Not every product finds its market, and persistence is not always the right answer. Review the business honestly at 90 days after launch. If, after a full sequenced launch, you have fewer than a handful of repeat buyers, a refund rate above 10%, and no organic word of mouth — no one recommending you unprompted — the problem is usually the product-market fit, not the marketing. That is information, not failure. The positioning work in Module 1, done honestly with real customer conversations, is the cheapest way to find out before you spend more.

## Your next 8 weeks

The onboarding guide (`onboarding.md`) gives you a suggested 8-week schedule that walks through this course in order and ends with your launch date on the calendar. Print it, pin it up, and start on Monday. A launch is not a single brave day. It is ninety small days, done in order, by a founder who decided to treat launch as a campaign.

**Module 8 exercise:** Write down your five systems as checklists. Calculate your product's replenishment timing and write the reminder email. Schedule your 90-day review date now.

---

# Appendix A — Launch Metrics Dashboard: What to Measure and When

Use the Launch Metrics Worksheet in the workbook to track these weekly.

**Audience metrics:** waitlist size, weekly sign-ups, email open rate, email click rate, social followers, saves per post, replies and direct messages.

**Funnel metrics:** waitlist page conversion rate (visitors to sign-ups), email-to-purchase rate, pre-sell conversion rate, checkout completion rate.

**Sales metrics:** orders, revenue, average order value, units per order, refund rate, discount cost (total margin given away in promotions).

**Creator metrics:** creators contacted, replies, products shipped, posts published, clicks from creator links, sales attributed to creator codes, cost per creator post.

**Customer metrics:** new versus repeat buyers, repeat purchase rate at 30/60/90 days, review rate, average review score, top three customer questions, top three complaints.

**Review cadence:** audience and funnel metrics weekly during the 90 days; sales metrics daily during launch week, weekly after; customer metrics monthly. If a metric moves sharply, ask why before you change anything — a single week's data is noise, and a trend over three weeks is a signal.

---

# Appendix B — Compliance Checklist Before You Sell

This checklist is educational, not legal advice. Confirm every item against the rules in each market where you will sell, and consult a qualified professional where you are unsure.

- [ ] Full ingredient list on the label, in the order and format your market requires.
- [ ] Product name, net contents, and responsible company name and address on the label.
- [ ] No drug claims (treating, curing, or preventing disease) anywhere — label, website, social posts, or creator briefs.
- [ ] Safety substantiation for the product on file, appropriate to your market.
- [ ] Good manufacturing practice followed by you or your manufacturer, with batch records kept.
- [ ] Any required facility registration, product listing, or notification completed for your market.
- [ ] Allergen and warning statements included where required.
- [ ] Creator and affiliate disclosure instructions sent with every gifted or paid product.
- [ ] Privacy notice and terms for your email list and your store, including how customer data is used.
- [ ] Return and refund policy written, published, and honored.
- [ ] Records kept of every customer complaint, reaction report, and how it was resolved.
- [ ] Insurance reviewed with a professional, appropriate to selling cosmetics.

---

# Worked Example — A Full Launch, Start to Finish

This fictional example ties the whole playbook together. Every number is illustrative, invented to show the arithmetic — not market data and not a promise.

**The brand.** Amara, a fictional founder, is a former care worker who spent years washing her hands dozens of times a day. She formulates a fast-absorbing hand cream for shift workers. Her positioning sentence: "For nurses and care workers who wash their hands all day, Amara's is the hand cream that absorbs in ten seconds with no greasy residue, so they can moisturize between patients without slowing down."

**Pricing.** Her landed cost per unit is $11.60 (formula $3.40, packaging $2.90, filling $1.10, freight $0.70, payment processing $1.50 on a $42 price, subsidized shipping $2.00). She prices at $42. Gross margin is $30.40 per unit, or 72%. A wholesale buyer at 50% of retail ($21.00) still leaves her $9.40. A 15% affiliate commission ($6.30) leaves her $24.10. The price survives every channel she plans to use, so she launches at $42 and does not discount the hero product in the first year.

**The 90 days.** Amara starts with no audience. In the tease phase she posts three times a week about cracked hands, failed creams, and glove life, and her waitlist page promises early access and 15% off on launch day. By day 21 she has 120 subscribers. In the build phase she publishes a free guide, "The 7-Day Hand Rescue Routine," runs a weekly Q&A, and sends ten tester jars to nurses who match her customer. By day 56 the waitlist is 480 people and her weekly email open rate is 41%. In pre-sell she opens founding-member access to the first 100 buyers at $35.70 (the 15% launch discount), with the regular $42 price stated beside it. The 12-email sequence runs as written. Sixty-two waitlist members buy during pre-sell — a 13% conversion rate on the waitlist at that point — producing about $2,213 in pre-sell revenue before launch day.

**Launch week.** Doors open to the waitlist first, then the public. Amara answers every message within the hour, shares unboxing videos the same day, and posts tester reviews with one honest caveat included. Launch week brings 74 more orders. Average order value is $51 because a third of buyers add a second tube or a travel size. First-month totals: 136 orders, roughly $6,800 in revenue, a 2.9% refund rate (four orders, all handled with a replacement or refund within a day).

**The systems.** Amara installs the five systems from Module 8. Her replenishment reminder goes out at day 45, timed to a tube lasting about six weeks with twice-daily use. By day 90 after launch, 31 of her first 136 buyers have ordered again — a 23% repeat rate. Her second launch, a matching hand wash, uses the same calendar and the same creator pipeline, and starts with 136 customers instead of zero.

**What made it work.** Nothing exotic. The positioning was specific enough that a nurse could recognize herself in it. The price protected the margin. The launch was a sequence, not a post. The waitlist was built one conversation at a time. And the founder answered her customers. That is the whole playbook, and it is repeatable.

---

# Your First Monday — A Checklist to Begin

You do not need to feel ready. You need a start date and five small actions. Do these on your first Monday, before you buy anything or design anything:

1. Write your positioning sentence on one page and read it to a stranger. If they cannot tell you who the product is for, rewrite it until they can.
2. Phone or email your manufacturer or supplier and get your real per-unit costs in writing. Put them in the pricing calculator the same day.
3. Set up the waitlist page with one email field and one promise. Share it with five people who match your customer, personally, one message at a time.
4. List fifty creators whose audiences look like your customer. Follow ten of them and leave a genuine comment on something they posted this week.
5. Put Day 90 on your calendar, in ink, and work backward to today. A launch with a date is a plan. A launch without one is a wish.

Ninety days from now you will either have a launched brand or another three months of thinking about one. The difference is not talent, budget, or luck. It is the sequence, done in order, one day at a time.

---

*End of course. Now open the workbook and start Module 1.*
