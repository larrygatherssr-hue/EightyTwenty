# Pre-Sell Email Sequence — All 12 Emails

Customize every bracketed field with your brand's details, real prices, real tester stories, and real dates. The pacing is deliberate: eight emails of value before the first offer. Send from a real person's name, not a generic brand address. Each email has one story or idea, one useful takeaway, and one call to action.

**Send schedule:** Email 1 immediately on sign-up. Emails 2–8 spaced 3–4 days apart. Email 9 opens the offer. Emails 10–11 follow over the next 4 days. Email 12 goes out the day after the offer closes.

---

## Email 1 — Welcome: The Problem, the Promise, What Happens Next

**Subject:** You're in — here's what happens next
**Send:** Immediately on sign-up

Hi [First Name],

Thank you for joining the waitlist for [Product Name]. You're one of the first people to hear about it, and that matters to me — because I built this for people like you, not for a shelf.

Here's the problem I set out to solve: [describe the problem in the customer's words, e.g. "hands that crack and sting by the middle of a twelve-hour shift, and hand creams that feel greasy under gloves"].

Here's my promise: over the next few weeks, I'll send you one short email at a time — the story behind the product, what my testers honestly thought, and how to use it. Then, before anyone else, you'll get first access to buy, at a launch price that won't be available again.

No spam. One email a week, sometimes two. You can leave any time with one click.

For now, one question — just hit reply and tell me: what is the single most annoying thing about [the problem]? I read every reply.

Talk soon,
[Your Name]
Founder, [Brand Name]

P.S. Your early-access spot is saved. Launch day is [date].

---

## Email 2 — The Founder Story

**Subject:** Why I built this
**Send:** Day 2 after sign-up

Hi [First Name],

I want to tell you why [Product Name] exists.

[Write your real story here — 3 to 5 short paragraphs. The specific moment matters more than the summary. Example structure: the day the problem hit you personally; what you tried; what failed; the moment you decided to make something better; what you gave up to do it.]

I didn't set out to start a beauty brand. I set out to fix one annoying problem in my own life. Then I found out how many other people had the same problem, and I kept going.

Next time, I'll share what my testers said — including the parts I didn't want to hear.

[Your Name]

P.S. If you have a story like mine, hit reply. I read them all.

---

## Email 3 — The Problem, Deepened

**Subject:** Does this sound familiar?
**Send:** Day 5 after sign-up

Hi [First Name],

Last week I asked you what annoys you most about [the problem]. Your answers were remarkably similar. Here are three, in your words:

- "[Quote a real subscriber or interviewee, anonymized, e.g. 'By 3 p.m. my hands are so dry they catch on fabric.']"
- "[Second real quote.]"
- "[Third real quote.]"

If any of those sound like your day, you're not alone — and you're not imagining it. [One or two plain sentences about why the problem happens, in everyday language. No medical claims.]

Here's one thing that helps right now, whether or not you ever buy from me: [one genuinely useful tip, e.g. "Pat your hands dry instead of rubbing them, and moisturize while they're still slightly damp — it locks in more moisture than waiting until they're fully dry."]

More soon,
[Your Name]

---

## Email 4 — The Science and the Formula

**Subject:** What's inside — and why
**Send:** Day 9 after sign-up

Hi [First Name],

People ask me what's in [Product Name]. Here's the honest answer: [2–3 short paragraphs about your hero ingredients and why you chose them, in plain language].

- **[Ingredient 1]:** [What it does, plainly — e.g. "draws moisture into the skin and holds it there."]
- **[Ingredient 2]:** [What it does.]
- **[Ingredient 3]:** [What it does.]

And here's what we left out, and why: [e.g. "No added fragrance, because the people I built this for have sensitive skin and didn't ask for perfume — they asked for relief."]

The full ingredient list is on our website, and it will be printed on every box. If you have a known sensitivity, check the list and do a patch test first — that advice applies to any skincare product, including ours.

Next time: what my testers actually said after two weeks.

[Your Name]

---

## Email 5 — The Tester Story

**Subject:** What 10 real people thought
**Send:** Day 13 after sign-up

Hi [First Name],

Before I launched anything, I gave [Product Name] to [number] people who [describe them — e.g. "work twelve-hour shifts and wash their hands all day"]. I asked them to use it for two weeks and tell me the truth.

Here's what they said:

"[Tester quote 1 — specific, in their words, with first name and role if they agreed to be named.]"

"[Tester quote 2.]"

"[Tester quote 3.]"

And the honest part: not everyone loved everything. [One genuine caveat, e.g. "Two testers told me the tube was smaller than they expected. Fair — so I added a larger size to the launch."] I would rather you hear that from me now than discover it later.

These are real people, not paid reviewers. Nobody was paid for their opinion, and nobody was asked to say anything nice.

Next time, I'll show you exactly how to use it — the two-minute version.

[Your Name]

---

## Email 6 — How to Use It

**Subject:** The two-minute ritual
**Send:** Day 17 after sign-up

Hi [First Name],

[Product Name] works best as a small ritual, not a chore. Here's the whole thing — two minutes:

1. [Step 1 — e.g. "Wash and pat your hands dry, leaving them slightly damp."]
2. [Step 2 — e.g. "Squeeze out a pea-sized amount — a little goes a long way."]
3. [Step 3 — e.g. "Rub it in, including between your fingers and around your nails."]
4. [Step 4 — e.g. "Wait ten seconds. That's it — no residue, gloves back on."]

When to use it: [e.g. "Between hand washes during a shift, and once more before bed."]

One thing to avoid: [e.g. "Don't use it on broken skin — wait until any cracks have closed, and talk to a healthcare professional if you're unsure."]

That's the whole routine. Simple on purpose — the people I built this for don't have time for a ten-step process.

We're getting close now. Next time, I'll show you what makes this different from everything else on the shelf.

[Your Name]

---

## Email 7 — The Comparison

**Subject:** How this is different
**Send:** Day 21 after sign-up

Hi [First Name],

By now you've seen a lot of hand creams. So let me be direct about how [Product Name] compares.

Most hand creams are built for [the usual customer or use case]. They [the usual trade-off — e.g. "feel rich and luxurious, and leave a film on your skin for twenty minutes"]. That's fine if you're at home on the sofa. It's a problem if you're about to put gloves on.

[Product Name] is built for [your customer]. It [your difference — e.g. "absorbs in about ten seconds, leaves no residue, and has no added fragrance"]. The trade-off we made: [be honest about it — e.g. "it's not the thickest cream you'll ever use. If you want a heavy overnight mask, this isn't it."]

Here's a quick comparison:

| | Most hand creams | [Product Name] |
|---|---|---|
| Absorbs in | 10–20 minutes | About 10 seconds |
| Residue | Noticeable film | None |
| Fragrance | Usually added | None |
| Built for | General use | [Your customer] |

I'm not saying other creams are bad. I'm saying they were built for a different day than yours.

Next time, I'll answer the questions you've been sending me.

[Your Name]

---

## Email 8 — The Questions

**Subject:** Your questions, answered honestly
**Send:** Day 25 after sign-up

Hi [First Name],

You've been writing in with questions, so here are the five I hear most — answered plainly.

**1. Will it work for me?**
[Honest answer. State who it is for and who it is not for. No guarantees.]

**2. Is it worth [price]?**
[A $X product used [how often] lasts about [how long], which works out to about $[amount] a day. Use your real arithmetic.]

**3. What if I don't like it?**
[Your guarantee, stated plainly — e.g. "You have 14 days. If it's not for you, email us and we'll refund you. No forms, no argument."]

**4. Is it safe for sensitive skin?**
[Honest answer: full ingredient list available, no added fragrance if applicable, patch-test advice, and a plain statement that no cosmetic suits every person. Never claim safety for everyone.]

**5. When does it ship?**
[Your real shipping timeline, e.g. "Orders ship within 2 business days, and you'll get tracking by email."]

If your question isn't here, hit reply and ask me directly.

One more email after this, and then the doors open.

[Your Name]

---

## Email 9 — The Offer Opens

**Subject:** First access is open — [Product Name] is here
**Send:** Day 29 after sign-up (offer opens)

Hi [First Name],

It's here. [Product Name] is available to buy — and you're getting first access before anyone else.

Here's what you get as a waitlist member:

- **[Product Name] — [size] — $[launch price]** (regular price $[regular price])
- [Founding-member benefit, e.g. "A free travel size with your first order"]
- [Benefit, e.g. "Free shipping on orders over $[threshold]"]
- Early access: this offer is open to the waitlist only until [date and time]. After that, the price goes to $[regular price] and the founding-member benefit ends.

[Link to the pre-sell page — one clear button: "Get [Product Name]"]

A reminder of what it is: [one-line positioning, e.g. "the hand cream that absorbs in ten seconds with no greasy residue, built for people who wash their hands all day"].

And the guarantee: 14 days, full refund, no questions asked. If it's not for you, email us and we'll make it right.

Thank you for being here from the beginning. You helped build this — your answers, your questions, your patience. I hope you love it.

[Your Name]
Founder, [Brand Name]

P.S. The first batch is [number] units. When they're gone, the founding-member offer closes.

---

## Email 10 — Proof and Urgency

**Subject:** What early buyers are saying
**Send:** Day 32 after sign-up

Hi [First Name],

The first orders are going out, and the messages coming back have been better than I dared hope. A few, in buyers' own words:

"[Buyer quote 1 — real, with permission.]"

"[Buyer quote 2.]"

"[Buyer quote 3.]"

A quick update on the numbers: [honest status, e.g. "just over half of the first batch is spoken for"]. The founding-member offer — $[launch price] plus [benefit] — ends on [date and time].

If you've been meaning to order, now is the time. If you've decided it's not for you, that's completely fine — you'll still hear from me once a week, and there's no hard feeling.

[Link to the pre-sell page — "Get [Product Name]"]

Thank you,
[Your Name]

---

## Email 11 — Last Call

**Subject:** Tonight: the founding-member offer ends
**Send:** Day 35 after sign-up

Hi [First Name],

This is the last email about the founding-member offer, because tonight it ends.

At [time] tonight, [Product Name] goes to its regular price of $[regular price], and the [benefit] ends. The waitlist price of $[launch price] won't be available again.

[Link to the pre-sell page — "Get [Product Name] before tonight"]

If you're on the fence, here's my honest advice: the 14-day guarantee means you can try it and decide at home, not from a product page. If it's not for you, we'll refund you.

Thank you for reading these emails, whether you buy or not. It meant a lot to have you here for the launch.

[Your Name]

---

## Email 12 — Thank You and What's Next

**Subject:** Thank you — and what happens now
**Send:** Day 36 after sign-up (the day after the offer closes)

Hi [First Name],

The founding-member offer is closed, and I wanted to say thank you.

If you ordered: your order is [status — e.g. "being packed and will ship within 2 business days"]. You'll get tracking by email. In about two weeks I'll ask you what you thought — honestly, good or bad.

If you didn't order: thank you for reading, replying, and being part of this. I'll keep sending you one useful email a week — tips, answers to your questions, and news about what's next. The regular price is $[regular price] on our website whenever you're ready, and there's no pressure.

What's next for [Brand Name]: [one honest sentence about the next product, bundle, or restock].

Thank you for being here at the beginning. Brands are built by their first customers, and you're one of mine.

[Your Name]
Founder, [Brand Name]
