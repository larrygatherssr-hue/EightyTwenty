# Influencer Outreach Scripts

Customize every bracketed field before you send. Keep pitches under 150 words. Never send the same generic message twice — each creator should be able to tell you actually watched their work. These scripts are starting points, not copy-paste blasts.

**A note on disclosure:** In the United States, the Federal Trade Commission requires creators to disclose a material connection (free product, payment, or commission) clearly and conspicuously. Other countries have equivalent rules. Include a plain-language disclosure reminder with every gifted or paid product, and keep a record of every arrangement.

---

## 1. The Pitch (first contact)

**When to send:** After at least a week of warm-up — you have followed the creator and left two or three genuine comments on their posts.

**Where:** Email if they list one; direct message if they do not.

**Subject (email):** A product your audience asked for — [Your Brand Name]

Hi [Creator's first name],

I watched your [specific post or video — name it, e.g. "Tuesday video on getting through a double shift without your hands cracking"] and it stayed with me, because that is exactly the problem I built [Product Name] to solve.

I'm [Your Name], founder of [Brand Name]. We make [one-line description, e.g. "a fast-absorbing hand cream for people who wash their hands all day"]. It absorbs in about ten seconds with no greasy residue, so you can put gloves back on straight away.

Would you like to try it? No obligation to post — if you like it, I'd love to talk about working together. If you don't, I'd still value your honest feedback.

Thank you for the work you do for [their audience, e.g. "nurses on long shifts"].

[Your Name]
[Brand Name] — [website or waitlist link]

**Why it works:** It proves you watched their work, it describes the product in one line tied to their audience, the ask is small (try it, not post about it), and it is easy to answer yes or no.

---

## 2. The Follow-Up

**When to send:** Five to seven days after the pitch, if there is no reply. Send once. Then move on.

**Subject (email):** Re: A product your audience asked for — [Your Brand Name]

Hi [Creator's first name],

Just floating this back to the top of your inbox — I know you get a lot of messages.

I make [Product Name], [one-line description], and I thought it might be a fit for your audience after your [specific post]. Happy to send you one to try, no strings attached.

If it's not a fit, no worries at all — just let me know either way when you have a moment.

Thanks,
[Your Name]

**Why it works:** It is short, gracious, and easy to answer. It does not guilt the creator or repeat the whole pitch.

---

## 3. The Gifting Note (sent with the product)

**When to send:** With the product, after the creator says yes. Include a short card — handwritten-style, not a printed flyer.

Hi [Creator's first name],

Thank you for trying [Product Name]. This is [one line: what it is and who it is for].

A few things that might help:
- Use [amount, e.g. "a pea-sized amount"] [how often, e.g. "between hand washes"].
- The texture is [describe it honestly]. It absorbs in about ten seconds.
- Full ingredients are on the box and on our website.

There is no obligation to post. If you do share it, please mention that the product was gifted to you — it keeps everything clear for your audience, and we appreciate it.

If you love it, I'd love to talk about an affiliate code for your audience. If you don't, tell me why — honest feedback is worth more to us than a polite post.

Thank you,
[Your Name]
[Brand Name] — [email]

**Why it works:** It gives the creator what they need to use the product well, removes pressure, handles disclosure plainly, and opens the door to an affiliate relationship without demanding one.

---

## 4. The Affiliate Offer

**When to send:** After the creator has tried the product and told you they liked it — or after they have posted about it.

**Subject (email):** An affiliate code for your audience — [Brand Name]

Hi [Creator's first name],

Thank you for trying [Product Name] — I'm glad it worked for you.

I'd like to offer you an affiliate arrangement: a personal code, [SUGGESTED CODE, e.g. FIRSTNAME15], that gives your audience 15% off their first order, and pays you [commission, e.g. 15%] of every sale made with your code. There is no minimum, no exclusivity, and you can stop any time.

Here's what I'd send you:
- Your code and a personal link to share.
- A short guide to the product and the ingredients, so you can answer questions confidently.
- Early access to new products before they launch.

All I'd ask is that you disclose the affiliate relationship clearly when you share the code, so your audience always knows.

If you'd like to go ahead, reply and I'll set up your code today. And if the timing isn't right, no problem — the offer stands whenever you want it.

Thanks again,
[Your Name]

---

## 5. The Paid Collaboration Brief (when you want a guaranteed deliverable)

Use this when you are paying for a post. Agree everything in writing before the product ships.

Hi [Creator's first name],

Thank you for your interest in a paid collaboration. Here's what I have in mind:

- **Deliverable:** [e.g. one in-feed post and two stories, published between X and Y dates]
- **Fee:** $[amount], paid [e.g. 50% on agreement, 50% on publication] via [payment method]
- **Product:** [Product Name], shipped to [address] by [date]
- **Key points to cover:** [2–3 honest points, e.g. absorbs in ten seconds; made for people who wash their hands all day]
- **Points to avoid:** [e.g. no medical or treatment claims; no "cures" language]
- **Disclosure:** Please disclose the paid partnership clearly in the post and stories, following your platform's rules.
- **Usage rights:** [e.g. we may repost your content on our channels with credit for 90 days]

If that works for you, I'll send a short written agreement confirming the above, and then ship the product. If you'd like to change anything, tell me — I'd rather agree on the details now than fix them later.

Thanks,
[Your Name]

---

## 6. The Thank-You (after a creator posts)

Hi [Creator's first name],

Thank you for sharing [Product Name] with your audience. Your post was [specific detail — what you liked about it], and we've already had [honest note, e.g. "several new waitlist sign-ups from your audience"].

I've shared your post on our channels with credit. If there's anything else you need — more product, the ingredient guide, or an affiliate code for your audience — just ask.

Thank you for being part of our launch.

[Your Name]

---

## Tracking Reminder

Record every creator in the Influencer Tracker (Workbook, Worksheet 4): name, platform, handle, followers, audience fit, dates contacted, pitch and follow-up sent, reply, product shipped, posted, affiliate code, sales attributed, and next step. Review the tracker weekly. A pipeline you do not review is a list you forget.
