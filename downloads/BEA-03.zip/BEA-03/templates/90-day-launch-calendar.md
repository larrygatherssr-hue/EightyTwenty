# 90-Day Launch Calendar — Day-by-Day Plan

**How to use this calendar:** Day 1 is the day you start, not the day you feel ready. Each day has one primary action. If you miss a day, do not double up — just do the next day's action. Replace the bracketed placeholders with your brand's details. Post 3–5 times a week on your main channel; the calendar marks the content days.

---

## Phase 1 — Tease (Days 1–21): Make the problem visible

| Day | Action |
|---|---|
| 1 | Write your positioning sentence (Module 1). Pin it above your desk. |
| 2 | List 10 people who match your customer. Message 3 of them personally and ask about their biggest frustration. |
| 3 | Set up your waitlist page: headline in the customer's words, 3 short lines, one email field, one button, one image. |
| 4 | Publish post 1: the problem, in the customer's words. Short video or a relatable story. End with a question. |
| 5 | Message 3 more people from your list of 10. Record their exact words. |
| 6 | Publish post 2: a failed solution you tried, and why it did not work. |
| 7 | Review the week's numbers: reach, saves, waitlist sign-ups. Write down what got saved and what got ignored. |
| 8 | Join 2 communities where your customer gathers. Read the rules. Contribute something useful — no promotion yet. |
| 9 | Publish post 3: a poll — "Which of these frustrates you most?" Give 3 real options. |
| 10 | Message the last 4 people on your list of 10. Complete the interview worksheet. |
| 11 | Publish post 4: behind the scenes — your workspace, your notes, the work in progress. No finished product shown. |
| 12 | Write your lead magnet outline (a genuinely useful guide tied to the problem, e.g. a 7-day routine or checklist). |
| 13 | Publish post 5: answer the most common answer from your poll with a useful tip. |
| 14 | Weekly review: waitlist size, open rate if you have emailed yet, saves per post. Adjust next week's content toward what got saved. |
| 15 | Draft the lead magnet. Keep it short and genuinely useful — something worth an email address. |
| 16 | Publish post 6: a question to your audience — "What do you wish someone had told you about [problem]?" |
| 17 | Reply to every comment and DM from the past week. Engagement is audience building. |
| 18 | Publish post 7: a myth about the problem, corrected plainly. |
| 19 | Finish the lead magnet. Put it on the waitlist thank-you page. |
| 20 | Publish post 8: a teaser of the process — an ingredient, a texture close-up, a packaging decision — without revealing the product. |
| 21 | End of Phase 1 review: waitlist size, saves per post, top 3 customer phrases. Write the waitlist promise for Phase 2. |

## Phase 2 — Build (Days 22–56): Grow the waitlist, prove you understand the customer

| Day | Action |
|---|---|
| 22 | Send waitlist email 1 (welcome). One story, one useful tip, one update. |
| 23 | Publish post 9: how you chose the formula — one decision, explained simply. |
| 24 | Recruit 5–10 testers who match your customer. Send them the product with a one-page guide and no pressure to post. |
| 25 | Publish post 10: a tester-free process post — why you rejected the obvious ingredient or approach. |
| 26 | Plan your weekly live/Q&A: pick a day and time, same time every week. Announce it. |
| 27 | Publish post 11: founder story, part 1 — the moment you decided to build this. |
| 28 | Weekly review + first live/Q&A (30 minutes, answer real questions). Save the recording. |
| 29 | Publish post 12: the texture, the scent, the feel — a sensory post. |
| 30 | Reach out to 3 complementary brands or creators about a collaboration or guest appearance. |
| 31 | Publish post 13: a customer-language post — use the exact words your interviewees used. |
| 32 | Send waitlist email 2 (founder story). |
| 33 | Publish post 14: packaging decisions — why this bottle, this size, this label. |
| 34 | Cut the best 60 seconds from your Q&A into a short clip and post it. |
| 35 | Weekly review + live/Q&A. Note the questions that keep repeating — they become launch FAQ. |
| 36 | Publish post 15: tester update — what your testers are experiencing after one week (honest, no medical claims). |
| 37 | Build your list of 50 creators (Module 5). Evaluate each on audience match, engagement quality, content fit, reliability. |
| 38 | Publish post 16: a how-to — one small routine your audience can use today, with or without your product. |
| 39 | Send waitlist email 3 (the problem, deepened). |
| 40 | Start creator warm-ups: follow 10 creators, leave genuine comments on their recent posts. |
| 41 | Publish post 17: the ingredient story — one ingredient, what it does, why you chose it. No treatment or cure claims. |
| 42 | Weekly review + live/Q&A. Check waitlist growth rate and email open rate. |
| 43 | Publish post 18: a before-and-after story from a tester, in their words, with their permission. |
| 44 | Warm up 10 more creators with genuine comments. |
| 45 | Publish post 19: answer the single most-asked question from your Q&A sessions. |
| 46 | Send waitlist email 4 (formula and science). |
| 47 | Publish post 20: a day-in-the-life of building the brand — honest, unpolished. |
| 48 | Warm up 10 more creators. Begin drafting your pitch messages (customize the template scripts). |
| 49 | Weekly review + live/Q&A. If open rate is below 25%, rewrite your subject lines in the customer's language. |
| 50 | Publish post 21: tester results round-up — what testers liked, what surprised them, one honest caveat. |
| 51 | Send the first 10 creator pitches (customized, under 150 words each). |
| 52 | Publish post 22: countdown with substance — "21 days to launch: today we reveal the texture." |
| 53 | Send waitlist email 5 (tester story). |
| 54 | Follow up with creators who have not replied after 5–7 days. One polite follow-up each, then move on. |
| 55 | Publish post 23: the ritual — how the product fits into a two-minute routine. |
| 56 | End of Phase 2 review: waitlist size, open rate, testers' feedback summary, creators pitched/replied. Lock the founding-member offer and the launch price. |

## Phase 3 — Pre-sell (Days 57–83): Convert attention into committed buyers

| Day | Action |
|---|---|
| 57 | Build the pre-sell page: product, price, founding-member benefit, unit limit, deadline, guarantee. Test checkout end to end. |
| 58 | Publish post 24: the full reveal — the product, the name, the story, the price. |
| 59 | Send waitlist email 6 (how to use it). |
| 60 | Send the next 10 creator pitches. Ship product to every creator who said yes, with a handwritten-style note. |
| 61 | Publish post 25: how-to-use demonstration video. |
| 62 | Send waitlist email 7 (what makes it different). |
| 63 | Weekly review + live/Q&A. Announce the pre-sell opening date to the waitlist. |
| 64 | Publish post 26: the comparison — your product versus the usual alternative, honestly framed. |
| 65 | Confirm fulfillment: packaging, labels, shipping supplies, and your order checklist are ready. |
| 66 | Send waitlist email 8 (questions answered). |
| 67 | Publish post 27: creator content — repost the first creator's honest try-on, with credit. |
| 68 | Send the next 10 creator pitches. Follow up once with earlier non-replies. |
| 69 | Publish post 28: the numbers — how many units in the first batch, and why the batch is limited. |
| 70 | Weekly review + live/Q&A. Final check: pre-sell page, checkout, emails 9–12 scheduled. |
| 71 | Send waitlist email 9 — THE OFFER OPENS. Founding-member access live for the waitlist. |
| 72 | Publish post 29: the offer announcement — price, benefit, limit, deadline. |
| 73 | Answer every question and DM within the hour. Share the first pre-sell orders (with permission). |
| 74 | Publish post 30: a buyer story — why an early buyer joined, in their words. |
| 75 | Send waitlist email 10 (proof and urgency). |
| 76 | Publish post 31: FAQ round-up — the five most common pre-sell questions, answered plainly. |
| 77 | Weekly review: pre-sell conversion rate so far. If low, check the offer clarity and the page, not the product. |
| 78 | Publish post 32: behind the scenes of packing the first orders. |
| 79 | Send the final 10 creator pitches. Offer affiliate codes to every creator who posted. |
| 80 | Publish post 33: last week of pre-sell — what early buyers are saying. |
| 81 | Send waitlist email 11 — LAST CALL. The founding-member window closes tonight. |
| 82 | Publish post 34: last-call post, one clear deadline. Then stop posting about the offer. |
| 83 | Close the founding-member offer as promised. Count pre-sell orders. Send waitlist email 12 (thank you and what's next). Prepare launch week. |

## Phase 4 — Launch (Days 84–90): Open the doors

| Day | Action |
|---|---|
| 84 | LAUNCH DAY. Send the launch email to the waitlist first thing. Post the announcement. Answer everything within the hour. Share orders and unboxings (with permission). |
| 85 | Publish the founder story (long-form post or video). The specific moment you started. |
| 86 | Publish the how-to-use demonstration. Customers who know how to use it buy more and return less. |
| 87 | Publish tester results and the first honest reviews — including one small honest caveat. |
| 88 | Publish the FAQ post: the five most common questions, answered plainly. |
| 89 | Open to the public. Fresh announcement. Repost the best creator content from launch week. |
| 90 | LAST CALL. One email, one post, one deadline. Close the launch offer tonight — no extensions. Then write down: orders, revenue, average order value, refund rate, reviews received, and the date of your 90-day review. |

---

## After Day 90

- Ask every buyer for a review 14 days after delivery.
- Send the waitlist that did not buy a weekly email: reviews, answers, tips.
- Update the Launch Metrics Worksheet weekly.
- Plan the second launch (second product, bundle, or limited edition) for 90 days after the first.
