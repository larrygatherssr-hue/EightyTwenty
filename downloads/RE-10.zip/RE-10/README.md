# RE-10 — The Deal Analyzer Pro Toolkit

**Price:** $147 (one-time) | **Category:** Real Estate | **SKU:** RE-10

Underwrite any deal in 15 minutes — rentals, flips, BRRRR, and short-term rentals in one toolkit.

**Format note:** This is a written guide plus spreadsheets. No video is included. The 15-minute underwriting walkthrough is provided as a complete written step-by-step process in the guide.

## Files

- `content.md` — The full written toolkit guide (11,193 words): 15-minute underwriting walkthrough, the seven numbers that decide every deal, a full worked example for each strategy (rental, flip, BRRRR, STR), buy box, offer-price calculation, five-year projections, financing/DSCR, reserves, taxes and insurance, deal comparison, red flags, and portfolio systems.
- `workbook.md` — Companion workbook: buy-box worksheet, deal comparison sheet, underwriting checklist, offer-price worksheet, five-year projection worksheet, red-flags checklist, and a weekly routine tracker.
- `templates/rental-analyzer.csv` — Long-term rental analyzer with worked example and blank rows.
- `templates/flip-analyzer.csv` — Fix-and-flip analyzer with worked example and blank rows.
- `templates/brrrr-analyzer.csv` — BRRRR analyzer with worked example and blank rows.
- `templates/str-analyzer.csv` — Short-term rental analyzer with worked example and blank rows.
- `templates/buy-box-scorecard.md` — Buy-box scorecard (0–100) with hard minimums.
- `templates/offer-price-calculator.md` — Offer-price calculator, step by step, for all four strategies.
- `sales-page.md` — Full sales page: headline, problem, solution, contents, who it is for / not for, price and guarantee, 12-question FAQ, and disclaimers.
- `listing.json` — Marketplace listing data (valid JSON, price_cents 14700).
- `cover.png` — Cover image (1280 × 1920 PNG, black-and-gold luxury branding).
- `cover.md` — Cover design brief.
- `onboarding.md` — Customer onboarding guide: what to do first, how to use the materials, first-week schedule, and support.
- `README.md` — This index.

## Disclaimer

Educational material only — not individualized investment, legal, tax, or financial advice. No guaranteed returns. Worked examples are illustrative.
