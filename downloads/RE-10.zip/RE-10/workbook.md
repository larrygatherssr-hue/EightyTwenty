# The Deal Analyzer Pro Toolkit — Companion Workbook

## Disclaimer

This workbook is educational material only. It is not individualized investment, legal, tax, or financial advice. It does not guarantee any return. Worked examples in the guide are illustrative, and real results depend on market conditions, financing, execution, and factors outside your control. Verify every number independently and consult licensed professionals before investing.

## How to Use This Workbook

Complete one copy of the relevant worksheets for every deal you analyze. Print them, or copy them into a fresh document per deal. Keep completed worksheets in your deal log so you can compare deals and learn from your own estimates over time.

---

## Worksheet 1: Buy-Box Worksheet

Write your buy box before you analyze your next deal. Revisit it quarterly.

**My strategy (circle one):** Long-term rental / Flip / BRRRR / Short-term rental / More than one

**Property criteria**
- Property types I buy: ________________________________________
- Bedrooms / bathrooms: ________________________________________
- Square footage range: ________________________________________
- Year built (earliest acceptable): ________________________________________
- Condition limits (maximum renovation): $________
- Deal killers I will not accept: ________________________________________

**Location criteria**
- Areas I invest in: ________________________________________
- Maximum distance from home: ________________________________________
- School / crime / employer requirements: ________________________________________

**Return minimums (hard minimums — do not waive these)**
- Minimum monthly cash flow per unit: $________
- Minimum cash-on-cash return: ________%
- Minimum cap rate: ________%
- Minimum DSCR: ________
- Minimum flip profit: $________ and minimum margin: ________%
- Maximum cash left in (BRRRR): $________

**Financing**
- Down payment I can make: $________
- Target interest rate (realistic, from a lender quote): ________%
- Lender(s): ________________________________________

**My buy box in one sentence:** ________________________________________

---

## Worksheet 2: Deal Comparison Sheet

Complete one row per deal. Compare on the same metrics, every time.

| Deal | Address | Strategy | Price | Rent / ARV / Nightly | Monthly Cash Flow | Cash-on-Cash | Cap Rate / Margin | DSCR | Cash Invested | Buy-Box Score | Decision |
|------|---------|----------|-------|----------------------|-------------------|--------------|-------------------|------|---------------|---------------|----------|
| 1 | | | | | | | | | | / 100 | |
| 2 | | | | | | | | | | / 100 | |
| 3 | | | | | | | | | | / 100 | |
| 4 | | | | | | | | | | / 100 | |
| 5 | | | | | | | | | | / 100 | |

**Best deal this week:** ______________________________ **Why:** ______________________________

**Exercise:** Take the three worked examples from the guide (rental, flip, BRRRR) and enter them in the table above. Which one scores highest, and why? What would have to change for the lowest-scoring deal to become the best?

---

## Worksheet 3: Underwriting Checklist

Complete this checklist for every deal before you decide. Check each box only when you have the evidence, not when you assume it.

**Income**
- [ ] Rent / ARV / nightly rate from at least 3 comparable properties
- [ ] Comps are recent (last 6 months), nearby, and similar in size and condition
- [ ] Vacancy or occupancy applied at a conservative rate
- [ ] Seasonality considered (STRs)

**Costs**
- [ ] Taxes verified from county records
- [ ] Insurance quoted (not estimated from a listing)
- [ ] Renovation from a written contractor estimate
- [ ] Contingency of 10–20% added to renovation
- [ ] Holding costs calculated for the realistic timeline plus 2 months
- [ ] Management budgeted even if self-managing
- [ ] Maintenance reserve included (5–10%)
- [ ] CapEx reserve included (5–10%)

**Financing**
- [ ] Lender quote in writing: rate, term, down payment, fees, DSCR requirement
- [ ] Monthly payment confirmed including or excluding escrow
- [ ] DSCR calculated on my numbers and on the lender's likely numbers

**Decision**
- [ ] All four outputs read together (cash flow, cash-on-cash, cap rate, DSCR)
- [ ] Stress test completed: income −10%, renovation +20%, rate +1 point
- [ ] Decision recorded with the reason
- [ ] Price at which the deal would work recorded (if passing)

**Exercise:** Run the 15-minute underwrite on a live listing in your market using only this checklist and the relevant spreadsheet template. Time yourself. What took longest, and what will you prepare in advance next time?

---

## Worksheet 4: Offer-Price Worksheet

- Property address: ______________________________
- Strategy: ______________________________
- Asking price: $________
- Market rent / ARV / nightly rate: $________ (source: ____________________)
- Renovation budget (with contingency): $________
- Holding costs: $________
- Selling costs (flips): $________
- Target profit / cash flow: $________
- Calculated maximum offer: $________
- 70% rule check (flips): $________
- **Ceiling (lower of the two, where applicable): $________**
- Opening offer: $________
- Walk-away price: $________
- One-sentence case for the offer: ____________________________________________________________

**Exercise:** Take the flip worked example from the guide and recalculate the maximum offer with a target profit of $35,000 instead of $25,000. How much does the ceiling move? What does that tell you about the sensitivity of offer price to target profit?

---

## Worksheet 5: Five-Year Projection Worksheet

Enter year-one numbers from your template, then apply your growth assumptions.

**Assumptions (write them down and defend them)**
- Rent growth per year: ________%
- Expense growth per year: ________%
- Appreciation per year: ________% (test the deal at 0% as well)
- Vacancy / reserves: held constant as % of rent

| Year | Rent / Income | Operating Expenses | NOI | Debt Service | Cash Flow | Loan Balance | Property Value |
|------|---------------|--------------------|-----|--------------|-----------|--------------|----------------|
| 1 | | | | | | | |
| 2 | | | | | | | |
| 3 | | | | | | | |
| 4 | | | | | | | |
| 5 | | | | | | | |

**Cumulative cash flow (5 years): $________**
**Equity from loan paydown: $________**
**Equity from appreciation: $________**
**Total wealth created (before taxes and selling costs): $________**

**Downside case:** Rent growth 0%, expense growth 4%, appreciation 0%. Year-5 cash flow: $________. Does the deal still work? Yes / No

**Exercise:** Project the rental from Chapter 4 at a purchase price of $110,000 and rent of $1,650, using 2.5% rent and expense growth. Compare your result to the guide's five-year example and note any differences in your assumptions.

---

## Worksheet 6: Red-Flags Checklist

Check every item that applies. Any deal-killer item ends the deal unless you have the expertise, budget, and price to solve it.

**Inspect and verify**
- [ ] Roof age: ________ years (15+ is a flag)
- [ ] HVAC age: ________ years (12+ is a flag)
- [ ] Water heater age: ________ years (8+ is a flag)
- [ ] Signs of water damage, mold, or foundation movement
- [ ] Sewer line scoped (or priced to scope)
- [ ] Electrical panel type and wiring checked
- [ ] Flood zone checked
- [ ] HOA documents reviewed; special assessments or litigation noted

**Documents and seller**
- [ ] Rent rolls and leases provided (rentals)
- [ ] Expense records provided
- [ ] Seller's numbers reconciled to tax records and bank statements where available
- [ ] Tenant access for inspection confirmed

**Legal and strategy**
- [ ] Property can legally be used for my strategy (zoning, STR rules, permits)
- [ ] Title clear or clearable
- [ ] Insurance obtainable at a quoted price

**Deal killers present?** Yes / No — If yes, list them: ________________________________________

**Decision:** Pursue / Verify ____________________ / Walk away

---

## Weekly Routine Tracker

| Week of | Deals screened | Deals passed | Deals pursued | Offers made | Offers accepted | Lesson learned |
|---------|---------------|--------------|---------------|-------------|-----------------|----------------|
| | | | | | | |
| | | | | | | |
| | | | | | | |
| | | | | | | |

Use this tracker for your first month. At the end of the month, review it and update your buy box based on what you learned.
