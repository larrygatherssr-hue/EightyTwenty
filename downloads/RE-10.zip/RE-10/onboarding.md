# Onboarding Guide — The Deal Analyzer Pro Toolkit

Welcome. This guide will get you using the toolkit in your first week.

## What You Received

- `content.md` — the full written toolkit guide (start here)
- `workbook.md` — companion workbook with worksheets and exercises
- `templates/rental-analyzer.csv` — long-term rental analyzer
- `templates/flip-analyzer.csv` — fix-and-flip analyzer
- `templates/brrrr-analyzer.csv` — BRRRR analyzer
- `templates/str-analyzer.csv` — short-term rental analyzer
- `templates/buy-box-scorecard.md` — buy-box scorecard
- `templates/offer-price-calculator.md` — offer-price calculator
- `sales-page.md` — the sales page for reference
- `listing.json` — the marketplace listing data
- `cover.png` / `cover.md` — the cover image and design brief
- `README.md` — index of all files

## What to Do First (Day 1, about 60 minutes)

1. Read Chapters 1–3 of `content.md` — how to use the toolkit, the 15-minute underwriting walkthrough, and the seven numbers that decide every deal.
2. Open the spreadsheet template for your primary strategy and study the worked example already filled in. Follow the numbers against the matching chapter in the guide until you can see how each result was calculated.
3. Fill in the buy-box worksheet in `workbook.md` (Worksheet 1). Do not skip this step. Your buy box is what makes every later decision fast.

## Your First Week — Suggested Schedule

- **Day 1:** Read Chapters 1–3, study your primary template, write your buy box.
- **Day 2:** Read the chapter for your primary strategy (Chapter 4 for rentals, 5 for flips, 6 for BRRRR, 7 for STRs). Rework its example by hand in the template.
- **Day 3:** Read Chapters 8–10 (buy box, offer price, five-year projections). Score the worked example on the buy-box scorecard and calculate its offer price.
- **Day 4:** Read Chapters 11–13 (financing, reserves, taxes and insurance). Check your reserve percentages and financing assumptions against your lender's actual terms.
- **Day 5:** Run the 15-minute underwrite on a live listing in your market, using the underwriting checklist in the workbook. Time yourself and record the decision in your deal log.
- **Day 6–7:** Read Chapters 14–16 (comparing deals, red flags, portfolio systems). Set up your weekly routine: one block for screening, one for verifying.

## How to Use the Materials on Every Deal

1. Pick your strategy for the property before you run any numbers.
2. Open the matching spreadsheet template and enter the numbers from your comps, contractor estimate, and lender quote.
3. Read all four outputs together — cash flow, cash-on-cash return, cap rate, DSCR (or profit and margin for a flip) — and compare them to your buy box.
4. Run the stress test: income down 10%, renovation up 20%, rate up 1 point.
5. Score the deal on the buy-box scorecard and calculate your offer price.
6. Record the decision — pursue, pass, or verify one thing — in your deal log, with the reason.

## Tips

- Use conservative numbers: the lower rent, the higher expense, the longer vacancy, and the higher repair estimate. If a deal only works on optimistic numbers, it does not work.
- Never use the rent or ARV from the listing. Use comparable properties.
- Keep at least two months' rent per property in a separate reserve account, plus your CapEx reserves.
- Review your deal log monthly and update your buy box quarterly based on what you learn.

## How to Get Support

Contact EightyTwenty marketplace support by email with your order details and a description of your question. You will receive a reply within two business days. Support can help with file access and questions about using the materials. Support cannot provide individualized investment, legal, tax, or financial advice — for those questions, consult a licensed professional.
