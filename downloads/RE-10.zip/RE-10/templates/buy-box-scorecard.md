# Buy-Box Scorecard

Score each deal from 0 to 10 on each criterion, then total the score out of 100. A deal must also pass every hard minimum marked with an asterisk — a high total score does not override a failed hard minimum.

## How to Score

- 10 = exceeds your buy box comfortably
- 7–9 = meets your buy box
- 4–6 = below your buy box but close
- 0–3 = far below your buy box or unknown

## Scorecard

| # | Criterion | Weight | Your Score (0–10) | Weighted Score |
|---|-----------|--------|-------------------|----------------|
| 1 | Monthly cash flow meets minimum * | 20 | ___ / 10 | ___ / 20 |
| 2 | Cash-on-cash return meets minimum * | 15 | ___ / 10 | ___ / 15 |
| 3 | Cap rate meets minimum (rentals) / profit margin meets minimum (flips) * | 10 | ___ / 10 | ___ / 10 |
| 4 | DSCR at or above 1.25 (rentals / BRRRR) * | 10 | ___ / 10 | ___ / 10 |
| 5 | Rent / ARV / nightly rate verified from 3+ comps | 10 | ___ / 10 | ___ / 10 |
| 6 | Renovation scope within your limits; estimate from a written bid + contingency | 10 | ___ / 10 | ___ / 10 |
| 7 | Location meets your criteria (schools, crime, employers, growth) | 10 | ___ / 10 | ___ / 10 |
| 8 | Property condition: no deal-killer issues (structure, flood, legal use) * | 5 | ___ / 10 | ___ / 5 |
| 9 | Financing confirmed: rate, down payment, DSCR requirement in writing | 5 | ___ / 10 | ___ / 5 |
| 10 | Exit options: at least one realistic backup exit (rent, flip, or sell to owner-occupant) | 5 | ___ / 10 | ___ / 5 |
| **Total** | | **100** | | **___ / 100** |

## Decision Guide

- **80–100 and all hard minimums pass:** Pursue. Verify comps, get bids and quotes, schedule an inspection, and offer at or below your calculated offer price.
- **60–79:** Maybe. Name the one number that would change the decision, verify it, and re-score. Do not pursue until the score improves or the price drops.
- **Below 60:** Pass. Record the price at which the deal would work and move on.

## Your Hard Minimums (fill in before you score any deal)

- Minimum monthly cash flow per unit: $________
- Minimum cash-on-cash return: ________%
- Minimum cap rate (rentals): ________%
- Minimum DSCR: ________
- Minimum flip profit: $________ and minimum margin: ________%
- Maximum cash left in (BRRRR): $________
- Maximum renovation budget: $________

## Notes

Property address: ______________________________ Date: ____________ Strategy: ____________________

Key strengths: ___________________________________________________________________________

Key risks: _______________________________________________________________________________

Decision: Pursue / Maybe — verify ____________________ / Pass
