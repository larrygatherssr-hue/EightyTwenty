# Offer-Price Calculator

The offer price is the highest price at which a deal still meets your buy box. Know it before you negotiate. Work through the section for your strategy, then record the ceiling and your opening offer.

## Rental — Worked Method

1. Market rent (monthly, from comps): $________
2. Less vacancy (6%): $________
3. Effective gross income (monthly): $________
4. Less operating expenses (monthly, line by line): $________
5. Net operating income (monthly): $________
6. Target monthly cash flow: $________
7. Maximum monthly debt service allowed (NOI − target cash flow): $________
8. Maximum loan that payment supports at your rate and term: $________ (use the rental template or a mortgage calculator)
9. Maximum price (maximum loan ÷ (1 − down-payment %)): $________
10. Also check by cap rate: maximum price = annual NOI ÷ target cap rate = $________
11. **Your ceiling is the lower of steps 9 and 10: $________**

Example from the guide: NOI $730/month, target cash flow $200/month, maximum debt service $530/month, which supports roughly an $80,000–$88,000 loan at 7.5% for 30 years, implying a maximum price near $100,000–$110,000 at 20% down.

## Flip — Worked Method

1. After-repair value (ARV): $________
2. Less renovation (with contingency): $________
3. Less holding costs: $________
4. Less selling costs: $________
5. Less financing costs (points, fees, purchase closing): $________
6. Less target profit: $________
7. **Maximum offer: $________**
8. 70% rule check: 70% of ARV − renovation = $________
9. **Your ceiling is the lower of steps 7 and 8: $________**

Example from the guide: $245,000 − $60,000 − $9,250 − $17,200 − $7,810 − $25,000 = $125,740; the 70% rule gives $111,500, so the ceiling is $111,500.

## BRRRR — Worked Method

1. Maximum offer from flip math (above): $________
2. Maximum offer from rental math (price at which post-refinance cash flow meets your minimum): $________
3. **Your ceiling is the lower of steps 1 and 2: $________**
4. Cash left in at that price: $________
5. Post-refinance DSCR at that price: ________

A BRRRR must work as both a renovation project and a rental. If it only works as one, it is not a BRRRR at that price.

## Short-Term Rental — Worked Method

1. Gross annual revenue (nightly rate × booked nights): $________
2. Less all operating expenses (annual): $________
3. Net operating income (annual): $________
4. Target annual cash flow: $________
5. Maximum annual debt service allowed (NOI − target cash flow): $________
6. Maximum loan that payment supports: $________
7. **Maximum price: $________**

Use annual-average rates and occupancy, not peak season, and test the low season separately.

## Your Offer

- Property address: ______________________________
- Strategy: ______________________________
- Asking price: $________
- Your calculated ceiling: $________
- Your opening offer: $________
- Walk-away price: $________
- Reason for the offer (one sentence, with comps): ____________________________________________________________

Disclaimer: This calculator is educational only. It does not provide individualized investment, legal, tax, or financial advice, and it does not guarantee any return. Verify every input independently and consult licensed professionals before making an offer.
