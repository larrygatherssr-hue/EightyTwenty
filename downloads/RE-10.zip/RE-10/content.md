# The Deal Analyzer Pro Toolkit
## Underwrite Any Deal in 15 Minutes — Rentals, Flips, BRRRR, and Short-Term Rentals in One Toolkit

**RE-10 | EightyTwenty Marketplace | $147**

---

## Important Disclaimer — Read First

This toolkit is educational material only. It is not individualized investment advice, legal advice, tax advice, or financial advice. It does not recommend that you buy, sell, or hold any specific property, and it does not guarantee any return, profit, or outcome. All worked examples in this guide are illustrative. They use simplified, rounded numbers to teach a method. Real results depend on your market, your financing, your execution, your team, interest rates, taxes, insurance, local law, and conditions that change over time. Always verify every number independently, confirm financing terms with a licensed lender, confirm legal and tax questions with a licensed attorney and a qualified tax professional in your state, and inspect any property before you make an offer. Never invest money you cannot afford to lose, and never skip due diligence because a spreadsheet looked good.

No testimonial, sales figure, or review is included in this toolkit. Any statement about what an investor "can" earn describes a possibility under stated assumptions, not a promise.

---

## Table of Contents

1. How to Use This Toolkit
2. The 15-Minute Underwriting Walkthrough
3. The Seven Numbers That Decide Every Deal
4. Strategy 1: Long-Term Rentals — Worked Example
5. Strategy 2: Fix-and-Flip — Worked Example
6. Strategy 3: BRRRR — Worked Example
7. Strategy 4: Short-Term Rentals — Worked Example
8. Building Your Buy Box
9. The Offer-Price Calculator, Step by Step
10. Five-Year Projections That Tell the Truth
11. Financing, DSCR, and the Cost of Money
12. Reserves: Vacancy, Maintenance, and CapEx
13. Taxes, Insurance, and the Costs Beginners Miss
14. Comparing Deals Side by Side
15. Red Flags, Deal Killers, and When to Walk Away
16. From One Deal to a Portfolio: Systems and Routines
17. Glossary
18. Final Checklist and Next Steps

---

## 1. How to Use This Toolkit

This toolkit has three parts. First, this guide, which teaches the method. Second, four spreadsheet templates in the `templates/` folder — one for each strategy — plus a buy-box scorecard and an offer-price calculator. Third, the companion workbook, which turns the method into worksheets you fill in for every deal you analyze.

Do not read this guide once and then analyze from memory. Use it the way a pilot uses a checklist: open the relevant template, work through the steps in order, and write down every assumption. A deal analyzed in writing is a deal you can defend, compare, and revisit. A deal analyzed in your head is a feeling.

The core promise is speed with discipline. Fifteen minutes is enough to reject most deals and to identify the few worth a second look. It is not enough to close a deal. The 15-minute underwrite is a screen. Deals that pass the screen earn a full hour of verification: rent comps, contractor bids, lender quotes, insurance quotes, tax records, and an inspection. Deals that fail the screen are released immediately, without regret. Most of your profit in real estate comes from the deals you do not buy.

### Who this is for

This toolkit is for active investors analyzing five or more deals per month who need fast, consistent underwriting across strategies. It assumes you already understand the basics of buying property — what a mortgage is, what closing costs are, what a lease is — and it focuses on the analysis itself: turning a listing into a yes, a no, or a price.

### What you need before you start

You need four things for every deal: the asking price, a realistic rent or sale price from comparable properties (not from the listing), an honest estimate of repair costs, and a financing quote or at least a realistic rate and down-payment assumption for your situation. If any of those four is missing, your analysis is a guess. Get the missing number before you decide.

### The rule that governs everything

Underwrite to the conservative case. Use the lower rent, the higher expense, the longer vacancy, and the higher repair estimate. If a deal only works on optimistic numbers, it does not work. A good deal survives pessimism. That single habit will save you more money than any formula in this book.

---

## 2. The 15-Minute Underwriting Walkthrough

This chapter is the heart of the toolkit. It is the written version of the 15-minute underwriting walkthrough: a step-by-step process you can run on any deal, for any of the four strategies, in fifteen minutes. Time yourself the first few times. Speed comes from repetition, not from skipping steps.

Set a timer. Keep the relevant spreadsheet template open. Work in order and do not jump ahead to the answer you want.

### Minutes 0–2: Capture the deal

Write down the address, the asking price, the property type, the number of bedrooms and bathrooms, the square footage, the year built, and the lot size. Note the listing source and the date. Note whether the property is occupied, vacant, or tenant-occupied, and whether there are any obvious condition issues visible in photos: roof age, HVAC age, water heater age, foundation cracks, or deferred maintenance.

Then write down your strategy for this property before you run any numbers. Is this a rental, a flip, a BRRRR, or a short-term rental? A property can often work for more than one strategy, but you must pick one primary strategy for the first pass. Analyzing a deal as "a little bit of everything" is how investors talk themselves into bad purchases. Pick one. You can test a second strategy later if the first one fails.

### Minutes 2–5: Find the income

Income is the single most important number, and it is the number most often inflated. Never use the rent stated in the listing. Never use the seller's pro forma. Use comparable rents from at least three similar properties rented in the last six months within a reasonable distance — same bedroom count, similar condition, similar neighborhood.

For a rental, write down the market rent. For a flip, write down the after-repair value (ARV) from at least three comparable sales in the last six months. For a BRRRR, you need both: the rent after renovation and the ARV after renovation. For a short-term rental, write down the nightly rate and the occupancy rate from comparable listings in the same area, and adjust for seasonality — a beach town in July is not a beach town in January.

If you cannot find three good comps in five minutes, that is information. It means the market is thin, the property is unusual, or you do not know the area well enough yet. Note that, use the most conservative comp you can defend, and flag the deal for extra verification if it passes the screen.

### Minutes 5–8: Estimate the costs

Now estimate the three cost buckets: purchase costs, renovation costs, and operating costs.

Purchase costs include the price, closing costs (typically 2 to 5 percent of the price, depending on your market and loan type), and any immediate costs such as an inspection, an appraisal, and lender fees. For a flip or a BRRRR, add holding costs: mortgage payments, taxes, insurance, and utilities for every month you will own the property before it sells or refinances.

Renovation costs are where most analyses fail. Walk the property in your mind room by room — or better, walk it in person — and price each item: roof, HVAC, plumbing, electrical, kitchen, bathrooms, flooring, paint, exterior, and landscaping. Use a per-square-foot sanity check: a light cosmetic renovation might run $15 to $30 per square foot, a moderate renovation $30 to $60, and a full gut renovation $75 or more, depending on your market. If your line-by-line estimate is far below the per-square-foot check, you have missed something. Add a contingency of 10 to 20 percent on top of the renovation estimate, more for older properties.

Operating costs for a rental include property taxes, insurance, property management (budget 8 to 10 percent of rent even if you plan to self-manage at first, because your time has value and you may hire a manager later), vacancy (budget 5 to 8 percent), maintenance (budget 5 to 10 percent), and capital expenditure reserves (budget 5 to 10 percent). Those reserve percentages are not optional padding. They are the difference between a deal that looks profitable and a deal that is profitable. Chapters 4 and 12 work through them in detail.

### Minutes 8–11: Run the core math

Open the template for your strategy and enter the numbers you have gathered. The template does the arithmetic. Your job is to read the outputs and compare them to your buy box.

For a rental, the outputs that matter are monthly cash flow, cash-on-cash return, cap rate, and debt service coverage ratio (DSCR). For a flip, the outputs are total profit, return on investment, and profit margin. For a BRRRR, the outputs are cash left in the deal after refinance and cash-on-cash return on the cash that remains. For a short-term rental, the outputs are monthly net income after all expenses, occupancy-adjusted revenue, and cash-on-cash return.

Do not cherry-pick the metric that looks best. A rental can have a good cap rate and a terrible cash flow if the financing is expensive. A flip can have a good profit and a terrible return if it ties up your cash for a year. Read all of the outputs together.

### Minutes 11–13: Stress-test the deal

Change three inputs and watch what happens. First, reduce the income by 10 percent. Second, increase the renovation budget by 20 percent. Third, increase the interest rate by one percentage point. If the deal still meets your minimum standards under all three changes, it is robust. If it fails under any one of them, it is fragile. Fragile deals can still be worth pursuing, but only at a lower price — and you now know exactly how much lower.

This stress test takes two minutes and prevents most bad purchases. It forces you to confront the fact that rents can fall, renovations can overrun, and rates can rise, all at the same time.

### Minutes 13–15: Decide and record

Make one of three decisions and write it down with the reason.

- **Yes — pursue.** The deal meets your buy box on conservative numbers and survives the stress test. Next step: verify comps, get contractor bids, get a lender quote, schedule an inspection, and make an offer at or below your calculated offer price.
- **No — pass.** The deal fails your buy box even on reasonable numbers. Write down the price at which it would work, so you can recognize it if the price drops. Then move on. Do not revisit a passed deal unless the price or the facts change.
- **Maybe — verify one thing.** The deal is close, and one uncertain number decides it. Name that number, name how you will verify it, and set a deadline. A "maybe" without a verification step is a "yes" in disguise.

Record the deal in your deal log with the date, the address, the key numbers, and the decision. Over time, this log becomes one of your most valuable assets: it shows you which markets, property types, and sellers produce deals that work, and it stops you from analyzing the same bad deal twice.

### A note on speed

Fifteen minutes is a target, not a law. Your first few underwrites may take thirty minutes. That is fine. Speed comes from having your buy box written down, your templates ready, and your comp sources bookmarked. Do not rush the income or renovation estimates to hit the clock. Rush the decision, not the data.

---

## 3. The Seven Numbers That Decide Every Deal

Every deal in this toolkit is decided by seven numbers. Learn them, and you can underwrite anything. The chapters that follow apply them to each strategy; this chapter defines them once, clearly.

### 1. Gross income

For a rental, gross income is the monthly rent multiplied by twelve. For a short-term rental, it is the nightly rate multiplied by the number of booked nights per year. For a flip, the equivalent number is the after-repair value — the price you expect to sell for after renovation. Gross income is the top line. Everything else is subtracted from it.

### 2. Vacancy and credit loss

A property is not rented 100 percent of the time. Tenants move out, units sit empty between tenants, and occasionally a tenant does not pay. Budget for it. For long-term rentals, 5 to 8 percent of gross rent is a reasonable starting range in most markets; use 8 percent or more for lower-priced rentals or higher-turnover areas. For short-term rentals, vacancy is captured in the occupancy rate instead — do not double-count it.

### 3. Operating expenses

Operating expenses are the recurring costs of owning and operating the property, excluding the mortgage payment: taxes, insurance, management, maintenance, capital expenditure reserves, utilities you pay, HOA dues, and landscaping or snow removal. A useful rule of thumb is that operating expenses run 40 to 50 percent of gross rent for a typical long-term rental, but that range varies widely. Always build the expenses line by line, then compare the total to the rule of thumb. If your line-by-line total is far below 40 percent, you have probably missed an expense.

### 4. Net operating income (NOI)

Net operating income is gross income minus vacancy minus operating expenses. It is the income the property produces before debt service — before the mortgage is paid. NOI is the most important number in rental analysis because it separates the property from the financing. Two investors can buy the same property with different loans and different down payments, but the NOI is the same. If the NOI is weak, no loan structure fixes it.

### 5. Debt service

Debt service is the annual mortgage payment: principal and interest, and in many analyses the taxes and insurance escrow as well. When a lender quotes a payment, confirm whether it includes taxes and insurance or not, and be consistent. Debt service is what turns NOI into cash flow.

### 6. Cash flow

Cash flow is NOI minus debt service. For a rental, monthly cash flow is the cash left after every expense and the mortgage are paid. Positive cash flow is the goal, but the amount matters: $50 a month is positive and also fragile — one repair wipes out a year of it. Your buy box should set a minimum monthly cash flow per unit, and this toolkit recommends at least $150 to $250 per unit for a long-term rental in most markets, with higher minimums for properties that carry more risk.

### 7. Cash-on-cash return

Cash-on-cash return is annual cash flow divided by the total cash you invested: down payment, closing costs, and renovation costs paid out of pocket. It answers the question, "For every dollar I put in, how many dollars do I get back each year?" A 10 percent cash-on-cash return means $10,000 of cash invested returns $1,000 per year in cash flow. This is the number that lets you compare a rental to a flip, a flip to a BRRRR, and real estate to any other investment. Your buy box should set a minimum cash-on-cash return, and this toolkit suggests 8 to 12 percent as a reasonable starting range for long-term rentals, with higher minimums for strategies that demand more of your time.

### Two more numbers you will use constantly

**Cap rate** is NOI divided by the property's value or purchase price, expressed as a percentage. It lets you compare properties without financing. A $200,000 property with $12,000 of NOI has a 6 percent cap rate. Cap rates vary by market and property type; what matters is the cap rate relative to comparable properties in the same market, not an absolute number.

**Debt service coverage ratio (DSCR)** is NOI divided by annual debt service. A DSCR of 1.25 means the property's NOI covers the mortgage payment 1.25 times. Most lenders want a DSCR of at least 1.20 to 1.25 for investment properties. A DSCR below 1.0 means the property does not earn enough to pay its own mortgage — you would be feeding it cash every month.

Keep these definitions in front of you while you work through the chapters that follow. Every worked example uses them, and every template calculates them for you.


---

## 4. Strategy 1: Long-Term Rentals — Worked Example

Long-term rentals are the foundation strategy: you buy a property, rent it to a tenant on a 12-month lease, and hold it for years. The income is steady, the work is manageable, and the returns come from four sources at once — cash flow, mortgage paydown by the tenant, appreciation, and tax benefits. The risk is that a rental with thin cash flow can become a liability: every vacancy, repair, and rate increase comes out of your pocket.

### How to analyze a rental

Start with market rent from comps. Then subtract vacancy. Then subtract operating expenses line by line. The result is NOI. Subtract debt service. The result is cash flow. Divide annual cash flow by total cash invested. That is your cash-on-cash return. Compare all four outputs — cash flow, cash-on-cash, cap rate, DSCR — to your buy box before you decide.

The most common beginner error is undercounting expenses. The seller's numbers often show taxes, insurance, and the mortgage, and nothing else. Your analysis must include vacancy, maintenance, capital expenditure reserves, and management, even if you plan to self-manage. A property that "cash flows $400 a month" on the seller's numbers often cash flows $50 a month — or less than zero — on honest numbers. This chapter shows you the honest version.

### Worked example: a three-bedroom single-family rental

Consider a three-bedroom, two-bathroom single-family house built in 1985, 1,400 square feet, in a stable working-class neighborhood. The asking price is $185,000. Comparable rents for similar three-bedroom houses in the area are $1,500, $1,550, and $1,475 per month. We use $1,500, the middle value, and we do not use the highest comp.

The house needs $12,000 of work before it can be rented: paint throughout, new carpet in two bedrooms, a water heater replacement, minor plumbing repairs, and landscaping cleanup. The roof is eight years old and the HVAC is six years old, so neither needs immediate replacement, but both will need reserves.

Financing: a 20 percent down payment of $37,000, a loan of $148,000 at 7.5 percent interest for 30 years, with a monthly principal and interest payment of $1,035. Closing costs are $5,500. Total cash invested is the down payment plus closing costs plus renovation: $37,000 + $5,500 + $12,000 = $54,500.

Now the monthly operating picture:

- Gross rent: $1,500 per month, or $18,000 per year.
- Vacancy at 6 percent: $90 per month, or $1,080 per year.
- Effective gross income: $1,410 per month, or $16,920 per year.
- Property taxes: $225 per month ($2,700 per year).
- Insurance: $125 per month ($1,500 per year).
- Property management at 8 percent of rent: $120 per month ($1,440 per year).
- Maintenance reserve at 7 percent of rent: $105 per month ($1,260 per year).
- Capital expenditure reserve at 7 percent of rent: $105 per month ($1,260 per year).
- Total operating expenses: $680 per month, or $8,160 per year.

Net operating income is effective gross income minus operating expenses: $16,920 − $8,160 = $8,760 per year, or $730 per month.

Debt service is $1,035 per month, or $12,420 per year. Cash flow is NOI minus debt service: $8,760 − $12,420 = −$3,660 per year, or −$305 per month. This deal loses money every month on honest numbers. The cap rate is NOI divided by price: $8,760 ÷ $185,000 = 4.7 percent. The DSCR is NOI divided by debt service: $8,760 ÷ $12,420 = 0.71 — far below the 1.25 most lenders require.

This is the point of the exercise. At $185,000, this property does not work as a rental at $1,500 of rent with 7.5 percent financing. The seller's numbers might have shown a profit by omitting vacancy, maintenance, and CapEx. Yours do not.

### What price would make it work?

Work backward. For a target monthly cash flow of $200, the property needs annual cash flow of $2,400, which means NOI must be debt service plus $2,400. Debt service depends on the loan amount, which depends on the price, so solve it iteratively in the spreadsheet — but the approximate answer is instructive. If the price were $140,000, the loan at 20 percent down would be $112,000, the monthly payment would be about $783, and annual debt service would be about $9,396. NOI would be roughly the same $8,760 (taxes and insurance would fall slightly at the lower price, but we keep them constant for conservatism), so cash flow would still be slightly negative. At $130,000, the loan would be $104,000, the payment about $727 per month, annual debt service about $8,724, and cash flow would be about $36 per year — essentially break-even. At $120,000, the loan would be $96,000, the payment about $671 per month, annual debt service about $8,052, and cash flow would be about $708 per year, or $59 per month — still below a $200 target.

The honest conclusion is that this property, at $1,500 of rent, needs to sell for roughly $100,000 to $110,000 to produce $200 a month of cash flow at 7.5 percent interest — or it needs higher rent, a lower rate, or a larger down payment. That is not a failure of the method. It is the method working. You have learned in fifteen minutes that the asking price is roughly $75,000 too high for a rental, and you can now either negotiate from a position of knowledge or walk away and analyze the next deal.

### What changes the answer

Three levers change a rental analysis more than any others: price, rent, and interest rate. A $200 increase in monthly rent adds $2,400 a year to NOI and to cash flow, dollar for dollar. A one-point drop in the interest rate on a $148,000 loan saves roughly $100 a month. A $10,000 drop in price saves roughly $70 a month in debt service and $2,000 in down payment. When a deal is close, test each lever honestly: can the rent really be $1,700, or are you wishing? Can you really get a 6.5 percent rate, or is 7.5 percent the real quote? Can the seller really come down $20,000, or is that a fantasy? Only count levers you can defend.

### Rental underwriting checklist

Before you call a rental a "yes," confirm each of these: rent from three comps, not the listing; taxes from the county records, not the seller; insurance from an actual quote; vacancy, maintenance, and CapEx reserves included at the percentages above; management budgeted even if you self-manage; DSCR at or above 1.25; cash flow at or above your buy-box minimum; and cash-on-cash return at or above your buy-box minimum. If any item is missing, the deal is a "maybe" until you fill it in.

---

## 5. Strategy 2: Fix-and-Flip — Worked Example

A fix-and-flip is a short-term project: you buy a distressed property below market value, renovate it, and sell it for the after-repair value. The profit comes from buying right and renovating efficiently, not from hoping the market rises while you hold. Flips reward speed, accurate renovation budgets, and disciplined purchase prices. They punish optimism in all three.

### How to analyze a flip

The flip formula is simple: ARV minus purchase price minus renovation costs minus holding costs minus selling costs equals profit. Each term deserves its own verification. ARV comes from comparable sales. Renovation costs come from contractor bids or detailed line-by-line estimates plus contingency. Holding costs are the monthly cost of owning the property — mortgage, taxes, insurance, utilities — multiplied by the number of months you will hold it. Selling costs include agent commissions (typically 5 to 6 percent of the sale price), closing costs, and any seller concessions.

A useful guardrail is the 70 percent rule: a common starting point is to pay no more than 70 percent of ARV minus renovation costs. It is a rule of thumb, not a law — in expensive markets or for light renovations, investors often pay more; in risky markets or for heavy renovations, they pay less. Use it as a sanity check, not as a substitute for the full calculation.

### Worked example: a cosmetic flip

Consider a three-bedroom, one-and-a-half-bathroom house, 1,200 square feet, built in 1962, listed at $145,000. Comparable renovated houses nearby sold recently for $248,000, $255,000, and $242,000. We use an ARV of $245,000, the conservative end of the range.

The renovation is cosmetic-to-moderate: new kitchen cabinets and counters, two bathroom refreshes, new flooring throughout, interior and exterior paint, new light fixtures, landscaping, and minor repairs. The contractor's detailed estimate is $52,000. We add a 15 percent contingency of $7,800, for a total renovation budget of $59,800. We round to $60,000 for the analysis.

Financing: a hard-money or private loan covering 90 percent of the purchase price plus 100 percent of renovation costs, at 11 percent interest with 2 points. The purchase loan is $130,500; points on the total loan of $190,500 are $3,810. Cash invested is the 10 percent down payment of $14,500, plus points of $3,810, plus closing costs on purchase of $4,000, for a total of $22,310 before holding costs. Holding costs are $1,850 per month — interest, taxes, insurance, and utilities — and the project is expected to take five months from purchase to sale: $9,250.

Selling costs: agent commissions at 6 percent of $245,000 are $14,700; closing costs on sale are $2,500; total selling costs are $17,200.

Now the profit calculation:

- ARV: $245,000
- Less purchase price: −$145,000
- Less renovation: −$60,000
- Less holding costs: −$9,250
- Less selling costs: −$17,200
- Less loan points and purchase closing costs: −$7,810
- Profit: $5,740

A profit of $5,740 on a five-month project that risks $22,310 of cash is a poor return: about 26 percent on cash over five months sounds acceptable until you remember that a single surprise — a $6,000 sewer repair, a month of delay, a $5,000 price reduction — erases it entirely. The profit margin is $5,740 ÷ $245,000 = 2.3 percent. Most experienced flippers want a margin of at least 10 to 15 percent and a profit that justifies the risk, often a minimum of $20,000 to $30,000 on a project of this size.

Check the 70 percent rule: 70 percent of ARV is $171,500; minus renovation of $60,000, the maximum purchase price is $111,500. The asking price of $145,000 is $33,500 above that. The rule and the full calculation agree: this deal does not work at $145,000.

At a purchase price of $110,000, the calculation changes completely. The purchase loan falls, points fall, holding costs fall slightly, and profit becomes roughly $40,000. That is the price at which this flip works — and it is the number to take into the negotiation, along with the contractor's estimate and the comparable sales that support the ARV.

### Where flips go wrong

Flips go wrong in four predictable ways. First, the ARV is inflated: the investor uses the nicest house in the neighborhood, or a sale from a year ago, or a house with an extra bedroom. Second, the renovation is underestimated: the investor budgets for paint and flooring and discovers a bad roof, knob-and-tube wiring, or a cracked sewer line. Third, the timeline slips: permits take six weeks instead of two, a contractor disappears, or the market cools while the house sits. Fourth, the holding costs are forgotten: every extra month costs $1,850 in this example, so a two-month delay costs $3,700 — more than half the projected profit.

Protect yourself on all four: use conservative ARV comps, add contingency, budget holding costs for two months longer than the optimistic timeline, and never count on appreciation during the project. If the flip only works if the market rises, it is speculation, not investing.

### Flip underwriting checklist

Before you call a flip a "yes," confirm each of these: ARV from three recent comparable sales of renovated houses; renovation from a written contractor estimate plus 10 to 20 percent contingency; holding costs for the realistic timeline plus two extra months; selling costs at full commission; financing costs including points, fees, and interest; profit of at least your buy-box minimum in dollars and at least 10 percent margin; and an exit plan if the house does not sell — can it be rented, and at what rent?

---

## 6. Strategy 3: BRRRR — Worked Example

BRRRR stands for Buy, Rehab, Rent, Refinance, Repeat. You buy a distressed property, renovate it, rent it to a tenant, refinance it at its new value to recover most or all of your cash, and then repeat the process with the recovered cash. Done well, BRRRR lets you build a rental portfolio with far less cash left in each deal than a traditional purchase. Done poorly, it leaves you with an over-leveraged rental that loses money every month and cash you cannot recover.

### How to analyze a BRRRR

A BRRRR analysis has two stages. Stage one is the flip analysis: purchase price plus renovation plus holding costs, compared to ARV. Stage two is the rental analysis: the renovated property's rent, expenses, and new mortgage after refinance. The bridge between the two is the refinance: the lender will typically lend 70 to 80 percent of the appraised value (the ARV, if the appraisal agrees), and that loan pays off the original purchase and renovation financing. The cash left in the deal is your total cash invested minus the cash you recover at refinance. The goal is to leave as little cash in as possible while keeping the rental cash-flow positive after the new, larger mortgage.

The danger is buying a property whose ARV is not high enough to support a refinance that covers your costs. If you put $60,000 into a property and the refinance only returns $40,000, you have $20,000 left in the deal — and you must still earn a return on that $20,000 from the rent. Always calculate cash left in before you buy, not after you renovate.

### Worked example: a BRRRR with $18,000 left in

Consider a three-bedroom, two-bathroom house, 1,500 square feet, built in 1978, listed at $120,000. Comparable renovated houses sold for $218,000, $225,000, and $212,000. We use an ARV of $215,000. Comparable rents for renovated three-bedroom houses are $1,650 per month.

The renovation is moderate: kitchen refresh, two bathroom updates, flooring, paint, a water heater, and exterior work. The estimate is $48,000, plus a 15 percent contingency of $7,200, for a total of $55,200. We round to $55,000.

All-in cost: purchase $120,000 + renovation $55,000 + closing and financing costs $6,000 + holding costs during renovation $5,000 = $186,000. You fund this with cash and a short-term loan; for the analysis, total cash invested before refinance is $186,000, of which a portion may be borrowed and repaid at refinance — what matters is the net cash left in after refinance, so we track total cost against the refinance proceeds.

After renovation, the property is rented at $1,650 per month. The refinance: the lender appraises the property at $215,000 and lends 75 percent, or $161,250, at 7.25 percent for 30 years. The monthly principal and interest payment on $161,250 is $1,100. Cash recovered at refinance is $161,250. Cash left in the deal is $186,000 − $161,250 = $24,750.

Now the rental analysis after refinance. Monthly rent is $1,650. Vacancy at 6 percent is $99. Effective gross income is $1,551 per month. Operating expenses: taxes $240, insurance $130, management at 8 percent $132, maintenance at 7 percent $116, CapEx at 7 percent $116 — total $734 per month. NOI is $1,551 − $734 = $817 per month, or $9,804 per year. Debt service is $1,100 per month, or $13,200 per year. Cash flow is $9,804 − $13,200 = −$3,396 per year, or −$283 per month.

This BRRRR fails at the rental stage even though the refinance recovered most of the cash. The rent of $1,650 cannot support a $161,250 loan at 7.25 percent with honest reserves. The DSCR is $9,804 ÷ $13,200 = 0.74.

### What would make it work?

Two changes, separately or together. First, a lower all-in cost: if the purchase price were $95,000 instead of $120,000, all-in cost would be $161,000, cash left in would be roughly zero ($161,000 − $161,250), and the rental math would be unchanged — still negative, because the refinance loan is the same size. The refinance loan is set by the ARV, not by your cost. So lowering the purchase price fixes the cash-left-in problem but not the cash-flow problem.

Second, higher rent or a lower rate. At a rent of $1,950 per month, effective gross income would be $1,833, NOI would be about $1,064 per month, and cash flow would still be slightly negative at −$36 per month. At a rent of $2,050, cash flow would be about $40 per month. At a refinance rate of 6.25 percent, the payment on $161,250 would fall to about $993 per month, and cash flow at $1,650 rent would improve to about −$176 per month — still negative.

The honest conclusion: this property at $215,000 ARV and $1,650 rent cannot support a 75 percent refinance loan and cash flow at the same time. It would work as a BRRRR only if the rent were materially higher, the ARV were materially higher, or the investor accepted leaving more cash in and taking a smaller loan — for example, refinancing at 60 percent of value ($129,000), leaving $57,000 in the deal, with a payment of about $880 per month and cash flow of about −$63 per month — still short. The property is simply not a BRRRR at these numbers. It might work as a flip at the right purchase price, or as a rental bought at a discount with a smaller loan, but the BRRRR math does not close. Learning that before you buy is the entire value of the analysis.

### BRRRR rules to remember

Never count on the appraisal matching the ARV — budget for an appraisal 5 to 10 percent below your ARV and test the deal at that lower value. Never assume the lender will lend 80 percent; confirm the loan-to-value limit, the seasoning requirement (many lenders require you to own the property for six to twelve months before a cash-out refinance), and the DSCR requirement before you buy. And never do a BRRRR where the post-refinance rental loses money. A BRRRR that leaves no cash in but loses $283 a month is not a success; it is a liability you manufactured efficiently.

### BRRRR underwriting checklist

Confirm ARV from three comparable sales; confirm rent from three comparable rentals; confirm renovation from a written estimate plus contingency; calculate all-in cost; calculate refinance proceeds at a conservative loan-to-value and a conservative appraised value; calculate cash left in; calculate post-refinance cash flow, cash-on-cash return on cash left in, and DSCR; and confirm the lender's seasoning and DSCR rules in writing before you close on the purchase.


---

## 7. Strategy 4: Short-Term Rentals — Worked Example

A short-term rental (STR) is a furnished property rented by the night on platforms such as Airbnb or Vrbo. Nightly rates are much higher than long-term rent, but so are the costs: furnishing, cleaning, platform fees, utilities, supplies, management, and vacancy between bookings. STR income is also seasonal and sensitive to local regulation. Some cities cap the number of nights, require permits, or ban short-term rentals in certain zones. Always confirm the local rules before you analyze an STR — a deal that is illegal in its location is not a deal.

### How to analyze an STR

Start with the nightly rate and the occupancy rate from comparable listings. Multiply them to get gross revenue: nightly rate × 365 days × occupancy rate. Then subtract every expense: platform fees (typically 3 percent for the host on Airbnb, plus guest fees that affect pricing), cleaning costs, utilities, internet, supplies, property management or co-host fees (often 20 to 30 percent of revenue for full-service management), maintenance, CapEx reserves for furniture and appliances, taxes, insurance (short-term rental insurance costs more than a standard landlord policy), HOA dues, and mortgage payments.

The most common STR error is using peak-season rates and peak-season occupancy for the whole year. A property that earns $250 a night at 90 percent occupancy in July may earn $140 a night at 45 percent occupancy in February. Use an annual average, and test the low season separately.

### Worked example: a two-bedroom STR near a tourist area

Consider a two-bedroom, two-bathroom condo, 950 square feet, listed at $285,000, in a tourist area with year-round demand but clear seasonality. Comparable STR listings charge $165 to $210 per night. We use an average nightly rate of $175. Comparable occupancy is 55 to 70 percent annually. We use 62 percent, which is 226 booked nights per year.

Gross revenue: $175 × 226 nights = $39,550 per year. Platform fees at 3 percent are $1,187. Cleaning: the cleaner charges $85 per turnover, and with 226 nights at an average stay of 3.5 nights, there are about 65 turnovers, costing $5,525 — a portion of this is typically passed to guests as a cleaning fee, so we credit $4,000 of guest-paid cleaning fees, for a net cleaning cost of $1,525. Supplies, linens, and restocking are $150 per month, or $1,800 per year. Utilities and internet are $220 per month, or $2,640 per year. Property management at 20 percent of gross revenue is $7,910. Maintenance and CapEx reserves combined at 10 percent of gross revenue are $3,955. Taxes are $300 per month ($3,600 per year). Insurance for short-term rental use is $250 per month ($3,000 per year). HOA dues are $185 per month ($2,220 per year). Furnishing cost is $18,000 upfront, with furniture replaced on a five-year cycle — budget $3,600 per year in reserves, which is included in the CapEx figure above in simplified form; the template separates it.

Total operating expenses before debt service: platform fees $1,187 + net cleaning $1,525 + supplies $1,800 + utilities $2,640 + management $7,910 + maintenance and CapEx $3,955 + taxes $3,600 + insurance $3,000 + HOA $2,220 = $27,837 per year. NOI is $39,550 − $27,837 = $11,713 per year.

Financing: 20 percent down of $57,000, a loan of $228,000 at 7.75 percent for 30 years, monthly payment $1,634, annual debt service $19,608. Add furnishing of $18,000 and closing costs of $8,000, for total cash invested of $83,000. Cash flow is $11,713 − $19,608 = −$7,895 per year, or −$658 per month. This STR loses money at $175 a night and 62 percent occupancy with 20 percent management.

### What would make it work?

Test the levers. Self-managing instead of paying 20 percent saves $7,910 a year and turns cash flow to roughly break-even — but self-managing an STR is a part-time job: guest messages, cleanings, maintenance calls, and pricing. Count it only if you will actually do the work, and value your time. Raising the nightly rate to $210 and occupancy to 68 percent lifts gross revenue to $52,122, NOI to about $18,500, and cash flow to about −$1,100 per year — still short. A lower purchase price of $235,000 drops the loan to $188,000, the payment to about $1,347 per month, annual debt service to $16,164, and cash flow to about −$4,451 per year — still negative. Combining a $235,000 price with self-management brings cash flow to about $3,459 per year, or $288 per month, on $73,000 of cash invested — a 4.7 percent cash-on-cash return, below most investors' minimums for the workload an STR demands.

The lesson is not that STRs never work. It is that STRs need either a strong nightly rate, high occupancy, a low purchase price, or owner management — usually more than one of those at once. In this example, the property would need to be bought near $200,000, or to earn $225 a night at 70 percent occupancy with self-management, to produce a return that justifies the effort. Run those numbers before you fall in love with the listing photos.

### Seasonality: test the low season

Take the example above and test February alone: 28 days, 45 percent occupancy (about 13 nights), a nightly rate of $140. Revenue is $1,820. Monthly expenses — mortgage $1,634, taxes $300, insurance $250, HOA $185, utilities $220, management $364, cleaning and supplies $250 — total about $3,203. The low-season month loses about $1,383. That is normal for an STR. The question is whether the high season covers it. July: 31 days, 88 percent occupancy (27 nights), $215 a night. Revenue is $5,805. Monthly expenses are about $3,800. The high-season month earns about $2,005. A property that loses $1,383 in February and earns $2,005 in July can work over the full year — but only if you have the cash reserves to survive the low months. Budget for seasonality in cash, not just on paper.

### STR underwriting checklist

Confirm that short-term rentals are legal at this address, including permits, HOA rules, and night caps; confirm the nightly rate and occupancy from at least five comparable listings across seasons; include all STR-specific costs — furnishing, cleaning, platform fees, STR insurance, utilities, supplies, and management; test the low season separately; confirm your cash reserves cover three low-season months; and compare the STR return to the long-term rental return for the same property — sometimes the simpler strategy pays almost as well with far less work.

---

## 8. Building Your Buy Box

A buy box is a written set of criteria that a deal must meet before you pursue it. It is the single most valuable document in this toolkit, because it turns every decision into a comparison against your own standards instead of a negotiation with your own enthusiasm.

### What goes in a buy box

A complete buy box covers property, location, price, returns, and financing. Write yours in the workbook's buy-box worksheet and revisit it quarterly. A sample buy box for a long-term rental investor might read:

- Property: single-family houses, 3+ bedrooms, 1,200–2,000 square feet, built after 1960, no foundation issues, no flood zone.
- Location: within 30 minutes of home; school ratings 6/10 or above; crime below the city average; population growing or stable; at least two major employers nearby.
- Price: $100,000–$250,000; at least 10 percent below comparable renovated sales if renovation is needed.
- Returns: minimum $200 monthly cash flow per unit; minimum 10 percent cash-on-cash return; minimum 6 percent cap rate; DSCR at or above 1.25.
- Financing: 20–25 percent down; fixed rate; monthly payment that leaves cash flow positive after all reserves.
- Condition: renovation under $30,000; no roof, sewer, or structural work unless priced accordingly.
- Exits: property must also work as a flip or a BRRRR at a discount, or must be sellable to an owner-occupant.

Your buy box will differ. A flipper's buy box emphasizes ARV margin, renovation scope, and timeline. A BRRRR investor's emphasizes cash left in and post-refinance DSCR. An STR investor's emphasizes nightly rate, occupancy, legality, and seasonality. The templates include a buy-box scorecard that scores each deal from 0 to 100 against your criteria, so you can compare deals objectively instead of relying on memory.

### How to build yours

Start with your goals: how much cash can you invest per deal, how much monthly cash flow do you need, and how much time can you give? Then look at your market honestly: what do properties that meet your return targets actually cost, and how often do they appear? A buy box that no property in your market can meet is a wish list, not a tool. Adjust it until it is strict enough to protect you and realistic enough to produce deals — then hold it steady for at least a quarter before changing it. Changing your buy box for every deal is the same as having no buy box.

### Using the scorecard

Score each deal on the buy-box scorecard in the templates folder. A deal that scores 80 or above and meets every hard minimum — your non-negotiable floors for cash flow, DSCR, or profit — is worth pursuing. A deal that scores 80 but fails a hard minimum is not. A deal that scores below 60 is a pass, even if one metric looks exciting. The scorecard exists to stop a single attractive number from overriding the full picture.

---

## 9. The Offer-Price Calculator, Step by Step

The offer price is the highest price at which a deal still meets your buy box. It is not the asking price, and it is not a guess. It is a calculated number, and you should know it before you negotiate.

### For a rental

Start with market rent and honest expenses to get NOI. Decide your target cap rate or your target cash flow. If you work from a target cap rate, the maximum price is NOI divided by the target cap rate. If you work from a target cash flow, solve iteratively in the spreadsheet: lower the price until cash flow reaches your minimum, remembering that a lower price also lowers the down payment and the loan. The template does this calculation for you. In the rental worked example in Chapter 4, the maximum price for $200 a month of cash flow was roughly $100,000 to $110,000 — far below the $185,000 asking price. That gap is the negotiation, and it is also the reason most offers are declined. That is fine. You only need a few accepted offers a year.

### For a flip

The maximum offer is ARV minus renovation minus holding costs minus selling costs minus financing costs minus your target profit. Using the flip example: $245,000 ARV − $60,000 renovation − $9,250 holding − $17,200 selling − $7,810 financing − $25,000 target profit = $125,740 maximum offer. The 70 percent rule gave $111,500, which is more conservative because it implies a larger profit. Use the lower of the two as your ceiling, and open the negotiation below it so you have room to move.

### For a BRRRR

Calculate the maximum offer twice: once from the flip math (ARV minus costs minus a margin) and once from the rental math (the price at which post-refinance cash flow meets your minimum). The lower of the two is your ceiling. A BRRRR must work as both a renovation project and a rental; if it only works as one, it is not a BRRRR.

### For an STR

Calculate the maximum offer from the STR cash flow: the price at which annual cash flow reaches your minimum after all STR expenses. Because STR income is less certain than long-term rent, use a higher cash-on-cash minimum for STRs than for long-term rentals — the extra return compensates for the extra work and volatility.

### Negotiating with a number

When you make an offer below asking price, bring the math, not just the number. Sellers and agents respond better to "comparable sales support $245,000, renovation is $60,000, and my maximum is $125,000" than to "I will offer $125,000." The first is a business case. The second is a lowball. You will still be declined often. That is the cost of discipline, and it is far cheaper than overpaying.

---

## 10. Five-Year Projections That Tell the Truth

A one-year analysis tells you whether a deal works today. A five-year projection tells you whether it keeps working. Rents rise, expenses rise, mortgages stay fixed (on a fixed-rate loan), and equity builds. A good projection shows all of that, with conservative growth assumptions you can defend.

### Assumptions to use

Use modest assumptions and state them in writing. A reasonable starting set: rent growth 2 to 3 percent per year; expense growth 2 to 3 percent per year; property value appreciation 2 to 3 percent per year (or zero, if you want to test the deal without appreciation); vacancy, maintenance, and CapEx reserves held constant as percentages of rent. Never project rent growth of 5 percent or more for five years straight. Never project appreciation you need in order for the deal to work. The deal should work in year one on current numbers; appreciation is a bonus, not a plan.

### Worked example: five years on the rental

Return to a rental that works — not the Chapter 4 example, which did not, but a version bought at a price that does. Suppose you buy a house for $110,000, invest $12,000 in renovation, and rent it for $1,500 a month. Your loan is $88,000 at 7.5 percent, payment $615 per month. Year-one NOI is $8,760 (from Chapter 4's expense structure), debt service is $7,380, and cash flow is $1,380 per year, or $115 per month — below the $200 target, so even this is thin; suppose instead rent is $1,650, which lifts year-one NOI to about $10,400 and cash flow to about $3,020 per year, or $252 per month. Total cash invested is $22,000 down plus $5,000 closing plus $12,000 renovation, or $39,000. Year-one cash-on-cash return is $3,020 ÷ $39,000 = 7.7 percent.

Now project five years with rent growth of 2.5 percent and expense growth of 2.5 percent. Rent rises from $1,650 to about $1,820 by year five. NOI rises from about $10,400 to about $11,480. Debt service stays at $7,380 on a fixed-rate loan. Cash flow rises from $3,020 to about $4,100 per year. Cumulative cash flow over five years is about $17,600. The loan balance falls from $88,000 to about $81,500 as the tenant pays down principal — about $6,500 of equity from paydown. If the property appreciates 2 percent a year, its value rises from $110,000 to about $121,400 — about $11,400 of appreciation. Total wealth created over five years is roughly $17,600 + $6,500 + $11,400 = $35,500 on $39,000 invested, before taxes and before selling costs. That is the full picture: cash flow is only one of three returns, and a five-year view shows you all three.

### What to watch in a projection

Watch for three traps. First, expenses growing faster than rent — in markets where taxes or insurance rise sharply, cash flow can shrink even as rent rises. Second, a large capital expense in year three or four — a roof or HVAC replacement — that the projection ignores. Your CapEx reserve is meant to fund it, but check that the reserve balance actually covers it. Third, a refinance or sale assumption that depends on appreciation. If your five-year plan requires selling at a higher price to succeed, say so plainly and treat it as a risk, not a certainty.

### Building your projection

Use the five-year projection worksheet in the workbook. Enter year-one numbers from your template, apply your growth assumptions, and calculate cash flow, loan balance, and property value for each year. Then run a downside case: rent growth zero, expense growth 4 percent, and no appreciation. If the deal still cash flows in the downside case, it is a strong deal. If it only works in the upside case, it is a speculation.


---

## 11. Financing, DSCR, and the Cost of Money

Financing is not a detail. It is often the difference between a deal that works and a deal that does not. A property that cash flows at 6.5 percent may lose money at 7.5 percent. A lender's DSCR requirement can block a refinance you were counting on. Understand your financing before you make an offer, not after.

### Loan types you will encounter

Conventional investment-property loans typically require 20 to 25 percent down, a credit score of 620 or higher (with better rates above 720), and a DSCR of at least 1.20 to 1.25. FHA loans can be used for house hacking — buying a multi-unit property, living in one unit, and renting the others — with as little as 3.5 percent down, but you must occupy the property. Hard-money loans fund flips and BRRRR purchases quickly, often at 10 to 12 percent interest plus 1 to 3 points, with short terms of 6 to 12 months. Private money from individuals can be flexible but must be documented in writing, with clear terms, to protect both sides. Seller financing is possible when a seller owns a property outright and is willing to act as the lender; terms vary widely and must be reviewed by an attorney.

### How to compare loans

Compare loans on total cost, not just the interest rate. A loan at 7 percent with 2 points and $4,000 in fees may cost more over your holding period than a loan at 7.5 percent with no points. Ask every lender for the same quote in writing: loan amount, rate, fixed or adjustable, term, points, lender fees, monthly payment including or excluding escrow, prepayment penalty, and DSCR requirement. Get at least two quotes for every purchase. A second quote takes an hour and can save thousands.

### DSCR in practice

Lenders calculate DSCR from the property's income, not yours. They will use the lower of the actual rent and the appraiser's market rent, and they will apply their own vacancy and expense assumptions, which are often more conservative than yours. If your DSCR is 1.30 on your numbers and the lender's is 1.18, the loan may be declined or reduced. Build a margin: aim for a DSCR of 1.35 or higher on your own numbers so that the lender's more conservative calculation still clears 1.25.

### Rate risk and the refinance trap

Many BRRRR and flip plans assume a refinance at a lower rate in six months. Rates may not fall. Never buy a property that only works if you can refinance at a lower rate. Buy it because it works at today's rate, or because the flip profit does not depend on refinancing at all. The same applies to adjustable-rate loans: calculate the payment at the highest rate the loan allows, not the introductory rate.

---

## 12. Reserves: Vacancy, Maintenance, and CapEx

Reserves are the least glamorous part of this toolkit and the most important. They are the reason honest analyses look worse than sellers' analyses — and the reason honest investors survive.

### Vacancy

Vacancy is not just the weeks between tenants. It includes the cost of finding a new tenant (advertising, screening, leasing), the risk of a tenant who leaves early or does not pay, and the reality that some months a unit simply sits empty. Budget 5 to 8 percent of gross rent for long-term rentals. In lower-priced rentals, in student areas, or in markets with high turnover, use 8 to 10 percent. Keep a separate cash reserve of at least two months' rent per property, held in a savings account, so a vacancy never becomes a crisis.

### Maintenance

Maintenance is the recurring small work: fixing a leaky faucet, replacing a garbage disposal, patching drywall, servicing the HVAC, unclogging a drain. Budget 5 to 10 percent of gross rent. Older properties, properties with older systems, and properties with more tenants per unit need the higher end. Track your actual maintenance spending per property each year and adjust your budget to match reality.

### Capital expenditures (CapEx)

CapEx is the large, infrequent work: a roof ($8,000–$15,000), an HVAC system ($6,000–$12,000), a water heater ($1,200–$2,500), flooring ($4,000–$8,000), appliances ($2,000–$4,000), and a sewer line ($5,000–$15,000). These do not happen every year, which is exactly why investors forget them. Budget 5 to 10 percent of gross rent for CapEx reserves, and keep the money in a separate account. When the roof fails in year six, you will be glad the reserve exists. A useful exercise: list every major system in the property, its age, its expected remaining life, and its replacement cost. Divide cost by remaining life to get an annual reserve for that item, and add the items together. If the total is far above your percentage-based reserve, trust the itemized version.

### The 50 percent rule as a check

A common rule of thumb is that operating expenses, including vacancy, maintenance, and CapEx, will consume about 50 percent of gross rent over time. Use it as a check, not a substitute for line-by-line budgeting. In the Chapter 4 rental example, operating expenses were $680 a month on $1,500 of rent — 45 percent — which is consistent with the rule. If your line-by-line expenses total only 30 percent of rent, you have missed something. Find it before you buy.

---

## 13. Taxes, Insurance, and the Costs Beginners Miss

Three costs surprise new investors more than any others: taxes, insurance, and the small costs that add up.

### Property taxes

Property taxes vary enormously by location — from under 0.5 percent of value per year in some states to over 2 percent in others — and they can rise after a purchase, because many jurisdictions reassess value at sale. Always verify taxes from county records, confirm whether the current assessment reflects the purchase price, and budget for an increase. A property taxed at $2,700 a year on a $120,000 assessment may be taxed at $4,000 a year after it sells for $185,000. That $1,300 difference is $108 a month of cash flow.

### Insurance

Get an actual insurance quote before you make an offer. Landlord policies cost more than owner-occupied policies. Short-term rental policies cost more again. Flood insurance, where required, can cost thousands per year. Older roofs, older wiring, and properties in high-risk areas can carry higher premiums or be difficult to insure at all. An insurance quote takes a phone call and can change the entire analysis.

### The costs beginners miss

Budget for all of these: HOA dues and special assessments; utilities you pay (water, sewer, trash, and sometimes gas or electric for common areas or for STRs); lawn care and snow removal; pest control; turnover costs between tenants (cleaning, paint touch-ups, lock changes); legal costs for evictions, which can run into thousands of dollars even when you win; bookkeeping and tax preparation; and the cost of your own time. None of these is large alone. Together they are the difference between profit and loss.

### A note on taxes

Real estate offers tax benefits — depreciation, deductible expenses, and in some cases deferral of gains through a 1031 exchange — but tax law is complex, changes frequently, and depends on your individual situation. This toolkit does not provide tax advice. Consult a qualified tax professional before you rely on any tax benefit in your analysis, and never let a tax benefit turn a bad deal into a good one on paper. A deal should work before taxes; tax benefits are a bonus.

---

## 14. Comparing Deals Side by Side

Most investors analyze deals one at a time and choose the one in front of them. Better investors analyze several deals, compare them on the same metrics, and choose the best. Use the deal comparison sheet in the workbook for this.

### What to compare

Compare the same five outputs for every deal: monthly cash flow, cash-on-cash return, cap rate, DSCR, and total cash invested. Then add two qualitative scores: the buy-box scorecard result and a risk rating (low, medium, high) based on renovation scope, market, tenant profile, and financing. A deal with a 12 percent cash-on-cash return and high risk is not automatically better than a deal with a 9 percent return and low risk. Your time, your cash reserves, and your tolerance for work should shape the choice.

### An example comparison

Imagine three rentals. Deal A: $110,000 price, $252 monthly cash flow, 7.7 percent cash-on-cash, 6.1 percent cap rate, DSCR 1.41, $39,000 cash invested, low risk. Deal B: $185,000 price, −$305 monthly cash flow, negative return, 4.7 percent cap rate, DSCR 0.71, $54,500 cash invested, medium risk. Deal C: $150,000 price, $180 monthly cash flow, 9.2 percent cash-on-cash, 6.8 percent cap rate, DSCR 1.28, $42,000 cash invested, medium risk. The choice is clear: Deal A is best on cash flow and risk, Deal C is acceptable, and Deal B is a pass. Without the side-by-side comparison, an investor might have pursued Deal B because it was the newest listing or the nicest house. The comparison removes that bias.

### Opportunity cost

Every dollar you put into one deal is a dollar you cannot put into another. When you compare deals, you are also comparing them to doing nothing — holding cash — and to the next deal that may appear next week. If no deal on your desk meets your buy box, the right decision is to wait. Cash earns nothing, but it also loses nothing, and it is ready when the right deal appears. Patience is a strategy, not a failure.

---

## 15. Red Flags, Deal Killers, and When to Walk Away

Some problems can be priced. Others should end the deal. Learn the difference.

### Red flags to investigate

These do not automatically kill a deal, but each one demands verification and a price adjustment: a roof older than 15 years; an HVAC system older than 12 years; a water heater older than 8 years; signs of water damage, mold, or foundation movement; aluminum wiring or a fuse box instead of a circuit breaker panel; a sewer line that has never been scoped; a property in a flood zone; an HOA with pending litigation or a large special assessment; a tenant who will not allow an inspection; and a seller who will not provide rent rolls, leases, or expense records.

### Deal killers

Walk away when you find any of these, unless you have the expertise and the budget to solve them and the price reflects that: structural foundation failure; extensive mold or asbestos that requires professional remediation beyond your budget; a property that cannot legally be used for your intended strategy (for example, an STR ban or a zoning restriction); a title problem that cannot be cleared; a seller who misrepresents income, expenses, or condition in a way that destroys trust; or a deal that only works if you skip the inspection, skip the appraisal, or waive contingencies you need.

### The sunk-cost trap

The most expensive mistake in real estate is not passing on a good deal. It is refusing to walk away from a bad one because you have already spent money on an inspection, an appraisal, or a contractor bid. Those costs are sunk. They are gone whether you buy or not. The only question is whether the deal works from this point forward. If it does not, walk away. The inspection fee you lose is far cheaper than the property you should not have bought.

---

## 16. From One Deal to a Portfolio: Systems and Routines

Analyzing one deal well is a skill. Analyzing five deals a week, every week, without burning out, is a system. Build the system before you need it.

### Your weekly routine

Set aside two fixed blocks each week: one for finding and screening deals, and one for verifying the deals that passed the screen. In the screening block, run the 15-minute underwrite on every new listing that fits your buy box. Log each one with its decision. In the verification block, work the "yes" and "maybe" deals: verify comps, get contractor and insurance quotes, talk to lenders, and schedule inspections. Do not mix the two blocks. Screening is fast and broad; verification is slow and deep.

### Your deal log

Keep a simple log with the date, address, strategy, asking price, your offer price, the key outputs, and the decision. Review it monthly. You will start to see patterns: which neighborhoods produce workable deals, which property types consistently fail, which sellers price realistically, and how your own estimates compare to reality. Update your buy box and your reserve percentages based on what the log teaches you.

### Your team

No investor succeeds alone. Before you need them urgently, identify a real estate agent who understands investors, a lender who understands investment loans, a contractor who gives written estimates, a home inspector, an insurance agent, a real estate attorney, and a tax professional. Pay them fairly, communicate clearly, and keep their contact information in one place. A good team makes every deal faster and safer. A bad team — or no team — makes every deal slower and riskier.

### Scaling without breaking

Grow at a pace your cash reserves and your time can support. A common guideline is to keep at least six months of mortgage payments in reserve across your portfolio, plus the vacancy and CapEx reserves for each property. Adding a second property before the first is stable is how investors end up selling at a loss. Let each property prove itself — rented, cash flowing, reserves funded — before you add the next one.

---

## 17. Glossary

- **After-repair value (ARV):** The estimated market value of a property after renovation, based on comparable sales of renovated properties.
- **Cap rate:** Net operating income divided by property value, expressed as a percentage. Used to compare properties without financing.
- **Capital expenditure (CapEx):** Large, infrequent replacement costs such as a roof, HVAC system, or flooring.
- **Cash flow:** Net operating income minus debt service. The cash a property produces (or consumes) each month or year.
- **Cash-on-cash return:** Annual cash flow divided by total cash invested, expressed as a percentage.
- **Debt service:** The annual mortgage payment of principal and interest.
- **Debt service coverage ratio (DSCR):** Net operating income divided by annual debt service. Lenders typically require 1.20 to 1.25 or higher.
- **Effective gross income:** Gross income minus vacancy and credit loss.
- **Gross rent multiplier (GRM):** Property price divided by annual gross rent. A quick screening tool, not a substitute for full analysis.
- **Holding costs:** The monthly costs of owning a property during renovation or before sale: mortgage, taxes, insurance, and utilities.
- **Net operating income (NOI):** Effective gross income minus operating expenses, before debt service.
- **Operating expenses:** Recurring costs of owning and operating a property, excluding the mortgage.
- **Buy box:** A written set of criteria a deal must meet before you pursue it.

---

## 18. Final Checklist and Next Steps

Before your next deal, confirm you have: a written buy box; the four spreadsheet templates ready to use; your comp sources bookmarked; a lender, agent, inspector, contractor, and insurance agent identified; and a deal log started.

For your next deal, run the 15-minute underwrite, stress-test it, record your decision, and verify before you offer. Then do it again. The investors who succeed are not the ones who find a secret formula. They are the ones who underwrite honestly, pass on most deals, and buy the few that survive conservative numbers — and then do it again the next week.

### Disclaimer (repeated for clarity)

This toolkit is educational material only. It is not individualized investment, legal, tax, or financial advice. It does not guarantee any return. Worked examples are illustrative, and real results depend on market conditions, financing, execution, and factors outside your control. Verify every number, inspect every property, and consult licensed professionals before you invest.

*End of The Deal Analyzer Pro Toolkit.*
