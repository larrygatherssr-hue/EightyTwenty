# The Pet Grooming Business Academy — Workbook

Use this workbook alongside the course. Print it, or keep a copy on your phone or tablet at the grooming table. The exercises are designed to be completed as you work through the modules, not all at once at the end. A workbook that is finished is proof of practice. A workbook that is blank is a course that was only read.

**Safety reminder:** This workbook supports a grooming course. It teaches grooming technique, handling, hygiene, and business practice. It does not teach veterinary care. Any skin condition, lump, wound, ear infection, discharge, swelling, pain, or health concern you notice must be referred to a veterinarian. Never diagnose, never treat, and never present grooming advice as veterinary advice.

---

## Exercise 1 — Skills Self-Assessment

Rate yourself honestly on each skill, from 1 (never done it) to 5 (confident and consistent). Complete this at the start of the course, and again after Module 18. The gap between the two scores is your progress.

| Skill | Start (1–5) | End (1–5) | Notes |
|---|---:|---:|---|
| Identifying coat types | | | |
| Assessing skin and coat at intake | | | |
| Safe handling and restraint | | | |
| Reading dog stress signals | | | |
| Bathing and shampoo selection | | | |
| High-velocity drying | | | |
| Clipping technique (flat blade, even pressure) | | | |
| Scissoring and blending | | | |
| Poodle face and feet | | | |
| Teddy bear trim | | | |
| Schnauzer head (beard and brows) | | | |
| Dematting safely | | | |
| Nail trimming and grinding | | | |
| Ear checking and cleaning | | | |
| Puppy first groom | | | |
| Senior dog handling | | | |
| Pricing a groom from costs | | | |
| Rebooking clients | | | |
| Handling a complaint | | | |
| Salon cleaning and sanitation | | | |

**Reflection (write 3–5 sentences):** Which three skills improved most, and which one skill will you keep practicing in the next 90 days?

**How to use the scores:** A skill rated 1 or 2 is a priority — schedule practice for it in the coming week, using the action steps at the end of the matching module. A skill rated 3 is developing — keep it in your regular rotation. A skill rated 4 or 5 is a strength — use it to help a fellow student or a new hire, because teaching a skill is the fastest way to keep it sharp. If a score has not moved between your first and second assessment, that is useful information too: it tells you where to focus your next block of practice, rather than repeating what you already do well.

---

## Exercise 2 — Breed-Cut Practice Log

Log at least 25 practice grooms before claiming your certificate. Photograph each groom from the front, side, and back, and keep the photos with your log.

| # | Date | Dog (name/breed) | Coat type | Cut requested | Time taken | What went well | What to improve |
|---:|---|---|---|---|---|---|---|
| 1 | | | | | | | |
| 2 | | | | | | | |
| 3 | | | | | | | |
| 4 | | | | | | | |
| 5 | | | | | | | |
| 6 | | | | | | | |
| 7 | | | | | | | |
| 8 | | | | | | | |
| 9 | | | | | | | |
| 10 | | | | | | | |
| 11 | | | | | | | |
| 12 | | | | | | | |
| 13 | | | | | | | |
| 14 | | | | | | | |
| 15 | | | | | | | |
| 16 | | | | | | | |
| 17 | | | | | | | |
| 18 | | | | | | | |
| 19 | | | | | | | |
| 20 | | | | | | | |
| 21 | | | | | | | |
| 22 | | | | | | | |
| 23 | | | | | | | |
| 24 | | | | | | | |
| 25 | | | | | | | |

**Breed focus:** Groom at least three dogs each of your two most common breeds. Name your two focus breeds here: 1) _______________ 2) _______________

---

## Exercise 3 — Pricing Worksheet

Complete one worksheet per service, using your real costs. See Module 12 for the worked example.

**Service:** _________________________ **Breed/size:** _________________________

| Cost item | Amount |
|---|---:|
| Your time (hours × target hourly rate) | $ |
| Shampoo and conditioner | $ |
| Water, electricity, dryer wear | $ |
| Blade and shear wear, oil, coolant | $ |
| Towels, laundry, disinfectant | $ |
| Booking and card processing fees | $ |
| Share of fixed costs (rent, insurance, subscriptions) | $ |
| **Total cost** | **$** |
| **Price you will charge** | **$** |
| **Profit (price − total cost)** | **$** |
| **Profit margin (profit ÷ price)** | **%** |

**Check:** Is your profit margin at least 15%? If not, raise the price or reduce a cost — do not absorb the shortfall with longer hours.

**Monthly model:** Working days per month ____ × appointments per day ____ × average price $____ = gross monthly revenue $____. Minus monthly costs $____ = monthly profit before tax $____.

---

## Exercise 4 — Salon Setup Checklist

Tick each item as you buy it, and note the date and cost. Items are ordered by priority — buy in this order.

**Essential (needed before your first paying client):**

- [ ] Professional clipper with detachable blade system — Date: ______ Cost: $______
- [ ] Blades: #10, #7F, #5F, #4F, #3¾F, #30 — Date: ______ Cost: $______
- [ ] Snap-on guide comb set — Date: ______ Cost: $______
- [ ] High-velocity dryer — Date: ______ Cost: $______
- [ ] Shears: straight, curved, blending — Date: ______ Cost: $______
- [ ] Slicker brush, pin brush, bristle brush, fine comb — Date: ______ Cost: $______
- [ ] Dematting tool and mat splitter — Date: ______ Cost: $______
- [ ] Nail clippers and rotary grinder — Date: ______ Cost: $______
- [ ] Grooming table with lift and grooming arm with loop — Date: ______ Cost: $______
- [ ] Non-slip table mat — Date: ______ Cost: $______
- [ ] Bath tub with sprayer and non-slip base — Date: ______ Cost: $______
- [ ] Towels (at least 20) — Date: ______ Cost: $______
- [ ] Dog shampoos: general, whitening, hypoallergenic — Date: ______ Cost: $______
- [ ] Conditioner — Date: ______ Cost: $______
- [ ] Veterinary-grade disinfectant — Date: ______ Cost: $______
- [ ] Styptic powder — Date: ______ Cost: $______
- [ ] Happy hoodie and basket muzzles (2 sizes) — Date: ______ Cost: $______
- [ ] First-aid kit — Date: ______ Cost: $______
- [ ] Professional liability insurance — Date: ______ Cost: $______
- [ ] Booking system — Date: ______ Cost: $______

**Next stage (add as income grows):**

- [ ] Stand dryer or dryer arm
- [ ] Second clipper and spare blades
- [ ] Spare set of shears
- [ ] Grooming smocks and aprons
- [ ] Client waiting-area seating
- [ ] Signage and price-list board
- [ ] Camera for before-and-after photos

**Total equipment spend to date: $______**

---

## Exercise 5 — Client Intake Form

Complete one form per dog, at the first visit and updated at every visit. Keep it on file.

**Owner name:** _________________________ **Phone:** _________________________

**Dog name:** _________________________ **Breed:** _________________________ **Age:** ______ **Weight:** ______

**Sex:** ☐ Male ☐ Female **Neutered/spayed:** ☐ Yes ☐ No

**Vaccinations up to date:** ☐ Yes ☐ No **Veterinarian name and phone:** _________________________

**Health conditions or medication:** _______________________________________________________

**Allergies (products, foods, treats):** _______________________________________________________

**Has this dog ever bitten or snapped at a groomer or veterinarian?** ☐ Yes ☐ No — Details: _______________

**Sensitive areas (ears, paws, tail, other):** _______________________________________________________

**Previous grooming experience (good or bad):** _______________________________________________________

**Coat condition at intake:** ☐ Good ☐ Light matting ☐ Moderate matting ☐ Severe/pelted

**Skin check:** ☐ Clear ☐ Concern noted: _______________________________________________________

**Ears:** ☐ Clear ☐ Concern noted: _______________________________________________________

**Nails:** ☐ Normal ☐ Overgrown ☐ Dewclaws need attention

**Cut requested:** _______________________________________________________

**Price agreed:** $______ **Surcharges agreed (dematting, size, behaviour):** $______ **Total:** $______

**Anything found during the groom that the owner should know about (lumps, sores, redness, ear concerns):** _______________________________________________________

**Referral to veterinarian recommended:** ☐ Yes ☐ No — Reason: _______________________________________________________

**Owner signature:** _________________________ **Date:** _________________________

---

## Exercise 6 — Weekly Review (repeat every week)

1. How many grooms did I complete this week? ______
2. What was my average price per groom? $______
3. How many clients rebooked before leaving? ______ out of ______
4. What was the best groom this week, and why? _______________________________________________________
5. What was the hardest moment this week, and what did I learn from it? _______________________________________________________
6. One thing I will do differently next week: _______________________________________________________
