# Breed-Cut Reference Library

Use this library at the grooming table. Each entry gives the coat, the standard pet cut, the tools, and the details that make the cut recognizable. Confirm the style with the owner before you start — these are starting points, not orders.

---

## 1. Poodle (Toy, Miniature, Standard)

- **Coat:** Dense, curly, continuously growing. Mats at friction points.
- **Pet cut — Teddy Bear Trim:** Body and legs even at 13–25 mm using a guide comb over a #30 blade. Rounded face, rounded topknot, tail shaped into a pom or left natural per owner.
- **Pet cut — Puppy Clip:** Short, even cut all over at 6–13 mm (#5F or #4F). Easy care, good for active dogs.
- **Pet cut — Lamb Clip:** Body clipped short (#7F or #5F), legs left longer and scissored into full, round columns.
- **Face and feet:** Clip clean with a #10 or #15 blade. Hold the skin taut on the muzzle and between the toes.
- **Topknot:** Scissor round, blending into the ears. Comb the hair up and cut the ends that stick past the comb.
- **Time:** Toy 1.5 hours, Miniature 2 hours, Standard 2.5–3 hours.
- **Watch for:** Matting behind the ears, in the armpits, and between the back legs. Always comb through with a fine comb before clipping.

## 2. Doodle Mixes (Labradoodle, Goldendoodle, Bernedoodle)

- **Coat:** Varies by dog — wavy fleece, curly, or straighter. Assess each dog individually, never by its label.
- **Pet cut — Teddy Bear Trim:** Even length all over at 13–25 mm, rounded face, natural look. The most requested Doodle cut.
- **Face:** Rounded, with the hair between the eyes kept short enough not to poke the eyes. Ears blended into the head.
- **Tools:** Guide comb over a #30 blade for the body; blending shears for the legs and face; straight shears for shaping.
- **Time:** 2–3.5 hours depending on size and coat condition. Large Doodles are a full morning.
- **Watch for:** Matting is the biggest issue. Check behind the ears, under the collar, in the armpits, and behind the elbows first. If the coat is pelted, clip short and agree it with the owner before you start.

## 3. Shih Tzu

- **Coat:** Long, dense, double, continuously growing. Tangles easily.
- **Pet cut — Puppy Cut:** Short and even all over at 6–13 mm (#5F or #4F), rounded face. The most popular pet option.
- **Pet cut — Teddy Bear Trim:** Coat left at 13–25 mm, rounded face, ears left long and blended.
- **Face:** Rounded, full muzzle. Keep the hair over the nose short so it does not irritate the eyes. Keep the hair between the eyes short and clean.
- **Ears:** Left long and full. Check the base of the ears for matting — clip mats out rather than pulling at the thin ear leather.
- **Time:** 1–1.5 hours.
- **Watch for:** Eye irritation from hair in the eyes. Check the eyes at intake; redness or discharge means a veterinary referral, not a grooming fix.

## 4. Bichon Frise

- **Coat:** Soft, dense double coat with a coarser outer layer. Mats quickly, especially when damp.
- **Pet cut:** Body clipped to a soft, even length (usually 10–16 mm), legs scissored into full, round columns, head shaped into a soft, round cloud.
- **Head:** The signature shape. Scissor the head round, with the ears blending into the shape and the muzzle short and neat. Use curved shears and check the shape from every angle.
- **Finish:** Dry fully and fluff thoroughly. A Bichon that is not fully dry looks flat and stringy instead of soft and full.
- **Tools:** Guide comb for the body; curved shears for the head and legs; whitening shampoo used sparingly.
- **Time:** 1.75–2.25 hours.
- **Watch for:** Tear staining. Clean gently; heavy staining, redness, or odor means a veterinary referral.

## 5. Miniature Schnauzer

- **Coat:** Wiry outer coat over a softer undercoat. Clipping softens the coat over time; hand-stripping preserves texture.
- **Pet cut:** Body clipped short with a #7F or #5F blade. The clip line runs from the base of the skull along the back and down the sides to just below the ribcage. Skirt left longer at 13–25 mm on the belly and legs, scissored into a neat, straight line.
- **Head:** Top of the head clipped short. Eyebrows left long and combed forward. Beard left full and shaped into a rectangle. Ears clipped close inside and out.
- **Time:** 1.25–1.75 hours.
- **Watch for:** Clipper irritation on the belly and groin — use a sharp blade with light pressure. Explain the clipping-versus-stripping trade-off to owners who care about coat texture.

## 6. Cocker Spaniel (American and English)

- **Coat:** Medium-length, silky, with feathering on the ears, chest, belly, and legs. Mats easily in the feathering.
- **Pet cut:** Back clipped short (#7F or #5F), skirt and feathering left longer and scissored to a neat shape. Ears left long and full.
- **Feet:** Trim the hair between the pads so the dog does not slip. Keep the nails short.
- **Ears:** Check at every visit. Redness, odor, or dark discharge means a veterinary referral — do not clean an infected ear.
- **Time:** 1.5–2 hours.
- **Watch for:** Matting behind the ears and in the armpits. Comb these areas at every groom.

## 7. Golden Retriever

- **Coat:** Double coat with a dense undercoat. Never shave.
- **Pet cut:** Bath, thorough undercoat removal, tidy-up of the feathering, neat trim of the feet, ears, and tail. Thin the feathering on the chest, belly, and back of the legs with blending shears so it looks natural.
- **Feet:** Trim into neat, round "cat feet."
- **Ears:** Trim to a tidy shape, keeping the natural outline.
- **Time:** 1.5–2 hours, plus a de-shedding treatment in spring and autumn.
- **Watch for:** Heavy seasonal shedding. Sell the de-shedding treatment as a package, not an afterthought. The owner should not be able to tell where you cut.

## 8. West Highland White Terrier (Westie)

- **Coat:** Wiry double coat. Clipped or hand-stripped depending on owner preference.
- **Pet cut:** Body clipped short, skirt and legs left fuller. Head shaped into a round "chrysanthemum" shape, with the ears tipped.
- **Face:** Round and full, with the hair around the muzzle kept tidy so it does not cover the eyes.
- **Time:** 1.5–2 hours.
- **Watch for:** Sensitive skin on the belly and groin. Terriers are opinionated on the table — handle the face calmly and do not rush it.

## 9. Yorkshire Terrier

- **Coat:** Long, silky, continuously growing. Fine and prone to tangling.
- **Pet cut — Puppy Cut:** Short and even at 6–13 mm, rounded face, ears tipped. The most popular pet option.
- **Pet cut — Long Coat:** Coat left long and parted down the back, kept clean and brushed daily by the owner. Only suitable for owners who brush every day.
- **Face:** Small and neat. Keep the hair between the eyes short. Topknot tied up or clipped short per owner preference.
- **Time:** 1–1.5 hours.
- **Watch for:** The fine coat mats fast, especially under a harness. Line-brush to the skin.

## 10. German Shepherd

- **Coat:** Dense double coat. Heavy seasonal shedding. Never shave.
- **Pet cut:** Bath, undercoat removal with a high-velocity dryer and thorough brushing, tidy of the feet and ears, nail care. No clipping of the body coat.
- **Feet:** Trim the hair between the pads and shape the feet neatly.
- **Time:** 1.5–2 hours, longer during coat-blowing season.
- **Watch for:** Undercoat packed tight against the skin. Work in sections with the dryer and brush until the undercoat is fully out. A Shepherd that is not fully de-shedded will shed at home for weeks.

---

## Quick Reference Table

| Breed | Body length | Face | Signature feature | Typical time |
|---|---|---|---|---|
| Poodle | 13–25 mm (teddy) | Clean clip #10/#15 | Clean face and feet, round topknot | 1.5–3 hrs |
| Doodle | 13–25 mm | Rounded | Soft, even teddy finish | 2–3.5 hrs |
| Shih Tzu | 6–13 mm (puppy cut) | Rounded, full muzzle | Round face, long ears | 1–1.5 hrs |
| Bichon Frise | 10–16 mm | Round cloud head | Round sculpted head, full legs | 1.75–2.25 hrs |
| Miniature Schnauzer | #7F/#5F body | Rectangular beard | Beard, brows, skirt | 1.25–1.75 hrs |
| Cocker Spaniel | #7F/#5F back | Natural | Long ears, feathered skirt | 1.5–2 hrs |
| Golden Retriever | No body clip | Natural | Natural, unnoticeable tidy | 1.5–2 hrs |
| Westie | Short body | Round chrysanthemum | Round head, skirt | 1.5–2 hrs |
| Yorkshire Terrier | 6–13 mm (puppy cut) | Small, neat | Silky finish, tipped ears | 1–1.5 hrs |
| German Shepherd | No body clip | Natural | Full undercoat removal | 1.5–2 hrs |
