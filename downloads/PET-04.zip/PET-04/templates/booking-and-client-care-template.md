# Booking and Client-Care Template

Use this template for every appointment. Part A is completed at booking. Part B is completed at handover and given to the owner.

---

## Part A — Booking Form

**Salon name:** _________________________ **Date of booking:** _________________________

**Owner name:** _________________________

**Phone:** _________________________ **Email:** _________________________

**Dog name:** _________________________ **Breed:** _________________________ **Age:** ______ **Weight:** ______

**Service booked:** ☐ Full groom ☐ Bath and tidy ☐ De-shedding treatment ☐ Nail trim ☐ Nail trim and grind ☐ Puppy first groom ☐ Other: _______________

**Cut requested:** _______________________________________________________

**Appointment date and time:** _________________________ **Groomer:** _________________________

**Price quoted:** $______ **Deposit taken:** $______ **Balance due:** $______

**Cancellation policy (read to the client and ticked):** ☐ 48 hours' notice to cancel or reschedule without losing the deposit. No-show or late cancellation forfeits the deposit.

**Health or behaviour notes from the owner:** _______________________________________________________

**Allergies:** _______________________________________________________

**Reminder sent:** ☐ 48 hours before ☐ Day before

---

## Part B — Aftercare Instructions (give to the owner at handover)

**Dog:** _________________________ **Date of groom:** _________________________

**What we did today:**
- ☐ Bath and dry
- ☐ Full groom — cut: _________________________
- ☐ De-shedding treatment
- ☐ Nails trimmed / ground
- ☐ Ears checked and cleaned
- ☐ Teeth brushed
- ☐ Matting removed — areas: _________________________

**How to keep the coat looking good until the next visit:**
- Brush to the skin two to three times a week, using a slicker brush and then a fine comb. If the comb will not pass through, there is a mat forming — work it out gently or book a visit.
- Pay special attention to the friction points: behind the ears, under the collar, in the armpits, and between the back legs.
- If the coat gets wet (rain, swimming, bath at home), dry it and brush it out the same day. Wet coats mat fast.
- Do not use human shampoo on your dog. If you bathe your dog at home, use a dog shampoo and rinse thoroughly.

**Next groom due:** _________________________ **Next appointment booked:** ☐ Yes — Date/time: _________________________ ☐ Not yet — please call to book.

**Things we noticed today (if any):**
___________________________________________________________________________
___________________________________________________________________________

If we noted anything about your dog's skin, ears, teeth, or general health, we have written it above. We are groomers, not veterinarians: if we suggested a veterinary check, please follow up with your veterinarian. Any skin condition, lump, ear infection, or health concern should be checked by a veterinarian.

**Questions?** Contact the salon at: _________________________

Thank you for trusting us with your dog. We look forward to seeing you both again.
