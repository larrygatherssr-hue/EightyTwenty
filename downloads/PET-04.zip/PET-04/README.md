# The Pet Grooming Business Academy — PET-04

A grooming skills and business academy for career-changers and pet lovers who want to become professional groomers or open a grooming salon or mobile service. Price: $697 (one-time).

## Files

| File | What it is |
|---|---|
| `content.md` | The full course: 18 modules, fully written (coat and skin science, handling, bathing, clipping, breed cuts, matting, nails/ears/teeth, puppy/senior/anxious protocols, safety, equipment, pricing, booking, clients, mobile grooming, hiring, launch, first 90 days). |
| `workbook.md` | Exercises and worksheets: skills self-assessment, 25-groom practice log, pricing worksheet, salon setup checklist, client intake form, weekly review. |
| `templates/salon-pricing-calculator.csv` | Price build-up for 16 services, with costs, time, profit, and margin. |
| `templates/breed-cut-reference.md` | Cut specifications for 10 popular breeds, with a quick-reference table. |
| `templates/booking-and-client-care-template.md` | Booking form plus aftercare instructions to give the owner at handover. |
| `sales-page.md` | Sales copy: headline, problem, solution, module list, who it is for / not for, price, FAQ, disclaimers. |
| `listing.json` | Marketplace listing data (SKU, name, category, price, headline, description, delivery note, SEO keywords, refund policy, support). |
| `cover.md` | Cover design brief (black-and-gold luxury branding). |
| `cover.png` | The product cover image. |
| `onboarding.md` | What to do first, how to use the materials, a 6-week schedule, and how to get support. |
| `README.md` | This file. |

## Safety note

This product teaches grooming technique, handling, hygiene, and business practice. It does not teach veterinary care. Any skin condition, lump, ear infection, or health concern must be referred to a veterinarian.
