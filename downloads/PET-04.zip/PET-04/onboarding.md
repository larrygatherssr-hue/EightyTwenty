# Getting Started — The Pet Grooming Business Academy

Welcome. You now own the complete academy: the course, the workbook, the templates, and the certificate path. This page tells you what to do first, how to use the materials, and how to work through the program in six weeks.

## What to do first

1. **Read the safety note.** Before anything else, read the safety and scope note at the start of content.md. It states the rule that runs through the whole course: this academy teaches grooming technique, handling, hygiene, and business practice. It does not teach veterinary care. Any skin condition, lump, ear infection, or health concern must be referred to a veterinarian. Never diagnose and never treat.
2. **Skim the whole course.** Spend thirty minutes reading the module titles and the action steps at the end of each module. This gives you the map before you start the journey.
3. **Print or save the workbook.** Print workbook.md, or keep it on a tablet at your grooming table. Complete the skills self-assessment (Exercise 1) now, before you start Module 1, so you have a baseline to measure against.
4. **Line up your first practice dogs.** You will need dogs to practice on — your own, a friend's, or volunteer dogs. Aim for three dogs in your first two weeks. Confirm each dog's vaccination status and ask the owner about health issues, sensitivities, and any history of biting before you begin.
5. **Check your equipment.** Read Module 11 and the salon setup checklist in the workbook. You do not need everything before you start, but you do need a clipper, a dryer, shears, brushes, a comb, and a safe table before your first practice groom.

## How to use the materials

- **content.md** is the course itself: 18 modules, fully written, in order. Work through them in sequence. Each module ends with action steps — do them before moving on.
- **workbook.md** is your practice record. Complete the exercises as you go: the self-assessment, the 25-groom practice log, the pricing worksheet, the salon setup checklist, the client intake form, and the weekly review.
- **templates/breed-cut-reference.md** is your table-side reference. Keep it open during grooms. It covers ten popular breeds with cut specifications.
- **templates/salon-pricing-calculator.csv** is your pricing tool. Open it in a spreadsheet, replace the example figures with your real costs, and use it to set your prices.
- **templates/booking-and-client-care-template.md** is your booking form and aftercare sheet. Use it for every appointment, and give the aftercare sheet to the owner at handover.

## Suggested 6-week schedule

**Week 1 — Foundations (Modules 1–3).** Coat and skin science, safe handling, bathing and drying. Practice: bath and dry two dogs, line-brush a long coat until a comb passes through. Complete the skills self-assessment.

**Week 2 — The craft (Modules 4–6).** Clipping, scissoring, and breed cuts. Practice: groom two dogs with a teddy bear trim, and study the breed-cut reference library. Start your practice log.

**Week 3 — The hard parts (Modules 7–9).** Matting, nails, ears, teeth, and puppy, senior, and anxious-dog protocols. Practice: demat a small mat safely, trim nails on three dogs, and plan a puppy first groom.

**Week 4 — Safety and equipment (Modules 10–11).** Salon safety, sanitation, and equipment. Practice: set up your cleaning checklist, price your essential kit, and start a maintenance log.

**Week 5 — The business (Modules 12–14).** Pricing, booking, and client communication. Practice: complete the pricing worksheet for three grooms, write your price list, and set up your booking and reminder system.

**Week 6 — Launch (Modules 15–18).** Mobile grooming, hiring, launching, and your first 90 days. Practice: write your launch checklist, your 90-day plan, and your first three client intake forms. Complete the workbook and review your self-assessment scores.

After week 6, follow the 90-day plan in Module 18: three dogs a week in month one, five a week in month two, and a full review of your numbers in month three. Log 25 grooms to earn your certificate of completion.

## How to get support

If you have a problem with your purchase, a file that will not open, or a question about the materials, email marketplace support with your order number and a description of the issue. Include the file name if the problem is with a specific file.

If you have a question about a grooming technique, re-read the relevant module and try the action steps on a practice dog before changing your approach. Grooming is learned by doing, and the workbook is designed to guide that practice.
