# The Pet Grooming Business Academy

## Welcome

This academy teaches two trades at once: the craft of professional dog grooming and the business of running a grooming salon or mobile service that earns a living. Most cheap online courses teach theory only. This course is different. Every module ends with action steps, every technique is tied to a real dog on a real table, and every business lesson is tied to real numbers. Work through the modules in order. Practice on your own dog, a friend's dog, or a volunteer dog before you ever charge a client. Keep this document beside your grooming table and beside your price list. It is both a textbook and a working manual.

**A note on safety and scope.** Grooming is a skilled, safety-critical trade. This course teaches grooming technique, handling, hygiene, and business practice. It does not teach veterinary care, and nothing in it should be read as veterinary advice. Grooming is not diagnosis and it is not treatment. If you see a skin condition, a lump, a wound, an ear infection, discharge, swelling, pain, or anything else that looks like a health concern, stop, tell the owner, and refer the dog to a veterinarian. Do not attempt to diagnose it, treat it, or shave over it without veterinary guidance. When in doubt, refer out. A groomer who refers promptly earns trust; a groomer who guesses risks a dog's health and their own livelihood.

---

## Module 1 — Coat and Skin Science

A groomer who understands coat and skin makes better decisions at every step: which shampoo to reach for, which blade to choose, whether a coat can be dematted or must be clipped short, and when to stop and call the owner. A groomer who does not understand coat and skin guesses, and guessing shows up as clipper burn, broken coat, irritated skin, and unhappy clients.

### The skin

A dog's skin is thinner than human skin — roughly one-third to one-fifth as thick in the epidermis — and its pH is different. Human skin sits around pH 4.5 to 5.5. A dog's skin sits around pH 6.2 to 7.4, closer to neutral. That is why human shampoo is wrong for dogs: it is formulated for a more acidic surface and can strip and irritate canine skin. Use products made for dogs, and use them at the dilution the manufacturer specifies. More concentrate is not more cleaning; it is more residue, and residue itches.

Healthy skin is supple, free of flaking, redness, odor, and broken areas. Learn what healthy skin looks and feels like on many dogs so that unhealthy skin stands out immediately. Run your hands over the whole dog at intake, before water touches the coat. Feel for lumps, hot spots, scabs, fleas, ticks, and tender areas. Note anything you find on the intake form and tell the owner before you begin. This protects the dog, and it protects you from being blamed for something that was already there.

### Coat types

Dogs do not have one kind of coat. They have several, and each behaves differently under clippers, scissors, water, and a dryer.

**Smooth coats** (Labrador, Beagle, Boxer) are short, dense, and close-lying. They shed steadily. Grooming is mostly bathing, drying, and de-shedding with a rubber curry or a de-shedding tool used gently. Clipping is rarely needed and usually wrong.

**Double coats** (Golden Retriever, Husky, German Shepherd, Samoyed) have a soft, dense undercoat beneath longer guard hairs. The undercoat sheds seasonally in heavy "blow-outs." Never shave a double coat to "fix" shedding. Shaving damages the guard hairs, can change the coat texture permanently, and removes the insulation that keeps the dog cool in summer and warm in winter. Brush out the undercoat, bathe, and use a high-velocity dryer to blow loose undercoat free.

**Long, silky coats** (Yorkshire Terrier, Maltese, Afghan Hound) grow continuously and tangle easily. They need regular brushing to the skin, not just over the top layer. A brush that glides over the surface while mats form underneath is the most common beginner mistake. Learn the line-brushing technique: part the coat in thin lines and brush each line from the skin outward.

**Curly and wavy coats** (Poodle, Bichon Frise, Doodle mixes) also grow continuously and mat quickly, especially at friction points — behind the ears, under the collar, in the armpits, and between the back legs. These coats are the groomer's bread and butter, and they are also the most demanding. They need thorough drying and fluffing, and they hide mats well. Always comb through with a fine-toothed comb after brushing. If the comb will not pass through, the coat is not finished.

**Wire coats** (many terriers, Schnauzers) have a harsh outer coat over a softer undercoat. Traditionally they are hand-stripped — dead outer hairs pulled out by hand or with a stripping knife — which preserves color and texture. Many pet clients prefer clipping instead, which is faster and cheaper but softens the coat over time. Know both, explain the difference to the owner, and charge accordingly: hand-stripping takes far longer.

**Hairless and short-coated breeds** need skin care more than coat care. Watch for sunburn, dryness, and irritation, and keep baths gentle and infrequent unless the veterinarian advises otherwise.

### The hair growth cycle

Hair grows in a cycle: growth (anagen), transition (catagen), rest (telogen), and shedding (exogen). Breeds whose coats grow continuously, like Poodles, spend a long time in anagen; breeds with seasonal coats shed heavily when many follicles enter telogen together. This is why a Husky "blows coat" twice a year and a Poodle does not. It also explains why a shaved double coat can take many months to grow back, and sometimes grows back patchy or changed in texture. Tell owners this before you clip, not after.

### Coat assessment at intake

Before every groom, assess the coat in five minutes: run your fingers through it, part it in several places, check the friction points, smell it, look at the skin underneath. Grade the matting honestly — light, moderate, or severe — and agree the approach and the price with the owner before the dog goes on the table. A coat that is pelted (matted solidly to the skin) cannot be brushed out humanely. It must be clipped short under the mat, and the owner must understand why.

### Action steps

1. Practice identifying the six coat types above on ten different dogs — in person, in photos, or at a dog park — and write down what you see.
2. Line-brush a long-coated dog until a fine comb passes through every section. Time yourself; that time is your baseline.
3. Write your own one-paragraph explanation of why you never shave a double-coated breed, in words a client would understand.

---

## Module 2 — Safe Handling and Restraint

Nothing in this course matters more than this module. A frightened dog can bite in a fraction of a second. A dog that falls from a table can break a leg or its neck. A groomer who rushes handling loses clients, gets bitten, and hurts dogs. Calm, confident, predictable handling is the foundation of everything else.

### Reading the dog

Learn to read stress signals before they become a bite. A dog that is lip-licking, yawning, turning its head away, showing the whites of its eyes (whale eye), freezing, or tucking its tail is telling you it is uncomfortable. A frozen dog is not a calm dog; freezing is often the last warning before a snap. A dog that is panting hard, pacing, or trying to climb off the table is over threshold. Slow down, give the dog a break, and change your approach. The groom is not worth a bite — to the dog, to you, or to your business.

At intake, ask the owner the questions that keep everyone safe: Has the dog ever bitten or snapped at a groomer or veterinarian? Is it sensitive anywhere — ears, paws, tail? Has it had a bad grooming experience? Is it on any medication? Does it have any condition, such as epilepsy or a heart problem, that changes how it should be handled? Write the answers on the intake form. If an owner tells you the dog bites, believe them, and decide honestly whether you can groom that dog safely. Saying no to a dog you cannot handle safely is professional, not a failure.

### The grooming loop and the table

A grooming loop (also called a noose) is a safety tool, not a punishment. It keeps a dog from jumping off the table. Use a loop that fits snugly but not tightly — you should be able to slip two fingers between the loop and the neck. Never leave a dog unattended on a table with a loop on. Never use a loop on a dog with a collapsing trachea or a severe breathing problem; ask the owner and, if in doubt, groom the dog on the floor or on a non-slip mat with a helper instead. A dog left alone on a table can hang itself in seconds. This is not an exaggeration; it is the single most serious accident in grooming, and it is entirely preventable.

Use a non-slip mat on the table. Keep the table at a height where you can work without bending over the dog. Move the table height, not your back.

### Lifting and positioning

Lift small dogs with one hand under the chest and one under the hindquarters. Lift larger dogs by guiding them up a ramp or steps rather than hauling them onto the table — your back and the dog's joints will thank you. Never lift a dog by its legs, its tail, or the scruff of its neck. Keep the dog's weight supported at all times.

When you need a paw, lift it gently from below and support the leg at the joint. Do not pull a leg out sideways or twist it. When you need the face, hold the chin or the muzzle gently from underneath, never by squeezing the muzzle shut. When you need the tail, lift it by the base and support it.

### Restraint that works

Good restraint is minimal restraint. Most dogs stand still when they feel secure, when the surface does not slip, when the room is calm, and when the groomer moves smoothly and predictably. Use a second loop around the waist (a belly loop or grooming harness) for dogs that sit or try to lie down, but never use it to force a dog to stand when it is in pain. Use a happy hoodie or cotton in the ears to muffle dryer noise for sensitive dogs. Use a second person as a holder for nervous dogs rather than tightening restraints further.

Muzzles have a place. A properly fitted basket muzzle allows a dog to pant and breathe while keeping teeth away from your hands. Use one when a dog is genuinely snapping, and tell the owner you used it and why. Never muzzle a dog that is brachycephalic (flat-faced, such as a Pug or Bulldog) and already struggling to breathe, and never leave a muzzle on a dog in a dryer or a crate. If a dog needs a muzzle for the entire groom, ask whether the dog should be groomed by a veterinarian or a behaviorist instead. Some dogs are beyond the scope of a grooming salon, and recognizing that is a skill.

### If a dog bites

Stay calm. Do not pull away sharply — that tears skin. Do not punish the dog. Secure the dog safely, stop the groom, and give first aid to the wound. Clean it, apply pressure if it is bleeding, and seek medical attention for any bite that breaks the skin. Record the incident in writing: the date, the dog, what happened, what you were doing, and what you did next. Tell the owner honestly. A bite report is not an admission of failure; it is a professional record, and it protects everyone.

### Action steps

1. Watch five dogs at a park or shelter and write down three stress signals you see in each.
2. Practice fitting a grooming loop and a basket muzzle on a calm, cooperative dog until you can do it smoothly in under a minute.
3. Write your intake questions on a card and keep it at your front desk until you know them by heart.

---

## Module 3 — Bathing and Drying

Bathing is where most grooms are won or lost. A coat that is not fully clean will not clip evenly, will not dry fluffy, and will dull your blades. A dog that is not fully dry will mat again within days. Bathing is not a rinse; it is a process, and the process has an order.

### Before the water

Brush the dog before the bath. Water tightens mats, so a mat that could have been brushed out dry becomes a solid felted lump when wet. Remove as much loose hair, dirt, and debris as you can first. Check the ears for redness or odor — if you see either, note it, tell the owner, and do not put water in the ears. Place a cotton ball loosely in each ear to keep water out, and remember to remove both afterward. Count them: two in, two out.

Protect the eyes. Never spray water or shampoo directly at the face. Wash the face last, with a damp cloth or a small sponge and a tearless face wash, wiping away from the eyes.

### Choosing and diluting shampoo

Match the shampoo to the coat and the skin. A general-purpose dog shampoo suits most healthy coats. A whitening shampoo helps white coats but can dry the skin if overused. A medicated shampoo is for dogs whose veterinarian prescribed it — follow the veterinarian's instructions, including contact time, and never substitute a medicated product for a veterinary visit. An oatmeal or hypoallergenic shampoo suits sensitive or itchy skin. A de-shedding shampoo supports undercoat removal in heavy shedders.

Dilute as the label directs. Most professional shampoos are concentrates designed to be diluted, often between 4:1 and 32:1. Diluted shampoo spreads more evenly, rinses out more completely, and costs less per bath. Undiluted shampoo is harder to rinse and leaves residue that itches. Mix only what you need for the day; diluted shampoo does not keep.

### The bath, step by step

Wet the coat thoroughly with lukewarm water — warm enough to be comfortable on the inside of your wrist, never hot. Work from the neck down and the back toward the tail, keeping water out of the ears and eyes. Apply shampoo and work it through the coat with your fingertips, massaging down to the skin. Pay attention to the dirty areas: paws, belly, rear, and behind the ears. Let the shampoo sit for the time the label recommends — usually three to five minutes — so it can do its work. Then rinse, rinse, and rinse again. Shampoo residue is the most common cause of itchy skin after grooming. Rinse until the water runs clear and the coat squeaks slightly between your fingers. If the dog is very dirty, wash twice: the first wash removes dirt, the second wash cleans the coat.

Conditioner is not optional for long, curly, or easily tangled coats. It closes the hair cuticle, reduces static, and makes brushing and drying far easier. Apply it after rinsing, leave it for the recommended time, and rinse lightly — a little conditioner left in the coat helps a long coat stay manageable, but too much leaves it greasy.

### Drying

Drying is half the groom. A coat dried carelessly will be wavy, flat, or matted again by morning.

Start by squeezing excess water from the coat with your hands, then wrap the dog in a towel and press — do not rub vigorously, which tangles long coats. Then use a high-velocity dryer. A high-velocity dryer blows water out of the coat and separates the hair, which is what creates the fluffy, straight finish on Poodles, Bichons, and Doodles. Work in sections, holding the nozzle a few inches from the coat and moving constantly so the air never sits in one place. Dry with the direction of hair growth for a smooth finish, and brush as you dry: dry a section, brush it, move on. Keep the dryer on a low or medium setting around the face, ears, and belly, and never point it directly into the ears or eyes.

A stand dryer or a cage dryer has a place for finishing or for dogs that tolerate it, but never leave a dog unattended in front of a heated dryer, and never use a heated dryer on a brachycephalic dog or a dog that is panting hard. Heat stroke in a grooming salon is rare and entirely preventable. If a dog is overheating, stop, move it to a cool area, offer water, and let it rest.

Check dryness with your hands and a comb. The coat should feel dry all the way to the skin — especially in the armpits, behind the ears, and between the back legs, where dampness hides. If the comb catches, the coat is not finished.

### Bathing frequency and skin health

Most pet dogs do well with a bath every four to eight weeks. Bathing more often is fine if you use a gentle shampoo and rinse thoroughly, but over-bathing with a harsh product strips natural oils and dries the skin. If a dog's skin is flaky, red, or irritated after grooming, review your products and your rinsing before you blame the dog. And remember the rule from Module 1: skin problems get referred to a veterinarian. You can note them, you can photograph them for the owner, but you do not diagnose or treat them.

### Action steps

1. Time a full bath and dry on three different coat types and record the times; these become your scheduling baseline.
2. Practice the two-wash method on a dirty dog and compare the rinse water after wash one and wash two.
3. Write your shampoo shelf list: one general, one whitening, one hypoallergenic, one conditioner — with the correct dilution for each.

---

## Module 4 — Clipping and Scissoring Fundamentals

Clippers and scissors are where craft becomes visible. A good clip is even, clean, and suited to the dog. A bad clip is choppy, uneven, and — worst of all — unsafe. Speed comes later. Safety and evenness come first.

### Know your clippers

A professional clipper has a detachable blade system. The blade number tells you how much hair it leaves. The higher the number, the shorter the cut: a #10 blade leaves about 1.5 mm, a #7F leaves about 3.2 mm, a #5F leaves about 6.3 mm, a #4F leaves about 9.5 mm, and a #3¾F leaves about 13 mm. "F" means finishing — the teeth are closer together and the cut is smoother. Skip-tooth blades cut faster through thick or matted coats but leave track marks and are more likely to nick skin, so beginners should avoid them until their technique is solid.

Clipper combs (snap-on guide combs) fit over a #30 or #40 blade and leave longer lengths — from 3 mm up to 25 mm. They are the workhorse for pet trims on Doodles and Poodles because they leave a soft, even finish. They only work on a coat that is clean, fully dry, and completely combed out. A comb attachment dragged through a matted coat will jam, pull, and leave an uneven mess. If the comb will not glide, stop and brush the coat out first.

Keep blades cool, clean, and oiled. A hot blade burns skin. Check blade temperature on the inside of your wrist every few minutes, and keep a second blade ready so you can swap when one heats up. Use blade coolant spray sparingly and never spray it on a dog. Clean hair from the blade with a brush after every dog, oil the blade daily, and sharpen or replace blades when they start to drag or pull. A dull blade is a dangerous blade: it pulls hair, heats up fast, and causes clipper burn.

### Clipping technique

Clip with the grain of the hair — in the direction the hair grows — for a smooth, even finish. Clipping against the grain cuts shorter and leaves a closer finish, but it is more likely to irritate the skin and show lines, so use it only where the style calls for it and the skin tolerates it. Hold the clipper flat against the skin with light, even pressure. Do not press hard; pressure causes lines and nicks. Keep the blade flat — tilting it digs the corner teeth into the skin, especially in loose skin areas such as the armpits, groin, and belly.

Work in smooth, overlapping strokes. Overlap each pass by about half a blade width so you do not leave ridges. Keep the skin taut with your free hand wherever the skin is loose — under the legs, around the neck, and on the belly. Loose skin folds under a blade and cuts. This is the single most common cause of clipper nicks, and it is entirely a technique problem, not a blade problem.

Clip the sanitary areas — around the genitals and under the tail — with a #10 blade, carefully and with the skin held taut. Clip the paw pads with a #10 or #15 blade, spreading the toes gently. These are the areas where beginners rush and dogs get hurt. Slow down here.

### Scissoring technique

Scissors finish what clippers start. Blending shears (thinners) remove bulk and blend lines without leaving a hard edge. Straight shears cut clean lines on legs, faces, and tails. Curved shears shape rounded areas — the topknot, the tail, the feet.

Hold scissors correctly: thumb in one handle, ring finger in the other, index and middle fingers resting along the shank for stability. Cut with the tips of the blades for detail work and the full blade for long, straight cuts. Comb the hair up and cut the ends that stick past the comb — this is the "comb and cut" method, and it produces the even finish clients notice. Never cut with the points aimed at the dog's skin. Never cut while the dog is moving. If the dog shifts, close the scissors, remove them from the coat, and wait.

Keep your scissors sharp and clean. Dull scissors fold hair instead of cutting it, which leaves split ends and a frizzy finish. Never use your grooming scissors to cut paper, bandages, or anything else. Store them in a case, blade closed, and have them professionally sharpened — not ground on a home sharpener, which ruins the edge.

### Common mistakes and how to fix them

Choppy lines come from cutting too much at once or from a coat that is not fully dry. Fix it by combing the area up and taking small, even cuts. Clipper lines come from uneven pressure or a blade that is not flat. Fix them by going back over the area with a longer blade or a blending shear. A coat that looks good wet and terrible dry was not dried properly — dry it again, fully, and re-check. A dog that looks uneven from one side was clipped from one side only; walk around the table and check your work from every angle, and use a mirror for the far side.

### Action steps

1. Clip a practice coat (or a willing volunteer dog) with a #7F blade and a #4F blade, and write down the visible difference in finish.
2. Practice comb-and-cut scissoring on a leg until the silhouette is even from front, side, and back.
3. Start a blade log: date, dog, blade used, and any heat or drag problems — this tells you when to sharpen or replace.

---

## Module 5 — Breed-Specific Cuts I: Poodles, Doodles, Shih Tzus, and Bichons

Breed cuts are where a groomer earns a reputation. Owners of Poodles, Doodles, Shih Tzus, and Bichons are the most frequent salon clients, and they can tell the difference between a groomer who knows their breed and one who does not. The full cut specifications for these breeds — and four more — are in the breed-cut reference library in your templates folder. This module teaches the principles and the four most common cuts in depth.

### The Poodle

The Poodle coat is dense, curly, and continuously growing. It is the most versatile coat in grooming: it can be clipped short, scissored into a teddy bear trim, or shaped into the traditional continental or English saddle clips seen in the show ring. Most pet clients want one of three things: a teddy bear trim (even length all over, usually 13–25 mm with a rounded face), a puppy clip (a short, even, easy-care cut), or a lamb clip (body clipped short, legs left longer and scissored round).

Whatever the style, the rules are the same. The coat must be fully dry and combed out before clipping, or the finish will be uneven. The face and feet are clipped close with a #10 or #15 blade — the clean face and clean feet are the signature of a Poodle groom, and they are also where beginners nick skin, because the skin on the muzzle and between the toes is thin and loose. Hold the skin taut, use a sharp blade, and work slowly. The topknot is scissored round, blending into the ears. The tail is shaped into a pom or left natural according to the owner's preference — ask, do not assume.

A standard Poodle in full coat takes two to three hours from bath to finish. Price it accordingly. Module 12 works through the full pricing build-up for a standard Poodle groom, and the numbers will surprise you if you have been undercharging.

### Doodle mixes

Doodles — Labradoodles, Goldendoodles, Bernedoodles — are now among the most common dogs in any salon, and they are also the most misunderstood. There is no single "Doodle coat." A Doodle can have a wavy fleece coat, a curly Poodle-like coat, or a straighter coat that sheds. Assess each dog individually, never by its label. Most Doodle owners want a teddy bear trim: a soft, even length (usually 13–25 mm), a rounded face, and a natural look.

The challenge with Doodles is matting. The coat is dense, the dogs are often large, and many owners do not brush between grooms. Check the friction points first — behind the ears, under the collar, in the armpits, and behind the elbows. If the coat is matted to the skin, the humane option is a short clip, and the owner needs to hear that before you start, with the price agreed. Do not promise a fluffy teddy bear trim on a pelted coat; you cannot deliver it, and trying will hurt the dog.

Doodles are also large, strong, and often young and bouncy. Build your table and handling skills around them. A 30-kilogram Goldendoodle that will not stand still is a different job from a 5-kilogram Shih Tzu, and your pricing should reflect the time, the physical effort, and the product used.

### The Shih Tzu

The Shih Tzu has a long, dense double coat that grows continuously. Pet clients usually want one of two cuts: a puppy cut (short and even all over, typically 6–13 mm, with a rounded face) or a longer teddy bear trim with the coat left at 25 mm or more. The face is the signature: a rounded, full muzzle with the hair over the nose kept short enough that it does not poke the eyes, and the ears left long and blended into the head.

Shih Tzus are prone to eye irritation from hair in the eyes, so keep the hair between the eyes short and clean, and check the eyes at intake for redness or discharge — if you see it, note it and refer to the veterinarian. The breed is also prone to matting under the ears and in the armpits. Line-brush these areas carefully, and if the ears are matted at the base, clip the mat out rather than pulling at the ear leather, which is thin and tears easily.

Shih Tzus are generally cooperative on the table, which makes them a good breed for building scissoring confidence. Take your time on the round face — it is the part the owner sees first.

### The Bichon Frise

The Bichon is a show breed with a distinctive pet cut: a rounded, sculpted head, a body clipped to a soft, even length, and legs scissored into full, round columns. The classic Bichon head is the hardest shape in pet grooming to get right: it should look like a soft, round cloud, with the ears blending into the shape and the muzzle short and neat. Practice it. Study photos of well-groomed Bichons, and compare your work honestly.

The Bichon coat is a double coat — a soft, dense undercoat with a coarser outer coat — and it mats quickly, especially when damp. Dry it fully and fluff it thoroughly; a Bichon that is not fully dry looks flat and stringy instead of soft and full. Use a whitening shampoo sparingly to keep the white coat bright, and rinse thoroughly. Tear staining is common in the breed; clean the area gently, and if the staining is heavy, red, or accompanied by odor or discharge, refer to the veterinarian — it can signal an eye problem, not a grooming problem.

### Action steps

1. Study the breed-cut reference library and pick one breed to master first. Groom three dogs of that breed before you move on.
2. Photograph your work from the front, side, and back every time, and compare each groom with the last.
3. Ask every Poodle and Doodle owner at intake: "When did you last brush the coat to the skin?" Record the answer — it predicts matting better than anything else.

---

## Module 6 — Breed-Specific Cuts II: Schnauzers, Cockers, Goldens, Terriers, and More

### The Miniature Schnauzer

The Schnauzer cut is one of the most recognizable in grooming: a short body, a skirt left longer on the belly and legs, a rectangular beard, and bushy eyebrows. The body is clipped with a #7F or #5F blade, with the clip line running from the base of the skull along the back and down the sides to just below the ribcage. The skirt is left at 13–25 mm and scissored into a neat, straight line. The head is the craft: the top of the head is clipped short, the eyebrows are left long and combed forward, and the beard is left full and shaped into a rectangle. The ears are clipped close inside and out.

The wire coat matters here. Clipping softens the coat over time; hand-stripping preserves it. Explain this to owners who care about coat texture, and charge more for stripping — it takes significantly longer. Most pet Schnauzers are clipped, and that is fine, but the owner should know the trade-off.

### The Cocker Spaniel

The Cocker has a medium-length silky coat with feathering on the ears, chest, belly, and legs. The classic pet cut clips the back short (a #7F or #5F blade) and leaves the skirt and feathering longer, scissored to a neat shape. The ears are left long and full — they are the breed's signature — but they must be kept clean and dry underneath, because Cockers are prone to ear infections. Check the ears at every visit. Redness, odor, or dark discharge means a veterinary referral, not ear cleaning with a home remedy.

Cocker coats mat easily in the feathering, especially behind the ears and in the armpits. Comb these areas at every groom. The feet need attention too: trim the hair between the pads so the dog does not slip, and keep the nails short.

### The Golden Retriever

The Golden is a double-coated breed, and the rule from Module 1 applies: never shave it. The Golden groom is a bath, a thorough undercoat removal, a tidy-up of the feathering, and a neat trim of the feet, ears, and tail. Thin the feathering on the chest, belly, and back of the legs with blending shears so it looks natural, not cut. Trim the feet into neat, round "cat feet." Trim the ears to a tidy shape. That is the whole groom, and it is a skilled one: the difference between a good Golden groom and a bad one is restraint. The owner should not be able to tell where you cut.

Goldens shed heavily, especially in spring and autumn. A de-shedding treatment — bath, high-velocity dry, and thorough brushing — is a service worth selling on its own. Price it as a package, not as an afterthought.

### Terriers: West Highland White, Cairn, and Scottish

Terriers are clipped or hand-stripped depending on the owner's preference and the dog's coat. The West Highland White Terrier (Westie) pet cut clips the body short, leaves the skirt and legs fuller, and shapes the head into a round "chrysanthemum" shape with the ears tipped. The Cairn Terrier is usually left looking natural and shaggy, with hand-stripping to tidy the outline. The Scottish Terrier has a distinctive profile: a short body clip, a skirt, and a beard, with the head shaped to show the long, rectangular muzzle.

Terrier coats are wiry and the skin underneath can be sensitive. Watch for clipper irritation on the belly and groin, and use a sharp blade with light pressure. Terriers are also famously opinionated on the table. Handle them with calm confidence and do not rush the face — that is where most terrier bites happen.

### Short-coated and smooth-coated breeds

Do not neglect the smooth-coated dogs. A Beagle, a Boxer, a French Bulldog, or a Labrador still needs a professional groom: a bath, a de-shedding treatment, nail care, ear cleaning, and a check of the skin and paws. These are quick, high-volume services, and they are an excellent way to fill quiet slots in the diary. They also bring owners into the salon who later book a full groom for a second dog. Price them fairly, do them well, and treat them as real grooms, not as filler.

### Action steps

1. Add the four breeds in this module to your breed-cut reference library notes, with one sentence each on the signature feature of the cut.
2. Practice the Schnauzer head — the beard and eyebrows — on a model or a volunteer dog; photograph it and compare it with the reference.
3. Write a short script for explaining to a Golden Retriever owner why you will not shave their dog, and practice saying it out loud.

---

## Module 7 — Matting and Dematting

Matting is the most common difficult problem in a pet grooming salon, and it is the one where the groomer's judgment matters most. A mat is tangled hair that has felted together. Left alone, mats tighten, pull on the skin, trap moisture, and cause sores, hot spots, and infections underneath. Dematting is not a cosmetic service. It is a welfare decision.

### Why coats mat

Mats form where hair rubs: behind the ears, under a collar or harness, in the armpits, behind the elbows, between the back legs, and under the tail. They form faster when a coat gets wet and is not dried and brushed — after a bath at home, after swimming, after rain. They form faster in curly and long coats, in dogs that are not brushed between grooms, and in dogs whose owners brush only the top layer. A slicker brush gliding over the surface while mats form underneath is the most common cause of severe matting in pet dogs.

### Assessing a mat

Before you decide what to do, assess. Part the coat and look at the skin under the mat. Feel how close the mat sits to the skin. Ask yourself three questions: How big is it? How tight is it? How close is it to the skin? A small, loose mat in the outer coat can be worked out. A large, tight mat sitting on the skin cannot be brushed out without hurting the dog. A coat that is pelted — matted solidly across a whole area, tight to the skin — cannot be brushed out at all.

Be honest with the owner at this point, before the dog is on the table. Show them the mat. Explain what you can do and what you cannot do, and agree the approach and the price. Never promise a long, fluffy finish on a pelted coat. Never start dematting and then discover halfway through that the coat must be clipped short — that conversation should happen before you begin, not after the dog has endured an hour of pulling.

### Dematting technique

Work on a dry coat, before the bath. Water tightens mats, so never bathe a matted dog first. Use a dematting spray or a light leave-in conditioner on the mat to add slip. Hold the base of the mat firmly with your fingers so that pulling does not tug on the skin — this is the single most important technique in dematting. The dog feels the pull on the skin, not on the hair, so your fingers between the mat and the skin are what make it tolerable.

Start at the outer edge of the mat, not the middle. Use a dematting tool, a mat splitter, or the tips of your fingers to pick the mat apart in small pieces, working inward. Use a slicker brush with short, gentle strokes on the loosened hair. Work in short sessions — ten to fifteen minutes on one area, then a break. If the dog is showing stress — flinching, snapping, panting hard, trying to leave the table — stop. Dematting should be uncomfortable at most, never painful. If it is painful, the mat is too tight to brush out, and the humane option is to clip it off.

### When to clip instead

Clip a mat off when it is tight to the skin, when it covers a large area, when the dog is in pain, when the skin underneath is red, sore, or broken, or when dematting would take so long that the dog's welfare is compromised. Use a #10 blade and slide it flat under the mat, between the mat and the skin, with the skin held taut. Work slowly. Check the skin as you go. The skin under a mat is often irritated, and sometimes there is a sore or a hot spot hiding underneath. If you find broken skin, a wound, or anything that looks infected, stop, tell the owner, and refer to the veterinarian. Do not apply creams, powders, or home remedies to broken skin.

After clipping a mat out, show the owner what was underneath and explain how to prevent it: brushing to the skin, line brushing, and a shorter cut or more frequent grooms if the owner cannot keep up with brushing at home. Prevention is a conversation, not a lecture. Owners who feel judged do not come back.

### Charging for dematting

Dematting takes time, skill, and patience, and it must be charged for. Set a dematting fee — either an hourly rate or a per-area fee — and put it in writing before you start. A common approach is a per-15-minute dematting charge on top of the groom price, agreed at intake. If the coat must be clipped short, charge the full groom price plus a mat-removal fee, because clipping a pelted coat takes longer and dulls blades faster than a normal groom. Do not absorb the cost of an owner's neglect. Charging fairly for dematting is also what allows you to spend the time the dog needs instead of rushing and hurting it.

### Action steps

1. Practice the hold-the-base technique on a matted area of a volunteer dog, and time how long a small mat takes to work out safely.
2. Write your dematting fee and your "when we clip instead" explanation, and keep both at the front desk.
3. Photograph a mat before and after removal (with the owner's permission) so you can show future clients what matting looks like under the surface.

---

## Module 8 — Nails, Ears, and Teeth

These three services are small, quick, and easy to get wrong. They are also the services that bring clients back between full grooms, and the ones where a mistake — a cut quick, a damaged ear, a choking hazard — is most likely. Treat them with the same care as a full groom.

### Nails

A dog's nails grow continuously. Long nails change how the dog walks, put pressure on the joints, and can snag and tear. Most pet dogs need their nails trimmed every three to four weeks. Nails have a blood supply — the quick — running through the center. In white nails you can see the pink quick; in black nails you cannot, so trim in small amounts and watch the cut surface. When you see a dark dot in the center of the cut surface, you are near the quick. Stop.

Use sharp nail clippers or a rotary nail grinder (a Dremel-style tool). Clippers are fast; a grinder gives a smoother finish and lets you take off small amounts safely. Whichever you use, hold the paw firmly but gently, support the toe, and cut at a slight angle following the natural curve of the nail. If you cut the quick, stay calm. Apply styptic powder or a styptic pencil with firm pressure for thirty seconds. The bleeding will stop. Tell the owner what happened and that the dog is fine. It happens to every groomer; hiding it destroys trust.

For dogs that hate nail trims, desensitize gradually: touch the paws, then hold the clippers near the paws, then trim one nail and reward. Never wrestle a dog into a nail trim. If a dog is genuinely distressed, trim two nails today and two next visit, or use a grinder, which many dogs tolerate better. Dewclaws — the small nails on the inner leg — are easy to forget and grow into a painful curl. Check them on every dog.

### Ears

Healthy ears are clean, dry, and free of odor. Check both ears at intake. Clean only the outer ear and the ear flap with a cotton ball or gauze dampened with a veterinarian-approved ear cleaner. Never push anything into the ear canal. Never use cotton swabs inside the ear. Never use alcohol, hydrogen peroxide, or home remedies in a dog's ears.

If you see redness, swelling, dark discharge, a strong odor, or the dog flinches when you touch the ear, do not clean it and do not treat it. Note it on the intake form, tell the owner, and refer to the veterinarian. Ear infections are common in Cocker Spaniels, Basset Hounds, and other floppy-eared breeds, and they are painful. A groomer who cleans an infected ear can push infection deeper and cause real harm. Plucking ear hair is a debated practice: some breeds traditionally have the hair plucked from the ear canal, and some veterinarians advise against it because it can irritate the ear. If you pluck, do it gently, only when the hair is clearly blocking airflow, and stop if the ear is red or sore. When in doubt, leave the hair and note it for the veterinarian.

### Teeth

Groomers are not dentists, and this course does not teach dental treatment. What you can do is offer a gentle tooth-brushing service with a dog toothbrush and dog toothpaste — never human toothpaste, which contains ingredients that are unsafe for dogs to swallow. Brush the outer surfaces of the teeth in small circles. Keep the session short and calm. If the dog will not tolerate it, stop.

What you must do is notice. Lift the lip and look: heavy tartar, red or bleeding gums, broken teeth, loose teeth, swelling, or a bad smell are all reasons to tell the owner and refer to the veterinarian. Dental disease is one of the most common health problems in dogs, and it is painful even when the dog is still eating. You are not diagnosing anything — you are noticing something and passing it to the right professional. That distinction matters, and it is what keeps you on the safe side of the line.

### Action steps

1. Practice nail trimming on five dogs of different sizes, and write down how many nails you trimmed before the dog showed stress — that is your pacing guide.
2. Set up your ear station: ear cleaner, cotton balls, gauze, and a card listing the signs that mean "refer, do not clean."
3. Add a teeth check to your intake routine and practice lifting the lip on a calm dog.

---

## Module 9 — Senior, Puppy, and Anxious-Dog Protocols

Not every dog is a healthy adult that stands happily on a table for two hours. Puppies, seniors, and anxious dogs each need a different pace, a different plan, and sometimes a different groom. This module is about adapting without lowering your standards.

### Puppies: the first groom

A puppy's first groom sets the tone for its whole grooming life. The goal of the first visit is not a perfect haircut. The goal is a puppy that leaves happy and wants to come back. Keep the first groom short — thirty to forty-five minutes at most. Introduce the table, the dryer noise, the brush, the clippers (turned on, held nearby, not cutting), and the bath in small steps, with praise and treats throughout. Do a light tidy: face, feet, sanitary area, and a gentle bath. Do not attempt a full breed cut on a first visit. Book the second visit sooner — two to three weeks — so the puppy builds familiarity quickly.

Tell the owner what you did and what the puppy handled well, and give them homework: handle the puppy's paws daily, touch its ears, run a brush through its coat, and let it hear a hair dryer at home. A puppy that is handled at home is a puppy that stands still on your table.

Start puppies at around twelve to sixteen weeks, once they have had their first vaccinations — confirm vaccination status at intake and follow your local requirements. Never groom an unvaccinated puppy in a salon full of other dogs.

### Senior dogs

Senior dogs need more time, more patience, and more care. Their joints hurt. Standing on a table for two hours is hard. Their skin is thinner and tears more easily. They may have lumps, heart conditions, arthritis, or poor eyesight and hearing. Ask the owner about all of it at intake, and write it down.

Adapt the groom: use a non-slip mat, keep the table low, take frequent breaks, let the dog lie down for parts of the groom if it needs to, and groom on the floor for dogs that cannot stand safely. Use a gentler dryer setting and keep sessions shorter — split a full groom across two shorter visits if needed. Be extra careful with clippers on thin, loose skin. Check lumps before you clip over them; clip around them, never over them, and tell the owner about any new lump you find.

Watch for signs of distress that are different from a young dog's: heavy panting, trembling, confusion, or sudden lethargy. Stop the groom and let the dog rest. If a senior dog is struggling, call the owner. A half-finished groom on a comfortable dog is better than a finished groom on a dog that has been pushed too far.

### Anxious and fearful dogs

Anxious dogs need the same thing puppies need: a slow, predictable, low-pressure experience. Keep the room calm and quiet. Move slowly. Talk in a low, even voice. Let the dog sniff the table and the tools before you start. Work in short blocks with breaks. Use a happy hoodie or cotton in the ears to reduce dryer noise. Use treats generously — ask the owner to bring the dog's favorites and confirm there are no allergies.

Desensitization works over visits, not in one session. A dog that panics at the dryer today may tolerate it in three visits if each visit ends on a good note. Never flood a fearful dog — do not force it through a full groom while it is terrified, hoping it will "get used to it." It will not. It will get worse, and it may bite. If a dog's anxiety is severe, suggest the owner speak to their veterinarian about anxiety support or to a behavior professional. That is not a failure of grooming; it is good care.

### Dogs with health conditions

Some conditions change the groom. Dogs with epilepsy can be triggered by stress or by flashing light — keep the environment calm and ask the owner what their triggers are. Dogs with heart conditions should not be stressed or overheated. Dogs with skin conditions need the veterinarian's instructions followed exactly. Diabetic dogs may need to eat on schedule — ask the owner. Dogs that have recently had surgery need the veterinarian's clearance before grooming, and you must not get the incision wet or clip near it.

Keep a health note on every client file. Update it at every visit. A groomer who remembers a dog's condition is a groomer the owner trusts.

### Action steps

1. Write a first-puppy-groom script: what you do, in what order, and what you tell the owner afterward.
2. Design a senior-dog intake add-on: five questions you ask for every dog over ten years old.
3. List three calming adjustments you can make to your salon today — noise, lighting, and pace — and make them.

---

## Module 10 — Salon Safety and Sanitation

A grooming salon is a workplace with water, electricity, sharp tools, chemicals, and animals that can bite. Safety and sanitation are not paperwork. They are what keep dogs, staff, and clients safe, and they are what keep you in business when something goes wrong.

### The safe salon

Keep floors dry and non-slip. Wet floors are the most common cause of falls in a salon — for dogs and for people. Mop up spills immediately. Keep electrical equipment away from water: dryers, clippers, and outlets should never be within splash range of a bath. Use ground-fault protection on outlets near water. Keep cords off the floor and out of reach of dogs.

Store sharp tools safely: scissors closed in a case, blades in blade holders, clippers on a stable surface. Store chemicals — shampoos, disinfectants, flea treatments — out of reach, labeled, and with their safety data sheets on file. Never mix cleaning chemicals. Never use a product on a dog that is not labeled for use on dogs.

Keep a first-aid kit in the salon and know how to use it: styptic powder, gauze, bandages, saline wound wash, tweezers, and a muzzle. Keep the number of the nearest emergency veterinary clinic posted on the wall. Keep a fire extinguisher accessible and know where it is. If you have staff, run a short safety briefing when they start and repeat it every six months.

### Sanitation between dogs

Clean and disinfect the table, the tub, and the tools between every dog. This is not optional. Dogs carry bacteria, fungi, and parasites, and a dirty table spreads them from one client to the next. Wipe the table with a veterinary-grade disinfectant and let it sit for the contact time on the label — spraying and immediately wiping does not disinfect. Wash and disinfect clipper blades between dogs, and clean brushes and combs daily. Wash towels after every use; never reuse a towel between dogs. Launder bedding and smocks regularly.

Clean the salon itself daily: sweep and mop floors, empty bins, wipe surfaces, clean the tub and drains. Once a week, deep-clean: move equipment, clean behind it, disinfect drains, and check for mould or damp. A salon that smells clean is a salon that clients trust. A salon that smells of wet dog and chemicals is a salon that loses bookings.

### Parasites and contagious conditions

If you find fleas, ticks, or lice on a dog, tell the owner immediately. Do not treat the dog with a flea product unless the owner has agreed and the product is appropriate — flea treatments are veterinary products, and the wrong one can harm a dog. Isolate the dog from other dogs in the salon, clean the area thoroughly afterward, and note it on the file. If a dog has ringworm, a skin infection, or kennel cough, do not groom it in a shared space with other dogs. Reschedule, or groom it at a time when no other dogs are present, and disinfect thoroughly afterward. Your responsibility is to the dog in front of you and to every dog that comes after it.

### Records and liability

Keep records. Every groom should have a date, the dog's name, the owner, the services performed, the products used, anything you noticed about the dog's health or coat, and anything you told the owner. Keep intake forms signed by the owner. Keep incident reports for bites, nicks, or any accident. Keep vaccination records on file where your local rules require them.

Carry professional liability insurance and, if you have staff, the employer's insurance your jurisdiction requires. Insurance is not a cost to avoid; it is what stands between one accident and the end of your business. Review your policy every year and make sure it covers grooming, mobile grooming if you offer it, and the number of staff you actually have.

### Action steps

1. Write your between-dog cleaning checklist and post it at your workstation.
2. Check your salon today for the five most common hazards: wet floor, cords near water, unsecured blades, unlabeled chemicals, and a missing first-aid kit. Fix what you find.
3. Start a cleaning log: date, what was cleaned, and who did it. Keep it for a month and review it.

---

## Module 11 — Equipment Selection and Maintenance

Good equipment is an investment, not an expense. A professional clipper, a high-velocity dryer, and a set of sharp shears will earn their cost many times over. Cheap equipment costs more in the long run — in time, in repairs, in poor finishes, and in injuries.

### The essential kit

Start with these and add to them as your income grows: a professional clipper with a detachable blade system; a set of blades (#10, #7F, #5F, #4F, #3¾F, and a #30 for use with guide combs); a set of snap-on guide combs; a high-velocity dryer; a stand dryer or a hands-free dryer arm; a set of shears — straight, curved, and blending (thinning) shears; a slicker brush, a pin brush, a bristle brush, and a fine-toothed comb; a dematting tool and a mat splitter; nail clippers and a rotary grinder; a grooming table with a hydraulic or electric lift and a grooming arm with a loop; a non-slip mat; a bath tub with a sprayer and a non-slip base; a happy hoodie; a basket muzzle in two sizes; and a good-quality set of towels.

Choose a table that lifts. Your back is your business asset, and a table that forces you to bend over a large dog for two hours will end your career early. Choose a dryer with adjustable speed and heat. Choose shears that fit your hand — try them before you buy them if you can. Choose clippers with a motor strong enough for thick coats; a weak clipper stalls in a Doodle coat and overheats.

### Maintenance

Maintenance is a daily habit, not a repair. Clean blades after every dog: brush the hair out, wipe them, and oil them. Oil clippers daily. Clean and oil shears daily and wipe them after every use. Check dryer filters weekly and clean them — a clogged filter overheats the motor. Check cords and plugs monthly for damage. Sharpen blades and shears when they start to drag; send them to a professional sharpener, and keep a spare set so you are never without tools while they are away.

Keep a maintenance log: date, tool, what you did. It takes thirty seconds and it tells you when a blade is due for replacement, when a dryer filter needs cleaning, and when a pair of shears has reached the end of its life. Budget for replacement: blades last months with care, shears last years with care, dryers last years if the filters are cleaned.

### What not to buy yet

Do not buy everything at once. Do not buy a second dryer, a second table, or a full set of specialty shears before you have paying clients. Do not buy a grooming van before you have a waiting list. Buy the essentials, earn with them, and let the business pay for the upgrades. The equipment list in your salon setup checklist (workbook) is ordered by priority so you can buy in the right order.

### Action steps

1. Price your essential kit from three suppliers and write down the total. That number is your start-up equipment budget.
2. Set up a maintenance log and use it for two weeks until it is a habit.
3. Test your blades: clip a clean, dry coat and note any dragging, heat, or uneven cutting. Replace or sharpen anything that fails.

---

## Module 12 — Pricing Your Services

Pricing is where most new groomers fail. They charge what the salon down the road charges, or what feels polite, or what they think a neighbor will pay — and then they discover they are working sixty hours a week and losing money. Pricing is not a guess. It is arithmetic, and this module teaches you the arithmetic.

### The cost of a groom

Every groom has costs. List them: your time, shampoo and conditioner, water and electricity, wear on blades and shears, towels and laundry, disinfectant, rent, insurance, booking and payment processing, and tax. Most new groomers count only the shampoo. Count everything. If you do not know a cost, estimate it honestly and write the estimate down — an honest estimate beats an ignored cost every time.

Work out your hourly cost of running the salon. Add up your fixed monthly costs — rent, insurance, subscriptions, loan payments — and divide by the number of grooming hours you realistically work in a month. Then add your variable cost per groom — products, laundry, wear, payment fees. The result is the minimum you must earn per hour to break even. Your price must be higher than that, or you are paying clients to groom their dogs.

### The pricing build-up: a standard Poodle groom

Here is a worked example, using realistic figures for a small salon. Adjust every number to your own costs and your own area — the method is what matters, not the exact figures.

A standard Poodle full groom takes 2.5 hours from intake to finish.

- Your time: 2.5 hours at a target rate of $40 per hour = $100.00
- Shampoo and conditioner: $4.50
- Water, electricity, dryer wear: $3.00
- Blade and shear wear, clipper oil, coolant: $2.50
- Towels, laundry, disinfectant: $3.00
- Booking and card processing fees (about 3% of the price): $4.20
- Share of fixed costs (rent, insurance, subscriptions) allocated to this groom: $12.00
- **Total cost: $129.20**

If you charge $140, your profit is $10.80 — about 8% — and one cancelled appointment, one broken blade, or one slow day wipes it out. If you charge $160, your profit is $30.80 — about 19% — and the business can survive a bad week. If you charge $180, your profit is $50.80 — about 28% — and you can afford to invest in better equipment, better training, and a day off.

Notice what the numbers say: the difference between a struggling salon and a healthy one is not working harder. It is charging $20 more per groom. Clients who value a good groom will pay it. Clients who will not pay it were never going to make your business work.

### Pricing by dog, not by the hour

Clients understand prices by dog, not by time. Set your price list by breed and size, with the time and cost behind it. A small Shih Tzu puppy cut takes an hour; a standard Poodle takes two and a half; a matted Bernedoodle takes three and a half. Price each one from its own build-up, not from a single flat rate. Add clear surcharges: matted coat, aggressive or very anxious dog, extra-large breed, de-shedding treatment, flea bath, and nail grinding. Put the surcharges in writing and agree them at intake. A surcharge agreed before the groom is a fair price. A surcharge added after the groom is an argument.

### Raising prices

Raise your prices every year, by at least the rate your costs rise. Tell existing clients in advance, in writing, with a reason: "From March 1, our prices rise by $5 per groom to cover increased product and insurance costs." Give them a month's notice. Most clients will stay. The ones who leave over $5 were the ones who complained the most and tipped the least. Do not apologize for charging what your work is worth. Do not discount to fill the diary — a discount trains clients to wait for the next discount. Instead, fill quiet slots with services that cost you little time: nail trims, de-shedding treatments, and bath-only appointments.

### The monthly revenue model: a one-groomer salon

Here is a worked model for a single groomer working five days a week.

- Working days per month: 21
- Grooms per day: 5 (four full grooms and one bath-only or nail appointment)
- Average price per groom: $85
- **Gross monthly revenue: 21 × 5 × $85 = $8,925**
- Product and consumable costs (about 10%): $893
- Card and booking fees (about 3%): $268
- Rent: $1,200
- Insurance: $120
- Utilities: $250
- Marketing and subscriptions: $150
- **Total monthly costs: $2,881**
- **Monthly profit before tax: $6,044**

That is a healthy model — and it depends on two things: five grooms a day, every working day, and an average price of $85. If your average price is $55, the same month produces $5,775 in revenue and $2,894 in profit — less than half. If you do three grooms a day instead of five, revenue falls to $5,355 and profit falls to $2,474. The model shows the levers clearly: price, volume, and consistency. You cannot fix a low price by working longer hours. You fix it by pricing correctly and keeping the diary full.

### Action steps

1. Build your own pricing build-up for three grooms — a small dog, a medium dog, and a large dog — using the template in the workbook. Use your real costs.
2. Write your price list with surcharges, and post it where clients can see it.
3. Work out your monthly revenue model with your real rent, your real costs, and your real prices. If the profit does not support you, raise the price before you raise the hours.

---

## Module 13 — Booking and Scheduling

A full diary is the difference between a hobby and a business. Booking and scheduling look like administration, but they are really client care: a client who can book easily, who is reminded, and who is never double-booked is a client who comes back.

### How long does a groom take?

Build your schedule from real times, not hopes. Time yourself for two weeks and record the average for each service: a small-dog full groom, a medium-dog full groom, a large-dog full groom, a bath and tidy, a de-shedding treatment, and a nail trim. Add fifteen minutes between appointments for cleaning, notes, and the next intake. Add a lunch break and a buffer for the appointment that runs long — because one always does. A schedule built on real times is a schedule you can keep. A schedule built on wishes is a schedule that runs late every day, and a salon that runs late every day loses clients.

A realistic starting diary for one groomer is four to five full grooms a day, or three full grooms plus two shorter services. Do not book six full grooms a day to chase revenue. You will run late, cut corners, hurt a dog, or burn out. The revenue model in Module 12 works at five appointments a day. It does not need six.

### Booking systems

Use a booking system, even a simple one. An online booking page, a calendar, and automated reminders will save you hours a week and cut no-shows dramatically. Choose a system that lets clients book, reschedule, and cancel online, that sends a confirmation and a reminder, and that records the dog's notes and history. If you start with a paper diary, move to a digital system as soon as you have twenty regular clients — paper does not send reminders, and it does not tell you who has not booked in three months.

Take a deposit for new clients and for appointments over a certain value. A deposit of 25 to 50 percent, taken at booking, cuts no-shows sharply. State your cancellation policy clearly: 48 hours' notice to cancel or reschedule without losing the deposit, and a no-show fee for a missed appointment. Enforce it kindly and consistently. A policy you do not enforce is not a policy.

### No-shows and late clients

No-shows cost you the groom, the slot, and the client you turned away to hold it. Reduce them with reminders: a confirmation at booking, a reminder 48 hours before, and a reminder the day before. If a client no-shows twice, require a deposit for all future bookings, or decline to rebook. If a client is late, groom what you can in the remaining time or reschedule — do not rush a groom to catch up, and do not make the next client wait. Tell the late client plainly: "We have thirty minutes left in your slot, so today we can do a bath and tidy, and we will book the full groom for next week." That is fair to everyone.

### Rebooking at the appointment

The single most effective scheduling habit is rebooking before the client leaves. When the dog is finished, say: "She is due again in six weeks. Shall we book the same time on Tuesday the 14th?" Most clients will say yes. A client who leaves without a booking is a client you must chase, and many of them drift away. Aim to have at least 60 percent of your diary booked four weeks ahead. When you reach that, you have a business with a future. When your diary is empty two weeks out, you have a problem to fix now, not next month.

### Action steps

1. Time your five most common services over two weeks and write your real averages into the booking template.
2. Write your cancellation and deposit policy in one paragraph, and put it on your booking page and your intake form.
3. Start rebooking every client before they leave. Track your rebooking rate for a month and aim for 60 percent.

---

## Module 14 — Client Communication and Retention

Grooming is a trust business. Owners hand you a member of their family and leave. They come back because they trust you, because the dog comes home happy, and because the experience is easy. Retention is not a marketing trick. It is the sum of a hundred small things done well.

### The intake conversation

The first conversation sets the tone. Ask about the dog, not just the cut. How old is the dog? How does it behave at the groomer? Any sensitivities? Any health issues? What does the owner like about the last groom, and what would they change? Listen and write it down. Owners can tell when a groomer is listening and when they are waiting to talk. Use the intake form in the workbook and keep it on file.

Agree the cut before you start. Show the owner photos of the style you plan, or ask them to show you a photo of what they want. If what they want is not possible — a fluffy teddy bear trim on a pelted coat, a long coat on a dog that is never brushed — say so now, kindly and clearly, and offer the closest achievable alternative. A client who agrees to a short clip before the groom is a satisfied client. A client who discovers it afterward is an angry one.

### The handover

When the owner collects the dog, show them the groom. Point out what you did, what you noticed, and what they should do at home: "Her coat is clear now. Brush her twice a week to the skin, especially behind the ears, and she will stay like this until her next visit in six weeks." Give aftercare instructions in writing — the booking and client-care template includes a form you can use. If you found anything — a lump, a sore, redness in an ear — tell the owner in person, calmly and factually, and put it in writing. "I noticed a small lump on her left side. It may be nothing, but I would have your veterinarian look at it." That sentence earns more trust than any discount.

### Handling complaints

Complaints happen to every groomer. Handle them well and they become loyalty. Listen first, without interrupting and without defending yourself. Repeat back what the client said so they know you heard them. Apologize for the experience, even if you believe the work was correct: "I am sorry you are not happy with the cut." Then fix what can be fixed: offer to adjust the cut, re-do the finish, or book a follow-up. If the complaint is about something you cannot fix — the dog would not tolerate a longer style, the coat was matted — explain it calmly and offer the alternative next time. Never argue with a client in front of other clients. Never blame the dog. If a client is abusive, end the conversation politely and decline future bookings. You do not need every client. You need the right clients.

### Retention

Retention is cheaper than acquisition by a wide margin. A client who books every six weeks for three years is worth thousands of dollars. Keep them with consistency: the same quality every visit, the same groomer where possible, notes on file so the owner does not have to repeat themselves, and a reminder when the next groom is due. Send a reminder a week before the dog is due. Call or message clients who have not booked in ten weeks — not to sell, but to check in: "Biscuit is due for a groom. Would you like the usual slot?" Small gestures matter: a birthday card for the dog, a photo of the groom sent to the owner, a thank-you note after the first visit. None of these cost much. All of them make a client feel known.

Ask for reviews, but do not buy them and do not fabricate them. After a good groom, say: "If you are happy, a review on our page would mean a lot." Most satisfied clients will leave one if asked once. Do not ask twice.

### Action steps

1. Write your intake script: the five questions you ask every new client, and the sentence you use to agree the cut.
2. Set up a reminder system for dogs due in one week and dogs that have not booked in ten weeks.
3. After your next ten grooms, ask each owner for a review. Record how many leave one.

---

## Module 15 — Mobile Grooming

Mobile grooming — taking the salon to the client in a van or trailer — is a different business from a fixed salon. It has higher start-up costs, higher running costs, and higher prices, but it also has no rent, no waiting room, and a client base that values convenience enough to pay for it. Many groomers add mobile grooming after building a fixed-salon client list. Some start mobile and never open a salon. This module covers what changes.

### The vehicle and the set-up

A mobile grooming unit needs water, power, drainage, heating, and a safe working space. Most groomers use a converted van or a trailer with a built-in bath, a grooming table, a water tank, a water heater, a generator or an inverter system, and grey-water storage. The conversion is the largest cost — often tens of thousands of dollars — so research it carefully, get quotes from specialist converters, and check the regulations in your area before you spend anything. Your vehicle must be insured for business use, and your equipment must be secured so it does not move while you drive.

Plan the working space like a salon in miniature: a non-slip floor, a tub with a sprayer, a table with a loop, storage for products and tools, a place for dirty towels, and ventilation. Keep it clean and organized — a cramped, cluttered van is slow and unsafe. Keep a fire extinguisher, a first-aid kit, and the emergency vet number posted, just as in a fixed salon.

### Pricing mobile grooming

Mobile grooming costs more to deliver and it must be priced higher. Your costs include fuel, vehicle maintenance, insurance, water, power, and the time spent driving between clients. A mobile groomer typically sees four to five dogs a day, not five to six, because of travel time. Price accordingly: a mobile full groom is commonly priced 30 to 50 percent above a salon groom in the same area, and clients accept this because they are paying for convenience and for one-to-one attention.

Work out your pricing the same way as Module 12, but add the vehicle costs: fuel per day, maintenance per month, vehicle insurance, and the value of your driving time. If the numbers do not work at the price your area will bear, mobile grooming is not the right model for you yet. Do not subsidize a van with salon prices.

### Scheduling and routing

Routing is everything in mobile grooming. Cluster appointments by area: one neighborhood in the morning, another in the afternoon. Do not criss-cross a city all day. Allow thirty minutes between appointments for driving, cleaning, and set-up. Build your diary a week ahead and confirm every appointment the day before — a no-show on a mobile round costs you the groom and the fuel to get there. Keep a buffer slot each day for the appointment that runs long or the road that is closed.

### Safety on the road and at the client's home

Never groom a dog in a client's home without the owner present or reachable. Keep the van doors secured while you work. Keep the dog on a lead or in the van at all times — a loose dog in an unfamiliar street is a lost dog. Watch the temperature in the van: never leave a dog in a parked van in warm weather, even for a few minutes. In cold weather, keep the van warm enough for the dog and for you. Carry a phone charger, a spare lead, and a basic tool kit for the van. And remember the safety rules from Module 10 apply in the van too: dry floors, cords away from water, sharp tools stored safely.

### Action steps

1. If you are considering mobile grooming, get three conversion quotes and a vehicle insurance quote before you commit to anything.
2. Work out a mobile price list using the Module 12 method, including fuel, maintenance, and driving time.
3. Map your area into four or five zones and plan a sample week of routes, with thirty minutes between appointments.

---

## Module 16 — Hiring and Building a Team

There comes a point where one groomer cannot do more. The diary is full, the waiting list is growing, and you are turning clients away. That is the moment to hire — not before, and not long after. Hiring too early burns money. Hiring too late burns you out.

### When to hire

Hire when your diary is consistently full four weeks ahead, when you are turning away more than five clients a week, and when your monthly profit can cover a new person's wages, their insurance, and their training for three months without the business going backward. Do the arithmetic before you advertise. A bather or grooming assistant is usually the first hire: someone to bathe, dry, brush, and clean, freeing you to do the skilled clipping and scissoring. A second groomer comes later, when the assistant is trained and the demand is still there.

### Who to hire

Hire attitude first and skill second. A person who is calm with dogs, careful with detail, reliable, and willing to learn will become a good groomer. A person who is fast but careless will cost you clients. Look for someone who has handled dogs before — in a shelter, a kennel, a vet clinic, or at home — and who is honest about what they do not know. Check references. Have them spend a trial day in the salon so you can see how they are with dogs, with clients, and with cleaning. Pay for the trial day.

Be clear about the job: the hours, the pay, the duties, and the expectations. Put it in writing. Include the unglamorous parts — cleaning, laundry, answering the phone — because a hire who discovers them later will leave.

### Training your team

Train in the same order this course teaches: safety and handling first, then bathing and drying, then clipping and scissoring, then breed cuts. Do not let a new hire clip a client's dog on their first week. Let them bathe, dry, and brush until those skills are solid, then supervise their first clips closely. Set clear standards: the coat must be fully dry before clipping, the comb must pass through the coat before the dog leaves the table, the intake form must be completed for every dog. Check their work and give feedback the same day, kindly and specifically: "The body is even, but the legs need another pass with the blending shears" is useful. "That is not good enough" is not.

### Managing people

A small team needs the same things a large one does: clear expectations, regular communication, fair pay, and respect. Hold a short weekly meeting — fifteen minutes — to review the diary, discuss difficult dogs, and plan the week. Pay fairly and on time. Give your team the tools they need and keep them maintained. If someone is struggling, find out why before you blame them: they may need training, a different task, or a lighter diary. If someone is consistently careless with dogs, act quickly. One careless groomer can undo years of reputation.

Know the employment rules in your jurisdiction: contracts, minimum wage, working hours, insurance, and tax. Get advice from a professional before you hire, not after a dispute.

### Action steps

1. Work out the true monthly cost of a part-time assistant in your area: wages, insurance, tax, and training time.
2. Write a one-page job description for a grooming assistant, including the cleaning and admin duties.
3. Write your three non-negotiable standards for anyone who grooms a dog in your salon.

---

## Module 17 — Launching Your Grooming Business

Launching is a sequence, not a single event. Do it in order, and do not skip the boring steps. The boring steps are the ones that keep you legal and keep you open.

### The legal and financial foundations

Choose a business structure and register it. In the United States this usually means a sole proprietorship or a limited liability company (LLC); in other countries the equivalents differ, so check your local rules. Open a separate business bank account and keep business money and personal money apart from day one. Get professional liability insurance and, if you have a premises, property insurance. Check whether your area requires a business license, a kennel license, or a grooming license — requirements vary widely by city and state, so check with your local authority rather than assuming. Check zoning: not every residential area allows a grooming salon, and not every landlord allows one in a rented property. Get these answers in writing before you sign a lease or buy equipment.

Set up a simple bookkeeping system: income, expenses, and tax. Record every sale and every expense. Keep receipts. Set aside money for tax from every payment you receive — a separate savings account for tax is the simplest way to avoid a nasty surprise. If bookkeeping is not your strength, hire a bookkeeper for a few hours a month. It costs less than a tax mistake.

### Choosing a location

If you open a fixed salon, location matters more than size. Look for a spot that is easy to find, easy to park at, and visible from the road. A small, clean, well-lit space beats a large, dark one. Check the plumbing: you need good water pressure, good drainage, and a water heater that can keep up with a day of baths. Check the floor: it must be non-slip when wet and easy to clean. Check the ventilation: a grooming salon is humid, and poor ventilation means mould, smells, and unhappy dogs.

If you work from home, check the rules first, and think about the practicalities: clients coming to your door, dogs in your home, noise, and the boundary between your work and your life. Many groomers start from home and move to a salon later. That is a sensible path, not a compromise.

### Your opening offer

Do not open with a discount that trains clients to expect cheap prices. Open with a clear, fair price list and a simple launch offer that brings people in without devaluing your work: for example, a free nail trim with a first full groom, or a free de-shedding treatment for the first month. Announce the opening locally: a sign, a social media page with photos of your work, a listing on local directories, and a short introduction to nearby veterinary clinics and pet shops. Veterinary clinics are a valuable source of referrals — introduce yourself, leave a card, and be the groomer they trust to send a nervous dog to.

### Your first clients

Your first twenty clients matter more than your first two hundred. Treat them exceptionally well. Ask them what they thought of the groom. Fix anything they were not happy with. Ask them to tell a friend. A grooming business grows by word of mouth more than by any other channel, and word of mouth starts with the first dog on the table. Keep a record of where each client came from so you know what is working.

### Action steps

1. Make a launch checklist: registration, insurance, bank account, license checks, bookkeeping, price list, booking system. Tick each one off before you take your first paying client.
2. Write a one-page introduction to your local veterinary clinics and pet shops.
3. Decide your opening offer and your launch date, and put both in writing.

---

## Module 18 — Your First 90 Days and the Certificate Path

This final module turns the course into a plan. You have the knowledge. Now you need the repetitions, the clients, and the habits that make a groomer.

### Your first 90 days

**Days 1–30: Skill.** Groom at least three dogs a week, even if they are volunteer dogs, friends' dogs, or your own. Focus on the foundations: safe handling, a full bath and dry, a clean clip, and a complete intake form for every dog. Photograph every groom. Keep a log: the dog, the breed, the cut, the time, and one thing you would do better next time. Complete the skills self-assessment in the workbook at the start of the month and again at the end — the difference is your progress.

**Days 31–60: Consistency.** Increase to five dogs a week. Start charging for grooms if you have not already, using the pricing build-up from Module 12. Set up your booking system, your price list, and your cancellation policy. Start rebooking clients before they leave. Build your breed-cut practice log: three grooms each of your two most common breeds.

**Days 61–90: Business.** Review your numbers: how many grooms, what average price, what profit, what rebooking rate. Raise any price that is below your build-up. Ask your first ten paying clients for reviews. Set your next 90-day goal: a number of regular clients, a revenue target, or a new service to add. If you have completed the modules, the exercises, and the practical work, you are ready to claim your certificate of completion.

### The certificate of completion

Your certificate is included with this academy. To earn it, complete all 18 modules, finish the workbook exercises, log at least 25 supervised practice grooms in the breed-cut practice log, and complete a pricing build-up for three grooms using your real costs. There is no exam. The proof is the work: the log, the workbook, and the grooms. A certificate that means something is one backed by real practice, not by a multiple-choice test.

Keep learning after the certificate. Grooming changes: new tools, new coat products, new breed styles, new safety guidance. Follow professional groomers, attend a workshop or a trade show when you can, and keep photographing and comparing your work. The groomers who keep improving are the ones who are still in business in five years.

### Your career from here

A professional groomer has options. You can run a salon, work mobile, specialize in a breed, teach, or build a team. You can add services: de-shedding packages, puppy programs, senior-dog care, or cat grooming (which needs separate training — do not groom cats with dog techniques). You can raise your prices as your skill and your reputation grow. The path is the same as the one in this course: learn the craft, price it honestly, look after the dogs, and look after the clients. Do that consistently, and the business follows.

### Action steps

1. Write your 90-day plan with dates, starting today.
2. Set up your practice log and your first three volunteer grooms.
3. Complete the workbook, log 25 grooms, and claim your certificate.

---

## A Final Word

Grooming is a trade that rewards patience, honesty, and care. The dogs will tell you when you are doing it well — they will stand still, relax, and come back happily. The owners will tell you too — they will rebook, they will recommend you, and they will trust you with a member of their family. Earn that trust every day, one groom at a time.

**Safety reminder, repeated because it matters:** this course teaches grooming technique, handling, hygiene, and business practice. It does not teach veterinary care. Any skin condition, lump, wound, ear infection, discharge, swelling, pain, or health concern you notice must be referred to a veterinarian. Never diagnose, never treat, and never present grooming advice as veterinary advice. When in doubt, refer out.
