# The Generational Wealth Blueprint

## A Complete Family System for Earning, Investing, and Passing It On

**SKU:** FIN-01 | **Format:** 18-module written course manual, a 120-page workbook, family wealth dashboard spreadsheets, and legacy letter and family meeting templates.

---

## Important Disclaimer — Please Read First

This material is general education only. It is not individualized financial, legal, tax, or investment advice, and it does not create an advisor–client relationship. The examples, projections, and illustrations in this course use stated assumptions — such as assumed rates of return — to show how the mathematics of compounding and planning work. Actual results will vary, and can be lower or higher than any illustration here. Past performance does not guarantee future results. No outcome is guaranteed, and this course makes no promise of any specific return, income level, or wealth outcome. Laws, tax rules, account limits, and contribution limits change over time and differ by jurisdiction; verify current rules with the relevant authorities and consult a qualified financial planner, tax professional, or estate attorney for advice about your own situation before making decisions. Do not act on any single example in this course without considering your full circumstances.

---

## How to Use This Masterclass

This course is built around one household: the Alvarez family. Maria (38) and James (40) Alvarez earn a combined $120,000 a year, have two children (ages 9 and 12), a mortgage, two car payments, and $18,000 in savings. They are not wealthy. They are the exact family this course is for. Every module returns to their numbers so you can see a complete plan working on a real household income, not on a fantasy salary.

You do not need to finish the course in a weekend. The recommended pace is one module per week for 18 weeks, with the workbook exercise for that module completed the same week. By the end you will have a written family wealth plan, funded accounts, signed estate documents, an insurance program, and a first family meeting behind you.

### The Alvarez Household — Baseline Facts (used throughout)

- Combined gross income: $120,000 per year ($10,000 per month)
- After-tax take-home: approximately $8,600 per month (assumes roughly 17% combined effective tax withholding; actual tax depends on location, deductions, and filing status)
- Mortgage: $285,000 balance, 6.5% interest, $1,950 per month, home value $375,000
- Car loans: $420 per month combined; credit card balance $4,500 at 22% APR
- Student loan: $11,000 balance at 5.5%, $185 per month
- Retirement savings: $42,000 combined in 401(k) accounts
- Emergency savings: $6,000 (less than one month of expenses)
- Monthly essential expenses: approximately $6,900
- Net worth at start: approximately $142,000 (home equity $90,000 + retirement $42,000 + savings $6,000 + cars $14,000, minus debts of $10,000 in non-mortgage debt; rounded)

All projections in this course use these stated assumptions unless a module says otherwise: long-term investment returns of 7% per year before inflation (about 4% after inflation at 3% inflation), wage growth of 3% per year, and home price growth of 3% per year. These are planning assumptions for illustration, not predictions. Actual returns vary year to year and can be negative.

---

## Module 1 — Family Financial Foundations

Most families do not have a money problem in the way they think they do. They have a coordination problem. Two adults earn, spend, save, borrow, and worry — mostly separately, mostly reactively, and mostly without a shared picture of where the household stands. The first module of this course is about fixing that coordination problem before a single dollar is invested, because investing without a foundation is how families end up selling investments at the worst moment to cover an emergency they could have planned for.

A family wealth system has five parts, and they must be built in order: (1) a shared picture of the present, (2) a cash-flow plan that produces a surplus, (3) a buffer against shocks, (4) a debt strategy, and (5) only then, long-term investing and protection. Skip the order and the system wobbles. A family that invests while carrying 22% credit card debt is paying the bank far more than the market is likely to pay them. A family that invests without an emergency fund will raid the investments the first time the furnace breaks.

### The Net-Worth Statement: Your Family's Balance Sheet

A net-worth statement lists everything the family owns (assets) and everything it owes (liabilities). Net worth equals assets minus liabilities. It is the single most honest number in family finance, and most families have never calculated it.

The Alvarez family's starting net worth, worked out in full:

| Item | Amount |
|---|---|
| Home value | $375,000 |
| Retirement accounts (401(k)) | $42,000 |
| Emergency savings | $6,000 |
| Cars (estimated resale value) | $14,000 |
| **Total assets** | **$437,000** |
| Mortgage balance | $285,000 |
| Credit card balance | $4,500 |
| Student loan balance | $11,000 |
| Car loans | $9,500 |
| **Total liabilities** | **$310,000** |
| **Net worth** | **$127,000** |

Note the difference from the rounded $142,000 figure in the introduction: that figure used a simplified asset list. This table is the precise one, and the workbook will have you build your own the same way. Two lessons live in this table. First, the family's net worth is dominated by home equity ($90,000), which is real wealth but illiquid — it cannot pay for groceries or a broken car. Second, their liquid wealth (savings plus retirement) is only $48,000, and $42,000 of that is locked in retirement accounts. A family can be worth $127,000 on paper and still be one emergency from a credit card. That gap between paper wealth and usable wealth is what the next three modules close.

### The Family Money Meeting

Wealth building is a team project, and teams need a meeting rhythm. The Alvarez family institutes a 30-minute money meeting every Sunday evening. The agenda is fixed: (1) what came in and what went out this week, (2) any upcoming irregular expense, (3) one decision, (4) one appreciation — something the other person did well with money. The fourth item is not decoration. Couples who only talk about money when something is wrong come to dread the topic, and dreaded topics get avoided until they become crises. A standing meeting with a fixed, short agenda turns money from a recurring argument into a recurring routine, like laundry.

### Values Before Numbers

Before the numbers, the family writes a one-page values statement: three sentences about what money is for in this household. The Alvarez version reads: "Money in our family buys security first, freedom second, and fun third. We want our children to see us choose the future over the moment — most of the time, not all of the time. We want to leave our children skills and options, not just things." Every later decision in this course — how much to save, what insurance to buy, what to teach the children — is tested against that paragraph. A family without a values statement optimizes for whatever is loudest this month. A family with one can say no to a purchase and yes to a plan, and explain why in one sentence.

### The Wealth-Building Equation

Family wealth grows by one equation: **Wealth = (Income − Spending) × Time × Return, minus shocks.** There are only four levers: earn more, spend less, give it more time, earn a better return — and protect the result from shocks. Most financial media obsesses over the return lever, which is the one the family controls least. This course spends most of its time on the other three, because a family that saves $1,000 a month for 25 years at a 7% assumed return accumulates about $810,000, while a family that saves $500 a month at the same return accumulates about $405,000. Doubling the savings rate doubles the outcome; chasing an extra 1% of return does not. The worked example below uses the standard future-value-of-a-series formula; the workbook dashboard computes it for your own numbers.

**Worked example — the power of the savings rate.** Assume monthly contributions, a 7% annual return compounded monthly, and 25 years. $500/month grows to approximately $405,000. $1,000/month grows to approximately $810,000. $1,500/month grows to approximately $1,215,000. Total contributions in the $1,000/month case are $300,000; the remaining $510,000 is growth. Time and consistency do the heavy lifting — which is why starting now, even with a modest amount, matters more than waiting until you can save a large amount.

### Action Steps — Module 1

1. Calculate your household net worth using the workbook's net-worth statement. Update it on the first of every month.
2. Hold your first 30-minute family money meeting this week. Set the recurring time and write your one-page values statement together.
3. Write down your household's four levers: one way to earn more, one spending category to reduce, your time horizon, and your current return assumption. Circle the lever you will pull first.
4. Open the family wealth dashboard spreadsheet and enter your starting numbers so every later module has a baseline to measure against.

---

## Module 2 — Household Cash-Flow Engineering

Budgeting fails when it is a list of restrictions. Cash-flow engineering succeeds when it is a design problem: how do we arrange the flow of money through this household so that the future gets paid first, the present is comfortable, and the system runs without willpower?

### The 50/30/20 Starting Point — and Why It Needs Adjusting

A common framework divides after-tax income into 50% needs, 30% wants, and 20% savings and extra debt repayment. For the Alvarez family, with $8,600 monthly take-home, that would mean $4,300 for needs, $2,580 for wants, and $1,720 for savings and debt. Their actual spending is $6,900 on essentials alone — 80% of take-home — because housing, transport, food, and childcare in their area are expensive. The framework is a compass, not a verdict. A family at 80% needs is not failing; it is living in a high-cost reality, and the useful question is which need can be restructured, not which want can be shamed away.

The Alvarez cash-flow map, built in the workbook, shows the real picture:

| Category | Monthly amount |
|---|---|
| Housing (mortgage, tax, insurance) | $1,950 |
| Utilities and phones | $380 |
| Food and household | $950 |
| Transport (cars, fuel, insurance) | $890 |
| Childcare and school costs | $700 |
| Health insurance and medical | $520 |
| Clothing and personal | $240 |
| Entertainment and dining | $320 |
| Subscriptions and miscellaneous | $180 |
| Minimum debt payments (cards, student loan) | $340 |
| **Total spending** | **$6,670** |
| Take-home pay | $8,600 |
| **Monthly surplus before savings** | **$1,930** |

The surprise is that the surplus exists — $1,930 a month — but it has been evaporating into unplanned spending because no one assigned it a job. Cash-flow engineering is the act of assigning every dollar a job before the month begins.

### Pay Yourself First, Automatically

The single most effective cash-flow technique is automation: money moves to savings and investments on payday, before it can be spent. The Alvarez family sets up automatic transfers for the day after payday: $400 to the emergency fund, $600 to retirement contributions above the employer match (via payroll), $200 to a children's education fund, and $150 to an opportunity fund. That is $1,350 a month leaving the checking account automatically. What remains is the spending money, and the family can spend it without guilt, because the future has already been paid.

### The Three-Account System

One checking account invites confusion. Three accounts create clarity:

1. **Bills account** — receives a fixed transfer each payday covering all fixed bills; every recurring bill auto-pays from here. If the balance is wrong, something changed, and it is visible immediately.
2. **Spending account** — receives the weekly variable-spending allowance (food, fuel, fun). When it is empty, spending stops until next week. No judgment, just a boundary.
3. **Future account(s)** — savings, investing, and opportunity funds. Money flows in automatically and almost never flows out.

Families that adopt this system report the same result: fewer arguments, because the argument used to be "you spent too much" and is now "the spending account is empty until Friday," which is a fact rather than an accusation.

### Finding $500 Without Misery

The course does not ask families to cut everything enjoyable. It asks for one structural change and two small ones. For the Alvarez family: (1) refinancing nothing yet, but calling their internet and mobile providers and their insurer to renegotiate — saving $85 a month; (2) meal planning four dinners a week from a repeating rotation, cutting food spending by $220 a month; (3) a one-month pause on two subscriptions and a dining-out cap, saving $195 a month. Total: $500 a month, found without touching anything the family loves. Over 25 years at a 7% assumed return, $500 a month grows to about $405,000. That is the price of unexamined spending, stated plainly.

### Irregular Expenses: The Budget Killer

The expenses that break budgets are not the daily ones; they are the irregular ones — car repairs, school fees, holiday spending, annual insurance premiums. The Alvarez family lists every irregular expense they can remember from the last year, totals it ($4,800), divides by 12 ($400 a month), and auto-transfers that amount into a separate "irregular" savings bucket. When the car needs brakes, the money is already there. This single practice eliminates most "emergency" credit card use.

### Action Steps — Module 2

1. Build your cash-flow map in the workbook: every dollar in, every dollar out, for the last 30 days. No estimating — use bank statements.
2. Set up the three-account system and automate at least one transfer to savings for the day after payday.
3. List your irregular expenses for the past year, total them, divide by 12, and fund that monthly amount.
4. Find your $500: one renegotiation, one food-system change, one pause or cap. Write the three changes down and the monthly amount each saves.

---

## Module 3 — Emergency and Opportunity Funds

An emergency fund is not savings. It is insurance you pay to yourself, and it is the difference between a setback and a spiral. A family without one borrows at the worst moment — high-interest debt taken on under stress — and the interest on that debt then eats the savings rate for years. A family with one absorbs the shock and keeps investing.

### How Much Is Enough?

The standard guidance is three to six months of essential expenses. For a two-income household with stable jobs, three months is a reasonable starting target; for a single-income household, a household with variable income, or one with health concerns, six months is safer. The Alvarez family's essential expenses run about $6,670 a month, so three months is roughly $20,000 and six months is roughly $40,000. They currently have $6,000 — less than one month. That gap is the family's first financial priority, ahead of extra investing and ahead of extra debt repayment beyond minimums (except for the 22% credit card, which is itself an emergency — see Module 4).

The build sequence matters: first, $2,000 as a starter buffer within 60 days (this alone stops most small emergencies from reaching a credit card); then one month of expenses; then three months; then, once high-interest debt is gone, six months. Each milestone is celebrated, because a family that has never had a buffer needs to feel progress to keep going.

### Where to Keep It

An emergency fund must be safe, liquid, and slightly inconvenient. A high-yield savings account at a different bank from the family's daily checking account is the standard choice: it earns interest, it can be reached in one to two days, and it is not sitting in the account the debit card draws from. It should not be invested in the stock market — the point of the fund is that it is there in full on the worst day, and markets fall hardest exactly when jobs are lost. It should not be in cash at home beyond a small amount, and it should not be mixed with vacation or house-deposit savings. Separate buckets, separate purposes.

### The Opportunity Fund: The Other Side of the Coin

Once the emergency fund reaches three months, the family starts a second fund with a different job: the opportunity fund. This is money set aside to act when a good opportunity appears — a course that raises earning power, a business idea, a property, a career move that requires a pay cut for a year. The Alvarez family funds it at $150 a month. After five years at a modest assumed return it holds roughly $10,000–$11,000, and the family that has it can say yes to a chance the family without it must decline. Wealth is not only built by avoiding disaster; it is also built by being ready when a door opens.

**Worked example — building the emergency fund.** The Alvarez family directs $400 a month automatically plus their $500-a-month found savings (Module 2) to the emergency fund — $900 a month total. Starting from $6,000, they reach $20,000 (three months of expenses) in about 16 months, assuming a 4% annual yield on the savings account. Once the credit card is cleared (Module 4), the full $900 plus the freed card payment accelerates the build to six months ($40,000) roughly 18 months later. The timeline is honest: a full emergency fund takes about two and a half years on this income, and that is normal.

### What Counts as an Emergency?

Write the definition down before the emergency arrives: job loss, essential home or car repair, urgent medical expense, or essential travel for a family crisis. A sale, a holiday, a new phone, and a wedding invitation are not emergencies. The written definition prevents the fund from becoming a general spending account with a reassuring name.

### Action Steps — Module 3

1. Calculate your three-month and six-month emergency fund targets from your essential expenses.
2. Open a separate high-yield savings account for the emergency fund and set up an automatic transfer for the day after payday.
3. Reach the $2,000 starter buffer within 60 days, then one month of expenses.
4. Write your emergency definition and tape it — literally — inside the folder or note where you track the fund.
5. Once the emergency fund reaches three months, open the opportunity fund at whatever monthly amount fits, even $50.

---


## Module 4 — Debt Strategy

Debt is not one thing. A 6.5% mortgage on an appreciating home, a 5.5% student loan, and a 22% credit card balance are three different instruments with three different urgencies, and treating them the same wastes money. This module sorts debt by cost and by risk, then eliminates it in the order that saves the most money and the most stress.

### The Debt Inventory

The Alvarez family's non-mortgage debt:

| Debt | Balance | Rate | Minimum payment |
|---|---|---|---|
| Credit card | $4,500 | 22% APR | $135 |
| Student loan | $11,000 | 5.5% | $185 |
| Car loan 1 | $6,000 | 7.0% | $260 |
| Car loan 2 | $3,500 | 8.0% | $160 |
| **Total** | **$25,000** | — | **$740** |

The mortgage ($285,000 at 6.5%) is treated separately: it is secured by an appreciating asset, its interest may be tax-deductible depending on the family's situation, and paying it early is a lower priority than clearing high-interest debt and building the emergency buffer.

### Avalanche vs. Snowball — Use Both, in Sequence

The **avalanche** method pays the highest-interest debt first, which saves the most money mathematically. The **snowball** method pays the smallest balance first, which delivers quick wins and motivation. This course recommends a hybrid: avalanche by interest rate, but with one exception — if a tiny balance can be cleared in 60 days, clear it first for the psychological win, then switch to avalanche. For the Alvarez family, the order is clear: the 22% credit card first (it costs about $990 a year in interest on a $4,500 balance if only minimums are paid, and minimum-only repayment would take more than four years and cost over $2,500 in interest), then car loan 2 at 8%, then car loan 1 at 7%, then the student loan at 5.5%.

**Worked example — the credit card payoff.** Paying $500 a month toward the $4,500 card at 22% APR clears it in about 10 months, with roughly $460 in total interest. Paying only the $135 minimum takes over four years and costs over $2,500 in interest — more than half the original balance again. The difference, about $2,000, is the price of paying slowly. The family finds the $500 by combining the freed surplus from Module 2 with a temporary pause on the opportunity fund.

### When Extra Mortgage Payments Make Sense — and When They Don't

Extra mortgage payments earn a guaranteed return equal to the mortgage rate (6.5% here) — but that return is locked in the house until it is sold or refinanced, and the family cannot eat home equity. Extra mortgage payments make sense only after: the emergency fund is at three months, all debt above the mortgage rate is gone, and retirement contributions capture the full employer match. Before that point, liquidity is worth more than a slightly smaller mortgage. The exception is a family close to retirement with a paid-off home as a core goal — for them, the certainty may outweigh the liquidity, and that is a legitimate choice to make consciously.

### Debt Rules for the Next Generation

The family adopts four written debt rules, posted where financial decisions get made: (1) never carry a credit card balance past the statement due date — the card is a payment tool, not a loan; (2) no new consumer debt without a family meeting and a written payoff plan under 12 months; (3) car loans never exceed three years, and the monthly payment never exceeds 10% of take-home pay; (4) total non-mortgage debt payments never exceed 15% of take-home pay. Rules beat willpower, because willpower is weakest in a showroom.

### Refinancing and Consolidation: The Honest Check

Refinancing can help, but only if the numbers survive three questions: What is the total cost, including fees? How long until the monthly saving repays those fees (the break-even point)? Will the new loan actually be paid off sooner, or does it restart the clock and cost more in total interest? A consolidation loan that turns a 22% card balance into a 12% loan helps only if the card is then cut up and the freed payment goes to the loan — otherwise the family ends up with the loan *and* a new card balance. The Alvarez family checks a refinance of the mortgage at 5.5% versus 6.5%: on $285,000, the monthly saving is roughly $185, but closing costs of $4,500 mean a break-even of about 24 months. Worth doing if they will stay in the home at least that long; not worth doing for a move in a year.

### Action Steps — Module 4

1. List every debt with balance, rate, and minimum payment. Sort by interest rate, highest first.
2. Choose your payoff order and write it down with target payoff dates.
3. Call each lender once: ask about hardship options, rate reductions, and autopay discounts. A single call can cut a card rate by several points.
4. Adopt the family's four debt rules and post them visibly.
5. Set up automatic payments above the minimum on the target debt, and automatic minimums on all others so nothing is ever late.

---

## Module 5 — Investing Fundamentals

Investing is how a family's surplus becomes wealth. It is also the topic most surrounded by noise, fear, and salesmanship. This module strips it to the principles that survive every market cycle: own a diversified mix of productive assets, keep costs low, contribute regularly, and leave it alone for decades.

### What Investing Is — and Is Not

Investing is buying a share of productive assets — businesses, property, bonds — and sharing in the income and growth they produce over time. It is not predicting next month's market, not picking a winning stock, not buying something because someone on the internet is excited about it. The Alvarez family does not need to beat the market. They need to *be in* the market, consistently, for 25 years. The historical record of broad stock market index returns is roughly 10% per year before inflation over the very long term in the United States, with wide variation year to year, including years of steep decline. This course uses a more conservative 7% planning assumption precisely because the future may be worse than the past — and because a plan that works at 7% is robust, while a plan that needs 10% is fragile.

### Risk, Return, and Time

Risk and return travel together: the investments with the highest expected returns also fall the furthest in bad years. That is not a flaw; it is the price of the return. The family's protection against risk is not cleverness — it is time and diversification. A family investing monthly for 25 years buys at high prices and low prices, and the low prices turn out to be the best purchases. A family that stops investing during a downturn locks in the worst outcome: it misses the recovery. The rule is written down in advance: *we contribute the same amount every month regardless of what the market did this month.* Deciding in advance is what makes it possible to keep deciding when the news is frightening.

### The Core Portfolio: Simple Beats Clever

For most families, the core portfolio is three building blocks:

1. **A broad stock index fund** (total market or S&P 500) — the growth engine. Low cost, diversified across hundreds of companies.
2. **A broad bond index fund** — the stabilizer. Lower expected return, but steadier, and it cushions the portfolio when stocks fall.
3. **An international stock index fund** — diversification beyond one country.

A young family might hold 80–90% stocks and 10–20% bonds; a family near retirement might hold 50–60% stocks. The Alvarez family, aged 38 and 40 with 25 years to retirement, uses 80% stocks (60% domestic, 20% international) and 20% bonds. Costs matter enormously: a fund charging 0.03% a year keeps almost all of the return; a fund charging 1% a year quietly takes a large share over 25 years. On a $500,000 portfolio, the difference between 0.03% and 1.0% is roughly $4,850 a year — every year.

**Worked example — cost of fees.** Assume $10,000 invested, $500 added monthly, a 7% gross return, 25 years. At a 0.03% fund cost, the portfolio reaches about $803,000. At a 1.0% fund cost (a 6% net return), it reaches about $704,000. The fee difference alone costs the family about $99,000 over 25 years. Fees are the one part of investing performance the family controls completely.

### Accounts Come Before Investments

Where you hold an investment matters as much as what you hold, because tax-advantaged accounts change the outcome. The priority order for the Alvarez family: (1) contribute enough to each 401(k) to capture the full employer match — the match is an immediate 100% return on those dollars, and skipping it is declining a pay rise; (2) pay off debt above 7%; (3) build the emergency fund to three months; (4) fund Roth IRAs (tax-free growth, flexible in an emergency); (5) increase 401(k) contributions beyond the match; (6) taxable brokerage investing for goals before retirement. The workbook includes a one-page account checklist with current-year contribution limits to verify at the time of use, since limits change.

### Dollar-Cost Averaging and Lump Sums

Contributing the same amount every month (dollar-cost averaging) is the default for a family investing from salary, because salary arrives monthly. It also removes timing decisions. A family that receives a lump sum — a bonus, an inheritance, a tax refund — faces a choice: invest it all at once or spread it over months. Historically, investing a lump sum at once has produced a better outcome about two-thirds of the time, because markets rise more often than they fall — but spreading it over 6–12 months is a reasonable choice for a family that would lose sleep over an immediate drop. The wrong choice is leaving the lump sum in a checking account for years while waiting for the perfect moment.

### Action Steps — Module 5

1. Confirm you are capturing the full employer 401(k) match for every working adult in the household. If not, fix that this month — it outranks everything except the credit card.
2. List every investment account and fund you own, with its annual cost (expense ratio). Move anything charging over 0.50% into a low-cost equivalent unless there is a specific reason not to.
3. Choose your stock/bond split, write it down with the reason, and set your automatic monthly contribution.
4. Write your market-drop rule in one sentence ("When the market falls 20%, we keep contributing and rebalance") and keep it where you will see it during the next downturn.

---

## Module 6 — Asset Allocation Across a Lifetime

Asset allocation — how much of the portfolio sits in stocks, bonds, and other assets — is the largest single determinant of investment outcomes, larger than which funds you pick. This module sets the allocation for each stage of a family's life and explains how and when to change it.

### The Glide Path

A family's allocation should change as the time horizon shortens. The course uses a simple glide path:

| Family stage | Ages | Stocks | Bonds | Notes |
|---|---|---|---|---|
| Building | 25–40 | 85–90% | 10–15% | Maximum growth; decades to recover from drops |
| Growing | 40–50 | 75–80% | 20–25% | Alvarez family sits here |
| Consolidating | 50–60 | 60–70% | 30–40% | Protecting what has been built |
| Approaching retirement | 60–65 | 50–60% | 40–50% | Sequence-of-returns risk becomes the main danger |
| Retired | 65+ | 40–60% | 40–60% | Balance growth against withdrawals |

The Alvarez family at 80/20 is exactly on this path. The key discipline is that allocation changes are made on birthdays, not on headlines. Rebalancing once a year — selling a little of what grew and buying a little of what lagged to restore the target percentages — forces the family to sell high and buy low, mechanically, without needing to predict anything.

### Sequence-of-Returns Risk: The Danger Nobody Warns About

Two families can earn the same average return and end up with very different retirements, because the *order* of returns matters once withdrawals begin. A family that retires into a market decline and withdraws from a falling portfolio permanently damages its capital; a family that retires into a rising market does not. The defenses are: (1) hold two to three years of spending in bonds or cash at retirement, so withdrawals in a downturn come from the stable bucket; (2) keep the stock allocation moderate in the five years before and after retirement; (3) stay flexible on spending in down years. This is why Module 6's allocation shift before retirement is not timidity — it is the single most valuable protection a family can buy.

### The Alvarez Portfolio at Ages 40, 50, and 60 (Projection)

Assume the family invests $1,350 a month (their automated amount from Module 2, growing 3% a year with wages) at a 7% assumed return, starting from $42,000:

- **Age 50 (10 years):** approximately $315,000
- **Age 60 (20 years):** approximately $830,000
- **Age 65 (25 years):** approximately $1,215,000

These are illustrations at a stated 7% assumption, before taxes and fees, and actual results will differ — sometimes substantially. The lesson is the shape of the curve: growth is slow for the first decade and then accelerates, because compounding works on an ever-larger base. Families who quit in year seven, when the balance still looks modest, miss the years when the curve bends upward.

### Diversification Beyond Stocks and Bonds

Real estate (the family home and possibly a rental later — see the companion volume on rental property), inflation-protected bonds, and, for some families, a small allocation to real assets can all play a role. What does not belong in the core portfolio: speculative single stocks as a large share, leveraged products, and anything the family does not understand well enough to explain to a teenager. Complexity is not sophistication; it is usually a fee in disguise.

### Rebalancing in Practice

Once a year, on a fixed date (the Alvarez family picks January 15), the family checks the portfolio against its target. If stocks have grown to 86% against an 80% target, they sell 6% of the portfolio's stock holdings and buy bonds. Inside a retirement account this has no immediate tax cost; in a taxable account, they rebalance mainly with new contributions to limit taxable sales. The whole exercise takes 30 minutes. It is the highest-value half-hour in the family's financial year.

### Action Steps — Module 6

1. Write down your target allocation for your current stage and the date you will move to the next stage.
2. Put a recurring annual calendar event for rebalancing on a fixed date, and write the steps down so future-you can follow them without thinking.
3. Run your own projection in the dashboard: your monthly contribution, your starting balance, 7% and 5% assumptions side by side, so you can see the range of plausible outcomes rather than a single number.
4. Identify any holding above 10% of your portfolio in a single stock or fund and decide whether it belongs there.

---

## Module 7 — Tax-Aware Planning Basics

Taxes are usually a family's largest lifetime expense — larger than housing over a lifetime for many households — and yet most families spend more time choosing a phone plan than planning their taxes. Tax-aware planning is not tax evasion, and it is not clever loopholes. It is the legal, ordinary practice of using the accounts and timing the tax code already offers, and avoiding the unforced errors that hand money to the tax authority unnecessarily.

### The Three Tax Buckets

Every dollar a family saves sits in one of three tax buckets, and the mix matters:

1. **Tax now** (taxable brokerage accounts) — contributions are made with after-tax money, and interest, dividends, and capital gains are taxed as they occur. Flexible, no contribution limits, no withdrawal restrictions.
2. **Tax later** (traditional 401(k) and traditional IRA) — contributions reduce taxable income today, investments grow tax-deferred, and withdrawals in retirement are taxed as income. Best when the family's tax rate is higher now than it will be in retirement.
3. **Tax never** (Roth IRA and Roth 401(k)) — contributions are made with after-tax money, growth is tax-free, and qualified withdrawals in retirement are tax-free. Best when the family's tax rate is lower now than it will be later — which is often true for younger families and for families in lower brackets.

The Alvarez family, in a moderate bracket, splits contributions across tax-later (401(k) to the match and beyond) and tax-never (Roth IRAs), because no one knows future tax rates and a mix of buckets gives the family choices in retirement about which bucket to draw from each year. That flexibility is itself a form of wealth.

### The Annual Tax Habits That Matter Most

Four habits capture most of the value: (1) maximize contributions to tax-advantaged accounts before the deadlines — retirement contributions, and health savings accounts where eligible; (2) keep the family's withholding roughly right, so there is neither a large refund (an interest-free loan to the government) nor a large bill; (3) harvest losses in taxable accounts where the rules allow — selling an investment at a loss to offset gains, then replacing it with a similar (not identical) investment; (4) keep records. A family that keeps a single folder — physical or digital — with every tax document, receipt for deductible expenses, and charitable giving record saves hours every April and never pays tax twice on the same dollar for want of a receipt.

**Worked example — Roth vs. traditional.** Assume a family contributes $6,000 a year for 30 years at a 7% assumed return, reaching about $567,000. In a traditional account, every dollar withdrawn is taxed; at a 22% retirement tax rate, the after-tax value is about $442,000. In a Roth account, contributions were taxed up front (at 22%, costing about $1,320 a year in extra tax during the working years), but the full $567,000 is tax-free in retirement. Which wins depends on the tax rate now versus later — the exact question a qualified tax professional can help the family answer with their real numbers. The point of the example is that the choice is worth making deliberately, not by default.

### Common Unforced Errors

The expensive mistakes are ordinary ones: not contributing enough to get the employer match; holding income-producing investments in a taxable account while leaving tax-advantaged space unused; selling investments in a taxable account without checking the tax cost; forgetting to name or update beneficiaries (see Module 10); and treating a tax refund as a windfall rather than adjusting withholding so the money arrives monthly, where it can be invested. None of these require brilliance to fix. All of them require attention once a year.

### Action Steps — Module 7

1. List your three tax buckets and the balance in each. If one bucket holds everything, plan a deliberate shift over the next two years.
2. Check your withholding now, not in April. Adjust it so a refund, if any, is small.
3. Create the single tax folder — digital or physical — and put this year's documents in it today.
4. Book a one-hour session with a qualified tax professional before any large decision (a property sale, a business, a Roth conversion). Bring your bucket list and your questions, not just your return.

---

## Module 8 — Retirement Accounts

Retirement accounts are where the family's long-term wealth will mostly live, and the rules around them are the most valuable piece of financial machinery a family can learn. The accounts are not the investment; they are the container, and choosing the right container is worth thousands of dollars over a career.

### The 401(k): The Workhorse

A 401(k) is an employer plan. The Alvarez family each contributes through payroll. The 2026-era mechanics the family should verify each year: an employer match (commonly 50 cents or a dollar for each dollar up to a percentage of pay), a pre-tax (traditional) or Roth option, and annual contribution limits set by the tax authority. James's employer matches 100% of the first 4% of pay — on his $65,000 salary, contributing 4% ($2,600) earns a $2,600 match, an immediate doubling of that money. Maria's employer matches 50% of the first 6% — on her $55,000 salary, contributing 6% ($3,300) earns $1,650. Together, capturing both matches is $4,250 a year of free money. Families that leave a match unclaimed are the only families in this course who are guaranteed to be leaving money on the table.

Within the 401(k), the family chooses low-cost index funds (Module 5) and sets contributions to rise automatically — many plans allow an automatic 1% annual increase, which the family enables so that every pay rise lifts the savings rate without a decision.

### IRAs: The Family's Own Account

An Individual Retirement Account is opened by the family, not the employer. A traditional IRA offers tax-deferred growth and possibly a deduction; a Roth IRA offers tax-free growth and tax-free qualified withdrawals, and — importantly — contributions (not earnings) can be withdrawn at any time without penalty, which makes a Roth IRA a flexible second-layer emergency reserve for a young family. The family verifies the current annual contribution limits and income limits each year, since both change. The Alvarez family funds two Roth IRAs at $250 a month each once the credit card is gone — $6,000 a year combined — and treats that as the backbone of their retirement saving beyond the 401(k) match.

### The Order of Operations (Retirement Saving)

The family's written order, taped inside the workbook:

1. Contribute to each 401(k) up to the full employer match.
2. Eliminate high-interest debt (above 7%).
3. Build the emergency fund to three months.
4. Fund Roth IRAs.
5. Raise 401(k) contributions toward the annual limit.
6. Invest in a taxable brokerage account for pre-retirement goals.

This order is a default, not a law: a family with a large tax bill might prioritize pre-tax 401(k) contributions sooner, and a family with a pension might need less in these accounts. The value is in having an order at all, so each pay rise and each bonus has a pre-decided destination.

### What Happens When a Job Changes

When a worker leaves a job, the old 401(k) can usually be rolled into the new employer's plan or into an IRA. The costly mistake is cashing it out: a $20,000 cash-out at age 35 can cost roughly $5,000 in taxes and penalties immediately, and — far worse — removes about $150,000 of projected age-65 value at a 7% assumed return. The rule is written in the workbook in bold: **never cash out a retirement account to cover a short-term expense; find any other way first.**

### Action Steps — Module 8

1. Verify both employer matches and confirm you are capturing each in full. Calculate the annual dollar value of each match.
2. Enable automatic annual contribution increases of 1% in each 401(k).
3. Open Roth IRAs for each adult if you do not have them, and set the automatic monthly contribution — even $100 to start.
4. Write your job-change rule down: old 401(k) rolls over, never cashes out. Keep the rollover instructions with your estate documents.

---

## Module 9 — Insurance: Life, Disability, and Umbrella

Insurance is the part of the wealth plan that protects everything else. A family can do everything right for twenty years and lose it in a single uninsured event. Insurance is also the part most families get wrong in both directions: underinsured where it matters most (disability), and overinsured where it matters least (small policies sold with a product).

### Life Insurance: How Much Is Enough?

Life insurance replaces the income a family would lose if an earner dies. The rule of thumb — ten times annual income — is a starting point, not an answer. The Alvarez family does the real calculation, and the workbook walks any family through the same one:

**Worked example — insurance needs (Alvarez family).**

| Need | Amount |
|---|---|
| Income replacement: $60,000 a year for 15 years until the youngest is 24, present value at a 4% assumed discount rate | ~$667,000 |
| Pay off mortgage | $285,000 |
| Pay off remaining debts | $25,000 |
| Children's education fund | $80,000 |
| Final expenses | $15,000 |
| **Total needs** | **$1,072,000** |
| Less: existing savings and retirement | −$48,000 |
| Less: existing life insurance through work ($100,000 each) | −$200,000 |
| **Additional life insurance needed** | **~$824,000** |

The family rounds this to $850,000 of term life insurance on James and $750,000 on Maria (her income is lower, but her unpaid care work would cost a great deal to replace — a cost families routinely forget). Term life insurance — pure protection for a fixed period, 20 years here — costs a healthy 40-year-old roughly $40–$70 a month per $500,000 of coverage, though actual premiums depend on age, health, and underwriting. Whole life and other permanent policies cost many times more for the same death benefit, and this course's position is direct: buy term, invest the difference, and revisit the coverage at every major life event.

### Disability Insurance: The Forgotten Coverage

A 40-year-old worker is statistically more likely to be disabled for 90 days or more during their career than to die before retirement, yet disability insurance is the coverage families most often lack. Employer short-term disability usually covers a few months at partial pay; long-term disability through work, where offered, typically replaces 60% of salary. The family checks: does the employer policy exist, what percentage does it replace, how long is the waiting period, and is the benefit taxable? If employer coverage is thin or absent, an individual long-term disability policy — ideally one that replaces 60–65% of income with a 90-day waiting period — is the next purchase after term life insurance. The waiting period aligns with the emergency fund: three months of savings covers the 90 days before benefits begin, which is exactly why Modules 3 and 9 are built to fit together.

### Umbrella, Home, and Auto: The Liability Shield

Once a family's net worth passes roughly $200,000–$300,000, a personal umbrella policy — typically $1 million of extra liability coverage above home and auto policies, often costing $150–$300 a year — is inexpensive protection against a lawsuit that could take the house and the retirement accounts. The family also reviews home and auto coverage annually: replacement-cost coverage on the home (not market value), deductibles high enough to keep premiums down but low enough to pay from the emergency fund, and liability limits on auto insurance raised above state minimums, which are often far too low to protect a family's assets after a serious accident.

### What Not to Buy

The family declines, politely and firmly: insurance sold as an investment, extended warranties on small electronics, credit life insurance tied to a loan, and accidental-death policies that pay only for one narrow cause of death. Each of these is either poor value or a duplicate of coverage the family already owns. The test for any policy is one question: *what specific financial loss does this cover that nothing else covers, and what would that loss cost us?*

### Action Steps — Module 9

1. Complete the insurance-needs worksheet in the workbook for each adult earner, using the Alvarez table as your model.
2. Get term life insurance quotes for 20-year level term at the calculated amount. Compare at least three insurers.
3. Check your employer disability coverage in writing: percentage replaced, waiting period, and duration. Fill any gap.
4. Get an umbrella policy quote once household net worth passes $200,000, and review home and auto liability limits annually.
5. Store all policy numbers, insurer contacts, and beneficiary designations in one place, and tell your executor where it is.

---


## Module 10 — Estate Documents: Wills, Powers of Attorney, Healthcare Directives

Estate planning is not about being rich. It is about being clear. Without documents, a family's wishes are guesses, and the state makes the decisions — about who raises the children, who manages the money, and who decides on medical care. The cost of the documents is a few hundred dollars; the cost of not having them can be years of family conflict and court proceedings.

### The Four Core Documents

Every adult in the household needs four documents:

1. **A will** — names an executor, names guardians for minor children, and states who receives what. Without a will, the state's default rules decide, and those rules may not match the family's wishes at all. The Alvarez will names Maria's sister as guardian, James's brother as alternate, and leaves assets in trust for the children until age 25 (see Module 11) rather than handing a teenager a lump sum at 18.
2. **A durable financial power of attorney** — names someone to handle money and property if an adult becomes unable to do so. Without it, even a spouse may need a court order to manage a solely owned account or sell a property.
3. **A healthcare power of attorney (healthcare proxy)** — names someone to make medical decisions if an adult cannot. The Alvarez family names each other first, then a sibling.
4. **A living will / advance directive** — states wishes about life-sustaining treatment. This is the document that prevents the worst family argument there is: relatives disagreeing in a hospital corridor about what their loved one would have wanted.

### Beneficiaries Beat Wills — Check Them

Retirement accounts, life insurance, and many bank accounts pass by beneficiary designation, not by will. If the beneficiary form still names an ex-partner, a deceased parent, or no one at all, the will cannot fix it. The family reviews every beneficiary designation annually — 401(k)s, IRAs, life insurance, bank payable-on-death designations — and after every marriage, divorce, birth, and death. This 20-minute annual check is the highest-value estate task there is.

### Guardianship: The Decision Parents Avoid

Choosing a guardian for minor children is the hardest decision in this module, and the reason many parents never write a will at all. The course's advice is practical: choose the best available person, name an alternate, write a short letter explaining why (Module 14 covers the letter), and accept that the choice can be changed later. A good-enough guardian named in a will is infinitely better than a perfect guardian never named. The family also discusses the choice with the chosen person before naming them — a guardian who is surprised in a lawyer's office is a guardian who may decline.

### Where Documents Live — and Who Knows

Documents that no one can find are almost as useless as documents that do not exist. The Alvarez family keeps originals in a fireproof box at home and copies with their estate attorney, and each adult carries a card in their wallet stating where the documents are and who the healthcare proxy is. The executor and the guardians are told directly, in conversation, where everything is. Digital copies are stored in an encrypted folder, and the password is shared with the executor through a secure method — not written on a note stuck to the box.

**Worked example — estate-document checklist (Alvarez family).** Will signed and witnessed: yes. Guardian named, alternate named, guardian informed: yes. Financial power of attorney: yes, each spouse. Healthcare proxy: yes, each spouse. Living will: yes. Beneficiaries checked on two 401(k)s, two Roth IRAs, two life policies: yes, all current. Digital asset list (accounts, passwords via a password manager, online photos): compiled. Total cost: $650 for an attorney-drafted package, plus two hours of the family's time. Total time without documents, had something happened: months of court proceedings, and a judge choosing the guardian.

### Action Steps — Module 10

1. Complete the estate-document checklist in the workbook. Mark what exists, what is out of date, and what is missing.
2. Book the attorney appointment this month. Bring the checklist, the guardian decision, and the beneficiary list.
3. Review and update every beneficiary designation. Record the date of each check.
4. Tell your executor, guardians, and healthcare proxy where the documents live, in person.
5. Revisit the documents every three years and after every major life event.

---

## Module 11 — Trusts Explained

Trusts sound like something only wealthy families use. In reality, a trust is simply a legal container with instructions attached — and for a family with minor children, it is often the most important estate tool of all, because without one, a court may control the children's inheritance until they turn 18, and then hand it over in full.

### What a Trust Does

A trust holds assets for the benefit of named people (beneficiaries), managed by a trustee according to instructions the family writes. The instructions can say: use the money for the children's education and health, distribute a portion at 25, another at 30, and the remainder at 35. A will can create a testamentary trust that only comes into existence at death — the usual choice for a family like the Alvarez family — or a family can create a living (revocable) trust during life, which can also avoid the public court process called probate in many jurisdictions and can manage assets if the creators become incapacitated.

### The Three Trusts a Middle-Income Family Might Use

1. **Testamentary trust in a will** — the default recommendation in this course for families with minor children. Low cost (it is part of the will), and it solves the central problem: children do not receive a large sum at 18.
2. **Revocable living trust** — the family transfers assets (home, accounts) into the trust during life and manages them as trustee. On death or incapacity, a successor trustee steps in without court involvement. More expensive to set up and requires actually retitling assets into the trust — a step families often skip, which defeats the purpose.
3. **Special-needs trust** — if a child or other beneficiary receives government benefits tied to asset limits, an inheritance paid directly can disqualify them. A special-needs trust preserves eligibility. Any family in this situation should get specialist advice; the generic documents in this course are not a substitute.

### Choosing a Trustee

The trustee manages money for the children, possibly for years. The family chooses someone financially responsible, trustworthy, and willing — often a different person from the guardian, so that no single person controls both the children and their money. The Alvarez family names James's brother as trustee (he is an accountant) and Maria's sister as guardian, with a professional trustee as a backup if both decline. The trust also names a trust protector — a provision allowing a named person to replace the trustee if needed — because the trustee chosen at age 40 may not be the right trustee at age 60.

### What Trusts Do Not Do

A trust does not make a family rich, does not avoid all taxes, and does not protect assets from every creditor. Marketing that promises those things is selling something. A trust's real job is narrower and more valuable: it makes sure the money is used the way the family intended, at the ages the family intended, by someone the family chose. That is enough.

### Action Steps — Module 11

1. Decide, with your estate attorney, whether a testamentary trust in your will is sufficient or whether a living trust fits your situation. Write the reason for the choice.
2. Name a trustee and a successor trustee, and ask each if they are willing.
3. Write the distribution ages and purposes (education, health, first home, business) in plain language for the attorney to draft.
4. If any beneficiary receives needs-based government benefits, raise a special-needs trust with the attorney before signing anything.

---

## Module 12 — Teaching Children About Money

Wealth that is not accompanied by skill does not survive a generation. Studies of family wealth consistently find that a large share of inherited wealth is spent within a generation or two — not because the heirs are bad people, but because no one taught them the skills the wealth required. This module is the countermeasure: a year-by-year curriculum for the Alvarez children, ages 9 and 12, that any family can adapt.

### The Curriculum by Age

**Ages 5–8: Money is real, and choices are real.** Children earn small amounts for extra tasks (not for chores that are part of family life), divide money into three jars — spend, save, give — and learn that when the spend jar is empty, the answer is to wait. The Alvarez 9-year-old receives $5 a week: $2 to spend, $2 to save, $1 to give.

**Ages 9–12: Earning, budgeting, and delayed gratification.** The children get a monthly clothing and fun budget they manage themselves — including the consequences of spending it all in week one. They open savings accounts in their own names, track a savings goal on a chart, and learn compound growth with a concrete example: $10 a month at a 7% assumed return becomes about $1,760 in 10 years, of which $1,200 was contributions and $560 was growth. Small numbers, big idea.

**Ages 13–17: Work, accounts, and the cost of borrowing.** Teenagers earn from part-time work, open a checking account with a debit card, file a simple tax return, and learn the credit card lesson with real numbers: a $500 purchase at 22% APR, paid at $25 a month, takes two years and costs over $100 in interest. They also learn the investing lesson properly: a custodial Roth IRA can be funded from earned income, and money invested at 16 has 50 years to compound.

**Ages 18+: The handoff.** The young adult receives the family wealth plan in full — the net-worth statement, the insurance summary, the estate documents' location — and a first real responsibility, such as managing one household budget category or one investment account with supervision. The goal is not control; it is competence before independence.

### The Family Economy

The Alvarez family runs a small family economy: children earn "family dollars" for extra work, which can be exchanged for privileges (choosing dinner, a later bedtime on Friday, a family outing) or converted to real money at a fixed rate. The point is not the currency; it is that children experience earning, choosing, saving, and regretting a purchase in a low-stakes environment, so they do not have to learn those lessons at 25 with rent due.

### Money Talk at the Table

The family holds a monthly "money minute" at dinner — one short, age-appropriate topic: what is a stock, why does the family save, what did something cost and was it worth it. The children are told the family's values about money (Module 1) long before they are told the family's numbers. And when a parent makes a money mistake — an impulse purchase, a forgotten bill — it is named out loud. Children who see adults handle mistakes calmly learn that money is manageable; children who only see perfection learn that money is frightening.

### Action Steps — Module 12

1. Set up the three jars (spend, save, give) for each child under 12, and a managed budget for each teenager.
2. Hold the first monthly money minute at dinner this month. Pick one topic and keep it under five minutes.
3. Open a savings account in each child's name and set a first savings goal together, with a visible chart.
4. Write down the age at which each child will learn each part of the family plan, and put it in the family governance file (Module 13).

---


## Module 13 — Family Governance and Meetings

A family that builds wealth without a way of deciding things together will argue about the wealth. Family governance is the unglamorous machinery — meetings, roles, records, and agreed rules — that keeps a wealth plan alive across decades and across generations. Businesses have boards; families building wealth need something like one, at their own scale.

### The Annual Family Wealth Meeting

Once a year, the Alvarez family holds a two-hour family wealth meeting, separate from the weekly money meeting. The agenda is fixed and included as a template with this course: (1) review the net-worth statement and the year's progress; (2) review the investment allocation and rebalance if needed; (3) review insurance and estate documents — anything changed?; (4) review the children's money education (Module 12); (5) one decision about the coming year (a savings-rate change, a new goal, a gift); (6) the legacy conversation — one story from the family's history, told by an elder or read from a legacy letter. Children old enough to understand attend for part of the meeting. The meeting is scheduled a year in advance, on the same weekend every year, and it is treated as immovable as a holiday.

### Roles, Not Just Good Intentions

Governance works when roles are named. The Alvarez family assigns: a **financial lead** (James, who manages the dashboard and the investments), a **records keeper** (Maria, who keeps the documents, passwords, and tax folder), an **estate contact** (Maria's sister, who knows where everything is), and a **next-generation lead** (the 12-year-old, who tracks the children's savings goals and reports at the annual meeting). Roles rotate every two years so that no single person holds all the knowledge — because the family's greatest vulnerability is one person knowing everything and then being unavailable.

### The Family Constitution: One Page

The family writes a one-page family constitution: our values (from Module 1), our rules (debt rules from Module 4, the market-drop rule from Module 5), our roles, our meeting schedule, and our procedure for disagreements (talk, wait 48 hours, decide together, revisit in a year). It is signed by both adults and kept with the estate documents. It sounds formal, and that is the point: formality is what turns good intentions into a system that survives a bad year, a bereavement, or a disagreement.

### Decision Rules for Big Money

The family adopts three decision rules for any expenditure or commitment above $1,000 that is not already in the plan: (1) wait 72 hours before deciding; (2) both adults agree; (3) write down the reason and the expected outcome, and review it at the next annual meeting. These rules have saved the Alvarez family from a timeshare presentation, a "guaranteed" investment pitched by a relative, and a car upgrade that would have added $300 a month for five years. The 72-hour rule is the cheapest financial product in this entire course.

### When Families Disagree About Money

Disagreement is normal; the plan for disagreement is what matters. The course's framework: separate the money decision from the relationship (argue about the numbers, not about each other), name the underlying value in conflict (security versus enjoyment, present versus future), and look for the trade that honors both — often a smaller version of the thing, funded from the spending account rather than from savings. If a disagreement persists, the default is the plan: the written plan wins until the next annual meeting, when it can be changed deliberately. A plan that can be overturned in a heated moment is not a plan.

### Action Steps — Module 13

1. Schedule the first annual family wealth meeting. Put it on the calendar a year in advance and send the agenda to everyone attending.
2. Assign the four roles and write them into your one-page family constitution.
3. Adopt the three decision rules for spending above $1,000 and post them with the debt rules.
4. Start a family record: one folder, physical or digital, holding the constitution, the net-worth statements, the meeting notes, and the legacy letters.

---

## Module 14 — Legacy Letters and Values Transfer

Money transfers in a will. Values transfer in a letter. The families whose wealth survives are usually the ones who passed on both, because an heir who understands *why* the family saved, what it cost, and what it is for will treat the money differently from an heir who receives a number with no story.

### What a Legacy Letter Is

A legacy letter (sometimes called an ethical will) is a personal document, not a legal one. It says: who we are, what we learned about money and life, what we hope for the people reading it, what we regret, and what we are proud of. It can be one page or ten. It is written in plain language, in the writer's own voice, and it is updated every few years. The Alvarez parents each write one to their children, and one to each other. The template included with this course provides structured prompts so that no one stares at a blank page.

### What to Include

The template guides the writer through seven sections: (1) our family's story — where we came from, in a paragraph; (2) what money meant in our childhoods; (3) the hardest money decision we made and what it taught us; (4) the three values we most want to pass on; (5) what we hope each child does with their life — not a career prescription, but a hope; (6) what we are grateful for; (7) one request — something we ask of the reader, such as "take care of each other" or "keep the annual meeting going." The most powerful letters are specific: a named memory, a named mistake, a named hope. Generalities are forgettable; a story about a grandmother mending a coat so the family could save for a house is remembered for decades.

### When and How to Share

A legacy letter is not only read after a death. The Alvarez family reads a short extract at each annual family wealth meeting (Module 13), and each parent gives their children a letter on a milestone birthday — 16, 18, 21. Sharing letters during life turns them from a farewell into a conversation, and gives the children a chance to ask questions while the answers are still available. Letters are stored with the estate documents and in the family record, and a copy is held by the executor.

### Values Transfer Is Also Behavior

Children learn more from watching than from reading. The legacy letter matters, but so does the fact that the children saw their parents hold a weekly money meeting, say no to a purchase, keep an emergency fund, and give money away (Module 15). The course's blunt summary: the letter tells the children what the family believes; the family's behavior tells them whether the family believed it.

### Action Steps — Module 14

1. Each adult writes a first legacy letter using the template prompts. Aim for two pages, not twenty. Imperfect and finished beats perfect and unwritten.
2. Share one paragraph from your letter at the next family meeting.
3. Record one family story — audio or video, on a phone — from an older relative this year. A three-minute recording is a legacy asset.
4. Store the letters with the estate documents and note their location in the family record.

---

## Module 15 — Charitable Giving

Giving is part of a wealth plan for three reasons: it expresses the family's values, it teaches children that wealth has a purpose beyond accumulation, and — where the tax rules allow — it can be tax-efficient. A family that never gives teaches its children that money is only for the family, and that lesson shapes how the next generation will use whatever it inherits.

### A Giving Plan, Not Random Generosity

The Alvarez family sets a giving budget of 2% of take-home pay — about $170 a month — and gives it deliberately: half to a local food bank they have visited, a quarter to the children's school fund, and a quarter held for the children to direct themselves, so they practice choosing a cause and seeing the result. The amount matters less than the regularity and the deliberateness. A family that gives 1% consistently and talks about it teaches more than a family that gives a large amount once and never mentions it.

### Giving With Children

Children direct a share of the giving budget from age 10, researching a cause, presenting it at the family meeting, and reporting back on what the gift did. This is the most effective financial education in this course: it requires research, judgment, delayed gratification, and empathy — and the stakes are real but small. The family also gives time, not only money: one volunteer day a quarter, chosen by the children in rotation.

### Tax-Efficient Giving (General Education Only)

In many jurisdictions, charitable donations may be deductible, and donating appreciated investments rather than cash can be more tax-efficient than selling the investment and donating the proceeds — because the capital gain may not be taxed. The rules differ by jurisdiction and change over time, and this course does not advise any family on their specific tax position. The habit to build is record-keeping: every donation receipt goes into the tax folder (Module 7) the day it is made, so that whatever deduction is available is actually claimed. A family that gives without records gives twice: once to the charity, once to the tax authority.

### Donor-Advised Funds and Bequests

For families whose giving grows, a donor-advised fund — an account from which the family recommends grants to charities over time — can simplify record-keeping and allow a large gift in a high-income year to be spread across later years. For legacy giving, the will can include a charitable bequest — a fixed amount or a percentage — and the family can state in the legacy letter why those causes matter. None of this is required for the Alvarez family now; it is included so that the plan has somewhere to grow.

### Action Steps — Module 15

1. Set a giving budget as a percentage of take-home pay, however small, and automate it.
2. Give the children a share of the giving budget to direct, with a short presentation at the family meeting.
3. Keep every donation receipt in the tax folder the day the gift is made.
4. Name the causes that matter to your family in the legacy letter, and the reason they matter.

---


## Module 16 — Business-Owning Families

Some families build wealth through a salary. Others build it through a business — and a business-owning family needs a wealth plan that treats the business as what it is: the family's largest asset, its largest risk, and its most complicated inheritance. This module is for families who own a business or are considering one; families without a business should still read it, because a side business is the most common way a salaried family's income grows.

### The Business Is Not the Family's Bank Account

The first rule of a business-owning family is separation: the business has its own accounts, its own records, and its own pay structure. The owners pay themselves a regular salary or draw, on a schedule, and the business keeps its own emergency reserve — three to six months of operating expenses — separate from the family's emergency fund. A family that treats business revenue as personal income will find that neither the business nor the family has a buffer when a bad quarter arrives. The Alvarez family considers a weekend catering side business run by Maria; the plan requires it to hold its own $5,000 reserve before it pays Maria anything beyond ingredients.

### Valuing and Protecting the Business

A business is worth what a buyer would pay for it — which depends on its profit, its systems, and how much it depends on the owner. A business that stops when the owner stops is worth far less than one with documented processes, a customer list, and staff who can operate it. The family should: keep clean books from day one; document key processes; insure the business (liability, and key-person coverage where appropriate); and have a written buy-sell agreement if there are partners, stating what happens if a partner dies, leaves, or wants to sell. A partnership without a buy-sell agreement is a future lawsuit with a friendly beginning.

### Paying the Family, Tax-Aware

How owners pay themselves — salary, distributions, dividends — has tax consequences that differ by business structure and jurisdiction. The general principles: pay a reasonable salary for the work actually done; keep distributions documented and regular rather than random; fund retirement through the business where the rules allow (a solo 401(k) or similar plan can allow substantially higher contributions than an IRA alone, within the limits in force at the time); and keep a qualified tax professional involved from the first year, not the year a problem appears. The most expensive business tax mistake is the one discovered three years late.

### Succession: Who Runs It Next?

Most family businesses fail in the second generation, and the cause is usually not the market — it is the absence of a succession plan. The questions to answer while everyone is healthy and friendly: who is capable of running the business, who wants to, how will ownership transfer (gift, sale, or a mix), how will non-involved children be treated fairly (fair does not always mean equal — a child who works in the business and a child who does not may reasonably receive different assets of equal value), and what happens if no one wants it (a sale, with the proceeds divided)? These conversations are difficult, which is why they belong in the annual family meeting (Module 13) years before they are urgent, not in a lawyer's office after a crisis.

**Worked example — a side business's first year.** Maria's catering business earns $18,000 in revenue in year one, with $7,000 of costs (ingredients, transport, insurance), leaving $11,000 of profit. The family plan allocates it: $3,000 to the business reserve, $3,000 to taxes set aside in a separate account, $3,000 to the family's Roth IRAs, and $2,000 to the opportunity fund. Nothing is spent on lifestyle in year one. By year three, at $30,000 revenue and $16,000 profit, the allocation can include a modest lifestyle share — because the reserve, the tax account, and the retirement habit are already built.

### Action Steps — Module 16

1. If you own or run a business, separate its accounts from the family's this month. No exceptions, no "I'll do it later."
2. Build the business's own three-to-six-month operating reserve before increasing any owner's pay.
3. Document the five most important processes in the business, so it can operate for two weeks without the owner.
4. If there are partners, put a written buy-sell agreement in place. If there is a succession question, raise it at the next annual family meeting — early, while it is still theoretical.

---

## Module 17 — Annual Review System

A plan that is never reviewed is a wish. A plan reviewed once a year, with a fixed process, stays alive for decades. This module builds the Alvarez family's annual review — a single day, once a year, that maintains everything the previous sixteen modules built.

### The Annual Review Day

The family picks one Saturday in January. The day has five blocks, each with a checklist in the workbook:

1. **Numbers (morning, 90 minutes).** Update the net-worth statement. Compare this year to last year. Calculate the savings rate: total saved divided by total take-home pay. The Alvarez family's savings rate in year one is about 16% ($1,350 automated saving plus $400 irregular fund, against $8,600 take-home — the workbook shows the calculation). Review investment performance against the plan's assumption, not against the market's best fund.
2. **Protection (late morning, 45 minutes).** Insurance still adequate? Any new child, new home, new debt, new job? Beneficiaries still current? Estate documents still reflect reality?
3. **Tax (midday, 30 minutes).** Any tax-advantaged space left unused last year? Withholding still right? Records complete?
4. **Goals (afternoon, 60 minutes).** Which goals were met, which slipped, and what changes for next year? Set one savings change, one learning goal, one family goal.
5. **Legacy (late afternoon, 30 minutes).** Update the legacy letters. Record one family story. Confirm the annual family wealth meeting date for next year.

### The Savings Rate: The One Number That Matters

Of all the numbers in this course, the savings rate is the one to watch. A family saving 10% of take-home pay, starting at 40, will likely need to work longer or live more modestly in retirement than a family saving 20%. The rule of thumb used in this course: aim for 15–20% of gross income saved for retirement and long-term goals combined, including employer matches, with the rate rising as income rises. The Alvarez family starts at about 16% and raises it 1% a year — reaching 20% by year five, mostly through pay rises rather than spending cuts.

### Tracking Progress Without Obsession

The family updates the net-worth statement monthly but reviews investments only at the annual review. Checking investments daily creates anxiety and bad decisions; checking them annually creates perspective. The dashboard spreadsheet shows the trend, not the noise: net worth over time, savings rate over time, and progress toward each goal as a percentage. A family that watches the trend line will keep going; a family that watches the daily balance will quit.

### When the Plan Needs to Change

Plans change for good reasons: a new child, a job loss, a move, an illness, an inheritance. The annual review is the moment to change the plan deliberately — never in the middle of a crisis, and never because of a headline. Any change is written down with a reason and a date, so that future reviews can see whether the change helped. A family that changes its plan every month has no plan; a family that never changes its plan has a museum piece.

### Action Steps — Module 17

1. Put the annual review day on the calendar now, for this January and next.
2. Complete the annual review checklist in the workbook, even if it is your first year — a partial first review is worth more than a perfect review postponed.
3. Calculate your savings rate and write it on the dashboard. Set the target for next year.
4. Record every plan change with a reason and a date, in the family record.

---

## Module 18 — The 5-Year Implementation Roadmap

Everything in this course converges here: a dated, sequenced plan for the Alvarez family — and, by adaptation, for yours — covering the next five years. The roadmap is deliberately front-loaded with protection and foundations, because wealth built on a solid base compounds faster than wealth built on sand.

### Year 1 — Foundations (Months 1–12)

- Complete the net-worth statement, cash-flow map, and values statement (Modules 1–2).
- Reach the $2,000 starter emergency buffer, then one month of expenses (Module 3).
- Clear the 22% credit card using the avalanche order (Module 4).
- Capture both full employer 401(k) matches; open Roth IRAs at $100 a month each (Modules 5, 8).
- Buy 20-year term life insurance at the calculated amounts; check disability coverage (Module 9).
- Sign the four estate documents; name guardians and trustees; check every beneficiary (Modules 10–11).
- Hold the first annual family wealth meeting; write first legacy letters (Modules 13–14).
- Set the giving budget at 1–2% (Module 15).

**End-of-year-1 position (projection at stated assumptions):** credit card gone, emergency fund around $14,000, retirement savings around $58,000 (contributions plus growth at 7%), net worth around $155,000. Savings rate about 16%.

### Year 2 — Momentum (Months 13–24)

- Emergency fund reaches three months (~$20,000); start the opportunity fund (Module 3).
- Clear car loan 2; raise Roth IRA contributions to $250 a month each (Modules 4, 8).
- Raise the 401(k) contributions 1% via automatic escalation (Module 8).
- Begin the children's money curriculum in earnest; give children a share of the giving budget (Modules 12, 15).
- First full annual review using the Module 17 system.

**End-of-year-2 position (projection):** non-mortgage debt down to the student loan and one car loan, emergency fund at three months, retirement savings around $85,000, net worth around $185,000.

### Year 3 — Acceleration (Months 25–36)

- Emergency fund reaches six months (~$40,000) (Module 3).
- Clear the remaining car loan; attack the student loan (Module 4).
- Increase total monthly investing to $1,800 as debts fall away (Modules 5–6).
- Review the mortgage refinance question with real numbers (Module 4).
- Consider the side business or income project, with its own reserve and tax account (Module 16).
- Children open their own savings accounts and set goals (Module 12).

**End-of-year-3 position (projection):** only the mortgage and possibly the student loan remain, retirement savings around $120,000, net worth around $225,000, savings rate around 19%.

### Year 4 — Consolidation (Months 37–48)

- All non-mortgage debt cleared. Every freed payment redirects to investing (Modules 4–6).
- Savings rate reaches 20%; total monthly investing around $2,200 (Module 17).
- Review and update the estate plan and trust provisions; update legacy letters (Modules 10, 11, 14).
- Evaluate the first rental property or taxable brokerage goal using the opportunity fund (Modules 3, 6).
- Children take on a managed budget category (Module 12).

**End-of-year-4 position (projection):** retirement savings around $165,000, net worth around $275,000, zero non-mortgage debt.

### Year 5 — The System Runs Itself (Months 49–60)

- The system is now automatic: saving, investing, reviewing, meeting, giving, and teaching all run on schedule (Module 17).
- Net worth crosses $300,000; the family reviews umbrella insurance and long-term care planning as a future topic with a qualified professional (Module 9).
- The 5-year plan is replaced by a 10-year plan, written at the year-5 annual meeting, with the children's education funding and the family's retirement date as the new horizons.
- The family writes its second-generation legacy letter — a letter from the parents to the family they are becoming.

**End-of-year-5 position (projection at a 7% assumed return, 3% wage growth):** retirement savings around $215,000, home equity around $115,000 (at 3% assumed annual price growth), emergency fund at six months, net worth around $340,000. Total contributions over five years are roughly $110,000; the remainder of the growth is investment return and home appreciation. Actual results will vary.

### The Full 25-Year Picture

If the family sustains a 20% savings rate on a growing income and a 7% assumed return, the projection from Module 6 holds: roughly $1.2 million in retirement accounts alone by age 65, plus a paid-off home and an emergency reserve. At a 5% assumed return, the figure is roughly $830,000 — still life-changing, and the reason this course shows two assumptions side by side. The plan does not require a high income, a lucky stock pick, or a windfall. It requires a system, followed for 25 years, by a family that decided together what its money is for.

### Your First Seven Days

Do not wait for the perfect week. This week: day 1, calculate your net worth; day 2, hold your first money meeting and write your values statement; day 3, build your cash-flow map; day 4, open the separate emergency savings account and automate the first transfer; day 5, list your debts in avalanche order; day 6, confirm your employer matches; day 7, book the estate attorney appointment. Seven days, seven actions, and the system exists. Everything after that is maintenance.

### Action Steps — Module 18

1. Copy the 5-year roadmap into the workbook and adapt every number to your household.
2. Complete the seven first-week actions above.
3. Schedule the year-1 milestones on your calendar with dates, not intentions.
4. At the end of year 1, re-read this module and write the next five years.

---

## Appendix A — The Alvarez Family's Complete Wealth Plan, Year by Year

This appendix pulls every module together into a single 25-year plan for the Alvarez household, so you can see the whole system operating at once. Every number uses the stated assumptions from the introduction: a 7% annual investment return, 3% annual wage growth, 3% annual home price growth, and 3% inflation. Actual results will vary, and the table is an illustration, not a prediction.

### A.1 — The 25-Year Projection

The family starts at age 40 with $42,000 in retirement savings, invests $1,350 a month in year one, and increases contributions by 3% a year in line with wages. The table shows the retirement portfolio balance at each five-year mark, with the total contributed and the growth separately, so the role of compounding is visible.

| Year | Age | Annual contributions | Total contributed to date | Portfolio balance (7% assumption) | Portfolio balance (5% assumption) |
|---|---|---|---|---|---|
| 0 | 40 | — | $0 | $42,000 | $42,000 |
| 5 | 45 | $18,800 | $89,000 | $215,000 | $191,000 |
| 10 | 50 | $21,800 | $192,000 | $468,000 | $383,000 |
| 15 | 55 | $25,300 | $311,000 | $815,000 | $624,000 |
| 20 | 60 | $29,300 | $449,000 | $1,245,000 | $925,000 |
| 25 | 65 | $34,000 | $610,000 | $1,810,000 | $1,305,000 |

Read the last row carefully. At the 7% assumption, the family contributes about $610,000 over 25 years and ends with about $1,810,000 — meaning roughly $1,200,000 of the final balance is growth. At the 5% assumption, the same contributions produce about $1,305,000. The gap between the two columns is the honest range of plausible outcomes: the plan works in both, and the family should plan its retirement spending around the lower column and treat anything above it as a bonus. Note also that these figures are before taxes on withdrawals from tax-deferred accounts, before fees, and before any employer match beyond what is included in the contribution figures. Your dashboard computes the same table for your own starting balance, contribution, and assumptions.

The shape of the table is the lesson. In the first five years the balance grows by $173,000, of which $89,000 is contributions — the family is doing most of the work. In the last five years the balance grows by $565,000, of which $161,000 is contributions — the portfolio is doing most of the work. Wealth building feels slow at the start because it is slow at the start; the compounding does not announce itself until the base is large. Families that understand this table do not quit in year four.

### A.2 — Net-Worth Build-Up Table

Net worth is the family's real scoreboard, and it includes the home, the emergency fund, and the debts — not just the investment portfolio. This table tracks the Alvarez family's projected net worth at the same five-year marks, using the same assumptions, and assuming the mortgage is paid on schedule (balance falling from $285,000 to zero over 25 years at the current payment, with no extra payments) and the home appreciates at 3% a year.

| Year | Age | Home value | Mortgage balance | Home equity | Retirement portfolio | Emergency + other savings | Non-mortgage debt | Net worth |
|---|---|---|---|---|---|---|---|---|
| 0 | 40 | $375,000 | $285,000 | $90,000 | $42,000 | $6,000 | $25,000 | $127,000 |
| 5 | 45 | $435,000 | $262,000 | $173,000 | $215,000 | $40,000 | $0 | $428,000 |
| 10 | 50 | $504,000 | $232,000 | $272,000 | $468,000 | $45,000 | $0 | $785,000 |
| 15 | 55 | $584,000 | $192,000 | $392,000 | $815,000 | $50,000 | $0 | $1,257,000 |
| 20 | 60 | $677,000 | $140,000 | $537,000 | $1,245,000 | $55,000 | $0 | $1,837,000 |
| 25 | 65 | $785,000 | $0 | $785,000 | $1,810,000 | $60,000 | $0 | $2,655,000 |

Several things deserve attention. First, the non-mortgage debt reaches zero in year five and stays there — the plan's debt rules (Module 4) prevent it from returning. Second, home equity grows steadily, but it is the smaller part of the growth; the retirement portfolio is the engine. Third, the emergency fund grows modestly and then holds steady at six months of expenses, because its job is protection, not growth — money beyond six months belongs in investing. Fourth, the mortgage is paid off at year 25, which frees $1,950 a month in retirement, equivalent to about $23,400 a year of spending that no longer needs to be funded from the portfolio. That single fact — entering retirement without a mortgage — is worth more to the family's monthly freedom than a much larger portfolio with a mortgage still attached.

A caution about this table: it assumes the family stays in the same home for 25 years. Many families move, and moving resets the mortgage clock. That is not a failure — it is a choice with a cost, and the honest version of the choice is to run the table both ways before deciding. The dashboard includes a simple version of this comparison.

### A.3 — The Insurance-Needs Calculation in Full

Module 9 gave the summary. Here is the full working, so any family can replicate it. The income-replacement figure uses the present value of an annual amount: the family needs $60,000 a year for 15 years, and money held today can be assumed to earn 4% a year while it is drawn down. The present value of $60,000 a year for 15 years at 4% is about $667,000. If the family instead assumed a 3% return while drawing down, the figure would be about $716,000; at 5%, about $623,000. The workbook lets you test all three. The education fund of $80,000 assumes partial support for two children at in-state public university costs, with the children also contributing through work and savings — a deliberate choice, not an oversight. The final-expenses figure of $15,000 covers funeral costs and immediate legal and administrative expenses, based on typical current costs, and should be updated at each annual review.

For Maria's coverage, the calculation is different because her contribution is partly unpaid care. The family prices replacement childcare at $700 a month for six years (until the youngest is 18), which is $50,400, plus her $55,000 income replacement for 10 years (present value about $446,000 at 4%), plus the shared mortgage, debt, and education amounts. The total supports the $750,000 figure in Module 9. The lesson is general: insure the earner and insure the caregiver, because both contribute economic value and both are expensive to replace.

### A.4 — The Tax Buckets Over a Lifetime

Module 7 introduced the three tax buckets. Here is how the Alvarez family's buckets evolve. In year one, nearly everything is in the tax-later bucket (the 401(k)s), because the employer match lives there. By year five, the Roth IRAs (tax-never) hold about $45,000, and the family has opened a taxable brokerage account (tax-now) for the pre-retirement goal of a rental property deposit. By year fifteen, the mix is roughly 55% tax-later, 30% tax-never, and 15% tax-now. In retirement, that mix is what gives the family control: in a low-income year, they draw from the tax-later bucket up to the top of a low bracket; in a high-income year, they draw from the Roth bucket tax-free. The family that holds everything in one bucket has no such choices, and choices are worth money. The exact split depends on the tax rates in force at the time, which is why this course recommends reviewing the mix with a qualified tax professional every few years rather than setting it once and forgetting it.

### A.5 — What Can Go Wrong, and What the Plan Does About It

A plan that only works when everything goes right is not a plan. Here are the five most likely disruptions and the module that answers each:

1. **Job loss.** The emergency fund (Module 3) covers three to six months; the Roth IRA contributions can be withdrawn without penalty as a last resort; the insurance and the pause on investing are pre-agreed so the family does not have to decide under stress.
2. **A market fall of 30% or more.** The written market-drop rule (Module 5) says: keep contributing, rebalance at the annual date, and do not sell. The allocation (Module 6) limits the fall's size, and the bond allocation funds spending if retirement is near.
3. **A serious illness or disability.** Disability insurance (Module 9) replaces income; the healthcare proxy and living will (Module 10) ensure decisions are made by the right person; the emergency fund covers the waiting period.
4. **A death.** Term life insurance (Module 9) replaces income; the will, trust, and guardianship provisions (Modules 10–11) protect the children; the legacy letters (Module 14) carry the values.
5. **A family disagreement about money.** The governance system (Module 13) — the annual meeting, the roles, the decision rules, the rule that the written plan wins until the next meeting — exists precisely for this.

None of these protections is expensive relative to what it protects. The most expensive item in the list, term life insurance, costs less per month than the family's dining-out budget. That comparison is worth sitting with.

### A.6 — The One-Page Family Wealth Plan

Every family finishing this course should be able to write its plan on one page. The Alvarez family's one-page plan reads:

> **Our values:** Security first, freedom second, fun third. We leave skills and options, not just things.
> **Our numbers:** $120,000 income, $8,600 take-home, $127,000 net worth, 16% savings rate rising 1% a year.
> **Our accounts:** 401(k)s to the full match, Roth IRAs at $250/month each, emergency fund to six months, opportunity fund at $150/month.
> **Our protection:** $850,000 and $750,000 of 20-year term life, long-term disability through work plus a private policy, umbrella policy at $200,000 net worth.
> **Our documents:** Will, financial and healthcare powers of attorney, living will, testamentary trust, all beneficiaries current, all stored in the fireproof box and with the attorney.
> **Our rhythm:** Weekly money meeting, annual family wealth meeting every January, annual review day, annual rebalance on January 15.
> **Our teaching:** Three jars for the 9-year-old, a managed budget for the 12-year-old, a monthly money minute at dinner.
> **Our giving:** 2% of take-home, children direct a quarter of it.
> **Our next milestone:** Credit card gone by month 10, emergency fund at three months by month 16, net worth $200,000 by year three.

Write yours on one page, keep it where you can see it, and update it every January. A plan you can see is a plan you will follow.

## Appendix B — Answers to the Questions Families Ask Most

**"We earn less than the Alvarez family. Does this still work?"** Yes. The system is proportional: the percentages, the order of operations, and the habits are the same at $60,000 as at $120,000. The dollar amounts and the timeline change, not the method. A family earning $60,000 that saves 15% and invests it for 25 years at a 7% assumed return accumulates a life-changing sum relative to its income. Start with the starter emergency buffer and the employer match, and build from there.

**"We earn more. Do we need anything different?"** The same system, with two additions: a qualified tax professional becomes worth the fee earlier, because the tax decisions get larger; and the estate plan deserves more attention sooner, including the trust discussion in Module 11 and the business discussion in Module 16. The investing principles do not change with income.

**"What if we are starting at 50, not 40?"** The plan still works, but the levers change priority. At 50, the savings rate matters even more and the time horizon is shorter, so the allocation should already be moving toward the consolidating stage (Module 6), and the "catch-up" contributions that tax rules allow for savers over 50 become relevant — verify the current limits. The estate documents and insurance become urgent rather than important. Starting late is not starting too late; starting at 50 with a serious savings rate beats starting at 40 with a casual one that never happens.

**"Should we pay off the mortgage early or invest?"** The honest answer is that it depends on the mortgage rate, the family's tax situation, and how much the family values the certainty of a paid-off home versus the liquidity of investments. The course's default order (Module 4) is: clear high-interest debt, build the emergency fund, capture the employer match, then invest — and only then consider extra mortgage payments. A family that is five years from retirement and wants the certainty of no mortgage has a good reason to prioritize it. A family of 35 with a 4% mortgage and no emergency fund does not.

**"What about our children's college costs?"** Save for retirement first. That sounds harsh, and it is the most repeated advice in this course for a reason: there are loans for college and no loans for retirement, and a parent who sacrifices retirement for college often becomes financially dependent on the child later — the opposite of the gift intended. Fund the retirement accounts to the plan's targets first, then fund education savings with what remains, and involve the children in the college cost conversation early so they can make informed choices about schools, work, and borrowing.

**"How do we handle money disagreements with extended family?"** The family's plan is the family's business. Gifts, loans, and guarantees to relatives are decided by the two adults together, against the written plan, and never under pressure in the moment. The course's rule: never co-sign a loan, never guarantee a debt, and treat any money lent to family as a gift in your own mind — if it comes back, it is a pleasant surprise, not a plan. The legacy letter (Module 14) is the right place to explain the family's approach to relatives, kindly and once, rather than in repeated arguments.

**"Is this course enough, or do we need a professional?"** This course is education, and for many families it is enough to build the system. A qualified professional is worth engaging for: a complex tax situation, a business, a special-needs beneficiary, a large inheritance, a divorce, or any decision where the cost of being wrong exceeds the cost of advice. Think of it the way the course frames it throughout — the course teaches you how the machine works; a professional helps you operate it in your specific circumstances. Interview at least two professionals, ask how they are paid, and prefer fee-only advice over advice paid by commissions on products sold.

## Appendix C — Three More Families, Three More Plans

The Alvarez family is one example. A wealth system that only works for one household is not a system. This appendix applies the same modules to three different households, so you can find the one closest to yours and see how the plan adapts.

### C.1 — The Bennett Household: A Single Parent on $65,000

Dana Bennett, 34, earns $65,000 a year as a medical assistant and raises one child, age 7, alone. Take-home pay is about $4,500 a month. Rent is $1,400, childcare is $650, and the household's essential spending is about $3,900 a month, leaving a surplus of roughly $600 before savings. Dana has $2,000 in savings, $3,200 in credit card debt at 24% APR, a $9,000 car loan at 8%, and $8,000 in a 401(k) from a previous job that she has not touched since changing employers.

Dana's plan follows the same order of operations, at her scale. First, the employer match: her current employer matches 50% of the first 4% of pay, worth $1,300 a year — she enrolls at 4% immediately, because that match is the highest-return money available to her. Second, the credit card: she directs $300 a month to it and clears it in about 11 months, paying roughly $400 in interest rather than the $1,800-plus that minimum payments would cost over several years. Third, the starter emergency buffer of $2,000, built at $150 a month from the month the card is cleared. Fourth, term life insurance: Dana needs coverage more urgently than a two-parent household, because there is no second income to fall back on. Using the Module 9 method — income replacement of $40,000 a year for 11 years until her child is 18 (present value about $355,000 at a 4% assumed discount rate), plus $9,000 of debt, plus $30,000 for education, plus $12,000 final expenses, less $10,000 of existing savings and retirement — she needs roughly $396,000, rounded to $400,000 of 20-year term life insurance, which for a healthy 34-year-old typically costs $25–$40 a month, though actual premiums depend on underwriting.

Dana's estate documents matter more, not less, than the Alvarez family's: without a will naming a guardian, a court decides who raises her child. She names her sister as guardian and her brother as trustee, and she writes the legacy letter in the same month as the will, because her child is young enough that the letter may one day be the fullest record of who she was. Her investing is modest — $200 a month into a Roth IRA once the card is gone — and her 25-year projection at a 7% assumed return puts her retirement savings at roughly $330,000 by age 60, plus a home if she buys one in her forties using the opportunity fund she starts in year three. The numbers are smaller than the Alvarez family's, and the plan is identical in structure. The system does not care about the size of the income; it cares about the order and the consistency.

### C.2 — The Okafor Household: Dual Income on $180,000

Chidi and Adaeze Okafor, 42 and 40, earn $180,000 combined as an engineer and a nurse. Take-home pay is about $12,200 a month. Their mortgage is $420,000 on a home worth $610,000, they have $95,000 in retirement accounts, $25,000 in savings, no consumer debt, and two children aged 10 and 14. Their problem is not scarcity; it is drift. They save about $1,000 a month without a plan, spend the rest, and have never calculated their net worth or written a will.

The Okafor plan starts with the numbers: net worth about $310,000, savings rate about 8% — low for their income, and the reason they feel no richer than they did five years ago despite two pay rises. The fix is structural, not sacrificial. They raise their 401(k) contributions to 12% of pay each, capturing full matches and lifting the savings rate to about 20% without changing their lifestyle, because the money was previously drifting into unexamined spending. They automate $2,500 a month into retirement accounts, $500 into a taxable brokerage account for a pre-retirement goal, and $300 into the opportunity fund. Their emergency fund is already at three months; they top it to six months ($45,000) within a year.

Their insurance needs are larger: Chidi needs about $1.4 million of term life cover (income replacement of $100,000 a year for 15 years has a present value of about $1.11 million at a 4% assumed discount rate, plus the mortgage and education costs, less existing assets), and Adaeze about $1 million. Their estate plan includes a testamentary trust with staggered distributions at 25, 30, and 35, and a conversation with their children about the family's wealth that the Alvarez children will not have for years — because at this income level, the children will inherit a substantial sum, and the teaching in Module 12 becomes the most important module in the course for this family. Their 25-year projection at a 7% assumed return, investing $3,300 a month growing at 3% a year from a $95,000 start, reaches roughly $2.9 million in retirement accounts by age 65, and their net worth crosses $1 million around year eight. The risk for this household is not that the plan fails; it is that the household never writes it down and lets lifestyle inflation consume every pay rise. The annual review (Module 17) is their most valuable habit.

### C.3 — The Rivera Household: A Family Business on $90,000

Sofia and Miguel Rivera, 45 and 47, run a landscaping business that nets the family about $90,000 a year after business expenses, with income that varies by season — $11,000 a month in summer, $4,500 in winter. They have $60,000 in retirement savings, $15,000 in a business account, $8,000 in family savings, a $310,000 mortgage, and no consumer debt. Their children are 16 and 19; the older one works in the business in summer.

The Rivera plan is built around the variability. First, separation (Module 16): the business and family accounts are fully separated, and the business holds a six-month operating reserve of $30,000 before the family takes any distribution beyond the regular monthly draw. Second, the family draw is smoothed: instead of taking whatever the business earns each month, the owners pay themselves a flat $6,500 a month, twelve months a year, and the business account absorbs the seasonal swing. Third, taxes are handled quarterly: 25% of every business receipt goes into a separate tax account the day it arrives, so April never brings a surprise bill. Fourth, retirement saving uses the business: a solo 401(k) allows contributions as both employer and employee within the limits in force, and the family contributes $1,500 a month — more than an IRA alone would allow.

Their succession question is live, not theoretical: the 19-year-old may want the business, and the 16-year-old does not. The family holds the conversation at the annual meeting (Module 13) and writes down the principles before any transfer happens: the child who works in the business can buy in over time at a fair value set by an independent valuation; the other child receives assets of equivalent value from the family's investments and property; neither child is promised anything that is not written down. Their insurance includes key-person considerations and a buy-sell framework, because the business is the family's largest asset and its value depends heavily on Miguel. Their 25-year projection is the least certain of the three households, because business income is variable — so the plan uses a 5% assumed return for its base case and treats anything above it as a bonus, and the family's emergency fund is held at six months rather than three, specifically because of the income variability. The lesson of the Rivera household is that a variable income does not need a different system; it needs the same system with a bigger buffer and a smoother draw.

### What the Three Households Share

Different incomes, different structures, different risks — and the same six moves in the same order: calculate net worth, engineer cash flow, build the buffer, clear expensive debt, insure the catastrophic risks, and sign the documents. Then invest automatically, teach the children, hold the meetings, and review annually. The households that succeed are not the ones with the highest income; they are the ones that complete the first six moves and then repeat the last four for 25 years.

## Appendix D — Glossary, Checklists, and Where to Verify Current Rules

### D.1 — Glossary

**Asset allocation:** How a portfolio is divided among asset classes such as stocks, bonds, and cash. The largest single determinant of investment outcomes for most families.

**Beneficiary:** The person or people named to receive an account, policy, or asset when the owner dies. Beneficiary designations on retirement accounts and life insurance override a will, which is why they must be checked annually.

**Bond:** A loan an investor makes to a government or company, repaid with interest over a set period. Bonds are generally steadier than stocks and pay lower expected returns.

**Brokerage account (taxable):** An investment account without the tax advantages of a retirement account. Contributions are made with after-tax money, and investment income and gains are taxed as they occur. Flexible, with no contribution limits.

**Buy-sell agreement:** A written agreement among business partners stating what happens if a partner dies, leaves, or wants to sell — including who can buy the share and at what price.

**Compound growth:** Growth on both the original investment and the growth already earned. The force that makes long-term investing powerful and slow to start.

**Dollar-cost averaging:** Investing the same amount at regular intervals regardless of market prices. It removes timing decisions and means the family buys more shares when prices are low.

**Emergency fund:** Cash savings held for genuine emergencies, sized at three to six months of essential expenses, kept in a safe, liquid account separate from daily spending.

**Estate plan:** The set of documents — will, powers of attorney, healthcare directive, and any trust — that states who manages a person's affairs and who receives their assets if they die or become unable to decide.

**Executor:** The person named in a will to carry out its instructions, pay debts and taxes, and distribute assets.

**Expense ratio:** The annual cost of running a fund, expressed as a percentage of the assets. A fund with a 0.03% expense ratio costs $3 a year per $10,000 invested; a 1% fund costs $100.

**Fiduciary:** A person or firm legally required to act in a client's best interest. Fee-only fiduciary advisers are paid by the client, not by commissions on products sold.

**Guardian:** The person named in a will to raise minor children if both parents die. The most important decision in a young family's estate plan.

**Healthcare proxy (healthcare power of attorney):** The person named to make medical decisions for someone who cannot make them. The document that prevents relatives from disagreeing in a hospital corridor.

**Index fund:** A fund that holds a broad market index — such as the whole stock market — rather than trying to pick winners. Low cost, diversified, and the core holding recommended in this course.

**Inflation:** The general rise in prices over time, which reduces the purchasing power of money. A 3% annual inflation rate halves purchasing power in about 24 years, which is why cash alone is not a long-term wealth strategy.

**IRA (Individual Retirement Account):** A personal retirement account opened by an individual. A traditional IRA offers tax-deferred growth; a Roth IRA offers tax-free qualified withdrawals.

**Liability:** A debt or obligation — a mortgage, a loan, a credit card balance. The other half of the net-worth equation.

**Living will (advance directive):** A document stating a person's wishes about life-sustaining treatment if they cannot communicate. Distinct from a last will, which deals with property.

**Net worth:** Assets minus liabilities. The family's balance sheet and the single most honest number in family finance.

**Opportunity fund:** Savings set aside to act on a good opportunity — a course, a business, a property, a career move — rather than for emergencies.

**Power of attorney (financial):** A document naming someone to handle money and property if the person becomes unable to do so. Without it, even a spouse may need a court order.

**Present value:** What a future stream of payments is worth today, after discounting for the return money can earn in the meantime. The method used in this course to calculate life insurance needs.

**Rebalancing:** Restoring a portfolio to its target allocation by selling some of what grew and buying some of what lagged. Done annually, it forces the family to sell high and buy low.

**Roth IRA / Roth 401(k):** Retirement accounts funded with after-tax money, offering tax-free growth and tax-free qualified withdrawals in retirement.

**Savings rate:** Total saved and invested divided by total take-home pay (or gross income, stated consistently). The one number this course asks families to watch above all others.

**Sequence-of-returns risk:** The risk that poor market returns early in retirement, combined with withdrawals, permanently damage a portfolio. Managed by holding bonds or cash for near-term spending and keeping the stock allocation moderate around retirement.

**Stock:** A share of ownership in a company. Stocks offer the highest long-term expected returns of the main asset classes, with the largest year-to-year swings.

**Term life insurance:** Life insurance that covers a fixed period (commonly 10, 20, or 30 years) and pays a death benefit if the insured dies during that period. The lowest-cost way to buy a large amount of protection.

**Testamentary trust:** A trust created by a will that comes into existence at death, commonly used to hold assets for minor children and distribute them at ages chosen by the parents.

**Trust:** A legal arrangement in which a trustee holds and manages assets for beneficiaries according to instructions written by the creator of the trust.

**Trustee:** The person or institution that manages a trust's assets for the beneficiaries.

**Umbrella insurance:** Extra liability coverage, typically $1 million, that sits above home and auto policies and protects a family's assets against a large lawsuit.

**Will:** The legal document naming an executor, guardians for minor children, and who receives what after death. Without one, the state's default rules decide.

### D.2 — The Monthly Maintenance Checklist

- [ ] Update the net-worth statement on the first of the month (10 minutes).
- [ ] Confirm automatic transfers and contributions went out on payday.
- [ ] Review the spending account balance against the weekly allowance.
- [ ] Hold the 30-minute family money meeting.
- [ ] Log any irregular expense into the irregular-expense tracker.
- [ ] File any tax document, receipt, or donation record into the tax folder.

### D.3 — The Annual Maintenance Checklist

- [ ] Full annual review day (Module 17) in January.
- [ ] Rebalance the portfolio to the target allocation on January 15.
- [ ] Review insurance coverage and get fresh quotes where coverage is thin.
- [ ] Check every beneficiary designation.
- [ ] Review the will, powers of attorney, and healthcare directive — anything changed?
- [ ] Update legacy letters and record one family story.
- [ ] Recalculate the savings rate and set next year's target.
- [ ] Verify current contribution limits, tax brackets, and account rules with the relevant authorities or a qualified professional — limits change, and this course's figures are illustrations, not current law.
- [ ] Hold the annual family wealth meeting and set its date for next year.

### D.4 — Where to Verify Current Rules

Tax brackets, contribution limits, and estate rules change regularly and differ by jurisdiction. Before acting on any figure in this course, verify the current numbers from an authoritative source: the tax authority's official site for your country, your employer's plan documents for 401(k) matching and limits, your state's official site for estate and probate rules, and a qualified financial planner, tax professional, or estate attorney for advice about your own situation. This course is general education; the current rules and your personal circumstances are what determine the right decision for your family.

## Appendix E — Using the Family Wealth Dashboard

The dashboard spreadsheet included with this course is the family's command center. It is not a complicated financial model; it is four simple sheets that answer four questions, and this appendix explains how to use each one.

### E.1 — Sheet 1: Net Worth

Enter every asset and every liability once, then update the balances on the first of each month. The sheet calculates total assets, total liabilities, and net worth automatically, and charts net worth over time. The rule is to enter real balances from real statements, not estimates — an estimate that is wrong by $5,000 is worse than a blank, because it creates false confidence. If an asset is hard to value, such as a car, use a conservative resale estimate and note the source. The history matters more than any single month: a family that watches net worth rise by $2,000 a month for a year has proof the system works, and proof is what sustains motivation through the slow years.

### E.2 — Sheet 2: Monthly Cash Flow

List take-home pay at the top, every spending category below it, and the surplus at the bottom. The sheet compares actual spending against the plan each month and flags any category more than 10% over plan. The point is not to punish overspending; it is to notice it early, while the month can still be corrected, rather than discovering it in January when the year is over. Enter the irregular-expense monthly amount from Module 2 as its own line, so that the car repair in March does not look like a failure of the plan — it looks like the plan working, because the money was already set aside.

### E.3 — Sheet 3: Investment Allocation

List each investment account and fund, its balance, and its asset class. The sheet calculates the portfolio's overall stock and bond percentages and compares them with the family's target from Module 6, highlighting the gap in red when it exceeds five percentage points. At the annual rebalance date, the sheet tells the family exactly how much to move and in which direction, so the rebalance takes 30 minutes instead of an afternoon of indecision. The projection section lets the family enter its monthly contribution, starting balance, and two return assumptions — 7% and 5% in this course — and see the 10-year and 25-year outcomes side by side. Seeing both columns is the discipline: the plan should be built around the lower one.

### E.4 — Sheet 4: Goals Tracker

Every goal gets a row: the goal, the target amount, the current amount, the monthly contribution, the target date, and the percentage complete. The Alvarez family's goals are pre-filled as examples — emergency fund to $40,000, Roth IRAs funded, credit card at zero, net worth $200,000 by year three — and the family replaces them with its own. A goal that is not on the tracker does not exist; a goal on the tracker with a monthly contribution and a date is a plan. Review the tracker at the monthly money meeting and the annual review, and celebrate each goal that reaches 100% before moving on to the next one.

### E.5 — Keeping the Dashboard Alive

A dashboard that is updated monthly for a year and then abandoned is a common story. Three habits prevent it: keep the update to 15 minutes by using real statements and not chasing perfection; keep the file in one place both adults can reach; and review it together at the money meeting, so it belongs to the family rather than to one person. If the dashboard ever feels like a burden, simplify it — delete a sheet, track fewer categories, round to the nearest $100. A simple dashboard that is used beats a detailed dashboard that is abandoned. The dashboard is a tool, not a test.

## Appendix F — How This Manual Is Organized

This manual contains the complete 18-module course in written form. Each module is a chapter of the same number and title, and the workbook exercise for a module is designed to be completed in the same week as its module. The written format gives you what a lecture cannot: tables you can return to, checklists you can print, and projections you can re-run with your own numbers.

The recommended pace is one module per week for 18 weeks, with the appendix material read alongside Modules 17 and 18. Families who prefer a faster pace can complete two modules a week, but should not skip the workbook exercises — the course's value is in the documents and accounts it produces, not in the hours spent reading. By the end of the 18 weeks, a family should have: a written net-worth statement and cash-flow map; an emergency fund on its way to three months; a debt payoff plan in motion; retirement contributions capturing the full employer match; term life insurance in force; signed estate documents; a first annual family wealth meeting held; and a first legacy letter written. Those eight outcomes are the course's definition of success, and they are all measurable. If you have them, the course has done its job — and the next 25 years are maintenance.

A final note on assumptions: every projection in this course states its assumptions in the text beside it, and the dashboard lets you change them. If you believe a 7% long-term return is too optimistic for your planning, use 5% or 4% and build the plan around that figure — a plan that works at a lower assumed return is a stronger plan, and a family that saves a little more because it planned conservatively is a family with a margin of safety. Similarly, if your wage growth is slower than 3% or your housing costs rise faster, enter your real numbers and let the plan reflect your life rather than the Alvarez family's. The Alvarez numbers are an illustration of the method, not a prescription for your household. Your own numbers, entered honestly and completely into the same structure, are what make this course yours — and the habit of revisiting them every January is what keeps the plan honest for decades to come for your whole family.

## Closing Note

Wealth that lasts a generation is not built in a single decision. It is built in a thousand small ones, made by a family that knows what its money is for, protects what it builds, teaches the next generation, and writes down what matters. The system in this course is ordinary on purpose: save automatically, invest in low-cost diversified funds, insure the risks that could destroy the plan, sign the documents, hold the meetings, and write the letters. Ordinary, repeated for 25 years, becomes extraordinary. Start this week.

---

*This course is general education only. It is not individualized financial, legal, tax, or investment advice. Consult a qualified professional for advice about your own situation. All projections use stated assumptions and actual results will vary.*

