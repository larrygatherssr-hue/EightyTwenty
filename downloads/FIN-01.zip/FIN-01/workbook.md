# The Generational Wealth Blueprint — Workbook

## Companion Workbook to the 18-Module Masterclass

**SKU:** FIN-01 | **Product:** The Generational Wealth Blueprint

> **Disclaimer:** This workbook is general education only. It is not individualized financial, legal, tax, or investment advice. The exercises ask you to record your own numbers and make your own decisions; consult a qualified financial planner, tax professional, or estate attorney for advice about your own situation. Any projections you calculate use assumptions you choose, and actual results will vary. No outcome is guaranteed.

## How to Use This Workbook

Complete one section per module, in the same week you watch the module. Work in pencil or in a copy of the file — you will update these pages every year. Keep the finished workbook with your estate documents and your family record. Estimated time per section: 20–45 minutes.

**A note on honesty:** these exercises only work with real numbers. An estimated net worth or a guessed spending figure will produce a plan for a household that does not exist. Take the extra ten minutes to look up the real balances. The discomfort of seeing the true numbers lasts an afternoon; the value of a plan built on them lasts for decades. If a section feels hard to complete, that is information, not failure — it tells you exactly where the plan needs the most attention first.

---

## Exercise 1 — Net-Worth Statement (Module 1)

List everything your household owns and owes. Use real balances from real statements.

**Assets**

| Asset | Value |
|---|---|
| Home (estimated value) | $__________ |
| Retirement accounts (401(k), IRA) | $__________ |
| Savings accounts | $__________ |
| Investment / brokerage accounts | $__________ |
| Vehicles (resale value) | $__________ |
| Business value (if any) | $__________ |
| Other assets | $__________ |
| **Total assets** | **$__________** |

**Liabilities**

| Liability | Balance |
|---|---|
| Mortgage | $__________ |
| Credit cards | $__________ |
| Student loans | $__________ |
| Car loans | $__________ |
| Other loans | $__________ |
| **Total liabilities** | **$__________** |

**Net worth (assets − liabilities): $__________**

Date completed: __________. Next update (1st of next month): __________.

**Your values statement.** In three sentences, what is money for in your household?

1. ________________________________________________________________________
2. ________________________________________________________________________
3. ________________________________________________________________________

**Your four levers.** One way to earn more: ______________________________. One spending category to reduce: ______________________________. Your time horizon (years to retirement): ______. Your planning return assumption: ______%.

---

## Exercise 2 — Cash-Flow Map (Module 2)

Record last month's actual income and spending from bank and card statements. Do not estimate.

| Category | Planned | Actual | Difference |
|---|---|---|---|
| Take-home pay | $ | $ | $ |
| Housing (mortgage/rent, tax, insurance) | $ | $ | $ |
| Utilities and phones | $ | $ | $ |
| Food and household | $ | $ | $ |
| Transport | $ | $ | $ |
| Childcare / school | $ | $ | $ |
| Health insurance / medical | $ | $ | $ |
| Clothing / personal | $ | $ | $ |
| Entertainment / dining | $ | $ | $ |
| Subscriptions | $ | $ | $ |
| Debt minimum payments | $ | $ | $ |
| Savings / investing (automated) | $ | $ | $ |
| **Total out** | **$** | **$** | **$** |
| **Monthly surplus / shortfall** | | **$** | |

**Your $500.** One renegotiation (what, and how much it saves): ______________________________ $______/month. One food-system change: ______________________________ $______/month. One pause or cap: ______________________________ $______/month. Total found: $______/month.

**Irregular expenses.** List last year's irregular costs, total them, divide by 12: total $__________ ÷ 12 = $__________ per month to set aside.

**Automation set up:** Emergency fund transfer $______ on the ______ of the month. Retirement contribution ______%. Roth IRA $______/month. Opportunity fund $______/month.

---

## Exercise 3 — Emergency and Opportunity Funds (Module 3)

Essential monthly expenses: $__________. Three-month target: $__________. Six-month target: $__________. Current balance: $__________. Monthly contribution: $__________. Date you will reach three months: __________.

**What counts as an emergency in our household?** Write your definition: ________________________________________________________________________

**Opportunity fund.** Monthly amount: $__________. First opportunity you are saving toward: ______________________________.

---

## Exercise 4 — Debt Payoff Plan (Module 4)

| Debt | Balance | Interest rate | Minimum payment | Payoff order | Target payoff date |
|---|---|---|---|---|---|
| | $ | % | $ | | |
| | $ | % | $ | | |
| | $ | % | $ | | |
| | $ | % | $ | | |
| **Total** | **$** | | **$** | | |

**Our four debt rules** (write them in your own words and post them visibly):

1. ________________________________________________________________________
2. ________________________________________________________________________
3. ________________________________________________________________________
4. ________________________________________________________________________

Did you call each lender to ask about a rate reduction or autopay discount? Yes / No. Result: ______________________________.

---

## Exercise 5 — Investment Check (Modules 5–6)

Employer 401(k) match: ______% of pay, worth $__________ per year. Am I capturing the full match? Yes / No. If no, the fix and the date: ______________________________.

**Every account and fund I own:**

| Account | Fund | Balance | Annual cost (expense ratio) |
|---|---|---|---|
| | | $ | % |
| | | $ | % |
| | | $ | % |

**My target allocation:** Stocks ______% (domestic ______%, international ______%), Bonds ______%. Reason: ______________________________.

**My market-drop rule** (one sentence): ________________________________________________________________________

**Annual rebalance date:** __________ (same date every year).

---

## Exercise 6 — Insurance-Needs Worksheet (Module 9)

Complete one column per adult earner.

| Need | Adult 1: __________ | Adult 2: __________ |
|---|---|---|
| Income replacement (annual amount × years, present value at 4% assumed) | $ | $ |
| Pay off mortgage | $ | $ |
| Pay off other debts | $ | $ |
| Children's education fund | $ | $ |
| Final expenses | $ | $ |
| **Total needs** | **$** | **$** |
| Less: existing savings and retirement | −$ | −$ |
| Less: existing life insurance | −$ | −$ |
| **Additional life insurance needed** | **$** | **$** |

Term life insurance in force: Adult 1 $__________ (______-year term). Adult 2 $__________ (______-year term). Quotes requested from at least three insurers? Yes / No.

Disability coverage: employer long-term disability replaces ______% of pay after a ______-day waiting period. Gap filled? Yes / No / Not needed because: ______________________________.

Umbrella policy: in force / quoted / not yet needed (net worth $__________; review when it passes $200,000).

---

## Exercise 7 — Estate-Document Checklist (Module 10)

| Document | Done? | Date signed | Location | Next review |
|---|---|---|---|---|
| Will | ☐ | | | |
| Guardian named (+ alternate) | ☐ | | | |
| Guardian informed in person | ☐ | | | |
| Durable financial power of attorney | ☐ | | | |
| Healthcare power of attorney | ☐ | | | |
| Living will / advance directive | ☐ | | | |
| Testamentary trust (Module 11) | ☐ | | | |
| Beneficiaries checked: 401(k) | ☐ | | | |
| Beneficiaries checked: IRA | ☐ | | | |
| Beneficiaries checked: life insurance | ☐ | | | |
| Beneficiaries checked: bank accounts | ☐ | | | |
| Digital asset list compiled | ☐ | | | |
| Executor told where documents live | ☐ | | | |

Attorney appointment booked for: __________. Attorney name and contact: ______________________________.

---

## Exercise 8 — Family Meeting Agenda (Module 13)

Use this agenda for the annual family wealth meeting. Date: __________. Attendees: ______________________________.

1. Review the net-worth statement and this year's progress.
2. Review the investment allocation; rebalance if needed.
3. Review insurance and estate documents — anything changed?
4. Review the children's money education.
5. One decision about the coming year: ______________________________.
6. Legacy conversation — one family story, told by: ______________________________.

**Family roles:** Financial lead: __________. Records keeper: __________. Estate contact: __________. Next-generation lead: __________.

**Decision rules for spending above $1,000:** (1) wait 72 hours; (2) both adults agree; (3) write down the reason and review it at the next annual meeting.

---

## Exercise 9 — Legacy Letter Prompts (Module 14)

Answer each prompt in a few sentences. Your answers become your first legacy letter.

1. Our family's story — where we came from: ________________________________________________________________________
2. What money meant in my childhood: ________________________________________________________________________
3. The hardest money decision I made, and what it taught me: ________________________________________________________________________
4. The three values I most want to pass on: ________________________________________________________________________
5. What I hope for each child: ________________________________________________________________________
6. What I am grateful for: ________________________________________________________________________
7. One request I make of the reader: ________________________________________________________________________

Date the letter was written: __________. Stored with: ______________________________.

---

## Exercise 10 — Annual Review Checklist (Module 17)

Complete every January.

- [ ] Net-worth statement updated; this year vs. last year: $__________ → $__________.
- [ ] Savings rate calculated: total saved $__________ ÷ take-home pay $__________ = ______%.
- [ ] Portfolio rebalanced on January 15 to the target allocation.
- [ ] Insurance reviewed; changes needed: ______________________________.
- [ ] Beneficiaries checked and current.
- [ ] Estate documents reviewed; changes needed: ______________________________.
- [ ] Tax folder complete; withholding checked.
- [ ] Legacy letters updated; one family story recorded.
- [ ] Next year's savings target: ______%. One learning goal: ______________________________. One family goal: ______________________________.
- [ ] Plan changes this year (with reason and date): ______________________________.
- [ ] Annual family wealth meeting date for next year: __________.

---

## Exercise 11 — Your 5-Year Roadmap (Module 18)

Copy the course roadmap and adapt it. Write one milestone per year, with a date.

**Year 1:** ________________________________________________________________________
**Year 2:** ________________________________________________________________________
**Year 3:** ________________________________________________________________________
**Year 4:** ________________________________________________________________________
**Year 5:** ________________________________________________________________________

**My first seven days:** Day 1 — net worth. Day 2 — money meeting and values statement. Day 3 — cash-flow map. Day 4 — emergency account opened and automated. Day 5 — debts listed in payoff order. Day 6 — employer matches confirmed. Day 7 — estate attorney appointment booked.

---

## Exercise 12 — Children's Money Curriculum Tracker (Module 12)

One row per child. Update at the annual family wealth meeting.

| Child | Age | Current stage | Allowance / budget | Savings goal | Savings balance | Next step |
|---|---|---|---|---|---|---|
| | | Spend / save / give jars | $______/week | | $ | |
| | | Managed monthly budget | $______/month | | $ | |
| | | Earning + checking account | $______/month | | $ | |

**Monthly money minute topics covered this year:** (1) ______________________________ (2) ______________________________ (3) ______________________________ (4) ______________________________ (5) ______________________________ (6) ______________________________

**Age milestones planned:** First savings account at age ______. First managed budget at age ______. First earned income and tax return at age ______. First investment account at age ______. Full family plan shared at age ______.

**A money mistake I named out loud this year, so my children could learn from it:** ________________________________________________________________________

## Exercise 13 — Giving Plan (Module 15)

Giving budget: ______% of take-home pay = $__________ per month.

| Cause | Monthly amount | Why this cause matters to us |
|---|---|---|
| | $ | |
| | $ | |
| | $ | |
| Children's choice (directed by the children) | $ | |

Donation receipts filed in the tax folder? Yes / No. Volunteer day scheduled: __________ (one per quarter, chosen by the children in rotation).

## Exercise 14 — My One-Page Family Wealth Plan (Appendix A)

Copy your completed one-page plan here, and update it every January.

**Our values:** ________________________________________________________________________
**Our numbers:** Income $__________, take-home $__________, net worth $__________, savings rate ______%.
**Our accounts:** ________________________________________________________________________
**Our protection:** ________________________________________________________________________
**Our documents:** ________________________________________________________________________
**Our rhythm:** ________________________________________________________________________
**Our teaching:** ________________________________________________________________________
**Our giving:** ________________________________________________________________________
**Our next milestone:** ________________________________________________________________________

*This workbook is general education only. It is not individualized financial, legal, tax, or investment advice. Consult a qualified professional for advice about your own situation.*
