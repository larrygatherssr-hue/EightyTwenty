# The Generational Wealth Blueprint — Product Index

**SKU:** FIN-01 | **Category:** Finance & Wealth Building | **Price:** $1,497 (one-time) | **Tier:** Elite (flagship)

Build wealth that outlives you — a complete family system for earning, investing, and passing it on.

## Files in This Product

| File | What it is |
|---|---|
| `content.md` | The complete 18-module masterclass text (20,000+ words): family financial foundations, cash-flow engineering, emergency and opportunity funds, debt strategy, investing fundamentals, asset allocation, tax-aware planning, retirement accounts, insurance, estate documents, trusts, teaching children about money, family governance, legacy letters, charitable giving, business-owning families, the annual review system, and the 5-year implementation roadmap — plus appendices with a 25-year year-by-year projection, net-worth build-up table, three additional family case studies, a glossary, checklists, and a dashboard guide. |
| `workbook.md` | Companion workbook (14 exercises): net-worth statement, cash-flow map, emergency fund planner, debt payoff plan, investment check, insurance-needs worksheet, estate-document checklist, family meeting agenda, legacy letter prompts, annual review checklist, children's money curriculum tracker, giving plan, 5-year roadmap, and one-page family wealth plan. |
| `templates/family-wealth-dashboard.csv` | Family wealth dashboard spreadsheet: net worth, monthly cash flow, investment allocation, and goals tracker, pre-filled with the Alvarez family's example numbers. |
| `templates/legacy-letter-template.md` | Structured legacy letter template with seven guided sections and prompts. |
| `templates/family-meeting-agenda.md` | Complete agenda for the annual family wealth meeting, with preparation checklist and action-item tracker. |
| `sales-page.md` | Sales page copy: headline, problem, solution, full module list, who it is for / not for, price and guarantee, FAQ, and disclaimers. |
| `listing.json` | Marketplace listing data (SKU, name, category, price in cents, headline, description, delivery note, SEO keywords, refund policy, support). |
| `cover.md` | Cover design brief (black-and-gold luxury branding, typography, imagery, layout). |
| `cover.png` | Product cover image (1280×1920, generated from the brief). |
| `onboarding.md` | Buyer onboarding guide: what to do first, how to use the materials, suggested 12-week schedule, and how to get support. |

## Disclaimer

This product is general education only. It is not individualized financial, legal, tax, or investment advice. All projections use stated assumptions and actual results will vary. Consult a qualified professional for advice about your own situation.
