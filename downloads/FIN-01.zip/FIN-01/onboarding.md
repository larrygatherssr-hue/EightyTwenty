# Welcome to The Generational Wealth Blueprint

Thank you for purchasing the flagship course of the EightyTwenty marketplace. This guide tells you what to do first, how to use the materials, and how to get support.

## What You Received

- **content.md** — the complete 18-module masterclass text (20,000+ words), including worked examples with real numbers, a 25-year year-by-year projection, three additional family case studies, a glossary, and maintenance checklists. This is the complete written course manual.
- **workbook.md** — the companion workbook with 14 exercises: net-worth statement, cash-flow map, insurance-needs worksheet, estate-document checklist, family meeting agenda, legacy letter prompts, annual review checklist, and your 5-year roadmap.
- **templates/family-wealth-dashboard.csv** — the family wealth dashboard spreadsheet (net worth, monthly cash flow, investment allocation, goals tracker), pre-filled with the Alvarez family's example numbers.
- **templates/legacy-letter-template.md** — structured prompts for writing your first legacy letter.
- **templates/family-meeting-agenda.md** — the complete agenda for the annual family wealth meeting.
- **cover.png** — the product cover image (black-and-gold luxury branding).

## What to Do First

Do these five things in your first week — they take a few hours in total and they create the foundation everything else builds on:

1. **Read Module 1 and complete Workbook Exercise 1.** Calculate your household net worth and write your one-page values statement. If you can only do one thing this week, do this.
2. **Hold your first 30-minute family money meeting.** Pick a recurring time (Sunday evening works well) and put it on the calendar. Use the fixed agenda in Module 1.
3. **Build your cash-flow map (Module 2, Workbook Exercise 2).** Use real bank statements, not estimates, and set up your first automatic transfer to savings for the day after payday.
4. **Open the dashboard spreadsheet** and replace the Alvarez example numbers with your own. Save a copy with today's date so you can see progress over time.
5. **Book the estate attorney appointment** (Module 10). Even if the appointment is weeks away, booking it now makes the estate documents real instead of theoretical.

## How to Use the Materials

The recommended pace is **one module per week for 18 weeks**, completing the matching workbook exercise in the same week. Each module ends with action steps — do them before moving on, because the course's value is in the documents and accounts it produces, not the hours watched.

Work through the modules in order. The system is sequenced deliberately: foundations and cash flow first, then the emergency fund, then debt, then investing, then protection and estate documents. Skipping ahead to investing before the emergency fund and debt plan are in place is the most common way families undermine their own plan.

Keep the workbook with your estate documents and your family record, and update it every year at the annual review (Module 17). The dashboard should be updated on the first of every month — fifteen minutes with real statements.

## Suggested 12-Week Schedule

The 18-module course runs 18 weeks at one module a week. If you want a faster start, here is a 12-week accelerated schedule that covers the foundations and protection first, then the legacy and planning modules:

| Week | Modules | Workbook exercises | Milestone |
|---|---|---|---|
| 1 | 1–2: Foundations, Cash Flow | 1–2 | Net worth calculated; first money meeting held |
| 2 | 3–4: Emergency Funds, Debt | 3–4 | Emergency account opened; debts listed in payoff order |
| 3 | 5–6: Investing, Allocation | 5 | Employer match confirmed; target allocation chosen |
| 4 | 7–8: Tax Planning, Retirement | 5 (continued) | Tax buckets listed; Roth IRAs opened |
| 5 | 9: Insurance | 6 | Insurance-needs worksheet complete; quotes requested |
| 6 | 10–11: Estate Documents, Trusts | 7 | Attorney appointment held; documents signed or in progress |
| 7 | 12: Teaching Children | 12 | Three jars or managed budgets set up; first money minute held |
| 8 | 13–14: Governance, Legacy Letters | 8–9 | First legacy letter written; roles assigned |
| 9 | 15–16: Giving, Business Families | 13 | Giving budget set; business accounts separated if applicable |
| 10 | 17: Annual Review System | 10 | Annual review day scheduled; savings rate calculated |
| 11 | 18: 5-Year Roadmap | 11, 14 | One-page plan written; milestones calendared |
| 12 | Review week | All | Revisit any incomplete exercise; hold the first annual family wealth meeting |

After week 12, the system runs on its rhythm: weekly money meetings, monthly dashboard updates, and the annual review day each January.

## A Note on the Numbers

Every projection in this course states its assumptions — such as a 7% annual investment return — beside the number, and actual results will vary. The dashboard lets you test lower assumptions (5% or 4%) so you can build your plan around a conservative outcome. Tax brackets, contribution limits, and estate rules change over time and differ by jurisdiction; verify current figures with the relevant authorities or a qualified professional before acting on them.

## How to Get Support

For help with your order or the course files, email the marketplace support address with your order number and a description of the issue, and the support team will respond. For questions about your personal financial, legal, or tax situation, consult a qualified financial planner, tax professional, or estate attorney — this course is general education, not individualized advice.

## Your First Seven Days

Day 1: calculate your net worth. Day 2: hold your first money meeting and write your values statement. Day 3: build your cash-flow map. Day 4: open the separate emergency savings account and automate the first transfer. Day 5: list your debts in payoff order. Day 6: confirm your employer matches. Day 7: book the estate attorney appointment. Seven days, seven actions, and the system exists. Everything after that is maintenance.
