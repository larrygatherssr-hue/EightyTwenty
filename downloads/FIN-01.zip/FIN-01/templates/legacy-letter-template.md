# Legacy Letter Template

## A Letter to the People I Love Most

*This is a personal document, not a legal one. It does not replace a will. Write it in your own voice, in plain language. Two pages, finished, beats twenty pages, unwritten. Update it every few years and share an extract at the annual family wealth meeting.*

**From:** ______________________________

**To:** ______________________________

**Date written:** ______________

---

## 1. Our Family's Story

Where did our family come from? What should the reader know about the people and places that shaped us?

*(Example: "Your grandmother came to this city with one suitcase and a nursing qualification. She worked nights for ten years so your grandfather could finish his training. Everything we have starts with that decade.")*

Write here:

________________________________________________________________________
________________________________________________________________________
________________________________________________________________________

## 2. What Money Meant in My Childhood

What did money feel like when you were growing up? Was it scarce, comfortable, frightening, or never discussed? What did you learn — good or bad — from watching the adults around you handle money?

Write here:

________________________________________________________________________
________________________________________________________________________
________________________________________________________________________

## 3. The Hardest Money Decision I Made

Name one difficult money decision, what it cost, and what it taught you. Specific stories are remembered; general advice is forgotten.

Write here:

________________________________________________________________________
________________________________________________________________________
________________________________________________________________________

## 4. The Three Values I Most Want to Pass On

Name three values, and give one short example of each in action.

1. Value: ______________________________ Example: ______________________________

2. Value: ______________________________ Example: ______________________________

3. Value: ______________________________ Example: ______________________________

## 5. What I Hope for Each Child

Not a career prescription — a hope. Name each child and write one or two sentences for each.

Write here:

________________________________________________________________________
________________________________________________________________________
________________________________________________________________________

## 6. What I Am Grateful For

Name the people, the chances, and the ordinary days you are grateful for.

Write here:

________________________________________________________________________
________________________________________________________________________
________________________________________________________________________

## 7. One Request

Something you ask of the reader. Examples: "Take care of each other." "Keep the annual family meeting going." "Use what we leave you to build a life you are proud of, not to keep score."

Write here:

________________________________________________________________________
________________________________________________________________________

---

## Closing

A final sentence in your own words.

________________________________________________________________________

**Signed:** ______________________________

---

*Store this letter with your estate documents and in the family record. Tell your executor where it is. A copy may also be held by a trusted family member. Review and update it every three years and after every major life event.*
