# Annual Family Wealth Meeting — Agenda

**Family:** ______________________________

**Date:** ______________ **Time:** ______________ **Location:** ______________

**Attendees:** ______________________________

**Duration:** Two hours. Children old enough to understand attend for items 1, 4, and 6.

---

## Before the Meeting

- [ ] Financial lead updates the net-worth statement and the family wealth dashboard.
- [ ] Records keeper confirms insurance policies, estate documents, and beneficiary designations are current.
- [ ] Each adult writes down one decision they would like the family to make this year.
- [ ] The next-generation lead (oldest child, or a rotating role) prepares a short report on the children's savings goals.

---

## Agenda

### 1. Review the Numbers (30 minutes)

- Net worth this year: $__________ (last year: $__________; change: $__________).
- Savings rate this year: ______% (target was ______%).
- Investment portfolio: balance $__________, allocation stocks ______% / bonds ______% (target: ______% / ______%).
- Emergency fund: $__________ (target: $__________).
- Debts: remaining balances and payoff progress.
- **Discussion:** What went well? What surprised us? What do we want to change?

### 2. Review Protection (20 minutes)

- Life insurance: still adequate? Any new child, new home, new debt, or new job since last year?
- Disability coverage: still in force? Any change at work?
- Home and auto insurance: liability limits reviewed?
- Estate documents: will, powers of attorney, healthcare directive, trust — anything changed?
- Beneficiaries: checked and current on every account and policy?

### 3. Review the Children's Money Education (15 minutes)

- Each child's savings goal and balance.
- Money minutes held this year: topics covered.
- Children's share of the giving budget: what they chose and what happened.
- Next step for each child this year.

### 4. One Decision for the Coming Year (20 minutes)

The decision on the table: ______________________________

Options considered: ______________________________

Decision made: ______________________________

Who does what, by when: ______________________________

### 5. Giving Review (10 minutes)

- Total given this year: $__________.
- Causes supported: ______________________________.
- Causes for next year: ______________________________.

### 6. Legacy Conversation (15 minutes)

- One family story, told by: ______________________________.
- Extract from a legacy letter, read aloud by: ______________________________.
- One story to record this year (audio or video): ______________________________.

### 7. Close (10 minutes)

- Next year's meeting date (same weekend next year): ______________.
- Roles for next year: Financial lead: __________. Records keeper: __________. Estate contact: __________. Next-generation lead: __________.
- One thing each person is proud of this year: ______________________________.

---

## Notes and Action Items

| Action | Owner | Due date | Done |
|---|---|---|---|
| | | | ☐ |
| | | | ☐ |
| | | | ☐ |
| | | | ☐ |

---

*File these notes in the family record with the net-worth statement and the legacy letters. The meeting is scheduled a year in advance, on the same weekend every year, and is treated as immovable as a holiday.*
