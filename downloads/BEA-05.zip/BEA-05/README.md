# BEA-05 — Skin Science & Signature Routines: Evidence-Based Skincare Education

**Price:** $397 (one-time) | **Category:** Beauty & Health | **SKU:** BEA-05

An evidence-based skincare education course for beauty professionals, skincare enthusiasts, and new estheticians: skin anatomy and the barrier, honest skin-type assessment, ingredient science, sun protection, routine architecture, and six fully worked routine builds — plus a workbook, a 134-ingredient decoder, and reusable client templates.

**Education only.** No medical advice, diagnosis, or treatment claims. Patch-test all new products. For persistent or worsening skin problems, consult a qualified dermatologist or doctor.

## Files

| File | What it is |
|---|---|
| `content.md` | The full course — all 9 modules, glossary, further reading, final checklist (~18,500 words) |
| `workbook.md` | Companion workbook — 9 exercises, tracking logs, checklists, referral red-flag reference |
| `templates/ingredient-decoder.csv` | 134-ingredient decoder: function, evidence level, irritation risk, best skin types, cautions |
| `templates/routine-builder-worksheet.md` | Reusable worksheet for building a routine for any client or profile |
| `templates/client-consultation-form.md` | Complete consultation form: history, routine, observation, plan, referral, consent |
| `sales-page.md` | Full sales page: headline, problem, solution, module list, who it is for / not for, FAQ, disclaimers |
| `listing.json` | Marketplace listing data (SKU BEA-05, price 39700 cents, billing one_time) |
| `cover.png` | Course cover image — black-and-gold luxury design (1120 × 2240 px) |
| `cover.md` | Cover design brief (palette, typography, imagery, layout) |
| `onboarding.md` | Customer onboarding guide (first steps, how to use the materials, 9-week schedule) |
| `README.md` | This index |
