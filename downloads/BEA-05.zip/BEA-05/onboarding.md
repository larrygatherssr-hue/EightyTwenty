# Customer Onboarding Guide — BEA-05

**Skin Science & Signature Routines: Evidence-Based Skincare Education**

Welcome. This guide tells you what to do first, how to use the materials, and how to get the most from the course in your first month.

---

## What you received

| File | What it is |
|---|---|
| `content.md` | The full course — all 9 modules, glossary, further reading, and final checklist |
| `workbook.md` | Companion workbook — 9 exercises, tracking logs, and checklists |
| `templates/ingredient-decoder.csv` | 134-ingredient decoder (function, evidence, irritation risk, skin-type fit) |
| `templates/routine-builder-worksheet.md` | Reusable worksheet for building a routine for any client or profile |
| `templates/client-consultation-form.md` | Complete consultation form, including referral and consent sections |
| `cover.png` | Course cover image (black-and-gold luxury design) |
| `sales-page.md` | The full sales page for reference |
| `onboarding.md` | This guide |
| `README.md` | File index |

All files are in Markdown (`.md`) or CSV format. They open on any device — phone, tablet, or computer — and can be printed. No special software is required. The CSV opens in any spreadsheet app (Excel, Google Sheets, Numbers, LibreOffice).

---

## What to do first (Day 1)

1. **Read the note at the top of `content.md`.** It states the scope of the course: education only, no medical advice, no diagnosis, no treatment claims. Everything in the course follows from that.
2. **Skim the table of contents.** Get a sense of the nine modules and where the reference material sits (the ingredient comparison table in Module 4, the six routine builds in Module 7, the referral red flags in Module 8).
3. **Save the files somewhere you can find them again.** Keep the folder intact — the workbook exercises refer to the templates by name.
4. **Do not buy any new products yet.** The course is designed to be studied before you change a routine. Read first, buy later.

## How to use the materials

- **Study in order the first time.** Modules build on each other: the barrier (Module 1) explains the ingredient advice (Modules 3–4), which explains the routine builds (Module 7).
- **Do the workbook exercise as you finish each module.** The exercises are short and practical — assessing your own skin, reading real labels, comparing sunscreens. They are where the learning becomes a skill.
- **Use the ingredient decoder as a reference, not a textbook.** When you meet an ingredient you do not know, look it up in the CSV. Filter by category or search by name. Add your own notes as you learn.
- **Use the templates with real people.** The routine-builder worksheet and the consultation form are designed to be printed or copied and used with clients. One copy per client, per consultation.
- **Revisit Module 7 whenever you meet a new skin profile.** The six builds are starting points with clear reasoning, so you can adapt them rather than memorise them.

## Suggested schedule

**Nine-week pace (recommended):**

| Week | Module | Workbook exercise | Time |
|---|---|---|---|
| 1 | Module 1 — Skin Anatomy and the Barrier | Exercise 1.1 | 60–90 min + 30 min |
| 2 | Module 2 — Skin Types and Assessment | Exercise 2.1 | 60–90 min + 45 min |
| 3 | Module 3 — Ingredient Science I | Exercise 3.1 | 60–90 min + 45 min |
| 4 | Module 4 — Ingredient Science II | Exercise 4.1 | 90 min + 45 min |
| 5 | Module 5 — Sun Protection | Exercise 5.1 | 60 min + 45 min |
| 6 | Module 6 — Routine Architecture | Exercise 6.1 (start your 2-week baseline) | 60–90 min + 30 min |
| 7 | Module 7 — Six Skin Profiles | Exercise 7.1 | 90 min + 60 min |
| 8 | Module 8 — The Client Consultation | Exercise 8.1 (practice consultation) | 60–90 min + 45 min |
| 9 | Module 9 — Troubleshooting, Myths, Trends | Exercise 9.1 + final checklist | 60–90 min + 30 min |

**Intensive pace:** one module every two to three days, completing the workbook exercise the same day. Do not skip the two-week baseline in Exercise 6.1 — it is a real test on your own skin, and it cannot be rushed.

## Your first 30 days

- **Days 1–7:** Read Modules 1–2 and complete Exercises 1.1 and 2.1. Assess your own skin.
- **Days 8–14:** Read Modules 3–4 and complete Exercises 3.1 and 4.1. Start using the ingredient decoder.
- **Days 15–21:** Read Modules 5–6, start your baseline routine (Exercise 6.1), and find a sunscreen you will wear every day.
- **Days 22–30:** Read Modules 7–9, build two routines (Exercise 7.1), and do one practice consultation (Exercise 8.1). Identify a local dermatologist or clinic for referrals and keep their details on file.

## Common questions

**Can I print the materials?** Yes. All files are designed to be printed. The workbook and templates are the most useful in print.

**Can I use the templates with my clients?** Yes. Print or copy them and adapt them for your practice. You may not resell or redistribute the course files themselves.

**What if I have a question about the materials?** Contact support through the EightyTwenty marketplace using the order number from your purchase confirmation.

**What if I or a client has a skin problem that worries me?** Consult a qualified dermatologist or doctor. The course teaches you when to refer (Module 8.5) and includes a referral red-flag quick reference in the workbook. Support cannot give medical advice or diagnose a skin condition.

## A final note

The most valuable thing in this course is not any single product recommendation — it is the method: assess honestly, fix the baseline first, add one thing at a time, set honest timelines, and refer when something is outside your scope. Learn the method, and you can build a routine for any skin you meet.

---

*Skin Science & Signature Routines (BEA-05). Education only — not medical advice. Patch-test all new products. Individual results vary.*
