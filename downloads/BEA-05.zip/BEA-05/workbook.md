# Skin Science & Signature Routines — Companion Workbook

**BEA-05 — Use alongside `content.md`.**

This workbook turns the course into practice. Complete the exercises as you work through each module — do not leave them all to the end. Print the worksheets, or copy them into a notebook or digital document. There are no right answers to memorise here; the value is in doing the assessment, reading the labels, and building the routines yourself.

*Education only. This workbook does not diagnose, treat, or cure any skin condition. Patch-test all new products. If a skin problem persists or worsens, consult a qualified dermatologist or doctor.*

---

## Exercise 1.1 — Explain the Barrier in Plain Language (Module 1)

Write a one-paragraph explanation of the skin barrier for a client who says their skin "stings when I put anything on it." Do not use the words "stratum corneum," "TEWL," or "corneocyte."

Your paragraph:

> _Write here._

Now check your paragraph against this list:

- [ ] It uses an everyday comparison (a wall, a shield, a roof) a non-expert can picture.
- [ ] It explains why the skin stings, in one sentence.
- [ ] It says what will help, without naming a specific product or brand.
- [ ] It contains no medical diagnosis and no promise of a cure.
- [ ] A friend with no skincare knowledge could understand it.

Rewrite it once, cutting any word that does not earn its place. Keep the final version — you will use this skill in Module 8.

---

## Exercise 2.1 — Skin-Type Assessment (Module 2)

Complete this assessment on yourself first, then on a willing friend or family member, using conversation and observation only.

### Part A — The conversation

Ask (and answer for yourself):

1. How does your skin feel one hour after washing with water only? (Tight / comfortable / oily / mixed)
2. By mid-afternoon, where is your skin shiny, if anywhere? (Forehead / nose / chin / cheeks / nowhere)
3. Does anything sting, burn, or redden your skin? What, and when did it start?
4. What products are you using now, and how long have you used each one?
5. How does your skin behave in summer versus winter?
6. Have you ever had a reaction to a product? What happened?
7. Do dark marks remain after spots heal? How long do they take to fade?

### Part B — The bare-skin observation

Cleanse with a gentle cleanser, apply nothing, and wait 30–60 minutes. Then record:

| Area | Shine (none / some / a lot) | Flaking | Redness | How it feels |
|---|---|---|---|---|
| Forehead | | | | |
| Nose | | | | |
| Chin | | | | |
| Left cheek | | | | |
| Right cheek | | | | |

### Part C — Your assessment

- Skin type (oily / dry / combination / normal): _______________
- Current conditions (dehydrated / sensitive / breakout-prone / uneven tone / dull / calm): _______________
- Confidence in this assessment (low / medium / high): _______________
- What would make you more confident? _______________

### Part D — Compare

If you assessed a second person, note where the two assessments differed and where you were unsure. Uncertainty is information: write down the follow-up questions you would ask at a consultation.

---

## Exercise 3.1 — Read Three Moisturiser Labels (Module 3)

Take three moisturisers you own or can find in a shop. For each, copy the ingredient list and sort the ingredients into families.

### Product 1

- Name: _______________
- Full ingredient list: _______________
- Humectants: _______________
- Emollients: _______________
- Occlusives: _______________
- Fragrance present? (Yes / No)
- Best suited skin type, and why: _______________

### Product 2

- Name: _______________
- Full ingredient list: _______________
- Humectants: _______________
- Emollients: _______________
- Occlusives: _______________
- Fragrance present? (Yes / No)
- Best suited skin type, and why: _______________

### Product 3

- Name: _______________
- Full ingredient list: _______________
- Humectants: _______________
- Emollients: _______________
- Occlusives: _______________
- Fragrance present? (Yes / No)
- Best suited skin type, and why: _______________

**Reflection:** Which of the three is the most complete moisturiser (all three families present)? Which would you recommend for dry, sensitive skin, and which for oily skin? What surprised you?

---

## Exercise 4.1 — Ingredient Decoder Practice (Module 4)

Using `templates/ingredient-decoder.csv`, complete entries for five ingredients you have never used. For each, record the function, strength of evidence, irritation risk, and suitable skin types. Then write one plain-language sentence you would say to a client about each — no hype, no promises.

| Ingredient | Function | Evidence | Irritation risk | Suits | One sentence for a client |
|---|---|---|---|---|---|
| 1. | | | | | |
| 2. | | | | | |
| 3. | | | | | |
| 4. | | | | | |
| 5. | | | | | |

**Check your sentences:** Would a client understand what the ingredient does, how long it takes, and what the risk is? If any sentence contains "miracle," "instant," "guaranteed," or "erases," rewrite it.

---

## Exercise 5.1 — Sunscreen Comparison (Module 5)

Find three sunscreens: one mineral, one chemical, one hybrid. Compare them honestly — if you can, try each on the back of your hand.

| | Sunscreen A (mineral) | Sunscreen B (chemical) | Sunscreen C (hybrid) |
|---|---|---|---|
| Product name | | | |
| SPF | | | |
| Broad spectrum? | | | |
| White cast (none / slight / obvious) | | | |
| Feel (light / rich / greasy) | | | |
| Price per ml | | | |
| Best suited to | | | |

**Reflection:** Which would you recommend to a client with deeper skin who hates white cast? Which to a client with reactive, sensitive skin? Which would you wear yourself every day — and why?

---

## Exercise 6.1 — Build Your Starter Routine (Module 6)

Use the routine-builder worksheet (`templates/routine-builder-worksheet.md`) to build your own starter routine. Then track it for two weeks.

### My starter routine

- Morning: _______________
- Evening: _______________

### Two-week tracking log

| Day | Comfort (1–5) | Shine | Breakouts | Stinging | Notes |
|---|---|---|---|---|---|
| 1 | | | | | |
| 3 | | | | | |
| 5 | | | | | |
| 7 | | | | | |
| 10 | | | | | |
| 14 | | | | | |

### Adding one active

- Active chosen: _______________
- Concentration and frequency at start: _______________
- Patch-test result (date and outcome): _______________
- Week 1 notes: _______________
- Week 2 notes: _______________
- Week 4 notes: _______________
- Decision: continue / adjust frequency / stop — and why: _______________

---

## Exercise 7.1 — Build Two Routines (Module 7)

### Routine A — the profile closest to your own skin

- Profile: _______________
- Morning: _______________
- Evening: _______________
- Actives, and the order in which you would add them: _______________
- What to avoid: _______________
- What you would tell this client about expectations: _______________

### Routine B — a profile unlike your own

- Profile: _______________
- Morning: _______________
- Evening: _______________
- Actives, and the order in which you would add them: _______________
- What to avoid: _______________
- What you would tell this client about expectations: _______________

### Compare

- What stayed the same between the two builds? _______________
- What changed, and why? _______________
- Which decision in Routine B were you least sure about? What would you check before recommending it? _______________

---

## Exercise 8.1 — Practice Consultation (Module 8)

Role-play a consultation with a friend or colleague using `templates/client-consultation-form.md`. Have them play a client with a concern you have not prepared for.

Afterwards, ask them:

1. Did you feel listened to? (Yes / Mostly / No — and what was missing?)
2. Did you understand the explanation of your skin and the routine?
3. Did you know exactly what to do next, and when to come back?
4. Was there anything I said that worried you or confused you?

**Your reflection:**

- What did you do well? _______________
- What would you do differently next time? _______________
- Did you catch yourself diagnosing, guaranteeing a result, or using a technical term without explaining it? _______________

---

## Exercise 9.1 — Judge a Trend (Module 9)

Pick one skincare trend you have seen recently (social media, a shop, or a client question). Run it through the five-question test.

- Trend: _______________
- 1. What is the claim, exactly? _______________
- 2. Is there a plausible mechanism? _______________
- 3. What is the evidence (published study, lab work, testimonials, nothing)? _______________
- 4. What is the risk? _______________
- 5. What would it replace in a routine? _______________
- Verdict (recommend / try cautiously / do not recommend / not enough evidence): _______________
- One sentence you would say to a client who asks about it: _______________

---

## Checklists

### Daily Routine Checklist

- [ ] Morning: cleanse (or rinse), moisturise if needed, sunscreen — every day
- [ ] Evening: cleanse, treatment step (if scheduled), moisturise
- [ ] Sunscreen reapplied if outdoors for more than two hours, after swimming, or after heavy sweating
- [ ] No new products introduced today without a patch test

### Weekly Routine Checklist

- [ ] Exfoliating acid used only on scheduled nights (not daily by accident)
- [ ] Retinoid frequency as planned — no extra nights added in enthusiasm
- [ ] Skin check: any new redness, stinging, flaking, or breakouts?
- [ ] If irritation appeared, actives paused and baseline resumed

### New Product Checklist

- [ ] Ingredient list read and checked against known sensitivities
- [ ] Fragrance-free if the client has sensitive or reactive skin
- [ ] Patch-tested for 3–7 days on the inner forearm or behind the ear
- [ ] Small facial test area used for a few more days
- [ ] Only one new product introduced at a time
- [ ] Start date and product name recorded

### Consultation Checklist

- [ ] Client's concerns heard in their own words before any advice given
- [ ] Current routine, allergies, medications, and pregnancy status asked about
- [ ] Skin observed in good light, with permission
- [ ] Routine explained with reasons, in plain language
- [ ] Honest timeline given
- [ ] Referral made if any red flag was present
- [ ] Plan written down and a copy given to the client
- [ ] Follow-up date booked (2–4 weeks)

### Referral Red Flags — Quick Reference

Seek medical advice promptly if a client has any of these:

- A new, changing, bleeding, or itchy mole or spot
- A sore or wound that does not heal within a few weeks
- Persistent, widespread, painful, or scarring acne
- A spreading, blistering, or oozing rash
- Persistent facial redness with visible blood vessels or eye irritation
- Swelling of the lips or eyes, or difficulty breathing after using a product (seek urgent care)

---

*Workbook for Skin Science & Signature Routines (BEA-05). Education only — not medical advice.*
