# Routine-Builder Worksheet

**BEA-05 — Skin Science & Signature Routines**
*Use one copy per client (or per profile you are building). Education only — not medical advice.*

---

## 1. Client / Profile

- Name or profile label: _______________
- Date: _______________
- Skin type (oily / dry / combination / normal): _______________
- Current conditions (dehydrated / sensitive / breakout-prone / uneven tone / dull / calm): _______________
- Fitzpatrick type (if known, I–VI): _______________
- Known allergies or sensitivities: _______________
- Current medications or skin treatments (including prescribed): _______________
- Pregnant, trying to conceive, or breastfeeding? (Yes / No / Not applicable)
- Main concern in the client's own words: _______________
- Budget (low / medium / flexible): _______________
- Willing to follow a routine daily? (Yes / Mostly / Unsure)

## 2. Baseline Routine (Weeks 1–2 — no actives yet)

| Step | Morning | Evening |
|---|---|---|
| Cleanse | | |
| Treat | — | — |
| Moisturise | | |
| Protect | Sunscreen SPF ___ | — |

Notes on product types chosen and why: _______________

## 3. Actives Plan (add one at a time, 2–4 weeks apart)

| Order | Active | Concentration | Frequency at start | Start date | Tolerance notes |
|---|---|---|---|---|---|
| 1st | | | | | |
| 2nd | | | | | |
| 3rd | | | | | |

## 4. Full Routine (once actives are established)

### Morning

1. _______________
2. _______________
3. _______________
4. _______________ (sunscreen — always last)

### Evening

1. _______________
2. _______________
3. _______________

### Weekly extras (acids, masks, treatments — with scheduled nights)

| Day | Extra step | Notes |
|---|---|---|
| | | |
| | | |

## 5. What to Avoid

- _______________
- _______________
- _______________

## 6. Expectations Agreed With the Client

- Hydration and comfort: expect change in _______________ (days to 1 week)
- Texture and brightness: expect change in _______________ (2–4 weeks)
- Breakouts / congestion: expect change in _______________ (4–8 weeks)
- Uneven tone / dark marks: expect change in _______________ (8–12+ weeks)
- Fine lines: expect change in _______________ (3–6 months)

Client's own words for what "better" looks like: _______________

## 7. Patch-Test Record

| Product | Test area | Start date | Result after 3–7 days | Proceed? |
|---|---|---|---|---|
| | | | | |
| | | | | |
| | | | | |

## 8. Follow-Up Plan

- Check-in 1 (2–4 weeks): date _______________
- Check-in 2 (8–12 weeks): date _______________
- Referral made? (Yes / No) — reason and to whom: _______________

## 9. Notes and Adjustments

| Date | What changed | Why | Outcome |
|---|---|---|---|
| | | | |
| | | | |
| | | | |

---

*If anything on this sheet falls outside ordinary cosmetic concern — persistent, painful, spreading, or worsening skin problems, or a new or changing mole — refer the client to a qualified dermatologist or doctor.*
