# Client Consultation Form

**BEA-05 — Skin Science & Signature Routines**
*Complete one form per client, per consultation. Store securely and privately, in line with local data-protection rules. Never share client information without consent. Education only — this form does not diagnose any condition.*

---

## 1. Client Details

- Full name: _______________
- Date of birth: _______________
- Contact (phone / email): _______________
- Date of consultation: _______________
- Practitioner: _______________

## 2. What Brings You Here

In the client's own words — what bothers you about your skin, and what would "better" look like?

> _______________

How long has this been a concern? _______________

What have you already tried, and what happened?

| Product or treatment | How long used | What happened |
|---|---|---|
| | | |
| | | |
| | | |

## 3. Current Routine

List every product currently used, including how often.

| Product (type and name) | Morning / Evening | How long used |
|---|---|---|
| | | |
| | | |
| | | |
| | | |
| | | |

Do you use sunscreen daily? (Yes / No / Sometimes) — If yes, which one? _______________

## 4. Skin History and Health

- Known allergies (products, ingredients, foods, latex): _______________
- Previous reactions to skincare products — what happened? _______________
- Skin conditions diagnosed by a doctor (if any): _______________
- Current medications (including any that affect skin): _______________
- Recent skin procedures (peels, laser, microneedling, injectables): _______________
- Pregnant, trying to conceive, or breastfeeding? (Yes / No / Not applicable)
- Do dark marks remain after spots heal? How long do they take to fade? _______________
- Family history of skin conditions (if the client wishes to share): _______________

## 5. Lifestyle

- Sun exposure (work outdoors / mostly indoors / mixed): _______________
- Climate and environment (humid / dry / cold / air-conditioned): _______________
- Sleep and stress (brief, in the client's words): _______________
- Smoking or vaping? (Yes / No / Prefer not to say)
- Anything else that affects your skin that you would like to mention: _______________

## 6. Practitioner Observation (with the client's permission, in good light)

- Skin type (oily / dry / combination / normal): _______________
- Current conditions (dehydrated / sensitive / breakout-prone / uneven tone / dull / calm): _______________
- Fitzpatrick type (if known): _______________
- Observations (factual and neutral): _______________
- Anything outside ordinary cosmetic concern? (Yes / No) — If yes, describe: _______________

## 7. Plan Agreed

### Recommended routine

**Morning:**
1. _______________
2. _______________
3. _______________
4. Sunscreen SPF ___

**Evening:**
1. _______________
2. _______________
3. _______________

### Actives to add, and in what order

1. _______________ — start date: _______________
2. _______________ — start date: _______________

### What to stop or avoid

- _______________
- _______________

### Expectations discussed

- Timeline explained? (Yes / No)
- Patch testing explained? (Yes / No)
- What to do if irritation appears: _______________

## 8. Referral

- Referral made? (Yes / No)
- Reason: _______________
- Referred to (doctor / dermatologist / clinic name): _______________
- Client's response: _______________

## 9. Follow-Up

- Next check-in date (2–4 weeks): _______________
- Second check-in date (8–12 weeks): _______________
- Notes: _______________

## 10. Consent and Acknowledgement

- The client understands this is skincare education and advice, not medical diagnosis or treatment. (Initials: ___)
- The client understands they should consult a qualified dermatologist or doctor for persistent or worsening skin problems. (Initials: ___)
- The client consents to these notes being kept securely for follow-up purposes. (Initials: ___)

Client signature: _______________ Date: _______________

Practitioner signature: _______________ Date: _______________

---

*Referral red flags — seek medical advice if a client has: a new, changing, bleeding, or itchy mole or spot; a sore that does not heal; persistent, widespread, painful, or scarring acne; a spreading, blistering, or oozing rash; persistent facial redness with visible blood vessels or eye irritation; or swelling of the lips or eyes, or difficulty breathing after using a product (seek urgent care).*
