# Skin Science & Signature Routines: Evidence-Based Skincare Education

**BEA-05 — Professional Course**
**Price: $397 (one-time)**

---

## A Note Before You Begin

This course is education, not medical care. It teaches you how skin works, how cosmetic ingredients behave, and how to assemble sensible routines for different skin types and concerns. It does not diagnose skin conditions, prescribe treatment, or replace the advice of a qualified dermatologist or doctor. If you or a client has a persistent rash, lesion, wound that will not heal, severe acne, hair loss, unusual pigmentation, or any skin change that worries you, the correct next step is a referral to a qualified health professional — not a new product.

Ingredient information in this course is educational and general. Individual results vary. Patch testing is covered in Module 6 and should be treated as a standard part of introducing any new product. Product names appear only as examples of ingredient categories, never as endorsements, and formulations change — always check the current ingredient list on the product itself.

---

## How This Course Works

This is a text-based video-course companion: the full instructional content of all nine modules, written to be read, studied, and referred back to. Work through the modules in order the first time. Each module ends with key takeaways and a short practice task. The companion workbook (`workbook.md`) holds the assessments, exercises, and worksheets — do them as you go, not at the end.

**Suggested pace:** one module per week over nine weeks, or one module every two to three days if you are studying intensively. Budget 60–90 minutes per module for reading, plus 30–45 minutes for the workbook exercise. Revisit Module 7 (the six worked routine builds) whenever you meet a new skin profile in real life.

**What you will be able to do when you finish:**

- Explain how skin is structured and how the barrier actually works, in plain language a client can understand.
- Assess a skin type and condition accurately instead of guessing from a single glance or a trend.
- Read an ingredient list and identify what a product is really doing — and what it is not doing.
- Compare ingredients honestly: what the evidence supports, what is plausible but unproven, and what is marketing.
- Build safe, step-by-step routines for six common skin profiles, including what to add, what to leave out, and in what order.
- Run a professional client consultation, document it, and know when to refer onward.
- Spot myths, misleading claims, and unsafe trends before they reach your clients.

---

## Table of Contents

- Module 1 — Skin Anatomy and the Barrier: How Skin Actually Works
- Module 2 — Skin Types, Skin Conditions, and Honest Assessment
- Module 3 — Ingredient Science I: The Foundation — Cleansers, Moisturisers, and the Barrier
- Module 4 — Ingredient Science II: Active Ingredients — Retinoids, Vitamin C, Acids, and More
- Module 5 — Sun Protection: The Single Most Evidence-Based Step
- Module 6 — Routine Architecture: Building Safe Routines in the Right Order
- Module 7 — Six Skin Profiles: Fully Worked Routine Builds
- Module 8 — The Client Consultation: Communication, Documentation, and Ethics
- Module 9 — Troubleshooting, Myths, Trends, and Staying Current
- Glossary of Key Terms
- Further Reading and Sources
- Final Checklist: Your First 30 Days After This Course

---

# Module 1 — Skin Anatomy and the Barrier: How Skin Actually Works

## 1.1 Why anatomy comes first

Most skincare mistakes are anatomy mistakes. People treat the surface of the skin as if it were a sponge that absorbs whatever is rubbed into it, or as if it were a wall that nothing can cross. Neither is true. Skin is a living, selective barrier: it keeps water in and the outside world out, it renews itself constantly, and it responds to what you put on it — but only within limits set by its structure. If you understand those limits, almost every ingredient claim becomes easier to judge. If you do not, you are guessing.

This module gives you the working model you need. You do not need a medical degree to use it, and you should not pretend this module gives you one. Think of it as the map: it tells you where things happen, what can and cannot reach them, and why the barrier matters more than any single "miracle" ingredient.

## 1.2 The three layers

Skin has three main layers. From the outside in, they are the epidermis, the dermis, and the hypodermis (sometimes called the subcutaneous layer). Each does a different job, and cosmetic products interact with them very differently.

**The epidermis** is the outermost layer and the one your routines actually touch. It is thin — roughly 0.05 mm on the eyelids to about 1.5 mm on the palms and soles — and it is made mostly of cells called keratinocytes. At the bottom of the epidermis, new keratinocytes are born. As they move upward, they flatten, fill with a tough protein called keratin, and eventually die, forming the outermost sub-layer: the stratum corneum. The whole journey from birth to shedding takes roughly 28 days in younger adults and longer — often 40 to 60 days — as we age. That turnover time matters: it is one reason results from a new routine take weeks, not days, to show. You are waiting on a new generation of cells to reach the surface.

The epidermis also contains melanocytes, the cells that produce melanin (pigment), and Langerhans cells, part of the immune system. The epidermis has no blood vessels of its own; it is fed by diffusion from the dermis below.

**The dermis** is the thick, structural middle layer. It contains collagen and elastin fibres that give skin its strength and spring, blood vessels, nerves, hair follicles, sweat glands, and oil (sebaceous) glands. Fibroblasts in the dermis produce collagen. This is the layer that determines firmness and where most of the visible signs of ageing — loss of elasticity, deeper lines — actually develop. It is also the layer that topical cosmetics largely cannot reach in meaningful amounts. That is a crucial fact, and it is the reason this course is honest about what skincare can and cannot do: a cream sits on and in the upper epidermis. It does not rebuild the dermis the way a surgical or prescription procedure might. Some ingredients, notably retinoids, can influence the dermis indirectly by signalling through the epidermis, but the effect is modest and slow, and it is not the same as "rebuilding collagen overnight."

**The hypodermis** is the deepest layer, made mostly of fat and connective tissue. It insulates, cushions, and anchors skin to muscle. Cosmetic products do not act on it, and you do not need to think about it when building routines — except to remember that fat loss, whether from ageing or weight change, changes how skin drapes, and no cream addresses that.

**Practical takeaway:** when a product claims to work "deep within the skin," ask which layer it could plausibly reach. Most cosmetic ingredients act in the stratum corneum and upper epidermis. That is not a failure — the stratum corneum is where hydration, barrier health, and the look and feel of skin are largely decided. It is simply the honest frame.

## 1.3 The stratum corneum: the brick wall

The outermost part of the epidermis, the stratum corneum, is often described as a brick wall. The "bricks" are dead, flattened cells called corneocytes, packed with keratin. The "mortar" is a mixture of lipids — ceramides, cholesterol, and free fatty acids — arranged in organised layers between the cells. This structure is the skin barrier.

The barrier does two jobs at once. It limits **transepidermal water loss (TEWL)** — water escaping from inside the body out through the skin — and it limits what gets in: microbes, irritants, allergens, and chemicals. A healthy barrier is not waterproof in the absolute sense; it is selective and well-sealed. A damaged barrier leaks water out (skin feels dry, tight, and rough) and lets irritants in (skin stings, reddens, and reacts).

Three things damage the barrier most often in everyday life:

1. **Over-cleansing.** Harsh cleansers, very hot water, and washing too often strip the lipid mortar. Skin feels "squeaky clean" — which is a warning sign, not a goal.
2. **Over-exfoliation.** Too-frequent acids, scrubs, or retinoids remove corneocytes faster than they can be replaced. The wall thins.
3. **Environmental stress.** Cold, dry air, wind, low humidity, and UV exposure all increase water loss and stress the barrier.

And three things support it: gentle cleansing, regular moisturising with ingredients that replace or mimic the lipid mortar (ceramides, cholesterol, fatty acids), and sun protection. Notice that the most important skincare is also the least glamorous. That pattern repeats throughout this course.

## 1.4 The acid mantle and the skin microbiome

The surface of healthy skin is slightly acidic, with a pH roughly between 4.5 and 5.5. This "acid mantle" — a thin film of sebum, sweat, and dead-cell debris — helps keep the barrier intact and makes the surface less hospitable to many harmful microbes. Strongly alkaline products (traditional bar soaps can sit around pH 9–10) disrupt it temporarily; skin usually recovers, but repeated disruption adds up, especially for sensitive or already-compromised skin. This is why cleanser pH matters and why "pH-balanced" is a meaningful claim rather than pure marketing — though it is no guarantee of gentleness on its own.

The skin also hosts a microbiome: a community of bacteria, fungi, and other micro-organisms that live on the surface. In healthy skin this community is diverse and balanced, and it helps crowd out harmful organisms and supports immune function. You do not need to memorise species names. What you need to know is practical: harsh antibacterial products, overuse of strong actives, and constant scrubbing disturb the microbiome; gentle, minimal routines support it. Products marketed as "probiotic" or "microbiome-friendly" are a young category — the idea is plausible, the evidence for specific cosmetic products is still limited, and this course treats such claims as interesting but unproven until better studies exist.

## 1.5 Sebum, sweat, and the skin's own moisturising system

Sebaceous glands produce sebum, an oily substance that coats the skin surface, slows water loss, and keeps skin supple. Sebum production is driven largely by hormones, which is why it rises at puberty and why it varies so much between people. More sebum is not a defect — it is normal variation — but excess sebum mixed with dead cells can contribute to clogged pores, and that is where several common concerns begin.

Sweat glands produce sweat, which cools the body and contributes to the acid mantle. Sweat itself does not "detox" the skin; the idea that sweating purges toxins from the skin is a myth addressed in Module 9.

Skin also has its own internal moisturising system: the **natural moisturising factor (NMF)**, a mixture of amino acids, urea, lactic acid, and other small molecules inside corneocytes that attract and hold water. Many effective moisturisers work simply by supplying ingredients similar to the NMF (glycerin, urea, hyaluronic acid) or by sealing water in (occlusives). When you understand the NMF, you understand why a good basic moisturiser is often more valuable than an expensive serum: it is doing the same fundamental job.

## 1.6 How ingredients get in (and mostly do not)

For a topical ingredient to act, it must cross the stratum corneum. That is deliberately difficult. In general, small, fat-soluble molecules penetrate better than large, water-soluble ones — but "better" still means a small fraction of what is applied, and mostly into the upper epidermis. Very large molecules, such as collagen itself and most forms of hyaluronic acid, are too large to pass the barrier in meaningful amounts. That does not make them useless: hyaluronic acid is an excellent surface humectant, and collagen in a cream can improve surface hydration and feel. It does mean the claim "this cream puts collagen into your skin" is misleading. Topical collagen stays on top; it does not become your collagen.

Formulation matters as much as the ingredient itself. The same ingredient at the same percentage can behave differently depending on the vehicle (cream, gel, serum), the pH, and the other ingredients present. This is why ingredient lists alone never tell the whole story, and why this course teaches you to read them as clues rather than verdicts.

## 1.7 Ageing: what changes, honestly

Skin changes with age in ways that are normal and predictable. Cell turnover slows. Collagen production declines — roughly 1% per year after early adulthood, though the rate varies. Elastin degrades. Sebum production falls. The barrier recovers more slowly after disruption. Blood flow to the skin decreases. These intrinsic changes are real but modest compared with **photoageing** — the damage caused by cumulative UV exposure — which accounts for the majority of visible ageing in sun-exposed skin: wrinkles, uneven pigmentation, loss of elasticity, and roughness.

The practical consequence is straightforward and is the backbone of this whole course: the two most effective anti-ageing steps in skincare are sun protection and retinoids, both covered in depth in Modules 4 and 5. Everything else is secondary. Any routine that skips sun protection while promising to reverse ageing is selling the wrong priority.

## 1.8 Key takeaways

- Skin has three layers; cosmetics act mainly on the epidermis, especially the stratum corneum.
- The barrier is a brick-and-mortar structure of corneocytes and lipids; its health determines hydration, comfort, and resilience.
- Cell turnover takes about 28 days in younger adults and longer with age — expect weeks, not days, for visible change.
- Skin is slightly acidic (pH ~4.5–5.5); harsh alkaline cleansing disrupts that.
- Most cosmetic ingredients cannot reach the dermis; claims of deep rebuilding should be treated with scepticism.
- Photoageing from UV exposure is the largest driver of visible ageing — which is why sun protection comes first.

## 1.9 Practice task

Write a one-paragraph explanation of the skin barrier in plain language, as if to a client who has just told you their skin "stings when I put anything on it." Do not use the words "stratum corneum," "TEWL," or "corneocyte" — translate them. Put your paragraph in the workbook (Exercise 1.1) and keep it; you will reuse this skill in Module 8.

---

# Module 2 — Skin Types, Skin Conditions, and Honest Assessment

## 2.1 Type is not condition

The single most common error in skincare advice is confusing skin **type** with skin **condition**. They are different things, they change on different timescales, and they need different responses.

**Skin type** is the long-term, largely inherited baseline: how much oil the skin produces and how it behaves day to day. It changes slowly, mainly with age and hormones. The classic four types — oily, dry, combination, normal — are a useful starting shorthand, but they are a simplification. Real skin sits on a spectrum, and many people are between categories.

**Skin condition** is what is happening right now: dehydrated, sensitive, breakout-prone, sun-damaged, irritated, or calm. Conditions come and go. A person with oily skin can be dehydrated. A person with dry skin can have breakouts. Sensitive is not a type at all — it is a condition, a description of reactivity — and it can appear in any type. Treating a condition as if it were a type is how people end up using a harsh "oily skin" routine on skin that is actually dehydrated and irritated, making everything worse.

Rule for this course: assess type first, then condition, then build the routine for the combination.

## 2.2 The four types, described honestly

**Oily skin** produces visibly more sebum. It tends to look shiny, especially in the T-zone (forehead, nose, chin), pores may appear larger, and makeup may not last as long. Oily skin is not dirty skin, and it is not a problem to be solved by stripping. Aggressive oil removal triggers a cycle: the barrier is damaged, skin feels tight, and oil production continues — often the shine returns within an hour. Oily skin also has a genuine advantage: it tends to show fine lines later than dry skin, because the surface stays better lubricated.

**Dry skin** produces less sebum and often has a weaker barrier. It can feel tight, look dull or flaky, and fine lines may show earlier. Dry skin needs lipids — ingredients that replace the mortar of the barrier — not just water. A watery gel that feels refreshing may do very little for truly dry skin if it contains no emollients or occlusives.

**Combination skin** is the most common presentation: oilier in the T-zone, normal or drier on the cheeks. It does not need two entirely different routines; it usually needs a balanced routine with slightly different emphasis by area — for example, a lighter moisturiser overall and a richer one on the cheeks in winter.

**Normal skin** is balanced: neither very oily nor very dry, with few concerns. It still needs cleansing, moisturising, and sun protection. "Normal" does not mean "needs nothing."

A fifth term you will see is **sensitive skin**. Treat it as a reactivity label, not a type. Sensitive skin stings, reddens, or flushes easily in response to products, temperature change, or friction. Some people are constitutionally reactive; more often, sensitivity is acquired — the result of a damaged barrier from over-exfoliation or harsh products. In the second case, the fix is not a lifetime of "sensitive" products; it is barrier repair, then a slow reintroduction of actives.

## 2.3 The Fitzpatrick scale and why it matters for your advice

The Fitzpatrick scale (types I–VI) classifies skin by its response to sun: from type I, which always burns and never tans, to type VI, deeply pigmented skin that rarely burns. It was developed for dermatology, and it matters in skincare education for two practical reasons.

First, **pigmentation risk differs**. Deeper skin tones (types IV–VI) are more prone to post-inflammatory hyperpigmentation — dark marks left after a breakout or irritation. That means irritation is costlier: an aggressive exfoliant that causes a mild redness in lighter skin can leave a mark lasting months in deeper skin. Strong actives must be introduced more slowly, and soothing, barrier-supporting steps matter more.

Second, **sunscreen advice must be inclusive**. The white cast left by mineral sunscreens is a real barrier to use for deeper skin tones, and "just wear sunscreen" is unhelpful advice if every formula you recommend leaves a visible cast. Chemical or hybrid formulas, tinted mineral formulas, and newer sheer mineral formulations are legitimate options, and recommending them is part of competent practice. Sun protection is for every skin tone — skin cancer and photoageing affect all tones, even though risk levels differ.

Never assume a client's Fitzpatrick type by appearance alone in a way that changes your advice without asking about their own experience of sun and pigmentation. Ask; do not guess.

## 2.4 Assessment methods that actually work

You need assessment methods that are simple, repeatable, and honest about their limits. Three are worth using:

**1. The conversation.** Ask about the client's own experience: How does skin feel an hour after washing with only water? Does it feel tight, comfortable, or oily? Does anything sting? What products are they using now, and what happened when they started them? How does skin behave in summer versus winter? The client's history is more informative than any single observation.

**2. The bare-skin observation.** After cleansing with a gentle cleanser and waiting 30–60 minutes with nothing applied, observe: shine in the T-zone versus cheeks, visible flaking, redness, and how the skin feels to the client. This is the classic "wash test." It is simple and useful, but it is affected by weather, recent products, and the time of day — treat it as one data point.

**3. The blotting-paper check (optional).** Press clean blotting paper on the forehead, nose, chin, and cheeks after the wait period. Oil transfer in the T-zone only suggests combination skin; oil everywhere suggests oily skin; little or no oil suggests dry or normal skin. It is a rough indicator, not a diagnosis.

**What not to rely on:** single-use "skin analysis" apps and devices that claim to measure hydration, age, or "skin score" from a phone photo. They can be interesting, but their accuracy varies widely and they are not a substitute for observation and conversation. If you use one, treat its output as a conversation starter, never as a verdict. The same applies to in-store skin scanners: useful for engagement, unreliable as the sole basis for a routine.

## 2.5 Common conditions and what they usually mean

**Dehydration** is a lack of water, not a lack of oil. Signs: skin looks dull and feels tight even though it may be oily, fine lines appear more visible (sometimes called "dehydration lines"), and makeup sits poorly. Cause: low humidity, over-cleansing, too many drying products, not enough humectants. Response: humectants plus a moisturiser that seals water in — not more oil alone, and not harsher cleansing.

**Breakouts** range from occasional spots to persistent acne. Occasional spots are a cosmetic concern you can address with routine adjustments. Persistent, painful, widespread, or scarring acne is a medical matter: your role is to keep the routine gentle, avoid irritating products, and refer to a dermatologist or doctor. Do not attempt to treat acne yourself beyond basic skincare, and never promise to clear it. See Module 9 for the referral threshold in detail.

**Redness and reactivity** can be temporary (irritation from a product) or persistent (conditions such as rosacea, which only a clinician can diagnose). Your role: simplify the routine, remove suspected irritants, support the barrier, and refer if redness persists, worsens, or comes with visible blood vessels, bumps, or eye irritation.

**Uneven tone and dark marks** usually follow sun exposure or inflammation after breakouts. They respond slowly to sun protection plus gentle brightening ingredients (see Module 4). Warn clients that this is a months-long process, that sun protection is non-negotiable during it, and that aggressive peeling makes it worse, particularly in deeper skin tones.

**Dullness** is often just dehydration plus slow cell turnover. It is one of the most fixable concerns: gentle exfoliation, hydration, and sun protection usually improve it within weeks.

## 2.6 What assessment cannot do

Assessment does not diagnose. You cannot diagnose eczema, psoriasis, rosacea, fungal infection, or skin cancer from looking at skin, and you must not try. What you can do is recognise that something is outside the range of ordinary cosmetic concern and refer. The referral phrases in Module 8 are there so you are never stuck for words when that moment comes.

Assessment also does not predict the future precisely. Two people with the same type can respond differently to the same product. That is why patch testing, slow introduction, and follow-up matter more than getting the first assessment "perfect."

## 2.7 Key takeaways

- Type is long-term (oil production); condition is current (dehydration, sensitivity, breakouts). Assess both.
- Sensitive is a condition, not a type — and it is often a sign of a damaged barrier, which can be repaired.
- Deeper skin tones carry a higher risk of post-inflammatory hyperpigmentation: introduce actives slowly and prioritise barrier support.
- The conversation and a simple bare-skin observation beat any app or scanner.
- Persistent, painful, scarring, or worsening skin problems are referral territory, not routine-building territory.

## 2.8 Practice task

Complete the skin-type assessment in the workbook (Exercise 2.1) on yourself, then on a willing friend or family member using only conversation and observation. Compare the two. Note where you were unsure — that uncertainty is information, and it is what the follow-up questions in Module 8 are for.

---

# Module 3 — Ingredient Science I: The Foundation — Cleansers, Moisturisers, and the Barrier

## 3.1 The hierarchy nobody markets

If you rank skincare steps by the strength of evidence and the size of their effect, the list is unglamorous:

1. Sun protection
2. Gentle cleansing
3. Moisturising (barrier support)
4. Targeted actives (retinoids, vitamin C, exfoliants)

Marketing inverts this list, because steps 1–3 are cheap and hard to differentiate, while step 4 is where premium prices live. Your job is to keep the hierarchy straight for your clients: a routine that does steps 1–3 well and step 4 modestly will outperform a routine that does step 4 aggressively and steps 1–3 badly, almost every time.

## 3.2 Cleansers: what they do and how they go wrong

A cleanser's job is narrow: remove dirt, excess oil, sunscreen, and makeup without damaging the barrier. That is all. A cleanser does not need to "treat" anything, and the ingredients that claim to treat — acids, vitamins, antioxidants in a wash-off product — have minimal contact time and are mostly rinsed away. Pay for treatment in leave-on products, not cleansers.

Cleansers work with **surfactants**, molecules that lift oil and dirt so water can rinse them away. Surfactants differ in harshness. The harshest common ones (for example, sodium lauryl sulfate) clean aggressively and strip lipids; gentler ones (such as coco-betaine, decyl glucoside, and sodium cocoyl isethionate) clean effectively with less disruption. You do not need to memorise surfactant chemistry — but you should know the practical test: after cleansing and patting dry, skin should feel clean and comfortable, not tight, squeaky, or stripped. If it feels tight, the cleanser is too strong for that person, whatever the label says.

**Choosing a cleanser by skin type:**

- **Oily skin:** a gel or light foaming cleanser, used once or twice daily. Avoid the temptation to cleanse three times a day or to use a harsh scrub cleanser — both damage the barrier without reducing oil production.
- **Dry skin:** a cream, milk, or oil-based cleanser, or a gentle non-foaming gel. Avoid strong foaming cleansers and hot water.
- **Combination skin:** a gentle gel or cream cleanser; adjust by season rather than by buying two products.
- **Sensitive or compromised skin:** the gentlest option available — a minimal, fragrance-free cream or micellar cleanser, lukewarm water, no rubbing, pat dry.

**How to cleanse well:** lukewarm water (never hot), a small amount of product, gentle circular motions for 30–60 seconds, rinse thoroughly, pat dry with a clean towel — never rub. Cleanse once in the evening always; in the morning, oily skin usually benefits from a cleanse, while very dry or sensitive skin may do fine with a water rinse alone. Double cleansing (an oil-based cleanser followed by a water-based one) is useful for removing sunscreen and makeup thoroughly in the evening, but it is optional, not mandatory. If a client wears no makeup and light sunscreen, a single gentle cleanse is enough.

**What to avoid:** physical scrubs with rough particles (walnut shell, apricot kernel, coarse sugar) used aggressively — they create micro-tears and uneven exfoliation; cleansing brushes used daily on sensitive skin; and any cleanser that leaves skin feeling tight. "Squeaky clean" is damage, not cleanliness.

## 3.3 Moisturisers: three ingredient families

Every moisturiser works through one or more of three ingredient families. Once you can identify which family an ingredient belongs to, you can read any moisturiser label with confidence.

**Humectants** attract water. They pull water from the deeper skin and, in humid conditions, from the air, into the stratum corneum. Examples: glycerin, hyaluronic acid, urea, lactic acid, propylene glycol, panthenol (pro-vitamin B5). Glycerin is the workhorse — cheap, effective, and supported by decades of use. Hyaluronic acid is a larger molecule that sits on the surface and holds water there; it hydrates the surface well but does not penetrate deeply, and that is fine — surface hydration is what it is for. Important caveat: in very dry air, a humectant used alone with nothing to seal it in can increase water loss from the skin. Humectants need an emollient or occlusive partner. This is why a hyaluronic acid serum alone, with no moisturiser over it, can leave skin feeling drier — a common and easily fixed mistake.

**Emollients** soften and smooth by filling the gaps between corneocytes with lipids, making the surface feel smooth and flexible. Examples: squalane, ceramides, cholesterol, fatty acids (such as linoleic acid), shea butter, jojoba oil, and dimethicone (a silicone). Ceramides deserve special attention: they are a natural component of the lipid mortar, and moisturisers containing ceramides, cholesterol, and fatty acids in roughly the skin's own ratio are among the best-supported choices for barrier repair. Squalane is a light, stable emollient that suits most skin types, including oily skin, because it is non-greasy and non-comedogenic in the ordinary sense. Dimethicone is often misunderstood: it is a silicone that forms a breathable, protective film. It does not "suffocate" skin, it does not clog pores in the way people fear, and it is one of the most useful ingredients for sensitive and barrier-compromised skin. Judge silicones by their function, not by internet reputation.

**Occlusives** form a physical seal over the skin and slow water loss. Examples: petrolatum (petroleum jelly), mineral oil, beeswax, lanolin, and heavier plant butters. Petrolatum is the most effective occlusive known — it can reduce transepidermal water loss by over 90% — and it is also one of the cheapest and most misunderstood. It is not absorbed, it does not clog pores in the way commonly claimed, and for very dry, cracked, or barrier-damaged skin it is often the single most helpful product available. The reason people avoid it is cosmetic: it feels greasy and looks shiny. Used as a thin final layer at night ("slugging"), it is a legitimate, evidence-based technique for dry skin — and it costs almost nothing.

**Putting it together:** a good moisturiser usually contains all three families — a humectant to bring water in, emollients to smooth and repair, and an occlusive to keep the water there. A product that contains only one family is incomplete for most people. When a client says "moisturiser doesn't work for me," the usual problem is that they are using the wrong family for their need: a light gel (humectant only) on very dry skin, or a heavy butter (occlusive only) on dehydrated skin that actually needs water first.

## 3.4 Choosing a moisturiser by skin type

- **Oily skin:** a light gel or gel-cream with humectants and a small amount of emollient; avoid heavy occlusives during the day. Oily skin still needs moisturiser — skipping it does not reduce oil, and dehydrated oily skin overproduces shine while feeling tight.
- **Dry skin:** a cream with ceramides, cholesterol, fatty acids, and a meaningful occlusive component. In winter, a richer cream or a thin occlusive layer at night.
- **Combination skin:** a medium-weight lotion or cream; apply more generously on dry areas, thinly on the T-zone.
- **Sensitive skin:** a minimal formula — few ingredients, fragrance-free, with ceramides and soothing agents such as panthenol or allantoin. Fewer ingredients means fewer potential irritants.

## 3.5 Toners, essences, and mists: optional, not essential

Toners were originally designed to restore pH after alkaline cleansing. Modern gentle cleansers make that job largely unnecessary. Today's toners are usually either hydrating (humectant-based) or exfoliating (acid-based). A hydrating toner is a pleasant, optional extra layer of humectants — useful, but not essential if the moisturiser already contains them. An exfoliating toner is simply an exfoliant in liquid form and should be counted as one (see Module 4). Essences and mists are similar: light hydrating layers. None of them is required for a complete routine. If a client enjoys them and they cause no irritation, keep them; if budget is limited, they are the first thing to cut.

## 3.6 Fragrance, essential oils, and alcohol: the honest position

**Fragrance** (listed as "parfum" or "fragrance") is the most common cosmetic irritant and allergen. It adds nothing to a product's function. For sensitive, reactive, or barrier-compromised skin, fragrance-free is the right recommendation. For resilient skin, a fragranced product is usually fine — but fragrance is never a benefit, only a preference. "Unscented" is not the same as "fragrance-free": unscented products may contain masking fragrance. Teach clients to look for the words "fragrance-free" on the label.

**Essential oils** (lavender, tea tree, citrus oils, and others) are concentrated plant compounds. Some have real antimicrobial or soothing properties in studies, but they are also common irritants and sensitisers, and citrus oils can increase sun sensitivity. Tea tree oil has modest evidence for spot treatment, but it must be diluted and patch-tested. As a general rule, essential oils do not belong in a routine for sensitive skin, and they should never be applied undiluted.

**Alcohol:** the ingredient list may show "alcohol denat." (denatured alcohol), which evaporates quickly and gives products a light, fast-absorbing feel. In high concentrations it is drying and irritating, particularly for dry and sensitive skin. Fatty alcohols (cetyl alcohol, stearyl alcohol, cetearyl alcohol) are entirely different — they are emollients that thicken creams and are not drying. Teach clients the distinction, because "alcohol-free" marketing often confuses the two.

## 3.7 Worked example: reading a moisturiser label

Consider a label that reads: *Water, glycerin, ceramides (NP, AP, EOP), cholesterol, squalane, petrolatum, dimethicone, panthenol, phenoxyethanol.*

Reading it by family: glycerin and panthenol are humectants; ceramides, cholesterol, and squalane are emollients that mimic the skin's own lipids; petrolatum and dimethicone are occlusives. This is a well-constructed barrier-repair moisturiser: all three families present, ceramides included, no fragrance listed, and a standard preservative (phenoxyethanol) at the end. It would suit dry, sensitive, or barrier-compromised skin, and it would be a reasonable night cream for most types.

Now consider: *Water, alcohol denat., fragrance, hyaluronic acid, green tea extract.* The humectant is present but the formula is dominated by drying alcohol and fragrance, with no meaningful emollient or occlusive. Whatever the marketing claims, this product is a poor moisturiser and a likely irritant for sensitive skin. The ingredient list told you that in ten seconds.

**A note on ingredient order:** ingredients are listed in descending order of concentration (above 1%), with ingredients below 1% listed in any order. If a celebrated ingredient appears after the preservative or near the very end of the list, it is present in a very small amount. That does not automatically make it useless — some ingredients work at low concentrations — but it should lower your expectations.

## 3.8 Key takeaways

- The hierarchy is: sun protection, gentle cleansing, moisturising, then actives. Keep it in that order.
- A cleanser's only job is to clean without damaging the barrier. "Squeaky clean" is a warning sign.
- Moisturisers work through humectants (attract water), emollients (smooth and repair), and occlusives (seal water in). A good moisturiser usually contains all three.
- Petrolatum is the most effective occlusive known and is unfairly maligned; ceramides are the best-supported barrier-repair emollients.
- Fragrance adds no function and is the most common irritant. Fragrance-free is the right default for sensitive skin.
- Read ingredient lists by family and by order — a celebrated ingredient at the end of the list is present in a tiny amount.

## 3.9 Practice task

Take three moisturisers you own or can find in a shop. Write out their ingredient lists and sort each ingredient into humectant, emollient, occlusive, or other. Decide which skin type each product suits best and why. Record your answers in the workbook (Exercise 3.1).

---

# Module 4 — Ingredient Science II: Active Ingredients — Retinoids, Vitamin C, Acids, and More

## 4.1 What "active" means

An active ingredient is one included to produce a specific effect beyond basic cleansing and moisturising: increasing cell turnover, reducing the appearance of pigmentation, supporting collagen, or exfoliating the surface. Actives are where the most impressive claims — and the most irritation — live. The rule for this whole module is simple: **an active is only useful if the skin tolerates it consistently.** A strong active used for two weeks and then abandoned because of irritation achieves less than a gentle one used for six months.

Introduce one active at a time. Wait two to four weeks before adding another. If irritation appears, you will know which ingredient caused it. This discipline is the difference between a professional and a trend-chaser.

## 4.2 Retinoids: the best-supported active

Retinoids are derivatives of vitamin A. They are the most studied topical anti-ageing ingredient family in dermatology, with decades of evidence behind them. They work by increasing cell turnover, supporting collagen production in the dermis, and improving the appearance of uneven pigmentation and fine lines. No other cosmetic ingredient family has comparable evidence for visible ageing.

**The family, from gentlest to strongest:**

- **Retinyl palmitate and retinol esters:** the gentlest, weakest options. They must convert through several steps in the skin before becoming active, so much of the effect is lost. Suitable for very sensitive skin or as a first step, but expect modest results.
- **Retinol:** the standard over-the-counter retinoid. It converts to retinaldehyde and then to retinoic acid in the skin. Effective at concentrations around 0.1%–1%, with higher concentrations bringing more irritation as well as more effect. The usual starting point is a low concentration (0.1%–0.3%) used two to three nights a week.
- **Retinaldehyde (retinal):** one conversion step from retinoic acid, so it acts faster than retinol and is often better tolerated at equivalent strength. A good middle option.
- **Adapalene:** available over the counter in many countries at 0.1%. Originally developed for acne, it is effective, stable, and often well tolerated. Useful for breakout-prone skin.
- **Tretinoin (retinoic acid):** prescription-only in most countries. The most potent and best studied. If a client is a candidate — persistent acne, significant photoageing — the honest advice is to discuss it with a doctor or dermatologist rather than to chase ever-stronger over-the-counter products.

**How to use retinoids well:** apply a pea-sized amount to the whole face at night, on clean, dry skin, two to three nights a week at first, increasing frequency as tolerated over weeks. Moisturiser can be applied before ("sandwich method") or after to reduce irritation. Expect an adjustment period of two to six weeks: mild dryness, flaking, or sensitivity is common and usually passes. This is sometimes called "retinisation." If irritation is severe, persistent, or painful, reduce frequency or stop and let the barrier recover.

**Retinoid cautions:** do not use retinoids during pregnancy or while trying to conceive — this is a standard precaution, and anyone pregnant or planning pregnancy should discuss all skincare with their doctor. Retinoids increase sun sensitivity, so daily sun protection is essential while using them. Do not combine a new retinoid with a new exfoliating acid in the same week. Do not use retinoids on broken or eczema-affected skin. And never apply retinoids around the eyes unless the product is specifically formulated for that area — the skin there is thin and irritates easily.

**Expectations:** visible improvement in texture and tone typically takes 8–12 weeks; improvement in fine lines takes three to six months or longer. Anyone promising faster results is selling hope, not evidence.

## 4.3 Vitamin C: brightening and antioxidant support

Vitamin C (ascorbic acid) is an antioxidant that supports collagen synthesis and helps reduce the appearance of uneven pigmentation by interfering with melanin production. It is the best-supported brightening ingredient in cosmetics, but it is also one of the most unstable: pure ascorbic acid oxidises easily when exposed to light and air, turning yellow or brown — a sign it has degraded.

**Forms:**

- **L-ascorbic acid (pure vitamin C):** the most studied form, effective at 10%–20%, but most likely to irritate and oxidise. Best in a low-pH formula (around 3.5 or below), stored in opaque, airtight packaging.
- **Derivatives (sodium ascorbyl phosphate, magnesium ascorbyl phosphate, ascorbyl glucoside, tetrahexyldecyl ascorbate):** more stable and gentler, but with less direct evidence than pure ascorbic acid. Good choices for sensitive skin.
- **Combination note:** vitamin C and sunscreen work well together — vitamin C provides antioxidant support that complements UV protection, and using vitamin C in the morning under sunscreen is a well-supported routine choice.

**Practical guidance:** start at 10% or lower, use once daily in the morning, and stop using a bottle that has turned dark brown. If a client experiences stinging or redness, switch to a derivative form rather than abandoning vitamin C entirely. Vitamin C does not need to be combined with vitamin E and ferulic acid to work, but that combination is well studied and does improve stability and effectiveness — it is one of the few "combination" claims with real evidence behind it.

## 4.4 Exfoliating acids: AHAs, BHAs, and PHAs

Chemical exfoliants dissolve the bonds between dead surface cells, allowing them to shed more evenly. Used correctly, they improve texture, brightness, and the appearance of clogged pores. Used too often, they are the fastest route to a damaged barrier.

**AHAs (alpha hydroxy acids)** are water-soluble and work on the surface. The main ones:

- **Glycolic acid:** the smallest AHA, penetrates most readily, effective but the most likely to irritate. Typical concentrations 5%–10% in leave-on products.
- **Lactic acid:** larger, gentler, and also a humectant — a good choice for dry or sensitive skin. Typical concentrations 5%–10%.
- **Mandelic acid:** the largest AHA, penetrates slowly, gentle and well suited to sensitive skin and deeper skin tones (lower irritation means lower risk of post-inflammatory hyperpigmentation).

**BHAs (beta hydroxy acids):** salicylic acid is the main one. It is oil-soluble, so it can penetrate into pores, making it the most useful exfoliant for oily, breakout-prone skin. Typical concentrations 0.5%–2%. It also has mild anti-inflammatory properties. Salicylic acid is the standard over-the-counter choice for blackheads and congestion. Do not use it on broken skin, and note that it is not recommended during pregnancy at high concentrations — anyone pregnant should ask their doctor.

**PHAs (polyhydroxy acids)** — gluconolactone and lactobionic acid — are larger molecules that exfoliate very gently and also attract water. They are the best starting point for sensitive skin and for anyone who has previously over-exfoliated.

**How to use acids well:** start with one acid, once or twice a week, at a low concentration. Use at night. Do not layer multiple acids, and do not combine a new acid with a new retinoid. Always use sun protection — exfoliation increases sun sensitivity. The signs of over-exfoliation are unmistakable once you know them: persistent redness, stinging when applying products that never stung before, shininess that is not oil but stretched, irritated skin, and breakouts in unusual places. The fix is always the same: stop all actives, return to gentle cleansing and barrier moisturiser, and wait two to four weeks before reintroducing anything — one product at a time.

## 4.5 Niacinamide: the versatile supporting ingredient

Niacinamide (vitamin B3) is one of the most useful and best-tolerated ingredients in modern skincare. The evidence supports several effects: it supports the barrier by increasing ceramide production, reduces the appearance of redness and blotchiness, helps regulate the look of oiliness, and modestly improves uneven tone. It does not do any one of these dramatically, but it does all of them gently, and it is tolerated by almost everyone, including sensitive skin.

Typical concentrations are 2%–5%; higher concentrations (10%) are widely sold but offer little additional benefit and are more likely to cause flushing or irritation in some people. Niacinamide combines well with almost everything, including retinoids and vitamin C — the old claim that niacinamide and vitamin C cannot be used together is based on outdated chemistry and does not apply to modern formulations. If a client can only afford one "extra" ingredient beyond the basics, niacinamide is a strong candidate: low risk, broad benefit, and compatible with everything else in the routine.

## 4.6 Peptides, growth factors, and the ingredients with thinner evidence

**Peptides** are short chains of amino acids. In theory, some signal skin cells to produce more collagen; in practice, the evidence for cosmetic peptides is promising but limited, because peptides are large molecules that struggle to penetrate the barrier, and the studies that exist are often small or funded by manufacturers. Peptides are not harmful and may help with hydration and skin feel, but they should be presented as a secondary, "nice to have" ingredient — never as a substitute for retinoids or sun protection, and never at a premium price justified by collagen claims.

**Growth factors** are proteins involved in cell signalling and wound healing. They appear in expensive products, but the evidence for topical cosmetic growth factors is thin, the molecules are large, and the products are costly. This course does not recommend them as a priority.

**Antioxidants** beyond vitamin C — vitamin E, ferulic acid, green tea (polyphenols), resveratrol, coenzyme Q10 — have plausible mechanisms and some supporting evidence, mostly for protecting against environmental damage. They are reasonable supporting ingredients, particularly in the morning under sunscreen, but they are not replacements for sunscreen. No antioxidant protects skin from UV the way sunscreen does.

**Bakuchiol** is a plant-derived compound marketed as a "natural retinol alternative." Early studies suggest it may improve the appearance of fine lines and pigmentation with less irritation than retinol, but the evidence base is small — a handful of studies, not decades. It is a reasonable option for people who cannot tolerate retinoids or who prefer to avoid them, but it should be presented as promising rather than proven, and not as equivalent to retinol.

## 4.7 Ingredients comparison: what the evidence actually says

| Ingredient | Best-supported use | Strength of evidence | Irritation risk |
|---|---|---|---|
| Retinoids (retinol/tretinoin) | Visible ageing, texture, uneven tone | Strong — decades of studies | Moderate to high |
| Vitamin C (ascorbic acid) | Brightening, antioxidant support | Moderate to strong | Low to moderate |
| Salicylic acid (BHA) | Congestion, blackheads, oily skin | Moderate to strong | Low to moderate |
| Glycolic/lactic acid (AHA) | Texture, dullness, uneven tone | Moderate | Moderate |
| Niacinamide | Barrier support, redness, tone | Moderate | Very low |
| Ceramides | Barrier repair, dryness | Moderate | Very low |
| Hyaluronic acid | Surface hydration | Moderate (for hydration) | Very low |
| Peptides | General skin feel, possible firmness | Weak to moderate | Very low |
| Bakuchiol | Gentle alternative to retinol | Weak to moderate (early) | Low |

This table is the heart of honest ingredient advice. When a client asks whether an expensive peptide serum is "worth it," the answer is in the table: it is low-risk and possibly helpful, but it is not where the evidence is strongest, and it should never come before sun protection, a gentle cleanser, a good moisturiser, and (if tolerated) a retinoid.

## 4.8 Key takeaways

- Introduce one active at a time; wait two to four weeks before adding another.
- Retinoids have the strongest evidence for visible ageing. Start low, go slow, use at night, and always pair with sun protection.
- Vitamin C is best in the morning under sunscreen; discard it when it turns dark brown.
- Acids exfoliate well but are the fastest route to a damaged barrier. One acid, once or twice a week, to start.
- Niacinamide is the safest broad-benefit active — a good first active for almost anyone.
- Peptides, growth factors, and bakuchiol are promising but not proven equivalents to retinoids. Present them honestly.

## 4.9 Practice task

Using the ingredient decoder template (templates/ingredient-decoder.csv), look up and complete entries for five ingredients you have never used. For each, note its function, the strength of evidence, its irritation risk, and which skin types it suits. Then write one sentence you would say to a client about each — in plain language, with no hype. Record your sentences in the workbook (Exercise 4.1).

---

# Module 5 — Sun Protection: The Single Most Evidence-Based Step

## 5.1 Why this module is the most important one

If this course had only one module, it would be this one. UV radiation is the largest preventable contributor to visible skin ageing and the primary risk factor for skin cancer. Sunscreen is the single skincare product with the strongest evidence for preventing both. Every other step in a routine is secondary to this one. A person who uses sunscreen daily and nothing else is doing more for their skin's future than a person with a ten-step routine and no sunscreen.

This is also the step people resist most: sunscreen feels unpleasant, leaves a cast, causes breakouts in some formulas, or simply gets forgotten. Your job is not to lecture. It is to help each client find a formula they will actually use every day — because the best sunscreen is the one that gets worn.

## 5.2 UV radiation in plain language

Sunlight contains two types of ultraviolet radiation that matter for skin:

- **UVA** penetrates deeply, is present all day and all year, and passes through window glass and cloud. It is the main driver of photoageing — wrinkles, loss of elasticity, uneven pigmentation — and it contributes to skin cancer risk. It does not cause sunburn, which is why its damage is easy to ignore.
- **UVB** is stronger in summer and at midday, does not pass through glass, and causes sunburn. It is the main driver of direct DNA damage and skin cancer risk.

Both matter, every day, in every season. "I don't need sunscreen in winter" and "I work indoors" are both wrong: UVA comes through windows and clouds, and cumulative low-level exposure adds up over years. The damage is cumulative and largely irreversible — which is why starting now matters more than starting perfectly.

## 5.3 SPF and broad spectrum: what the numbers mean

**SPF (sun protection factor)** measures protection against UVB — the burning rays. SPF 30 blocks about 97% of UVB; SPF 50 blocks about 98%. The difference between SPF 30 and SPF 50 is small, and the difference between SPF 50 and SPF 100 is smaller still. Higher SPF is not a reason to apply less or reapply less often. The practical point: SPF 30 is adequate for most daily use; SPF 50 is a sensible choice for extended outdoor time, fair skin, or anyone who tends to under-apply (which is almost everyone).

**Broad spectrum** means the product also protects against UVA. Always choose broad spectrum. In many countries this is regulated and labelled; where it is not, look for UVA protection indicators (such as PA ratings or the UVA circle logo).

**Water resistance** is measured in minutes (40 or 80) and means the product retains protection after water exposure under test conditions — not that it is waterproof. Reapply after swimming or heavy sweating regardless.

## 5.4 Mineral versus chemical filters

Sunscreens use one or both types of UV filter:

**Mineral (inorganic) filters** — zinc oxide and titanium dioxide — sit on the skin surface and scatter and absorb UV. They work immediately on application, are generally well tolerated by sensitive skin, and are the usual recommendation for children and for reactive skin. Their main drawback is white cast, which is most visible on deeper skin tones, although modern formulations (micronised particles, tints) have improved this considerably.

**Chemical (organic) filters** — such as avobenzone, octocrylene, and newer filters — absorb UV and convert it to heat. They tend to be lighter, sheerer, and easier to wear daily, with no white cast. Some people find them irritating around the eyes, and some older chemical filters have raised environmental questions (notably around coral reefs). The evidence for harm to human health from approved chemical filters at normal use levels is not established; the evidence for harm from UV exposure is certain. Do not let an unproven worry about filters outweigh a proven risk from the sun.

**Hybrids** combine both types and are often the best compromise: good protection, good wearability, less cast.

**The right recommendation:** the best sunscreen is the one the client will wear. For a client with deeper skin who hates white cast, recommend a chemical or tinted formula — do not insist on mineral. For a client with reactive skin, recommend mineral. For a client who wears makeup, recommend a formula that layers well under it. Fit the product to the person, not the person to the product.

## 5.5 How to apply sunscreen correctly

Most people apply far too little. The tested amount is about 2 mg per square centimetre of skin — in practice, roughly a teaspoon (5 ml) for the face and neck, or the "two finger lengths" rule: a line of product along the index and middle fingers, applied to the face and neck. Apply as the last step of the morning routine, after moisturiser, and wait a few minutes before makeup.

**Reapplication:** every two hours during continuous sun exposure, and after swimming, sweating heavily, or towelling off. For a normal indoor day, a single morning application is reasonable; for a day with a long lunch outdoors, reapply before going out. Sunscreen in makeup or moisturiser (SPF 15 in a foundation, for example) does not count as adequate protection — the amount applied is far too small, and it is not reapplied.

**Common mistakes to correct gently:** applying sunscreen only on sunny days; applying it only on the face and forgetting the neck, ears, and hands; using a product that expired last year (check the date — expired sunscreen may have degraded filters); and assuming a high SPF means no reapplication is needed.

## 5.6 Sunscreen and specific concerns

- **Breakout-prone skin:** choose a lightweight, oil-free or gel formula labelled non-comedogenic. If a sunscreen causes breakouts, the answer is a different formula, not no sunscreen.
- **Sensitive skin:** mineral formulas are usually best tolerated; avoid fragrance and drying alcohols.
- **Deeper skin tones:** prioritise sheer chemical or tinted mineral formulas to avoid white cast. Reassure clients that sunscreen is still necessary — skin cancer occurs in all skin tones, and hyperpigmentation worsens with UV exposure.
- **Children:** mineral formulas are the usual recommendation, along with hats and shade. Sunscreen is not recommended for babies under six months — shade and clothing are the protection at that age. (Parents should confirm current guidance with their child's doctor.)
- **Vitamin D:** a common worry. The evidence is that normal daily sunscreen use does not cause vitamin D deficiency in most people, because people rarely apply enough sunscreen perfectly enough to block all UV, and vitamin D also comes from diet and supplements. Anyone concerned about vitamin D should discuss testing and supplementation with their doctor — not stop using sunscreen.

## 5.7 Beyond sunscreen: the full sun-protection routine

Sunscreen is one part of sun protection, not the whole of it. The full set: seek shade during peak hours (roughly 10 a.m. to 4 p.m.), wear a wide-brimmed hat and sunglasses, wear protective clothing (long sleeves, UPF-rated fabrics for extended exposure), and avoid tanning beds entirely — tanning beds are a known source of UV damage and skin cancer risk, and no skincare routine can undo their effect. Teach clients that sunscreen is the last line of defence, not the first.

## 5.8 Key takeaways

- Sunscreen is the single most evidence-based skincare step. Everything else is secondary.
- Use broad-spectrum SPF 30 or higher, every day, in every season, including indoors near windows.
- Apply enough: about a teaspoon for face and neck. Reapply every two hours outdoors.
- Mineral suits sensitive skin; chemical and hybrid formulas suit deeper skin tones and daily wear. The best sunscreen is the one that gets worn.
- Sunscreen does not cause vitamin D deficiency in most people; tanning beds are never a safe option.

## 5.9 Practice task

Find three sunscreens — one mineral, one chemical, one hybrid — and compare them on: SPF, broad-spectrum labelling, finish (cast, feel), price per millilitre, and who each would suit best. Write your comparison in the workbook (Exercise 5.1). If you can, try each on the back of your hand and note the cast and feel honestly.

---

# Module 6 — Routine Architecture: Building Safe Routines in the Right Order

## 6.1 The principle: fewer steps, done consistently

A good routine is one the client will actually follow every day. Three steps done daily beat ten steps done twice a week. Every addition to a routine must earn its place: it must do something the existing steps do not, and the client must be willing to do it. When in doubt, remove a step rather than add one.

This module gives you the architecture — the order, the timing, and the rules for adding and removing products — that the worked builds in Module 7 are based on.

## 6.2 The order of application

The general rule is **thinnest to thickest**: light, watery products first; heavy creams and oils last. The more specific rules:

1. **Cleanser** (evening always; morning usually).
2. **Treatment products that need direct skin contact** — exfoliating acids and retinoids go on clean, dry skin.
3. **Water-based serums** (vitamin C, hyaluronic acid, niacinamide) — thinnest first if using more than one.
4. **Moisturiser** — seals in the layers beneath it.
5. **Sunscreen** (morning, last step) — always last, because it needs to form an even film on the surface. Applying moisturiser over sunscreen disturbs that film and reduces protection.

**Wait times:** you do not need to wait long between most steps — a minute for a serum to absorb is enough. The exception is retinoids and acids on damp skin: apply them to dry skin, because damp skin increases penetration and irritation. After cleansing, wait a few minutes or pat dry thoroughly before applying a retinoid or acid.

**What not to layer:** do not apply a retinoid and an exfoliating acid at the same time when starting out; do not layer multiple strong actives in one routine; do not apply vitamin C and a strong acid together if the client has sensitive skin (the combined low pH increases stinging). When you are unsure, separate them — one in the morning, one at night, or on alternate days.

## 6.3 Morning and evening: what belongs where

**Morning routine — the goal is protection:**

1. Cleanse (or rinse with water for dry/sensitive skin).
2. Vitamin C serum (optional but well supported).
3. Moisturiser (if needed — some people skip it in the morning if their sunscreen is moisturising enough).
4. Sunscreen (non-negotiable).

The morning routine is short on purpose. It protects against the day's damage. Antioxidants belong here because they complement sunscreen.

**Evening routine — the goal is repair and treatment:**

1. Cleanse (double cleanse if wearing sunscreen and makeup).
2. Treatment step: retinoid or exfoliating acid, on alternate nights when both are used.
3. Moisturiser — usually richer than the morning one.

The evening routine is where actives live, because the skin is not being exposed to sun, and because retinoids in particular are best used at night (some degrade in sunlight, and they increase sun sensitivity).

**A note on "skin cycling":** the popular routine pattern — exfoliation night, retinoid night, recovery nights, repeat — is a sensible way to organise actives for people who want both an acid and a retinoid. It is not a new discovery; it is simply a schedule that prevents overuse. If it helps a client stick to a safe pattern, use it. If it overcomplicates things, a simpler alternate-nights schedule does the same job.

## 6.4 The starter routine: where everyone begins

Before adding any active, every client should have a stable baseline routine running comfortably for two weeks:

- **Morning:** gentle cleanser (or water rinse), moisturiser, sunscreen.
- **Evening:** gentle cleanser, moisturiser.

That is the whole starter routine. If a client cannot maintain this, they are not ready for actives — and the honest advice is to fix the baseline first. Most skincare problems are baseline problems: the cleanser is too harsh, the moisturiser is wrong for the skin type, or sunscreen is missing. Fix those before reaching for a serum.

## 6.5 Adding actives: the rules

1. **One at a time.** Add one active, wait two to four weeks, assess tolerance, then consider the next.
2. **Start low and infrequent.** The lowest effective concentration, two to three times a week, increasing only if the skin is comfortable.
3. **Introduce at night.** Most actives that cause irritation (retinoids, acids) belong in the evening routine, where sun exposure is not a factor and the skin has hours to recover.
4. **Buffer if needed.** Applying moisturiser before a retinoid (the "sandwich method") or mixing a small amount of a strong product with moisturiser can reduce irritation while the skin adjusts. This slightly reduces the active's effect, which is an acceptable trade for tolerance.
5. **Never add an active during a flare.** If the skin is irritated, red, or broken out unusually, the routine goes back to baseline until it calms down. Adding a new product to irritated skin is how small problems become large ones.

## 6.6 Patch testing: the non-negotiable step

Every new product should be patch tested before full-face use, especially for sensitive skin and especially for actives. The method:

1. Apply a small amount of the product to a discreet area — behind the ear or on the inner forearm — once a day for three to seven days.
2. Watch for redness, itching, swelling, bumps, or burning.
3. If there is no reaction, apply to a small area of the face (for example, along the jawline) for a few more days.
4. If there is still no reaction, begin normal use at the intended frequency.

A patch test does not guarantee that a product will never irritate — some reactions appear only with repeated full-face use, and some ingredients cause irritation rather than allergy, which a patch test may not predict. But it catches the clearest problems before they reach the whole face, and it is a professional standard. Teach it to every client, and follow it yourself.

**Allergy versus irritation:** an allergic reaction (redness, itching, swelling, sometimes spreading beyond where the product was applied) is a reason to stop the product entirely and not retry it. Irritation (mild stinging, dryness, flaking that appears with frequent use and improves when use is reduced) is often a matter of frequency and concentration. When in doubt, treat it as allergy: stop the product, and if the reaction is severe, spreading, or involves swelling of the lips or eyes or difficulty breathing, seek medical attention promptly.

## 6.7 Seasons, life stages, and routine changes

Routines should change with circumstances:

- **Winter:** colder, drier air increases water loss. Switch to a richer moisturiser, consider a humidifier indoors, and reduce exfoliation frequency if skin becomes reactive.
- **Summer:** heat and humidity increase oil and sweat. A lighter moisturiser, more diligent sunscreen reapplication, and attention to cleansing after sweating.
- **Pregnancy:** retinoids and high-concentration salicylic acid are avoided as a standard precaution; anyone pregnant should discuss all skincare with their doctor. Gentle cleansing, moisturising, sunscreen, niacinamide, and vitamin C are generally considered compatible, but the doctor's advice governs.
- **Ageing:** as skin becomes drier and thinner, richer moisturisers and gentler actives matter more; retinoid concentrations may need to be reduced, not increased.
- **Travel and climate change:** a routine built for a humid climate may fail in a dry one. The fix is usually the moisturiser, not the actives.

The rule: change one thing at a time, and give each change two weeks before judging it.

## 6.8 How long to wait for results

Set expectations honestly, because unrealistic timelines are the main reason people abandon good routines and chase trends:

- **Hydration and comfort:** days to one week.
- **Texture and brightness:** two to four weeks.
- **Breakouts and congestion:** four to eight weeks (and sometimes a temporary worsening when starting retinoids — the "purge" — which is real but should be mild and should pass within a few weeks; severe worsening is not a purge, it is a reaction).
- **Uneven tone and dark marks:** eight to twelve weeks minimum, often longer.
- **Fine lines:** three to six months.

If a client has used a product correctly for the full expected period with no improvement, the product is not working for them — change it, rather than increasing the strength in frustration.

## 6.9 Key takeaways

- Fewer steps, done consistently, beat a long routine done sporadically.
- Order: thinnest to thickest; sunscreen always last in the morning.
- Everyone starts with the same baseline — cleanser, moisturiser, sunscreen — for two weeks before any active is added.
- Add one active at a time, start low and infrequent, and never add during a flare.
- Patch test every new product. Allergy means stop entirely; irritation usually means reduce frequency.
- Set honest timelines: hydration in days, tone in weeks, fine lines in months.

## 6.10 Practice task

Build your own starter routine using the routine-builder worksheet in the workbook (Exercise 6.1). Follow it for two weeks and note what happens: comfort, shine, breakouts, and whether you actually stuck to it. Then add one active using the rules in this module and track the first four weeks. Your own experience of the adjustment period will make you a better adviser than any amount of reading.

---

# Module 7 — Six Skin Profiles: Fully Worked Routine Builds

This is the module you will return to most. Each profile below is a complete routine build: assessment notes, the reasoning, a morning routine, an evening routine, what to add over time, what to avoid, and what to tell the client about expectations. Product types are described by ingredient and function, not by brand, so the builds stay useful regardless of which products are available. Prices are not given for individual products because they vary by market — the builds are designed to work with affordable options at every step.

**How to use these builds:** match the client to the closest profile, then adjust. No real person matches a profile exactly. The builds are starting points with clear reasoning, so you can adapt them with confidence.

---

## Profile 1 — Oily, Breakout-Prone Skin (with Dehydration)

**Who this is:** A client in their twenties or thirties whose skin is shiny by midday, with frequent blackheads on the nose and chin and occasional breakouts, but who also says their skin feels tight after washing. This is the most commonly misunderstood profile: the tightness is dehydration and barrier stress, usually caused by harsh cleansing and drying products, while the breakouts come from congestion, not from "dirt."

**Assessment notes:** Shine across the T-zone and cheeks by midday; visible pores on the nose; blackheads; occasional inflamed spots; skin feels tight after cleansing. The client is probably using a strong foaming cleanser, possibly a scrub, and may be skipping moisturiser entirely because they believe it will make them oilier.

**The reasoning:** Stop stripping the barrier — that is step one, before any acne-targeted product. Add a BHA for congestion, because it is oil-soluble and works inside pores. Keep moisturising light but consistent. Sun protection must be a formula that does not feel heavy, or it will not be worn.

**Morning routine:**

1. Gentle gel cleanser — a mild foaming or gel formula, fragrance-free. Lukewarm water, 30–60 seconds, pat dry.
2. Niacinamide serum (2%–5%) — supports the barrier and reduces the appearance of redness and oiliness.
3. Light gel or gel-cream moisturiser — humectant-based with a small amount of emollient (squalane or dimethicone). No heavy occlusive in the daytime.
4. Oil-free, broad-spectrum sunscreen SPF 30–50 — a gel or fluid formula that dries down matte or sheer.

**Evening routine:**

1. Gentle gel cleanser — double cleanse only if wearing heavy makeup; otherwise a single cleanse is enough.
2. Salicylic acid (BHA) 2% — two to three nights a week at first, on clean dry skin. Leave for a few minutes before the next step.
3. Light gel-cream moisturiser — the same as the morning, or a slightly richer lotion if the skin feels dry.

**Adding over time (after 4 weeks of tolerance):**

- Introduce a retinoid (adapalene 0.1% or retinol 0.1%–0.3%) on alternate nights from the BHA. Do not use both on the same night when starting. The retinoid addresses cell turnover and the longer-term picture; the BHA handles congestion.
- If breakouts remain frequent after 8–12 weeks of consistent use, that is a referral conversation, not a reason to add more products.

**What to avoid:** harsh sulfate cleansers, physical scrubs, alcohol-based toners, "drying" spot treatments used all over the face, and skipping moisturiser. Also avoid the temptation to cleanse more than twice a day — it does not reduce oil and it damages the barrier.

**What to tell the client:** "Your skin is oily and dehydrated at the same time — that is common, and it is why it feels tight and looks shiny. We are going to cleanse gently, moisturise lightly, and use one targeted product for the congestion. Expect the tightness to ease within a week. Expect the blackheads to improve over four to eight weeks. If breakouts become painful, widespread, or leave scars, we will talk about seeing a dermatologist — that is a normal next step, not a failure."

---

## Profile 2 — Dry, Sensitive Skin with a Compromised Barrier

**Who this is:** A client whose skin feels tight and uncomfortable most of the time, looks dull or flaky, stings when they apply products that never used to sting, and reacts to fragrance and strong actives. Often the history includes over-exfoliation — daily acids, a strong retinoid started too fast, or a harsh scrub — and the barrier needs repair before anything else happens.

**Assessment notes:** Flaking or roughness, especially on the cheeks; redness that comes and goes; stinging on product application; skin feels tight within minutes of washing. The client may have a long list of products they have tried and abandoned.

**The reasoning:** Repair first, treat later. Every active is paused. The routine is reduced to the gentlest possible baseline with barrier-repair ingredients, and nothing new is added for at least four weeks. This is the profile where doing less is the treatment.

**Morning routine:**

1. Lukewarm water rinse only (no cleanser) — or, if the client prefers a cleanser, a fragrance-free cream or milk cleanser used very gently.
2. Hydrating serum or light lotion with glycerin and hyaluronic acid — applied to slightly damp skin.
3. Rich barrier-repair cream — ceramides, cholesterol, fatty acids, squalane, and a modest occlusive. Fragrance-free.
4. Mineral sunscreen SPF 30–50 — fragrance-free, chosen for tolerance. If sunscreen stings, try a different mineral formula before concluding sunscreen cannot be worn.

**Evening routine:**

1. Fragrance-free cream or milk cleanser — gentle, no rubbing, pat dry.
2. Same hydrating step as the morning (optional — the cream alone may be enough).
3. Rich barrier-repair cream — a generous layer. Two to three nights a week, a thin layer of petrolatum over the cream on the driest areas can accelerate recovery.

**Adding over time (after 4–6 weeks, only if the skin is calm):**

- Niacinamide 2%–5% — the safest first active for this profile, supporting the barrier further.
- After another four weeks of tolerance, a very gentle PHA (gluconolactone) once a week for dullness — or lactic acid 5% if the skin tolerates it. Stop immediately if stinging returns.
- Retinoids are deferred until the barrier has been stable for at least two months, and then introduced at the lowest concentration, twice a week, buffered with moisturiser.

**What to avoid:** all exfoliating acids, retinoids, vitamin C in its pure ascorbic acid form, fragrance, essential oils, physical scrubs, hot water, and cleansing brushes — until the barrier has recovered. Also avoid the urge to try a new "soothing" product every week; stability is the point.

**What to tell the client:** "Your skin barrier is damaged, which is why everything stings. The good news is that barriers repair — but they need calm and consistency, not more products. We are going to use three gentle products for a month and nothing else. It will feel boring. That is the point. Once your skin stops stinging, we will add things back one at a time, slowly. If redness, flaking, or stinging does not improve in four weeks, or if it worsens, we will talk about seeing a dermatologist."

---

## Profile 3 — Combination Skin, First Routine (Skincare Beginner)

**Who this is:** A client who has never had a routine — or whose routine is a single bar of soap — and who wants to start properly. Oily in the T-zone, normal to slightly dry on the cheeks, no major concerns beyond occasional dullness and the first signs of fine lines. This is the most rewarding profile to work with, because the improvements are quick and visible.

**Assessment notes:** Shine on the forehead and nose by afternoon; cheeks comfortable; occasional dullness; no persistent redness or breakouts. The client is motivated but overwhelmed by choice and by conflicting advice online.

**The reasoning:** Keep it minimal and build the habit first. The beginner's enemy is not the wrong product — it is a routine so complicated it gets abandoned in two weeks. Three steps, then one active, then reassess.

**Morning routine:**

1. Gentle gel or cream cleanser — a mild, fragrance-free formula suited to combination skin.
2. Lightweight lotion moisturiser — a medium-weight lotion with glycerin, ceramides, and squalane.
3. Broad-spectrum sunscreen SPF 30 — a formula that feels comfortable and layers well; let the client choose between mineral and chemical based on feel and cast.

**Evening routine:**

1. Gentle cleanser — the same as the morning.
2. Lightweight lotion moisturiser — the same as the morning, applied slightly more generously on the cheeks if they feel dry.

**Adding over time (after 2 weeks of a stable baseline):**

- Week 3: niacinamide 2%–5% in the morning, under moisturiser.
- Week 6 (if the niacinamide is well tolerated): retinol 0.1%–0.3% two nights a week, increasing to three or four nights over the following month. Apply after cleansing on dry skin, followed by moisturiser.
- Month 3: consider a gentle AHA (lactic acid 5%) once a week for dullness, on a night when retinol is not used.

**What to avoid:** buying a full set of products at once; starting retinol and an acid in the same week; and any product marketed with urgency ("anti-ageing miracle," "instant results"). Also avoid the idea that more expensive means more effective — for this profile, affordable basics perform as well as premium ones.

**What to tell the client:** "You do not need ten products. You need three, used every day, and then we add one thing at a time so we know what is working. In two weeks your skin should feel more comfortable. In a month it should look brighter. The retinol is the long game — it works over months, not days, and that is normal. If anything stings or peels badly, tell me and we slow down. There is no prize for pushing through irritation."

---

## Profile 4 — Mature Skin (50s–60s): Dryness, Fine Lines, and Uneven Tone

**Who this is:** A client in their fifties or sixties with skin that has become drier and thinner, fine lines around the eyes and mouth, uneven pigmentation from decades of sun exposure, and a loss of firmness. They may have used the same products for years and are now finding them insufficient, or they may be starting skincare for the first time.

**Assessment notes:** Dryness and fine flaking, especially on the cheeks; visible fine lines; brown spots or uneven tone; skin feels thin and is slow to recover from irritation. The client may be concerned about "looking old" — handle that with respect and honesty about what skincare can and cannot do.

**The reasoning:** Hydration and barrier support matter more than ever, because the skin produces less oil and recovers more slowly. Retinoids are the priority active, but they must be introduced gently — mature skin tolerates irritation less well, and overdoing it causes prolonged redness. Sun protection is essential to prevent further pigmentation. Be honest: skincare can improve texture, tone, and the appearance of fine lines, but it cannot restore the firmness of younger skin. That is not a failure of the products; it is the limit of what topical skincare does.

**Morning routine:**

1. Cream or milk cleanser — gentle, fragrance-free, lukewarm water.
2. Vitamin C serum (10%–15% ascorbic acid, or a derivative if the skin is reactive) — for brightening and antioxidant support.
3. Rich cream moisturiser — ceramides, cholesterol, squalane, hyaluronic acid, and a meaningful occlusive component.
4. Broad-spectrum sunscreen SPF 30–50 — daily, without exception. A moisturising formula can double as the morning moisturiser for clients who prefer fewer steps.

**Evening routine:**

1. Cream cleanser — double cleanse if wearing sunscreen and makeup.
2. Retinol 0.1%–0.3% — two nights a week at first, buffered with moisturiser (the sandwich method), increasing slowly over two months if tolerated.
3. Rich cream moisturiser — a generous layer; a thin occlusive layer on the driest areas two to three nights a week.

**Adding over time (after 8 weeks of retinoid tolerance):**

- A gentle AHA (lactic acid 5%) once a week on a non-retinoid night, for texture and brightness.
- A peptide serum if the client wants an additional step and understands it is a supporting ingredient, not a primary treatment.

**What to avoid:** strong glycolic acid peels used at home, high-concentration retinoids started abruptly, fragranced products, and any treatment promising to "erase" wrinkles or "lift" skin without a procedure. Also avoid hot water and harsh cleansing, which worsen dryness.

**What to tell the client:** "Your skin needs moisture and protection more than it needs strong treatments, and the strongest treatment we have — a retinoid — works best when we introduce it slowly. Expect your skin to feel more comfortable within a couple of weeks, and the tone to look more even over two to three months. Skincare can soften the appearance of fine lines and improve texture, but it cannot lift skin or replace lost volume — anyone who promises that from a cream is not being honest with you. What we can do is help your skin look as healthy as possible, and protect it from further sun damage, which is the part we can still change."

---

## Profile 5 — Deeper Skin Tone: Hyperpigmentation and Uneven Tone

**Who this is:** A client with Fitzpatrick type IV–VI skin whose main concern is dark marks — left after breakouts, or from sun exposure — and uneven tone. The skin may otherwise be healthy: normal to oily, with no major dryness. The key risk in this profile is that irritation from treatment causes more pigmentation, so every step must be chosen to minimise irritation.

**Assessment notes:** Dark marks where breakouts have healed; uneven tone, often worse on the cheeks and forehead; possible sensitivity to strong actives tried in the past. Ask directly about the client's experience: how long do marks take to fade? Have products caused new dark marks before? That history is the most important information you will gather.

**The reasoning:** Sun protection is the treatment, not just a supporting step — UV exposure deepens existing marks and creates new ones, so without daily sunscreen, no brightening product can succeed. Actives are introduced one at a time, at low concentrations, with generous intervals, because the cost of irritation is higher here than in any other profile. Gentle, consistent treatment over months beats aggressive treatment that causes a flare.

**Morning routine:**

1. Gentle gel or cream cleanser — fragrance-free, suited to the client's oil level.
2. Vitamin C serum — a derivative form (sodium ascorbyl phosphate or ascorbyl glucoside) if the skin is reactive, or 10% ascorbic acid if tolerated. This is the primary brightening step.
3. Niacinamide 2%–5% — supports tone and the barrier.
4. Lightweight moisturiser — if needed.
5. Broad-spectrum sunscreen SPF 30–50 — a sheer chemical or tinted mineral formula with no white cast. This is non-negotiable and should be presented as such: the marks will not fade without it. Help the client find a formula they like enough to wear daily.

**Evening routine:**

1. Gentle cleanser.
2. Retinoid — retinol 0.1% at first, two nights a week, buffered with moisturiser, increasing slowly. Alternatively, a gentle retinaldehyde formula.
3. Moisturiser — a medium-weight cream with ceramides and niacinamide.

**Adding over time (after 8 weeks of tolerance):**

- A gentle exfoliant — mandelic acid or lactic acid 5%, once a week — for texture and to support tone. Mandelic acid is particularly suitable here because its large molecule size means slower penetration and lower irritation.
- Ingredients that target pigmentation specifically, such as azelaic acid (10%–15%, available over the counter in some countries and by prescription in others) or tranexamic acid, can be discussed — azelaic acid has good evidence for post-inflammatory hyperpigmentation and is generally well tolerated, including in deeper skin tones. Anyone considering prescription-strength options should discuss them with a dermatologist.

**What to avoid:** strong glycolic acid peels, high-concentration retinoids started quickly, physical scrubs, hydroquinone without medical supervision (it is prescription-only in many countries and carries risks, including paradoxical darkening, if misused), and any product promising to "bleach" or "whiten" skin. Avoid the language of lightening as a goal — the goal is even tone and healthy skin, not lighter skin.

**What to tell the client:** "Dark marks fade, but slowly — think months, not weeks — and the single most important step is sunscreen, because sun exposure keeps the marks dark. We are going to use gentle brightening ingredients and introduce them slowly, because irritation can cause new marks, and that would undo the progress. Expect to see the marks start to soften in eight to twelve weeks. If a product stings or causes redness, stop it and tell me — pushing through is not worth it for your skin. If the marks are very deep or do not improve after several months of consistent care, a dermatologist has prescription options that go further than cosmetics, and that is a reasonable next step."

---

## Profile 6 — Rosacea-Prone / Persistently Reactive Skin (Cosmetic Support Only)

**Who this is:** A client who flushes easily, has persistent redness on the cheeks and nose, and finds that many products sting. They may already have a diagnosis of rosacea from a doctor, or they may simply be highly reactive. This profile comes with a clear boundary: **you are providing cosmetic support, not treatment.** If the client has not seen a doctor about persistent redness, your first recommendation is to do so.

**Assessment notes:** Persistent redness (not just occasional flushing), visible blood vessels, skin that stings with many products, possible bumps that resemble breakouts but do not behave like them. Triggers may include heat, alcohol, spicy food, and sun exposure — ask about these, because avoiding triggers is part of the picture.

**The reasoning:** The routine is minimal, gentle, and boring by design. The goal is to reduce irritation, support the barrier, and protect from sun — all of which help the skin look calmer. No exfoliating acids, no retinoids, no vitamin C in its pure form, no fragrance, no essential oils. If the client is under a doctor's care, your routine must fit around their prescribed treatment, not compete with it — and you should ask what they have been prescribed so you can avoid conflicts.

**Morning routine:**

1. Lukewarm water rinse, or a very gentle fragrance-free cream cleanser.
2. Niacinamide 2%–5% (if tolerated — patch test first) or a soothing serum with panthenol.
3. Lightweight, fragrance-free moisturiser with ceramides.
4. Mineral sunscreen SPF 30–50 — fragrance-free. Mineral is preferred here because chemical filters can sting reactive skin. A tinted mineral formula can also help visually soften redness, which many clients appreciate.

**Evening routine:**

1. Very gentle cream cleanser — no rubbing, lukewarm water, pat dry.
2. Fragrance-free moisturiser with ceramides — a generous layer. Azelaic acid 10% (over the counter where available) may be added later if the client's doctor agrees it fits with their treatment, because it has evidence for reducing redness in rosacea — but only with medical agreement, and only introduced slowly.

**Adding over time:** Very little, and very slowly. If the skin is stable for two months, a PHA (gluconolactone) once a week may be tried for texture — and stopped at the first sign of increased redness. That is the full extent of "adding actives" for this profile. The discipline is in what you do not add.

**What to avoid:** exfoliating acids (especially glycolic), retinoids, pure vitamin C, fragrance, essential oils, alcohol-based products, physical scrubs, hot water, steam, and harsh cleansing tools. Also avoid products marketed as "anti-redness" that contain fragrance or strong actives — read the label, not the claim.

**What to tell the client:** "Your skin is reactive, so our job is to calm it, not to treat it aggressively. I am going to keep your routine very simple — a gentle cleanser, a barrier moisturiser, and sunscreen — because that is what helps reactive skin most. If you have not spoken to a doctor about the persistent redness, I strongly recommend that you do: there are medical treatments for rosacea that cosmetics cannot replace, and a doctor can tell you whether that is what is going on. What I can do is make sure nothing in your routine makes it worse, and help your skin feel more comfortable day to day. If the redness worsens, or you develop eye irritation, bumps that do not heal, or swelling, please see a doctor promptly — and tell me so we can simplify the routine further."

**Referral note for this profile:** persistent facial redness with visible blood vessels, eye irritation, or bumps that do not behave like ordinary breakouts should be assessed by a doctor or dermatologist. Do not attempt to manage it with cosmetics alone, and do not let a client delay medical care because a routine is "helping a little." Cosmetic support and medical care are complementary, not alternatives.

---

## 6.11 A final word on the six builds

Notice what the six builds have in common: every one starts with gentle cleansing, moisturising, and sun protection. Every one introduces actives slowly. Every one has a clear list of things to avoid. And every one ends with an honest conversation about expectations. The differences between the builds are real — different actives, different textures, different speeds — but the structure is the same. That structure is the skill this course teaches. Learn it, and you can build a routine for a seventh, eighth, or hundredth profile that is not in this book.

## 6.12 Practice task

Choose the profile closest to your own skin, and build the routine from this module using the routine-builder worksheet in the workbook (Exercise 7.1). Then choose a second profile — one unlike your own — and build that routine too, writing down your reasoning for each choice. Compare the two builds and note what changed and what stayed the same. The similarities are the core of the method.

---

# Module 8 — The Client Consultation: Communication, Documentation, and Ethics

## 8.1 The consultation is the product

A routine is only as good as the consultation that produced it. Two professionals can recommend the same products; the one who listened, asked good questions, set honest expectations, and documented the plan will get better results and keep the client. This module teaches the consultation as a skill, not a formality.

## 8.2 Before the consultation

Prepare the space and the paperwork. Have the client consultation form (templates/client-consultation-form.md) ready, a pen or a clean digital copy, and a quiet place to talk. If you are working in a salon or clinic, make sure you have good, natural light for observation — harsh overhead lighting and dim rooms both distort what you see. Wash your hands before touching a client's face, and ask permission before you do.

Check your own knowledge before the client arrives: review the six profiles in Module 7 and the ingredient table in Module 4, so you are not searching your memory mid-conversation.

## 8.3 The consultation conversation

A good consultation takes 20–30 minutes and follows a natural arc. Use the form as a guide, not a script.

**1. Listen first (5–10 minutes).** Start with an open question: "Tell me about your skin — what bothers you, and what have you tried?" Let the client talk. Listen for: what they have tried and what happened, what they hope to achieve, what they are willing to do daily, and what their budget is. Do not interrupt to correct them; note what they say, including misconceptions, and return to them gently later.

**2. Ask the structured questions.** Cover the essentials: current routine (every product, how long they have used it, how often); skin history (breakouts, reactions, allergies, known sensitivities); medical history relevant to skin (current skin conditions, medications that affect skin, pregnancy or plans to become pregnant, recent procedures); lifestyle (sun exposure, work environment, climate, sleep, stress); and goals (what would "better" look like to them, in their words).

**3. Observe.** With permission, look at the skin in good light. Note type, condition, and any signs that fall outside ordinary cosmetic concern (see 8.5). Keep your observations factual and neutral: "I can see some dryness on the cheeks and shine in the T-zone" is useful; "Your skin looks terrible" is not — and should never be said.

**4. Explain in plain language.** Use the barrier explanation from Module 1. Translate every technical term. Check understanding: "Does that make sense so far?" is a genuine question, not a formality. If the client looks confused, you have not explained it well enough yet.

**5. Recommend, with reasons.** Present the routine step by step, explaining why each product is there and what it does. Give the client the reasoning, not just the list — a client who understands why they are using a gentle cleanser is far more likely to keep using it than one who was simply told to buy it.

**6. Set expectations and agree the plan.** State the timeline honestly (Module 6.8). Agree what the client will do, what you will do (follow-up, check-in), and when you will review. Write it down. Give the client a copy of the plan — the routine-builder worksheet from the workbook is designed for exactly this.

## 8.4 Language that helps — and language that harms

**Helpful language:** "Let's build this slowly so we know what is working." "This usually takes eight to twelve weeks." "If it stings, stop and tell me." "That is a normal adjustment." "Seeing a dermatologist is a good next step — it does not mean the routine failed."

**Harmful language:** anything that guarantees a result ("This will clear your skin"), anything that shames ("You have been ruining your skin"), anything that creates urgency ("You need to start this today or the damage will be permanent"), and anything that presents a cosmetic product as a medical treatment ("This treats eczema"). Also avoid diagnosing: "You have rosacea" is a diagnosis and is not yours to make. "This redness has been persistent, and I think a doctor should look at it" is a referral, and it is exactly right.

**Talking about appearance:** be respectful and neutral. Clients are often self-conscious. Compliment effort, not features. Never comment on weight, age, or attractiveness. If a client asks "Do I look old?", answer honestly and kindly: focus on what skincare can improve (texture, tone, comfort) and what it cannot, without endorsing the idea that ageing is a problem to be fixed.

## 8.5 When to refer: the red flags

Refer to a doctor or dermatologist when you see any of the following. This list is not exhaustive, and when in doubt, refer — a referral is never the wrong call.

- A mole or spot that is new, changing, bleeding, itchy, or looks unusual in shape, colour, or size.
- A sore or wound that does not heal within a few weeks.
- Persistent, widespread, painful, or scarring acne.
- A rash that is spreading, blistering, oozing, or severely itchy.
- Persistent facial redness with visible blood vessels, eye irritation, or bumps that do not behave like ordinary breakouts.
- Hair loss in patches, or sudden and severe hair loss.
- Any skin problem that is getting worse despite a gentle routine, or that returns immediately when a product is stopped.
- A reaction with swelling of the lips, eyes, or face, or difficulty breathing — seek urgent medical attention.

**How to refer without alarming the client:** "What you are describing is outside what skincare alone can address, and the right person to look at it is a dermatologist. That is a normal part of good skincare — knowing when a specialist is the best next step. I will keep your routine gentle in the meantime, and we can review it once you have seen them." Keep a list of local dermatologists and clinics to hand, so the referral is practical, not vague.

## 8.6 Documentation: why it matters and what to record

Document every consultation. It protects the client (you can see what changed and what worked), it protects you (you have a record of what you recommended and what you said), and it makes follow-up meaningful instead of guesswork.

Record: the date; the client's concerns in their own words; your observations (type, condition, any relevant notes); the full current routine, including products the client was already using; allergies and sensitivities; the routine you recommended and why; the expected timeline; any referral made and the reason; and the follow-up date. Store records securely and privately, in line with local data-protection rules, and never share a client's information without their consent.

The client consultation form in the templates folder is designed to capture all of this on one or two pages. Use it every time.

## 8.7 Ethics: selling, recommending, and conflicts of interest

You will sometimes recommend products you sell, or products from brands you have a relationship with. That is legitimate — but only if you are transparent about it. Tell the client when you sell a product you are recommending, and be honest when a cheaper alternative would do the same job. A client who discovers you recommended a premium product when an affordable one was equivalent will not trust your next recommendation.

Do not accept payment or commission for recommending a specific product unless the client knows about it. Do not exaggerate evidence to make a sale. Do not recommend products a client does not need. And never let a sales target change a recommendation — if the right routine for this client is three affordable products, that is the routine, even if a longer list would earn more.

**Scope of practice:** you are an educator and adviser, not a clinician. Stay inside that scope. Do not diagnose, do not prescribe, do not perform procedures you are not trained and licensed for, and do not present yourself as a dermatologist or doctor. Your credibility comes from being honest about your limits, not from pretending they do not exist.

## 8.8 Follow-up: the part most people skip

A consultation without follow-up is half a job. Schedule a check-in two to four weeks after the first routine is started, and again at eight to twelve weeks. At each follow-up, ask: Is the routine comfortable? Is anything stinging, peeling, or breaking out? Is the client actually following it — and if not, why? (The answer is often that a step is unpleasant, too expensive, or too complicated, and the fix is to change the product, not to lecture the client.) What has changed, and what has not? Adjust one thing at a time, document the change, and set the next check-in.

Follow-up is also where you catch problems early: a client who is quietly over-exfoliating, a product that is causing a slow reaction, or a skin change that needs referral. None of that is visible if you never ask.

## 8.9 Key takeaways

- Listen first. The consultation is a conversation, not a sales pitch.
- Explain in plain language, check understanding, and give reasons, not just product lists.
- Never diagnose, never guarantee a result, and never present a cosmetic as a treatment.
- Know the referral red flags and refer without hesitation — it is a sign of competence, not failure.
- Document every consultation and follow up at two to four weeks and again at eight to twelve weeks.
- Be transparent about any product you sell or earn from, and never let a sale change a recommendation.

## 8.10 Practice task

Role-play a consultation with a friend or colleague using the client consultation form. Have them play a client with a concern you have not prepared for. Afterwards, ask them: Did you feel listened to? Did you understand the explanation? Did you know what to do next? Write down what you would do differently next time (workbook Exercise 8.1).

---

# Module 9 — Troubleshooting, Myths, Trends, and Staying Current

## 9.1 Troubleshooting: the most common problems

**"My skin is breaking out since I started the new routine."** First, check the timeline. A mild increase in breakouts in the first two to four weeks of starting a retinoid is common (the "purge") and usually passes. A severe breakout, breakouts in new areas, or breakouts that worsen after four weeks is more likely a reaction — often to a new product, a comedogenic ingredient, or over-exfoliation. The response: stop the most recently added product first, return to the baseline routine, and reintroduce slowly. If breakouts are painful, widespread, or scarring, refer.

**"Everything stings now."** This is the signature of a damaged barrier, usually from over-exfoliation or a too-strong active. Stop all actives, return to gentle cleansing and a barrier-repair moisturiser, and wait two to four weeks. Do not add a "soothing" serum on top of a damaged barrier and expect it to fix the problem — removing the cause is the fix.

**"My skin is oilier than before."** Check whether the client has started skipping moisturiser or using a harsh cleanser. Dehydrated skin often looks oilier because the surface is compensating and the barrier is stressed. The fix is usually gentler cleansing and a light moisturiser, not stronger oil control.

**"The product did nothing."** Check three things: Was it used consistently for the full expected period (Module 6.8)? Was it used correctly (enough product, right step, right frequency)? And was it the right product for the concern? A vitamin C serum will not fix congestion; a BHA will not fix pigmentation quickly. If the product was used correctly for long enough and nothing changed, change the product — and say so plainly to the client.

**"My skin got worse in winter / on holiday / after moving."** Climate and season change what skin needs. The usual fix is the moisturiser (richer in dry cold, lighter in humid heat) and sunscreen diligence, not a new active.

**"I had a reaction."** Stop the product immediately. If the reaction is mild (redness, itching where applied), it should settle within a few days on a baseline routine. If it is severe, spreading, blistering, or involves swelling of the lips or eyes or difficulty breathing, seek medical attention promptly. Record the product and the reaction, and do not retry that product or products with the same key ingredient.

## 9.2 Myths, answered plainly

**"You need to open your pores with steam and close them with cold water."** Pores do not open and close — they are not doors. Steam softens the surface and can make extraction easier, but it does not change pore size, and cold water does not shrink pores. Pore appearance is determined mainly by oil production, skin elasticity, and congestion. The honest way to improve the look of pores is consistent cleansing, a BHA for congestion, sun protection, and (over time) a retinoid.

**"Natural means safe, and chemical means dangerous."** Everything is a chemical, including water and the ingredients in a plant. Some natural ingredients are excellent; some are potent irritants (poison ivy is natural). Some synthetic ingredients are among the safest and best-studied in skincare (petrolatum, dimethicone, niacinamide). Judge an ingredient by its evidence and its effect on skin, not by whether it grew in a field.

**"Drinking water hydrates your skin."** Drinking water is important for health, but it does not directly hydrate the skin surface in the way a moisturiser does. Dehydrated skin is a barrier problem, not a water-intake problem. Encourage clients to drink water for their general health, but do not present it as a skincare treatment.

**"You can detox your skin by sweating."** Sweat does not remove toxins from the body in any meaningful amount; the liver and kidneys do that. Saunas and exercise are good for general health, but they are not skincare, and the idea that sweating "purges" the skin is a myth. What exercise does for skin is improve blood flow — which is real, but it is not detoxification.

**"Expensive products work better."** Price reflects branding, packaging, marketing, and positioning — not effectiveness. Some of the best-supported products in skincare (petrolatum, glycerin-based moisturisers, basic sunscreens) are among the cheapest. Judge a product by its ingredient list and its evidence, not its price tag.

**"You should feel a product working — tingling means it is effective."** Tingling usually means irritation, not effectiveness. A product that stings is not "working harder"; it is stressing the barrier. The exception is a brief, mild tingle from a low-pH vitamin C or acid that passes in a minute — and even then, persistent or painful stinging is a sign to stop, not to push through.

**"Oily skin does not need moisturiser."** Oily skin needs moisturiser. Skipping it does not reduce oil production; it dehydrates the skin, damages the barrier, and often makes the shine worse. Oily skin needs a light moisturiser, not no moisturiser.

**"Sunscreen causes vitamin D deficiency."** Addressed in Module 5: normal daily sunscreen use does not cause vitamin D deficiency in most people, and anyone concerned should discuss testing and supplementation with their doctor.

**"Collagen cream replaces lost collagen."** Addressed in Module 1: topical collagen is too large to penetrate the barrier. It can hydrate the surface, but it does not become your collagen. Retinoids and sun protection are the evidence-based approach to supporting collagen.

**"You can shrink pores permanently / erase wrinkles with a cream / remove cellulite with a lotion."** No cosmetic product does any of these permanently. Be honest about that every time — it is the single most trust-building thing you can say to a client who has been promised otherwise.

## 9.3 Trends: how to judge a new one

New skincare trends appear constantly. Use this five-question test before recommending or dismissing any of them:

1. **What is the claim, exactly?** Vague claims ("detoxifies," "boosts radiance," "activates skin") are marketing language, not testable claims. A real claim names a mechanism and a measurable outcome.
2. **Is there a plausible mechanism?** Does the proposed explanation fit what you know about skin anatomy and ingredient behaviour (Modules 1 and 3)? If the mechanism requires an ingredient to do something it physically cannot do — like a large molecule penetrating to the dermis — the claim fails here.
3. **What is the evidence?** Is there a published study in people, or only laboratory work, animal studies, or testimonials? Who funded the study? How many people were involved, and for how long? A single small study funded by the manufacturer is a starting point, not proof.
4. **What is the risk?** Could this trend damage the barrier, cause irritation, increase sun sensitivity, or delay proper care? A low-risk trend (a new humectant, a gentler format) can be tried; a high-risk trend (a strong at-home peel, an unregulated device) should not be recommended without strong evidence.
5. **What would it replace?** If a trend would displace a proven step (sun protection, gentle cleansing, moisturising), it is a bad trade. Trends should add to a solid baseline, never replace it.

Apply this test to any trend — skin cycling, slugging, "glass skin" routines, LED masks, at-home microneedling, beef tallow, snail mucin, or whatever comes next — and you will rarely go wrong. The test does not require you to know every new product. It requires you to know the fundamentals well enough to judge a claim against them, which is exactly what this course has taught.

**A note on at-home devices and procedures:** LED masks, microcurrent devices, and at-home microneedling rollers are increasingly marketed to consumers. The evidence for home-use devices is mixed and generally weaker than for professional versions, and some carry real risks (infection from microneedling rollers, eye damage from poorly designed LED devices). Do not recommend procedures or devices outside your training and scope. If a client asks, explain the evidence honestly, note the risks, and suggest they discuss it with a qualified professional.

## 9.4 Staying current without chasing trends

Skincare knowledge changes, but slowly. The fundamentals in this course — barrier science, sun protection, retinoids, gentle cleansing — have been stable for decades. What changes is the detail: new ingredients, better formulations, refined understanding of the microbiome, and new evidence on existing ingredients.

Stay current by: reading summaries from dermatology associations and reputable medical sources rather than influencer content; checking whether a new claim has a published study behind it; revisiting this course's ingredient table (Module 4.7) when you encounter an ingredient you do not know; and being willing to change your mind when good evidence appears — and equally willing to hold your position when the evidence has not changed.

**A practical habit:** once a quarter, pick one ingredient or trend you have been asked about and spend an hour checking the evidence using the five-question test above. Write a short note on what you found. Over a year, that is four ingredients you now understand properly — and a growing file of honest answers you can give clients with confidence.

## 9.5 Your professional standard, in one paragraph

You now have the knowledge to assess skin honestly, read ingredient lists, build safe routines for the six most common profiles, run a professional consultation, and know when to refer. Your professional standard is simple: recommend what the evidence supports, in the order the evidence supports it, at a pace the skin can tolerate, with honest expectations and a clear referral path when something is outside your scope. That is more valuable than any single product recommendation, and it is what will keep clients coming back.

## 9.6 Key takeaways

- Most problems are barrier problems, over-exfoliation problems, or baseline problems. Fix the baseline first.
- Tingling is irritation, not effectiveness. Pores do not open and close. Natural does not mean safe. Expensive does not mean effective.
- Judge every trend with the five-question test: claim, mechanism, evidence, risk, and what it would replace.
- Stay current by checking evidence, not by following influencers.
- Your standard: evidence-based, in the right order, at a tolerable pace, with honest expectations and a clear referral path.

## 9.7 Practice task

Pick one trend you have seen recently — on social media, in a shop, or from a client. Run it through the five-question test and write your verdict in the workbook (Exercise 9.1), with the evidence you found. Keep the note: you will be asked about the next trend soon, and the habit matters more than the answer.

---

# Glossary of Key Terms

- **Active ingredient:** An ingredient included to produce a specific effect beyond cleansing and moisturising, such as increasing cell turnover or reducing the appearance of pigmentation.
- **AHA (alpha hydroxy acid):** A water-soluble exfoliating acid (glycolic, lactic, mandelic) that works on the skin surface.
- **Barrier (skin barrier):** The stratum corneum's brick-and-mortar structure of corneocytes and lipids that limits water loss and keeps irritants out.
- **BHA (beta hydroxy acid):** Salicylic acid; an oil-soluble exfoliant that can work inside pores.
- **Broad spectrum:** Sunscreen protection against both UVA and UVB radiation.
- **Ceramide:** A lipid naturally present in the skin barrier; a key ingredient in barrier-repair moisturisers.
- **Comedogenic:** Tending to clog pores. The term is used loosely in marketing; individual responses vary.
- **Corneocyte:** A dead, flattened skin cell in the stratum corneum — the "brick" in the brick-wall model.
- **Dermis:** The middle skin layer, containing collagen, elastin, blood vessels, and glands.
- **Emollient:** An ingredient that softens and smooths skin by filling gaps between surface cells.
- **Epidermis:** The outermost skin layer, including the stratum corneum.
- **Fitzpatrick scale:** A classification (I–VI) of skin by its response to sun exposure.
- **Humectant:** An ingredient that attracts and holds water in the skin.
- **Hyperpigmentation:** Darkening of an area of skin, often after inflammation or sun exposure. Post-inflammatory hyperpigmentation (PIH) follows a breakout or injury.
- **Hypodermis:** The deepest skin layer, made mostly of fat and connective tissue.
- **Melanin:** The pigment produced by melanocytes that gives skin its colour and provides some natural UV protection.
- **Microbiome (skin):** The community of micro-organisms living on the skin surface.
- **NMF (natural moisturising factor):** The mixture of small molecules inside corneocytes that attract and hold water.
- **Occlusive:** An ingredient that forms a seal over the skin and slows water loss.
- **Patch test:** Applying a new product to a small, discreet area of skin for several days before full-face use, to check for a reaction.
- **PHA (polyhydroxy acid):** A large, gentle exfoliating acid (gluconolactone, lactobionic acid).
- **Photoageing:** Visible skin ageing caused by cumulative UV exposure.
- **Retinoid:** A vitamin A derivative (retinol, retinaldehyde, adapalene, tretinoin) that increases cell turnover and supports collagen.
- **Sebum:** The oily substance produced by sebaceous glands.
- **SPF (sun protection factor):** A measure of protection against UVB radiation.
- **Stratum corneum:** The outermost layer of the epidermis; the skin barrier.
- **Surfactant:** A cleansing agent that lifts oil and dirt so water can rinse them away.
- **TEWL (transepidermal water loss):** Water escaping from inside the body out through the skin; a measure of barrier health.
- **UVA / UVB:** Types of ultraviolet radiation. UVA drives photoageing; UVB causes sunburn. Both contribute to skin cancer risk.

---

# Further Reading and Sources

These are starting points for deeper study. They are general educational resources, not a substitute for professional training, and they do not replace the advice of a qualified dermatologist.

- American Academy of Dermatology (aad.org) — patient education on skin conditions, sun protection, and skincare basics.
- British Association of Dermatologists (bad.org.uk) — patient information leaflets on common skin conditions.
- DermNet (dermnetnz.org) — a dermatology reference covering skin anatomy, conditions, and treatments in plain language.
- The Skin Cancer Foundation (skincancer.org) — evidence-based information on UV radiation, sunscreen, and skin cancer prevention.
- *The Skin Barrier* and related dermatology textbook chapters on epidermal structure and function — for readers who want the underlying science in full depth (available through medical libraries).
- Cosmetic Ingredient Review (cir-safety.org) — published safety assessments of cosmetic ingredients.
- National Eczema Association (nationaleczema.org) — practical guidance on barrier care and gentle routines.

When you read a new claim, check whether it is supported by one of these sources or by a published study. If the only source is a brand's own marketing, treat the claim as unproven.

---

# Final Checklist: Your First 30 Days After This Course

- [ ] Complete all nine workbook exercises.
- [ ] Build your own starter routine and follow it for two weeks.
- [ ] Patch-test and introduce one active using the Module 6 rules.
- [ ] Complete the ingredient decoder for at least 20 ingredients.
- [ ] Build routines for two of the six profiles using the worksheets.
- [ ] Conduct one practice consultation using the client consultation form.
- [ ] Find a sunscreen you will wear every day — and wear it.
- [ ] Identify a local dermatologist or clinic for referrals and keep their details on file.
- [ ] Set a quarterly reminder to test one new ingredient or trend against the five-question test in Module 9.

---

*Skin Science & Signature Routines: Evidence-Based Skincare Education — BEA-05. Education only. This course does not diagnose, treat, or cure any skin condition. For persistent or worsening skin problems, consult a qualified dermatologist or doctor. Patch-test all new products. Individual results vary.*
