# The Fix-and-Flip Profit System (RE-03) — Product Index

**SKU:** RE-03 | **Category:** Real Estate | **Price:** $797 one-time (79700 cents)

Flip with confidence — budget the rehab, manage the crew, and exit for profit.

## Files

| File | Description |
|---|---|
| `content.md` | The full 15-module course manual — complete instructional text with worked examples, tables, and three full case studies (profitable, break-even, and losing flips). The core deliverable. |
| `workbook.md` | Companion workbook: rehab budget worksheet (room by room), ARV comp worksheet, contractor bid comparison sheet, draw-schedule tracker, holding-cost tracker, and deal case-study worksheet. |
| `templates/rehab-budget-arv-calculator.csv` | Spreadsheet calculator: purchase, rehab line items by room, carrying costs, selling costs, with computed ARV, total cost, gross profit, and ROI (pre-filled with the anchor deal example). |
| `templates/contractor-scope-of-work.md` | Fill-in scope-of-work template to give every bidding contractor. |
| `templates/draw-schedule.md` | Milestone draw-schedule template tied to inspected, completed work. |
| `templates/contractor-bid-comparison.md` | Line-by-line contractor bid comparison with license/insurance checks. |
| `sales-page.md` | Full sales page: headline, problem, solution, what's inside, who it is/isn't for, $797 price, 14-day guarantee, 8-question FAQ, and disclaimer. |
| `listing.json` | EightyTwenty marketplace listing data (validated JSON, price_cents 79700). |
| `cover.md` | Cover design brief: black-and-gold luxury branding, typography, imagery, and layout direction. |
| `cover.webp` | Generated cover image (premium black-and-gold eBook cover). |
| `onboarding.md` | Customer onboarding guide: what to read first, how to use each file, 6-week schedule, support. |
| `README.md` | This index. |

## Notes

- All content is original. No testimonials, reviews, sales figures, or customer stories are included, and no market data is invented.
- Education only: the disclaimer (real estate education, not individualized investment, legal, tax, or financial advice) appears in `content.md`, `workbook.md`, and `sales-page.md`.
- The anchor deal used throughout the course: $160,000 purchase, $55,000 rehab, $18,000 carrying/financing costs, $285,000 sale price, $12,000 selling costs = $40,000 gross profit (simplified presentation; the fully itemized version in Module 1 shows $35,983 after separately counting $4,000 of purchase closing costs — both presentations are explained in the text).
