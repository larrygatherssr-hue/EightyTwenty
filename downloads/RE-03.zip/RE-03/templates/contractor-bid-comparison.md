# Contractor Bid Comparison — Template

> **How to use:** Give every contractor the *same* written scope of work, then record their bids side by side on this sheet. Compare line by line — a bid that is cheaper because it omits work is not cheaper. Verify license and insurance for every bidder before you sign.
>
> **Disclaimer:** This template is general education, not a legal form.

---

**Property address:** ___________________________________________________________

**Date bids requested:** __________________ **Bids due:** __________________

**Scope of work attached to every bid?** [ ] Yes — if no, do not compare the bids yet.

## Bids

| Line item | Contractor A: __________________ | Contractor B: __________________ | Contractor C: __________________ |
|---|---|---|---|
| Demolition | $ | $ | $ |
| Rough electrical | $ | $ | $ |
| Rough plumbing | $ | $ | $ |
| HVAC | $ | $ | $ |
| Drywall | $ | $ | $ |
| Kitchen (cabinets / counters / install) | $ | $ | $ |
| Bathroom 1 | $ | $ | $ |
| Bathroom 2 | $ | $ | $ |
| Flooring | $ | $ | $ |
| Paint (interior) | $ | $ | $ |
| Paint (exterior) | $ | $ | $ |
| Trim / doors / hardware | $ | $ | $ |
| Roof | $ | $ | $ |
| Exterior / landscaping | $ | $ | $ |
| Permits | $ | $ | $ |
| Dumpster / cleanup | $ | $ | $ |
| Other: __________________ | $ | $ | $ |
| **TOTAL BID** | **$** | **$** | **$** |

## Terms Comparison

| | Contractor A | Contractor B | Contractor C |
|---|---|---|---|
| Materials included? | | | |
| Labor included? | | | |
| Permits included? | | | |
| Exclusions (list) | | | |
| Start date | | | |
| Duration (weeks) | | | |
| Payment schedule | | | |
| Upfront payment requested | $ | $ | $ |
| Warranty (workmanship) | | | |
| License # (verified) | [ ] Y [ ] N | [ ] Y [ ] N | [ ] Y [ ] N |
| Insurance cert. received & verified | [ ] Y [ ] N | [ ] Y [ ] N | [ ] Y [ ] N |
| References called (3) | [ ] Y [ ] N | [ ] Y [ ] N | [ ] Y [ ] N |
| Would references hire again? | | | |

## Why the totals differ

(Write the explanation for each gap — omitted line items, different materials, different allowances — before you choose.)

________________________________________________________________________________
________________________________________________________________________________
________________________________________________________________________________

## Decision

**Contractor selected:** ________________________________________________________

**Reason:** ____________________________________________________________________

**Contract price agreed:** $__________________ **Start date:** __________________

**Notes / concerns to address in the contract:** ____________________________________
________________________________________________________________________________
