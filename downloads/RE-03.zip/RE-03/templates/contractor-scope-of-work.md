# Contractor Scope of Work — Template

> **How to use:** Complete one scope of work per property and give the *same* document to every contractor bidding the job. Bids on different scopes cannot be compared. Attach the signed scope as an exhibit to the contractor agreement. No work outside this scope is authorized without a signed written change order.
>
> **Disclaimer:** This template is general education, not a legal form. Have a real estate attorney in your state review your contractor contract before you sign it.

---

**Property address:** ___________________________________________________________

**Owner / investor:** ___________________________________________________________

**Contractor:** _______________________________________________________________

**Date of scope:** __________________ **Target start date:** __________________

**Target completion date:** __________________ **Contract type:** [ ] Fixed price  [ ] Time & materials

---

## 1. General Conditions

- Contractor shall supply all labor, tools, equipment, and (unless noted otherwise below) materials required to complete the work described.
- Contractor shall obtain all required permits and schedule all inspections. No drywall shall be installed until rough inspections have passed.
- Contractor shall keep the site clean, remove debris daily, and provide dumpster service.
- Contractor shall protect all existing finishes and surfaces not part of the work.
- Work hours: __________ to __________, Monday–Friday (weekend work only by prior written agreement).
- Contractor shall carry general liability insurance and workers' compensation, and shall provide a certificate of insurance before work begins.
- All electrical, plumbing, and HVAC work shall be performed by appropriately licensed tradespeople.
- Materials supplied by owner (if any): ___________________________________________

## 2. Demolition

- [ ] Remove: _________________________________________________________________
- [ ] Remove: _________________________________________________________________
- [ ] Haul away and dispose of all demolition debris. Dumpster included: [ ] Yes [ ] No

## 3. Exterior

- Roof: _____________________________________________________________________
  (e.g., repair flashing and replace ___ missing shingles; or full tear-off and replacement with architectural shingles, including underlayment and drip edge)
- Siding / gutters / fascia: ______________________________________________________
- Windows (qty: ___): __________________________________________________________
  (brand / type / size: _________________________________________________________)
- Exterior paint (color: _______________): _________________________________________
- Landscaping / curb appeal: ____________________________________________________
- Driveway / walkways: _________________________________________________________

## 4. Systems

- Electrical: __________________________________________________________________
  (e.g., replace 100-amp panel with 200-amp panel; add ___ circuits; replace ___ fixtures)
- Plumbing: ___________________________________________________________________
  (e.g., replace water heater, model: _______________; replace supply lines to kitchen and baths)
- HVAC: ______________________________________________________________________
- Sewer / drain: _______________________________________________________________

## 5. Kitchen

- Cabinets (brand / line / color: _______________________________________________)
- Countertops (material / color: ________________________________________________)
- Appliances (brand / models: __________________________________________________)
- Sink / faucet (model: ________________________________________________________)
- Backsplash (material / color: _________________________________________________)
- Flooring (material: __________________________________________________________)
- Lighting: ____________________________________________________________________
- Layout changes (if any): ______________________________________________________
  (Note: moving plumbing or walls changes cost significantly — confirm in writing.)

## 6. Bathroom 1

- Tub / shower: _______________________________________________________________
- Vanity / toilet / fixtures (models: ____________________________________________)
- Tile / flooring: ______________________________________________________________
- Lighting / mirror / accessories: _______________________________________________

## 7. Bathroom 2

- Tub / shower: _______________________________________________________________
- Vanity / toilet / fixtures (models: ____________________________________________)
- Tile / flooring: ______________________________________________________________
- Lighting / mirror / accessories: _______________________________________________

## 8. Interior General

- Paint — walls (color: _______________), ceilings, trim: ____________________________
- Flooring by room: ____________________________________________________________
- Drywall repair / texture: ______________________________________________________
- Interior doors / trim / hardware: _______________________________________________
- Light fixtures: ________________________________________________________________
- Other: ______________________________________________________________________

## 9. Finish, Cleanup, and Close-Out

- [ ] All punch-list items completed and approved at final walk-through
- [ ] All permits finaled and inspection reports provided to owner
- [ ] Site broom-clean; all debris, tools, and surplus materials removed
- [ ] Touch-up paint, caulk, and hardware adjustment complete
- [ ] Warranties and manuals for appliances / fixtures / systems delivered to owner

## 10. Exclusions (work NOT included in this scope)

- ____________________________________________________________________________
- ____________________________________________________________________________
- ____________________________________________________________________________

## 11. Payment — Draw Schedule

| Draw | Milestone | Amount / % |
|---|---|---|
| 1 | Signing / mobilization | $__________ (____%) |
| 2 | Demolition + rough-in complete, rough inspections passed | $__________ (____%) |
| 3 | Drywall complete, kitchen cabinets installed | $__________ (____%) |
| 4 | Flooring, tile, trim, paint complete | $__________ (____%) |
| 5 | Punch list complete, final inspections passed, final walk-through approved | $__________ (____%) |
| | **Total contract price** | **$__________** |

Retainage held until final completion: $__________ (____% — 10% recommended).

## 12. Change Orders

No additional work, and no additional payment, without a signed written change order stating the work, the cost (labor and materials separately), and the effect on the completion date.

## 13. Signatures

**Owner:** __________________________________________ Date: __________________

**Contractor:** ______________________________________ Date: __________________

License #: ______________________  Insurance certificate received: [ ] Yes  Date: __________
