# Draw Schedule — Template

> **How to use:** Complete one draw schedule per contractor agreement. Payments are released only when the listed milestone is complete *and inspected* by you (or your lender's inspector). Hold the final 10–20% until the punch list is complete and the final walk-through is approved. Attach this schedule to the contract.
>
> **Disclaimer:** This template is general education, not a legal form. Have a real estate attorney in your state review your contractor contract before you sign it.

---

**Property address:** ___________________________________________________________

**Owner / investor:** ___________________________________________________________

**Contractor:** _______________________________________________________________

**Contract total:** $__________________ **Contract date:** __________________

**Retainage held until final completion:** $__________________ (____%)

**Lender-funded draws?** [ ] No  [ ] Yes — lender: __________________  Draw/inspection fee per draw: $__________

---

## Milestone Draws

| Draw | Milestone (work that must be complete and inspected) | Amount | % of contract | Target date | Date inspected | Date paid | Paid by |
|---|---|---|---|---|---|---|---|
| 1 | Contract signing / mobilization — materials ordered, dumpster on site | $ | 10% | | | | |
| 2 | Demolition complete; rough electrical, plumbing, and HVAC complete; rough inspections passed | $ | 25% | | | | |
| 3 | Insulation and drywall complete; kitchen cabinets installed | $ | 25% | | | | |
| 4 | Flooring, tile, trim, and paint complete | $ | 20% | | | | |
| 5 | Punch list complete; final inspections passed; final walk-through approved; site clean; warranties delivered | $ | 20% | | | | |
| | **TOTAL** | **$** | **100%** | | | | |

Adjust the percentages to fit the job, but keep two rules: never pay more than 10% before work begins, and never release the final draw before the punch list is done.

## Inspection Checklist (complete at each draw)

- [ ] Walked the work in person and compared it with the scope of work
- [ ] Photographed the completed work (photos filed with date)
- [ ] Rough or final inspections passed (where applicable) — report filed
- [ ] Materials installed match the scope (brand / model / color)
- [ ] No defective or incomplete work in the milestone area
- [ ] Contractor's invoice matches the draw amount in this schedule

Inspector name: ______________________________ Signature: __________________ Date: __________

## Change-Order Log

| # | Date | Description | Cost | Schedule impact | Approved by (initials) |
|---|---|---|---|---|---|
| 1 | | | $ | | |
| 2 | | | $ | | |
| 3 | | | $ | | |
| 4 | | | $ | | |

**Revised contract total after change orders: $__________________**

## Notes

- If a lender funds the rehab, allow 3–5 business days per draw for the lender's inspection and release, and tell the contractor in advance.
- If work is incomplete or defective at a milestone, do not release the draw. Note the deficiency in writing, agree a date to correct it, and re-inspect.
- Keep every invoice, inspection report, and photo with this schedule in the project file.

**Owner signature:** ______________________________________ Date: ______________

**Contractor signature:** _________________________________ Date: ______________
