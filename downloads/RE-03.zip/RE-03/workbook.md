# The Fix-and-Flip Profit System — Companion Workbook

> **Disclaimer:** This workbook is real estate education only. It is not individualized investment, legal, tax, or financial advice. All figures you enter are your own estimates — verify them with qualified professionals (a licensed real estate agent, a licensed lender, a contractor, and a tax professional) before making any purchase, financing, or sale decision. No profit is guaranteed.

## How to use this workbook

Work through the worksheets in order before you make an offer: ARV first, then the rehab budget, then the bid comparison, then the deal worksheet. Use the draw-schedule and holding-cost trackers during the rehab. Print the pages or copy them into a spreadsheet — either way, keep one completed workbook per property in your deal file.

---

## Worksheet 1 — Rehab Budget (Room by Room)

Property address: ____________________________________________  Date: ____________

| Area / item | Description | Estimated cost | Actual cost | Difference |
|---|---|---|---|---|
| **Exterior & structure** | | | | |
| Roof repair / replacement | | $ | $ | $ |
| Siding / gutters / fascia | | $ | $ | $ |
| Windows (qty: ___) | | $ | $ | $ |
| Landscaping / curb appeal | | $ | $ | $ |
| Driveway / walkways | | $ | $ | $ |
| Foundation / structural | | $ | $ | $ |
| **Systems** | | | | |
| Electrical (panel / rewiring) | | $ | $ | $ |
| Plumbing (fixtures / repairs) | | $ | $ | $ |
| Sewer line | | $ | $ | $ |
| HVAC | | $ | $ | $ |
| Water heater | | $ | $ | $ |
| **Kitchen** | | | | |
| Cabinets | | $ | $ | $ |
| Countertops | | $ | $ | $ |
| Appliances | | $ | $ | $ |
| Sink / faucet | | $ | $ | $ |
| Backsplash | | $ | $ | $ |
| Lighting | | $ | $ | $ |
| Flooring | | $ | $ | $ |
| **Bathroom 1** | | | | |
| Tub / shower | | $ | $ | $ |
| Vanity / toilet / fixtures | | $ | $ | $ |
| Tile / flooring | | $ | $ | $ |
| **Bathroom 2** | | | | |
| Tub / shower | | $ | $ | $ |
| Vanity / toilet / fixtures | | $ | $ | $ |
| Tile / flooring | | $ | $ | $ |
| **Interior general** | | | | |
| Paint (whole interior) | | $ | $ | $ |
| Flooring (other rooms) | | $ | $ | $ |
| Drywall repair | | $ | $ | $ |
| Doors / trim / hardware | | $ | $ | $ |
| Light fixtures | | $ | $ | $ |
| Cleaning / dumpster / debris | | $ | $ | $ |
| **Permits & other** | | | | |
| Permits | | $ | $ | $ |
| Other: ___________________ | | $ | $ | $ |
| Other: ___________________ | | $ | $ | $ |
| **SUBTOTAL** | | **$** | **$** | **$** |
| Contingency (10–15%; 20% if unknowns) ____% | | $ | $ | $ |
| **TOTAL REHAB BUDGET** | | **$** | **$** | **$** |

Notes / unknowns to investigate before offering:
1. ________________________________________________________________________
2. ________________________________________________________________________
3. ________________________________________________________________________

---

## Worksheet 2 — ARV Comp Worksheet

Property address: ____________________________________________  Date: ____________

Subject property: ______ beds / ______ baths / ______ sq ft / built ______ / lot ______

| | Comp 1 | Comp 2 | Comp 3 | Comp 4 | Comp 5 |
|---|---|---|---|---|---|
| Address | | | | | |
| Sale price | $ | $ | $ | $ | $ |
| Sale date | | | | | |
| Sq ft | | | | | |
| $ / sq ft | $ | $ | $ | $ | $ |
| Beds / baths | | | | | |
| Distance from subject | | | | | |
| Condition / renovation | | | | | |
| Adjustments (+ / −) | $ | $ | $ | $ | $ |
| Adjusted $ / sq ft | $ | $ | $ | $ | $ |

Adjusted $/sq ft range: $__________ to $__________
Subject sq ft: __________ × low-end $/sq ft: $__________ = ARV (low): $__________
Subject sq ft: __________ × high-end $/sq ft: $__________ = ARV (high): $__________

**Conservative ARV to use for offer math: $__________**

Why this figure (note the comps you weighted most and any you discounted, and why):
________________________________________________________________________________
________________________________________________________________________________

Neighborhood price ceiling (highest closed sale in the last 12 months): $__________
What did that home have that this one will not? ____________________________________

---

## Worksheet 3 — Contractor Bid Comparison

Property address: ____________________________________________  Date: ____________

Scope of work attached?  [ ] Yes  [ ] No — do not compare bids without a shared written scope.

| Line item | Contractor A: __________ | Contractor B: __________ | Contractor C: __________ |
|---|---|---|---|
| Demolition | $ | $ | $ |
| Rough electrical / plumbing / HVAC | $ | $ | $ |
| Drywall | $ | $ | $ |
| Kitchen | $ | $ | $ |
| Bathrooms | $ | $ | $ |
| Flooring | $ | $ | $ |
| Paint | $ | $ | $ |
| Trim / doors / hardware | $ | $ | $ |
| Exterior | $ | $ | $ |
| Permits | $ | $ | $ |
| Cleanup / dumpster | $ | $ | $ |
| **TOTAL BID** | **$** | **$** | **$** |
| Included? Materials / labor / permits | | | |
| Exclusions noted | | | |
| Start date / duration | | | |
| License verified? | [ ] Y [ ] N | [ ] Y [ ] N | [ ] Y [ ] N |
| Insurance verified? | [ ] Y [ ] N | [ ] Y [ ] N | [ ] Y [ ] N |
| References called (3)? | [ ] Y [ ] N | [ ] Y [ ] N | [ ] Y [ ] N |

Differences that explain the price gap:
________________________________________________________________________________
________________________________________________________________________________

Contractor selected: ________________________  Reason: ______________________________

---

## Worksheet 4 — Draw-Schedule Tracker

Property address: ____________________________  Contractor: ________________________
Contract total: $__________  Retainage held until punch list complete: $__________ (____%)

| Draw # | Milestone | Due date | Amount | Date inspected | Date paid | Initials |
|---|---|---|---|---|---|---|
| 1 | Signing / mobilization | | $ | | | |
| 2 | Demolition + rough-in complete, rough inspections passed | | $ | | | |
| 3 | Drywall complete, kitchen cabinets installed | | $ | | | |
| 4 | Flooring, tile, trim, paint complete | | $ | | | |
| 5 | Punch list complete, final inspections passed, final walk-through approved | | $ | | | |
| | **Total paid** | | **$** | | | |

Change orders approved (attach each signed change order):

| # | Date | Description | Cost | Schedule impact | New contract total |
|---|---|---|---|---|---|
| 1 | | | $ | | $ |
| 2 | | | $ | | $ |
| 3 | | | $ | | $ |

**Rule: no payment for work that has not been inspected. No extra work without a signed change order.**

---

## Worksheet 5 — Holding-Cost Tracker

Property address: ____________________________  Expected hold: ______ months

| Month | Loan interest | Property taxes | Insurance | Utilities | Lawn / maint. | HOA | Other | Monthly total |
|---|---|---|---|---|---|---|---|---|
| 1 | $ | $ | $ | $ | $ | $ | $ | $ |
| 2 | $ | $ | $ | $ | $ | $ | $ | $ |
| 3 | $ | $ | $ | $ | $ | $ | $ | $ |
| 4 | $ | $ | $ | $ | $ | $ | $ | $ |
| 5 | $ | $ | $ | $ | $ | $ | $ | $ |
| 6 | $ | $ | $ | $ | $ | $ | $ | $ |
| 7 | $ | $ | $ | $ | $ | $ | $ | $ |
| 8 | $ | $ | $ | $ | $ | $ | $ | $ |
| **TOTAL** | **$** | **$** | **$** | **$** | **$** | **$** | **$** | **$** |

Monthly burn rate: $__________  |  Cost of each extra month: $__________
Loan maturity date: ____________  Extension fee if needed: $__________

---

## Worksheet 6 — Deal Case-Study Worksheet (one per property analyzed)

Property address: ____________________________________________  Date: ____________

| Line item | Amount |
|---|---|
| ARV (conservative, from Worksheet 2) | $ |
| Purchase price | $ |
| Purchase closing costs | $ |
| Rehab total (from Worksheet 1, incl. contingency) | $ |
| Financing costs (points + interest + fees) | $ |
| Holding costs (from Worksheet 5) | $ |
| Selling costs (commission + concessions + sale closing) | $ |
| **TOTAL COST** | **$** |
| **PROJECTED GROSS PROFIT (ARV − total cost)** | **$** |
| **MAO at 70%: (ARV × 0.70) − rehab** | **$** |
| **MAO at 65%: (ARV × 0.65) − rehab** | **$** |

Decision:  [ ] Offer at $__________  [ ] Pass — reason: ________________________________
What would have to change for this deal to work? ____________________________________
Post-mortem (fill in after the deal closes or after you walk away):
________________________________________________________________________________
________________________________________________________________________________

---

*End of workbook. Keep one completed workbook per property in your deal file, with the signed contracts, permits, inspection reports, photos, and receipts.*
