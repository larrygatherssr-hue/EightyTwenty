# The Fix-and-Flip Profit System

## A Complete Course Manual for First-Time House Flippers

**By the EightyTwenty Real Estate Education Series**

---

> **IMPORTANT DISCLAIMER — PLEASE READ FIRST**
>
> This course is real estate education only. It is not individualized investment, legal, tax, or financial advice, and it does not guarantee any profit or outcome. House flipping involves substantial financial risk, including the possible loss of some or all of the capital you invest. Real estate markets, lending terms, construction costs, tax rules, and local laws vary by location and change over time. All numbers in this course are teaching examples based on stated assumptions — they are not predictions, guarantees, or representations of what any particular property will return. Before buying, financing, renovating, or selling a property, consult a qualified real estate attorney, a licensed real estate agent, a tax professional, and a licensed lender in your state. Verify every cost, regulation, permit requirement, and market assumption independently for the specific property and jurisdiction involved.

---

## Table of Contents

1. How Flipping Actually Makes Money — and How It Loses It
2. Finding Flip Deals: On-Market, Off-Market, Auctions, and Wholesalers
3. After-Repair Value (ARV): How to Estimate It from Comps
4. The Rehab Budget: Line by Line, Room by Room
5. The 70% Rule and Your Maximum Allowable Offer — Worked Examples
6. Financing a Flip: Cash, Hard Money, Private Money, and What Each Really Costs
7. Making the Offer and Closing the Purchase
8. Hiring and Managing Contractors: Bids, Contracts, and Scope of Work
9. Running the Rehab: Schedule, Draw Schedule, and Inspections
10. Change Orders and Budget Overruns: How to Control Them
11. Staging and Pricing for a Fast Sale
12. Selling: Agent, Flat Fee, or FSBO
13. Taxes and Holding Costs on a Flip
14. Three Full Worked Deal Case Studies with Real Numbers
15. Your First Flip: A 120-Day Plan from Offer to Closing

Appendices: Glossary of Terms | Recommended Due-Diligence Checklist | Resources for Further Learning

---

## Module 1 — How Flipping Actually Makes Money — and How It Loses It

### What a flip really is

A house flip is simple to describe and hard to execute well. You buy a property below its repaired value, improve it, and sell it for more than your total cost. The difference — after every cost is counted — is your profit. The difficulty is that "every cost" is a longer list than most beginners expect, and the profit lives in the gap between two estimates (what the house will be worth when fixed, and what the fix will cost) that are both easy to get wrong.

A flip makes money from exactly three sources:

1. **Buying below market value.** Distressed sellers, estates, foreclosures, and neglected properties sometimes sell for less than a comparable move-in-ready home. That discount is the raw material of a flip.
2. **Adding value through renovation.** A kitchen, bathrooms, flooring, paint, and systems work can raise a home's value by more than the renovation costs — when the work matches what buyers in that neighborhood actually pay for.
3. **Market movement.** If prices rise while you hold the property, you benefit. This is the least reliable source and should never be the plan. A good flip works even if prices stay flat.

### The full profit equation

Most beginners compute profit as: sale price minus purchase price minus rehab. That formula leaves out roughly a third of the real costs. The honest equation is:

**Net profit = Sale price − Purchase price − Rehab costs − Financing costs − Holding costs − Closing costs (both sides) − Selling costs − Taxes**

Here is that equation applied to a realistic example, the "anchor deal" we will return to throughout this course:

| Line item | Amount |
|---|---|
| Sale price | $285,000 |
| Purchase price | ($160,000) |
| Rehab costs | ($55,000) |
| Financing costs (hard-money interest, points, fees) | ($11,000) |
| Holding costs (taxes, insurance, utilities, 5 months) | ($7,000) |
| Purchase closing costs | ($4,000) |
| Selling costs (agent commission, concessions, sale closing) | ($12,000) |
| **Gross profit before tax** | **$36,000** |

Wait — the headline example in this course's introduction quoted $40,000 gross profit on the same deal with $18,000 of carrying/financing costs and $12,000 of selling costs. Reconcile the two: $285,000 − $160,000 − $55,000 − $18,000 − $12,000 = $40,000. The $18,000 carrying/financing figure combines the $11,000 financing and $7,000 holding costs above. The $4,000 purchase closing cost is the difference between the two presentations: in the simplified version it is folded into the purchase price for readability; in the detailed version it is shown separately. The lesson is the point: **the same deal can look $4,000 better or worse depending on which costs you remember to count.** Professional flippers count all of them, every time, before they offer.

### How flips lose money — the five classic failure modes

**1. Overpaying for the purchase.** This is the most common and least fixable error. If you pay $180,000 instead of $160,000 for the house above, $20,000 of profit disappears and no amount of good contracting brings it back. The purchase price is set before you own the house; it is the one cost you can fully control, and the one most beginners get wrong because they fall in love with a property.

**2. Underestimating the rehab.** A $55,000 rehab that becomes a $75,000 rehab destroys the same $20,000. Underestimates come from unseen damage (foundation, roof structure, plumbing, electrical panels), from scope creep ("while we're at it, let's also do the…"), and from pricing work from memory instead of from actual bids.

**3. Overestimating the after-repair value (ARV).** If the house sells for $260,000 instead of $285,000, $25,000 vanishes. Beginners overestimate ARV by comparing their property to the nicest renovated house in the neighborhood, or to homes in a better school zone, or to listings (asking prices) instead of closed sales.

**4. Holding too long.** Every extra month costs roughly $1,500–$3,000 on a typical flip: loan interest, taxes, insurance, utilities, lawn care. A six-month rehab that takes nine months can cost $6,000–$9,000 in pure holding cost, plus the risk that the market softens while you wait.

**5. Financing surprises.** Hard-money loans carry points (upfront fees of 1–3% of the loan), high monthly interest, and sometimes extension fees. A loan that costs $11,000 over five months can cost $16,000 over eight months, including a 1% extension fee. Beginners who budget "the interest" but forget the points and extension fees are budgeting a fantasy.

### What a realistic first flip looks like

A reasonable expectation for a first flip, done carefully, is a gross profit of $20,000–$50,000 on a $150,000–$300,000 property, over four to six months, with $25,000–$100,000 of your own capital at risk (or borrowed capital that you are personally responsible for). Some first flips lose money. That is not a reason to avoid flipping; it is a reason to size the deal so that a loss is survivable, to buy with a margin of safety, and to treat the first flip as paid education with upside — not as a lottery ticket.

A useful rule: **never risk money on a flip that you cannot afford to lose without changing your life.** If losing the entire investment would mean missing rent or raiding a retirement account, the deal is too big for you right now. Start smaller, partner, or wholesale a deal first (see Module 2) and learn the numbers with less capital at stake.

### The three numbers that decide everything

Every flip decision reduces to three numbers:

- **ARV** — what the fixed house will sell for (Module 3).
- **Rehab cost** — what the fix will actually cost (Module 4).
- **Total cost** — purchase + rehab + financing + holding + closing + selling (Modules 5, 6, 13).

If ARV minus total cost leaves a profit that justifies the risk and the months of work, the deal may be worth pursuing. If it does not, walk away. Walking away from a bad deal is the most profitable skill in flipping, and it costs nothing.

### Action steps — Module 1

1. Write down, in your own words, the full profit equation above, and memorize the cost categories.
2. Take the anchor deal ($160,000 purchase, $55,000 rehab, $18,000 carrying/financing, $285,000 sale, $12,000 selling costs) and recompute the profit yourself. Then recompute it assuming the sale price is $260,000 and the rehab is $70,000. See how fast the profit disappears.
3. Decide your maximum survivable loss before you look at a single property. Write it down and do not exceed it.
4. Read Modules 2–5 before making any offer. The purchase decision is made in those modules, not at the closing table.

---

## Module 2 — Finding Flip Deals: On-Market, Off-Market, Auctions, and Wholesalers

### The deal pipeline

Flipping is a numbers game at the sourcing stage. Experienced flippers commonly analyze 20–50 properties for every one they buy. That ratio is not a sign of failure; it is the job. Your pipeline needs four channels, because any single channel dries up.

### Channel 1: On-market (MLS and listing sites)

Properties listed publicly through a real estate agent are the most visible and the most competitive. The best on-market flip candidates share traits: long days on market (60+ days), price reductions, estate sales, dated interiors, deferred maintenance, and motivated-seller language ("as-is," "needs TLC," "bring your contractor," "estate sale").

**Advantages:** full information, inspections and financing contingencies are normal, title is clean, and you can verify comps easily.
**Disadvantages:** every other investor sees the same listing; the best deals rarely last a weekend; list prices often already reflect the property's potential.

**How to work it:** Build a relationship with an investor-friendly agent who will send you new listings the hour they appear and who understands that you need ARV and rehab estimates, not a tour of the granite. Set up saved searches with filters: price ceiling, age, days on market, and keywords. Be ready to view and offer within 24 hours on a genuinely good listing.

**A realistic expectation:** in a competitive market, you may make 10–15 on-market offers before one is accepted at a price that works. Budget your time accordingly.

### Channel 2: Off-market (direct to seller)

Off-market deals come from contacting owners directly: driving for dollars (noting neglected properties and looking up the owner), direct mail to absentee owners, probate and estate lists, pre-foreclosure lists, and expired listings. The owner has not listed the home, so there is less competition — but you must do the work of finding them and earning their trust.

**Advantages:** less competition, more flexible terms (seller financing, delayed closing, rent-backs), and sometimes a genuinely below-market price from an owner who values convenience over maximum price.
**Disadvantages:** slow and inconsistent; marketing costs money ($0.50–$1.00+ per mail piece, and response rates of 1–3% are normal); you need to handle seller conversations with honesty and care — these are often people in difficult situations (death in the family, divorce, financial distress). Never pressure a seller, never misrepresent a property's value, and always encourage them to get independent advice.

**Practical starting point:** pick one neighborhood you know well, drive it once a week, and keep a list of 20–30 neglected properties. Look up owners through the county tax assessor's public records (usually free online). A short, honest letter — "I buy houses in your neighborhood and pay cash; if you ever want to sell, I'd like to talk" — is a legitimate starting point. Expect most letters to go unanswered. That is normal.

### Channel 3: Auctions

County foreclosure auctions, bank-owned (REO) auctions, and online auction platforms sell properties fast, usually for cash, usually with no inspection and no financing contingency. Prices can be genuinely low — and so can the information.

**Advantages:** real discounts are possible; the process is fast.
**Disadvantages:** you often cannot enter the property before bidding; title issues, liens, and occupants are your problem after the sale; you need cash or a proof-of-funds letter on the day; and in many counties you must pay in full within 24 hours. Beginners should attend several auctions as observers before bidding at one, and should never bid on a property they have not driven past, researched in public records, and set a hard maximum price for in advance.

**Rule:** set your maximum bid before the auction, write it down, and do not exceed it in the heat of bidding. Auction fever has cost more beginners more money than any other single moment in flipping.

### Channel 4: Wholesalers

A wholesaler contracts a property with a seller and then assigns that contract to an investor (you) for a fee. You pay the seller's price plus the wholesaler's assignment fee, which typically runs $5,000–$20,000 depending on the deal.

**Advantages:** deals arrive in your inbox; the wholesaler has done the seller outreach.
**Disadvantages:** the fee comes out of your profit; some wholesalers inflate ARV or understate rehab to make a deal look good; and the quality of wholesalers varies enormously. Always verify ARV and rehab yourself, with your own comps and your own contractor walk-through, before accepting a wholesale deal. If a wholesaler will not let you inspect, walk away.

**How to vet a wholesaler:** ask for the contract price and the assignment fee separately, ask how they arrived at ARV, and check their reputation with other local investors. A good wholesaler is transparent about all three numbers; a bad one hides the fee inside a single "price."

### Building your buy box

Before you source seriously, define your "buy box" — the narrow profile of deals you will pursue. An example first-flip buy box:

- Price range: $100,000–$200,000 purchase
- Property: 3-bed, 1–2 bath single-family home, 1,000–1,800 sq ft
- Area: two or three specific neighborhoods you know, within a 30-minute drive
- Condition: cosmetic to moderate rehab ($30,000–$70,000), no foundation or major structural work
- ARV: $200,000–$350,000
- Minimum projected profit after all costs: $25,000

A buy box does two things: it focuses your search so you stop chasing every property, and it gives you a fast "no." If a property is outside the box, you pass without spending an hour analyzing it.

### Action steps — Module 2

1. Write your buy box and share it with an investor-friendly agent.
2. Set up saved searches for on-market listings in your target neighborhoods.
3. Pick one off-market method (driving for dollars or direct mail) and start a list of 20 properties this week.
4. Find your county's foreclosure auction schedule and attend one as an observer.
5. Join one local real estate investor group (in person or online) and ask who the reputable wholesalers are.

---

## Module 3 — After-Repair Value (ARV): How to Estimate It from Comps

### What ARV is and why it is the most important number

ARV is the price your property should sell for after renovation, based on what comparable homes have actually sold for. It is the single most important number in a flip: every other decision — the maximum offer, the rehab budget, the financing — is derived from it. If your ARV is wrong by 10%, your profit estimate is wrong by $20,000–$30,000 on a typical deal. Get ARV right and many other mistakes are survivable; get it wrong and even perfect execution may not save the deal.

### What counts as a comp

A comparable sale ("comp") is a home that is similar to your property *after renovation*, that sold recently, nearby, in similar condition. The standard filters:

- **Distance:** within 0.5–1 mile in a city or suburb; further only in rural areas where there is no alternative.
- **Recency:** sold within the last 3–6 months. Older sales are less reliable, especially in a moving market.
- **Size:** within roughly 20% of your property's square footage (a 1,200 sq ft comp for a 1,500 sq ft house is reasonable; a 2,500 sq ft comp is not).
- **Age and style:** similar construction era and type (a 1950s ranch is not a comp for a 1990s two-story).
- **Bedrooms and bathrooms:** same count, or adjust carefully.
- **Condition:** renovated to a similar standard. A fully gut-renovated flip is not a comp for a lightly updated home, and vice versa.
- **Location factors:** same school zone, same side of a major road, similar lot and street character.

**Use closed sales, not listings.** A listing price is an asking price — a hope. A pending sale is closer but still not final. Only a closed sale tells you what a buyer actually paid. Your agent can pull closed sales from the MLS; public sites also show sold prices, usually with a delay.

### The comp method, step by step

1. **Find 3–5 strong comps.** Three is the minimum for a real estimate; five is better. If you cannot find three good comps, that is information: the area may be thinly traded, and your ARV is less certain. Widen the radius or the time window slightly, but note the extra uncertainty.
2. **Calculate price per square foot for each comp.** Divide the sale price by the living square footage. Example: a 1,400 sq ft home that sold for $280,000 = $200 per sq ft.
3. **Adjust for differences.** A comp with a garage is worth more than one without; a comp with an extra bathroom is worth more; a comp on a busy road is worth less. Adjustments are judgment calls, and the honest ranges are: garage $5,000–$10,000; extra full bathroom $5,000–$10,000; extra bedroom $5,000–$15,000; lot size, pool, and condition differences vary widely and should be based on local evidence, not a national table. When in doubt, ask your agent what adjustments they use in that neighborhood.
4. **Apply the adjusted price per square foot to your property.** If the adjusted comps cluster around $195–$205 per sq ft and your renovated home will be 1,450 sq ft, the ARV range is roughly $283,000–$297,000.
5. **Take the conservative end.** For your offer math, use the low end of the range — or the median minus 5%. Optimism in ARV is the most expensive habit in flipping. Use $283,000, not $297,000, when you decide what to pay.

### Worked example — ARV for the anchor deal

Your target property: 3-bed, 2-bath, 1,450 sq ft ranch, built 1978, on a quiet street, no garage, small lot.

| Comp | Size | Sale price | $/sq ft | Notes / adjustment |
|---|---|---|---|---|
| A | 1,400 sq ft | $280,000 | $200 | Same street, renovated 2025, no garage |
| B | 1,500 sq ft | $292,500 | $195 | 2 blocks away, renovated 2024, has garage (−$7,500) |
| C | 1,380 sq ft | $269,100 | $195 | Same subdivision, renovated 2025, busy-road location (+$5,000) |
| D | 1,520 sq ft | $304,000 | $200 | 0.6 miles away, renovated 2025, extra half-bath (−$5,000) |

After adjustments, the comps support $195–$200 per sq ft. Applied to 1,450 sq ft, that is $282,750–$290,000. The conservative ARV for offer math: **$283,000**, rounded to $285,000 for the anchor example in this course (the difference is within the range, and we use $285,000 consistently in later modules — note that a $2,000 difference in ARV is well within the margin of error, which is exactly why the conservative habit matters).

### Common ARV mistakes

- **Using the nicest comp as "the" ARV.** The top sale is the exception, not the expectation. Use the cluster, not the outlier.
- **Comparing to new construction.** A 2024 build is not a comp for a 1978 ranch, however pretty the renovation.
- **Ignoring the ceiling.** Every neighborhood has a price ceiling — the most a buyer will pay for a home there, regardless of finishes. Putting $15,000 quartz counters in a $200,000 neighborhood does not create a $230,000 house. It creates a $200,000 house with expensive counters.
- **Trusting automated valuations blindly.** Online estimates are a starting point, not a valuation. They routinely miss condition, recent renovations, and hyperlocal boundaries. Use them to sanity-check your comp work, never to replace it.
- **Forgetting the appraisal.** Your buyer will likely need a mortgage, and their lender will order an appraisal. If the appraisal comes in below the contract price, the deal can fall apart or require renegotiation. A conservative ARV protects you from this.

### Action steps — Module 3

1. Ask your agent for closed sales in your target neighborhood from the last 6 months.
2. Pick a property you are considering (or a hypothetical one) and complete the ARV comp worksheet in the workbook.
3. Find at least three comps and compute an ARV range. Write down the conservative figure you would use for offer math and why.
4. Identify the neighborhood price ceiling: what is the highest closed sale in the last year, and what did that home have that yours will not?

---

## Module 4 — The Rehab Budget: Line by Line, Room by Room

### Why budgets fail

Rehab budgets fail for three reasons, and only one of them is bad luck. The first is that the budget was a guess — a round number ("about $50,000") with no line items behind it. The second is that the budget covered the visible work and not the hidden work: the roof deck under the shingles, the cast-iron drain under the slab, the panel that cannot carry a modern kitchen. The third is scope creep, which is a decision, not an accident, and is covered in Module 10.

A real rehab budget is a line-item list, priced from bids and supplier quotes, with a contingency. If you cannot point to the line that pays for the water heater, you do not have a budget — you have a hope.

### Budgeting by room and system

Walk the property room by room and system by system. The structure below is the standard framework; the accompanying workbook and calculator spreadsheet follow the same order so your numbers transfer cleanly.

**Exterior and structure**
- Roof repair or replacement: $5,000–$12,000 for a typical single-family roof (asphalt shingle); $1,500–$3,500 for repairs only. A full replacement on a larger or steeper roof can exceed $15,000.
- Siding, gutters, fascia: $2,000–$8,000.
- Windows: $400–$800 per window installed (vinyl replacement); a full house of 12 windows is $5,000–$9,500.
- Landscaping and curb appeal: $1,000–$3,000 (cleanup, sod, mulch, shrubs, mailbox, house numbers).
- Driveway and walkways: $1,500–$5,000 for repairs or resurfacing; more for full replacement.
- Foundation or structural repair: $3,000–$15,000+. If you see significant cracking, sloping floors, or sticking doors, get a structural engineer's opinion ($400–$800) before you offer. Structural work is the single most common budget-killer for beginners, and it is a valid reason to walk away from a first flip.

**Systems**
- Electrical panel upgrade: $2,000–$4,000. Rewiring part or all of a house: $5,000–$15,000.
- Plumbing: $2,000–$6,000 for fixture replacement and repairs; $8,000–$15,000+ for a re-pipe or sewer line replacement. A sewer scope (camera inspection, $200–$400) is one of the best dollars a flipper spends.
- HVAC: $5,000–$10,000 for a full system replacement; $500–$2,000 for repairs and servicing.
- Water heater: $1,200–$2,500 installed.

**Kitchen (the highest-return room, and the easiest to overspend on)**
- Full modest renovation: $12,000–$25,000. That covers stock or semi-custom cabinets ($5,000–$10,000), laminate or quartz counters ($2,000–$5,000), a mid-range appliance package ($2,500–$5,000), sink and faucet ($400–$900), lighting ($300–$800), backsplash ($500–$1,500), and flooring.
- Rule: match the kitchen to the neighborhood. In a $250,000 ARV neighborhood, a $12,000–$18,000 kitchen is right. A $35,000 kitchen there will not return its cost.

**Bathrooms**
- Full renovation, standard bath: $6,000–$12,000. Half bath or powder room: $3,000–$6,000. Covers tub/shower, vanity, toilet, tile, fixtures, and flooring.
- A second bathroom is often the single best value-add in a 1-bath house, but only if the plumbing allows it without major rework.

**Interior general**
- Paint (whole interior): $3,000–$6,000 for a 1,200–1,800 sq ft house, including prep.
- Flooring: $3–$8 per sq ft installed for luxury vinyl plank (the standard flip choice for durability and cost); $6–$12 per sq ft for refinishing hardwood; $4–$8 per sq ft for new carpet in bedrooms.
- Drywall repair and texture: $1,000–$3,000.
- Interior doors, trim, and hardware: $1,500–$4,000.
- Light fixtures throughout: $800–$2,000.
- Cleaning, debris removal, dumpster: $1,000–$2,500.

**Permits and miscellaneous**
- Permits: $500–$2,500 depending on scope and jurisdiction. Pull permits for structural, electrical, plumbing, and HVAC work. Unpermitted work can kill a sale or an appraisal, and it is a liability you carry after closing.
- Contingency: 10–15% of the rehab subtotal for a cosmetic-to-moderate rehab; 20% if the house is older, the inspection found unknowns, or you have not opened walls yet.

### Worked example — the anchor deal's $55,000 rehab

| Category | Amount |
|---|---|
| Roof repair + gutters | $3,500 |
| Exterior paint + landscaping | $4,500 |
| Kitchen renovation | $16,000 |
| Two bathroom renovations | $14,000 |
| Flooring throughout (LVP + carpet) | $7,000 |
| Interior paint | $4,000 |
| Electrical (panel + fixtures) | $2,500 |
| Plumbing repairs + water heater | $2,000 |
| Drywall, doors, trim, hardware | $2,500 |
| Permits, dumpster, cleaning | $2,000 |
| **Subtotal** | **$58,000** |

That subtotal is $58,000 — already over the $55,000 in the anchor example. This is deliberate: the anchor's $55,000 assumes $3,000 of value engineering (keeping the existing tubs and refinishing them instead of replacing, and reusing the existing kitchen layout with no plumbing moves). The point is that a line-item budget forces these decisions into the open *before* you own the house. With a 10% contingency ($5,500), the honest working budget is $60,500, and the offer math in Module 5 should be tested against both the $55,000 base and the $60,500 contingency figure.

### Getting real numbers

Never price a rehab from memory or from a national cost website alone. Prices vary by 30–50% between markets. The only reliable numbers are:

1. **Contractor bids** — at least two, ideally three, on the same written scope of work (Module 8).
2. **Supplier quotes** — big-box and local supply houses will price a materials list.
3. **Your own records** — after your first flip, your actual costs become your best estimator. Keep them.

Before you own the property, you will usually have one walk-through with a contractor. That is enough for a working budget if the scope is written down and the contractor has seen the attic, the crawl space or basement, the panel, and the roof. It is not enough for a fixed-price contract — that comes after closing, with a full scope (Module 8).

### Action steps — Module 4

1. Walk a property (yours, a friend's, or a listing) room by room and write a line-item rehab budget using the framework above.
2. Price the same scope two ways: your estimate, and a contractor's bid. Compare the gaps — the gaps are where you learn.
3. Add a 10–15% contingency to every budget and never present a budget without it.
4. Get a sewer scope and a roof assessment on any property you are seriously considering. Both are cheap; both prevent disasters.

---

## Module 5 — The 70% Rule and Your Maximum Allowable Offer — Worked Examples

### The rule

The 70% rule is the standard screening formula in flipping:

**Maximum Allowable Offer (MAO) = (ARV × 70%) − Rehab cost**

The 30% that is excluded is not profit. It is the allowance for everything else: financing, holding, closing, and selling costs, plus profit. On a typical deal those "everything else" costs run 20–25% of ARV, leaving roughly 5–10% of ARV as profit. The rule is a screen, not a valuation — it tells you quickly whether a deal is worth a deeper look.

### Worked example 1 — the anchor deal

- ARV: $285,000
- Rehab: $55,000
- MAO = ($285,000 × 0.70) − $55,000 = $199,500 − $55,000 = **$144,500**

The anchor deal's purchase price is $160,000 — $15,500 above the 70% rule MAO. Does that mean the anchor deal is a bad deal? Not necessarily, and this is an important lesson: the 70% rule is conservative by design, and the anchor deal still produces roughly $36,000–$40,000 of gross profit (Module 1) because its actual financing, holding, and selling costs are lower than the 30% allowance assumes. The rule is a starting discipline. A deal above MAO needs a written justification: lower-than-usual financing costs, a fast timeline, a rehab you can do partly yourself, or a market you know well. A deal below MAO is a deal with a built-in cushion.

Test the anchor deal at the 70% rule with the contingency budget ($60,500): MAO = $199,500 − $60,500 = $139,000. The gap widens. That tells you the anchor deal's margin depends on executing the rehab at or below $55,000 and selling at or near $285,000. That is a fair deal with real execution risk — exactly the kind of honest assessment a first flipper should make before offering.

### Worked example 2 — a deal that passes the rule

- ARV: $320,000
- Rehab: $60,000
- MAO = ($320,000 × 0.70) − $60,000 = $224,000 − $60,000 = **$164,000**
- Asking price: $150,000. The deal passes the screen with $14,000 of cushion below MAO. Worth a full analysis.

Full check on Example 2: purchase $150,000 + rehab $60,000 + financing $12,000 + holding $7,000 + purchase closing $4,000 + selling $19,200 (6% of $320,000) = $252,200 total cost. Sale at $320,000 leaves $67,800 gross profit before tax. That is a strong deal on paper — which means it deserves extra scrutiny on ARV and rehab, because strong-looking deals are where inflated assumptions hide.

### Worked example 3 — a deal that fails the rule

- ARV: $240,000
- Rehab: $45,000
- MAO = ($240,000 × 0.70) − $45,000 = $168,000 − $45,000 = **$123,000**
- Asking price: $150,000. The deal fails the screen by $27,000. Full check: purchase $150,000 + rehab $45,000 + financing $9,000 + holding $6,000 + purchase closing $3,500 + selling $14,400 = $227,900 total cost. Sale at $240,000 leaves $12,100 gross profit — before tax, and before any overrun. One $10,000 surprise erases it. Walk away, or offer $123,000 and accept that the seller will likely say no.

### When to adjust the percentage

The 70% rule is a convention, not a law. Experienced flippers adjust it:

- **75% rule** in hot markets with fast sales and cheap financing — thinner margin, faster turn, more risk. Only for flippers with proven execution and cash reserves.
- **65% rule** for first flips, slow markets, rural properties, or houses with structural unknowns — thicker margin, more room for error.
- **Never above 75%** on a first flip. The extra 5% is not worth the risk when you are still learning how long rehabs really take and what they really cost.

### The MAO worksheet habit

For every property you seriously consider, write down: ARV (conservative), rehab (with contingency), MAO at 70%, asking price, and the gap. If the gap is negative (asking price above MAO), either your numbers are wrong — recheck ARV and rehab — or the deal is wrong. Do not negotiate yourself into a deal by raising your ARV estimate to make the math work. That is the most common self-deception in flipping, and it is how beginners pay too much while believing they got a bargain.

### Action steps — Module 5

1. Compute the MAO for three properties in your target area using real asking prices and your own ARV and rehab estimates.
2. For the anchor deal, compute the MAO at 65%, 70%, and 75% and write down what changes at each level.
3. Set your personal rule before you offer: "I will not offer above my MAO unless I can write down the specific reason." Keep that note with the offer file.

---

## Module 6 — Financing a Flip: Cash, Hard Money, Private Money, and What Each Really Costs

### The four funding sources

**1. Your own cash.** The simplest and cheapest financing: no interest, no points, no lender deadlines, no monthly payments. You also carry 100% of the risk, and your capital is tied up for months. If you have $25,000–$100,000 available, cash is the cleanest way to do a first flip — but only if losing a meaningful part of it would not damage your household finances. Never use money you need for living expenses, and never drain an emergency fund to flip a house.

**2. Hard-money loans.** Short-term loans from private lending companies, secured by the property, designed for flips. Typical terms (which vary widely by lender and market — verify current terms with at least two lenders before you rely on them):

- Loan-to-value: 65–75% of ARV, or 80–90% of purchase price, whichever is lower.
- Interest: 9–13% annual, interest-only, paid monthly.
- Points: 1–3% of the loan amount, paid at closing.
- Term: 6–12 months, with extension fees (often 1% of the loan) if you run over.
- Rehab funds: often held in escrow and released in draws as work is completed (see Module 9).
- Speed: can close in 7–14 days, versus 30–45 days for a conventional mortgage.

**3. Private money.** Loans from individuals — a family member, a colleague, a local investor — on terms you negotiate directly. Typical private-money terms are 8–12% annual interest, sometimes with a share of profit instead of or in addition to interest. Private money is flexible and relationship-based, which is both its advantage and its risk: a handshake deal that goes wrong can damage a relationship permanently. Always put private-money terms in writing, with a promissory note and a mortgage or deed of trust recorded against the property, prepared or reviewed by a real estate attorney. Never borrow from someone who cannot afford to lose the money, and never promise a return you cannot control.

**4. Conventional and other institutional loans.** A conventional mortgage on an investment property typically requires 20–25% down, has lower rates (roughly 7–8% in recent markets), and takes 30–45 days to close — and many lenders will not finance a property in poor condition at all. Home equity lines of credit (HELOCs) on your own home are sometimes used, but they put your primary residence at risk and should be considered only with full awareness of that fact. Government-backed loans (FHA, VA) are generally for owner-occupants, not flips, and using them for a property you do not intend to occupy can violate the loan terms. Do not use a loan product for a purpose it prohibits.

### What financing really costs — worked comparison

The anchor deal: $160,000 purchase, $55,000 rehab, $285,000 ARV, 5-month hold.

**Option A — All cash.** You fund $160,000 + $4,000 closing + $55,000 rehab + $7,000 holding = $226,000 of your own capital. Financing cost: $0. Gross profit: $285,000 − $226,000 − $12,000 selling = $47,000. Return on cash invested: roughly 21% over 5 months. The profit is highest, but so is the capital committed and the risk concentration.

**Option B — Hard money.** Loan of $140,000 (87.5% of purchase price) at 11% annual interest, 2 points, 6-month term.
- Points at closing: 2% × $140,000 = $2,800.
- Interest: $140,000 × 11% ÷ 12 × 5 months = $6,417.
- Lender fees, appraisal, and legal: ~$1,800.
- Total financing cost: ~$11,017 (this is the $11,000 in the Module 1 breakdown).
- Your cash in: $160,000 − $140,000 loan + $4,000 closing + $2,800 points + $55,000 rehab + $7,000 holding = $88,800. (Rehab is often funded partly by the loan in draws; the simplified figure above assumes you fund rehab yourself. If the lender funds rehab in draws, your upfront cash falls but the loan balance and interest rise — the total financing cost is similar.)
- Gross profit: $285,000 − $160,000 − $55,000 − $11,000 − $7,000 − $4,000 − $12,000 = $36,000. Return on your $88,800 cash: roughly 40% over 5 months — higher leverage, higher return, and higher risk: if the deal loses $20,000, you still owe the lender in full.

**Option C — Private money.** Loan of $140,000 from a private lender at 10% annual interest, 1 point, no prepayment penalty.
- Points: $1,400. Interest for 5 months: $140,000 × 10% ÷ 12 × 5 = $5,833. Legal and recording: ~$800. Total: ~$8,033.
- Gross profit: roughly $39,000. Cheaper than hard money, but dependent on the relationship and the lender's patience if the project runs long. Agree in writing what happens if you need a 2-month extension.

### The costs beginners forget

- **Points are paid even if the deal fails.** They are due at closing, not at sale.
- **Extension fees.** A 6-month loan that runs to 8 months can add 1% of the loan ($1,400 on a $140,000 loan) plus two more months of interest ($2,500+ at 11%). Budget for the extension; hope you do not need it.
- **Draw fees.** Some hard-money lenders charge $150–$300 per inspection/draw. Five draws can add $750–$1,500.
- **Prepayment penalties.** Rare in hard money, but check. A penalty for selling "too fast" is an unpleasant surprise.
- **Personal guarantees.** Most hard-money and private loans require a personal guarantee, meaning your other assets are at risk if the flip fails. Read the guarantee before you sign, and understand what it covers.

### Getting pre-approved before you offer

Talk to two hard-money lenders and one private-money contact before you need the money. Get a written term sheet: maximum loan, rate, points, term, extension terms, draw process, and fees. Know your maximum loan amount so you can compute your cash requirement for any deal in minutes. Sellers and agents take you seriously when you can show proof of funds or a lender pre-approval with your offer.

### Action steps — Module 6

1. Call two hard-money lenders in your market this week and get written term sheets. Compare rate, points, term, and fees side by side.
2. For the anchor deal, compute total financing cost under cash, hard-money, and private-money scenarios. Write down which you would choose and why.
3. Decide your maximum personal guarantee exposure and your cash reserve: keep at least $10,000–$15,000 in reserve beyond the deal budget for surprises, and do not commit your last dollar to a flip.
4. If you are considering private money, draft the written terms you would propose — rate, term, extension, security — and have an attorney review them before any money moves.

---

## Module 7 — Making the Offer and Closing the Purchase

### Before the offer: your due-diligence checklist

Never offer on a property you have not walked, and never close on a property you have not inspected. The pre-offer checklist:

- **Walk the property with your contractor.** Get a verbal rehab range and note the big unknowns (roof age, panel, sewer, foundation).
- **Run the comps yourself** (Module 3) and compute the MAO (Module 5).
- **Order or review a home inspection.** A general inspection costs $300–$600 and is the best money in the deal. Add a sewer scope ($200–$400) and, if the roof is questionable, a roofer's opinion. If there are signs of structural issues, add a structural engineer ($400–$800).
- **Check title and liens.** Your title company or attorney runs a title search as part of closing, but ask early about known liens, back taxes, HOA dues, and code violations. A $5,000 code lien discovered after closing is your $5,000.
- **Check permits and zoning.** Confirm the property's permitted use, any open permits, and whether your planned work (adding a bathroom, finishing a basement, changing the footprint) is allowed. A quick call to the building department is free.
- **Verify taxes, insurance, and HOA costs.** Get a homeowner's insurance quote before you offer — some properties (old wiring, old roof, prior claims) are expensive or hard to insure. Confirm the annual property tax and any HOA dues and rules.
- **Know the neighborhood.** Visit at different times of day. Check school ratings, crime reports, and recent sales trends. Talk to a neighbor if you can; neighbors know about flooding, noise, and problem properties.

### Structuring the offer

A flip offer is a business proposal, not a personal statement. The components:

- **Price:** your MAO or below. Never offer above your MAO because you "really want the house."
- **Earnest money:** typically 1–3% of the price, held in escrow. It shows seriousness and is at risk if you walk away without a contractual reason.
- **Contingencies:** an inspection contingency (7–14 days to inspect and renegotiate or withdraw), a financing contingency if you are using a loan, and a title contingency. In competitive markets sellers favor fewer contingencies, but waiving the inspection contingency on a first flip is a mistake you may only get to make once. If you must waive something to win, waive the financing contingency only if you have cash or a firm lender commitment — never waive inspection.
- **Closing timeline:** 14–21 days for cash or hard money; 30–45 days for conventional financing. Shorter is more attractive to sellers.
- **Proof of funds or pre-approval letter:** attach it. It separates serious buyers from browsers.
- **As-is language:** most flip purchases are as-is, meaning the seller will not make repairs. That is fine — you are buying a project. But "as-is" does not remove your right to inspect and to walk away during the contingency period if the inspection reveals something your budget cannot absorb.

### Negotiation: how flippers actually win

- **Lead with the numbers, not the emotion.** "Based on comparable sales of $285,000 and a $55,000 renovation, I can pay $145,000" is a negotiation. "I love this house" is not.
- **Offer certainty.** Sellers of distressed properties often value a fast, certain close over the last $5,000. Cash or hard money with a 14-day close and no financing contingency can beat a higher offer that might fall apart.
- **Solve the seller's problem.** A seller who needs to close before a foreclosure date, who lives out of state, or who wants to leave furniture behind may accept less for convenience. Ask your agent what the seller actually needs.
- **Know your walk-away price and use it.** If the seller counters above your MAO, thank them and walk away politely. Leave your number with the agent: "If anything changes, I'm at $145,000." Deals come back more often than beginners expect — after another buyer falls through, after the house sits for 30 more days.
- **Do not bid against yourself.** After an offer is rejected, do not immediately raise it. Wait for a counter, and raise in small, deliberate steps.

### Closing the purchase

Once the offer is accepted, the closing process begins:

1. **Open escrow/title and order the title search.** The title company verifies ownership, liens, and encumbrances, and issues title insurance.
2. **Complete inspections within the contingency period.** If the inspection reveals a $12,000 sewer replacement you did not budget, you have three choices: renegotiate the price, ask for a credit, or walk away. Use the contingency for exactly this.
3. **Finalize financing.** The lender orders an appraisal (if required), verifies your funds, and prepares the loan documents. Hard-money lenders move fast but still need an appraisal or valuation, proof of insurance, and the executed purchase contract.
4. **Final walk-through.** Confirm the property is in the condition you agreed to, and that nothing material has changed or been removed.
5. **Sign and fund.** You sign the closing documents, wire the funds (never wire based on emailed instructions you have not verified by phone with a known number — wire fraud in real estate closings is a real and common crime), and receive the keys. Record the deed.

**Typical purchase closing costs** (budget 2–3% of the purchase price): title search and insurance ($1,000–$2,000), lender fees and points, appraisal ($400–$700), attorney fee where applicable ($500–$1,500), recording fees ($100–$300), and prepaid taxes and insurance. On the $160,000 anchor purchase, $4,000 is a reasonable allowance.

### Action steps — Module 7

1. Build your pre-offer checklist and keep it with every deal file.
2. Line up your inspector, your contractor, your agent, and your lender before you need them under time pressure.
3. Practice the negotiation: for the anchor deal, write the offer letter you would submit at $145,000, including contingencies and timeline.
4. Verify wire instructions by phone with a known number before sending any closing funds. Write this rule on your checklist.

---

## Module 8 — Hiring and Managing Contractors: Bids, Contracts, and Scope of Work

### The contractor is your most important hire

A good contractor is the difference between a flip that finishes on time and on budget and one that does not. On a first flip, the contractor relationship matters more than almost any other decision after the purchase price. Hire slowly, check references thoroughly, and never let price alone decide.

### Finding contractors

- **Referrals from other investors and your agent** are the best source. Ask specifically: "Who have you used on a flip, and would you use them again?"
- **Local investor groups and supplier counters** (lumber yards, tile shops) know who does steady work.
- **Online directories** can help, but verify independently. Reviews are a starting point, not a reference.
- **Avoid** the contractor who is dramatically cheaper than everyone else, who demands large upfront payments, who has no license or insurance, or who cannot provide recent references you can call and projects you can see.

### Vetting: the non-negotiables

- **License:** verify the contractor's license with your state licensing board. Requirements vary by state; some work (electrical, plumbing, HVAC) requires trade-specific licenses.
- **Insurance:** general liability insurance and workers' compensation. Ask for a certificate of insurance naming you as additional insured, and verify it with the insurer — do not accept a photocopy at face value.
- **References:** call at least three recent clients. Ask: Did they finish on time? On budget? How did they handle problems? Would you hire them again? Then go look at one finished project.
- **Financial stability:** a contractor who needs 50% upfront to buy materials may be funding your job with your money because they have no credit with suppliers. That is a warning sign.

### The bid process

1. **Write the scope of work first.** The scope of work (SOW) is a room-by-room, item-by-item description of exactly what will be done, with materials specified (brand and model where it matters, e.g., "LVP flooring, 20-mil wear layer, color to be selected from samples"). A template is included in this course's templates folder. Without a written scope, two bids are not comparable — each contractor is pricing a different job.
2. **Get at least three bids on the same scope.** Walk each contractor through the property with the written scope in hand.
3. **Compare line by line, not just the total.** A bid that is $8,000 cheaper because it omits the bathroom tile and the permits is not cheaper. The bid comparison sheet in the workbook exists for exactly this.
4. **Ask about exclusions.** What is not included? Permits? Dumpster? Materials or labor only? Who supplies appliances and fixtures? Exclusions are where surprise costs live.
5. **Check the schedule.** How long will the job take, when can they start, and how many other jobs are they running at the same time? A contractor running five jobs will not be on yours every day.

### The contract

Never start work without a signed written contract. At minimum it should state:

- The full scope of work (attached as an exhibit).
- The total price, and whether it is fixed-price or time-and-materials. For a first flip, a fixed-price contract tied to the written scope is strongly preferred.
- The payment schedule tied to completed milestones (see Module 9), never large upfront payments. A common structure: 10% at signing, then payments at defined milestones, with 10% retained until final completion and punch-list sign-off.
- Start date and completion date, and what happens if the date slips.
- Who supplies materials, and who pays for permits.
- Change-order procedure: no extra work without a written, signed change order stating the cost and the time impact (Module 10).
- Warranty: typically one year on workmanship.
- Insurance and licensing representations, and the requirement to use licensed subcontractors for electrical, plumbing, and HVAC.
- Cleanup, debris removal, and protection of the property.
- Termination terms: what happens if either side needs to end the contract.

Have a real estate attorney review your first contractor contract. The fee ($300–$800) is small compared with the cost of a dispute.

### Managing the relationship

- **Be the client, not the crew.** You manage schedule, budget, and quality; the contractor manages the workers. Do not hire or direct the subcontractors yourself.
- **Visit the site on a fixed schedule** (two to three times a week) and keep a written log with photos. Photos are your record if there is ever a dispute.
- **Pay on milestones, on time.** A contractor who is paid promptly for completed work will prioritize your job. A contractor who has to chase payment will not.
- **Address problems early and in writing.** A small issue discussed on day three is a conversation. The same issue discovered on day thirty is a conflict.
- **Never pay for work that is not done.** Inspect before you release a draw (Module 9). This is the single most important payment discipline in flipping.

### Red flags

A contractor who asks for 50% upfront, who will not put the scope in writing, who has no insurance, who pressures you to skip permits, who wants to be paid in cash with no receipts, or who cannot start for three months but promises to finish in four weeks — walk away. There are other contractors.

### Action steps — Module 8

1. Ask three people for contractor referrals this week and start a list.
2. Write a scope of work for a real or hypothetical rehab using the template in this course.
3. Get two bids on the same written scope and compare them line by line with the bid comparison sheet.
4. Verify a contractor's license and insurance yourself, once, so you know how the process works in your state.

---

## Module 9 — Running the Rehab: Schedule, Draw Schedule, and Inspections

### The rehab schedule

A rehab without a schedule is a hobby. Before work starts, agree on a written schedule with start and finish dates for each phase. A typical 8–10 week schedule for a $55,000 cosmetic-to-moderate rehab:

| Week | Work |
|---|---|
| 1 | Demolition, dumpster, rough inspections; order long-lead items (cabinets, windows, flooring) |
| 2–3 | Rough work: framing, electrical, plumbing, HVAC |
| 3 | Rough inspections; insulation and drywall |
| 4–5 | Kitchen and bathroom installation: cabinets, tile, fixtures |
| 5–6 | Flooring, trim, doors |
| 6–7 | Paint, fixtures, hardware |
| 7–8 | Appliances, final touches, punch list |
| 8–9 | Cleaning, final inspections, staging |

Order long-lead items on day one. Cabinets, windows, and specialty tile can take 2–6 weeks to arrive, and a job that waits on a cabinet delivery is a job that is paying holding costs for nothing.

### The draw schedule

A draw schedule ties payments to completed milestones. It protects you (you never pay for unfinished work) and it protects the contractor (they are paid promptly when milestones are met). A typical draw schedule for a $55,000 rehab contract:

| Draw | Milestone | Amount |
|---|---|---|
| 1 | Contract signing / mobilization | $5,500 (10%) |
| 2 | Demolition complete, rough-in complete, rough inspections passed | $13,750 (25%) |
| 3 | Drywall complete, kitchen cabinets installed | $13,750 (25%) |
| 4 | Flooring, tile, trim, paint complete | $11,000 (20%) |
| 5 | Punch list complete, final inspections passed, final walk-through approved | $11,000 (20%) |

Total: $55,000. Note that the final 10–20% is held until the punch list is complete. This "retainage" is your leverage to get the last small items finished — the items that matter to a buyer and that are the first to be skipped when a contractor moves to the next job.

**If a lender is funding the rehab**, the lender will have its own draw process: you request a draw, the lender sends an inspector ($150–$300 per visit), and funds are released after the inspector confirms the work. Budget 3–5 business days per draw and keep the contractor informed so they can plan around it.

### Inspections during the rehab

- **Rough inspections** by the building department after framing, electrical, plumbing, and HVAC rough-in, and before drywall closes the walls. Never let drywall go up before rough inspections pass.
- **Final inspections** for permits that were pulled, before listing.
- **Your own inspections** at each draw milestone: walk the work with the contractor, check it against the scope, and photograph everything. Pay particular attention to waterproofing in showers, tile work, cabinet installation, and paint finish — the items buyers notice first.
- **A pre-listing inspection** (optional, $300–$600) can catch issues before a buyer's inspector finds them. Fixing a $400 issue yourself is better than losing a $285,000 sale over it.

### Running the week

A simple weekly rhythm keeps a rehab on track:

- **Monday:** confirm the week's work plan with the contractor by text or email (written, so there is a record).
- **Midweek visit:** walk the site, photograph progress, note anything off-scope or off-schedule.
- **Friday:** confirm next week's plan and any material orders or deliveries needed.
- **Every draw:** inspect, photograph, and sign off in writing before payment is released.

Keep a single project file — physical or digital — with the contract, scope, change orders, permits, inspection reports, photos, receipts, and the draw log. When the house sells, that file is your record for taxes (Module 13) and your proof of what was done if a buyer ever asks.

### Common schedule killers

- **Material delays.** Order early, confirm delivery dates in writing, and have a backup supplier.
- **Permit delays.** Submit permit applications the day you close, not the day you want to start. Some jurisdictions take 2–4 weeks.
- **Scope changes mid-job.** Every change costs time as well as money (Module 10). Batch decisions and decide before work starts where possible.
- **Contractor overcommitment.** A contractor who takes your job and then disappears for a week to finish another job is a scheduling problem you should have caught in vetting (Module 8). Address it immediately and in writing.
- **Weather.** Exterior work in winter or rainy seasons takes longer. Build a week of weather buffer into the schedule.

### Action steps — Module 9

1. Draft a week-by-week schedule for the anchor deal's rehab and a matching draw schedule using the templates.
2. Decide your site-visit rhythm and put it in your calendar before the rehab starts.
3. Set up your project file and your photo log on day one.
4. Order long-lead items (cabinets, windows, flooring) in the first week — never in the fourth.

---

## Module 10 — Change Orders and Budget Overruns: How to Control Them

### What a change order is

A change order is a written, signed amendment to the contract that describes additional or different work, its cost, and its effect on the schedule. The rule is simple and absolute: **no change order, no extra work, no extra payment.** Verbal agreements on a job site are forgotten, disputed, or both. A change order takes five minutes to write and prevents most rehab disputes.

A change order should state: what is changing and why; the exact additional cost (labor and materials separately); the effect on the completion date; and the signatures of both parties. Keep every change order in the project file.

### The three kinds of overrun

**1. Discovered conditions.** The work you could not see until you opened a wall: rotted framing, a leaking drain, knob-and-tube wiring, a cracked slab. These are genuine unknowns, and they are exactly what the 10–15% contingency is for. When a discovered condition appears, the process is: stop the affected work, document it with photos, get a price to fix it, sign a change order, and draw from the contingency. Do not let the contractor proceed on a verbal "we'll sort it out later."

**2. Scope creep.** The work you chose to add: upgrading from laminate to quartz, adding recessed lighting, replacing a functioning vanity because you found a nicer one. Scope creep is a decision, and every decision has a price. The discipline is to ask three questions before approving any addition: Does this increase the sale price or the speed of sale by more than it costs? Would a buyer in this neighborhood pay for it? Can I afford it from the contingency without endangering the budget? If the answer to any of these is no, do not do it. The most expensive sentence in flipping is "while we're at it."

**3. Estimating error.** The work you knew about but priced wrong: the tile that costs $3,000 more than the allowance, the kitchen that needs a new subfloor. Estimating errors are reduced by the line-item budget (Module 4) and by getting real bids (Module 8), but they are never eliminated. The contingency absorbs the small ones; the big ones require a decision — cut scope elsewhere, fund the difference from reserves, or accept a lower profit.

### The overrun decision framework

When an overrun appears, work through these steps in order:

1. **Quantify it.** Get the exact cost in writing. "About $5,000" is not a number.
2. **Check the contingency.** How much is left? Does the overrun fit inside it?
3. **Check the profit.** Recompute the deal with the overrun included. If the deal still clears your minimum profit, proceed. If it does not, go to step 4.
4. **Find the offset.** Can scope be cut elsewhere without hurting the sale? (Example: keep the existing tubs and refinish them instead of replacing — the $3,000 saving in the anchor deal came from exactly this kind of decision.) Can the sale price be supported higher by the additional work? Is there a cheaper way to achieve the same result?
5. **Decide, in writing.** Approve the change order, reject it, or pause and reassess. A paused decision is better than an unexamined approval.

### Worked example — the anchor deal hits a $9,000 problem

Mid-rehab, the contractor opens the bathroom wall and finds rotted framing and a leaking cast-iron drain. Repair cost: $6,500. In the same week, the sewer scope (which should have been done before closing) reveals a cracked line: $2,500 to repair. Total overrun: $9,000.

- Original rehab budget: $55,000. Contingency at 10%: $5,500. The overrun exceeds the contingency by $3,500.
- Recomputed profit: $36,000 gross profit − $9,000 = $27,000. The deal still works, but the margin is thinner.
- Offsets: the contractor suggests keeping the existing kitchen layout (already planned) and using a mid-range faucet and lighting package instead of the premium one, saving $1,500. The flipper approves the $9,000 in change orders, cuts $1,500 elsewhere, and the final rehab lands at $62,500. Final gross profit: roughly $28,500.

The lesson is not that the flipper was unlucky. The lesson is that the sewer scope should have been done before closing, when the $2,500 could have been a negotiation point, and that the contingency did its job. A flipper with no contingency and no reserves would have had to stop work, borrow more, or sell the half-finished house at a loss.

### The weekly budget check

Every week, update a simple running total: original budget, approved change orders, spent to date, remaining, and projected final cost. Five minutes a week keeps a $5,000 overrun from becoming a $15,000 surprise at the end. The holding-cost tracker and draw-schedule tracker in the workbook are designed for this weekly habit.

### Action steps — Module 10

1. Write your change-order rule on the first page of your project file: "No written change order, no extra work."
2. Practice the overrun decision framework on the anchor deal's $9,000 example above, with your own offsets.
3. Decide your contingency policy now: 10% for cosmetic rehabs, 15% for moderate rehabs, 20% when there are unknowns. Write it down and apply it to every budget.
4. Make a list of the three scope items you are most likely to be tempted by (upgraded counters, extra lighting, nicer fixtures) and decide in advance what would justify each one.

---

## Module 11 — Staging and Pricing for a Fast Sale

### Why speed matters

Every month on the market costs $1,500–$3,000 in holding costs (Module 1), and a stale listing invites low offers. A house that sells in 14 days at $285,000 is worth more to you than the same house selling in 90 days at $290,000. Price and presentation are the two levers that control speed, and both are cheaper than carrying the house for another month.

### Staging: what it is and what it costs

Staging is furnishing and decorating a vacant home so buyers can see themselves living in it. You do not need to stage every room; the highest-impact areas are the living room, the primary bedroom, and the kitchen/dining area.

- **Full professional staging:** $2,000–$5,000 for a 2–3 month rental of furniture and accessories in a typical single-family home.
- **Partial staging:** $800–$2,000 for key rooms only.
- **DIY / light staging:** $300–$800 for new towels, a shower curtain, a few plants, fresh flowers, a bowl of fruit, and clean, neutral bedding on the primary bed. For a modest flip, light staging plus excellent cleaning and photography is often enough.
- **Virtual staging:** $25–$75 per photo for digitally furnished images. Useful for online listings, but the house itself is still empty at showings, so it is a supplement, not a substitute.

**Staging rules that work:** neutral colors; clear every surface by half; remove personal items and anything that signals the renovation (paint cans, tools, leftover materials); make the entry bright and clean; open blinds and curtains for every showing; keep the lawn mowed and the porch swept. The house should smell clean, not perfumed — air fresheners and candles can signal that you are covering something up.

### Photography

Professional real estate photography costs $150–$400 and is one of the highest-return expenses in a flip. Most buyers decide whether to visit based on the photos. Requirements: shoot on a bright day, all lights on, blinds open, decluttered rooms, and wide-angle shots that show the room, not the furniture. Include a floor-plan-style shot of the kitchen and the primary bedroom, and at least two exterior shots (front and backyard). Drone photos ($100–$250 extra) are worth it for larger lots or scenic settings. Do not use heavily edited photos that misrepresent the property — they waste showings and erode trust.

### Pricing for a fast sale

Pricing is where ARV meets reality. Your list price should be based on the same comps you used for ARV, updated with any sales that closed while you were renovating.

- **Price at the comp-supported value.** If your updated comps support $280,000–$290,000, listing at $285,000 is honest and defensible. Listing at $310,000 because you "need" the profit is not a pricing strategy; it is a wish.
- **Price slightly below a round number.** $284,900 captures buyers searching up to $285,000; $289,000 captures buyers searching up to $290,000. Small differences in list price change which search filters see your home.
- **Consider pricing just below the comp cluster to generate competition.** In a strong market, listing at $279,000 when comps support $285,000 can produce multiple offers and a sale above asking. This works only in genuinely competitive markets and only with your agent's advice — in a slow market it simply leaves money on the table.
- **Plan the price reduction in advance.** Agree with your agent before listing: if there are no offers in 14 days, reduce by 2–3%; if there are no offers in 30 days, reduce again and reassess. A planned reduction is a strategy; a panicked reduction after 60 days is a signal to buyers that you will keep dropping.

### What buyers notice — and what they do not

Buyers notice: the kitchen, the bathrooms, the floors, the paint, the light, the smell, and the curb appeal. They do not notice (and will not pay for): the brand of the water heater, the upgraded electrical panel, the premium underlayment, or the expensive grout. Spend your money where buyers look, and spend the minimum that is safe and code-compliant where they do not.

### Action steps — Module 11

1. Decide your staging level for your next flip and budget for it in the rehab budget, not as an afterthought.
2. Book a real estate photographer before the rehab finishes so photos happen the day the house is ready.
3. With your agent, set the list price, the first reduction trigger (14 days), and the second reduction trigger (30 days) before the house goes on the market.
4. Walk a staged home and an unstaged home in your market and note the difference in how each feels. That feeling is what buyers pay for.

---

## Module 12 — Selling: Agent, Flat Fee, or FSBO

### The three ways to sell

**1. Full-service listing agent.** The standard route: an agent lists the home on the MLS, markets it, shows it, negotiates offers, and manages the closing. Typical total commission is 5–6% of the sale price, split between the listing agent and the buyer's agent. On a $285,000 sale at 6%, that is $17,100 — though commissions are negotiable and vary by market, and the structure of who pays what has been changing; confirm current local practice with your agent and attorney. The anchor deal's $12,000 selling-cost figure assumes a negotiated total commission of roughly 4% plus closing costs, which is achievable in many markets for an investor who brings repeat business — but do not assume it. Get the commission in writing before you list.

**Advantages:** maximum exposure through the MLS, professional negotiation, and someone managing the process while you work on the next deal.
**Disadvantages:** the largest single cost in the deal after the purchase and the rehab.

**2. Flat-fee MLS listing.** You pay a flat fee ($300–$1,000) to list on the MLS, and you handle showings, negotiation, and paperwork yourself, usually with an attorney's help. You still typically offer a commission to the buyer's agent (commonly 2.5–3%) to attract represented buyers.

**Advantages:** saves the listing-agent commission (roughly $7,000–$8,500 on a $285,000 sale).
**Disadvantages:** you do the work — showings, calls, negotiations, contracts — and you do it without the market knowledge and negotiation experience of a full-service agent. A pricing or negotiation mistake can cost more than the commission you saved.

**3. For sale by owner (FSBO).** You sell without any agent, marketing the property yourself. You save all commission if the buyer is also unrepresented, but you still typically pay a buyer's agent commission if the buyer has one, and you handle everything.

**Advantages:** maximum commission savings.
**Disadvantages:** limited exposure (no MLS), more work, higher legal risk, and statistically lower sale prices — FSBO homes commonly sell for less than agent-listed homes, which can erase the commission saving. For a first flip, FSBO is rarely the right choice.

### Choosing an agent

If you use a full-service agent (recommended for a first flip), choose one who has sold renovated homes in your neighborhood, who understands investor timelines, and who will give you an honest pricing opinion — not the highest number to win your listing. Ask: How many homes have you sold in this neighborhood in the last year? What is your average days on market? What would you list this home for, and what comps support that? An agent who cannot answer with comps is not the right agent.

### The offer and negotiation

When offers arrive, evaluate them on more than price:

- **Price and terms.** A $285,000 offer with a financing contingency and an appraisal contingency is weaker than a $280,000 cash offer with no contingencies and a 14-day close.
- **Earnest money.** More earnest money signals a more committed buyer.
- **Contingencies.** Inspection, financing, appraisal, and sale-of-current-home contingencies each add a chance the deal falls apart. A buyer who waives the appraisal contingency (or covers an appraisal gap in cash) is a stronger buyer.
- **Closing timeline.** Faster is better for you, but make sure the buyer's lender can actually meet the timeline.
- **Proof of funds / pre-approval.** Verify them. A pre-approval letter from a real lender is meaningful; a verbal assurance is not.

Your agent negotiates on your behalf, but you make the final decisions. Common negotiation points: price, seller concessions (a credit toward the buyer's closing costs, typically 1–3%), repairs requested after the buyer's inspection, and the closing date. Budget for the buyer's inspection to find something — even a good renovation has a loose outlet or a dripping valve. A $500 repair credit is cheaper than losing the buyer.

### Closing the sale

Once an offer is accepted: the buyer orders an inspection and an appraisal; the title company prepares the closing; you provide the disclosures your state requires (lead paint, known defects, and any other state-mandated disclosures — be thorough and honest; hiding a known defect is a legal liability that survives the sale); and at closing you sign the deed, pay off your loan, pay the commission and closing costs, and receive the net proceeds. Sale-side closing costs typically run 1–2% of the sale price beyond commission, including title, attorney, recording, and transfer taxes where applicable.

### Action steps — Module 12

1. Interview two listing agents before your rehab finishes. Ask each for a pricing opinion with comps.
2. Get the commission and the marketing plan in writing before you sign a listing agreement.
3. Decide your minimum acceptable net proceeds before offers arrive, so you can evaluate an offer calmly instead of emotionally.
4. Ask your attorney which seller disclosures your state requires, and prepare them before the buyer's inspection, not after.

---

## Module 13 — Taxes and Holding Costs on a Flip

> This module is general education about how taxes and holding costs commonly work. Tax law is complex, varies by state, and changes frequently. It is not tax advice. Consult a qualified tax professional (CPA or enrolled agent) about your specific situation before you buy, sell, or file.

### Holding costs: the monthly burn

Holding costs are the costs of owning the property while you renovate and sell it. On a typical flip they run $1,500–$3,000 per month. The components:

| Holding cost | Typical monthly amount | Notes |
|---|---|---|
| Loan interest | $1,000–$1,600 | On a $140,000 hard-money loan at 11%: ~$1,283/month |
| Property taxes | $200–$450 | Based on assessed value; varies widely by jurisdiction |
| Homeowner's insurance (vacant/renovation policy) | $150–$300 | A standard homeowner's policy may not cover a vacant home under renovation — get a builder's risk or vacant-dwelling policy |
| Utilities (electric, water, gas) | $150–$300 | Higher during rehab (power tools, water for trades) |
| Lawn care and maintenance | $75–$150 | An unkempt lawn signals a distressed property to buyers and neighbors |
| HOA dues (if any) | $0–$400 | Confirm before you buy |
| **Total (anchor deal, 5 months)** | **~$1,400/month** | **$7,000 over 5 months** |

The anchor deal's $7,000 holding cost assumes $1,400 per month for 5 months. If the project runs to 8 months, holding costs rise to $11,200 — an extra $4,200 that comes straight out of profit. Speed is a tax strategy as well as a business strategy.

### How flip profits are taxed (general principles, US)

- **Short-term capital gains vs. ordinary income.** A property held for one year or less and sold at a profit generally produces a short-term capital gain, taxed at ordinary income rates. However, if flipping is your business — you buy and sell properties regularly with the intent to profit — the IRS may treat you as a "dealer" and the profit as ordinary business income, which can also be subject to self-employment tax. The dealer determination depends on your facts: frequency of sales, intent, advertising, and how the activity is conducted. This is a question for your CPA, not for a course.
- **No 1031 exchange for flips.** A 1031 like-kind exchange defers tax on investment property, but property held primarily for sale to customers (flip inventory) generally does not qualify. Do not plan a flip around a 1031 exchange.
- **Deductible costs.** Rehab costs, financing costs, holding costs, and selling costs are generally accounted for as part of the property's cost basis or as business expenses, depending on how the activity is structured. Keep every receipt, invoice, and bank record. Your CPA will tell you how to categorize them; your job is to have the records.
- **Entity structure.** Many flippers operate through an LLC, which can affect liability, taxation, and how lenders treat you. Forming an LLC is a legal decision with state-specific costs and consequences. Discuss it with an attorney and a CPA before your first purchase, not after.
- **Estimated taxes.** If a flip produces a large profit, you may owe estimated tax payments during the year rather than only at filing time. Ask your CPA whether estimated payments apply to you.
- **State taxes.** Some states have their own capital gains or transfer taxes, and some cities impose transfer taxes at sale. Confirm the transfer tax for your jurisdiction before you compute your net proceeds.

### Record-keeping that saves you money

Keep a single file per flip with: the purchase settlement statement, all contractor contracts and invoices, material receipts, lender statements, insurance and tax bills, utility bills, the listing agreement, and the sale settlement statement. Photograph receipts if they are paper. Reconcile the file monthly. When tax time comes, a complete file is the difference between claiming every legitimate deduction and guessing.

### Action steps — Module 13

1. Before your first flip, have a 30-minute conversation with a CPA about dealer status, entity structure, and record-keeping. Bring this module's cost list.
2. Set up a separate bank account (or at minimum a separate ledger) for each flip, so no personal expense mixes with deal expenses.
3. Build your holding-cost tracker (workbook) for your next deal and update it monthly.
4. Ask your CPA whether estimated tax payments apply to you, and calendar the quarterly due dates if they do.

---

## Module 14 — Three Full Worked Deal Case Studies with Real Numbers

These three case studies use the same structure and the same cost categories, so you can compare them directly. All three are teaching examples built from realistic market assumptions — they are not records of actual transactions, and no property address is given because none of these is a real property. The assumptions are stated with each case so you can test how the outcome changes when an assumption changes.

**Assumptions common to all three cases:** 3-bed, 2-bath single-family home, 1,400–1,500 sq ft; hard-money financing at 11% annual interest, 2 points; 6% total selling costs (commission plus concessions) is used in Cases 2 and 3, while Case 1 uses the anchor deal's itemized $12,000; property taxes, insurance, and utilities as in Module 13.

### Case Study 1 — The Profitable Flip (the anchor deal)

**The property:** A 1978 ranch, 1,450 sq ft, 3-bed/2-bath, on a quiet street. Estate sale, dated but structurally sound. Cosmetic-to-moderate rehab.

| Line item | Amount |
|---|---|
| **Purchase** | |
| Purchase price | $160,000 |
| Purchase closing costs | $4,000 |
| **Rehab** | |
| Kitchen renovation | $16,000 |
| Two bathroom renovations | $14,000 |
| Flooring throughout | $7,000 |
| Interior paint | $4,000 |
| Exterior paint + landscaping | $4,500 |
| Roof repair + gutters | $3,500 |
| Electrical (panel + fixtures) | $2,500 |
| Plumbing repairs + water heater | $2,000 |
| Drywall, doors, trim, hardware | $2,500 |
| Permits, dumpster, cleaning | $2,000 |
| **Rehab subtotal** | **$58,000** |
| Less value engineering (refinish tubs, keep layout) | ($3,000) |
| **Rehab total** | **$55,000** |
| **Financing (hard money, $140,000 loan, 5 months)** | |
| Points (2%) | $2,800 |
| Interest (11% × 5 months) | $6,417 |
| Lender fees, appraisal, legal | $1,800 |
| **Financing total** | **$11,017** |
| **Holding (5 months × $1,400)** | **$7,000** |
| **Selling** | |
| Agent commission (negotiated) + concessions | $9,500 |
| Sale closing costs | $2,500 |
| **Selling total** | **$12,000** |
| **TOTAL COST** | **$249,017** |
| Sale price (ARV $285,000, sold at list) | $285,000 |
| **GROSS PROFIT BEFORE TAX** | **$35,983** |
| **ROI on cash invested (~$88,800)** | **~40% over 5 months** |

**What went right:** The buyer paid $15,500 above the 70% rule MAO — but the rehab came in on budget, the project finished in 5 months, the ARV was conservative and accurate, and the sale happened in 18 days at list price. The margin was earned by execution, not by luck.

**What could have gone wrong:** A 3-month delay would have added roughly $4,200 in holding costs and $3,850 in interest, cutting profit to about $28,000. A $10,000 rehab overrun would have cut it to about $26,000. The deal had room for one problem, not three.

### Case Study 2 — The Break-Even Flip

**The property:** A 1985 split-level, 1,500 sq ft, 3-bed/2-bath, in a neighborhood with a $260,000 price ceiling. The flipper paid $150,000 — the asking price — after a bidding war, and estimated a $45,000 rehab and a $260,000 ARV.

| Line item | Amount |
|---|---|
| Purchase price | $150,000 |
| Purchase closing costs | $3,500 |
| Rehab (budgeted $45,000; actual $52,000 — see notes) | $52,000 |
| Financing (hard money, $125,000 loan, 7 months: 2 points $2,500 + interest $8,021 + fees $1,500) | $12,021 |
| Holding (7 months × $1,400) | $9,800 |
| Selling (6% of $250,000 sale price) | $15,000 |
| **TOTAL COST** | **$242,321** |
| Sale price | $250,000 |
| **GROSS PROFIT BEFORE TAX** | **$7,679** |

**What went wrong:** Three things, each survivable alone, fatal together. First, the flipper overpaid: the 70% rule MAO was ($260,000 × 0.70) − $45,000 = $137,000, and they paid $150,000 — $13,000 over. Second, the rehab overran by $7,000 (a sewer repair and a subfloor replacement that were not in the budget, and no contingency had been set). Third, the ARV was optimistic: the home sold for $250,000, not $260,000, because the highest comp was a fully renovated home on a better street and the appraiser would not support $260,000. The project also took 7 months instead of 5, adding $2,800 in holding costs and $2,500 in extra interest.

**The outcome:** $7,679 of gross profit before tax on roughly $85,000 of cash invested, over 7 months — about a 9% return for seven months of work and risk, before income tax. After tax and the value of the flipper's time, this deal was effectively break-even. The flipper did not lose money, but the return did not justify the risk.

**The lesson:** The break-even flip is not caused by one catastrophe. It is caused by paying a little too much, budgeting a little too low, and estimating ARV a little too high — and by a schedule that slips two months. Each error is small; together they consume the entire profit.

### Case Study 3 — The Losing Flip

**The property:** A 1965 bungalow, 1,300 sq ft, 3-bed/1-bath, bought at auction for $110,000. The flipper had not inspected the interior, had not run comps, and estimated a $40,000 rehab and a $225,000 ARV from online estimates.

| Line item | Amount |
|---|---|
| Purchase price (auction) | $110,000 |
| Purchase closing costs + auction fees | $5,000 |
| Rehab (budgeted $40,000; actual $68,000 — see notes) | $68,000 |
| Financing (hard money, $95,000 loan, 10 months: 2 points $1,900 + interest $8,708 + extension fee $950 + fees $1,500) | $13,058 |
| Holding (10 months × $1,500) | $15,000 |
| Selling (6% of $195,000 sale price) | $11,700 |
| **TOTAL COST** | **$222,758** |
| Sale price | $195,000 |
| **GROSS PROFIT (LOSS) BEFORE TAX** | **($27,758)** |

**What went wrong:** Almost everything, and each error is a lesson in this course. The auction purchase meant no inspection: the house had foundation movement, a failing sewer line, and a roof that needed full replacement, not repair — $18,000 of the $28,000 rehab overrun. The ARV was based on online estimates and listings, not closed comps: the neighborhood ceiling was $200,000, and the home sold for $195,000 after 74 days on the market and two price reductions. The project took 10 months, not the planned 4, because the contractor was unreliable, permits took 5 weeks, and the foundation work required an engineer. The loan had to be extended, adding a $950 extension fee and $4,000+ in extra interest.

**The outcome:** a loss of $27,758 before tax, on roughly $110,000 of cash invested. The flipper's own capital absorbed the loss, and the project consumed ten months.

**The lesson, stated plainly:** The money was lost at the purchase, not at the sale. The day the flipper bid $110,000 at auction without an inspection, without comps, and without a contractor's rehab estimate, the loss was already likely. Everything after that was execution on a bad decision. The single most valuable habit in this course — run the comps, get the rehab bid, compute the MAO, and walk away when the numbers do not work — would have prevented this loss entirely.

### Comparing the three cases

| | Case 1 (Profit) | Case 2 (Break-even) | Case 3 (Loss) |
|---|---|---|---|
| Purchase | $160,000 | $150,000 | $110,000 |
| Rehab (budget → actual) | $55,000 → $55,000 | $45,000 → $52,000 | $40,000 → $68,000 |
| ARV (estimated → actual sale) | $285,000 → $285,000 | $260,000 → $250,000 | $225,000 → $195,000 |
| Months held | 5 | 7 | 10 |
| Total cost | $249,017 | $242,321 | $222,758 |
| **Net profit (loss)** | **$35,983** | **$7,679** | **($27,758)** |

The pattern is consistent: the profitable flip had conservative numbers and on-time execution; the break-even flip had three small errors; the losing flip had no due diligence at all. Your job is not to avoid all errors — it is to build a process that catches them before you own the house.

### Action steps — Module 14

1. Recompute all three case studies yourself, line by line. Change one assumption in each (sale price −5%, rehab +10%, hold +2 months) and see how the outcome moves.
2. Write down, for each case, the single decision that mattered most.
3. Build your own "deal post-mortem" habit: after any deal you analyze — bought or not — write one paragraph on what the numbers taught you.

---

## Module 15 — Your First Flip: A 120-Day Plan from Offer to Closing

### The plan

This is a day-by-day framework for a first flip. It assumes a cosmetic-to-moderate rehab of 8–10 weeks and a 2–4 week sale. Adjust the dates to your market, but keep the sequence: diligence first, purchase second, rehab third, sale last. Do not compress diligence to save time. Diligence is the cheapest part of the flip.

**Days 1–14 — Learn the market and build the team.**
- Define your buy box (Module 2).
- Interview two investor-friendly agents, two hard-money lenders, and one CPA.
- Ask for contractor referrals and start vetting two or three contractors.
- Pull closed comps in your target neighborhoods and learn the price ceilings.
- Set up your deal file, your budget spreadsheet, and your cash reserve. Confirm your maximum survivable loss in writing.

**Days 15–30 — Find and analyze deals.**
- Review 15–25 properties. Run ARV and MAO math on the five best.
- Walk your top two or three with a contractor and get verbal rehab ranges.
- Make your first offers at or below MAO. Expect rejections. A rejection is not a failure — it is the market telling you the price.
- Do not chase a deal above your MAO. If nothing works in 30 days, widen the search area or lower the price range — do not raise the offer price.

**Days 31–45 — Offer accepted, due diligence, close.**
- Inspection, sewer scope, roof check, title search, insurance quote, permit check.
- Renegotiate or walk away if diligence reveals a problem the budget cannot absorb.
- Finalize financing, sign, fund, and close. Verify wire instructions by phone.
- Day 45 (target close): you own the house. Photograph every room before demolition begins.

**Days 46–50 — Mobilize.**
- Sign the contractor contract with the written scope and the draw schedule.
- Submit permit applications. Order cabinets, windows, flooring, and fixtures.
- Set up insurance (builder's risk / vacant dwelling), utilities in your name, and a lockbox.
- Confirm the start date and the weekly site-visit rhythm.

**Days 51–110 — Rehab (8–9 weeks).**
- Week 1: demolition and rough-in.
- Weeks 2–4: rough work, inspections, drywall.
- Weeks 4–7: kitchen, baths, flooring, trim, paint.
- Weeks 7–9: fixtures, appliances, punch list, final inspections, cleaning.
- Weekly: update the budget tracker, photograph progress, release draws only for completed milestones, and approve changes only by written change order.
- Week 7: interview listing agents and agree on a list price and a pricing-reduction plan.

**Days 111–120 — List, sell, close.**
- Professional photos, staging, and listing on the MLS.
- Showings and open house in the first weekend.
- Evaluate offers on price, terms, and certainty — not price alone.
- Buyer's inspection and appraisal; address reasonable repair requests with a credit rather than new work where possible.
- Close, pay off the loan, pay commission and closing costs, and receive net proceeds.
- **Day 120 (target):** the sale closes. Write your post-mortem: what the budget got right, what it missed, what you would do differently, and your actual profit. That document is worth as much as the profit — it is the foundation of your second flip.

### If the plan slips

It will slip somewhere. A 120-day plan that becomes 150 days is normal for a first flip. The plan's job is not to be perfect; it is to tell you early that you are slipping, so you can act — cut scope, add a crew, reduce the price, or extend the loan — while you still have options. A flipper who discovers the delay in week 12 has fewer options than one who sees it in week 4.

### Your first-flip rules (tape these to your desk)

1. Buy below your MAO or do not buy.
2. Budget line by line, with a contingency, and never without one.
3. Never pay for work that is not done.
4. No change order, no extra work.
5. Price to sell in 30 days, not to impress yourself.
6. Keep every receipt and every photo.
7. If a deal needs everything to go right, it is the wrong deal.

### Action steps — Module 15

1. Copy the 120-day plan into your calendar with real dates, starting from a date you choose this week.
2. Complete Days 1–14 before you look at a single listing with the intent to offer.
3. After your first flip — bought or not — write the post-mortem and file it with the deal file.
4. Decide now what your second flip looks like: same buy box, or a different one based on what the first taught you.

---

## Appendix A — Glossary of Terms

- **ARV (After-Repair Value):** the estimated sale price of a property after renovation, based on comparable closed sales.
- **Assignment fee:** the fee a wholesaler charges to assign a purchase contract to an investor.
- **Buy box:** the defined profile of properties an investor will pursue (price, size, area, condition).
- **Change order:** a written amendment to a construction contract describing additional work, its cost, and its schedule impact.
- **Comp (comparable sale):** a recently sold home similar to the subject property, used to estimate value.
- **Draw:** a payment released to a contractor when a defined milestone is complete and inspected.
- **Draw schedule:** the schedule of milestone payments in a construction contract.
- **Earnest money:** a good-faith deposit held in escrow with an offer.
- **FSBO (For Sale By Owner):** selling a property without a listing agent.
- **Hard money:** a short-term, asset-based loan from a private lender, typically at higher rates and shorter terms than a conventional mortgage.
- **Holding costs:** the ongoing costs of owning a property (interest, taxes, insurance, utilities, maintenance).
- **MAO (Maximum Allowable Offer):** the highest price an investor should pay, commonly computed as (ARV × 70%) − rehab cost.
- **MLS (Multiple Listing Service):** the database of properties listed for sale by real estate agents.
- **Points:** upfront fees on a loan, expressed as a percentage of the loan amount (1 point = 1%).
- **Punch list:** the list of small remaining items to complete before a project is considered finished.
- **Retainage:** the portion of a contract price held back until final completion.
- **Scope of work (SOW):** the written, itemized description of the work a contractor will perform.
- **Wholesaler:** an investor who contracts a property and assigns the contract to another buyer for a fee.

## Appendix B — Due-Diligence Checklist (tear-out)

- [ ] Walked the property with a contractor
- [ ] ARV computed from 3–5 closed comps
- [ ] MAO computed at 70% (and checked at 65%)
- [ ] Rehab budget written line by line, with contingency
- [ ] Home inspection ordered and reviewed
- [ ] Sewer scope completed
- [ ] Roof assessed
- [ ] Title search ordered; liens, back taxes, HOA dues checked
- [ ] Permits and zoning confirmed with the building department
- [ ] Insurance quote obtained (builder's risk / vacant dwelling)
- [ ] Financing term sheet in hand; cash requirement computed
- [ ] Contractor license and insurance verified
- [ ] Three bids on the same written scope
- [ ] Exit plan: list price, reduction triggers, and minimum net proceeds decided before closing

## Appendix C — Resources for Further Learning

- Your state real estate commission's website — licensing, disclosure, and contract requirements in your state.
- Your county tax assessor and recorder's websites — ownership, tax, and lien records (usually free).
- Your local building department — permit requirements and timelines.
- A local real estate investor association or meetup — referrals, wholesalers, and hard-money lender introductions.
- A real estate attorney and a CPA in your state — the two professionals every flipper should have before the first purchase.

---

*End of course. Remember the disclaimer at the front: this is real estate education, not individualized investment, legal, tax, or financial advice. Verify every number, regulation, and assumption for your specific property and jurisdiction, and consult qualified professionals before you buy, finance, renovate, or sell.*
