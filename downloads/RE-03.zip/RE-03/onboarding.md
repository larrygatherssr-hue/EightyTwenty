# Customer Onboarding — The Fix-and-Flip Profit System (RE-03)

Welcome. This guide tells you what to do first, how to use each file, and how to work through the course in about six weeks — before you make your first offer.

> **Disclaimer:** This product is real estate education only. It is not individualized investment, legal, tax, or financial advice. Consult a qualified real estate attorney, a licensed real estate agent, a tax professional, and a licensed lender in your state before buying, financing, renovating, or selling any property. No profit is guaranteed.

## What you received

| File | What it is |
|---|---|
| `content.md` | The full 15-module course manual (the complete video-course text) |
| `workbook.md` | Companion workbook with six fill-in worksheets |
| `templates/rehab-budget-arv-calculator.csv` | Rehab budget + ARV calculator spreadsheet |
| `templates/contractor-scope-of-work.md` | Scope-of-work template to give every bidder |
| `templates/draw-schedule.md` | Milestone draw-schedule template |
| `templates/contractor-bid-comparison.md` | Bid-comparison template |
| `cover.webp` | Product cover art |
| `sales-page.md` | The product sales page (reference) |
| `listing.json` | Marketplace listing data (reference) |

## What to do first (Day 1)

1. **Read the disclaimer** at the front of `content.md`. It is short and it matters.
2. **Read Modules 1–5** — how flipping makes and loses money, finding deals, ARV from comps, the rehab budget, and the 70% rule with your maximum allowable offer. Do not make an offer before you have read these five modules.
3. **Complete the ARV comp worksheet** (Workbook Worksheet 2) for one property in your target area — a real listing, or a recent sale you can study. Then complete the rehab budget worksheet (Worksheet 1) for the same property. This is the core skill of the course, and one practice run before real money is at stake is worth more than reading the chapters twice.
4. **Open the calculator** (`templates/rehab-budget-arv-calculator.csv`) in your spreadsheet app and enter the same property's numbers. Check that the computed profit, ROI, and maximum allowable offer match your worksheet. If they do not, find the difference — it is usually a cost you forgot.

## How to use each file

- **Course manual (`content.md`):** Read it in order the first time. Every module ends with action steps — do them; they are the course, not homework. Keep the manual open during your first deal and re-read Modules 3, 4, and 5 before every offer, and Modules 8–10 before every contractor meeting.
- **Workbook (`workbook.md`):** One completed workbook per property. Print it or copy it into a spreadsheet. Worksheets 1–3 and 6 are pre-offer tools; Worksheets 4–5 are used during the rehab. File the completed workbook with the property's contracts, permits, inspection reports, photos, and receipts.
- **Calculator (`templates/rehab-budget-arv-calculator.csv`):** Your deal-analysis spreadsheet. The example numbers in it are the course's anchor deal ($160,000 purchase, $55,000 rehab, $18,000 carrying/financing, $285,000 sale, $12,000 selling costs). Replace them with your property's numbers. The summary rows compute total cost, gross profit, ROI, and the 70% / 65% maximum allowable offers. Always run the numbers twice: once with the base rehab budget, once with the contingency spent.
- **Scope of work (`templates/contractor-scope-of-work.md`):** Complete one per property and give the *same* document to every contractor bidding. Attach the signed scope to the contract. No work outside the scope without a signed written change order.
- **Draw schedule (`templates/draw-schedule.md`):** Attach to the contract. Release a payment only when the milestone is complete and you have inspected it. Hold the final 10–20% until the punch list is done.
- **Bid comparison (`templates/contractor-bid-comparison.md`):** Record every bid line by line on the same sheet, verify license and insurance for each bidder, and write down why the totals differ before you choose.

## Suggested 6-week schedule

| Week | Do this |
|---|---|
| 1 | Read Modules 1–5. Define your buy box. Complete Worksheets 1–2 and the calculator for one practice property. |
| 2 | Read Modules 6–7. Talk to two hard-money lenders and get written term sheets. Interview an investor-friendly agent. |
| 3 | Read Modules 8–9. Get contractor referrals, vet two or three contractors, and practice writing a scope of work. |
| 4 | Read Modules 10–12. Analyze 5–10 real properties with the deal worksheet (Worksheet 6). Make your first offers at or below your maximum allowable offer. |
| 5 | Read Modules 13–14. Study the three case studies and recompute them with one assumption changed. Have a 30-minute conversation with a CPA about record-keeping and entity structure. |
| 6 | Read Module 15 and build your 120-day plan with real dates. Line up your inspector, contractor, agent, and lender so you are ready to move when the right deal appears. |

## Your first-flip rules (from Module 15)

1. Buy below your maximum allowable offer or do not buy.
2. Budget line by line, with a contingency, and never without one.
3. Never pay for work that is not done.
4. No change order, no extra work.
5. Price to sell in 30 days, not to impress yourself.
6. Keep every receipt and every photo.
7. If a deal needs everything to go right, it is the wrong deal.

## How to get support

- **Product or download questions:** Email marketplace support with your order number and the product name (The Fix-and-Flip Profit System, SKU RE-03).
- **Refunds:** 14-day money-back guarantee — full refund, no questions asked, within 14 days of purchase. Contact support with your order number.
- **Professional advice:** This course cannot answer questions about your specific property, loan, or tax situation. For those, consult a licensed real estate agent, a licensed lender, a real estate attorney, and a tax professional in your state.
