# The Abundant Home Garden: Grow Your Own Food Year-Round

## Grow your own food year-round — vegetables, herbs, and fruit, even in a small space.

---

## Education-Only Disclaimer

This programme is for general education and information only. It is not agricultural, medical, nutritional, legal, or financial advice. Gardening results depend on your climate, USDA hardiness zone or local equivalent, sunlight, soil, water, pests, weather, and the time and care you put in. Yields, harvest dates, and grocery savings in this programme are realistic ranges drawn from typical home-garden experience, not guarantees. Your first season is about learning; some crops will fail, and that is normal. Always check local rules before building structures, keeping chickens or bees, using a pesticide, or planting anything that may be invasive in your area. Wash all produce before eating it. If you have a medical condition, allergy, or dietary restriction, talk to a qualified professional before changing what you eat. Do not eat any plant you cannot positively identify as edible. Keep pesticides, fertilisers, and sharp tools away from children and pets, and follow every product label exactly. Prices in this programme are approximate, in US dollars, and will vary by store, region, and season; treat them as planning figures and check current local prices before you spend.

---

## How to Use This Programme

This is a written, video-course-style programme in eight modules. Read it in order the first time, then use it as a reference through the season. Each module ends with action steps and a checkpoint so you know you are ready to move on. The companion workbook (`workbook.md`) is where you record your own space, soil, planting dates, and harvests — the programme teaches the method; the workbook holds your garden's actual numbers. The templates folder holds the seasonal planting calendar, the garden planner spreadsheet, the soil health guide, and the pest control cheat sheet. Print the calendar and the planner and keep them where you garden.

You do not need a large garden, a greenhouse, or expensive equipment to start. You need a sunny spot, a container or a small bed, decent soil, water, and a routine you can keep for ten to fifteen minutes a day. This programme is built for that reality: homeowners with a yard, renters with a balcony or patio, and people with a small patch of shared ground. Everything is scaled so you can start with one bed or four pots and expand only when the first season proves the habit works.

A note on honesty before we begin. A home garden can save you real money and give you fresher food, but it will not replace your grocery shop in year one, and it will not pay for itself in a month. A realistic first-year goal is to grow a meaningful share of your salads, herbs, and a few staple vegetables, to learn your site, and to end the season knowing exactly what to plant more of next year. Gardeners who last are not the ones with the biggest first harvest. They are the ones who planted a manageable amount, kept watering, wrote down what happened, and came back the next season a little wiser.

---

## Table of Contents

- Introduction: Why Grow Your Own Food — and Why Most Beginners Quit
- Module 1: Know Your Site — Sun, Space, Water, and Climate
- Module 2: Soil First — Building the Foundation Everything Else Depends On
- Module 3: Planning Your Garden — What to Grow, When, and How Much
- Module 4: Starting Plants — Seeds, Seedlings, and Transplants
- Module 5: Growing Through the Season — Watering, Feeding, and Care
- Module 6: Pests, Diseases, and Problems — Prevention First, Treatment Second
- Module 7: Harvesting, Storing, and Preserving What You Grow
- Module 8: The Year-Round Garden — Succession, Season Extension, and Your Second Season
- Crop Guides: Twenty Reliable Crops, A to Z
- Worked Examples: Three Real Gardens, Three Real Budgets
- The Grocery-Savings Math, Done Honestly
- Your First 30 Days: A Starter Checklist
- Glossary

---

## Introduction: Why Grow Your Own Food — and Why Most Beginners Quit

People start a food garden for three reasons, and usually all three at once. They want fresher food. They want to spend less at the grocery store. And they want the satisfaction of eating something they grew themselves. All three are good reasons, and all three are achievable — but not in the way most beginners imagine.

The typical beginner story goes like this. In spring, full of enthusiasm, someone buys twenty seed packets, digs a large bed, plants everything on the same weekend, and waters when they remember. For three weeks it looks wonderful. Then the soil dries out, aphids arrive, the lettuce bolts in a heatwave, the tomatoes get blossom-end rot, and the weeds take over. By August the bed is a tangle, the gardener feels defeated, and the garden is quietly abandoned. The conclusion drawn is "I am bad at gardening." The real conclusion should be "I tried to do too much, too fast, with soil I had never tested and a plan I had never written down."

This programme exists to break that pattern. It is built around four principles that experienced gardeners return to again and again.

**Start small enough to succeed.** One raised bed of about 4 feet by 8 feet (roughly 1.2 by 2.4 metres), or four to six large containers, is a full first garden. It is enough to feed a household salads and herbs all summer and to teach you everything you need for year two. A garden you can water in ten minutes is a garden you will water.

**Soil first, plants second.** Most beginner crop failures are soil failures in disguise. Thin, compacted, or nutrient-poor soil cannot support healthy plants, and no amount of fertiliser poured on top fixes a soil with no structure and no life in it. Module 2 shows you how to test your soil with a jar, a squeeze, and an inexpensive lab test, and how to improve it with compost — the single highest-return investment in any garden.

**Plant the right crop at the right time.** A tomato planted two weeks too early in cold soil will sit, sulk, and often never catch up to one planted on time. Lettuce sown in July heat will bolt before it forms a head. Timing is not a detail; it is half the skill. Module 3 and the seasonal planting calendar give you a planting window for every crop, and show you how to adjust it for your own frost dates.

**Keep a routine, not a heroic effort.** Gardens fail on neglect, not on lack of knowledge. Ten minutes a day — watering, a quick look for pests, picking what is ripe — beats a four-hour weekend blitz followed by five days of nothing. Module 5 builds that routine into a simple weekly rhythm.

### What "year-round" really means

"Year-round" does not mean tomatoes in January in a cold climate, and anyone who promises that is selling you something. It means this: in every month of the year, something in your garden is growing, being harvested, or being prepared. In spring you plant peas, lettuce, and potatoes. In summer you harvest tomatoes, beans, courgettes, and herbs. In autumn you plant garlic, sow winter greens, and put the beds to bed with cover crops. In winter, in mild climates, you harvest kale, leeks, and Brussels sprouts; in cold climates you plan, order seed, start onions indoors, and use a cold frame or a sunny windowsill for herbs and salad leaves. The garden never truly stops — it changes pace with the season. Module 8 shows you how to keep that rhythm going without burning out.

### What you will be able to do by the end

By the end of this programme you will be able to: assess any sunny spot and know what will grow there; test and improve your soil; plan a garden that fits your space, your cooking, and your time; start seeds indoors and outdoors with confidence; water and feed plants correctly; spot the ten most common pests and diseases early and deal with them with the least harmful method first; harvest at the right moment; store and preserve a surplus; and plan a second season that is bigger, cheaper, and more productive than the first — because it is built on your own notes, not on guesswork.

### A word about space

You do not need land. Here is what different spaces can realistically grow:

- **A sunny windowsill (4–6 hours of direct sun):** herbs — basil, parsley, chives, mint in its own pot — and microgreens. Enough to flavour meals all year.
- **A balcony or patio (4–6 large pots, 5 gallons / 19 litres or larger):** salad leaves, herbs, cherry tomatoes, chillies, and dwarf beans. Enough for salads several times a week in summer.
- **A small yard bed, 4 by 8 feet (32 square feet / 3 square metres):** a full salad garden plus tomatoes, beans, and courgettes. Enough to noticeably reduce summer grocery spending on vegetables.
- **A larger garden, 100–200 square feet (9–19 square metres) of beds:** a serious share of a household's vegetables from late spring to autumn, plus storage crops like potatoes, onions, and winter squash.

Start with the space you have. The methods in this programme scale up and down; the principles do not change.

---

# Module 1: Know Your Site — Sun, Space, Water, and Climate

## What you will learn

How to measure sunlight honestly, how to read your climate and frost dates, how to find water, and how to choose the best spot — or the best containers — for the space you actually have.

## 1.1 Sunlight: the one thing you cannot fake

Vegetables need sun, and most need more of it than beginners expect. Sunlight is the engine of the garden. Soil can be improved, water can be carried, but a shady spot will never grow a good tomato, however much you feed it.

Learn the categories and be honest about which one your spot falls into:

- **Full sun:** 6 or more hours of direct sun a day. This is what tomatoes, peppers, courgettes, beans, cucumbers, aubergines, sweetcorn, and most fruit need. If you want these crops, you need a full-sun spot.
- **Part sun / part shade:** 3 to 6 hours of direct sun. Leafy greens, herbs, peas, beans, and root vegetables can do well here. Lettuce actually prefers a little afternoon shade in hot climates.
- **Shade:** fewer than 3 hours of direct sun. Grow herbs like mint and parsley, and leafy greens in spring and autumn — but expect slower growth and smaller harvests. Do not put fruiting vegetables here.

How to measure it: on a clear day, check your chosen spot every hour from 8 a.m. to 6 p.m. and note whether it is in direct sun or shade. Do it once in spring and once in midsummer, because the sun's path changes and a spot that is sunny in April can be shaded by a tree in full leaf by July. A phone photo taken from the same place at 9 a.m., noon, and 4 p.m. is a useful record. South-facing spots (in the Northern Hemisphere) get the most sun; north-facing walls and the north side of a house are the shadiest. In the Southern Hemisphere, reverse this: north-facing is sunniest.

Watch for reflected heat as well as shade. A south-facing brick wall can scorch plants in summer, while a white wall can usefully bounce light onto a bed. A spot next to a dark fence in a hot climate may need extra water.

**Action:** Fill in the Space Assessment in the workbook. Record hours of direct sun, the direction the spot faces, and anything that casts shade — trees, fences, buildings — at different times of day.

## 1.2 Climate and frost dates: your garden's calendar

Your local last frost date in spring and first frost date in autumn define your growing season. Everything in the planting calendar is anchored to those two dates.

Find them from your local agricultural extension service, meteorological office, or a reputable local gardening source — not from a generic national website, which may be off by weeks for your area. Write both dates down. Then learn the three temperature bands that govern planting:

- **Hardy crops** tolerate light frost and can be planted 2–4 weeks before the last frost: peas, broad beans, lettuce, spinach, kale, radishes, onions, potatoes.
- **Half-hardy crops** tolerate a light frost once established but are damaged by a hard freeze: carrots, beetroot, chard, cauliflower, broccoli.
- **Tender crops** are killed by frost and need warm soil: tomatoes, peppers, chillies, courgettes, cucumbers, beans, sweetcorn, basil, aubergines. Plant these after the last frost, when the soil has warmed — usually when night temperatures stay above 10°C / 50°F.

Soil temperature matters as much as air temperature. A simple soil thermometer costs a few dollars and removes the guesswork. Peas germinate in soil as cool as 5°C / 40°F. Beans need at least 16°C / 60°F and will rot in cold, wet soil. Tomatoes want 18°C / 65°F or warmer. If you do not have a thermometer, a practical rule is: if the soil feels cold and clammy to your bare hand and you would not sit on it comfortably, it is too cold for tender crops.

Know your hardiness zone, but do not treat it as a planting date. A zone tells you the average coldest winter temperature — useful for choosing perennial fruit and for knowing whether rosemary will survive winter outdoors — but it does not tell you when to sow lettuce. Frost dates do that.

**Microclimates are real and useful.** A sheltered spot against a south-facing wall can be a full zone warmer than an exposed corner of the same garden. A low hollow collects cold air and frost. A raised bed warms up faster in spring than ground-level soil. Use these differences deliberately: put tender crops in the warmest, most sheltered spot and hardy greens in the cooler corners.

## 1.3 Water: where it comes from and how far you will carry it

A garden that is hard to water is a garden that dies in July. Before you choose a spot, answer three questions:

1. **Where is the nearest tap or water butt?** If you have to carry watering cans more than about 10 metres, you will skip watering on busy days. A hose, a soaker hose, or a water butt next to the bed changes everything.
2. **How will you water?** A watering can gives control and is best for seedlings and containers. A hose with a gentle rose is faster for beds. Drip irrigation or soaker hoses, on a simple timer, are the most reliable option for anyone who works away from home — they water slowly at soil level, waste little, and keep leaves dry, which reduces disease.
3. **Can you collect rainwater?** A water butt under a downpipe is one of the cheapest garden investments. Rainwater is soft, free of chlorine, and slightly acidic, which most vegetables prefer. A standard 200-litre / 50-gallon butt can water a 4-by-8-foot bed for a week in mild weather.

Containers dry out far faster than beds — in hot weather a large pot may need watering every day, sometimes twice. If you garden in containers, plan for that, and use mulch and the largest pots you can manage. A 5-gallon pot holds moisture far better than a 1-gallon pot.

## 1.4 Choosing your spot and your setup

**In the ground.** Cheapest to start, best for root depth and moisture, but you inherit whatever soil is there. Good if your soil is reasonable and you can dig it. Bad if the ground is heavily compacted, full of rubble, or contaminated — in that case, build up, do not dig down.

**Raised beds.** A frame, usually 4 feet wide so you can reach the middle from either side, filled with good soil and compost. They warm up earlier in spring, drain well, and are easier on knees and backs. A 4-by-8-foot bed, 10–12 inches deep, needs about 1 cubic yard (0.75 cubic metres) of soil mix to fill. Costed honestly in the worked examples in this programme, a simple untreated-timber bed with soil and compost runs about $120–$200 to build; a ready-made kit costs more. Raised beds are the recommended starting point for most beginners.

**Containers.** The renter's garden and the balcony garden. Use the largest containers you can fit and lift: 5 gallons (19 litres) minimum for tomatoes and peppers, 3 gallons for herbs and salad. Always use containers with drainage holes — plants drown in pots without them. Use potting mix, not garden soil, in containers; garden soil compacts and drains badly in a pot. Group containers together so they shade each other's sides and dry out more slowly.

**Vertical space.** Walls, fences, trellises, and arches are free growing space. Peas, beans, cucumbers, and small squash climb; tomatoes can be trained up a string or stake. Vertical growing increases yield per square foot, improves air circulation, and keeps fruit off damp soil. A simple trellis of bamboo canes and twine costs a few dollars and lasts a season.

**A note for renters.** Use containers and freestanding raised beds that sit on the ground without digging in. Keep everything movable. Check your lease and any building rules before attaching anything to walls or balconies, and be careful with weight — wet soil is heavy, and a balcony has a load limit. Ask the building manager if you are unsure.

## 1.5 Your first site survey — do it this week

Walk your space with the workbook's Space Assessment and answer, in writing: Where is the sunniest spot? How many hours of direct sun does it get? Where is the water? What is the soil like — does it drain after rain, or does water sit in puddles? What is already growing there, and what does that tell you? Weeds like dandelions and clover suggest reasonable soil; bare, cracked ground suggests compaction. Is the spot sheltered from wind? Strong wind dries plants and snaps stems — a fence, hedge, or even a row of tall pots can act as a windbreak.

### Module 1 action steps

1. Measure sunlight at your chosen spot on a clear day, hourly from 8 a.m. to 6 p.m.
2. Look up your last and first frost dates from a local source and write them in the workbook.
3. Identify your water source and decide how you will water.
4. Choose your setup: in-ground bed, raised bed, containers, or a mix — and measure the space.
5. Complete the Space Assessment worksheet before buying anything.

### Module 1 checkpoint

You are ready for Module 2 when you can say: "My sunniest spot gets ___ hours of direct sun, my last frost date is ___, my water source is ___, and I will grow in ___." If you cannot fill in those blanks, do the survey before you spend money on seeds or soil.

---

# Module 2: Soil First — Building the Foundation Everything Else Depends On

## What you will learn

What soil is, how to test yours with simple methods and a lab test, how to improve it with compost, and how to keep it healthy year after year without expensive products.

## 2.1 What soil actually is

Good garden soil is roughly half mineral particles — sand, silt, and clay — about a quarter water, a quarter air, and a small but vital fraction of organic matter and living organisms. The mineral part determines texture. The organic matter and the life in the soil determine fertility.

- **Sandy soil** drains fast, warms early, and is easy to dig, but it dries out quickly and loses nutrients. It needs regular compost.
- **Clay soil** holds water and nutrients well but drains slowly, compacts easily, and is hard to work when wet or dry. It needs compost and time — never dig it when it is wet, or you will damage its structure for the season.
- **Silty soil** is smooth, holds moisture well, and is usually fertile, but it can compact and crust.
- **Loam** — a balanced mix of sand, silt, and clay with plenty of organic matter — is what every gardener is aiming for. It holds moisture without waterlogging, drains without drying out, and is easy to work.

Most gardens are not loam to start with. That is normal. You do not need to replace your soil; you need to improve it steadily, and compost is how you do it.

## 2.2 The jar test and the squeeze test

You can learn a lot about your soil in ten minutes, for free.

**The squeeze test.** Take a handful of moist soil — damp, not wet — and squeeze it. If it falls apart when you open your hand, it is sandy. If it holds its shape but crumbles when poked, it is loam. If it holds a ribbon when you press it between thumb and finger, it is clay. If it feels gritty and forms a weak ball, it is a sandy loam.

**The jar test.** Fill a clean jar one-third full with soil, add water to near the top, add a teaspoon of washing-up liquid, shake hard for two minutes, and leave it undisturbed for 24 hours. Sand settles in minutes at the bottom, silt settles over hours in the middle, and clay settles last, on top. Measure the depth of each layer and you have a rough percentage of each — a useful, honest picture of your texture.

**The drainage test.** Dig a hole about 12 inches (30 cm) deep and wide, fill it with water, let it drain, then fill it again and time how fast the water level drops. About 1 inch (2.5 cm) per hour is good for vegetables. Much faster, and the soil dries too quickly. Much slower, and roots will sit in water and rot. If water is still standing after 24 hours, you have a drainage problem that needs raised beds or serious organic matter before you plant.

## 2.3 The lab test: the best $20–$30 you will spend

A laboratory soil test — available through your local agricultural extension service or a garden soil lab — tells you what no squeeze test can: your soil's pH, its levels of the major nutrients (nitrogen, phosphorus, potassium), and often its organic matter percentage and any excess salts or heavy metals. It usually costs $20–$30 and the results come with specific recommendations for your soil type.

Do this before you buy fertiliser. Most beginner fertiliser purchases are wasted because the gardener never knew what the soil actually lacked. A lab test stops you buying what you do not need.

**pH, in plain language.** pH measures how acidic or alkaline your soil is, on a scale from 0 to 14, with 7 neutral. Most vegetables grow best between 6.0 and 7.0, slightly acidic to neutral. Below 5.5, nutrients become hard for plants to absorb even when they are present. Above 7.5, iron and other micronutrients become unavailable and leaves yellow. If your test shows pH below 6.0, garden lime, applied at the rate the lab recommends, will raise it slowly over a season. If it is above 7.5, adding compost and, where the lab advises it, elemental sulphur will lower it gradually. Do not chase pH with home remedies in large doses — small, measured changes, retested the following year, are the way.

Take the sample properly: collect soil from 6–8 spots in the bed, at 6 inches deep, mix them in a clean bucket, and send about a cup of the mix. Do not sample from one corner, and do not include surface mulch.

## 2.4 Compost: the single highest-return garden investment

Compost is decomposed organic matter — kitchen scraps, leaves, grass clippings, shredded paper — broken down by microbes into a dark, crumbly material that improves soil structure, holds water, feeds soil life, and releases nutrients slowly. There is no product that does more, for less money, than compost.

**What to compost.** Greens (nitrogen-rich): vegetable peelings, fruit scraps, coffee grounds, fresh grass clippings, manure from herbivores. Browns (carbon-rich): dry leaves, straw, shredded cardboard and newspaper, small twigs, sawdust from untreated wood. Aim for roughly two to three parts brown to one part green by volume. Keep the pile damp, like a wrung-out sponge, and turn it every few weeks to add air.

**What not to compost at home.** Meat, dairy, fats, and cooked food attract rats. Diseased plants and weed seeds that have set seed can survive a cool home pile. Treated wood, glossy paper, and anything with chemicals. Pet waste from dogs and cats should never go on a food garden.

**How to use it.** Spread 2–3 inches (5–7 cm) of finished compost over a bed each year and work it lightly into the top few inches, or simply leave it as a mulch and let the worms do the work. In a new raised bed, fill with a mix of roughly 60% topsoil and 40% compost. Do not plant directly into pure compost for most vegetables — it holds too much water and can be too rich for seedlings.

If you cannot make compost yet, buy it. A bagged compost or a bulk delivery from a local supplier is a fair price for what it does. Check that bought compost is mature — it should smell earthy, not sour or like ammonia — and ask the supplier whether it is suitable for vegetables.

## 2.5 Mulch, cover crops, and feeding

**Mulch** is a layer of material spread on the soil surface: straw, shredded leaves, wood chips (for paths and around fruit, not dug into vegetable beds), or grass clippings in thin layers. A 2–3-inch mulch layer suppresses weeds, keeps soil moist, moderates temperature, and feeds soil life as it breaks down. Keep mulch a couple of inches away from plant stems so they do not rot.

**Cover crops** — also called green manures — are plants grown not to eat but to improve the soil: crimson clover, winter rye, and field beans are common choices. Sow them in autumn on empty beds; they protect the soil from rain, fix nitrogen (in the case of legumes), and are dug in or cut down in spring to add organic matter. They are one of the cheapest soil improvements there is, and they turn a winter-empty bed into a working one.

**Feeding.** In a soil rich in compost, most vegetables need little extra feeding. Where feeding helps, prefer slow, gentle options: a liquid feed made from compost tea or diluted seaweed, or a balanced organic fertiliser applied at the label rate. Heavy feeders — tomatoes, courgettes, sweetcorn, brassicas — benefit from a side-dressing of compost or a liquid feed every two to three weeks once they are fruiting. More fertiliser is not better. Over-fertilised plants grow soft, leafy growth that attracts aphids, and excess fertiliser washes into waterways. Follow the label, and feed the soil first.

**Do not dig more than you need to.** Every time you dig deeply you disturb the fungal networks and soil life that took months to build. In an established bed, loosen the top few inches with a fork, add compost on top, and let worms and roots do the deep work. This is often called "no-dig" gardening, and it is particularly kind to clay soil.

## 2.6 Soil for containers

Containers need potting mix, not garden soil. A good potting mix is light, drains freely, and holds moisture — usually a blend of peat-free compost, coir, perlite, and bark. Mix in a slow-release organic fertiliser at planting time, because container plants cannot reach nutrients beyond their pot. Refresh container mix each year: tip out the top half, mix in fresh compost, and reuse the rest. After two or three years, replace it entirely.

### Module 2 action steps

1. Do the squeeze test and the jar test on your soil, and record the results in the Soil Test Log.
2. Send a sample for a lab test, or order a home test kit if a lab is not available locally.
3. Start a compost pile or bin, or source a reliable compost supplier.
4. Mulch every bed you plant, and plan a cover crop for any bed that will sit empty over winter.
5. Record your pH and nutrient results and the lab's recommendations in the workbook — they are the baseline you will compare against next year.

### Module 2 checkpoint

You are ready for Module 3 when you know your soil texture, your pH, and whether your drainage is fast, good, or slow — and you have compost on hand or on order. Do not skip this module to get to the planting. The planting is easy. The soil is the work.

---

# Module 3: Planning Your Garden — What to Grow, When, and How Much

## What you will learn

How to choose crops that match your cooking, your space, and your time; how much to plant so you harvest steadily instead of all at once; and how to lay out a bed so plants help rather than crowd each other.

## 3.1 Grow what you actually eat

The most common planning mistake is planting what looks exciting in a seed catalogue instead of what your household eats every week. Before you choose a single seed, write down what your household eats in a normal week: how many salads, how many stir-fries, how much tomato sauce, how many herbs. Then plant to that list.

A useful filter for every crop is to ask three questions:

1. **Do we eat it at least once a week in season?** If not, plant one plant as an experiment, not a row.
2. **Is it expensive or poor quality in the shops?** Herbs, salad leaves, and ripe tomatoes are expensive and often disappointing bought; potatoes and onions are cheap and store well bought, so they earn their space only if you have room.
3. **Does it suit my space and climate?** Sweetcorn needs a block of plants and a long warm season; a balcony gardener should skip it and grow beans instead.

For a first garden, the most forgiving and rewarding crops are: lettuce and salad leaves, radishes, spring onions, peas, French beans, courgettes, cherry tomatoes, herbs (basil, parsley, chives), and potatoes. They germinate reliably, grow fast enough to keep a beginner encouraged, and tolerate small mistakes. Save cauliflower, celery, and melons for year two — they are fussier and more disappointing when they fail.

## 3.2 How much to plant

Planting too much of one thing at once is the second most common beginner mistake. A single courgette plant can produce 3–5 kg (7–11 lb) of fruit over a summer — two plants will bury a household. Six tomato plants will give a family more tomatoes than they can eat fresh in August. The answer is succession sowing: sow a little, often.

A practical rule: sow salad leaves every two to three weeks from spring to late summer, a short row at a time. Sow beans in two batches, three weeks apart. Plant one courgette per household, two at most. Plant tomatoes at a rate of one to two plants per person for fresh eating, plus two more if you plan to make sauce.

The Crop Selection Worksheet in the workbook walks you through this for your household: list each crop, how many people it serves, how many plants or how many feet of row, and the sowing dates. The garden planner spreadsheet does the same arithmetic in a form you can sort by date.

**Space planning, in real numbers.** A 4-by-8-foot bed (32 square feet) can hold, for example: 2 tomato plants at one end (staked), a row of French beans along a trellis, 1 courgette plant in a corner (it will sprawl — give it room), a block of lettuce and salad leaves, a row of radishes and spring onions, and a patch of herbs at the edge. That is a full summer's salads and a useful quantity of tomatoes and beans from one bed. It is not a farm, and it does not need to be.

Use spacing honestly. Seed packets give spacing for a reason. Crowded plants compete for light and water, stay damp, and get disease. Thin seedlings to the spacing on the packet even though it feels wasteful — the plants you leave will be twice the size of crowded ones.

## 3.3 Succession, intercropping, and rotation

**Succession planting** means following one crop with another in the same space as the season goes on: peas in spring, followed by beans in summer, followed by winter lettuce or garlic in autumn. One bed can grow three crops in a year if you plan the handover.

**Intercropping** means growing a fast crop between slow ones: radishes sown between rows of carrots (the radishes are harvested before the carrots need the space), or lettuce under the shade of tall tomatoes in summer. It uses space well and keeps soil covered.

**Crop rotation** means not growing the same family of plants in the same spot year after year. The main families to rotate are: the tomato/potato family (Solanaceae), the cabbage family (Brassicaceae: cabbage, broccoli, kale, cauliflower, radishes), the legumes (beans and peas, which add nitrogen), and the onion family. A simple three- or four-year rotation — moving each family to a different bed each year — reduces soil-borne disease and pest build-up. In a single-bed garden, rotate within the bed as best you can and add plenty of compost; in a multi-bed garden, draw the rotation on paper in winter and stick to it.

**Companion planting, kept honest.** Some pairings genuinely help: beans fix nitrogen that leafy neighbours use; strong-smelling herbs like basil may confuse some pests; tall plants shade lettuce in summer. Other pairings are folklore with little evidence behind them. Treat companion planting as a useful nudge, not a guarantee, and never let it override spacing, sunlight, and watering — the things that actually decide whether a crop succeeds.

## 3.4 The planting calendar: your year on one page

Your planting calendar is built from three dates you already have: your last frost date, your first frost date, and the length of your growing season. The seasonal planting calendar template gives you a month-by-month guide to what to sow indoors, sow outdoors, transplant, and harvest. Adjust every date in it by your own frost dates — a gardener in Florida and a gardener in Minnesota are planting the same crops months apart, and both are right.

A simplified seasonal rhythm, for a temperate climate with a last frost in mid-spring:

- **Late winter:** plan, order seed, start onions and chillies indoors, test soil.
- **Early spring:** sow peas, broad beans, lettuce, spinach, radishes outdoors; start tomatoes and peppers indoors.
- **Mid-spring, after last frost:** transplant tomatoes, peppers, courgettes, and beans outdoors; sow sweetcorn and squash.
- **Summer:** succession-sow salad and beans; harvest daily; water deeply; mulch.
- **Late summer:** sow autumn lettuce, spinach, and radishes; plant garlic in autumn in cold climates.
- **Autumn:** harvest storage crops; sow cover crops; put beds to bed.
- **Winter:** harvest hardy greens where the climate allows; plan next year from your notes.

## 3.5 Laying out the bed

Draw your bed on paper before you plant. Mark north, mark the tallest plants on the north side so they do not shade shorter ones, put paths where you will actually walk, and leave room to reach the middle from either side. A bed wider than 4 feet is hard to work without stepping on the soil, which compacts it.

Keep a simple sketch in the workbook, with the date. Next year, when you rotate crops, that sketch is the record you will be glad you kept.

### Module 3 action steps

1. List what your household eats weekly and choose 8–12 crops for year one — no more.
2. Complete the Crop Selection Worksheet: plants per person, spacing, sowing dates.
3. Draw your bed layout, with tall plants on the north side and paths marked.
4. Build your planting calendar from your frost dates using the seasonal template.
5. Order seed. Buy from a reputable supplier, check the packet date, and store seed cool and dry.

### Module 3 checkpoint

You are ready for Module 4 when you have a written list of crops, a calendar with sowing dates, and a sketch of where each crop goes. If your plan exists only in your head, write it down. Gardens planned on paper get planted; gardens planned in the head get forgotten by June.

---

# Module 4: Starting Plants — Seeds, Seedlings, and Transplants

## What you will learn

When to sow indoors and when to sow outdoors, how to give seeds the warmth, moisture, and light they need, how to harden plants off, and how to transplant without setting them back by weeks.

## 4.1 Reading a seed packet

A seed packet is a small instruction manual. Learn to read it before you sow:

- **Sow indoors / sow outdoors:** whether the crop needs a protected start or can go straight into the ground.
- **Sowing depth:** a general rule is to sow a seed about twice as deep as the seed is wide. Tiny seeds like lettuce are barely covered; beans go about an inch deep.
- **Spacing:** the distance between plants at maturity. Thin to this, even when it hurts.
- **Days to germination and days to maturity:** germination is when the seed sprouts; maturity is when you can harvest. A "65 days to maturity" tomato sown indoors in March is not ready in May — count from transplanting outdoors, and add time in cool weather.
- **Sun, water, and soil notes:** the packet's shorthand for what the crop needs.

Buy fresh seed each year for crops that lose viability quickly — parsnips, onions, and sweetcorn are the classic examples — and store all seed in a cool, dry, dark place in a sealed container. A packet of lettuce seed can last two to three years if stored well; a packet of parsnip seed often fails in its second year.

## 4.2 Sowing outdoors: direct sowing done well

Many crops do best sown where they will grow: peas, beans, carrots, radishes, beetroot, spinach, lettuce, and potatoes. Direct sowing avoids transplant shock and is simpler.

The method is the same every time: prepare a fine, crumbly seedbed by raking the surface, water the soil before sowing if it is dry, sow at the depth on the packet, cover lightly, firm the soil gently with the back of a rake or your hand so the seed has good contact with moist soil, and mark the row with a label and the date. Then keep the surface moist — not soaked — until germination. A dry crust on the surface is the most common reason direct-sown seed fails; a light watering once or twice a day in dry weather, or a board or piece of hessian laid over a carrot row to hold moisture, makes a real difference. Remove the cover as soon as seedlings appear.

Thin ruthlessly and early. A row of carrots sown thickly and never thinned will give you a tangle of thin roots. Thin to the spacing on the packet when seedlings are about 2 inches tall, and thin on a damp day so you disturb the roots you leave as little as possible. Eat the thinnings of lettuce and beetroot as salad.

## 4.3 Sowing indoors: giving tender crops a head start

Tomatoes, peppers, chillies, aubergines, and, in short-season climates, courgettes and squash are started indoors 6–8 weeks before the last frost. The aim is a sturdy, stocky seedling — not a tall, pale, leggy one.

You need: clean pots or trays with drainage, a seed-starting mix (fine, light, and low in fertiliser so it does not burn young roots), a warm spot for germination, and a bright spot for growing on. Most seeds germinate best at 18–24°C / 65–75°F. A windowsill above a radiator, the top of a fridge, or a heated propagator all work. Once seedlings appear, move them to the brightest spot you have — a south-facing windowsill, or, better, a simple LED grow light hung a few inches above the plants for 14–16 hours a day. Light is the difference between a stocky seedling and a leggy one that falls over. Turn pots daily so plants do not lean.

Water from below where you can: stand the tray in a shallow dish of water for ten minutes and let the mix draw moisture up. This keeps the surface dry and reduces damping-off, the fungal disease that makes seedlings collapse at soil level. Good air circulation helps too — a small fan on low, or an open window on mild days, strengthens stems.

Pot seedlings on into larger pots when their roots fill the first pot, and feed very lightly — a half-strength liquid seaweed feed once a week — only once they have true leaves (the second set of leaves, which look like the adult plant's leaves, as opposed to the first smooth seed leaves).

## 4.4 Hardening off: the step beginners skip

A seedling raised indoors is soft. Put it straight outside on a sunny, windy day and it will wilt, scorch, or die. Hardening off is the gradual introduction to outdoor conditions over 7–10 days: put plants outside in a sheltered, shady spot for a few hours on day one, bring them in at night, and increase the time outdoors and the sun exposure each day until they stay out overnight. Only then plant them out. This single step saves more seedlings than any other piece of advice in this module.

## 4.5 Transplanting

Transplant on a cloudy day or in the evening, when the sun will not stress the plant. Water the seedling well an hour before, dig a hole slightly larger than the pot, set the plant at the same depth it was growing — except tomatoes, which can be planted deeper, up to their first true leaves, because they grow roots along the buried stem — firm the soil gently, water thoroughly, and mulch. Water daily for the first week until roots establish. If a cold night is forecast after planting tender crops, cover them with a bucket, a cloche, or horticultural fleece overnight.

Buy seedlings when it makes sense. There is no shame in buying tomato or pepper plants from a nursery in year one, and for a beginner it often gives a better result than starting from seed. Buy stocky plants with dark green leaves, not tall pale ones, and check the undersides of leaves for aphids before you pay.

## 4.6 What to do when seeds fail

Seeds fail for a small number of reasons, and each has a fix: old seed (buy fresh, check the date), soil too cold (wait, or use a thermometer), soil too wet (sow in a raised bed or wait for it to drain), soil crusted over (water gently, cover the row), birds and slugs eating the seed or seedlings (cover with netting or fleece until plants are established), or sowing too deep (check the packet). Keep the packet, note the sowing date in the workbook, and if a sowing fails, sow again — there is almost always time for a second sowing, and a second sowing in warm soil often overtakes the first.

### Module 4 action steps

1. Sort your seed into "sow indoors" and "sow outdoors" piles, with dates from your calendar.
2. Set up your indoor sowing station: trays, mix, labels, a bright spot, and a watering can with a fine rose.
3. Sow tender crops indoors 6–8 weeks before your last frost date.
4. Direct-sow hardy crops outdoors on the dates in your calendar, and label every row.
5. Harden off every indoor-raised plant for 7–10 days before planting out.

### Module 4 checkpoint

You are ready for Module 5 when your indoor seedlings are stocky and green, your outdoor rows are labelled and germinating, and you have a note of every sowing date. Leggy, pale seedlings are a light problem, not a seed problem — fix the light before you sow more.

---

# Module 5: Growing Through the Season — Watering, Feeding, and Care

## What you will learn

How much water plants really need, when to water, how to feed without overdoing it, and the small weekly jobs — staking, pruning, weeding — that keep a garden productive all season.

## 5.1 Watering: deep, infrequent, at the base

Most vegetables need about 1 inch (25 mm) of water a week from rain and watering combined. That is the figure to plan around, but the way you deliver it matters more than the total.

**Water deeply and infrequently, not a little every day.** A deep watering encourages roots to grow down, where the soil stays moist. A daily sprinkle wets only the surface, keeps roots shallow, and leaves plants vulnerable the moment you miss a day. For a bed, that means watering until the soil is moist 6 inches down — check with a finger or a trowel — then leaving it for two or three days. Containers are the exception: they dry fast and in hot weather need daily watering, sometimes twice.

**Water at the base, in the morning.** Watering leaves, especially in the evening, keeps foliage damp overnight and invites fungal disease. Water the soil at the base of the plant, in the morning, so any splashes dry during the day. Drip irrigation and soaker hoses do this automatically and use less water than a sprinkler — a soaker hose can cut water use by a third or more compared with overhead watering, because the water goes into the soil instead of evaporating or running off.

**Mulch is watering.** A 2–3-inch mulch layer can halve how often a bed needs watering in summer. Mulch after a good watering, not onto dry soil.

**Learn to read the plants.** Wilting in the heat of the afternoon is often normal — plants recover in the evening. Wilting in the morning means the soil is genuinely dry and you should water. Yellow lower leaves on a tomato can mean overwatering as often as underwatering; check the soil before you reach for the hose. Stick a finger 2 inches into the soil: if it is dry at that depth, water; if it is damp, wait.

**Watering worked example.** A 4-by-8-foot bed in a temperate summer, with mulch, typically needs about 20–30 litres (5–8 gallons) per watering, two to three times a week in dry weather, and less after rain. Over a 20-week season that is roughly 800–1,200 litres for one bed. That is the scale to plan for — and a reason a water butt and a mulch layer pay for themselves quickly.

## 5.2 Feeding through the season

If your soil is rich in compost, most crops need little extra food. The exceptions are the heavy feeders, and they tell you when they are hungry: tomatoes with pale leaves and slow fruit set, courgettes with small, yellowing fruit, sweetcorn with pale stripes on the leaves.

Feed at the right time, in the right amount. A liquid feed — diluted seaweed, compost tea, or a balanced organic liquid fertiliser — applied every two to three weeks once fruiting begins is enough for most heavy feeders. A side-dressing of compost around the base of the plant, kept off the stem, does the same job more slowly. Do not feed seedlings heavily, do not feed in the heat of the day, and never exceed the label rate. Overfeeding produces soft, sappy growth that aphids love, delays fruiting, and can burn roots.

Stop feeding leafy greens late in the season if you are about to harvest — excess nitrogen in leaves is not something you want to eat in quantity, and the plants do not need it once they are near harvest size.

## 5.3 The weekly routine

A productive garden runs on a short weekly rhythm, not on heroic effort. Aim for this:

- **Daily (5–10 minutes):** water containers and anything newly planted; pick what is ripe; a quick look for pests on the undersides of leaves.
- **Twice a week:** water beds deeply if there has been no rain; check ties and stakes.
- **Weekly (30–45 minutes):** weed while weeds are small — a hoe through dry soil on a sunny day kills seedlings in minutes; feed heavy feeders if due; tie in tomatoes and beans; harvest and record in the Harvest Log; remove yellowing or diseased leaves and put them in the bin, not the compost, if disease is suspected.
- **Monthly:** check soil moisture at depth, top up mulch, review the planner — what is ready to sow next, what is finishing, what needs replacing.

Weeding deserves emphasis because it is where beginners lose the most ground. A weed is simply a plant using the water, light, and nutrients your vegetables need. Weed little and often, when weeds are seedlings, and you will spend minutes. Leave them for a month and you will spend hours, and you will disturb your vegetables' roots pulling them out. A sharp hoe on a dry day, used shallowly, is the fastest tool you own.

## 5.4 Supporting, pruning, and training

**Tomatoes.** Indeterminate (cordon) tomatoes grow tall all season and need a stake, cane, or string at least 6 feet high, tied loosely every 8–12 inches as they grow. Remove the side shoots that appear in the leaf joints — pinch them out when small — so the plant puts energy into fruit, not foliage. Determinate (bush) tomatoes are shorter, need a shorter stake or cage, and are not pruned the same way; check the variety before you prune. In late summer, remove the growing tip so the plant ripens the fruit it already has instead of making new flowers that will not have time to ripen.

**Beans and peas.** Give them something to climb from the day they germinate: canes in a wigwam, a trellis, or netting. Guide the first tendrils onto the support and they will do the rest.

**Courgettes and squash.** Give them space — one plant needs at least a square yard — and let them sprawl, or train them up a strong trellis if space is tight. Remove the oldest, yellowing leaves to improve air flow.

**Fruit.** Strawberries in a bed or hanging basket need netting once fruit colours, or birds will take it. Raspberry canes need wires and annual pruning; new gardeners should check whether their variety fruits on first-year or second-year wood before cutting anything. Fruit trees need a different skill set again — this programme covers soft fruit and strawberries in the crop guides, and recommends a local fruit-growing guide before you invest in trees.

## 5.5 When things go wrong mid-season

Plants bolt, leaves yellow, fruit splits, and flowers drop. Most mid-season problems have a simple cause:

- **Bolting (lettuce, spinach, radishes shooting up to flower):** heat and long days. Sow in spring and autumn, give afternoon shade in summer, and keep the soil moist.
- **Blossom-end rot (dark, sunken patch on the end of tomatoes and peppers):** uneven watering preventing the plant taking up calcium, not a lack of calcium in the soil in most cases. Water evenly, mulch, and do not overfeed with nitrogen. Affected fruit will not recover; pick it off so the plant puts energy into the next fruit.
- **Split tomatoes:** a dry spell followed by heavy watering. Water evenly and mulch.
- **Flower drop on beans and tomatoes:** temperatures above about 30°C / 86°F, or cold nights below 10°C / 50°F. Shade in a heatwave, and be patient — flowers usually return when temperatures moderate.
- **Yellow leaves:** could be overwatering, underwatering, nitrogen deficiency, or natural ageing of lower leaves. Check soil moisture first, then consider a light feed, and remove only the badly yellowed lower leaves.

Write the problem and what you did in the Pest Log and the Season Review. That note is what turns a bad week into knowledge for next year.

### Module 5 action steps

1. Set your watering routine: morning, at the base, deeply, with mulch in place.
2. Put stakes, canes, and trellises in place before plants need them, not after they have flopped.
3. Start the weekly routine — daily check, weekly weed and harvest — and keep it for a month.
4. Feed heavy feeders lightly every two to three weeks once fruiting, at the label rate.
5. Record watering, feeding, and problems in the workbook as they happen, not from memory at the end of the season.

### Module 5 checkpoint

You are ready for Module 6 when you can water a bed to the right depth, tell a thirsty plant from a diseased one, and have a weekly routine you have actually kept for three weeks. A routine you keep beats a perfect plan you abandon.

---

# Module 6: Pests, Diseases, and Problems — Prevention First, Treatment Second

## What you will learn

How to prevent most problems before they start, how to identify the ten most common pests and diseases, and how to deal with them starting with the least harmful method — with honest limits on what home methods can do.

## 6.1 Prevention is the whole game

A healthy plant in good soil, with the right spacing, sunlight, and watering, resists pests and disease far better than a stressed one. Most of pest control is not spraying; it is the work of Modules 1–5 done well. On top of that, five habits prevent most trouble:

1. **Rotate crops** so pests and soil diseases do not build up in one spot.
2. **Space plants properly** so air moves between them and leaves dry after rain.
3. **Water at the base, in the morning,** so leaves stay dry.
4. **Keep the garden clean:** remove dead and diseased leaves promptly, do not leave rotting fruit on the ground, and clean tools between beds if disease is present.
5. **Invite the helpers:** flowers like marigolds, calendula, and nasturtiums attract hoverflies, ladybirds, and bees; a small patch of flowers at the end of a bed is pest control, not decoration. Avoid broad-spectrum insecticides that kill ladybirds and bees along with the pests — you need the helpers more than you need the spray.

Check plants regularly, and check the undersides of leaves, where aphids, whitefly, and eggs hide. Catching a problem on ten leaves is a five-minute job. Catching it when it covers a plant is a lost crop.

## 6.2 The ten most common problems — and what to do

Full identification notes, treatment steps, and safety warnings are in the Pest Control Cheat Sheet in the templates folder. This module gives you the working summary.

**Aphids.** Small green, black, or white insects clustered on shoot tips and leaf undersides, causing curling and sticky honeydew. First step: blast them off with a strong jet of water. Second: encourage ladybirds, or, if the infestation is heavy, use an insecticidal soap at the label rate, in the evening when bees are not active. Check again in three days.

**Slugs and snails.** The beginner's most common enemy, especially in wet weather. They eat seedlings overnight. Prevention: water in the morning, keep mulch away from stems, remove hiding places like boards and dense ground cover near beds, and go out with a torch after dark to pick them off by hand — unglamorous and effective. Barriers of copper tape around pots and containers help. Beer traps catch some. Avoid slug pellets containing metaldehyde where children, pets, or wildlife may be exposed; if you use any pellet, choose one labelled safe for food gardens and follow the label exactly.

**Cabbage white caterpillars.** Green caterpillars that chew holes in brassicas. Prevention: cover brassicas with fine insect mesh or netting from the day you plant them — this is the single most reliable method. Pick caterpillars off by hand and check leaf undersides for yellow eggs.

**Carrot fly.** The maggots tunnel into carrot roots. Prevention: sow carrots under fine mesh, avoid thinning carrots on a still day (the smell attracts the fly), and sow later in the season when the first flush of flies has passed, or grow carrots in a container at least 18 inches high — the fly stays low.

**Whitefly.** Tiny white insects that fly up in a cloud when a plant is disturbed, common on tomatoes and brassicas. Encourage natural predators, use yellow sticky traps for monitoring (not as the sole control), and wash leaves with water. Heavy infestations in a greenhouse may need a biological control — a product containing a predatory insect — bought from a garden supplier.

**Powdery mildew.** White powdery coating on leaves, common on courgettes, squash, and cucumbers in warm, humid weather. Prevention: space plants for airflow, water at the base, and remove affected leaves promptly. It rarely kills a plant outright but reduces yield; plants often keep producing if you keep removing the worst leaves.

**Blight (tomato and potato).** Dark patches on leaves and stems, spreading fast in warm, wet weather; fruit rots. This is the most serious disease in this programme, and honesty requires saying so: once blight takes hold there is no home cure that reliably saves the crop. Prevention is everything — buy blight-resistant varieties where available, space for airflow, water at the base, remove lower leaves, and do not compost diseased material. If blight appears, remove affected plants, bag them, and bin them (do not compost). Choose a resistant variety next year.

**Damping-off.** Seedlings collapse at soil level and die. A disease of indoor sowing, caused by wet, airless conditions. Prevention: clean pots, fresh seed mix, water from below, good air circulation, and do not sow too thickly.

**Flea beetles.** Tiny beetles that make small holes in leaves of radishes, rocket, and brassicas. Usually cosmetic on mature plants; serious on seedlings. Cover seedlings with fine mesh until they are established.

**Birds.** They take seedlings, peas, and soft fruit. Netting is the answer — drape it over a frame so it does not rest on the plants, and check it regularly so birds do not get tangled. For strawberries, net before the fruit colours.

## 6.3 Sprays, soaps, and the rules that matter

If you use any spray — even a homemade one — follow these rules: identify the pest first, so you are treating the right thing; use the least harmful method first; read the label and follow it exactly, including the waiting period before harvest; spray in the evening, when bees are not flying; never spray in wind, or when rain is expected within hours; and keep a note of what you sprayed, when, and on what. Do not mix products. Do not assume a "natural" product is safe for bees, children, or pets — some natural sprays are toxic to bees. If you are unsure, ask your local extension service before you spray a food crop.

Home remedies have limits. A soap spray will kill aphids it touches; it will not protect a plant after it dries, and it can scorch leaves in hot sun. Garlic and chilli sprays have mixed evidence behind them. They are worth trying on a small scale, but they are not a substitute for netting, hand-picking, and healthy plants. Do not spend money on expensive "miracle" pest products in year one.

## 6.4 When to accept a loss

Some crops will fail despite your best work, and the right response is to pull the plant, compost the healthy parts, bin the diseased parts, and sow something else in the space. A gardener who spends a month trying to save a blighted tomato plant loses the space, the time, and the chance of a second crop. A gardener who pulls it, plants beans, and writes down the lesson gains a harvest and knowledge. This is not giving up; it is good gardening.

### Module 6 action steps

1. Net brassicas and carrots from planting day — do not wait until you see damage.
2. Walk the garden every two to three days, checking leaf undersides, and record anything you find in the Pest Log.
3. Put a small patch of flowers at the end of each bed to attract beneficial insects.
4. Keep the Pest Control Cheat Sheet where you garden, and read the label of any product before you use it.
5. Decide your rule in advance: at what point will you pull a failing plant and replant, rather than keep treating it?

### Module 6 checkpoint

You are ready for Module 7 when you can name the three pests most likely in your garden, know the first thing you will do about each, and have netting and a hand-picking routine in place. You do not need to have solved every pest — you need to be watching for them.

---

# Module 7: Harvesting, Storing, and Preserving What You Grow

## What you will learn

How to tell when each crop is ready, how to pick so the plant keeps producing, how to store a harvest so it lasts, and how to preserve a surplus without expensive equipment.

## 7.1 Harvest at the right moment

Picking too early wastes flavour; picking too late wastes texture and, for crops like beans and courgettes, stops the plant producing more. The general rule is: pick little and often, and pick in the morning, when plants are cool and crisp, after the dew has dried.

- **Salad leaves:** pick outer leaves and let the centre keep growing — the "cut and come again" method gives weeks of harvest from one plant.
- **Peas:** pick when pods are plump and the peas inside are full — taste one. Pick every two to three days; a pea left on the plant signals it to stop producing.
- **French beans:** pick when pods are young, firm, and snap cleanly, before the beans inside swell. Pick every two to three days.
- **Courgettes:** pick when 6–8 inches (15–20 cm) long. A courgette left to grow into a marrow is edible but the plant will slow down dramatically — and you will have more marrow than anyone wants.
- **Tomatoes:** pick when fully coloured and slightly soft to the touch, with a strong smell at the stem. In cool weather at the end of the season, pick green tomatoes before the first frost and ripen them indoors in a paper bag with a banana.
- **Root vegetables:** pull one to check size before harvesting a row. Carrots and beetroot can be left in the ground for weeks in cool weather, but lift them before the ground freezes.
- **Herbs:** pick in the morning, after dew, before the heat of the day, when their oils are strongest. Never take more than a third of a plant at once.
- **Potatoes:** for new potatoes, lift a plant when the flowers fade. For maincrop storage, wait until the foliage dies back, cut it off, and leave the tubers in the ground for two weeks to harden their skins before lifting on a dry day.

Use clean, sharp scissors or secateurs for picking where a clean cut matters — tomatoes, beans, herbs, and leafy greens tear less and the plant heals faster. Wash your hands and your harvest basket, and wash all produce before eating.

## 7.2 Storing what you harvest

Most home-garden produce is best eaten fresh, within a few days. Storage is for the surplus and for the storage crops, and it is simpler than most people think:

- **Cool, dark, and dry:** onions, garlic, potatoes, and winter squash want a cool (5–10°C / 40–50°F), dark, dry, ventilated place. Do not store potatoes and onions together — onions release gases that make potatoes sprout. Cure onions and garlic by drying them in a warm, airy place for two weeks before storing.
- **Cool and humid:** carrots, beetroot, and leeks keep in a box of damp sand in a cool shed or garage for weeks, or in the ground in mild climates.
- **Fridge:** salad leaves (washed, dried, in a bag with a paper towel), herbs (in a damp cloth or a jar of water), beans, and peas keep a few days to a week.
- **Do not wash before storing** root vegetables and onions — brush off loose soil and wash just before use.

Check stored produce weekly and remove anything that is softening or rotting, before it spreads to the rest.

## 7.3 Preserving a surplus

You do not need a pressure canner or a freezer full of equipment to preserve a glut. Start with the three simplest methods:

**Freezing.** Blanch beans, peas, and sweetcorn for 2–3 minutes in boiling water, plunge into ice water, drain, and freeze in labelled bags. Herbs freeze well chopped in ice-cube trays with water or oil. Tomatoes can be frozen whole or as sauce. Label everything with the contents and the date; frozen produce is best used within 6–12 months.

**Drying.** Herbs dry easily: tie small bunches and hang them in a warm, dark, airy place for one to two weeks, then crumble into jars. Chillies and tomatoes can be dried in a low oven or a dehydrator if you have one. Dried herbs keep their flavour for 6–12 months in sealed jars away from light.

**Simple preserving.** Tomato sauce, chutney, and pickles are the classic home-garden preserves. Use a tested recipe from a reputable source — a cookbook, an extension service, or a national food-safety authority — and follow it exactly, especially for anything that will be stored at room temperature. Home canning of low-acid vegetables requires a pressure canner and tested procedures; do not improvise with canning, because the risk is botulism, which is rare but serious. If in doubt, freeze instead of canning. This programme gives methods, not canning recipes, for that reason.

## 7.4 Eating what you grow: using the harvest

A garden changes how you cook, in a good way, if you let it. Plan meals around what is ready rather than shopping first and gardening second. A glut of courgettes becomes soup, fritters, and ratatouille. A row of beans becomes a week of salads and stir-fries. Herbs turn plain rice, eggs, and roast vegetables into something worth eating. Keep a simple habit: when you harvest, write the weight or the approximate quantity in the Harvest Log, and write one line about what you cooked with it. That record is the evidence, at the end of the season, of what your garden actually fed you — and it is the basis for next year's plan.

### Module 7 action steps

1. Learn the harvest sign for each crop you grow — write it on the plant label or in the planner.
2. Harvest little and often, in the morning, and record every harvest in the Harvest Log.
3. Set up a storage spot — cool, dark, and dry for onions and potatoes; fridge space for salad.
4. Freeze or dry your first surplus the week it appears, before it becomes waste.
5. Cook one meal a week built around what the garden produced, and note it in the log.

### Module 7 checkpoint

You are ready for Module 8 when you have harvested, weighed or counted, stored, and cooked from your garden at least three times — and you have the numbers in the Harvest Log to prove it. Harvesting is the point of the garden. If you are not recording it, you are guessing at your own success.

---

# Module 8: The Year-Round Garden — Succession, Season Extension, and Your Second Season

## What you will learn

How to keep the garden producing through autumn and winter, how to extend the season cheaply, how to close the year properly, and how to plan a second season that is better than the first because it is built on your own evidence.

## 8.1 Succession: the garden that never stops

A year-round garden is a relay, not a single race. As one crop finishes, the next is already growing. The practical way to do this is a simple rolling plan with four handovers:

- **Spring to summer:** peas and early lettuce finish in early summer; beans, courgettes, and tomatoes take their space.
- **Summer to autumn:** after early potatoes and peas, sow autumn lettuce, spinach, radishes, and spring onions for a late harvest.
- **Autumn to winter:** plant garlic and broad beans in autumn for a spring harvest; sow winter-hardy greens like kale, chard, and winter lettuce under cover.
- **Winter to spring:** overwintered garlic, onions, and broad beans are the first crops of the new year; start the next round of seeds indoors while they grow.

Keep one rule: a bed is never left bare for long. A bare bed loses moisture, erodes in rain, and grows weeds. If you are not planting a crop, sow a cover crop or mulch the bed thickly. Your soil will thank you in spring.

## 8.2 Season extension, cheaply

You do not need a greenhouse to extend the season. Three low-cost tools cover most of what a beginner needs:

**Horticultural fleece.** A lightweight fabric draped over plants or over hoops. It protects against light frost, wind, and some pests, and lets light and water through. A few dollars a roll, reusable for several seasons if stored dry. Use it to protect tender plants in a cold snap and to get salads started a few weeks early.

**Cold frames.** A bottomless box with a glass or clear plastic lid, set on the soil. It warms the soil in spring, hardens off seedlings, and grows winter salads in mild climates. A simple cold frame can be made from old timber and a clear lid for under $50, or bought as a kit. Vent it on sunny days — a closed cold frame can overheat and cook plants in an hour.

**Cloches and tunnels.** A plastic bottle with the bottom cut off is a cloche for a single plant. A row of wire hoops with clear plastic over them is a low tunnel that can add weeks to either end of the season. Both are cheap, and both need venting on warm days and anchoring against wind.

A greenhouse is a bigger investment — $200 to $1,000 or more for a small one, plus a level base and a water supply. It is worth considering in year two or three if you love the work and want to start seeds earlier and grow tender crops reliably. Do not buy one in year one. Learn the garden first, in the open, and let the second season's notes tell you whether a greenhouse would actually earn its cost.

## 8.3 Closing the year: putting the garden to bed

In autumn, after the last harvests, spend a day closing the garden properly:

1. Pull spent plants. Compost the healthy ones; bin the diseased ones.
2. Harvest and store the last storage crops.
3. Sow a cover crop on any bed that will be empty, or mulch thickly with leaves or straw.
4. Clean and oil tools, empty and store pots, and coil hoses before the first hard frost.
5. Save seed only from open-pollinated varieties, from healthy plants, dried thoroughly and stored in labelled envelopes in a cool, dry place. Do not save seed from hybrid (F1) varieties — the offspring will not be the same as the parent.
6. Sit down with the workbook and complete the Season Review while the season is still fresh in your mind.

That review is the most valuable hour of the year. It is where a first season becomes a second season worth having.

## 8.4 Planning your second season

Your second season starts with three questions, answered from your notes, not from memory:

1. **What grew well, and why?** Which crops gave a good yield for the space and effort? Grow more of those.
2. **What failed, and why?** Was it timing, water, pests, soil, or simply the wrong crop for your site? Each failure has a specific fix — write it down and apply it.
3. **What did we actually eat?** The Harvest Log tells you what your household used. Grow more of that, and less of what sat in the fridge.

Then make three changes, not thirty. Add one new crop you are curious about. Fix the one biggest problem from year one — usually water, soil, or timing. And expand by one bed, or a few more containers, only if the first season's routine held up. A garden that grows by one bed a year becomes a serious food garden in three years, without a single overwhelming season.

Reorder seed in winter, when suppliers have full stock and you have time to choose. Test your soil again in year two — the lab test is a yearly habit that pays for itself — and compare the results with year one. You should see organic matter rising and pH moving towards the range you want, if you have been adding compost.

## 8.5 Staying with it: the long view

Gardening rewards patience in a way few hobbies do. The first season teaches you your site. The second teaches you your crops. By the third, you are growing with a confidence that no book can give you, because it is built on your own soil, your own weather, and your own notes. The gardeners who grow the most food are rarely the ones with the most land or the most equipment. They are the ones who kept a small routine, wrote things down, and came back every year.

Start small. Feed the soil. Plant on time. Water deeply. Watch, note, and adjust. That is the whole programme, and it is enough.

### Module 8 action steps

1. Plan your four handovers — spring to summer, summer to autumn, autumn to winter, winter to spring — on the planting calendar.
2. Buy or make one season-extension tool: fleece, a cold frame, or a low tunnel.
3. Close the garden properly in autumn and complete the Season Review within a week of the last harvest.
4. Plan your second season from your notes: more of what worked, a fix for the biggest failure, one new crop.
5. Order next year's seed in winter and retest your soil.

### Module 8 checkpoint

You have finished the programme when you can look at your workbook and answer, from your own records: what you grew, how much you harvested, what it saved you, what failed and why, and what you will do differently next year. That record is the real product of your first season — the food is the bonus.

---

# Crop Guides: Twenty Reliable Crops, A to Z

These guides give you the working facts for each crop: when to sow, spacing, sun, water, days to harvest, expected yield, and the most common problem. All yields are typical home-garden ranges for a healthy plant in decent soil — not guarantees. Always check the seed packet for your specific variety, which may differ.

**Basil.** Tender herb. Sow indoors 6 weeks before last frost, or buy plants; plant out after frost. Full sun. 12 inches apart. Harvest leaves from 60 days. Yield: a single plant gives a large bunch of leaves every few weeks all summer if picked regularly. Problem: cold and overwatering. Pinch out flower heads to keep leaves coming.

**Beetroot.** Hardy root. Sow outdoors from early spring, every 3 weeks until late summer. Full sun to part shade. 4 inches apart, rows 12 inches apart. Harvest from 60–70 days, when roots are the size of a golf ball. Yield: about 1 kg (2 lb) per 3-foot row. Problem: bolting in heat; keep moist. Eat the leaves as greens too.

**Broad beans.** Hardy legume. Sow outdoors in autumn (mild climates) or early spring. Full sun. 8 inches apart. Harvest from 80–90 days, when pods feel full. Yield: about 1–1.5 kg (2–3 lb) per 10 plants. Problem: blackfly on shoot tips — pinch out the tips when the first pods set.

**Broccoli (calabrese).** Half-hardy brassica. Sow indoors 6 weeks before last frost, transplant out after frost. Full sun. 18 inches apart. Harvest the central head from 70–90 days, then side shoots for weeks after. Yield: 300–500 g (10–18 oz) per plant, including side shoots. Problem: cabbage white caterpillars — net from day one.

**Carrots.** Hardy root. Sow outdoors from early spring to midsummer, in fine, stone-free soil. Full sun. Thin to 2 inches apart. Harvest from 70–80 days. Yield: about 1–1.5 kg (2–3 lb) per 3-foot row. Problem: carrot fly — grow under fine mesh. Do not use fresh manure before sowing; it causes forked roots.

**Chillies and peppers.** Tender fruit. Sow indoors 8–10 weeks before last frost, in warmth. Plant out after frost, in the sunniest spot. Full sun. 18 inches apart. Harvest from 70–90 days after transplanting. Yield: a chilli plant gives 20–40 chillies; a pepper plant gives 5–10 peppers in a good season. Problem: cold nights and blossom-end rot — water evenly.

**Courgettes (zucchini).** Tender fruit. Sow indoors 3–4 weeks before last frost, or outdoors after frost. Full sun. One plant per 3-foot square. Harvest from 50–60 days; pick at 6–8 inches. Yield: 3–5 kg (7–11 lb) per plant over a season. Problem: powdery mildew late in the season — remove affected leaves; one plant is enough for most households.

**Cucumbers.** Tender fruit. Sow indoors 3–4 weeks before last frost; plant out after frost. Full sun. 18 inches apart, with a trellis. Harvest from 60–70 days; pick regularly. Yield: 10–20 cucumbers per plant. Problem: bitter fruit from uneven watering — water evenly and mulch.

**French beans (bush and climbing).** Tender legume. Sow outdoors after frost, when soil is warm. Full sun. Bush: 6 inches apart; climbing: 8 inches apart on a trellis. Harvest from 55–65 days; pick every 2–3 days. Yield: about 1–1.5 kg (2–3 lb) per 10 plants. Problem: cold, wet soil rots the seed — wait for warmth.

**Garlic.** Hardy bulb. Plant cloves in autumn, point up, 6 inches apart, 2 inches deep. Full sun. Harvest the following summer when leaves yellow and fall over — typically 8–9 months after planting. Yield: each clove becomes a bulb of 6–10 cloves. Problem: wet soil rots bulbs — plant in well-drained soil or a raised bed.

**Kale.** Hardy leaf. Sow outdoors from spring to midsummer; transplant if started indoors. Full sun to part shade. 18 inches apart. Harvest outer leaves from 70–80 days; plants keep producing through winter in mild climates. Yield: about 500 g (1 lb) of leaves per plant over a season. Problem: cabbage white caterpillars — net from day one.

**Lettuce and salad leaves.** Hardy leaf. Sow outdoors from early spring, every 2–3 weeks until late summer. Part shade in summer is ideal. Thin to 8–12 inches apart. Harvest from 30 days for cut-and-come-again leaves, 45–60 days for heads. Yield: a 3-foot row gives 4–6 heads, or weeks of cut leaves. Problem: bolting in heat and slugs — sow in shade in summer, protect seedlings.

**Onions.** Hardy bulb. Sow seed indoors in late winter or plant sets (small bulbs) in spring. Full sun. 4 inches apart. Harvest when leaves fall over, then cure for two weeks before storing. Yield: about 1 kg (2 lb) per 3-foot row of sets. Problem: onion fly — rotate crops, do not grow onions in the same spot each year.

**Peas.** Hardy legume. Sow outdoors from early spring, every 2–3 weeks. Full sun to part shade. 2 inches apart, with support. Harvest from 60–70 days; pick every 2–3 days. Yield: about 500 g (1 lb) of peas per 3-foot row. Problem: birds taking seed — cover with netting until plants are established; mice also take seed.

**Potatoes.** Half-hardy tuber. Plant seed potatoes in early to mid-spring, 12 inches apart, 4–6 inches deep, in rows 2 feet apart. Full sun. Harvest new potatoes from 10 weeks; maincrop from 15–20 weeks. Yield: a realistic home-garden yield is 5–10 kg (11–22 lb) from a 10-foot row of maincrop potatoes, or about 1–1.5 kg per plant. Problem: blight in wet summers — choose resistant varieties and earth up the stems as they grow.

**Radishes.** Hardy root. Sow outdoors from early spring, every 2 weeks until autumn. Full sun to part shade. 1 inch apart. Harvest from 25–30 days — the fastest crop in this programme. Yield: about 200–300 g (7–10 oz) per 3-foot row. Problem: bolting and woody roots in heat or dry soil — keep moist, sow in cool weather.

**Spinach.** Hardy leaf. Sow outdoors in spring and again in late summer for autumn. Part shade in summer. 4–6 inches apart. Harvest from 40–50 days; pick outer leaves. Yield: about 500 g (1 lb) per 3-foot row. Problem: bolting in heat — sow in cool seasons, water well.

**Strawberries.** Perennial fruit. Plant bare-root or potted plants in spring or autumn. Full sun. 12–18 inches apart. Harvest from the first summer after spring planting; plants fruit for 3–4 years. Yield: about 500 g–1 kg (1–2 lb) per plant per year in a good season. Problem: birds and slugs — net before fruit colours, mulch with straw to keep fruit off the soil.

**Sweetcorn.** Tender, needs space. Sow outdoors after frost, or indoors 3 weeks before, in blocks of at least 4 by 4 plants so wind pollinates them. Full sun. 12–18 inches apart. Harvest from 70–90 days, when silks turn brown and a kernel pierced with a nail releases milky juice. Yield: 1–2 cobs per plant. Problem: poor pollination in single rows — always plant in a block.

**Tomatoes.** Tender fruit. Sow indoors 6–8 weeks before last frost; plant out after frost. Full sun, sheltered. 18–24 inches apart, staked. Harvest from 65–85 days after transplanting. Yield: a cherry tomato plant gives 2–4 kg (4–9 lb) over a season; a large slicing variety gives 3–6 kg (7–13 lb). Problem: blight and blossom-end rot — water evenly, mulch, space for airflow, choose resistant varieties.

---

# Worked Examples: Three Real Gardens, Three Real Budgets

All prices are approximate, in US dollars, based on typical garden-centre and hardware-store prices, and will vary by region and season. They are planning figures, not quotes. Each budget is for the first year, including the one-off cost of building the bed or buying containers. In year two, the cost falls sharply, because the bed, tools, and containers are already bought and only seed, compost, and a few consumables need replacing.

## Example A: The Balcony Garden — 4 large pots

**Space:** a sunny balcony or patio, 4–6 hours of sun. **Household:** 1–2 people.

- 4 large pots, 5 gallons each, with saucers: $40–$60
- Potting mix, 2 large bags: $25–$35
- Seed and plants: cherry tomato (1 plant), basil (2 plants), salad leaves (1 packet), chives (1 plant): $20–$30
- Liquid feed, 1 bottle: $10
- Watering can: $12
- **Total first-year cost: about $110–$150**

**What it grows:** salads several times a week from late spring to autumn, a cherry tomato plant giving 2–4 kg over the summer, and herbs all season. **Realistic savings:** $100–$200 over the season on salad, herbs, and tomatoes at typical grocery prices — enough to cover the first-year cost and leave a small surplus, with the pots and watering can lasting for years.

## Example B: The First Raised Bed — 4 by 8 feet

**Space:** a small yard, full sun. **Household:** 2–4 people.

- Untreated timber for a 4-by-8-foot bed, 12 inches deep, plus screws: $50–$80
- Soil and compost to fill it (about 1 cubic yard): $60–$90
- Seed: lettuce, radishes, peas, beans, courgette, tomato, herbs: $30–$45
- Tomato stakes and string, bean canes: $15–$25
- Mulch (straw bale): $10–$15
- Basic tools if you do not own them (fork, trowel, hoe): $30–$50
- Watering can or hose attachment: $15–$25
- **Total first-year cost: about $210–$330**

**What it grows:** a full summer of salads and herbs, 2 tomato plants, 1 courgette, beans, peas, and radishes — enough to noticeably reduce vegetable shopping from June to September. **Realistic savings:** $200–$400 over the season, depending on local grocery prices and how much of the harvest the household actually eats. In year two, with the bed and tools already owned, the cost is roughly $60–$90 for seed and compost, so the savings are clearer.

## Example C: The Serious Back Garden — 3 raised beds, about 100 square feet

**Space:** a larger yard, full sun. **Household:** 3–5 people.

- Timber and soil for 3 beds (4 by 8 feet each): $330–$510
- Seed and plants for a full season, including potatoes and onions: $60–$90
- Trellises, stakes, netting, fleece: $50–$80
- Compost, mulch, and a water butt: $80–$120
- Tools: $40–$60
- **Total first-year cost: about $560–$860**

**What it grows:** salads, herbs, tomatoes, beans, courgettes, potatoes, onions, carrots, kale, and soft fruit — a serious share of the household's vegetables from late spring to autumn, plus storage crops for winter. **Realistic savings:** $400–$800 over the season, again depending on prices and on how much is eaten rather than wasted. This is the garden where the savings become substantial — but only from year two onwards, when the setup cost has been paid.

**The honest pattern across all three examples:** year one roughly breaks even or saves a little, because you are buying the setup. Year two and beyond is where the money is saved, because the expensive items last for years and the annual cost is mostly seed and compost. A garden is a multi-year investment, not a one-season saving.

---

# The Grocery-Savings Math, Done Honestly

Home-garden savings are often exaggerated. Here is the honest arithmetic, so you can do it for your own garden.

**Step 1: Record what you harvest.** Use the Harvest Log. Weigh produce where you can — a kitchen scale is enough — or count it: 12 courgettes, 40 tomatoes, 20 bags of salad leaves.

**Step 2: Price it at what you would actually have paid.** Use the price of the equivalent item at your usual shop, in the same week. A bag of salad leaves at $3, a bunch of herbs at $2, a kilogram of tomatoes at $4. Use the ordinary price, not the most expensive organic price, unless that is what you normally buy.

**Step 3: Add up the value, subtract your costs.** Your costs are seed, compost, water, and any consumables for that season. Do not count the one-off cost of beds and tools in a single season — spread it over the years they will last (a timber bed lasts 5–8 years; a pot lasts many years).

**Worked example — Example B, the first raised bed, in its second year.** Annual costs: seed $35, compost $25, water roughly $10 (if metered), total $70. Harvest over the season: 30 bags of salad at $3 = $90; 15 kg of tomatoes at $4/kg = $60; 4 kg of courgettes at $3/kg = $12; 3 kg of beans at $5/kg = $15; herbs, 20 bunches at $2 = $40; peas and radishes $25. Total value: $242. Savings: $242 − $70 = $172 for the season. That is a realistic, good second year — meaningful, but not a replacement for the grocery shop. A household spending $150 a week on groceries spends about $7,800 a year; $172 is about 2% of that. The garden's value is in freshness, flavour, and the food you grow yourself, with a real but modest saving on top. Anyone promising that a home garden will save you thousands in year one is not doing the same arithmetic.

**What actually drives savings:** growing expensive, high-value crops (herbs, salad leaves, tomatoes, berries) rather than cheap ones (potatoes, onions, carrots, which are inexpensive to buy); eating what you grow instead of letting it rot; and keeping the garden going for several years so the setup cost is spread thin. Waste is the enemy of savings — a courgette left to grow into a marrow and thrown away is money lost, not saved.

---

# Your First 30 Days: A Starter Checklist

**Days 1–7:** Complete the Space Assessment. Measure sun. Look up frost dates. Do the squeeze and jar tests on your soil. Order or start compost. Decide on raised bed, containers, or in-ground.

**Days 8–14:** Send a soil sample for a lab test. Build or buy your bed or pots. Buy soil, compost, and tools. Draw your bed layout and fill in the Crop Selection Worksheet.

**Days 15–21:** Order seed. Set up your indoor sowing station. Sow the first indoor crops if the timing is right for your frost date. Mulch any bed that is ready.

**Days 22–30:** Direct-sow the first hardy crops outdoors. Label every row with the crop and the date. Start the daily watering check. Write your first Harvest Log entry — even if it is only "sowed lettuce, 12 March" — because the habit of recording starts now, not at harvest.

---

# Glossary

- **Bolting:** a plant running to seed prematurely, usually from heat or long days; the leaves become bitter.
- **Cloche:** a cover placed over a single plant to protect it from cold or pests.
- **Cold frame:** a low, lidded box set on the soil, used to protect and warm plants.
- **Compost:** decomposed organic matter used to improve soil.
- **Cover crop / green manure:** a crop grown to improve the soil, not to eat.
- **Damping-off:** a fungal disease that kills seedlings at soil level.
- **Determinate tomato:** a bush tomato that grows to a set height and fruits over a short period.
- **Hardening off:** gradually introducing indoor-raised plants to outdoor conditions.
- **Indeterminate tomato:** a cordon tomato that grows tall all season and fruits continuously.
- **Mulch:** a layer of material spread on the soil surface to retain moisture and suppress weeds.
- **Succession sowing:** sowing a crop in small batches over time, or following one crop with another in the same space.
- **Thinning:** removing some seedlings so the ones left have room to grow.

---

*End of programme. Now open the workbook, complete the Space Assessment, and start your first 30 days.*
