# GRN-04 — The Abundant Home Garden: Grow Your Own Food Year-Round

**SKU:** GRN-04 · **Category:** Green Living & Sustainability · **Price:** $197 (one-time) · **Tier:** Starter

**Headline:** Grow your own food year-round — vegetables, herbs, and fruit, even in a small space.

A practical home gardening and food production course for beginners growing vegetables, herbs, and fruit at home — for homeowners and renters who want to grow their own food to save on groceries and eat fresher produce.

## Files in this folder

| File | What it is |
|------|-----------|
| `content.md` | The full programme — introduction, 8 modules fully written, 20 crop guides, 3 worked garden budgets, honest grocery-savings math, first-30-days checklist, glossary. |
| `workbook.md` | Companion workbook — 7 worksheets: space assessment, soil test log, planting calendar worksheet, crop selection worksheet, harvest log, pest log, season review. |
| `templates/seasonal-planting-calendar.md` | Month-by-month planting guide (sow indoors / sow outdoors / transplant / harvest). |
| `templates/garden-planner.csv` | Garden planner spreadsheet — beds, crops, dates, spacing, yields (3-bed garden + containers). |
| `templates/soil-health-guide.md` | Soil testing, compost, mulch, cover crops, feeding, common soil problems, yearly routine. |
| `templates/pest-control-cheat-sheet.md` | The ten most common pests and diseases — identification, first steps, safety rules. |
| `sales-page.md` | Full sales page — headline, problem, solution, what is inside, who it is for / not for, $197 price + 14-day guarantee, FAQ (10 questions), disclaimers. |
| `listing.json` | Marketplace listing data (sku GRN-04, price_cents 19700, billing one_time). |
| `cover.md` | Cover design brief — premium black-and-gold luxury branding. |
| `cover.png` | The generated cover image (1280 × 1920). |
| `onboarding.md` | Customer onboarding guide — what to do first, how to use the materials, suggested schedule, support. |
