# Customer Onboarding — The Abundant Home Garden (GRN-04)

Welcome. You have just bought a complete home food gardening programme. This guide tells you what to do first, how to use the materials, and how to get support.

## What you received

- **content.md** — the full programme: introduction, 8 modules, 20 crop guides, 3 worked garden budgets, honest grocery-savings math, a first-30-days checklist, and a glossary.
- **workbook.md** — the companion workbook with 7 worksheets. Print this one.
- **templates/seasonal-planting-calendar.md** — month-by-month planting guide. Print this one.
- **templates/garden-planner.csv** — garden planner spreadsheet (beds, crops, dates, spacing, yields). Open it in any spreadsheet app.
- **templates/soil-health-guide.md** — testing, compost, mulch, cover crops, and a yearly soil routine.
- **templates/pest-control-cheat-sheet.md** — the ten most common problems, with first steps and safety rules. Keep it where you garden.
- **sales-page.md** — the full sales page for reference.
- **cover.png** — the product cover image.

No physical product is shipped. All files are standard documents you can read on any device and print.

## What to do first (your first hour)

1. **Read the introduction and Module 1** in content.md. Do not skip ahead to planting.
2. **Print the workbook and the seasonal planting calendar.** You will use them every week.
3. **Complete Worksheet 1 — Space Assessment.** Measure the sunlight at your chosen spot on a clear day, hourly from 8 a.m. to 6 p.m., and write down the result.
4. **Look up your last and first frost dates** from your local agricultural extension service or meteorological office, and write them in Worksheet 3. Every planting date in the programme is adjusted from those two dates.

## How to use the materials

- **Read the programme in order the first time.** Each module builds on the last, and each ends with action steps and a checkpoint. Do not buy seeds or soil until you have finished Module 3 — that is where you decide what to grow and how much.
- **Use the workbook as your garden's record.** The programme teaches the method; the workbook holds your garden's actual numbers — your sun hours, your soil test results, your sowing dates, your harvests. Fill it in as you go, not from memory at the end of the season.
- **Use the templates where you garden.** Keep the pest control cheat sheet and the planting calendar somewhere you will actually see them — a shed wall, a kitchen noticeboard, or a folder by the back door.
- **Use the garden planner spreadsheet to plan the season,** then print it or copy the dates into the workbook's planting calendar worksheet.

## Suggested schedule

**Week 1 — Assess.** Space assessment, sunlight measurement, frost dates, soil squeeze and jar tests. Send a soil sample for a lab test. Decide on raised bed, containers, or in-ground.

**Week 2 — Build and plan.** Build or buy your bed or pots. Buy soil, compost, and tools. Draw your bed layout. Complete the Crop Selection Worksheet and choose 8–12 crops.

**Weeks 3–4 — Sow.** Order seed. Set up your indoor sowing station. Sow tender crops indoors if the timing is right for your frost date. Direct-sow hardy crops outdoors and label every row.

**Then, through the season — the weekly routine.** Ten minutes a day for watering, picking, and a quick pest check; 30–45 minutes once a week for weeding, feeding, and harvesting. Record every harvest in the Harvest Log and every problem in the Pest Log.

**End of season — review.** Within a week of the last harvest, complete the Season Review worksheet. It is the most valuable hour of the year, and it is the plan for your second season.

A full first-30-days checklist is in content.md, at the end of the worked examples.

## A note on expectations

Your first season is about learning. Some crops will fail, and that is normal. A realistic first-year goal is to grow a meaningful share of your salads, herbs, and a few staple vegetables, to learn your site, and to end the season knowing exactly what to plant more of next year. Yields, harvest dates, and savings in this programme are realistic ranges, not guarantees — they depend on your climate, space, sunlight, soil, and effort. The programme is for general education only; it is not agricultural, medical, nutritional, legal, or financial advice.

## How to get support

Contact support through the EightyTwenty marketplace help channel listed at checkout, quoting SKU GRN-04. Include your order number and a short description of your question. Support covers file access, download problems, and questions about how to use the materials. Support does not provide agricultural, medical, nutritional, legal, or financial advice. For local growing advice — frost dates, soil testing, and pest identification — your local agricultural extension service is the best source.
