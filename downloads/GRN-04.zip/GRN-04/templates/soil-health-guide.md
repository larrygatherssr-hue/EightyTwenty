# Soil Health Guide — The Abundant Home Garden (GRN-04)

A practical guide to testing, improving, and maintaining the soil in a home food garden. Companion to Module 2 of the programme.

## Education-Only Disclaimer

This guide is for general education only. It is not agricultural advice. Soil conditions vary by location; follow the recommendations of your local agricultural extension service or soil laboratory for your specific soil, and follow every product label exactly.

---

## 1. Know Your Soil Type

### The squeeze test

Take a handful of moist soil and squeeze it. If it falls apart, it is sandy. If it holds its shape but crumbles when poked, it is loam. If it holds a ribbon when pressed between thumb and finger, it is clay.

### The jar test

Fill a clean jar one-third full with soil, add water to near the top, add a teaspoon of washing-up liquid, shake hard for two minutes, and leave it for 24 hours. Sand settles first (bottom), silt next (middle), clay last (top). Measure each layer for a rough percentage.

### The drainage test

Dig a hole 12 inches (30 cm) deep and wide, fill it with water, let it drain, fill it again, and time the drop. About 1 inch (2.5 cm) per hour is good for vegetables. Much faster: the soil dries too quickly. Much slower: roots will sit in water. Water still standing after 24 hours is a drainage problem — use raised beds.

## 2. Get a Lab Test

A laboratory soil test (through your local extension service or a garden soil lab, typically $20–$30) measures pH, nitrogen, phosphorus, potassium, and often organic matter. Take samples from 6–8 spots at 6 inches deep, mix them, and send about a cup. Test before you buy fertiliser, and retest yearly — it is the cheapest way to know what your soil actually needs.

**Target pH for most vegetables: 6.0–7.0.** Below 5.5, nutrients become hard for plants to absorb. Above 7.5, iron and other micronutrients become unavailable and leaves yellow. Change pH slowly, at the lab's recommended rate, and retest the following year.

## 3. Compost: How Much, How Often

- **New bed:** mix roughly 60% topsoil with 40% compost.
- **Established bed:** spread 2–3 inches (5–7 cm) of finished compost over the surface each year and work it lightly into the top few inches, or leave it as a mulch and let worms do the work.
- **Containers:** refresh the top half of the potting mix each year with fresh compost; replace the mix entirely after two to three years.

Finished compost should smell earthy, not sour or like ammonia, and be dark and crumbly. If bought compost smells sour, it is not mature — leave it to mature before using it on food crops.

## 4. Making Compost

Mix roughly two to three parts brown (dry leaves, straw, shredded cardboard, small twigs) to one part green (vegetable peelings, fruit scraps, coffee grounds, fresh grass clippings) by volume. Keep the pile damp, like a wrung-out sponge, and turn it every few weeks to add air. A hot, well-built pile finishes in 2–3 months in warm weather; a cold pile takes 6–12 months. Both are fine.

**Do not compost:** meat, dairy, fats, cooked food, diseased plants, weed seeds that have set seed, treated wood, glossy paper, or pet waste from dogs and cats.

## 5. Mulch

Spread 2–3 inches of straw, shredded leaves, or grass clippings (in thin layers) on the soil surface around plants, keeping mulch a couple of inches away from stems. Mulch suppresses weeds, keeps soil moist, moderates temperature, and feeds soil life as it breaks down. Mulch after watering, not onto dry soil. Wood chips are for paths and around fruit, not dug into vegetable beds.

## 6. Cover Crops (Green Manures)

Sow on empty beds in autumn. They protect soil from rain, suppress weeds, and add organic matter when dug in or cut down in spring. Legumes (clover, field beans) also fix nitrogen.

| Cover crop | When to sow | Notes |
|------------|-------------|-------|
| Crimson clover | Late summer–autumn | Fixes nitrogen; attractive to bees in spring |
| Winter rye | Autumn | Tough, good weed suppression; cut down in spring before it sets seed |
| Field beans | Autumn | Fixes nitrogen; hardy in cold climates |
| Phacelia | Spring–late summer | Fast growing; excellent for bees; not a legume |

## 7. Feeding

In soil rich in compost, most vegetables need little extra feeding. Feed heavy feeders (tomatoes, courgettes, sweetcorn, brassicas) with a liquid seaweed or balanced organic feed every two to three weeks once fruiting, at the label rate. Do not overfeed: soft, sappy growth attracts aphids, delays fruiting, and excess fertiliser washes into waterways.

## 8. Common Soil Problems

| Symptom | Likely cause | First step |
|---------|--------------|-----------|
| Plants yellow, stunted, despite watering | Low nitrogen or pH out of range | Lab test; add compost; check pH |
| Soil hard, cracked, water runs off | Compaction, low organic matter | Add compost; mulch; do not dig when wet; avoid walking on beds |
| Soil always wet, plants rot | Poor drainage, heavy clay | Raised beds; compost; do not overwater |
| Soil dries out within a day | Sandy soil, low organic matter | Compost; mulch thickly; water deeply |
| White crust on soil surface | Salt build-up (often from hard water or over-fertilising) | Flush with clean water; reduce fertiliser; lab test |
| Nothing grows, even weeds | Possible contamination or extreme pH | Lab test including contaminants; grow in raised beds with bought soil until resolved |

## 9. The Yearly Soil Routine

- **Late winter:** lab test; order compost.
- **Spring:** spread compost on beds; mulch after planting.
- **Summer:** keep mulch topped up; do not let soil bake bare.
- **Autumn:** sow cover crops or mulch empty beds; add compost.
- **Every year:** do not dig deeply unless you must — loosen the top few inches, add compost on top, and let worms and roots do the deep work.

---

*Healthy soil is built over years, not bought in a weekend. Compost, mulch, and patience are the whole method.*
