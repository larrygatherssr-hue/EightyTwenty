# Seasonal Planting Calendar — The Abundant Home Garden (GRN-04)

A month-by-month planting guide for a temperate climate. **Adjust every date to your own last and first frost dates** — a gardener in a warm climate and a gardener in a cold climate plant the same crops months apart, and both are right. Frost dates are the anchor; this calendar is the pattern.

- **Sow indoors:** start seed under cover, in trays or pots.
- **Sow outdoors:** sow direct where the crop will grow.
- **Transplant:** move hardened-off seedlings outdoors.
- **Harvest:** the main harvest window for crops sown at the usual time.

## January — Plan

- **Sow indoors:** onions from seed; chillies and peppers in warm climates with a long season.
- **Sow outdoors:** nothing in cold climates; broad beans and peas in mild, frost-free climates.
- **Transplant:** none.
- **Harvest:** kale, leeks, Brussels sprouts, winter lettuce (mild climates); stored potatoes, onions, and squash.
- **Jobs:** order seed; test soil; plan the bed layout and rotation; clean and repair tools; start a compost pile.

## February — Start

- **Sow indoors:** onions, leeks, chillies, peppers, aubergines (warm spot, 18–24°C / 65–75°F for germination).
- **Sow outdoors:** broad beans, peas, and spinach in mild climates; nothing yet in cold climates.
- **Transplant:** none.
- **Harvest:** winter greens, leeks, stored crops.
- **Jobs:** build or repair raised beds; buy soil and compost; set up the indoor sowing station and grow lights if using them.

## March — First Outdoor Sowings

- **Sow indoors:** tomatoes (6–8 weeks before last frost), peppers, chillies, aubergines; lettuce and brassicas for early transplanting.
- **Sow outdoors:** peas, broad beans, lettuce, spinach, radishes, spring onions, potatoes (when soil is workable).
- **Transplant:** hardy lettuce and brassicas under fleece or a cold frame.
- **Harvest:** early spring greens, overwintered leeks and kale.
- **Jobs:** mulch beds; harden off early seedlings on mild days; net peas against birds.

## April — The Main Spring Push

- **Sow indoors:** courgettes and squash (3–4 weeks before last frost); cucumbers; sweetcorn in short-season climates.
- **Sow outdoors:** carrots, beetroot, spinach, lettuce (succession), radishes, spring onions, peas (second sowing).
- **Transplant:** tomatoes and peppers only after the last frost and when nights stay above 10°C / 50°F.
- **Harvest:** spring lettuce, radishes, spinach, early peas.
- **Jobs:** water new sowings; thin seedlings to packet spacing; stake tomatoes as they grow.

## May — Planting Out

- **Sow indoors:** last courgettes and beans for succession; basil.
- **Sow outdoors:** French beans (soil above 16°C / 60°F), sweetcorn, squash, courgettes, cucumbers; lettuce and radishes (succession).
- **Transplant:** tomatoes, peppers, courgettes, cucumbers, basil — all after the last frost.
- **Harvest:** lettuce, radishes, spring onions, peas, early strawberries.
- **Jobs:** mulch everything; set up trellises for beans; net brassicas and carrots; start the weekly watering and weeding routine.

## June — Early Summer Harvests

- **Sow indoors:** none — focus on the garden, not the windowsill.
- **Sow outdoors:** French beans (second batch), lettuce, radishes, carrots for autumn; beetroot.
- **Transplant:** leeks for winter; late brassicas.
- **Harvest:** peas, broad beans, lettuce, strawberries, new potatoes, herbs, first courgettes.
- **Jobs:** water deeply in dry weather; feed tomatoes and courgettes lightly every 2–3 weeks; pick beans and courgettes every 2–3 days; watch for aphids and blight.

## July — High Summer

- **Sow indoors:** none.
- **Sow outdoors:** lettuce and radishes in part shade; French beans (last batch); spinach for autumn in late July.
- **Transplant:** winter brassicas (kale, broccoli for autumn) if started earlier.
- **Harvest:** tomatoes, courgettes, beans, cucumbers, peppers, herbs, potatoes, onions (lift and cure).
- **Jobs:** harvest daily; water at the base in the morning; remove yellowing leaves; preserve the surplus by freezing or drying.

## August — Late Summer, Autumn Sowing Begins

- **Sow indoors:** none.
- **Sow outdoors:** autumn lettuce, spinach, radishes, spring onions; turnips and winter radishes.
- **Transplant:** winter lettuce under fleece or a cold frame.
- **Harvest:** tomatoes, beans, courgettes, peppers, sweetcorn, maincrop potatoes, onions.
- **Jobs:** order garlic for autumn planting; sow cover crops on beds that are finishing; keep watering — August drought kills more plants than any pest.

## September — Autumn Harvests

- **Sow indoors:** none.
- **Sow outdoors:** spinach, winter lettuce, spring onions for overwintering (mild climates).
- **Transplant:** none.
- **Harvest:** tomatoes (last), courgettes, winter squash, maincrop potatoes, carrots, beetroot, apples and soft fruit where grown.
- **Jobs:** lift and store potatoes on a dry day; cure onions and garlic; start putting spent beds to bed with compost or cover crops.

## October — Planting for Next Year

- **Sow indoors:** none.
- **Sow outdoors:** garlic (cloves, point up, 6 inches apart); broad beans in mild climates; winter field beans as a cover crop.
- **Transplant:** none.
- **Harvest:** winter squash, leeks, carrots, beetroot, kale, late tomatoes (pick green before frost and ripen indoors).
- **Jobs:** plant garlic; sow cover crops (crimson clover, winter rye) on empty beds; clean tools; store pots and hoses before frost.

## November — Closing Down

- **Sow indoors:** none.
- **Sow outdoors:** garlic if not yet planted; broad beans in mild climates.
- **Transplant:** none.
- **Harvest:** kale, leeks, Brussels sprouts, winter lettuce (mild climates).
- **Jobs:** mulch beds thickly; protect tender plants with fleece; complete the Season Review in the workbook; save seed from open-pollinated varieties only.

## December — Rest and Plan

- **Sow indoors:** nothing, except herbs and microgreens on a sunny windowsill.
- **Sow outdoors:** nothing in cold climates.
- **Transplant:** none.
- **Harvest:** winter greens and leeks where the climate allows; stored potatoes, onions, and squash.
- **Jobs:** plan next year's rotation from your notes; order seed in winter while stock is full; retest soil in late winter; repair the cold frame and tools.

---

*Adjust this calendar to your frost dates, and write your adjusted dates into Worksheet 3 of the workbook. A calendar you have adjusted to your own garden is worth more than any printed one.*
