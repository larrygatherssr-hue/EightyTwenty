# Pest Control Cheat Sheet — The Abundant Home Garden (GRN-04)

Identify the problem first, then start with the least harmful method. Companion to Module 6 of the programme.

## Safety First — Read This Before You Spray Anything

- Identify the pest or disease before treating — treating the wrong thing wastes time and can harm useful insects.
- Start with prevention and physical methods (netting, hand-picking, water). Use sprays only when those are not enough.
- Read the product label and follow it exactly, including the waiting period between spraying and harvest. Never exceed the label rate.
- Spray in the evening, when bees are not flying. Never spray in wind, or when rain is expected within hours.
- Do not mix products. Do not assume a "natural" product is safe for bees, children, or pets.
- Keep a note of what you sprayed, when, and on what (use the Pest Log in the workbook).
- If you are unsure, ask your local agricultural extension service before spraying a food crop.
- Keep all pesticides, fertilisers, and sharp tools away from children and pets.

---

## Prevention Checklist (do these first — they prevent most problems)

- [ ] Rotate crop families each year; do not grow the same family in the same spot.
- [ ] Space plants to the packet spacing so air moves and leaves dry.
- [ ] Water at the base, in the morning; keep leaves dry.
- [ ] Mulch, but keep it away from stems.
- [ ] Net brassicas and carrots from planting day.
- [ ] Grow flowers (marigolds, calendula, nasturtiums) at the ends of beds to attract ladybirds, hoverflies, and bees.
- [ ] Remove dead and diseased leaves promptly; bin diseased material, do not compost it.
- [ ] Check leaf undersides every 2–3 days.

---

## Pest and Disease Quick Reference

### Aphids

- **Signs:** small green, black, or white insects clustered on shoot tips and leaf undersides; curling leaves; sticky honeydew; ants farming them.
- **Crops:** most vegetables, especially beans, lettuce, brassicas.
- **First step:** blast off with a strong jet of water.
- **Next:** encourage ladybirds; if heavy, use insecticidal soap at the label rate, in the evening. Check again in 3 days.

### Slugs and snails

- **Signs:** seedlings eaten overnight; silvery slime trails; holes in leaves and soft fruit.
- **Crops:** seedlings, lettuce, strawberries, hostas and young plants of all kinds.
- **First step:** water in the morning; remove hiding places; pick off by hand after dark with a torch.
- **Next:** copper tape around pots; beer traps. If using pellets, choose one labelled safe for food gardens and follow the label exactly; avoid metaldehyde products where children, pets, or wildlife may be exposed.

### Cabbage white caterpillars

- **Signs:** green caterpillars chewing holes in leaves; yellow eggs on leaf undersides; white butterflies over the bed.
- **Crops:** cabbage, broccoli, kale, cauliflower, radishes.
- **First step:** cover with fine insect mesh or netting from planting day — the most reliable method.
- **Next:** pick caterpillars off by hand; check for eggs weekly.

### Carrot fly

- **Signs:** rusty tunnels in carrot roots; wilting foliage.
- **Crops:** carrots, parsnips, celery.
- **First step:** grow under fine mesh from sowing; avoid thinning on a still day.
- **Next:** sow later in the season; grow carrots in a container at least 18 inches high — the fly stays low.

### Whitefly

- **Signs:** tiny white insects flying up in a cloud when the plant is disturbed; sticky leaves; sooty mould.
- **Crops:** tomatoes, brassicas, courgettes.
- **First step:** encourage natural predators; wash leaves with water.
- **Next:** yellow sticky traps for monitoring; in a greenhouse, a biological control (predatory insect) from a garden supplier.

### Flea beetles

- **Signs:** tiny beetles; small holes ("shot holes") in leaves.
- **Crops:** radishes, rocket, brassicas, especially seedlings.
- **First step:** cover seedlings with fine mesh until established.
- **Next:** keep soil moist; mature plants usually tolerate the damage.

### Birds

- **Signs:** seedlings pulled up; peas eaten; soft fruit taken as it colours.
- **Crops:** peas, seedlings, strawberries, soft fruit.
- **First step:** netting over a frame so it does not rest on the plants.
- **Next:** check netting regularly so birds do not get tangled; net strawberries before fruit colours.

### Powdery mildew

- **Signs:** white powdery coating on leaves, starting on older leaves.
- **Crops:** courgettes, squash, cucumbers.
- **First step:** space for airflow; water at the base; remove affected leaves promptly.
- **Next:** plants often keep producing if the worst leaves are removed; it rarely kills a plant outright.

### Blight (tomato and potato)

- **Signs:** dark patches on leaves and stems spreading fast in warm, wet weather; fruit rots.
- **Crops:** tomatoes, potatoes.
- **Honest limit:** once blight takes hold there is no home cure that reliably saves the crop.
- **Prevention:** buy blight-resistant varieties; space for airflow; water at the base; remove lower leaves; do not compost diseased material.
- **If it appears:** remove affected plants, bag them, and bin them. Choose a resistant variety next year.

### Damping-off

- **Signs:** seedlings collapse at soil level and die, indoors.
- **Crops:** indoor-sown seedlings of all kinds.
- **Prevention:** clean pots; fresh seed mix; water from below; good air circulation; do not sow too thickly.
- **If it appears:** remove affected seedlings; improve airflow; start again with fresh mix.

### Blossom-end rot (tomatoes, peppers)

- **Signs:** dark, sunken patch on the end of the fruit.
- **Cause:** uneven watering preventing calcium uptake — usually not a lack of calcium in the soil.
- **Fix:** water evenly; mulch; do not overfeed with nitrogen. Affected fruit will not recover — pick it off.

---

## When to Pull a Plant and Replant

Pull the plant, bin diseased material, and sow something else when: blight has spread through the plant; more than half the leaves are diseased; the plant has stopped growing for two weeks despite water and food; or the pest damage is so heavy that the plant will not recover before the season ends. A month spent trying to save a failing plant loses the space and the chance of a second crop.

---

## Beneficial Insects — Protect These

- **Ladybirds and their larvae:** eat aphids.
- **Hoverflies:** larvae eat aphids; adults pollinate.
- **Lacewings:** larvae eat aphids and whitefly.
- **Bees:** pollinate beans, courgettes, cucumbers, and fruit.
- **Ground beetles:** eat slugs and their eggs.

Avoid broad-spectrum insecticides that kill these along with the pests. If you must spray, spray in the evening and only the affected plant.
