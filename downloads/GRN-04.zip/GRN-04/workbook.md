# The Abundant Home Garden — Garden Planner Workbook

Companion workbook to *The Abundant Home Garden: Grow Your Own Food Year-Round* (GRN-04).

Print this workbook and keep it where you garden. Fill it in by hand as you go — the notes you make in the season are the plan for next season.

## Education-Only Disclaimer

This workbook is for general education and information only. It is not agricultural, medical, nutritional, legal, or financial advice. Gardening results depend on your climate, sunlight, soil, water, pests, weather, and the time and care you put in. Yields and savings are estimates, not guarantees. Always check local rules before building structures, using a pesticide, or planting anything that may be invasive in your area. Wash all produce before eating it. Follow every product label exactly, and keep pesticides, fertilisers, and sharp tools away from children and pets.

---

## Worksheet 1 — Space Assessment

Complete this before you buy anything. See Module 1 of the programme.

- My garden space (yard, balcony, patio, shared plot): ___________________________
- Total growing area (length × width): ___________________________
- Direction the main growing area faces (N / S / E / W): ___________________________
- Hours of direct sun on a clear day (counted hourly, 8 a.m.–6 p.m.): __________ hours
- Sunniest spot: ___________________________
- Shadiest spot: ___________________________
- What casts shade, and when (trees, fences, buildings): ___________________________
- Wind: sheltered / breezy / very exposed — notes: ___________________________
- Nearest water source: ___________________________  Distance to beds: __________ m
- How I will water (can / hose / soaker hose / drip): ___________________________
- Drainage after rain (drains well / puddles / water stands for hours): ___________________________
- What already grows here, and what it suggests about the soil: ___________________________
- Growing setup chosen (in-ground / raised bed / containers / mix): ___________________________
- Number and size of beds or containers: ___________________________
- Renter notes (anything that must stay movable; lease or building rules checked? Y / N): ___________________________

**My site in one sentence:** "My sunniest spot gets ___ hours of direct sun, my last frost date is ___, my water source is ___, and I will grow in ___."

---

## Worksheet 2 — Soil Test Log

See Module 2. Record each test with the date so you can compare year to year.

### Squeeze test

- Date: __________  Result (sandy / loam / clay / silty): ___________________________
- Notes: ___________________________

### Jar test

- Date: __________  Sand: ___%  Silt: ___%  Clay: ___%  Texture: ___________________________

### Drainage test

- Date: __________  Hole depth: __________  Water drop per hour: __________  Rating (fast / good / slow): __________

### Lab test

- Date sent: __________  Lab / service: ___________________________
- pH: __________  Organic matter: __________%
- Nitrogen: __________  Phosphorus: __________  Potassium: __________
- Lab recommendations: ___________________________
- Action taken (lime / sulphur / compost — amount and date): ___________________________

### Compost

- Compost source (home pile / bought): ___________________________
- Compost applied (date, bed, amount): ___________________________
- Mulch used (type, depth, date): ___________________________

**Year-on-year comparison:** pH last year: ______  pH this year: ______  Organic matter last year: ______%  This year: ______%

---

## Worksheet 3 — Planting Calendar Worksheet

Copy the dates from the seasonal planting calendar template, adjusted to your own frost dates. See Module 3.

- Last frost date: __________  First frost date: __________  Growing season: __________ days
- Hardiness zone (if known): __________

| Month | Sow indoors | Sow outdoors | Transplant out | Harvest | Notes |
|-------|-------------|--------------|----------------|---------|-------|
| Jan | | | | | |
| Feb | | | | | |
| Mar | | | | | |
| Apr | | | | | |
| May | | | | | |
| Jun | | | | | |
| Jul | | | | | |
| Aug | | | | | |
| Sep | | | | | |
| Oct | | | | | |
| Nov | | | | | |
| Dec | | | | | |

Succession sowings planned (crop, first sowing, then every ___ weeks, last sowing):
1. ___________________________  2. ___________________________  3. ___________________________

---

## Worksheet 4 — Crop Selection Worksheet

Choose 8–12 crops for year one. See Module 3. For each crop, answer honestly: do we eat it weekly?

| Crop | Do we eat it weekly? (Y/N) | Sun needed | Plants / row length | Spacing | Sow date | Transplant date | Expected harvest |
|------|------------------------------|------------|---------------------|---------|----------|-----------------|------------------|
| 1. | | | | | | | |
| 2. | | | | | | | |
| 3. | | | | | | | |
| 4. | | | | | | | |
| 5. | | | | | | | |
| 6. | | | | | | | |
| 7. | | | | | | | |
| 8. | | | | | | | |
| 9. | | | | | | | |
| 10. | | | | | | | |
| 11. | | | | | | | |
| 12. | | | | | | | |

Bed layout sketch (draw it here or on a separate page — mark north, tall plants on the north side, paths):

___________________________________________________________________________
___________________________________________________________________________
___________________________________________________________________________

Rotation plan for next year (which family moves where): ___________________________

---

## Worksheet 5 — Harvest Log

Record every harvest. Weigh where you can — a kitchen scale is enough — or count. Price each harvest at what the same item would have cost at your usual shop that week, and total it at the end of the season. That total, minus your costs, is your honest saving.

| Date | Crop | Amount (kg or count) | Shop price for same amount | What I cooked with it | Notes |
|------|------|----------------------|----------------------------|------------------------|-------|
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |

**Season totals**

- Total value of harvest (sum of shop prices): $__________
- Total costs this season (seed, compost, water, consumables): $__________
- Net saving this season: $__________
- Best-value crop (highest value for the space and effort): ___________________________
- Most wasted crop (grew more than we ate): ___________________________

---

## Worksheet 6 — Pest Log

Record problems as you find them, and what you did. See Module 6 and the pest control cheat sheet.

| Date | Crop | Problem seen (what, where on plant) | Likely cause | Action taken | Result (3–7 days later) |
|------|------|--------------------------------------|--------------|--------------|--------------------------|
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |

Sprays used (product, date, crop, waiting period before harvest observed? Y/N):
___________________________________________________________________________

Plants pulled and replaced (crop, date, reason, replacement crop): ___________________________

---

## Worksheet 7 — Season Review

Complete within a week of the last harvest, while the season is fresh. This is the most valuable page in the workbook.

**What grew well, and why?**
___________________________________________________________________________
___________________________________________________________________________

**What failed, and why? (timing / water / pests / soil / wrong crop for the site)**
___________________________________________________________________________
___________________________________________________________________________

**What did we actually eat? (from the Harvest Log)**
___________________________________________________________________________

**What should I grow more of next year?**
___________________________________________________________________________

**What should I grow less of, or drop?**
___________________________________________________________________________

**Biggest problem this season, and the fix for next year:**
___________________________________________________________________________

**One new crop to try next year:** ___________________________

**Soil changes this year (compost added, pH change, drainage change):** ___________________________

**Second-season plan — three changes only:**
1. ___________________________
2. ___________________________
3. ___________________________

**Would I expand next year? (one more bed / a few more pots / stay the same) — and why?**
___________________________________________________________________________

**Overall rating of the season (1–10) and one sentence on why:** ___________________________
