# First Investor: The Beginner Investing Foundations Course

**SKU:** FIN-02 · **Category:** Finance & Wealth Building · **Price:** $397 one-time

A complete 10-module written course manual for first-time investors, with the full course text, workbook, and supporting materials. Plain-English investing from zero to invested.

> Financial education only — not individualized investment, tax, or financial advice. Investing involves risk, including possible loss of principal.

## Files in this product

| File | What it is |
|---|---|
| `content.md` | The full course manual — all 10 modules in full prose, worked examples with real numbers, 50-term glossary, 25-question quiz bank |
| `workbook.md` | Companion workbook — risk-tolerance summary, account-opening checklists, portfolio-builder worksheet, fee-comparison worksheet, 90-day action tracker, rebalancing checklist, one-page investor plan |
| `templates/portfolio-builder.csv` | Portfolio-builder spreadsheet — holdings, allocations, dollar amounts, expense ratios, with summary (total, weighted expense ratio, stock/bond split) |
| `templates/risk-tolerance-worksheet.md` | Fill-in risk-tolerance questionnaire (10 questions) with scoring guide |
| `templates/account-opening-checklist.md` | Account-opening checklists for brokerage, Roth IRA, 401(k), and HSA |
| `sales-page.md` | Full sales page — headline, problem, solution, module list, who it is/is not for, $397 price, 14-day guarantee, FAQ, disclaimer |
| `listing.json` | EightyTwenty marketplace listing data (valid JSON, price_cents 39700) |
| `cover.md` | Cover design brief — black-and-gold luxury branding |
| `cover.png` | The generated cover image |
| `onboarding.md` | Customer onboarding guide — what to do first, how to use each file, 4-week schedule, support |
| `README.md` | This index |

## Quick start for the buyer

1. Read Module 1 of `content.md`.
2. Complete `templates/risk-tolerance-worksheet.md`.
3. Follow the 4-week schedule in `onboarding.md`, then the 90-day plan in Module 10.
