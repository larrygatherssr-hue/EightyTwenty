# First Investor — Customer Onboarding Guide

Welcome, and congratulations on starting. This guide tells you exactly what to do first, how to use each file, and how to finish the course in about four weeks.

> **Disclaimer:** This course is financial education only. It is not individualized investment, tax, or financial advice. Investing involves risk, including the possible loss of principal.

---

## What to do first (Day 1)

1. **Download and save all your files** somewhere you can find them again (a folder called "First Investor" on your computer works well).
2. **Read Module 1 of `content.md`** — "Why Investing, Why Now, and What Investing Is Not." It takes about 20 minutes and sets up everything that follows.
3. **Complete the risk-tolerance worksheet** in `templates/risk-tolerance-worksheet.md`. Score it, record your suggested allocation, and copy the result into the workbook (`workbook.md`, Section 1). Do this before you choose a portfolio — your allocation should follow your answers, not a guess.
4. **Write your one-sentence reason for investing** (Module 1 action step). Keep it somewhere you will see it when markets fall.

Do not skip the worksheet. It is the foundation the rest of the course builds on.

---

## How to use each file

| File | What it is | How to use it |
|---|---|---|
| `content.md` (course text / PDF) | The full course manual — all 10 modules, glossary, and quiz bank | Read one module at a time, in order. Each module ends with action steps — do them before moving on. |
| `workbook.md` | Companion workbook | Your working notebook. Fill in the risk-tolerance summary, account checklists, portfolio-builder worksheet, fee-comparison worksheet, 90-day tracker, and rebalancing checklist as you reach each module. Print it if you like writing by hand. |
| `templates/portfolio-builder.csv` | Portfolio-builder spreadsheet | Open in any spreadsheet app. Enter your fund names, tickers, allocation percentages, dollar amounts, and expense ratios. Check that allocations total 100% and the weighted expense ratio is under 0.20%. The example rows show Jordan's $10,000 starter portfolio from Module 7 — replace them with your own. |
| `templates/risk-tolerance-worksheet.md` | Risk-tolerance questionnaire with scoring guide | Complete all 10 questions, add your score, and read the suggested allocation range. Record the result in the workbook. |
| `templates/account-opening-checklist.md` | Account-opening checklists | Use when you open each account (brokerage, Roth IRA, 401(k), HSA). Gather the listed documents first so the application takes about 15 minutes. |
| `sales-page.md` | The course sales page | Reference copy — what the course promises and what it does not. Useful if you want to remind yourself of the scope. |
| `listing.json` | Marketplace listing data | Marketplace use only — you do not need to open it. |
| `cover.md` / `cover.png` | Cover design brief and cover image | The course cover. |

---

## Suggested 4-week schedule

**Week 1 — Foundations**
- Day 1: Read Module 1; complete the risk-tolerance worksheet.
- Day 2–3: Read Module 2; check your employer 401(k) match and your emergency savings.
- Day 4–5: Read Module 3; look up one total-market index fund and note its holdings and expense ratio.
- Weekend: Read Module 4; draft your allocation and enter it in the portfolio-builder worksheet.

**Week 2 — Risk, fees, and your portfolio**
- Day 8–9: Read Module 5; write your downturn rules (what you will do if your portfolio falls 20%, 30%, 50%).
- Day 10–11: Read Module 6; complete the fee-comparison worksheet for every fund you own or plan to buy.
- Day 12–14: Read Module 7; finalize your portfolio in the portfolio-builder spreadsheet and choose three-fund vs. target-date fund.

**Week 3 — Buying and staying the course**
- Day 15–16: Read Module 8; open and fund your account if you have not already.
- Day 17: Place your first buy, following the Module 8 walkthrough. Turn on dividend reinvestment.
- Day 18: Set up automatic contributions and automatic investments.
- Day 19–21: Read Module 9; put your annual rebalancing date and quarterly review date on the calendar.

**Week 4 — Your 90-day plan**
- Day 22–24: Read Module 10; copy the 90-day plan into your calendar with dated reminders.
- Day 25–28: Take the quiz bank at the end of the course manual. Re-read any module where you scored below your expectations. Complete the one-page investor plan in the workbook (Section 7) and file it with your records.

After Week 4, follow the 90-day plan in Module 10. Your next milestones are Day 31 (confirm the first automatic contribution invested), Day 60 (first monthly review), and Day 90 (full review).

---

## How to get support

- **Downloads or access problems:** Email the marketplace support address with your **order number** and a description of the problem. Support can re-send download links and help with file access.
- **Questions about the course content:** Re-read the relevant module and glossary entry first — most questions are answered there. For anything else, email support with your order number and the module or page number.
- **What support cannot do:** Support cannot provide individualized investment, tax, or financial advice, recommend specific securities for your situation, or tell you what to buy. For personal advice, consult a qualified professional.

---

## A final note

You do not need to finish this course perfectly. You need to finish it *started*: account open, portfolio bought, contributions automated. The 90-day plan exists so the learning becomes a habit. Good luck — and welcome to investing.
