# First Investor: The Beginner Investing Foundations Course

## The Complete Course Manual

**By EightyTwenty — Finance & Wealth Building**

---

> **IMPORTANT DISCLAIMER — PLEASE READ FIRST**
>
> This course is financial **education only**. It is not individualized investment advice, tax advice, legal advice, or financial planning advice, and it does not recommend any specific security, fund, brokerage, or strategy for you personally. Investing involves risk, including the possible loss of principal — the value of your investments can go down as well as up, and past performance does not guarantee future results. All return figures in this course are hypothetical illustrations based on stated assumptions, not predictions or guarantees. Your situation — income, debts, tax status, goals, time horizon, and risk tolerance — is unique. Before opening an account or investing, consider consulting a qualified, licensed financial adviser, tax professional, or other professional who can advise you on your specific circumstances. Nothing in this course creates an adviser–client relationship.

---

## How to Use This Course

This manual is the complete *First Investor* written course — all ten modules, in full. You do not need any prior knowledge. Each module builds on the last, and each ends with action steps you can complete in under an hour.

**What you will need:** this manual, the companion workbook (`workbook.md`), the portfolio-builder spreadsheet (`templates/portfolio-builder.csv`), and the risk-tolerance worksheet (`templates/risk-tolerance-worksheet.md`).

**Suggested pace:** one module per day, or two modules per week over five weeks. Module 10 gives you a dated 90-day plan so the learning turns into action.

**A note on honesty:** this course will not promise you riches. It will show you, with real numbers, how ordinary, boring, diversified investing has historically built wealth slowly — and how fees, taxes, panic, and inaction quietly destroy it. That is the whole secret. There is no other secret.

---

## Table of Contents

- Module 1 — Why Investing, Why Now, and What Investing Is Not
- Module 2 — The Accounts: Brokerage, Roth IRA, Traditional IRA, 401(k), HSA
- Module 3 — Stocks, Bonds, Index Funds, and ETFs in Plain English
- Module 4 — Diversification and Asset Allocation
- Module 5 — Risk: What It Really Is, How Much You Can Take, and How to Measure It
- Module 6 — Fees, Taxes, and the Costs That Quietly Eat Returns
- Module 7 — Building Your First Portfolio Step by Step
- Module 8 — How to Buy Your First Fund: A Walkthrough
- Module 9 — Staying the Course: Rebalancing, Downturns, and Behavior
- Module 10 — Your First 90 Days as an Investor: A Dated Action Plan
- Glossary (50 terms)
- Quiz Bank (25 questions with answers)
- Final Checklist and Next Steps

---

# Module 1 — Why Investing, Why Now, and What Investing Is Not

## 1.1 The problem: your cash is losing a quiet race

Open your banking app. Your savings account probably pays somewhere between 0.01% and 4% a year, depending on the bank and the year. Now look at prices. Over the long run, consumer prices in the United States have risen by roughly 3% a year on average. That rise is called **inflation**, and it is the reason a dollar today buys less than a dollar did ten years ago.

Here is what that means in real numbers. Suppose you keep $10,000 in cash under the mattress — or in an account paying 0% — for 30 years while prices rise 3% a year. The purchasing power of that $10,000 falls to about **$4,119.87**. The calculation is $10,000 ÷ (1.03)^30. You did nothing wrong. You did not lose money in the stock market. You lost more than half your buying power by doing nothing at all.

That is the first lesson of investing: **not investing is also a decision, and it has a cost.** Cash feels safe because the number on the screen never goes down. But the number that matters is not the balance — it is what the balance can buy.

This does not mean you should invest every dollar you own. You need cash for emergencies, and we will cover that in Module 2. But money you will not need for five, ten, or thirty years should not sit idle while inflation erodes it year after year.

## 1.2 What investing actually is

Investing means buying a small piece of something productive — a business, a loan to a government or company, a piece of real estate — and letting it generate value over time. When you buy a share of stock, you own a tiny slice of a real company that sells real products, employs real people, and earns real profits. When you buy a bond, you are lending money and being paid interest for it. When you buy a broad index fund, you own tiny slices of hundreds or thousands of companies at once.

Investing is not a lottery ticket. It is not a bet on a single hot tip. It is a claim on the future productive output of the economy. Over long periods, businesses tend to grow, earn more, and become more valuable. As an investor, you share in that growth. That is the engine. Everything else in this course — accounts, funds, allocation, rebalancing — is plumbing around that engine.

## 1.3 Compounding: the math that changes everything

Compounding means your earnings start earning earnings of their own. It is slow at first and powerful later, which is why starting early matters far more than starting big.

**Worked example — $500 a month at 7% for 30 years.**

Assumptions, stated plainly: you contribute $500 at the end of each month, your investments earn an average of 7% per year compounded monthly, returns are smooth (in reality they will bounce up and down — some years will be negative), and we ignore taxes and fees for this illustration. The 7% figure is a commonly used long-run planning assumption for a diversified stock-heavy portfolio; it is not a promise.

The future-value formula for monthly contributions is:

> FV = P × [((1 + r)^n − 1) / r], where P = $500, r = 0.07 ÷ 12 = 0.005833, n = 360 months.

- Monthly rate: 0.07 ÷ 12 = 0.0058333
- (1.0058333)^360 ≈ 8.1165
- FV = $500 × [(8.1165 − 1) ÷ 0.0058333] = $500 × 1,219.97 = **$609,985.50**

You contributed $500 × 360 = **$180,000** of your own money. Growth contributed **$429,985.50** — more than twice what you put in. Your money earned more than you did.

The same $500 a month, at the same 7%, is worth **$86,542.40 after 10 years** and **$260,463.33 after 20 years**. Notice the shape: the first ten years add about $86,000; the last ten years add about $350,000. Compounding accelerates. That is why the best time to start was ten years ago, and the second-best time is today.

Change the return assumption and the result changes dramatically — which is why you must never treat any single number as a guarantee:

- At 5% a year, $500 a month for 30 years grows to **$416,129.32**.
- At 9% a year, it grows to **$915,371.74**.

Same contributions, same time, wildly different outcomes — because the return is uncertain. The honest conclusion is not "you will have $609,985." It is: "regular contributions over a long time, invested in productive assets, have historically produced far more than the contributions alone — and the range of outcomes is wide."

**Worked example — starting ten years late.** Two friends each invest $500 a month at 7%. Ana starts at 25 and stops contributing at 35, having put in $60,000, then lets it grow untouched until 65. Ben starts at 35 and contributes $500 a month all the way to 65, putting in $180,000 — three times as much. At 65, Ana's account is worth roughly $600,000 and Ben's is worth roughly $610,000 — nearly the same, despite Ben contributing three times more. Early money has more time to compound. This is not a trick; it is arithmetic. It is also the strongest argument for starting now, even with a small amount.

## 1.4 What investing is NOT

- **It is not gambling.** Gambling is a zero-sum bet with a built-in house edge and no productive asset underneath. Investing in a diversified portfolio is buying ownership in businesses that create value.
- **It is not day trading.** Buying and selling stocks in minutes or hours, trying to predict short-term price moves, is a full-time job with a poor track record for amateurs. This course does not teach it, and you do not need it.
- **It is not a get-rich-quick scheme.** Anyone promising guaranteed returns, doubling your money in weeks, or risk-free profits is selling you something. Walk away.
- **It is not picking the next big stock.** You do not need to find the next great company before anyone else. Owning the whole market through index funds is a legitimate, historically effective strategy.
- **It is not something you do once and forget forever.** It is something you set up carefully, automate, and check occasionally — a few hours a year, not a few hours a day.

## 1.5 The three fears that keep beginners on the sideline

**Fear 1: "I will lose all my money."** If you invest in a single company, you can lose a great deal. If you invest in a broadly diversified fund holding thousands of companies across many countries, losing everything would require the collapse of the global economy — in which case your bank balance would not save you either. Diversification does not eliminate losses, but it makes total loss extraordinarily unlikely. Short-term drops of 10%, 20%, even 30% are normal and have happened many times; long-term investors who stayed invested have historically recovered. We will study downturns in detail in Module 9.

**Fear 2: "I do not know enough."** You do not need a finance degree. You need about ten concepts, and this course covers all of them. The financial industry profits from making investing look complicated. It is not.

**Fear 3: "I do not have enough money."** Many brokerages now let you start with $0 minimum and buy fractional shares — slices of a fund for as little as $1 or $5. Starting with $50 a month is a real start. The habit matters more than the amount.

## 1.6 The investor's mindset

Successful beginner investors share three habits: they automate contributions so willpower is not required; they diversify so no single failure ruins them; and they leave the money alone for years. That is the entire playbook. The rest of this course is the detail that makes those three habits work.

### Action Steps — Module 1

1. Write down, in one sentence, why you want to invest. Tape it somewhere you will see it when markets fall.
2. Calculate your own compounding example: pick a monthly amount you could realistically contribute and use the formula above, or use any free compound-interest calculator, with 7% and your own time horizon.
3. Check your savings account interest rate and compare it with the current inflation rate. Write both numbers down.
4. List every place your money currently sits (checking, savings, cash, retirement account at work). You will need this list in Module 2.

---

# Module 2 — The Accounts: Brokerage, Roth IRA, Traditional IRA, 401(k), HSA

## 2.1 An account is a container, not an investment

This confuses almost every beginner, so let us be precise: an **account** is where your money lives; an **investment** is what your money buys inside that account. Opening a Roth IRA does not invest your money. Depositing cash into a brokerage account does not invest it. You must take a second step — buying a fund — for the money to be invested. Many people open an account, deposit money, and leave it sitting in cash for years, wondering why nothing grows. Do not be one of them. Module 8 walks through the buying step.

Accounts matter because the tax rules differ. The same investment can produce very different after-tax results depending on which container holds it. Think of accounts as buckets with different tax labels.

## 2.2 The five accounts, in plain English

### Brokerage account (taxable account)

The flexible, no-special-rules account. You open it at a brokerage firm, deposit money, buy investments, and sell them whenever you like. There are no contribution limits and no age restrictions on withdrawals. The trade-off: you pay tax each year on dividends and interest you receive, and you pay capital-gains tax when you sell an investment for a profit. It is the right home for money you may need before retirement, and for investing after you have used your tax-advantaged accounts.

**Use it when:** you have filled your retirement accounts, or you are saving for a goal less than five years away that still belongs in investments (rare — see Module 4), or you simply want maximum flexibility.

### Roth IRA

An individual retirement account you open yourself. You contribute money you have already paid tax on (after-tax dollars). The money then grows tax-free, and withdrawals in retirement are tax-free, provided you follow the rules (generally age 59½ and the account open at least five years). Contributions (not earnings) can generally be withdrawn at any time without tax or penalty, though you should treat this as an emergency backstop, not a feature to use casually. There are annual contribution limits and income limits set by the IRS, which change from time to time — check the current year's limits before contributing. You need earned income to contribute.

**Use it when:** you are young, your tax rate is relatively low now, and you expect it to be higher later; or you want tax-free growth and tax-free withdrawals in retirement. For many first-time investors aged 25–40, the Roth IRA is the single best first account.

### Traditional IRA

Also an account you open yourself. Contributions may be tax-deductible now, depending on your income and whether you have a workplace plan. The money grows tax-deferred — you pay no tax year to year — and you pay ordinary income tax when you withdraw it in retirement. Withdrawals before age 59½ generally trigger income tax plus a 10% early-withdrawal penalty, with limited exceptions.

**Use it when:** you expect your tax rate to be lower in retirement than it is now, or you want a tax deduction this year and do not have access to a workplace plan. If your employer offers a 401(k), compare the two before choosing.

### 401(k) (and 403(b) / similar workplace plans)

A retirement account offered through your employer. Contributions come out of your paycheck before tax (traditional 401(k)) or after tax (Roth 401(k), if offered). The money grows tax-deferred (or tax-free in the Roth version). The killer feature is the **employer match**: many employers match part of your contributions — for example, 50 cents for every dollar you contribute up to 6% of your salary. That match is free money. It is the only guaranteed return in investing.

**Use it when:** your employer offers a match — contribute at least enough to get the full match before investing anywhere else. That is the first rule of this course, with almost no exceptions.

### HSA — Health Savings Account

Available only if you have a high-deductible health plan. Contributions are tax-deductible, growth is tax-free, and withdrawals for qualified medical expenses are tax-free — the only account with all three tax benefits. After age 65, you can withdraw for non-medical expenses and pay ordinary income tax, like a traditional IRA. If your health plan qualifies, an HSA is a remarkably powerful account, and it can double as a stealth retirement account.

**Use it when:** you have a qualifying high-deductible health plan and can afford to pay small medical bills out of pocket while letting the HSA grow.

## 2.3 The order of operations

For most first-time investors with a job, the sensible order is:

1. **Build a small emergency cushion first** — at least $1,000, ideally one month of expenses — in a high-yield savings account. Investing before you have any cushion means the next car repair forces you to sell investments at the worst time.
2. **Contribute to your 401(k) up to the full employer match.** Free money first.
3. **Pay off high-interest debt** (credit cards, payday loans — generally anything above about 8–10% interest). Paying off a 22% credit card is a guaranteed 22% return.
4. **Open and fund a Roth IRA** (or traditional IRA, if that fits better) up to the annual limit, or as much as you can afford.
5. **Return to the 401(k)** and increase contributions beyond the match.
6. **Open a taxable brokerage account** for anything left over.

Your exact order may differ — a person with no employer plan skips step 2; a person with no high-interest debt skips step 3 — but the logic is the same: free money, then expensive debt, then tax-advantaged accounts, then taxable accounts.

**Worked example — the match.** Maya earns $60,000 a year. Her employer matches 100% of the first 3% she contributes and 50% of the next 2%. If Maya contributes 5% ($3,000 a year), her employer adds 3% + 1% = 4%, or $2,400. Maya puts in $3,000; $5,400 lands in her account. That is an instant 80% return before any investment growth. No fund, stock, or strategy in this course beats that. If you are leaving a match on the table, fix that this week.

## 2.4 What to look for in a provider

Choose a large, established brokerage with no account minimums, no commissions on the funds you plan to buy, a wide selection of low-cost index funds, and a usable app or website. Avoid providers that charge account fees, push you toward expensive managed products, or make it hard to see what you own. You do not need a financial adviser to open any of these accounts, and you should not pay someone a percentage of your assets to do what this course teaches you to do yourself — unless you genuinely want ongoing personal advice, in which case look for a fee-only fiduciary adviser and understand exactly what you are paying.

## 2.5 Common beginner mistakes with accounts

- Opening an account and never investing the cash inside it.
- Contributing to a 401(k) but leaving the money in the default money-market fund for years.
- Choosing a traditional IRA for the deduction when a Roth would serve a young, low-tax investor better — or the reverse. The choice depends on your tax rate now versus later, and it is worth an hour of thought (or a conversation with a tax professional).
- Forgetting beneficiary designations. Every retirement account lets you name who receives it if you die. Fill this in when you open the account.

### Action Steps — Module 2

1. Find out whether your employer offers a 401(k) and a match. Write down the match formula and whether you are getting the full match today.
2. Check your current emergency savings. Is it at least $1,000? One month of expenses?
3. Decide your account order using the six-step list above. Write it down.
4. If you do not have a Roth IRA and one fits your situation, open one this week — opening takes about 15 minutes and usually requires your Social Security number, date of birth, address, employment information, and bank details.

---

# Module 3 — Stocks, Bonds, Index Funds, and ETFs in Plain English

## 3.1 Stocks: owning a slice of a business

A **stock** (also called a share or equity) is a unit of ownership in a company. If a company has one million shares and you own one thousand, you own 0.1% of that company. As an owner, you benefit when the company earns profits and grows, and you suffer when it does not. Stockholders may receive **dividends** — cash payments from company profits — but most of a stock's long-run return comes from the share price rising as the company grows.

Stocks are volatile. A single company's share price can fall 50% in a year. That is why beginners should not build a portfolio of five individual stocks and hope. The return of the overall stock market over long periods has historically averaged roughly 7–10% a year before inflation (about 7% after inflation is a common planning assumption), but that average hides enormous year-to-year variation. In some years the market falls 30%; in others it rises 30%. The long-run average is the reward for enduring the short-run swings.

## 3.2 Bonds: lending money and collecting interest

A **bond** is a loan. When you buy a bond, you lend money to a government or a company. In exchange, the borrower pays you interest (called the **coupon**) and returns your principal at maturity. Bonds are generally less volatile than stocks and pay steadier income, but their long-run returns are lower. A bond fund holding many bonds smooths out the risk that any single borrower fails to repay — that is **credit risk**.

The main risks of bonds are interest-rate risk (when rates rise, existing bonds with lower rates fall in value) and inflation risk (fixed interest payments buy less over time). Bonds are not risk-free; they are lower-risk. In a portfolio, bonds act as ballast: they tend to fall less than stocks in a crash, which makes the whole portfolio easier to hold.

## 3.3 Index funds: owning the whole haystack

An **index** is a list of securities that represents a market — for example, the S&P 500 (about 500 large U.S. companies) or a total U.S. stock market index (roughly 3,500 companies). An **index fund** is a fund that buys all (or a representative sample) of the securities in an index and holds them. You are not betting on one company; you are buying the market itself.

Why does this matter? Because decades of evidence show that most professional fund managers — people paid very well to pick stocks — fail to beat a simple index fund after fees over long periods. If the professionals usually lose to the index, a beginner's best move is to buy the index and keep the fees low. Index funds are also diversified by construction and require no stock-picking skill.

## 3.4 ETFs vs. mutual funds: two wrappers, same idea

An **ETF** (exchange-traded fund) and an **index mutual fund** can hold exactly the same investments. The difference is how you buy and sell them:

- **Mutual funds** are bought and sold once a day, at the end-of-day price. You can invest any dollar amount, and you can set up automatic investments easily.
- **ETFs** trade on an exchange during the day, like stocks, at prices that move minute by minute. You buy whole shares (or fractional shares at many brokerages now), and you must place an order during market hours.

For a long-term beginner, the difference is minor. Choose whichever your brokerage makes easiest to buy automatically. A total U.S. stock market index fund, whether as a mutual fund or an ETF, is the same investment in different packaging.

## 3.5 The other things you will hear about

- **Target-date funds:** a single fund that holds a mix of stocks and bonds and gradually becomes more conservative as a chosen retirement year approaches. An excellent one-fund option for a beginner who wants to set it and forget it.
- **Money market funds:** funds that hold very short-term, very safe debt. They pay interest similar to a savings account. Useful as a parking place for cash inside an account — not as a long-term investment.
- **REITs (real estate investment trusts):** companies that own income-producing real estate. A total-market index fund already includes REITs; you do not need a separate one to start.
- **Cryptocurrency, commodities, options, leveraged funds:** volatile, specialized, or complex. Not part of a beginner foundation portfolio. Learn the basics first; revisit these only if you have a clear reason and can afford to lose the money.

## 3.6 How returns are actually made

A diversified stock fund earns returns in two ways: companies pay dividends, and companies grow in value. Over the long run, dividends have contributed a meaningful share of total return. That is why you should always choose **total return** — price growth plus dividends reinvested — rather than chasing only dividends or only price growth. Reinvesting dividends (buying more shares with the cash dividends pay) is a powerful compounding habit; turn on dividend reinvestment (DRIP) in your account settings.

### Action Steps — Module 3

1. In your own words, write one sentence explaining what a stock is, what a bond is, and what an index fund is. If you cannot explain it simply, re-read the section.
2. Look up the holdings of a total U.S. stock market index fund. Write down how many companies it holds and its expense ratio (see Module 6).
3. Decide whether you prefer mutual funds or ETFs at your brokerage, based on which is easier to automate there.
4. Turn on dividend reinvestment in any account you already own.

---

# Module 4 — Diversification and Asset Allocation

## 4.1 Diversification: don't bet the farm on one thing

**Diversification** means spreading your money across many different investments so that the failure of any one of them does not sink you. It is the only free lunch in investing: you can reduce risk without necessarily giving up expected return.

Consider two investors. Ana puts $10,000 into a single company. Ben puts $10,000 into a fund holding 3,500 companies. If Ana's company goes bankrupt, she loses everything. If one of Ben's 3,500 companies goes bankrupt, he loses about 0.03% of his portfolio. Both invested in stocks; only one was diversified. The same logic applies across countries, industries, and asset types.

Diversification has limits. In a broad market crash, most stocks fall together — diversification does not prevent that. What it prevents is a single bad pick destroying you. That distinction matters, and it is why Module 9 spends time on surviving crashes rather than avoiding them.

## 4.2 Asset allocation: the decision that matters most

**Asset allocation** is how you divide your portfolio between broad categories — mainly stocks and bonds, and within stocks, U.S. and international. Research consistently finds that asset allocation explains far more of a portfolio's long-run outcome than which specific funds you pick or when you buy them. Get the allocation roughly right and the fund choice is a detail. Get it wrong — for example, holding 100% cash for thirty years, or 100% in a single stock — and no fund choice will save you.

The core trade-off is simple: stocks offer higher expected long-run returns with higher volatility; bonds offer lower expected returns with lower volatility. Your allocation is a dial between growth and stability, and the right setting depends on your time horizon and your ability to stay invested during drops.

## 4.3 Three starting allocations

These are illustrations, not personal recommendations. Your allocation should reflect your own horizon, risk tolerance (Module 5), and circumstances.

| Investor | Stocks | Bonds | When it fits |
|---|---|---|---|
| Aggressive (long horizon, 20+ years) | 90% | 10% | Young investor, retirement decades away, comfortable with large swings |
| Moderate (medium horizon, 10–20 years) | 70% | 30% | Mid-career, wants growth with some cushion |
| Conservative (short horizon, under 10 years) | 50% | 50% | Nearing a goal, or low tolerance for drops |

A common rule of thumb is "110 minus your age in stocks" — a 30-year-old would hold about 80% stocks. Rules of thumb are starting points, not answers. Use the risk-tolerance worksheet in this course to refine yours.

## 4.4 Within stocks: U.S. vs. international

The U.S. stock market is the largest in the world, but it is not the only one. International stocks — companies based in Europe, Japan, emerging markets, and elsewhere — sometimes outperform U.S. stocks for years at a time, and sometimes underperform. Holding both means you are never entirely wrong. A common beginner split is 60–70% U.S. stocks and 30–40% international stocks within the stock portion of the portfolio. Some investors hold only U.S. stocks; that is a defensible choice, but it is a bet that the U.S. will outperform forever, and history does not guarantee that.

## 4.5 Within bonds: keep it simple

For a beginner, a single broad, high-quality bond fund — one holding U.S. government and investment-grade corporate bonds — is enough. Avoid long-term bond funds if you need the money soon (they swing more when rates change), and avoid high-yield ("junk") bond funds as a core holding (they behave more like stocks in a crisis, which defeats the purpose of bonds as ballast).

## 4.6 What diversification does NOT mean

- It does not mean owning twenty funds that all hold the same stocks. Overlap is not diversification.
- It does not mean owning a little of everything exotic. Complexity is not diversification.
- It does not mean you will never lose money. It means your losses will be the market's losses, not one company's catastrophe.

A three-fund portfolio — total U.S. stocks, total international stocks, total bonds — is diversified across thousands of securities, two broad regions, and two asset classes. That is a complete foundation. You can add complexity later if you have a reason; you do not need it to start.

### Action Steps — Module 4

1. Choose a draft allocation for yourself (for example, 80% stocks / 20% bonds, with stocks split 70% U.S. / 30% international). Write it down with your reasoning.
2. Complete the risk-tolerance worksheet and compare its result with your draft allocation. Adjust if they disagree sharply.
3. Count how many individual securities your draft portfolio would hold (a total-market fund holds thousands). Write the number down — it makes diversification concrete.
4. If you already own investments, list them and check for overlap: are three of your funds all holding the same top ten companies?

---

# Module 5 — Risk: What It Really Is, How Much You Can Take, and How to Measure It

## 5.1 Risk is not one thing

Beginners usually mean one thing by "risk": losing money. Professionals mean several things, and each needs a different response:

- **Volatility risk:** prices bouncing up and down. Uncomfortable, but temporary for a diversified portfolio. The cure is time and temperament.
- **Permanent-loss risk:** a company going bankrupt, or an investment becoming worthless. The cure is diversification.
- **Inflation risk:** your money losing buying power. The cure is owning productive assets (stocks) rather than holding only cash.
- **Longevity risk:** outliving your money in retirement. The cure is saving enough and investing for growth over decades.
- **Behavioral risk:** you, selling at the bottom. The cure is automation, a written plan, and the habits in Module 9.

Notice that the risks pull in opposite directions. Avoiding volatility by holding only cash increases inflation risk and longevity risk. There is no risk-free option — only a choice of which risks to accept. A thoughtful investor chooses the risks that are compensated (stocks pay you for enduring volatility) and avoids the risks that are not (a single stock can wipe you out for no extra reward).

## 5.2 Risk tolerance vs. risk capacity

**Risk tolerance** is emotional: how you feel when your portfolio falls 20%. **Risk capacity** is financial: how much loss you can afford given your time horizon, income, debts, and goals. They are different, and they often disagree. A 28-year-old with a stable job and no debts has high capacity — she has forty years to recover — but may have low tolerance if she panics and sells. A 55-year-old nearing retirement may have high tolerance ("I can handle the swings") but low capacity (she needs the money in five years).

Your allocation should respect the *lower* of the two. An allocation you cannot hold through a crash is worse than a more conservative allocation you can hold, because the plan you abandon at the bottom is the plan that locks in the loss.

## 5.3 How much can you take? A concrete test

Imagine you invest $10,000. Over the next year, the market falls and your account shows $8,000 — a 20% drop. What do you do?

- (a) Sell everything and move to cash.
- (b) Sell some and wait.
- (c) Do nothing.
- (d) Buy more while prices are low.

There is no "correct" answer to a feelings question, but your honest answer is diagnostic. If (a) is your true answer, a stock-heavy portfolio will hurt you, and you should hold more bonds — or use a target-date fund that manages the mix for you. If (d) is your answer, you may be able to hold a higher stock allocation — but be honest with yourself: many people choose (d) on a questionnaire and (a) in a real crash. Past behavior is the best predictor: if you sold investments in a past downturn, weight that heavily.

Complete the risk-tolerance worksheet in the templates folder. It scores your answers and suggests a starting stock/bond range. Treat the result as a starting point for thought, not a prescription.

## 5.4 Measuring risk: two numbers worth knowing

- **Standard deviation** measures how much returns bounce around their average. A fund with a 15% standard deviation will, in a typical year, land within roughly ±15% of its average return about two-thirds of the time. Higher standard deviation means a bumpier ride.
- **Maximum drawdown** is the largest peak-to-trough fall a fund or market has experienced. The U.S. stock market has fallen more than 50% from peak to trough in major crashes (for example, 2007–2009 and, briefly, in early 2020 it fell about 34% in a month). Knowing this before you invest is essential: if you cannot imagine holding through a 30–50% fall, your allocation is too aggressive.

Neither number predicts the future. Both describe the past and calibrate your expectations.

## 5.5 Time horizon is your superpower

Risk shrinks with time — not because stocks become safe, but because you have more years for good years to offset bad ones, and because you are adding contributions along the way. Money you need next year should not be in stocks. Money you need in thirty years can afford to ride out several crashes. That is why the same person should hold different allocations for different goals: retirement money (long horizon) can be stock-heavy; a house deposit needed in two years (short horizon) belongs in a savings account or short-term bond fund.

A practical rule: money needed within five years should not be in the stock market. Money needed in five to ten years can be in a balanced mix. Money needed in ten-plus years can be mostly stocks, if your tolerance allows.

### Action Steps — Module 5

1. Complete the risk-tolerance worksheet and record your score and suggested allocation.
2. Write down, in advance, what you will do if your portfolio falls 20%, 30%, and 50%. This is your pre-commitment. Sign and date it.
3. Identify your time horizon for each goal (retirement, house, education) and note which horizon each pot of money belongs to.
4. Look up the maximum drawdown of a total U.S. stock market index fund over the last twenty years. Write the number down and sit with it.

---

# Module 6 — Fees, Taxes, and the Costs That Quietly Eat Returns

## 6.1 The expense ratio: the fee you pay every year

Every fund charges an annual fee called the **expense ratio**, expressed as a percentage of your investment. A 0.03% expense ratio costs you $3 a year for every $10,000 invested. A 0.75% expense ratio costs $75 a year for every $10,000. The fee is deducted automatically from the fund's returns — you never see a bill, which is exactly why it is dangerous. It is small, silent, and relentless.

Over one year, the difference between 0.03% and 0.75% looks trivial. Over twenty years, it is not.

**Worked example — expense ratios over 20 years (lump sum).**

Assumptions: $10,000 invested once, gross return 7% a year before fees, no further contributions, no taxes. The net return is 7% minus the expense ratio.

- At 0.03%: net return 6.97%. $10,000 × (1.0697)^20 = **$38,480.43**.
- At 0.75%: net return 6.25%. $10,000 × (1.0625)^20 = **$33,618.53**.
- Difference: **$4,861.90** — nearly half your original investment, lost to a fee difference of 0.72 percentage points.

**Worked example — the same fee gap with monthly contributions.**

Assumptions: $500 a month for 20 years (240 months), gross return 7% a year, no taxes.

- At 0.03%: **$259,516.65**.
- At 0.75%: **$237,987.73**.
- Difference: **$21,528.92**.

That is a car's worth of money, surrendered to a fee you could have avoided by choosing a low-cost index fund. This is the single most controllable factor in your investment outcome. You cannot control what the market returns. You can control what you pay.

## 6.2 Other fees to watch

- **Advisory fees:** some advisers charge 1% of your assets every year. On a $100,000 portfolio, that is $1,000 a year, every year, compounding against you. Over thirty years, a 1% annual fee can consume roughly a quarter of your potential wealth. If you hire an adviser, understand exactly what you pay and what you get.
- **Trading commissions:** most major brokerages now charge $0 commission on stock and ETF trades. If yours still charges, switch.
- **Loads:** some mutual funds charge a front-end or back-end sales load (a commission for buying or selling). There is no reason for a beginner to ever pay a load.
- **Account fees and inactivity fees:** avoid brokerages that charge them.
- **Expense ratios inside target-date funds and funds-of-funds:** check the total cost, not just the headline. A target-date fund at 0.08% is fine; one at 0.75% is not.

A good rule: if a fund's expense ratio is above 0.20% and it is not doing something genuinely specialized, ask why. For broad index funds, 0.03–0.10% is normal and achievable.

## 6.3 Taxes: the basics a beginner must know

This section is education, not tax advice. Tax law changes, and your situation is specific — consult a qualified tax professional for decisions that affect you.

- **In a 401(k) or traditional IRA,** you generally pay no tax year to year. You pay ordinary income tax when you withdraw in retirement.
- **In a Roth IRA or Roth 401(k),** qualified withdrawals in retirement are tax-free.
- **In a taxable brokerage account,** you pay tax each year on dividends and interest, and you pay capital-gains tax when you sell an investment for more than you paid. Gains on investments held longer than a year are generally taxed at lower long-term capital-gains rates than gains on investments held a year or less, which are taxed as ordinary income. That is one reason frequent trading is costly: it converts long-term gains into short-term gains.
- **Tax-loss harvesting** (selling a losing investment to offset gains) is a real technique, but it is an optimization, not a foundation. Get the foundation right first.
- **Asset location** means placing tax-inefficient investments (bonds, which pay taxable interest) inside tax-advantaged accounts and tax-efficient investments (broad stock index funds) in taxable accounts, where possible. Again, an optimization — useful, but secondary to saving and allocating well.

The most important tax move a beginner can make is not a clever trick. It is using the right account (Module 2) and holding investments for the long term.

## 6.4 The cost of doing nothing, revisited

Fees and taxes are visible costs. Inaction is the invisible one. Every year you delay investing $500 a month at 7%, you lose not just that year's $6,000 in contributions but all the compounding those contributions would have earned. Delaying ten years — from age 25 to 35 — roughly halves the final balance at 65, as the Module 1 example showed. The cost of waiting for the "perfect" time is the largest fee most beginners will ever pay.

### Action Steps — Module 6

1. List every fund you own (or plan to buy) with its expense ratio. Total the weighted cost using the fee-comparison worksheet.
2. If any broad fund you own charges more than 0.20%, find a lower-cost equivalent and note the switch you would make.
3. Check whether your adviser, if you have one, charges a percentage fee. Write down the annual dollar cost on your current balance.
4. Confirm you understand the tax treatment of each account you own. If you do not, note the question to ask a tax professional.

---

# Module 7 — Building Your First Portfolio Step by Step

## 7.1 The three-fund portfolio

The simplest complete portfolio a beginner can own has three parts:

1. **Total U.S. stock market index fund** — thousands of U.S. companies.
2. **Total international stock index fund** — thousands of companies outside the U.S.
3. **Total U.S. bond market index fund** — government and investment-grade corporate bonds.

That is it. Three funds, thousands of securities, two regions, two asset classes. You can build a lifetime portfolio on this foundation. Some investors use a single target-date fund instead, which is the same idea in one fund — the fund manager handles the mix and adjusts it over time. Both are legitimate. Choose the one you will actually maintain.

## 7.2 Worked example — a $10,000 starter portfolio

Meet Jordan, 29, who has an emergency fund, no high-interest debt, and $10,000 to invest in a Roth IRA. Jordan's risk-tolerance worksheet suggests a moderately aggressive allocation: 80% stocks, 20% bonds. Within stocks, Jordan chooses 70% U.S. and 30% international.

The math:

| Holding | Allocation | Dollar amount | Role |
|---|---|---|---|
| Total U.S. stock index fund | 56% (80% × 70%) | $5,600 | Growth engine — U.S. companies |
| Total international stock index fund | 24% (80% × 30%) | $2,400 | Growth engine — diversification beyond the U.S. |
| Total bond market index fund | 20% | $2,000 | Ballast — steadies the portfolio in downturns |
| **Total** | **100%** | **$10,000** | |

**The reasoning, in Jordan's words:** "Most of my money is in stocks because I will not touch it for thirty-plus years and I can handle the swings. Most of my stocks are American because that is the market I know best, but almost a quarter is international because I do not want to bet everything on one country. The bonds are there so that when stocks fall 30%, my portfolio falls less, and I am less likely to panic."

**What Jordan does next:** Jordan sets up an automatic $500 monthly contribution split in the same proportions ($280 U.S. stocks, $120 international, $100 bonds), turns on dividend reinvestment, and sets a calendar reminder to rebalance once a year (Module 9). Jordan does not check the balance daily.

**A second example — a more cautious investor.** Sam, 38, has a shorter horizon and lower tolerance. Sam chooses 60% stocks / 40% bonds, with stocks split 70% U.S. / 30% international, on the same $10,000: $4,200 U.S. stocks, $1,800 international stocks, $4,000 bonds. Sam accepts lower expected growth in exchange for a calmer ride. Neither Jordan nor Sam is "right" — each matches a portfolio to a person.

**A third option — the one-fund portfolio.** If even three funds feel like too much, a target-date fund matching your expected retirement year (for example, a 2060 fund for a 30-year-old) holds a similar mix in a single fund and adjusts it automatically. The trade-off is a slightly higher expense ratio and less control over the exact mix. For many beginners, that trade is worth it.

## 7.3 How much to invest?

A common starting target is 15% of gross income toward retirement, including any employer match — a widely cited guideline, not a law. If 15% is impossible today, start with what you can: 5% is far better than 0%, and you can raise it by 1% each year or with each pay rise. The habit and the automation matter more than hitting a magic percentage in month one.

**Worked example:** Jordan earns $60,000 a year. Fifteen percent is $9,000 a year, or $750 a month. Jordan starts at $500 a month and adds $50 a month each year. Within five years Jordan is at $750 a month without ever feeling a sudden squeeze. Gradual increases beat heroic starts that collapse.

## 7.4 Where to hold what

As a starting guide: hold your bond fund inside a tax-advantaged account (IRA or 401(k)) where its interest is sheltered, and hold broad stock index funds wherever they fit. If you only have one account, do not worry about this yet — hold all three funds in that account. Asset location is an optimization for later, not a barrier to starting.

## 7.5 What NOT to put in your first portfolio

- Individual stocks you picked because of a tip, a headline, or a friend.
- Sector funds, country funds, or thematic funds (artificial intelligence, cannabis, space) as core holdings.
- Leveraged or inverse funds, which are designed for day trading, not holding.
- Anything you cannot explain in one sentence to a friend.

If you want to experiment with individual stocks later, limit it to a small "fun money" slice — say 5% of your portfolio — that you can afford to lose, and keep the foundation intact.

### Action Steps — Module 7

1. Using the portfolio-builder worksheet, build your own $10,000 starter portfolio (or use your real starting amount). Write the fund names, tickers, percentages, and dollar amounts.
2. Enter your portfolio into `templates/portfolio-builder.csv` and check that the allocations add to 100% and the weighted expense ratio is under 0.20%.
3. Decide: three-fund portfolio or a single target-date fund? Write your choice and why.
4. Set your monthly contribution amount and the date it will start. Automate it.

---

# Module 8 — How to Buy Your First Fund: A Walkthrough

## 8.1 Before you click buy

Confirm three things: (1) your account is open and funded — the money has arrived and is showing as cash available to trade (bank transfers usually take 1–3 business days); (2) you know the exact fund you want, including its ticker symbol and expense ratio; (3) you know how much you are buying and in what account. If any of those is unclear, stop and re-read Modules 2, 3, and 7.

## 8.2 Buying a mutual fund — step by step

1. Log in to your brokerage account.
2. Go to Trade or Buy.
3. Enter the fund's ticker symbol or name. Confirm it is the right fund — check the full name and expense ratio, not just the ticker.
4. Choose "Buy" and enter the dollar amount (for example, $5,600 for the U.S. stock fund in Jordan's example).
5. Choose the order type. For a mutual fund, you buy at the end-of-day price; there is usually no choice to make.
6. Select the account (Roth IRA, brokerage, and so on) if you have more than one.
7. Review the order summary carefully: fund name, amount, account. Confirm.
8. You will receive a confirmation. The purchase settles at that day's closing price.

## 8.3 Buying an ETF — step by step

1. Log in and go to Trade or Buy.
2. Enter the ETF ticker. Confirm the full name and expense ratio.
3. Choose "Buy" and enter the number of shares or the dollar amount (many brokerages now allow dollar-based ETF purchases and fractional shares).
4. Choose the order type. For a beginner, a **market order** (buy at the current price) during market hours is simplest. A **limit order** (buy only at or below a price you set) gives you price control but may not execute if the price moves away. Do not use complex order types you do not understand.
5. Choose "Day" as the time in force (the order expires at the end of the trading day if it does not fill).
6. Review and confirm. Check the confirmation and your holdings.

**Practical tips:** trade during regular market hours, avoid the first and last fifteen minutes of the trading day when prices can be jumpy, and do not watch the price tick by tick. You are buying for decades, not for today.

## 8.4 Automating everything

After your first manual purchase, set up the automation that will do the real work:

- **Automatic contributions:** a recurring transfer from your bank account or paycheck into your investment account on payday.
- **Automatic investments:** a recurring instruction to invest that cash into your chosen funds in your chosen proportions.
- **Dividend reinvestment:** dividends automatically buy more shares instead of sitting as cash.
- **Annual increase:** if your brokerage or employer plan allows it, raise your contribution by 1% each year, or set a calendar reminder to do it yourself.

Automation is the single most effective behavioral tool in this course. It removes willpower, timing, and emotion from the process. The best portfolio is the one that keeps getting funded while you live your life.

## 8.5 What to do if something goes wrong

- **Order did not execute:** check whether the market was open, whether your cash had settled, and whether you entered the correct ticker. Call the brokerage's support line — that is what it is for.
- **You bought the wrong fund:** most brokerages let you sell and re-buy, but selling in a taxable account can trigger tax. In a retirement account, correcting a mistake is usually tax-free. Do not panic; fix it methodically and note the lesson.
- **The price fell the day after you bought:** normal. It will happen many times. It does not mean you made a mistake. See Module 9.

### Action Steps — Module 8

1. Fund your account and confirm the cash is available to trade.
2. Place your first buy using the steps above. Start with one fund if buying three at once feels overwhelming — you can add the others the same week.
3. Turn on dividend reinvestment and set up automatic contributions and automatic investments.
4. Save or screenshot your trade confirmations and file them with your records.

---

# Module 9 — Staying the Course: Rebalancing, Downturns, and Behavior

## 9.1 Rebalancing: keeping your portfolio on target

Over time, your investments grow at different rates, and your allocation drifts. Suppose you start at 80% stocks / 20% bonds. After a strong year for stocks, you might be at 86% stocks / 14% bonds — more risk than you chose. **Rebalancing** means selling some of what has grown and buying some of what has lagged, to return to your target.

Rebalancing feels wrong — you are selling winners and buying losers — but it is disciplined risk management. It forces you to sell high and buy low, in small, regular doses, without trying to predict anything.

**Worked example.** Jordan's $10,000 portfolio (80/20) grows to $12,000 after a year: stocks are now $10,320 (86%) and bonds are $1,680 (14%). To rebalance to 80/20, Jordan needs stocks at $9,600 and bonds at $2,400. Jordan sells $720 of stock funds and buys $720 of bond funds. In a retirement account, this is generally not a taxable event. In a taxable account, selling can trigger capital-gains tax, so many investors rebalance in taxable accounts by directing *new contributions* to the underweight asset instead of selling — the same result, without the tax bill.

**How often?** Once a year, or when any asset class drifts more than 5 percentage points from target — whichever you prefer. More often than that adds work and taxes for no benefit. Set a calendar reminder and do it on the same date every year.

## 9.2 Downturns: what actually happens

Stock markets fall. This is not a flaw; it is the price of the long-run return. Here is what history shows, in broad terms:

- **Corrections** (a fall of 10% or more) happen frequently — roughly once a year on average in the U.S. market.
- **Bear markets** (a fall of 20% or more) happen every few years.
- **Crashes** (a fall of 30–50%) happen roughly once a decade.

Each time, the headlines declare that this time is different and the market will never recover. Each time so far, diversified markets have eventually recovered and gone on to new highs — but "eventually" can mean months or years, and there is no guarantee about the future. That uncertainty is real, and you should sit with it before investing money you cannot afford to leave alone.

What should you do during a downturn? If your time horizon is long and your allocation matches your tolerance: **nothing, except keep contributing.** Your automatic monthly contribution now buys more shares at lower prices — the same fund, on sale. This is dollar-cost averaging working in your favor, and it is the reason long-term investors can benefit from downturns even while they dislike them.

What should you *not* do? Sell everything and move to cash "until things settle." That locks in the loss and requires you to guess correctly twice — when to get out and when to get back in. Study after study finds that investors who try to time the market underperform those who stay invested, because the market's best days often cluster near its worst days, and missing just a handful of the best days over decades can cut your final balance dramatically.

## 9.3 The behavior gap

The "behavior gap" is the difference between what an investment returns and what the average investor in that investment actually earns, because investors buy after rises and sell after falls. The gap is often several percentage points a year — larger than any fee. Closing it does not require intelligence. It requires a plan, automation, and the willingness to do nothing when doing something feels urgent.

**Five rules for your worst day in the market:**

1. Do not open your brokerage app and sell. Wait 48 hours.
2. Re-read the one-sentence reason you wrote in Module 1.
3. Re-read your pre-commitment from Module 5.
4. Remind yourself of your time horizon: money you need in thirty years does not care about this month.
5. If you must act, direct your next contribution — do not sell what you own.

## 9.4 News, noise, and other people's portfolios

Financial news is designed to make you trade, because trading generates fees and clicks. Your plan is designed to make you wealthy slowly. Those goals conflict. Check your portfolio quarterly at most — annually is enough for many investors. Do not compare your diversified portfolio with a friend's single winning stock, a stranger's crypto gains, or a headline about a market record. You are running a different race, with a different finish line.

## 9.5 When to change your plan

A plan should change when *your life* changes — a new job, a marriage, a child, a house purchase, a health change, approaching retirement — not when the market changes. Review your allocation once a year, or after a major life event, and adjust the allocation to match the person you are now. That is rebalancing your life, not reacting to the news.

### Action Steps — Module 9

1. Put an annual rebalancing date on your calendar, with a reminder.
2. Write your downturn rules (the five rules above, in your own words) and keep them with your investment records.
3. Decide how often you will check your portfolio — quarterly or annually — and delete the brokerage app from your phone's home screen if daily checking is a temptation.
4. Tell one trusted person your plan, so someone else knows what you committed to.

---

# Module 10 — Your First 90 Days as an Investor: A Dated Action Plan

This module turns the course into a calendar. Day 1 is the day you finish this course. If you follow this plan, you will be a real investor — account open, portfolio bought, contributions automated — within 90 days.

## Days 1–7: Foundations

- **Day 1:** Re-read your one-sentence reason for investing (Module 1). Confirm your emergency cushion ($1,000 minimum, ideally one month of expenses) is in a savings account.
- **Day 2:** Check your employer's 401(k) match. If you are not getting the full match, log in and raise your contribution to the full-match level today.
- **Day 3:** List high-interest debts. If any debt charges more than about 8–10%, write a payoff plan before investing beyond the match.
- **Day 4:** Complete the risk-tolerance worksheet. Record your score and your draft allocation.
- **Day 5:** Choose your accounts in order (Module 2). If a Roth IRA fits, open one — about 15 minutes online.
- **Day 6:** Choose your portfolio: three-fund or target-date. Fill in the portfolio-builder worksheet with real fund names, tickers, percentages, and dollar amounts.
- **Day 7:** Review your plan with a clear head. Confirm the allocation matches your risk worksheet, the expense ratios are under 0.20%, and the monthly contribution is an amount you can sustain.

## Days 8–30: First purchase and automation

- **Day 8–10:** Transfer your starting amount into the account. Wait for the cash to settle (1–3 business days).
- **Day 11–14:** Place your first buy (Module 8). Buy all three funds, or start with the U.S. stock fund and add the others within the week.
- **Day 15:** Turn on dividend reinvestment.
- **Day 16:** Set up automatic monthly contributions from your bank account or paycheck, and automatic investments into your funds in your target proportions.
- **Day 17–21:** Name beneficiaries on every retirement account. File your trade confirmations and account details somewhere safe.
- **Day 22–30:** Leave it alone. Do not check the balance daily. Use this time to read the glossary terms you are least sure about and take the quiz bank at the end of this manual.

## Days 31–60: Verify and learn

- **Day 31:** Confirm your first automatic contribution went through and was invested (not sitting as cash).
- **Day 35:** Check that dividends, if any were paid, were reinvested.
- **Day 45:** Review your fee worksheet. Confirm the weighted expense ratio of your portfolio is what you expected.
- **Day 60:** First monthly review (15 minutes, no more). Confirm contributions, allocation, and automation are all working. Do not change the allocation because of one month of market movement.

## Days 61–90: Lock in the habit

- **Day 61–75:** If you received a pay rise or paid off a debt, raise your monthly contribution by at least 1% of your income.
- **Day 76–85:** Read one reputable source on investing — a book, not a social-media thread — to deepen what this course started. Suggestions from the public domain of common knowledge include the classic works on index investing and personal finance found in most libraries; choose one and finish it.
- **Day 90:** Full 90-day review. Answer these questions in writing: Did every contribution happen automatically? Is my allocation still on target? Did I panic, check obsessively, or change the plan — and why? What is my contribution amount for the next 90 days? Then set your next review date (quarterly) and your annual rebalancing date, and get on with your life.

## What success looks like after 90 days

You have an emergency cushion, you are capturing any employer match, your account is open, your portfolio is bought, your contributions are automatic, your dividends reinvest, and you have a written plan for downturns and rebalancing. You are not rich. You are not done. You are an investor — and the compounding clock, which rewards time more than timing, is now running in your favor.

### Action Steps — Module 10

1. Copy the 90-day plan into your calendar with dated reminders, starting today.
2. Complete the 90-day action tracker in the workbook as you go.
3. On Day 90, write your review and file it with this manual. Then repeat the quarterly review cycle.

---

# Glossary

1. **Asset allocation** — How a portfolio is divided among broad categories such as stocks, bonds, and cash.
2. **Asset class** — A broad category of investments with similar characteristics, such as stocks, bonds, or cash.
3. **Bear market** — A market decline of 20% or more from a recent peak.
4. **Beneficiary** — The person named to receive an account's assets if the account holder dies.
5. **Bond** — A loan made by an investor to a government or company, paying interest and returning principal at maturity.
6. **Brokerage account** — A taxable investment account with no contribution limits, opened at a brokerage firm.
7. **Bull market** — A sustained period of rising market prices.
8. **Capital gain** — The profit from selling an investment for more than its purchase price.
9. **Capital loss** — The loss from selling an investment for less than its purchase price.
10. **Compounding** — Earnings generating further earnings over time, so growth accelerates.
11. **Contribution limit** — The maximum amount the IRS allows you to contribute to a retirement account in a year.
12. **Correction** — A market decline of 10% or more from a recent peak.
13. **Coupon** — The interest payment a bond pays its holder.
14. **Credit risk** — The risk that a borrower fails to repay a bond.
15. **Diversification** — Spreading investments across many securities so no single failure dominates the outcome.
16. **Dividend** — A cash payment a company makes to its shareholders from its profits.
17. **Dividend reinvestment (DRIP)** — Automatically using dividends to buy more shares of the same investment.
18. **Dollar-cost averaging** — Investing a fixed amount at regular intervals, buying more shares when prices are low and fewer when prices are high.
19. **Drawdown** — The fall in value from a peak to a later low point.
20. **Emergency fund** — Cash set aside in a savings account for unexpected expenses, typically 3–6 months of expenses.
21. **Employer match** — Money an employer adds to an employee's 401(k) based on the employee's contributions.
22. **ETF (exchange-traded fund)** — A fund that holds a basket of securities and trades on an exchange during the day.
23. **Expense ratio** — A fund's annual fee, expressed as a percentage of assets.
24. **Fiduciary** — A person or firm legally and ethically required to act in a client's best interest.
25. **Fractional share** — A slice of a share smaller than one whole share, allowing small-dollar investing.
26. **HSA (Health Savings Account)** — A tax-advantaged account for medical expenses, available with a high-deductible health plan.
27. **Index** — A list of securities representing a market or segment, such as the S&P 500.
28. **Index fund** — A fund that tracks an index by holding its securities.
29. **Inflation** — The general rise in prices over time, which reduces the purchasing power of money.
30. **Interest-rate risk** — The risk that a bond's value falls when interest rates rise.
31. **IRA (Individual Retirement Account)** — A personal retirement account with tax advantages, in Roth or traditional form.
32. **Limit order** — An order to buy or sell only at a specified price or better.
33. **Liquidity** — How easily an investment can be bought or sold without affecting its price.
34. **Long-term capital gain** — A gain on an investment held longer than one year, generally taxed at lower rates.
35. **Market order** — An order to buy or sell immediately at the best available current price.
36. **Maturity** — The date when a bond's principal is repaid to the holder.
37. **Mutual fund** — A pooled fund, bought and sold once a day at the end-of-day price.
38. **Portfolio** — The complete set of investments a person owns.
39. **Principal** — The original amount invested, or the amount a bond repays at maturity.
40. **Rebalancing** — Buying and selling to return a portfolio to its target allocation.
41. **Risk capacity** — The financial ability to bear investment losses, based on horizon, income, and goals.
42. **Risk tolerance** — The emotional ability to endure investment losses without abandoning the plan.
43. **Roth IRA** — An IRA funded with after-tax money, with tax-free growth and qualified tax-free withdrawals in retirement.
44. **Short-term capital gain** — A gain on an investment held one year or less, generally taxed as ordinary income.
45. **Standard deviation** — A measure of how much investment returns vary around their average.
46. **Stock (share, equity)** — A unit of ownership in a company.
47. **Target-date fund** — A fund that holds a diversified mix and gradually becomes more conservative as a target retirement year approaches.
48. **Tax-advantaged account** — An account with special tax treatment, such as an IRA, 401(k), or HSA.
49. **Total return** — An investment's full return, including both price change and income such as dividends.
50. **Volatility** — The degree to which an investment's price moves up and down over time.
51. **401(k)** — An employer-sponsored retirement account, in traditional (pre-tax) or Roth (after-tax) form.

---

# Quiz Bank

Test yourself after each module, or take the whole quiz at the end. Answers follow the questions — cover them before you answer.

1. **What is inflation, and why does it matter to a saver who never invests?**
   *Answer: Inflation is the general rise in prices over time. Cash that earns less than inflation loses buying power — $10,000 held at 0% for 30 years at 3% inflation is worth only about $4,120 in today's purchasing power.*

2. **You invest $500 a month at an average 7% a year for 30 years. Roughly how much will you have, and how much of it did you contribute?**
   *Answer: About $609,986 in total. You contributed $180,000; growth contributed about $429,986. (Assumes smooth 7% returns, monthly compounding, no taxes or fees — a hypothetical illustration, not a guarantee.)*

3. **What is the difference between an account and an investment?**
   *Answer: An account (Roth IRA, brokerage) is the container that holds your money; an investment (a fund, a stock) is what your money buys inside it. Opening an account does not invest the money — you must buy something.*

4. **Your employer matches 100% of the first 3% you contribute to your 401(k). You earn $60,000. How much free money do you get by contributing 3%?**
   *Answer: 3% of $60,000 is $1,800 from you, plus $1,800 from your employer — $1,800 of free money.*

5. **Name one advantage of a Roth IRA and one advantage of a traditional IRA.**
   *Answer: Roth IRA — tax-free growth and qualified tax-free withdrawals in retirement. Traditional IRA — contributions may be tax-deductible now, reducing this year's taxable income.*

6. **What is a stock, in one sentence?**
   *Answer: A stock is a unit of ownership in a company.*

7. **What is a bond, in one sentence?**
   *Answer: A bond is a loan you make to a government or company, which pays you interest and returns your principal at maturity.*

8. **What is an index fund, and why do many beginners choose one?**
   *Answer: A fund that tracks a market index by holding its securities. Beginners choose it for instant diversification, low fees, and because most professional managers fail to beat the index after fees over long periods.*

9. **What is the practical difference between an ETF and a mutual fund holding the same investments?**
   *Answer: ETFs trade during the day at changing prices; mutual funds are bought and sold once a day at the closing price. The underlying investments can be identical.*

10. **What is diversification, and what does it NOT protect you from?**
    *Answer: Spreading money across many securities so no single failure dominates. It does not protect you from a broad market crash, when most stocks fall together.*

11. **What is asset allocation, and why is it more important than picking individual funds?**
    *Answer: How a portfolio is divided among stocks, bonds, and other classes. Research finds allocation explains far more of a portfolio's long-run outcome than fund selection or timing.*

12. **A portfolio is 80% stocks / 20% bonds. After a strong year for stocks it is 86% / 14%. What should the investor do, and what is this called?**
    *Answer: Rebalance — sell about 6% of the portfolio's value in stocks and buy bonds to return to 80/20.*

13. **What is the difference between risk tolerance and risk capacity?**
    *Answer: Tolerance is emotional — how you feel about losses. Capacity is financial — how much loss you can afford given your horizon, income, and goals. Your allocation should respect the lower of the two.*

14. **Your portfolio falls 20% in a year. You sell everything and move to cash. What have you done, and why is it usually costly?**
    *Answer: You have locked in the loss and must now guess correctly twice — when to get out and when to get back in. Investors who do this typically miss the market's best recovery days.*

15. **A fund charges a 0.75% expense ratio; an equivalent fund charges 0.03%. On a $10,000 lump sum at 7% gross for 20 years, roughly how much does the higher fee cost?**
    *Answer: About $4,862 — $38,480 at 0.03% versus $33,619 at 0.75%, before taxes.*

16. **What is a target-date fund?**
    *Answer: A single fund holding a diversified mix of stocks and bonds that gradually becomes more conservative as a chosen retirement year approaches.*

17. **Why should dividends be reinvested?**
    *Answer: Reinvested dividends buy more shares, which then earn their own dividends — compounding. Dividends have contributed a meaningful share of long-run stock returns.*

18. **In a taxable brokerage account, how are long-term capital gains generally treated compared with short-term gains?**
    *Answer: Long-term gains (investments held longer than a year) are generally taxed at lower rates than short-term gains, which are taxed as ordinary income.*

19. **What is dollar-cost averaging?**
    *Answer: Investing a fixed amount at regular intervals, so you automatically buy more shares when prices are low and fewer when prices are high.*

20. **Money you need in two years for a house deposit — should it be in the stock market? Why or why not?**
    *Answer: No. Money needed within about five years should not be in stocks, because a market fall could coincide with the date you need the money, and there is too little time to recover.*

21. **What is the maximum drawdown, and why should a beginner know it before investing?**
    *Answer: The largest peak-to-trough fall an investment has experienced. Knowing it calibrates expectations — for example, that a stock-heavy portfolio can fall 30–50% in a severe crash.*

22. **Name two costs, other than the expense ratio, that can reduce investment returns.**
    *Answer: Any two of: advisory fees (often 1% of assets a year), trading commissions, sales loads, taxes on short-term gains or on dividends and interest in taxable accounts, or the cost of frequent trading.*

23. **What does "rebalancing with new contributions" mean, and when is it useful?**
    *Answer: Directing new money to the underweight asset instead of selling the overweight one. Useful in taxable accounts, where selling could trigger capital-gains tax.*

24. **Your friend tells you about a guaranteed 20% return with no risk. What should you do?**
    *Answer: Walk away. There is no guaranteed, risk-free 20% return. It is a hallmark of a scam or a deeply misleading sales pitch.*

25. **List the first three steps of the account order of operations from Module 2.**
    *Answer: (1) Build a small emergency cushion; (2) contribute to a 401(k) up to the full employer match; (3) pay off high-interest debt — before funding an IRA or a taxable brokerage account.*

---

# Final Checklist

Before you call yourself an investor, confirm you can tick every box:

- [ ] Emergency cushion in place ($1,000 minimum, ideally one month of expenses)
- [ ] Employer 401(k) match captured in full, if offered
- [ ] High-interest debt addressed
- [ ] Risk-tolerance worksheet completed and allocation chosen
- [ ] Account(s) opened, beneficiaries named
- [ ] Portfolio built in the portfolio-builder spreadsheet; weighted expense ratio under 0.20%
- [ ] First purchase made; trade confirmations filed
- [ ] Dividend reinvestment on; automatic contributions and investments set up
- [ ] Annual rebalancing date and quarterly review date on the calendar
- [ ] Downturn rules written down and kept with your records
- [ ] 90-day plan in the calendar, starting today

---

*Disclaimer repeated: This course is financial education only. It is not individualized investment, tax, or financial advice. Investing involves risk, including possible loss of principal. All return examples are hypothetical illustrations based on stated assumptions, not predictions or guarantees. Consult a qualified professional for advice about your specific situation.*

*— End of First Investor: The Beginner Investing Foundations Course —*
