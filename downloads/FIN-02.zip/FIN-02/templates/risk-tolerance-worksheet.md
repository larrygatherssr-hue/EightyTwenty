# Risk-Tolerance Worksheet

> **Disclaimer:** This worksheet is financial education only, not individualized investment, tax, or financial advice. It helps you think about your own comfort with risk; it does not recommend a specific investment for you. Investing involves risk, including the possible loss of principal.

Answer each question honestly — choose the answer that matches what you would *actually* do, not what sounds brave. Circle or write your points, then add them up.

---

## Part A — Time horizon and capacity (Questions 1–4)

**1. When will you need most of this money?**
- (a) Less than 3 years — 1 point
- (b) 3–5 years — 2 points
- (c) 6–10 years — 3 points
- (d) 11–20 years — 4 points
- (e) More than 20 years — 5 points

My answer: ______ Points: ______

**2. How stable is your income?**
- (a) Unstable or uncertain — 1 point
- (b) Somewhat stable — 2 points
- (c) Stable — 3 points
- (d) Very stable, with savings to fall back on — 4 points
- (e) Very stable, with a large emergency fund and no high-interest debt — 5 points

My answer: ______ Points: ______

**3. If you lost your job tomorrow, how long could you cover expenses from cash savings (not investments)?**
- (a) Less than 1 month — 1 point
- (b) 1–3 months — 2 points
- (c) 3–6 months — 3 points
- (d) 6–12 months — 4 points
- (e) More than 12 months — 5 points

My answer: ______ Points: ______

**4. How much of your monthly income could you invest without affecting your lifestyle?**
- (a) Nothing right now — 1 point
- (b) Less than 5% — 2 points
- (c) 5–10% — 3 points
- (d) 10–15% — 4 points
- (e) More than 15% — 5 points

My answer: ______ Points: ______

## Part B — Tolerance and behavior (Questions 5–9)

**5. You invest $10,000. A year later it is worth $8,000 (a 20% fall). What do you do?**
- (a) Sell everything and move to cash — 1 point
- (b) Sell some and wait — 2 points
- (c) Do nothing — 3 points
- (d) Hold and keep contributing as planned — 4 points
- (e) Buy more while prices are low — 5 points

My answer: ______ Points: ______

**6. Which statement best describes your feelings about investment risk?**
- (a) I would rather earn a small, steady return than risk any loss — 1 point
- (b) I accept small losses for modestly higher returns — 2 points
- (c) I accept moderate ups and downs for higher long-run returns — 3 points
- (d) I am comfortable with large swings for the highest long-run returns — 4 points
- (e) I actively seek the highest possible returns and accept very large swings — 5 points

My answer: ______ Points: ______

**7. Have you invested before, and how did you react to a fall?**
- (a) I have never invested — 2 points
- (b) I invested and sold during a fall — 1 point
- (c) I invested, felt anxious, but held — 3 points
- (d) I invested and held comfortably through a fall — 4 points
- (e) I invested and bought more during a fall — 5 points

My answer: ______ Points: ______

**8. How often would you want to check your portfolio?**
- (a) Daily — I need to know what is happening — 1 point
- (b) Weekly — 2 points
- (c) Monthly — 3 points
- (d) Quarterly — 4 points
- (e) Annually or less — I prefer to set it and leave it — 5 points

My answer: ______ Points: ______

**9. Which portfolio would you choose if you had to pick one today?**
- (a) Expected return 3%, worst year about −2% — 1 point
- (b) Expected return 5%, worst year about −8% — 2 points
- (c) Expected return 7%, worst year about −20% — 3 points
- (d) Expected return 8%, worst year about −30% — 4 points
- (e) Expected return 9%, worst year about −40% or more — 5 points

My answer: ______ Points: ______

**10. If your portfolio fell 30% and stayed down for two years, what would you do?**
- (a) Sell everything — 1 point
- (b) Sell most of it — 2 points
- (c) Hold, but stop contributing — 3 points
- (d) Hold and keep contributing — 4 points
- (e) Hold, keep contributing, and increase contributions — 5 points

My answer: ______ Points: ______

---

## Scoring Guide

Add up all ten answers. Maximum score: 50. Minimum: 10.

| Total score | Suggested starting range | What it means |
|---|---|---|
| 10–19 | 30–50% stocks / 50–70% bonds | Conservative. Capital preservation matters most to you right now. Consider a target-date fund or a balanced portfolio, and revisit as your horizon or comfort grows. |
| 20–29 | 50–65% stocks / 35–50% bonds | Moderately conservative. You want growth but need a meaningful cushion. A 60/40 portfolio is a common starting point in this range. |
| 30–39 | 65–80% stocks / 20–35% bonds | Moderate. You can accept real swings for higher long-run growth. A 70/30 or 80/20 portfolio is a common starting point in this range. |
| 40–50 | 80–100% stocks / 0–20% bonds | Aggressive. You have a long horizon and the temperament for large swings. Even here, most beginners keep at least 10% in bonds for stability, and a 100% stock portfolio should be a deliberate choice, not a default. |

**My total score: ______ / 50**

**Suggested range: ______% stocks / ______% bonds**

**My chosen allocation: ______% stocks / ______% bonds**

### Important notes

- This worksheet is a starting point for your own thinking, not a prescription. If the result surprises you, trust the surprise — it is telling you something about yourself.
- Your allocation should respect the *lower* of your tolerance and your capacity. If your score is high but you need the money in three years, your horizon — not your score — decides.
- Re-take this worksheet once a year or after a major life change. Your answer will change as your life does.
- If you scored in the conservative range but your horizon is 30 years, consider whether fear is costing you long-run growth — and consider whether a target-date fund, which manages the mix for you, would be easier to hold than choosing the mix yourself.
