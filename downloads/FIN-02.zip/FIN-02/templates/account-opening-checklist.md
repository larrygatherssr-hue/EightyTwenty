# Account-Opening Checklist

> **Disclaimer:** This checklist is financial education only, not individualized investment, tax, or financial advice. Account rules, contribution limits, and tax treatment change from time to time — verify current limits with the IRS or a qualified tax professional before contributing.

## Before you open anything

- [ ] Emergency cushion confirmed: at least $1,000, ideally one month of expenses, in a savings account
- [ ] Employer 401(k) match checked — I am getting the full match: Yes / No / No employer plan
- [ ] High-interest debts (above about 8–10%) listed and payoff plan in place
- [ ] Risk-tolerance worksheet completed; draft allocation chosen: ______% stocks / ______% bonds
- [ ] Chosen brokerage: _______________________________________________ (large, established, $0 commissions, no account fees, low-cost index funds available)

## Documents to have ready

- [ ] Social Security number
- [ ] Date of birth
- [ ] Current address
- [ ] Employment information (employer name and address)
- [ ] Bank account number and routing number for funding
- [ ] Government-issued ID (some brokerages ask for it)

## Brokerage account (taxable)

- [ ] Account opened online (about 15 minutes)
- [ ] Bank account linked
- [ ] Test transfer sent and confirmed arrived
- [ ] Dividend reinvestment turned ON
- [ ] Beneficiary named (if offered)

## Roth IRA (or traditional IRA)

- [ ] Earned income confirmed (required for an IRA)
- [ ] Current-year IRS contribution limit checked: $__________
- [ ] Income limits checked for my situation: _______________________________________________
- [ ] Roth vs. traditional decided — my reason: _______________________________________________
- [ ] IRA opened at my chosen brokerage
- [ ] Beneficiary named
- [ ] First contribution set up: $__________ on __________ (date)
- [ ] Confirmed the contribution was INVESTED, not left as cash

## 401(k) at work

- [ ] Match formula written down: _______________________________________________
- [ ] My contribution raised to the full-match level on: ______________
- [ ] Investment choice checked (target-date fund or low-cost index options): ____________________
- [ ] Beneficiary named

## HSA (only if you have a qualifying high-deductible health plan)

- [ ] Health plan confirmed as HSA-eligible: Yes / No
- [ ] HSA opened (through employer or on my own)
- [ ] Contribution amount set: $__________ per __________
- [ ] Investment option selected (not just cash), if the balance allows it
- [ ] Beneficiary named

## After opening — do not skip this

- [ ] First investment purchase made (see Module 8 of the course)
- [ ] Automatic contributions set up
- [ ] Automatic investments set up
- [ ] Trade confirmations saved
- [ ] Annual rebalancing date on the calendar: ______________
- [ ] Quarterly review date on the calendar: ______________
