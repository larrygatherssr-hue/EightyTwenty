# First Investor — Companion Workbook

> **Disclaimer:** This workbook is financial education only. It is not individualized investment, tax, or financial advice. Investing involves risk, including the possible loss of principal. The worksheets here help you organize your own thinking; they do not recommend any specific investment for you. Consult a qualified professional for advice about your specific situation.

Print this workbook or copy it into a notebook. Work through it in order — it follows the course modules.

---

## 1. Risk-Tolerance Worksheet (summary version)

*The full questionnaire with scoring guide is in `templates/risk-tolerance-worksheet.md`. Use that version for your scored result, and record the outcome here.*

- My risk-tolerance score: ______ / 50
- Suggested stock/bond range from the scoring guide: ______% stocks / ______% bonds
- My chosen allocation: ______% stocks / ______% bonds
- Why I chose this allocation (one or two sentences): _______________________________________________
- What I will do if my portfolio falls 20%: _______________________________________________
- What I will do if my portfolio falls 30%: _______________________________________________
- What I will do if my portfolio falls 50%: _______________________________________________

Signed: ______________________________ Date: ______________

---

## 2. Account-Opening Checklist

### Brokerage account

- [ ] Chosen a brokerage (large, established, $0 commissions, no account fees)
- [ ] Gathered: Social Security number, date of birth, address, employment information, bank account details
- [ ] Opened the account online (about 15 minutes)
- [ ] Linked my bank account
- [ ] Set up a test transfer and confirmed it arrived
- [ ] Turned on dividend reinvestment
- [ ] Named a beneficiary (if the brokerage offers it)

### Roth IRA (or traditional IRA)

- [ ] Confirmed I have earned income (required for an IRA)
- [ ] Checked the current year's IRS contribution limit: $__________
- [ ] Checked whether the income limits affect me: Yes / No / Not sure — asked a tax professional
- [ ] Decided Roth vs. traditional and wrote down why: _______________________________________________
- [ ] Opened the IRA at my chosen brokerage
- [ ] Named a beneficiary
- [ ] Linked my bank account and set up the first contribution: $__________ on __________ (date)
- [ ] Confirmed the contribution was invested, not left as cash

### 401(k) at work

- [ ] Confirmed my employer offers a 401(k): Yes / No
- [ ] Match formula: _______________________________________________
- [ ] My current contribution: ______% — full match requires: ______%
- [ ] Raised my contribution to the full-match level on: ______________
- [ ] Checked my 401(k) investment choice (target-date fund or low-cost index options): ____________________
- [ ] Named a beneficiary

---

## 3. Portfolio-Builder Worksheet

*Also available as a spreadsheet: `templates/portfolio-builder.csv`.*

My starting amount: $__________

| # | Fund name | Ticker | Asset class | Allocation % | Dollar amount | Expense ratio |
|---|---|---|---|---|---|---|
| 1 | | | U.S. stocks | ____% | $__________ | ____% |
| 2 | | | International stocks | ____% | $__________ | ____% |
| 3 | | | Bonds | ____% | $__________ | ____% |
| | **Total** | | | **100%** | **$__________** | **Weighted: ____%** |

Weighted expense ratio calculation: (Allocation 1 × Expense 1) + (Allocation 2 × Expense 2) + (Allocation 3 × Expense 3). My weighted expense ratio is ______%. Target: under 0.20%.

Monthly contribution: $__________ — split: U.S. stocks $______, International $______, Bonds $______

Why I chose this portfolio (two sentences): _______________________________________________

---

## 4. Fee-Comparison Worksheet

List each fund you own or plan to buy, then compare it with a lower-cost equivalent.

| Fund I own / plan to buy | Expense ratio | Lower-cost equivalent | Its expense ratio | Annual saving on $10,000 |
|---|---|---|---|---|
| | ____% | | ____% | $__________ |
| | ____% | | ____% | $__________ |
| | ____% | | ____% | $__________ |

Annual saving = $10,000 × (higher ratio − lower ratio). Example: 0.75% − 0.03% = 0.72% → $72 a year on $10,000.

**Twenty-year cost check:** On a $10,000 lump sum at 7% gross, a 0.03% fund grows to about $38,480 in 20 years; a 0.75% fund grows to about $33,619 — a difference of about $4,862. On $500 a month for 20 years, the gap is about $21,529. Write your own numbers here:

- My portfolio's weighted expense ratio: ______%
- Estimated 20-year cost of my fees vs. a 0.03% portfolio on my balance: $__________
- Action (switch funds / stay / ask my adviser): _______________________________________________

---

## 5. 90-Day Action Tracker

Copy the plan from Module 10 into this tracker and check off each step as you complete it.

| Day | Action | Done? | Date completed | Notes |
|---|---|---|---|---|
| 1 | Wrote my one-sentence reason for investing | [ ] | | |
| 2 | Checked employer 401(k) match | [ ] | | |
| 3 | Listed high-interest debts and payoff plan | [ ] | | |
| 4 | Completed risk-tolerance worksheet | [ ] | | |
| 5 | Chose accounts; opened Roth IRA if applicable | [ ] | | |
| 6 | Built portfolio in portfolio-builder worksheet | [ ] | | |
| 7 | Reviewed the full plan | [ ] | | |
| 8–10 | Transferred starting amount; cash settled | [ ] | | |
| 11–14 | Placed first buy | [ ] | | |
| 15 | Turned on dividend reinvestment | [ ] | | |
| 16 | Set up automatic contributions + investments | [ ] | | |
| 17–21 | Named beneficiaries; filed confirmations | [ ] | | |
| 31 | Confirmed first automatic contribution invested | [ ] | | |
| 35 | Confirmed dividends reinvested | [ ] | | |
| 45 | Reviewed fee worksheet | [ ] | | |
| 60 | First monthly review (15 min) | [ ] | | |
| 61–75 | Raised contribution if pay rose / debt paid off | [ ] | | |
| 76–85 | Read one reputable investing book | [ ] | | |
| 90 | Full 90-day review written | [ ] | | |

**Day 90 review — answer in writing:**

- Did every contribution happen automatically? _______________________________________________
- Is my allocation still on target? _______________________________________________
- Did I panic, check obsessively, or change the plan? Why? _______________________________________________
- My contribution amount for the next 90 days: $__________
- Next quarterly review date: ______________
- Annual rebalancing date: ______________

---

## 6. Rebalancing Checklist

Complete once a year, on your chosen rebalancing date, or when any asset class drifts more than 5 percentage points from target.

Rebalancing date: ______________

- [ ] Recorded current value of each holding
- [ ] Calculated current allocation % for each holding
- [ ] Compared with target allocation — drift: U.S. stocks ______, International ______, Bonds ______
- [ ] Rebalancing needed? Yes / No (if no drift above 5 points, stop here and record "no action")
- [ ] If in a retirement account: sold overweight holdings and bought underweight holdings to restore target
- [ ] If in a taxable account: directed new contributions to the underweight asset first; sold only if needed, and noted any capital-gains tax
- [ ] Confirmed new allocation matches target: ______% / ______% / ______%
- [ ] Recorded the rebalance in my records and set next year's date: ______________

**Rebalancing log:**

| Date | Portfolio value | Before (stocks/bonds) | After (stocks/bonds) | Trades made | Notes |
|---|---|---|---|---|---|
| | $__________ | ____% / ____% | ____% / ____% | | |
| | $__________ | ____% / ____% | ____% / ____% | | |
| | $__________ | ____% / ____% | ____% / ____% | | |

---

## 7. My One-Page Investor Plan

Fill this in and keep it with your investment records. When markets fall, read this before you act.

- My reason for investing (one sentence): _______________________________________________
- My time horizon: ______ years — money needed by: ______________
- My allocation: ______% stocks (______% U.S. / ______% international) / ______% bonds
- My monthly contribution: $__________ on the ______ of each month
- My accounts: _______________________________________________
- My funds and tickers: _______________________________________________
- My rebalancing date each year: ______________
- My review schedule: quarterly on ______________
- My downturn rule: _______________________________________________
- Support contact: marketplace support (see `onboarding.md` for how to reach support with your order number)

Signed: ______________________________ Date: ______________
