# Pet Nutrition Foundations — Companion Workbook

## Disclaimer

This workbook is general nutrition education only. It is not veterinary advice and never replaces veterinary care or a consultation with a board-certified veterinary nutritionist. Dogs and cats with medical conditions, and any animal that is pregnant, nursing, very young, very old, underweight, or recovering from illness, need individualised feeding plans made with their veterinarian. No exercise in this workbook guarantees any health outcome. If your pet stops eating for more than 24 hours (especially cats), vomits repeatedly, has persistent diarrhoea, or loses weight unexpectedly, contact your veterinarian promptly.

Print this workbook and work through it with your pet's real numbers. Keep the completed pages with your pet's records.

---

## Exercise 1.1 — Your Pet's Baseline (Module 1)

Pet's name: ______________________ Species: __________ Breed: ______________________

Age: __________ Sex: __________ Neutered/spayed? Yes / No

Current weight: __________ kg ( __________ lb) Date weighed: __________

How weighed: bathroom scale (hold pet) / pet scale / veterinary clinic scale

Current food (brand and product): ________________________________________________

Current daily amount fed (grams or cups): __________________________________________

Current treats given in a typical day: ______________________________________________

Any known health conditions or medications: ________________________________________

Veterinarian's name and phone number: ____________________________________________

---

## Exercise 2.1 — Water Needs (Module 2)

My pet weighs __________ kg.

Daily water need (40–60 ml per kg): __________ ml to __________ ml per day.

Moisture in today's food: wet food __________ g × __________ % moisture = __________ ml
Dry food __________ g × __________ % moisture = __________ ml

Water my pet still needs to drink: roughly __________ ml per day.

Do I provide fresh water daily in a clean bowl? Yes / No
Second water station or fountain? Yes / No — action: ______________________________

---

## Exercise 3.1 — The Adequacy Statement (Module 3)

Copy the adequacy statement from your current food's label, word for word:

________________________________________________________________________________

Life stage covered: maintenance / growth / all life stages / gestation and lactation / supplemental only

Established by: formulation / feeding trials / not stated

If the statement says "intermittent or supplemental feeding only," this food must NOT be the sole diet. Action taken: ______________________________

Manufacturer questions I will ask (from Module 3): __________________________________

---

## Exercise 4.1 — Dry Matter Basis Comparison (Module 4)

| | Food A (current) | Food B (comparison) |
|---|---|---|
| Protein % (label) | | |
| Fat % (label) | | |
| Moisture % (label) | | |
| Dry matter % (100 − moisture) | | |
| Protein on dry matter basis | | |
| Fat on dry matter basis | | |
| kcal per kg (or per 100 g) | | |
| Cost per kg | | |

Which food fits my pet better, and why? ___________________________________________

## Exercise 4.2 — Five-Minute Label Audit (Module 4)

Food: ___________________________________________________________________________

1. Adequacy statement present? Yes / No — Life stage: ______________________________
2. Named protein source in the first few ingredients? Yes / No — Which? ______________
3. Protein and fat on a dry matter basis: __________ % / __________ %
4. Calorie content stated? Yes / No — __________ kcal per kg / per cup / per 100 g
5. Feeding directions for my pet's weight: __________ g per day
6. Expiry date and batch code present, packaging intact? Yes / No

Verdict: keep / consider changing / do not feed as a staple diet

---

## Exercise 5.1 — Calorie Calculation (Module 5)

My pet's weight: __________ kg. Target weight (if different): __________ kg.

RER = 70 × (target weight in kg)^0.75 = __________ kcal/day.
(Shortcut check for 2–45 kg: (30 × kg) + 70 = __________ kcal/day.)

MER factor for my pet's situation: __________ (from the table in Module 5)

MER = RER × factor = __________ kcal/day.

My food's energy density: __________ kcal per kg = __________ kcal per gram.

Grams of food per day = MER ÷ kcal per gram = __________ g per day.

Meals per day: __________ → __________ g per meal.

What I have actually been feeding: __________ g per day = __________ kcal per day.

Difference: __________ kcal per day (over / under target).

Action: ________________________________________________________________________

## Exercise 5.2 — Treat Audit (Modules 5 and 8)

| Treat / extra | kcal each | Number per day | Total kcal |
|---|---|---|---|
| | | | |
| | | | |
| | | | |
| | | | |
| **Total treats per day** | | | **__________ kcal** |

10% allowance (MER × 0.10): __________ kcal.

Am I within the allowance? Yes / No. If no, what will I cut or replace? __________________

## Exercise 5.3 — Cost Comparison (Module 5)

| | Option A | Option B |
|---|---|---|
| Food and pack size | | |
| Price per pack | | |
| kcal per kg | | |
| Grams needed per day | | |
| Cost per day | | |
| Cost per month (× 30) | | |

---

## Exercise 6.1 — Body Condition Score and Weight Tracker (Module 6)

Body condition score today (1–9): __________ Date: __________

Ribs felt easily with a thin fat layer? Yes / No
Waist visible from above? Yes / No
Abdominal tuck visible from the side? Yes / No

Target weight (agreed with veterinarian): __________ kg

Safe rate of loss: dogs 1–2% of body weight per month; cats 0.5–2% per month.
My pet's safe monthly loss: __________ kg to __________ kg.

### Weight log

| Date | Weight (kg) | BCS (1–9) | Daily food (g) | Notes |
|---|---|---|---|---|
| | | | | |
| | | | | |
| | | | | |
| | | | | |
| | | | | |
| | | | | |
| | | | | |
| | | | | |

Rules: weigh every two weeks on the same scale. If weight is static for a month, reduce food by 10% and reassess. Never starve a cat — a cat that stops eating needs a veterinarian the same day.

---

## Exercise 7.1 — Life-Stage Check (Module 7)

My pet's life stage: puppy / kitten / adult / senior / pregnant / lactating

Does my food's adequacy statement match this life stage? Yes / No

If puppy/kitten — current weight __________ kg, recalculated ration __________ g/day, meals per day __________

If recently neutered/spayed — have I reduced the portion by about 20%? Yes / No

If senior — weight trend over the last 6 months: stable / gaining / losing
Protein level of current food (dry matter basis): __________ %
Has my veterinarian advised a low-protein or therapeutic diet? Yes / No — Details: __________

---

## Exercise 8.1 — Treats, Chews, and Supplements Review (Module 8)

Every treat, chew, topper, and supplement I currently use:

| Item | kcal per serving | Servings per day | Safe? (see Module 8) | Keep / cut / replace |
|---|---|---|---|---|
| | | | | |
| | | | | |
| | | | | |
| | | | | |

Supplements I use: ________________________________________________________________

For each supplement: does it have published evidence in my pet's species and condition at this dose? Yes / No / Don't know — Action: ______________________________

Am I adding any vitamins, minerals, or calcium to a complete and balanced diet? Yes / No — If yes, I will discuss this with my veterinarian before continuing.

---

## Exercise 9.1 — Homemade and Raw Diet Check (Module 9)

Do I feed homemade or raw? No — skip to Exercise 10.1. Yes — complete this section.

Recipe source: ___________________________________________________________________

Formulated by a board-certified veterinary nutritionist? Yes / No

Does the recipe include a vitamin-mineral balancer? Yes / No — Which one? ______________

Does the product carry a complete-and-balanced adequacy statement? Yes / No

If raw: hygiene steps I follow (hand washing, separate storage, surface cleaning): __________

Household members at higher risk (young children, elderly, immunocompromised): __________

Discussion with my veterinarian booked? Yes / No — Date: __________

---

## Exercise 10.1 — My Pet's Feeding Plan (Module 10)

Pet's name: ______________________ Date plan written: __________

Species / breed / age: ____________________________________________________________

Current weight: __________ kg — Target weight: __________ kg — BCS: __________ /9

Food (brand, product, life stage): ___________________________________________________

Adequacy statement: _____________________________________________________________

Daily calorie target (MER): __________ kcal/day (RER __________ × factor __________)

Daily amount: __________ g per day, in __________ meals of __________ g

Meal times: ______________________________________________________________________

Treat allowance: __________ kcal/day, consisting of: ___________________________________

Weighing schedule: every __________ weeks. Next weigh-in date: __________

Review date for this plan: __________ (every 3 months, or at the next veterinary visit)

Veterinary instructions or medical diet notes: ________________________________________

Signed (owner): ______________________ Veterinarian aware? Yes / No

---

## Exercise 10.2 — Transition Log (Module 10)

New food: _______________________________________________________________________

| Days | Old food | New food | Stool quality | Appetite | Notes |
|---|---|---|---|---|---|
| 1–2 | 75% | 25% | | | |
| 3–4 | 50% | 50% | | | |
| 5–6 | 25% | 75% | | | |
| 7+ | 0% | 100% | | | |

If soft stools appear, go back a step and hold for 2–3 days. If vomiting or diarrhoea persists, stop and contact your veterinarian.

---

*Pet Nutrition Foundations — Companion Workbook. Education only; not a substitute for veterinary care.*
