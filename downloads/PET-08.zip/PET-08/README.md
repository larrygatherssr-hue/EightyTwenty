# PET-08 — Pet Nutrition Foundations: Feed Your Dog and Cat for Lifelong Health

**Price:** $197 (one-time purchase) · **Category:** Pet Products & Pet Business · **SKU:** PET-08

An evidence-based pet nutrition education course for health-conscious dog and cat owners, pet sitters, and groomers who advise clients on feeding. Covers nutrient needs, AAFCO/FEDIAF basics, label reading, weight management, life-stage feeding, and safe homemade feeding — with worked examples using real numbers throughout.

**Format note:** this product delivers the complete **written course manual** (the video is not recorded). The sales page states this plainly so buyers are not misled.

## Files

| File | Description |
|---|---|
| content.md | Full written course — 10 modules, appendices, toxic-foods reference, glossary, sources (14,481 words) |
| workbook.md | Companion workbook — one exercise per module, using your own pet's numbers |
| templates/weight-management-planner.csv | Weight-loss calorie targets, RER quick-reference table, fortnightly weight log |
| templates/life-stage-feeding-charts.md | MER factors and example daily rations for dogs and cats at every life stage |
| templates/safe-foods-toxic-foods-reference.md | Safe treats and toxic foods, with clear warnings |
| templates/label-reading-guide.md | Five-minute label audit with worked dry-matter-basis examples |
| templates/meal-planning-worksheet.md | Weekly meal plan, treat plan, and check-in |
| sales-page.md | Full sales page — headline, problem/solution, module list, audience, price, guarantee, 10 FAQs, disclaimers |
| listing.json | Marketplace listing data (price_cents 19700, one-time billing, 12 SEO keywords) |
| cover.md | Cover design brief (black-and-gold luxury palette, typography, imagery, layout) |
| cover.png | Generated premium black-and-gold cover image (1280 × 1920 px) |
| onboarding.md | Customer onboarding guide — first steps, 5-week schedule, support |
| README.md | This index |

## Key facts

- Education only — general nutrition guidance that never replaces veterinary care or a veterinary nutritionist for medical diets or sick animals.
- No medical/disease-treatment claims; no guaranteed health outcomes.
- Disclaimers included in content.md, workbook.md, and sales-page.md.
- Toxic-foods reference included in the course (Appendix A) and as a standalone template.
- 14-day money-back guarantee.
