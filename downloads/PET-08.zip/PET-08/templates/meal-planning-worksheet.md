# Meal-Planning Worksheet

## How to use this worksheet

Fill in one sheet per pet, per week. Calculate the daily calorie target first (Module 5 of the course), then plan the food, the meals, and the treats. Post it on the fridge so everyone in the household feeds the same plan.

## My pet

Pet's name: ______________________ Species: __________ Weight: __________ kg

Target weight: __________ kg Body condition score: __________ /9

Food (brand and product): _______________________________________________________

Food energy density: __________ kcal/kg = __________ kcal per gram

## Daily targets

RER: __________ kcal/day × MER factor __________ = daily target __________ kcal/day

Grams of food per day: __________ g Treat allowance (10% max): __________ kcal/day

## Weekly meal plan

| Day | Meal 1 (time and grams) | Meal 2 (time and grams) | Meal 3 (time and grams) | Treats (what and kcal) | Total kcal |
|---|---|---|---|---|---|
| Monday | | | | | |
| Tuesday | | | | | |
| Wednesday | | | | | |
| Thursday | | | | | |
| Friday | | | | | |
| Saturday | | | | | |
| Sunday | | | | | |

## Weekly food prep checklist

- [ ] Food weighed on a kitchen scale (not a measuring cup)
- [ ] Daily ration pre-portioned into a container each morning
- [ ] Treat jar filled with the day's allowance only
- [ ] Fresh water in a clean bowl (second station for cats)
- [ ] Food stored sealed in its original bag, cool and dry
- [ ] Bowls washed

## Treat plan for the week

| Treat | kcal each | How many per day | Purpose (training / reward / medication) |
|---|---|---|---|
| | | | |
| | | | |
| | | | |
| | | | |

## Homemade meals (only if using a veterinary-nutritionist-formulated recipe)

Recipe source: _________________________________________________________________

Balancer supplement: ______________________ Dose: ______________________________

| Day | Protein (g) | Carbohydrate (g) | Vegetables (g) | Oil (g) | Balancer | Total kcal |
|---|---|---|---|---|---|---|
| Monday | | | | | | |
| Tuesday | | | | | | |
| Wednesday | | | | | | |
| Thursday | | | | | | |
| Friday | | | | | | |
| Saturday | | | | | | |
| Sunday | | | | | | |

Never feed a homemade diet long-term without a recipe from a board-certified veterinary nutritionist and the specified balancer supplement.

## Weekly check-in

Weight this week: __________ kg (date: __________)

Body condition score: __________ /9

Stool quality: firm / soft / loose / diarrhoea

Appetite: good / reduced / refused food

Energy and mood: _______________________________________________________________

Changes for next week: ___________________________________________________________

---

*General education only; not a substitute for veterinary advice. If your pet stops eating for more than 24 hours (especially cats), vomits repeatedly, or loses weight unexpectedly, contact your veterinarian promptly.*
