# Label-Reading Guide

## The five-minute label audit

Work through these steps for any pet food before you buy it or feed it as a staple diet.

## Step 1 — Find the adequacy statement

Look on the back of the bag or can, usually in small print. It should say the food is formulated (or feeding-trial tested) to meet AAFCO Dog/Cat Food Nutrient Profiles, or that it is a complete food to FEDIAF guidelines, for a stated life stage.

- Maintenance / adult
- Growth / growth and reproduction
- All life stages
- **Intermittent or supplemental feeding only — not a complete diet. Do not feed as a staple.**

If there is no adequacy statement at all, do not feed the product as a staple diet.

## Step 2 — Check the life stage matches your pet

A growth diet for a puppy or kitten; a maintenance diet for a healthy adult; an all-life-stages diet covers both but is energy-dense, so portion control matters more. A senior diet is not required by age alone.

## Step 3 — Read the ingredient list

- Ingredients are listed by weight as added, including water. Fresh meat listed first can be misleading — it is mostly water.
- Look for named protein sources ("chicken," "salmon") rather than generic terms ("meat," "poultry").
- Ingredient splitting (peas, pea protein, pea fibre) can push one ingredient lower on the list. Read the whole list.
- By-products are not automatically low quality — named by-products such as "chicken by-product meal" include nutrient-rich organ meats.
- The first ingredient is not the whole story. Judge the diet by its nutrient analysis and adequacy statement.

## Step 4 — Convert the guaranteed analysis to a dry matter basis

You cannot compare wet and dry foods directly. Remove the water first.

**Dry matter % = 100 − moisture %**
**Nutrient on dry matter basis = (nutrient % ÷ dry matter %) × 100**

### Worked example

Wet food: 10% protein, 78% moisture → dry matter 22% → protein DMB = (10 ÷ 22) × 100 = **45.5%**
Dry food: 26% protein, 10% moisture → dry matter 90% → protein DMB = (26 ÷ 90) × 100 = **28.9%**

### Your calculation

| | Food A | Food B |
|---|---|---|
| Protein % (label) | | |
| Fat % (label) | | |
| Moisture % (label) | | |
| Dry matter % | | |
| Protein (dry matter basis) | | |
| Fat (dry matter basis) | | |

## Step 5 — Check the calorie statement

Find kcal per kg (and per cup or per can). If it is missing, ask the manufacturer.

- kcal per gram = kcal per kg ÷ 1,000
- Grams per day = daily kcal need ÷ kcal per gram
- Weigh food on a kitchen scale. A "cup" can weigh 80–130 g depending on the kibble.

## Step 6 — Read the feeding directions critically

The directions are averages for a typical animal. Your pet may need 20% more or 20% less. Use the directions as a starting point, feed for 2–3 weeks, weigh your pet, assess body condition, and adjust.

## Step 7 — Check packaging and dates

- Expiry date present and in date
- Batch code present
- Packaging intact, no tears or swelling
- Store in the original bag, sealed, in a cool dry place; use within 4–6 weeks of opening

## Claims translated

| Claim on the bag | What it actually means |
|---|---|
| Natural | Ingredients from plant, animal, or mined sources; says nothing about nutritional adequacy |
| Holistic | No legal definition — marketing language |
| Premium / super-premium | No legal definition — marketing language |
| Human-grade | Ingredients and product handled to human food standards; does not mean nutritionally better |
| Vet recommended / vet formulated | Unregulated — ask which veterinarian and what their qualifications are |
| No fillers | "Filler" has no legal definition |
| Grain-free | Describes what is absent, not what is present; not automatically healthier |
| By-product free | Avoiding by-products is a preference, not a nutritional advantage |

## Questions to ask a manufacturer

1. Do you employ a full-time board-certified veterinary nutritionist or PhD animal nutritionist?
2. Do you conduct feeding trials, or only formulate to profiles?
3. Where is the food manufactured — your own plant or a co-packer?
4. What quality-control testing do you run on ingredients and finished products?
5. Can you provide the full typical nutrient analysis and the calorie content?

A reputable company answers these readily. Evasive or absent answers are information too.

## Quick verdict

- Adequacy statement present and life stage matches → proceed to fine-tuning.
- Adequacy statement missing or "supplemental only" → do not feed as a staple diet.
- Everything else on the front of the bag is advertising.
