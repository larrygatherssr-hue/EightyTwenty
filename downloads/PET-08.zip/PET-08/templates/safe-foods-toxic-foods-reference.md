# Safe Foods and Toxic Foods Reference

## WARNING

If your pet eats a toxic food, contact your veterinarian or an animal poison control service **immediately**. Do not wait for symptoms. Do not induce vomiting unless a veterinarian tells you to.

This reference is general education only. Individual animals can react differently, and any new food should be introduced in a small amount and watched for digestive upset. All safe foods below count toward the 10% daily treat allowance.

---

## TOXIC — Never Feed

| Food / substance | Dogs | Cats | Why it is dangerous |
|---|---|---|---|
| Chocolate (dark and baking are worst) | Toxic | Toxic | Theobromine; affects heart and nervous system |
| Xylitol (birch sugar; sugar-free gum, sweets, some peanut butters) | Toxic | Toxic | Causes dangerously low blood sugar and liver failure in dogs |
| Grapes, raisins, currants, sultanas | Toxic | Toxic | Can cause kidney failure; toxic dose is unpredictable |
| Onions, garlic, chives, leeks (raw, cooked, or powdered) | Toxic | Toxic | Damages red blood cells; cats are more sensitive |
| Macadamia nuts | Toxic | Toxic | Weakness, tremors, vomiting |
| Alcohol | Toxic | Toxic | Even small amounts |
| Caffeine (coffee, tea, energy drinks, coffee grounds) | Toxic | Toxic | Stimulant; dangerous in small doses |
| Lilies (all parts, including pollen and vase water) | Mildly toxic | **Highly toxic — can be fatal** | Causes kidney failure in cats, even from a small exposure |
| Cooked bones | Dangerous | Dangerous | Splinter and can perforate the gut |
| Raw dough with yeast | Dangerous | Dangerous | Expands in the stomach; produces alcohol |
| Other nuts (walnuts, pecans, hickory) | Harmful | Harmful | High fat; mouldy nuts can produce toxins |
| Fatty table scraps, skin, gravy, fried food | Harmful | Harmful | Common trigger for pancreatitis in dogs |
| Corn on the cob | Dangerous | Dangerous | Cob can cause intestinal blockage |
| Avocado (pit and skin; flesh in large amounts) | Harmful | Harmful | High fat; pit is a choking and blockage risk |
| Stone fruit pits (peach, plum, cherry) | Dangerous | Dangerous | Choking/blockage risk; pits contain cyanide compounds |

## CAUTION — Only in Small Amounts, or Avoid

| Food | Guidance |
|---|---|
| Dairy (milk, cheese, cream) | Most adult dogs and cats are lactose intolerant; small amounts of hard cheese are usually tolerated, but milk commonly causes diarrhoea |
| Raw meat, raw fish, raw eggs | Bacterial and parasite risk; raw egg white interferes with biotin absorption |
| Raw salmon / trout (Pacific Northwest) | Can carry a parasite that causes salmon poisoning disease in dogs — cook fish thoroughly |
| Tuna (for cats) | Occasional small amounts are fine, but tuna as a staple causes nutritional deficiencies and mercury exposure |
| Liver | Very high in vitamin A; small amounts occasionally are fine, large or frequent amounts can cause vitamin A toxicity |
| Citrus fruits | Upset stomach; citrus oils can be irritating |
| Coconut and coconut oil | High in fat; can cause digestive upset in large amounts |
| Mushrooms (wild) | Some wild mushrooms are toxic; plain cooked shop-bought mushrooms in small amounts are generally fine |

## SAFE — Occasional Treats in Small Amounts

All of these must be plain, cooked where applicable, unseasoned, boneless, and counted in the 10% treat allowance.

**Dogs and cats:**
- Cooked plain chicken or turkey (no skin, no bones)
- Cooked plain white fish (no bones)
- Cooked plain egg
- Carrot, cucumber, green beans, courgette/zucchini, peas
- Apple slices (no seeds, no core)
- Blueberries, banana (small pieces), watermelon without seeds or rind
- Plain cooked pumpkin (not pie filling)
- Plain cooked sweet potato

**Dogs additionally:**
- Plain cooked rice or pasta in small amounts
- Plain popcorn (no salt, no butter, fully popped)

**Cats additionally:**
- Small amounts of plain cooked salmon or sardine (occasionally, not as a staple)
- A little plain cooked chicken liver (occasionally)

## Foods that are NOT treats

- Anything from your plate that is seasoned, sauced, fried, or contains any item from the toxic list.
- "A little bit won't hurt" foods given daily — daily extras add up to a large calorie surplus over a year.

## If in doubt

Do not feed it. Check with your veterinarian first. A five-minute question is cheaper than an emergency visit.

---

*General education only; not a substitute for veterinary advice. If poisoning is suspected, seek veterinary help immediately.*
