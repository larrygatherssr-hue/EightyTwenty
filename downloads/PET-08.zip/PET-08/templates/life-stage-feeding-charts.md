# Life-Stage Feeding Charts

## How to use these charts

Find your pet's life stage, use the MER factor to calculate daily calories from RER (RER = 70 × body weight in kg^0.75), and convert calories to grams using your food's energy density. Always confirm the food's adequacy statement matches the life stage. Recalculate puppy and kitten rations every two weeks as they grow.

## Dogs

| Life stage | MER factor | Meals per day | Key notes |
|---|---|---|---|
| Puppy, under 4 months | 3.0 × RER (current weight) | 4 | Growth diet; controlled growth for large breeds |
| Puppy, 4 months to adult | 2.0 × RER (current weight) | 3, then 2 | Switch to adult food at skeletal maturity |
| Adult, intact | 1.8 × RER | 2 | Active adults may need more |
| Adult, neutered | 1.6 × RER | 2 | Reduce portion ~20% after neutering |
| Adult, inactive / obesity-prone | 1.4 × RER | 2 | Monitor weight monthly |
| Active / working dog | 2.0–5.0 × RER | 2–3 | Adjust to workload and season |
| Weight loss | 1.0 × RER at target weight | 2 | See weight-management planner |
| Senior, healthy | 1.4–1.6 × RER | 2 | Adequate protein; adjust to weight trend |
| Pregnant | 1.5–2.0 × RER, rising in late pregnancy | 2–3 | Growth or all-life-stages diet |
| Lactating | 2.0–4.0+ × RER | 3–4, or free-feed within reason | Highest demand of any stage; veterinary guidance |

### Example daily rations for dogs (grams of a 3,600 kcal/kg food)

| Weight | Puppy <4 mo (3.0×) | Puppy 4 mo+ (2.0×) | Neutered adult (1.6×) | Inactive adult (1.4×) | Weight loss (1.0× target) |
|---|---|---|---|---|---|
| 5 kg | 195 g | 130 g | 104 g | 91 g | 65 g |
| 10 kg | 328 g | 219 g | 175 g | 153 g | 109 g |
| 20 kg | 551 g | 368 g | 294 g | 257 g | 184 g |
| 30 kg | 748 g | 498 g | 399 g | 349 g | 249 g |
| 40 kg | 928 g | 619 g | 495 g | 433 g | 309 g |

## Cats

| Life stage | MER factor | Meals per day | Key notes |
|---|---|---|---|
| Kitten, under 4 months | 2.5 × RER (current weight) | 4 | Growth diet, rich in DHA |
| Kitten, 4 months to adult | 2.0 × RER (current weight) | 3–4 | Switch to adult food at ~12 months |
| Adult, intact | 1.4 × RER | 2–4 small meals | Active cats may need more |
| Adult, neutered | 1.2 × RER | 2–4 small meals | Reduce portion ~20% after neutering |
| Adult, inactive / obesity-prone | 1.0 × RER | 2–4 small meals | Monitor weight monthly |
| Weight loss | 0.8 × RER at target weight | 3–4 small meals | Never starve a cat |
| Senior, healthy | 1.0–1.2 × RER | 2–4 small meals | Adequate protein; adjust to weight trend |
| Pregnant | 1.5–2.0 × RER, rising late | 3–4 | Growth or all-life-stages diet |
| Lactating | 2.0–4.0+ × RER | Free-feed within reason | Very high demand with large litters |

### Example daily rations for cats (grams of a 3,800 kcal/kg dry food, or grams of an 85 kcal/100 g wet food)

| Weight | Kitten <4 mo (2.5×) | Kitten 4 mo+ (2.0×) | Neutered adult (1.2×) | Inactive adult (1.0×) | Weight loss (0.8× target) |
|---|---|---|---|---|---|
| 2 kg | 78 g dry / 347 g wet | 62 g / 278 g | 37 g / 166 g | 31 g / 139 g | 25 g / 111 g |
| 3 kg | 113 g dry / 500 g wet | 90 g / 400 g | 54 g / 240 g | 45 g / 200 g | 36 g / 160 g |
| 4 kg | 145 g dry / 643 g wet | 116 g / 515 g | 70 g / 310 g | 58 g / 258 g | 47 g / 207 g |
| 5 kg | 176 g dry / 780 g wet | 141 g / 624 g | 84 g / 375 g | 70 g / 312 g | 56 g / 250 g |
| 6 kg | 205 g dry / 910 g wet | 164 g / 728 g | 99 g / 437 g | 82 g / 364 g | 66 g / 291 g |

## When to switch foods

| Transition | Typical age |
|---|---|
| Puppy to adult food | Small breeds 9–12 months; medium 12–14 months; large 18 months; giant 18–24 months |
| Kitten to adult food | About 12 months (large breeds such as Maine Coons may take longer) |
| Adult to senior food | No fixed age — base it on the individual animal's health and weight, with your veterinarian |

## Notes

- These are starting points from published veterinary nutrition guidance. Individual animals vary — check the result against body condition and weight trends over 2–3 weeks.
- Large-breed puppies: use a large-breed puppy food with controlled calcium; never add calcium supplements.
- Senior diets: healthy seniors need adequate protein. Low-protein diets are a medical prescription, not a default.
- This chart is general education only and does not replace veterinary advice.
