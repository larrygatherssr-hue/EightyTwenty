# Pet Nutrition Foundations: Feed Your Dog and Cat for Lifelong Health

## A Complete Written Course Manual

---

## Important Disclaimer — Please Read First

This course is general nutrition education only. It is not veterinary advice, it does not diagnose or treat any disease, and it never replaces veterinary care or a consultation with a board-certified veterinary nutritionist. Dogs and cats with medical conditions — including kidney disease, liver disease, diabetes, pancreatitis, food allergies, gastrointestinal disease, urinary tract disease, heart disease, cancer, or any animal that is pregnant, nursing, very young, very old, underweight, or recovering from illness or surgery — need individualised feeding plans made with their veterinarian.

No food, diet, or feeding method in this course is guaranteed to prevent or cure disease, extend life, or produce any specific health outcome. Nutrition supports health; it does not guarantee it. Always transition foods gradually, monitor your pet's weight and body condition, and contact your veterinarian promptly if your pet stops eating for more than 24 hours (especially cats), vomits repeatedly, has persistent diarrhoea, loses weight unexpectedly, or shows any sign of illness.

Some foods that are safe for people are toxic to dogs and cats. A toxic-foods reference is included in Module 9 and in the templates folder. If you suspect your pet has eaten something toxic, contact your veterinarian or an animal poison control service immediately — do not wait for symptoms.

Where this course cites nutrient standards, it refers to the published nutrient profiles of AAFCO (the Association of American Feed Control Officials) and FEDIAF (the European Pet Food Industry Federation). Standards are updated over time; check the current published profiles and your local regulations for the most recent figures.

---

## Table of Contents

- Module 1 — Why Food Matters: What Nutrition Can and Cannot Do
- Module 2 — The Nutrients Dogs and Cats Need (and How Dogs and Cats Differ)
- Module 3 — Complete and Balanced: AAFCO, FEDIAF, and What the Label Statement Really Means
- Module 4 — Reading a Pet Food Label Like a Professional
- Module 5 — How Much to Feed: Calories, Portions, and Worked Examples
- Module 6 — Weight Management: Body Condition, Weight Loss, and Keeping It Off
- Module 7 — Life-Stage Feeding: Puppies, Kittens, Adults, and Seniors
- Module 8 — Treats, Chews, Table Food, and Supplements
- Module 9 — Homemade Feeding and Raw Diets: What the Evidence Actually Says
- Module 10 — Transitions, Picky Eaters, and Building Your Pet's Feeding Plan
- Appendix A — Toxic Foods Quick Reference
- Appendix B — Glossary
- Appendix C — Sources and Further Reading

---

## How to Use This Course

Work through the modules in order if you are new to pet nutrition; each one builds on the last. If you already feed a commercial food and simply want to check your portions, start with Modules 4, 5, and 6. The companion workbook (workbook.md) has an exercise for every module — doing the exercises with your own pet's numbers is where the learning becomes useful. The templates folder contains a weight-management planner, life-stage feeding charts, a safe-foods and toxic-foods reference, a label-reading guide, and a meal-planning worksheet you can print and reuse.

You do not need a science background. Every formula is worked through with real numbers, and every worked example shows each step so you can repeat it for your own dog or cat.

---

## Module 1 — Why Food Matters: What Nutrition Can and Cannot Do

Every day, twice a day, you make a decision that shapes your pet's health more than almost any other choice you control: what goes in the bowl. Food is not just fuel. It supplies the building blocks for muscle, skin, coat, bones, hormones, and immune cells. It influences energy, stool quality, body weight, and how well a pet ages. And yet feeding is also one of the most confusing parts of pet ownership, because the advice is contradictory. One source says grain-free is essential; another says it is a marketing trend. One says raw feeding is natural; another says it is dangerous. One bag promises "ancestral" nutrition; another promises "science-based" nutrition. Both cannot be right about everything, and neither tells you how much to feed your particular animal.

### What good nutrition can do

A diet that is complete and balanced for your pet's life stage, fed in the right amount, and suited to their individual needs can:

- Maintain a healthy body weight and muscle condition, which is associated with better mobility and a lower risk of weight-related problems.
- Support healthy skin and coat through adequate essential fatty acids, protein, zinc, and vitamins.
- Support normal digestion through appropriate fibre levels and highly digestible ingredients.
- Support growth in puppies and kittens at a steady, healthy rate — fast growth in large-breed puppies, in particular, is linked to skeletal problems, so controlled growth matters more than maximum growth.
- Support healthy ageing through appropriate protein, calorie control, and joint-supporting nutrients where evidence supports them.

### What good nutrition cannot do

Nutrition is powerful, but it is not medicine. Be suspicious of any food, supplement, or feeding philosophy that promises to cure disease, "detox" the body, reverse ageing, or guarantee a longer life. No diet has been shown to do those things. Claims such as "boosts immunity" or "supports kidney health" on a bag are marketing statements, not medical evidence. A diet can support normal function; it cannot repair a failing organ or replace treatment.

This distinction matters because it protects you from expensive mistakes. A pet with kidney disease does not need a "kidney support" over-the-counter food chosen from a shelf; it needs a therapeutic diet prescribed and monitored by a veterinarian. A pet with a food allergy does not need a "hypoallergenic" boutique food; it needs a properly conducted elimination diet trial under veterinary guidance. Knowing the boundary between general nutrition and medical nutrition is one of the most valuable skills in this course.

### The three questions every feeding decision should answer

Whenever you choose a food, a portion, or a feeding method, ask three questions:

1. **Is it complete and balanced for this animal's life stage?** (Module 3 shows you how to check in ten seconds.)
2. **Am I feeding the right amount of calories for this animal's weight and activity?** (Module 5 gives you the arithmetic.)
3. **Does this animal have any individual need — age, breed size, activity, health condition — that changes the answer?** (Modules 6, 7, and 10 cover this.)

If you can answer those three questions, you can ignore most of the noise in pet food marketing.

### The scale of the problem: weight

Surveys of veterinary practices in the United States and Europe consistently find that roughly half of dogs and a similar proportion of cats are above their ideal weight, and a substantial minority are clinically obese. Excess weight is the most common nutrition-related health problem in companion animals, and it is also the most preventable. It develops slowly — a few extra kibbles a day, a biscuit here, a scrap there — and owners often do not notice because they see their pet every day. Module 6 teaches you to assess body condition with your hands and eyes, and to build a weight-loss plan with real numbers.

### The scale of the problem: confusion

The pet food market offers thousands of products, and the marketing language is designed to sell, not to inform. Words like "natural," "holistic," "premium," "human-grade," and "ancestral" have no standardised legal meaning in pet food in most jurisdictions. An ingredient list that reads beautifully can still describe a diet that is unbalanced, and a diet with a plain-looking label can be excellent. Modules 3 and 4 teach you to look past the front of the bag and read the parts of the label that actually carry information.

### A note on dogs versus cats

Dogs and cats are not interchangeable. Cats are obligate carnivores with specific nutrient requirements dogs do not share; dogs are more flexible omnivores. A dog can survive — poorly — on cat food for a while, and a cat fed dog food will develop serious deficiencies. Module 2 explains exactly where the differences lie, and every worked example in this course is labelled for the species it applies to. Never feed a dog food to a cat as a staple diet, and never assume a feeding rule for dogs applies to cats.

### What you will be able to do by the end of this course

- Read any pet food label and judge whether the food is complete and balanced, and for which life stage.
- Calculate your pet's daily calorie needs and convert them into grams or cups of a specific food.
- Assess body condition score and build a safe, gradual weight-loss plan.
- Choose appropriate foods for puppies, kittens, adults, and seniors.
- Judge treats, chews, and supplements honestly, including what is worth paying for and what is not.
- Plan a safe homemade diet — or recognise when homemade feeding is not the right choice — and evaluate raw-feeding claims against the evidence.
- Know exactly when a feeding question is a veterinary question, and what to ask.

**Module 1 action step:** Weigh your pet this week and write the number down with today's date. Weigh yourself holding your pet and then alone if you do not have a pet scale, or use your veterinary clinic's scale. That single number is the starting point for almost everything in this course. Record it in the workbook (Exercise 1.1).

---

## Module 2 — The Nutrients Dogs and Cats Need (and How Dogs and Cats Differ)

All animals need the same six classes of nutrients: protein, fat, carbohydrate, vitamins, minerals, and water. What differs between species — and between life stages — is how much of each is needed, which specific nutrients are essential, and what happens when they are missing. This module gives you the working knowledge: enough to understand a label and a feeding decision, without a biochemistry degree.

### Water: the forgotten nutrient

Water is the most important nutrient and the one owners think about least. An adult dog or cat typically needs roughly 40–60 ml of water per kilogram of body weight per day from all sources (drinking water plus the moisture in food), though this varies with diet, activity, temperature, and health. A 10 kg dog therefore needs roughly 400–600 ml per day; a 4 kg cat roughly 160–240 ml.

Wet food is typically 70–80% water; dry food is typically around 8–12%. That difference matters. A cat eating only dry food and drinking little is taking in far less water than a cat eating wet food, and low water intake is a risk factor for urinary tract problems in cats. Practical steps: provide fresh water daily in a clean bowl, consider a second water station away from the food bowl (many cats prefer it), and consider a water fountain if your cat is a reluctant drinker. Never restrict water to manage urination unless your veterinarian specifically instructs it.

### Protein: building blocks, not just a percentage

Protein supplies amino acids, which build and repair muscle, skin, enzymes, hormones, and immune cells. Ten amino acids are essential for dogs; cats need eleven — they also require taurine and have a higher requirement for arginine. "Essential" means the animal cannot make it and must eat it.

Two common misunderstandings deserve attention. First, the protein percentage on a label tells you nothing about protein quality. Quality depends on the amino acid profile and digestibility — whether the protein contains the essential amino acids in the right proportions and whether the animal can actually absorb them. Animal-source proteins (meat, fish, egg) generally have more complete amino acid profiles for dogs and cats than most plant proteins, though well-formulated diets can combine plant proteins to cover the gaps. Second, more protein is not automatically better. Healthy adult dogs and cats need adequate protein, not maximum protein. Very high-protein diets are not harmful to healthy kidneys — that is a persistent myth — but excess protein is simply burned for energy or excreted, and it costs more. Animals with kidney disease do need controlled protein, but that is a medical decision, not a reason to restrict protein in a healthy pet.

AAFCO minimums (adult maintenance, dry matter basis) are about 18% protein for dogs and 25–26% for cats; growth and reproduction minimums are higher (about 22.5% for dogs, 30% for cats). Most commercial foods exceed these minimums comfortably. If a food is close to the minimum and your pet is very active, growing, or recovering, discuss it with your veterinarian.

### Fat: energy, essential fatty acids, and palatability

Fat is the most concentrated energy source in food — about 8.5 kcal of metabolisable energy per gram, compared with about 3.5 kcal per gram for protein and carbohydrate. Fat carries fat-soluble vitamins, supplies essential fatty acids, and makes food taste good.

The essential fatty acids are linoleic acid (omega-6), needed by both dogs and cats, and arachidonic acid, which cats cannot make in sufficient amounts and must obtain from animal fat. Alpha-linolenic acid (omega-3, from plants) can be converted to EPA and DHA by dogs to some extent, but cats convert it very poorly — cats need preformed EPA and DHA from fish oil or similar sources. This is one reason fish oil is a legitimate supplement for cats, while flaxseed oil is a poor substitute for them.

Fat content on labels varies enormously, from around 8% to over 20% on a dry matter basis. High-fat foods are energy-dense: a small volume carries many calories, which makes overfeeding easy. Low-fat foods can help weight management, but fat also carries flavour — very low-fat foods may be refused. There is no single right fat level; it depends on the animal's calorie needs and tolerance. Dogs prone to pancreatitis need low-fat diets, and that restriction should be set with a veterinarian.

### Carbohydrate: useful, not essential — with one important exception

Dogs and cats have no dietary requirement for carbohydrate as such; they can make glucose from protein and fat. But carbohydrate is a useful, economical energy source, and cooked starch is highly digestible for dogs (over 90%) and reasonably digestible for cats. Fibre — a type of carbohydrate — is genuinely useful: it supports gut health, feeds beneficial gut bacteria, adds bulk that helps satiety in weight management, and can help manage hairballs and stool quality in cats.

Grains are not inherently good or bad. Rice, oats, barley, and corn are well-digested by most dogs and cats when cooked, and they contribute energy and some nutrients. Grain-free diets are not automatically healthier; they typically replace grains with potatoes, peas, or lentils, which are also carbohydrates. The choice between grain-inclusive and grain-free should be based on the individual animal (a genuine grain allergy is rare, but it does exist) and on the overall formulation — not on the marketing claim.

### Vitamins and minerals: small amounts, large consequences

Vitamins and minerals are needed in tiny amounts, but deficiencies and excesses both cause real disease. The ones owners most often encounter are:

- **Calcium and phosphorus:** essential for bones and teeth, and the ratio matters as much as the amount. Growing large-breed puppies are especially sensitive: excess calcium is linked to skeletal disease in large and giant breeds. This is why large-breed puppy foods exist and why you should not add calcium supplements to a balanced puppy diet.
- **Taurine:** essential for cats — deficiency causes a serious heart condition (dilated cardiomyopathy) and retinal degeneration leading to blindness. Dogs can synthesise taurine, though certain breeds and diets have been associated with taurine-related heart disease; this is an area to discuss with your veterinarian, not to self-supplement.
- **Vitamin A:** cats cannot convert beta-carotene from plants into vitamin A; they need preformed vitamin A from animal sources. Dogs can convert beta-carotene.
- **Vitamin D:** dogs and cats cannot make enough vitamin D from sunlight the way people can; they need it in the diet. Both deficiency and excess cause disease, which is why vitamin D is one of the nutrients with a defined maximum in AAFCO profiles.
- **Zinc, iron, iodine, selenium:** trace minerals with narrow safe ranges; balanced commercial foods cover them, and supplementation without a diagnosed deficiency risks doing harm.

The practical lesson is simple: if the diet is complete and balanced, do not add vitamin or mineral supplements. More is not better, and several nutrients are toxic in excess.

### Dogs versus cats: the essential differences

| Feature | Dogs | Cats |
|---|---|---|
| Dietary classification | Flexible omnivore | Obligate carnivore |
| Protein requirement | Lower (18% adult minimum) | Higher (25–26% adult minimum) |
| Taurine | Can synthesise | Essential in diet |
| Arginine | Required, lower need | Required, higher need — deficiency can cause serious illness quickly |
| Vitamin A | Can convert beta-carotene | Needs preformed vitamin A |
| Arachidonic acid | Can synthesise | Needs dietary source |
| Carbohydrate handling | Digests cooked starch well | Digests cooked starch moderately; high-carb diets not ideal |
| Feeding pattern | Typically 1–2 meals a day | Naturally eats many small meals |

### Worked example 2.1 — Water needs

A 6 kg cat: 6 × 40 ml = 240 ml at the low end; 6 × 60 ml = 360 ml at the high end. If she eats 200 g of wet food per day at 75% moisture, the food alone supplies 150 ml of water, leaving 90–210 ml to be drunk. If the same cat ate only dry food (10% moisture), 60 g of dry food supplies only 6 ml of water, and she must drink nearly all 240–360 ml. This is why wet food or added water is worth considering for cats with a history of urinary problems, and why a cat that "never drinks" on a wet diet may actually be adequately hydrated.

### Key takeaways

- Dogs and cats need the same nutrient classes in different proportions and with different essentials.
- Protein quality matters more than protein percentage.
- Fat is energy-dense and carries essential fatty acids; cats specifically need arachidonic acid and preformed EPA/DHA.
- Carbohydrate is not essential but is useful; grains are not the enemy.
- Do not supplement a complete and balanced diet with vitamins or minerals unless a veterinarian identifies a deficiency.

**Module 2 action step:** Check your current food's guaranteed analysis for protein and fat percentages and write them down. You will convert them to a dry matter basis in Module 4.

---

## Module 3 — Complete and Balanced: AAFCO, FEDIAF, and What the Label Statement Really Means

The single most useful sentence on any bag or can of pet food is the nutritional adequacy statement — usually printed in small type on the back. Learning to find and read it takes ten seconds, and it tells you whether the food is a complete diet or merely a snack, treat, or supplement.

### What "complete and balanced" means

A complete and balanced food contains all the nutrients a pet needs, in the right proportions, for a stated life stage, when fed as the sole diet (apart from water). It is not a marketing claim; in the United States it is a claim tied to AAFCO nutrient profiles or feeding trials, and in Europe to FEDIAF nutritional guidelines. A food that is not complete and balanced must say so — typically with a statement such as "for intermittent or supplemental feeding only."

### The adequacy statement: what to look for

On a US label, look for wording like:

> "[Brand] [Product] is formulated to meet the nutritional levels established by the AAFCO Dog (or Cat) Food Nutrient Profiles for [maintenance / growth / all life stages / gestation and lactation]."

Or:

> "Animal feeding tests using AAFCO procedures substantiate that [product] provides complete and balanced nutrition for [life stage]."

Both routes are legitimate. The formulation route means the recipe was designed to meet the published nutrient minimums and maximums. The feeding-trial route means the food was actually fed to animals under controlled conditions and they thrived. Feeding trials are more expensive and less common, and they are arguably stronger evidence — but a well-formulated food from a reputable manufacturer is also a sound choice. What matters is that one of these statements is present.

In Europe, look for a statement that the food is a "complete" pet food for a stated life stage, formulated to FEDIAF guidelines. The word "complete" on a European label carries the same weight as the AAFCO statement in the US.

### Life stages: what the statement covers

- **Maintenance / adult:** for healthy adult animals that are not growing, pregnant, or nursing.
- **Growth / growth and reproduction:** for puppies, kittens, pregnant, and nursing animals. These foods are higher in protein, fat, calcium, and energy.
- **All life stages:** meets the requirements for growth and reproduction, which are the most demanding — so it also covers adults. This is convenient, but it means the food is relatively energy- and nutrient-dense, which can make portion control more important for a sedentary adult.
- **Intermittent or supplemental feeding only:** not a complete diet. This is the correct label for many treats, toppers, raw grinds without balancing, and some wet foods designed as mixers. Never feed a "supplemental" product as the sole diet.

A red flag: a food with no adequacy statement at all. That usually means it is a treat, topper, or supplement — or that it comes from a manufacturer not following the labelling framework. Do not feed it as a staple diet.

### What AAFCO is — and is not

AAFCO is an association of feed control officials; it publishes nutrient profiles and labelling guidelines, but it does not test, approve, or certify pet foods, and it does not inspect manufacturing plants. A food that "meets AAFCO profiles" has been formulated — or tested — against a published standard. That is meaningful, but it is not a guarantee of ingredient quality, digestibility, manufacturing hygiene, or palatability. Those depend on the manufacturer. This is why the reputation and quality-control practices of the manufacturer matter, and why the cheapest food that meets the profile is not automatically equal to a more expensive one — though the most expensive food is not automatically better either.

FEDIAF plays the equivalent role in Europe, publishing nutritional guidelines used by manufacturers across the EU. The numbers differ slightly from AAFCO's, but the concept is identical.

### Questions to ask about a manufacturer

Because the label cannot tell you everything, consider asking the manufacturer — by email or through their website — these questions:

1. Do you employ a full-time board-certified veterinary nutritionist or a PhD animal nutritionist?
2. Do you conduct feeding trials, or only formulate to profiles?
3. Where is the food manufactured, and do you own the plant or use a co-packer?
4. What quality-control testing do you run on incoming ingredients and finished products?
5. Can you provide the full typical nutrient analysis (not just the guaranteed analysis) and the calorie content?

A reputable company answers these readily. Evasive or absent answers are information too.

### Common label claims, translated

- **"Natural":** generally means the ingredients are derived from plant, animal, or mined sources without synthetic processing, with some exceptions for vitamins and minerals. It says nothing about nutritional adequacy.
- **"Holistic":** has no legal definition in pet food. It is marketing language.
- **"Premium" / "Super-premium":** no legal definition. Marketing language.
- **"Human-grade":** has a specific legal meaning in the US — every ingredient and the finished product must be handled and manufactured to human food standards. It is a legitimate claim when used properly, but it does not mean the food is nutritionally better.
- **"Vet recommended" / "Vet formulated":** unregulated in most places. It can mean anything from "a veterinarian reviewed the recipe" to "we asked a vet once." Ask which veterinarian and what their qualifications are.
- **"No fillers":** "filler" has no legal definition. Ingredients labelled as fillers — often corn or grains — do contribute nutrients.
- **"Grain-free":** describes what is absent, not what is present. Grain-free foods replace grains with other carbohydrates.
- **"By-product free":** by-products (organ meats, for example) are nutritious and normal parts of animal diets. Avoiding them is a preference, not a nutritional advantage.

### Key takeaways

- Find the adequacy statement before anything else. No statement, no staple diet.
- Match the life stage on the statement to your animal.
- "Complete" is a regulated concept; "natural," "holistic," and "premium" are not.
- AAFCO and FEDIAF set nutrient standards; they do not certify or approve individual foods.

**Module 3 action step:** Find the adequacy statement on your current food and copy it into the workbook (Exercise 3.1). Note the life stage it covers and whether it was established by formulation or by feeding trials.

---

## Module 4 — Reading a Pet Food Label Like a Professional

The front of the bag is advertising. The back of the bag is information. This module teaches you to read the four parts that matter: the ingredient list, the guaranteed analysis, the calorie statement, and the feeding directions — and to convert the numbers so you can compare foods fairly.

### The ingredient list: what order means — and what it does not

Ingredients are listed in descending order by weight as added, including the water in fresh ingredients. That is why fresh chicken often appears first: chicken is about 70% water, so once the food is dried, the actual chicken content is much lower than the first-place listing suggests. "Chicken meal," by contrast, is already rendered and concentrated, so it contributes more protein per gram. Neither is automatically better — but the order can mislead.

Other points:

- **Ingredient splitting:** a manufacturer can split one ingredient into parts (for example, "peas," "pea protein," and "pea fibre") so each appears lower on the list. This is legal and common. Read the whole list, not just the first three ingredients.
- **Named versus generic:** "chicken" is more informative than "meat" or "poultry." Named ingredients allow you to identify the protein source, which matters for allergies and for judging quality.
- **By-products:** named by-products such as "chicken by-product meal" include organ meats, which are nutrient-rich. The word "by-product" sounds unappealing, but nutritionally it is not a mark of low quality. What matters is whether the by-products are named and the overall diet is balanced.
- **The first ingredient is not the whole story:** a food whose first ingredient is chicken but which is then mostly rice is not a high-meat food. Judge the diet by its nutrient analysis and adequacy statement, not by the first ingredient.

### The guaranteed analysis: minimums and maximums

The guaranteed analysis lists minimum percentages of crude protein and crude fat, and maximum percentages of crude fibre and moisture. Note the words: protein and fat are guaranteed minimums — the food contains at least that much. Fibre and moisture are maximums. The actual values are usually a little higher for protein and fat, and a little lower for fibre and moisture.

"Crude" protein is a measure of nitrogen, not a measure of usable amino acids. Two foods with the same crude protein percentage can differ in protein quality and digestibility. The guaranteed analysis is a legal guarantee, not a full nutritional picture. For the full picture, ask the manufacturer for the typical (as-fed) analysis.

### The dry matter basis: the only fair comparison

You cannot compare a wet food at 10% protein with a dry food at 26% protein directly, because the wet food is mostly water. To compare fairly, convert both to a dry matter basis — the nutrient percentage with all the water removed.

**Formula:** Dry matter % = 100 − moisture %. Nutrient on dry matter basis = (nutrient % ÷ dry matter %) × 100.

**Worked example 4.1 — Comparing a wet food and a dry food**

Wet food: 10% protein, 78% moisture. Dry matter = 100 − 78 = 22%. Protein on a dry matter basis = (10 ÷ 22) × 100 = 45.5%.

Dry food: 26% protein, 10% moisture. Dry matter = 100 − 10 = 90%. Protein on a dry matter basis = (26 ÷ 90) × 100 = 28.9%.

The wet food, which looked low in protein, is actually much higher in protein on a dry matter basis. This is normal: wet foods are usually higher in protein and fat and lower in carbohydrate on a dry matter basis than dry foods. Neither is better by definition — but now you can compare them honestly.

**Worked example 4.2 — Two dry foods with different moisture**

Food A: 30% protein, 12% moisture. Dry matter = 88%. Protein DMB = (30 ÷ 88) × 100 = 34.1%.
Food B: 28% protein, 8% moisture. Dry matter = 92%. Protein DMB = (28 ÷ 92) × 100 = 30.4%.

Food A is higher in protein even though the gap on the label looked small. Run this calculation whenever you compare foods, and keep a note of it in the workbook (Exercise 4.1).

### The calorie statement

In the US, pet food labels must carry a calorie content statement (kcal per kg and per cup or per can). In Europe it is increasingly common but not always present; if it is missing, ask the manufacturer. The calorie statement is the bridge between the label and the portion in the bowl — Module 5 shows you how to use it.

Beware of cup measurements: a "cup" of one kibble can weigh 85 g and a cup of another 120 g, because kibble size and density differ. Weighing food on a kitchen scale is always more accurate than a measuring cup. A cheap digital kitchen scale is one of the best investments in this course.

### Feeding directions: a starting point, not a prescription

Feeding directions on the bag are averages for a typical animal of a given weight. Your animal may need 20% more or 20% less depending on activity, metabolism, neuter status, and environment. Treat the bag's directions as a starting point, feed that amount for two to three weeks, weigh your pet, assess body condition (Module 6), and adjust. The bag cannot know your pet; you can.

### A five-minute label audit

For any food, run this check:

1. Adequacy statement present? Which life stage? Formulation or feeding trial?
2. Named protein source in the first few ingredients?
3. Protein and fat on a dry matter basis — do they fit your pet's needs?
4. Calorie content stated? How many kcal per cup or per 100 g?
5. Feeding directions — what weight range does your pet fall into, and does the amount look plausible?
6. Expiry date and batch code present, packaging intact?

If a food fails step 1, stop there. If it passes, the rest is fine-tuning.

**Module 4 action step:** Run the label audit on your current food and on one food you are considering. Convert both to a dry matter basis and record the results in the workbook (Exercise 4.2).

---

## Module 5 — How Much to Feed: Calories, Portions, and Worked Examples

This is the module that saves the most money and prevents the most weight gain. Most owners overfeed, not because they are careless but because they have never been given the numbers. This module gives them to you, step by step, with worked examples for dogs and cats of different sizes.

### The two numbers that matter: RER and MER

**Resting Energy Requirement (RER)** is the energy an animal needs at rest in a thermoneutral environment — essentially the cost of staying alive. It is calculated from body weight:

**RER (kcal/day) = 70 × (body weight in kg)^0.75**

For animals between about 2 and 45 kg, a simpler linear approximation is widely used: **RER = (30 × body weight in kg) + 70**. The two formulas agree closely in that range; outside it, use the exponential formula. This course uses the exponential formula in worked examples and gives you the linear shortcut for everyday use.

**Maintenance Energy Requirement (MER)** is what the animal actually needs each day, and it equals RER multiplied by a factor that reflects life stage and activity:

| Situation | MER factor × RER |
|---|---|
| Neutered adult dog | 1.6 |
| Intact adult dog | 1.8 |
| Inactive or obesity-prone adult dog | 1.4 |
| Active / working dog | 2.0–5.0 |
| Weight-loss dog | 1.0 |
| Puppy, under 4 months | 3.0 |
| Puppy, 4 months to adult | 2.0 |
| Neutered adult cat | 1.2 |
| Intact adult cat | 1.4 |
| Inactive or obesity-prone adult cat | 1.0 |
| Active adult cat | 1.4 |
| Weight-loss cat | 0.8 |
| Kitten, under 4 months | 2.5 |
| Kitten, 4 months to adult | 2.0 |
| Pregnant queen or bitch | 2.0 (rising to 3.0–4.0 in late pregnancy) |
| Lactating queen or bitch | 2.0–4.0+ (up to 4–8× RER at peak lactation for large litters) |

These factors are starting points from published veterinary nutrition guidance. Individual animals vary; always check the result against body condition and weight trends over two to three weeks.

### How to do the calculation

Step 1: Weigh your pet in kilograms. (Pounds ÷ 2.2 = kilograms.)
Step 2: Calculate RER: 70 × (weight in kg)^0.75. If you do not have a calculator with a power function, use the linear shortcut (30 × kg + 70) for animals between 2 and 45 kg.
Step 3: Multiply RER by the MER factor for your pet's situation.
Step 4: Convert daily calories into grams of food: grams per day = daily kcal ÷ (kcal per gram of food). The kcal per gram comes from the label's calorie statement (kcal per kg ÷ 1,000) or the manufacturer's data.
Step 5: Divide by the number of meals per day. Subtract the calories of any treats from the daily total — treats come out of the food allowance, not on top of it.

### Worked example 5.1 — A neutered adult dog, 20 kg

RER = 70 × 20^0.75. 20^0.75 ≈ 9.46. RER ≈ 70 × 9.46 ≈ 662 kcal/day.
MER = 662 × 1.6 (neutered adult) ≈ 1,059 kcal/day.
His food states 3,600 kcal/kg, which is 3.6 kcal per gram. Grams per day = 1,059 ÷ 3.6 ≈ 294 g per day, or about 147 g per meal if fed twice daily.
Check against the bag: if the bag suggests 300–340 g for a 20 kg dog, our calculation sits at the low end of the range — consistent with a neutered, moderately active dog. If he gains weight at 294 g, reduce by 10% (to about 265 g) and reassess in three weeks.

### Worked example 5.2 — A small active dog, 8 kg

RER = 70 × 8^0.75. 8^0.75 ≈ 4.76. RER ≈ 70 × 4.76 ≈ 333 kcal/day.
MER = 333 × 1.8 (intact, active adult) ≈ 600 kcal/day.
Her food states 3,800 kcal/kg = 3.8 kcal/g. Grams per day = 600 ÷ 3.8 ≈ 158 g per day.
If the owner was previously feeding a "cup and a half" from a measuring cup that holds 120 g per cup, she was getting 180 g — about 684 kcal, or 14% over her needs. That 14% surplus, sustained, is roughly 1 kg of weight gain over a year for a small dog. Small errors matter more in small animals.

### Worked example 5.3 — A large dog, 40 kg

RER = 70 × 40^0.75. 40^0.75 ≈ 15.9. RER ≈ 70 × 15.9 ≈ 1,113 kcal/day.
MER = 1,113 × 1.6 (neutered adult) ≈ 1,781 kcal/day.
Food at 3,500 kcal/kg = 3.5 kcal/g. Grams per day = 1,781 ÷ 3.5 ≈ 509 g per day.
Note how the linear shortcut compares: (30 × 40) + 70 = 1,270 kcal RER, which is higher than the exponential result — the linear formula overestimates at larger weights, which is why the exponential formula is preferred above 30 kg.

### Worked example 5.4 — A neutered adult cat, 4.5 kg

RER = 70 × 4.5^0.75. 4.5^0.75 ≈ 3.09. RER ≈ 70 × 3.09 ≈ 216 kcal/day.
MER = 216 × 1.2 (neutered adult cat) ≈ 260 kcal/day.
She eats wet food at 90 kcal per 100 g (0.9 kcal/g). Grams per day = 260 ÷ 0.9 ≈ 289 g per day — roughly three and a half 85 g pouches, or one 400 g can is too much. If she eats dry food at 3,900 kcal/kg (3.9 kcal/g), she needs only 260 ÷ 3.9 ≈ 67 g per day — a small-looking amount that surprises many owners, which is exactly why dry food is so easy to overfeed. Weigh it.

### Worked example 5.5 — An overweight cat, 6 kg, target weight 5 kg

This is the most important rule in the module: **calculate RER from the target weight, not the current weight.** Using the current weight would maintain the excess.
Target weight 5 kg: RER = 70 × 5^0.75. 5^0.75 ≈ 3.34. RER ≈ 234 kcal/day.
Weight-loss MER = 234 × 0.8 ≈ 187 kcal/day. (See Module 6 for the full weight-loss plan.)
On dry food at 3,600 kcal/kg (3.6 kcal/g), that is 187 ÷ 3.6 ≈ 52 g per day. On wet food at 85 kcal per 100 g, it is 187 ÷ 0.85 ≈ 220 g per day.
The owner who was "free-feeding" dry food and refilling the bowl may have been offering 350–400 kcal a day — double the weight-loss target. The gap explains the weight gain, and closing it is the whole plan.

### Worked example 5.6 — Cost comparison: wet versus dry

A 10 kg neutered dog needs about 1.6 × RER. RER = 70 × 10^0.75 ≈ 70 × 5.62 ≈ 394 kcal. MER ≈ 630 kcal/day.
Dry food: 3,600 kcal/kg at £12 (or $15) per 3 kg bag = £4.00/kg. Daily cost = 630 ÷ 3,600 × 4.00 ≈ £0.70 per day.
Wet food: 90 kcal per 100 g at £1.10 per 400 g can = £2.75/kg. Daily food needed = 630 ÷ 0.9 = 700 g. Daily cost = 0.7 × 2.75 ≈ £1.93 per day.
Mixed feeding (half the calories from each): about £1.31 per day.
The point is not that one is better — wet food has real advantages for hydration and palatability — but that the cost difference is large and worth knowing before you commit. Run this comparison with your own food prices using the worksheet in the workbook (Exercise 5.3). Prices vary by country and retailer; the method is what matters.

### Treats and the 10% rule

Treats, chews, table scraps, and food used for training should together provide no more than 10% of daily calories. For the 20 kg dog in Example 5.1, that is about 106 kcal of treats per day at most — roughly two medium commercial dog biscuits (about 25–30 kcal each) plus a small training treat allowance, not a handful of biscuits plus a dental chew (often 50–90 kcal) plus table scraps. For the 4.5 kg cat in Example 5.4, 10% is 26 kcal — about 5–6 small commercial cat treats at 4–5 kcal each. Measure treats into a daily jar in the morning; when the jar is empty, treats are finished for the day.

### Why measuring cups fail

Kibble density varies widely. One cup can weigh anywhere from 80 to 130 g depending on kibble size, shape, and the food's formulation. A "cup" that the owner believes is 100 g but is actually 125 g delivers 25% more calories every single day. Over a year, that is the difference between a healthy weight and obesity in many animals. A digital kitchen scale costs little, takes ten seconds, and removes the largest single source of feeding error. If you buy one thing after this course, buy a kitchen scale.

### When the numbers do not match reality

If your calculated portion causes steady weight gain over three weeks, the calculation is not wrong — the inputs are. Either the animal's true energy need is lower than the factor suggests (common in neutered, indoor, or older animals), the food's calorie content differs from the label, or uncounted calories are entering the diet (treats, scraps, another family member feeding, a neighbour, food stolen from another pet's bowl). Reduce the portion by 10%, audit the extras, and reassess in three weeks. If your calculated portion causes weight loss in an animal that should be maintaining, increase by 10% and reassess. The formula is the starting point; the scale and the body condition score are the verdict.

**Module 5 action step:** Calculate your pet's RER and MER, convert to grams of their current food, and compare with what you have actually been feeding. Record both numbers in the workbook (Exercise 5.1).

---

## Module 6 — Weight Management: Body Condition, Weight Loss, and Keeping It Off

Weight management is the highest-value skill in this course. It is also the area where good intentions most often fail, because owners rely on the scale alone, cut food too drastically, or give up after a plateau. This module gives you a structured, humane method.

### How to assess body condition score (BCS)

Body condition score is a 9-point scale used by veterinarians (a 5-point scale is also used; this course uses the 9-point scale because it is more precise). Ideal is 4–5 out of 9.

- **BCS 1–3 (underweight):** Ribs, spine, and hip bones easily visible with no fat cover; obvious waist and abdominal tuck; muscle loss may be visible.
- **BCS 4–5 (ideal):** Ribs easily felt with a thin layer of fat over them, not visible at rest; waist visible from above; abdominal tuck visible from the side.
- **BCS 6–7 (overweight):** Ribs felt only with pressure; waist barely visible or absent; fat deposits over the hips and base of the tail; abdominal tuck reduced.
- **BCS 8–9 (obese):** Ribs very difficult to feel under thick fat; no waist; no abdominal tuck; fat deposits on the neck, limbs, and abdomen; the animal may have difficulty moving comfortably.

Assess with your hands, not just your eyes — long coats hide a great deal. Run your fingers lightly over the ribs: you should feel each rib under a thin fat layer, the way you feel your knuckles through the back of your hand. If you have to press firmly, there is too much fat. If the ribs feel like the knuckles of a clenched fist, the animal may be too thin.

Ask your veterinarian to confirm your assessment at the next visit and to agree a target weight. The target weight is essential: without it, you cannot calculate a weight-loss ration (Module 5, Example 5.5).

### How fast should weight come off?

Safe weight loss is **1–2% of body weight per month for dogs** and **0.5–2% of body weight per month for cats**. Faster loss risks muscle loss and, in cats, a serious liver condition called hepatic lipidosis (fatty liver disease), which can develop when an overweight cat stops eating or eats far too little. **Never starve a cat, and never let a cat go without food for more than 24 hours.** If an overweight cat refuses food, contact your veterinarian the same day.

At 1% per month, a 30 kg dog loses 0.3 kg per month and reaches a 27 kg target in about ten months. That sounds slow, and it is — deliberately. Slow loss preserves muscle, is sustainable, and is far more likely to stay off. Crash diets fail in pets exactly as they fail in people.

### Building a weight-loss plan: worked example 6.1

**Patient:** a neutered male Labrador, currently 38 kg, target weight 32 kg, eating a standard dry food at 3,500 kcal/kg.

Step 1 — Target weight RER: 70 × 32^0.75. 32^0.75 ≈ 13.45. RER ≈ 942 kcal/day.
Step 2 — Weight-loss MER: 942 × 1.0 = 942 kcal/day. (For dogs, a factor of 1.0 × RER at target weight is a standard starting point; some plans start at 0.8–1.0. If no loss after a month, reduce to 0.8 × RER at target weight, i.e. 754 kcal.)
Step 3 — Food amount: 942 ÷ 3.5 kcal/g ≈ 269 g per day, split into two meals of about 135 g.
Step 4 — Treats: no more than 10% of 942 kcal = 94 kcal. In practice, use part of the daily kibble allowance as treats, or low-calorie options such as carrot pieces or cucumber (dogs only; check the safe-foods reference).
Step 5 — Weigh every two weeks on the same scale. Expect about 0.3–0.7 kg loss per month. If weight is static for a month, reduce food by 10% (to about 242 g) and reassess.
Step 6 — Exercise: increase gradually. For this dog, two 20-minute walks a day, building to longer walks as fitness improves. Never start an obese, unfit animal on intense exercise — build up over weeks, and check with your veterinarian if the dog has joint disease or breathing problems.
Step 7 — Maintenance: once the target weight is reached, recalculate MER at the new weight with the neutered adult factor (1.6 × RER): 942 × 1.6 ≈ 1,507 kcal/day, or about 430 g of this food. Increase food gradually over two to three weeks to the maintenance amount, and keep weighing monthly. Most weight regain happens in the first six months after the target is reached — that is when monitoring matters most.

### Building a weight-loss plan: worked example 6.2

**Patient:** a neutered female domestic shorthair cat, currently 6.5 kg, target weight 5 kg, eating wet food at 85 kcal per 100 g.

Step 1 — Target weight RER: 70 × 5^0.75 ≈ 234 kcal/day.
Step 2 — Weight-loss MER: 234 × 0.8 = 187 kcal/day.
Step 3 — Food amount: 187 ÷ 0.85 ≈ 220 g of wet food per day, split into three or four small meals (cats do well on multiple small meals).
Step 4 — Treats: maximum 19 kcal per day — about four small cat treats. Use play, grooming, or attention as rewards instead where possible.
Step 5 — Weigh every two weeks. Expect 0.03–0.13 kg loss per month. If she loses nothing in a month, reduce to 170 kcal/day and reassess — but never below the point where she eats reliably every day. A cat that stops eating is an emergency, not a diet success.
Step 6 — Activity: two or three 5–10 minute interactive play sessions a day with a wand toy; food puzzle feeders to slow eating and add activity.
Step 7 — Maintenance at 5 kg: MER = 234 × 1.2 ≈ 281 kcal/day, or about 330 g of wet food. Increase gradually and weigh monthly.

### Practical tactics that make weight loss work

- **Weigh the food, every meal.** Eyeballing portions is how weight creeps back.
- **One feeder.** In multi-pet households, feed pets separately or supervise meals so the overweight animal cannot finish the other's bowl. Microchip-activated feeders exist for cats and are worth considering.
- **Pre-portion the day.** Put the whole day's food (including treats) in a container each morning. When it is empty, feeding is done.
- **Use the kibble as treats.** Take the treat allowance from the daily ration instead of adding treats on top.
- **Add bulk, not calories.** For dogs, a small amount of low-calorie vegetables (green beans, carrot, cucumber) can add volume. For cats, this is less useful — cats are less motivated by bulk and more by palatability.
- **Slow feeders and puzzle feeders.** They extend mealtimes, reduce gulping, and add mental stimulation. Especially valuable for cats and for dogs that eat in seconds.
- **Record everything.** The weight tracker in the workbook (Exercise 6.1) takes two minutes a fortnight and is the difference between a plan and a wish.
- **Involve the whole household.** A weight-loss plan fails if one family member is secretly giving scraps. Agree the rules together, in writing, on the fridge.

### Weight-management diets: when a special food helps

Therapeutic weight-management diets are formulated to be lower in calories per gram and higher in fibre and protein, so the animal can eat a satisfying volume while taking in fewer calories. They are worth considering when the calculated portion of a standard food is very small (which leaves the animal hungry and the owner guilty) or when previous attempts have stalled. They are not magic — the calorie arithmetic still applies — but they make the arithmetic easier to live with. Ask your veterinarian whether a weight-management diet suits your pet; do not simply pick a "light" food off the shelf, as "light" is not a regulated term and some light foods are barely lower in calories than the standard version.

### What about underweight pets?

Unintentional weight loss is a medical symptom, not a feeding problem to solve by adding food. If your pet is losing weight without a change in diet, or cannot gain weight despite eating well, see your veterinarian before changing the diet. Causes range from dental disease and parasites to thyroid disease, diabetes, kidney disease, and cancer. Once medical causes are ruled out, your veterinarian can advise on a higher-calorie diet and feeding frequency.

### Key takeaways

- Assess body condition with your hands; aim for BCS 4–5 out of 9.
- Lose weight slowly: 1–2% of body weight per month for dogs, 0.5–2% for cats.
- Calculate the ration from target weight, not current weight.
- Never starve a cat; a cat that stops eating needs a veterinarian the same day.
- Maintenance after weight loss is a permanent change, not a return to old habits.

**Module 6 action step:** Score your pet's body condition, agree a target weight with your veterinarian if your pet is above ideal, and start the weight tracker in the workbook (Exercise 6.1).

---

## Module 7 — Life-Stage Feeding: Puppies, Kittens, Adults, and Seniors

Nutrient needs change across a pet's life more than at any other time. A food that is perfect for a two-year-old dog can be wrong for a two-month-old puppy and wrong again for a fourteen-year-old senior. This module works through each stage with numbers.

### Puppies: growth is a controlled process, not a race

Puppies need more protein, fat, calcium, phosphorus, and energy per kilogram than adults, and they need food formulated for growth. The single most important principle for puppies — especially medium, large, and giant breeds — is **controlled growth**. Puppies that grow too fast, or that are overfed, are at higher risk of developmental skeletal disease, including hip dysplasia and osteochondrosis. A lean puppy with a visible waist is a healthy puppy; a roly-poly puppy is not "cute and well fed," it is overfed.

**Feeding amounts.** Use the MER factors from Module 5: puppies under four months need about 3.0 × RER; from four months to adulthood, about 2.0 × RER. The RER should be calculated from the puppy's *current* weight and recalculated every two weeks, because puppies grow fast.

**Worked example 7.1 — A 12-week-old Labrador puppy, 10 kg**

RER = 70 × 10^0.75 ≈ 70 × 5.62 ≈ 394 kcal/day.
MER = 394 × 3.0 ≈ 1,182 kcal/day.
Food: a growth diet at 3,900 kcal/kg = 3.9 kcal/g. Grams per day = 1,182 ÷ 3.9 ≈ 303 g per day, split into three or four meals.
At six months, suppose he weighs 22 kg. RER = 70 × 22^0.75 ≈ 70 × 10.15 ≈ 711 kcal. MER = 711 × 2.0 ≈ 1,422 kcal/day, or about 365 g of the same food, now in two or three meals. Notice the total food rises even as the multiplier falls, because the animal is bigger.

**Large and giant breeds.** Large-breed puppy foods are formulated with controlled calcium levels and a slightly lower energy density to slow growth to a safe rate. If you have a puppy whose adult weight will exceed about 25 kg, feed a food specifically labelled for large-breed puppies, and do not add calcium supplements — excess calcium is a known risk factor for skeletal disease in these breeds. Small-breed puppies, by contrast, reach adult size quickly and have high energy needs per kilogram; a small-breed puppy food with smaller kibble and higher energy density suits them.

**Meal frequency for puppies:** under three months, four meals a day; three to six months, three meals a day; over six months, two meals a day. Regular meals support steady growth and help with house training.

**When to switch to adult food:** small breeds at about 9–12 months; medium breeds at about 12–14 months; large breeds at about 18 months; giant breeds at about 18–24 months. Switch gradually (Module 10) and recalculate the portion for adult maintenance.

### Kittens: rapid growth, high protein, frequent meals

Kittens double or triple their birth weight in the first weeks and grow astonishingly fast. They need a growth diet (kitten food) that is high in protein and fat and rich in DHA, an omega-3 fatty acid important for brain and eye development.

**Worked example 7.2 — A 4-month-old kitten, 2 kg**

RER = 70 × 2^0.75. 2^0.75 ≈ 1.68. RER ≈ 118 kcal/day.
MER = 118 × 2.0 ≈ 236 kcal/day.
Wet kitten food at 95 kcal per 100 g: 236 ÷ 0.95 ≈ 248 g per day, split into three or four small meals. Dry kitten food at 4,000 kcal/kg: 236 ÷ 4.0 = 59 g per day.
Kittens under six months should be fed three to four times a day; many owners leave measured amounts available rather than free-feeding unlimited dry food, which makes it hard to monitor intake. At about twelve months, most cats can move to an adult food, though large breeds such as Maine Coons mature more slowly and may benefit from a growth diet for longer — ask your veterinarian.

**A warning about weaning and early feeding:** kittens should stay with their mother until at least eight weeks, and orphaned kittens need a proper milk replacer, never cow's milk. Cow's milk is not a substitute for kitten milk replacer and commonly causes diarrhoea.

### Adult maintenance: the long middle

For healthy adults, the goal is simple: maintain ideal body weight and condition on a complete and balanced adult food. Most adult dogs do well on two meals a day; most adult cats do well on two to four small meals, or on a measured amount offered across the day. There is no benefit to feeding an adult animal a growth diet — it is unnecessarily energy-dense and makes weight gain more likely.

Neutering lowers energy needs by roughly 20–30% in both dogs and cats. The single most common feeding error after neutering is continuing the same portion. Reduce the portion by about 20% at neutering (or switch to a food formulated for neutered animals) and monitor weight for the following three months. The MER factors in Module 5 already reflect this: neutered adults use lower multipliers than intact adults.

### Seniors: age is not a disease, but needs do change

"Senior" is not a single life stage. A healthy seven-year-old Labrador and a frail fourteen-year-old cat have very different needs. The honest summary of the evidence is:

- **Protein:** healthy senior dogs and cats generally need *at least* as much protein as younger adults, and possibly more, to maintain muscle mass. The old idea that all seniors need low-protein diets is outdated and wrong for healthy animals. Low protein is a medical prescription for specific diseases (notably advanced kidney disease), not a routine senior diet.
- **Calories:** energy needs often fall with age as activity declines, so many seniors need fewer calories — but some elderly animals, especially cats, lose weight and need more. Monitor weight and adjust; do not assume.
- **Joint support:** omega-3 fatty acids (EPA and DHA from fish oil) have the best evidence for supporting joint comfort in dogs with osteoarthritis. Glucosamine and chondroitin have mixed evidence. These are adjuncts, not treatments, and they never replace veterinary care or weight control — which is the single most effective intervention for arthritic joints.
- **Kidney support:** diets restricted in phosphorus are used in kidney disease, but they are therapeutic diets prescribed by a veterinarian, not a routine senior choice.
- **Palatability and texture:** older animals may have dental disease or a reduced sense of smell. Warming wet food slightly, offering softer textures, and feeding smaller, more frequent meals can help. Any senior that stops eating or loses weight needs a veterinary check, not a different flavour.

**Worked example 7.3 — A 12-year-old neutered cat, 4 kg, healthy but less active**

RER = 70 × 4^0.75. 4^0.75 ≈ 2.83. RER ≈ 198 kcal/day.
MER at the inactive factor 1.0 = 198 kcal/day. On wet food at 85 kcal per 100 g, that is about 233 g per day. If she is losing weight at this amount, increase by 10% and reassess in three weeks; if she is gaining, reduce by 10%. Her senior status alone does not justify a low-protein diet — her veterinarian should decide that on the basis of blood work, not age.

### Pregnancy and lactation: the most demanding stage

Pregnant and nursing animals need growth or all-life-stages diets — never a maintenance diet — and their energy needs rise steeply. A bitch or queen in late pregnancy needs roughly 1.5–2 times her maintenance calories; a nursing mother with a large litter can need three to four times her maintenance calories at peak lactation, and some queens with large litters need even more. Feed the mother freely during lactation (within reason) and monitor her body condition closely: she should not become emaciated feeding her litter. This is the one stage where "feed as much as she wants" is reasonable, and it is also a stage where veterinary guidance is important — pregnancy and lactation are not the time for dietary experiments. Puppies and kittens should be weaned onto a growth diet from about three to four weeks of age.

### Breed and size differences

- **Small breeds** have higher energy needs per kilogram, smaller stomachs, and faster metabolisms. They may do better on energy-dense foods in smaller volumes, and they are prone to dental disease — dental care matters more than kibble size claims.
- **Large and giant breeds** need controlled calcium and energy during growth (see above) and are prone to bloat (gastric dilatation-volvulus). Feeding two or three smaller meals rather than one large meal, avoiding vigorous exercise immediately before and after eating, and using a slow feeder can reduce risk. Discuss preventive gastropexy with your veterinarian if you own a high-risk breed.
- **Brachycephalic breeds** (flat-faced dogs and cats) may struggle with certain kibble shapes and with eating quickly. Softer textures, smaller kibble, and slow feeders can help.

### Key takeaways

- Feed growth diets to puppies and kittens; switch to adult food at skeletal maturity.
- Control growth in large-breed puppies — lean is healthy, fast is risky.
- Reduce portions by about 20% after neutering.
- Healthy seniors need adequate protein; low-protein senior diets are a medical decision, not a default.
- Pregnancy and lactation need growth diets and much more food — with veterinary guidance.

**Module 7 action step:** Identify your pet's life stage and check that the food's adequacy statement matches it. If your pet is a puppy or kitten, calculate this week's ration from their current weight (Exercise 7.1).

---

## Module 8 — Treats, Chews, Table Food, and Supplements

Treats are where most feeding plans quietly fail. They are also where owners show love, train behaviour, and manage medication. The goal of this module is not to eliminate treats — it is to make them count honestly in the daily calorie budget.

### The 10% rule, revisited

All extras combined — commercial treats, chews, table food, training rewards, food-stuffed toys, licks of peanut butter — should stay within 10% of daily calories. The arithmetic from Module 5 applies here: for a 260 kcal cat, that is 26 kcal; for a 1,059 kcal dog, about 106 kcal. The most common error is counting each treat type separately and forgetting they add up.

### Choosing treats

- **Check the calories.** Reputable treats state kcal per treat or per piece. If the calories are not stated, assume a typical biscuit is 25–35 kcal and a small training treat is 3–5 kcal — and consider choosing a different brand that does state them.
- **Small is smart.** For training, use tiny treats or pieces of the daily kibble allowance. A dog being trained does not need a full biscuit per repetition; it needs a taste and a reward.
- **Match the treat to the animal.** A dental chew designed for a 30 kg dog is not a treat for a 5 kg dog. A treat that is too hard can fracture teeth; a treat that is too large can be a choking risk.
- **Single-ingredient treats** (freeze-dried meat, for example) are simple and usually well tolerated, but they are still calories and still need counting.
- **Avoid treats with a long list of sugars, artificial colours, and flavourings.** They are not poisonous, but they add nothing and they displace better calories.

### Chews and bones: what is safe

- **Rawhide:** can cause intestinal blockages if large pieces are swallowed; choose size-appropriate, supervised use only, or avoid it entirely.
- **Cooked bones:** never feed cooked bones of any kind — they splinter and can perforate the gut. This includes cooked chicken, turkey, and rib bones.
- **Raw bones:** carry risks of tooth fracture, choking, and bacterial contamination, and are not recommended as a routine chew by most veterinary bodies. If you choose to offer them, do so only under veterinary guidance and supervision.
- **Antlers and very hard chews:** a leading cause of broken teeth in dogs. A useful rule of thumb: if you cannot make an indentation in the chew with your thumbnail, it is too hard for your dog's teeth.
- **Dental chews:** some have genuine evidence for reducing tartar (look for products accepted by the Veterinary Oral Health Council, VOHC). They are still calories — a large dental chew can be 50–90 kcal — so count them.

### Table food and "human food"

Some human foods are fine in small amounts as treats (see the safe-foods reference in the templates folder): small pieces of cooked plain chicken, carrot, cucumber, green beans, apple slices without seeds, blueberries. Others are toxic (Module 9 and Appendix A): chocolate, xylitol, grapes and raisins, onions and garlic, macadamia nuts, alcohol, and others. The general rules are:

- Table food should be plain, cooked, unseasoned, and boneless.
- It counts toward the 10% treat allowance.
- It should never be fed from the table during meals — that trains begging, and begging is very hard to untrain.
- Fatty table food (skin, gravy, fried food, fatty meat trimmings) is a common trigger for pancreatitis in dogs. One fatty meal can cause a painful, expensive emergency.
- Never feed a pet from a plate containing foods you have not checked for safety.

### Supplements: what is worth it, what is not

The supplement market for pets is large, lightly regulated, and full of confident claims. Here is the evidence in brief:

- **Fish oil (omega-3, EPA/DHA):** the best-supported supplement in pet nutrition. Evidence supports its use for skin and coat health and for joint comfort in dogs with osteoarthritis. Use a product made for pets, dose it by your veterinarian's guidance, and store it properly (oxidised fish oil is worse than none). Cats need EPA and DHA directly; plant-based omega-3 (flaxseed) is a poor substitute for them.
- **Probiotics:** some strains have evidence for specific situations (for example, certain strains for acute diarrhoea), but most over-the-counter probiotics have not been tested in the species and condition being claimed. Strain matters, dose matters, and "contains probiotics" on a label is not evidence. Ask your veterinarian for a product with published evidence for your pet's situation.
- **Glucosamine and chondroitin:** widely sold for joints, with mixed and modest evidence. Not harmful in most cases, but not a substitute for weight control and veterinary treatment.
- **Multivitamins:** unnecessary and potentially harmful if the diet is already complete and balanced. Fat-soluble vitamins (A and D) accumulate and can reach toxic levels.
- **Calcium supplements:** should never be added to a balanced diet. Excess calcium causes skeletal disease in growing large-breed puppies and can cause other problems in adults.
- **Herbal and "natural" remedies:** "natural" does not mean safe. Many herbs are toxic to dogs and cats, and supplement quality varies enormously. Discuss any supplement with your veterinarian before starting it, especially if your pet takes medication — interactions are real.

A useful test for any supplement: ask the manufacturer for published, peer-reviewed evidence in the species and condition you are treating, at the dose in the product. If they cannot provide it, you are buying a hope, not a treatment.

### Medication and food

Some medications must be given with food and some on an empty stomach; follow your veterinarian's instructions exactly. If your pet needs medication hidden in food, use a small amount of a soft treat or a pill pocket and count it in the treat allowance. If your pet is on a therapeutic diet, do not add toppers or treats that undermine it without asking your veterinarian — a "small" addition can defeat a diet designed for kidney disease or food allergy management.

### Key takeaways

- Treats count. Keep all extras within 10% of daily calories.
- Weigh or count treats; do not guess.
- Never feed cooked bones. Avoid very hard chews.
- Fish oil is the best-supported supplement; most others are unproven.
- Never add vitamins, minerals, or calcium to a complete and balanced diet without veterinary direction.

**Module 8 action step:** Gather every treat, chew, and topper you currently use, note the calories per item, and total a typical day's extras. Compare with the 10% allowance in the workbook (Exercise 8.1).

---

## Module 9 — Homemade Feeding and Raw Diets: What the Evidence Actually Says

This is the module most likely to surprise you, because it deals with the two feeding approaches that attract the strongest opinions and the weakest evidence. The goal here is honesty: what works, what does not, what the risks are, and how to make a safe decision.

### Homemade diets: possible, but harder than they look

A homemade diet can be excellent — and it can also be seriously unbalanced. Studies of homemade diet recipes found online and in books have repeatedly shown that most are deficient in one or more essential nutrients, most commonly calcium, zinc, iron, and certain vitamins, or have incorrect calcium-to-phosphorus ratios. The problem is not the idea of cooking for your pet; it is that a diet of chicken, rice, and vegetables looks complete and is not. Meat alone is very low in calcium. Rice and vegetables do not supply the missing minerals. A diet can look wholesome and still cause nutritional disease over months.

That said, homemade feeding has legitimate uses: pets with multiple food allergies, pets that refuse commercial diets, pets with conditions that need a precisely controlled diet, and owners who simply prefer it. If you want to feed homemade, do it properly:

1. **Get the recipe from a board-certified veterinary nutritionist**, not from a website, a book, or a social media post. A recipe formulated for a specific animal, with a vitamin-mineral supplement (often called a "balancer") included, is a complete diet. A recipe without a balancer almost certainly is not.
2. **Follow the recipe exactly.** Substituting ingredients changes the nutrient profile. "Chicken instead of turkey" seems trivial; it is not, because the mineral content differs.
3. **Include the balancer supplement specified in the recipe.** This is not optional. The balancer supplies the calcium, trace minerals, and vitamins that plain ingredients do not.
4. **Do not rotate ingredients casually.** Each change needs to be checked against the recipe.
5. **Weigh ingredients on a kitchen scale.** Cup measures are inaccurate for chopped meat and vegetables.
6. **Cook and store food safely.** Cook meat thoroughly, cool it promptly, refrigerate for no more than two to three days, and freeze the rest in portions.
7. **Monitor the animal.** Weigh them regularly, watch stool quality and coat condition, and have blood work checked at your veterinarian's recommended intervals.

**Worked example 9.1 — What a balanced homemade day can look like (adult dog, 15 kg, approximately 700 kcal/day)**

This is an illustrative example of the *structure* of a balanced homemade diet, not a recipe to use without professional formulation:

- Cooked lean meat or poultry (for example, cooked chicken breast or lean minced beef), weighed, providing the bulk of the protein.
- Cooked carbohydrate source (for example, cooked rice or potato), weighed.
- Cooked vegetables (for example, carrots, green beans) for fibre and bulk.
- A measured amount of oil (for example, a small amount of fish oil or vegetable oil) for essential fatty acids and energy.
- A veterinary-nutritionist-specified vitamin-mineral balancer, dosed exactly as directed, supplying calcium and trace nutrients.
- Fresh water available at all times.

The critical point is the last ingredient. Without the balancer, this diet is deficient in calcium and several trace minerals. With it, and with the recipe formulated for the individual dog, it can be a complete diet. Never feed a homemade diet long-term without that professional formulation.

**Cost note:** a properly formulated homemade diet with a balancer is usually more expensive and more time-consuming than a good commercial food. Worked cost comparison: feeding a 15 kg dog a commercial dry food at 3,600 kcal/kg costs roughly £0.55–£0.85 per day for food; a homemade diet of fresh meat, rice, vegetables, oil, and balancer typically costs £1.50–£3.00 per day depending on meat prices, plus cooking and storage time. Homemade feeding is a choice about control and preference, not a way to save money.

### Raw feeding: the claims and the evidence

Raw feeding (often called BARF — biologically appropriate raw food — or prey-model feeding) is based on the idea that dogs and cats should eat as their wild ancestors did. It is worth examining each claim honestly.

**Claim: "Raw is natural, so it must be healthier."** Dogs are not wolves. Domestic dogs have evolved alongside humans for thousands of years and have developed the ability to digest cooked starch far better than wolves can. Cats are obligate carnivores, but domestic cats are also not wildcats, and "natural" diets in the wild include parasites, food poisoning, and nutritional deficiencies — nature is not a guarantee of health. The naturalistic argument is an appeal to intuition, not evidence.

**Claim: "Raw diets are more nutritious."** Cooking does reduce some vitamins, but it also improves the digestibility of starch and kills pathogens. There is no published evidence that raw diets produce better health outcomes than well-formulated commercial diets. The studies that exist are small, short, and often funded by raw food companies.

**Claim: "Raw feeding cleans teeth."** Chewing raw bones can remove some tartar, but it also breaks teeth — veterinary dentists report a high rate of fractured teeth from raw bones. Dental chews with evidence, tooth brushing, and professional dental care are safer ways to manage dental health.

**The real risks of raw feeding:**

- **Bacterial contamination.** Raw meat commonly carries Salmonella, Campylobacter, E. coli, and Listeria. These bacteria can make the pet ill, and they can make people ill — especially children, elderly people, and anyone who is immunocompromised. Studies have found that a significant proportion of raw pet food samples test positive for pathogenic bacteria, and that dogs fed raw diets shed Salmonella in their faeces far more often than dogs fed cooked diets. Handling raw pet food requires the same hygiene as handling raw meat for people, and the risk extends to every surface the pet licks.
- **Nutritional imbalance.** Most homemade raw diets are unbalanced in the same ways as homemade cooked diets, and commercial raw products are not exempt: surveys have found that a substantial proportion of commercial raw diets do not meet AAFCO or FEDIAF nutrient profiles, including some that claim to be complete.
- **Bones.** Raw bones can fracture teeth, cause choking, and cause intestinal obstruction or perforation.
- **Parasites.** Raw meat and offal can carry parasites, including Toxoplasma and various worms, depending on the meat source and handling.

**If you choose to feed raw anyway:** do so with your eyes open. Use a commercial raw product that carries a complete-and-balanced adequacy statement for the correct life stage. Practise strict hygiene — wash hands, bowls, surfaces, and utensils after handling; store raw food separately from human food; do not let the pet lick faces, open wounds, or children's hands after eating. Do not feed raw to a household with an immunocompromised person, a very young child, or an elderly person without discussing it with your doctor and veterinarian. And discuss the decision with your veterinarian, who can advise on blood work and monitoring.

**The honest summary:** there is no good evidence that raw diets are healthier than well-formulated cooked or commercial diets, and there is good evidence that they carry additional risks from bacteria and nutritional imbalance. Many owners who feed raw report shinier coats and smaller stools — smaller stools are expected on a high-meat, low-fibre diet, and a shiny coat is often the result of higher fat intake, both of which can be achieved with a cooked or commercial diet. The decision is yours, but it should be an informed one.

### Grain-free diets and heart disease: what we know

In 2018, the US Food and Drug Administration (FDA) reported an association between certain diets — many of them grain-free and rich in peas, lentils, and potatoes — and dilated cardiomyopathy (DCM), a serious heart condition, in dogs not typically prone to it. Research is ongoing, and the mechanism is not fully understood; it may involve taurine metabolism, the bioavailability of certain nutrients, or other factors. The FDA has not banned grain-free diets, and most dogs eating grain-free diets do not develop DCM. But the association is real enough that veterinary cardiologists and nutritionists advise caution: there is no nutritional benefit to grain-free diets for most dogs, and there is a plausible (if not yet proven) risk. If your dog is healthy and doing well on a grain-free diet, discuss it with your veterinarian rather than panicking — but do not choose grain-free because you believe it is healthier. The evidence does not support that belief.

### Diet trends: a quick reality check

- **Vegan diets for dogs:** dogs can survive on a carefully formulated vegan diet, but it is difficult to get right and requires professional formulation and monitoring. There is no health advantage, and the risk of deficiency is real.
- **Vegan diets for cats:** not appropriate. Cats are obligate carnivores and cannot meet their needs for taurine, arachidonic acid, vitamin A, and vitamin B12 from plants. Do not feed a cat a vegan diet.
- **Single-protein / limited-ingredient diets:** useful for food allergy trials under veterinary guidance, but not a general health choice. Most food allergies are to common proteins (beef, chicken, dairy); a limited-ingredient diet is a diagnostic tool, not a lifestyle.
- **"Ancestral" / "wolf" diets:** marketing, not science. Domestic dogs are not wolves.
- **Fasting / intermittent fasting for pets:** not recommended. Cats in particular must not be fasted. Dogs do not need fasting days, and fasting can cause harm in small dogs, puppies, and animals with medical conditions.

### Key takeaways

- Homemade diets can work, but only with a recipe from a board-certified veterinary nutritionist and a proper balancer supplement.
- Most homemade recipes found online are unbalanced. Do not improvise.
- Raw diets have no proven health advantage and carry real bacterial and nutritional risks.
- Grain-free is not healthier; discuss it with your veterinarian.
- Never feed a cat a vegan diet.

**Module 9 action step:** If you currently feed homemade or raw, check the recipe's source and whether it includes a balancer and an adequacy statement. If it does not, book a nutrition consultation with your veterinarian (Exercise 9.1).

---

## Module 10 — Transitions, Picky Eaters, and Building Your Pet's Feeding Plan

This final module brings everything together: how to change foods safely, how to handle the common feeding problems owners actually face, and how to write a feeding plan for your own pet.

### How to transition to a new food

Change foods gradually over seven to ten days to avoid digestive upset:

- Days 1–2: 75% old food, 25% new food.
- Days 3–4: 50% old food, 50% new food.
- Days 5–6: 25% old food, 75% new food.
- Day 7 onward: 100% new food.

If soft stools appear, slow down — go back a step and hold for two or three days before progressing. If vomiting or diarrhoea persists, stop the transition and contact your veterinarian. Some animals, especially cats, are neophobic (suspicious of new foods) and may need a slower transition over two weeks. Never change a cat's food abruptly and then leave the new food down expecting hunger to win: a cat that refuses food for more than 24 hours is at risk of hepatic lipidosis and needs veterinary attention.

### Picky eaters

True pickiness is less common than owners think. Before labelling a pet picky, check:

- Are treats and table scraps filling them up? Cut extras to zero for a week and see whether appetite for meals returns.
- Is the food stale, or has the bag been open for weeks? Fats oxidise and kibble goes stale. Store food in its original bag, sealed, in a cool dry place, and use within four to six weeks of opening.
- Is the bowl clean? Some animals refuse food from a dirty bowl, and cats in particular dislike deep bowls that touch their whiskers.
- Is the pet stressed, in pain, or unwell? Dental disease is a common cause of reduced eating in older pets.
- Is the food actually appropriate? A food that is too rich, too low in fat, or the wrong texture may genuinely not suit the animal.

If the animal is healthy, at a good weight, and simply fussy, offer the food for 20–30 minutes and then remove it until the next meal. Do not add toppers, switch flavours daily, or hand-feed to coax eating — that trains fussiness. If a pet that previously ate well stops eating, that is a veterinary question, not a preference question.

### Food guarding and multi-pet households

Food guarding (growling or snapping around food) is a behavioural issue, not a nutrition issue, and it needs a qualified behaviour professional — never punish a guarding animal. In multi-pet households, feed animals separately or in different rooms, supervise meals, and remove bowls after eating. This prevents food stealing, ensures each animal eats its own ration, and reduces conflict.

### Feeding around exercise and travel

- Do not feed a large meal immediately before vigorous exercise, and wait at least an hour after exercise before feeding. This is especially important for large, deep-chested breeds at risk of bloat.
- When travelling, bring the pet's usual food and water, feed at the usual times, and avoid new treats or foods on the journey.
- Boarding and kennels: provide written feeding instructions with exact amounts in grams, the food's name, and any medication instructions.

### When feeding is a veterinary question

Contact your veterinarian promptly if your pet:

- Stops eating for more than 24 hours (especially a cat).
- Vomits repeatedly or has persistent diarrhoea.
- Loses weight unexpectedly or cannot gain weight.
- Drinks or urinates much more than usual.
- Has a swollen abdomen, difficulty breathing, or collapses.
- Has eaten something toxic (see Appendix A) — do not wait for symptoms.
- Needs a diet for a diagnosed medical condition.

### Building your pet's feeding plan

Use the template in the workbook (Exercise 10.1) to write a one-page feeding plan. It should state:

1. The pet's species, age, weight, target weight, and body condition score.
2. The food (brand, product, life stage) and its adequacy statement.
3. The daily calorie target (RER and MER, with the factor used) and the daily amount in grams.
4. Meal frequency and times.
5. The treat allowance in calories and what it will consist of.
6. The weighing schedule (fortnightly for weight loss, monthly for maintenance).
7. The date to review the plan (every three months, or at the next veterinary visit).
8. Any veterinary instructions or medical diets that override this plan.

Review the plan whenever the pet's weight, activity, age, or health changes. A feeding plan is a living document, not a one-time calculation.

### Worked example 10.1 — A complete feeding plan

**Milo, neutered male Cocker Spaniel, 3 years old, 13 kg, target weight 12 kg, BCS 6/9.**

- Food: a complete and balanced adult dry food, AAFCO maintenance statement, 3,700 kcal/kg.
- RER at target weight: 70 × 12^0.75 ≈ 70 × 6.45 ≈ 452 kcal/day.
- MER for weight loss: 452 × 1.0 = 452 kcal/day.
- Daily food: 452 ÷ 3.7 ≈ 122 g per day, split into two meals of 61 g.
- Treats: maximum 45 kcal per day, taken from the daily allowance where possible — a small dental chew three times a week (counted), plus carrot pieces.
- Weighing: every two weeks on the same scales. Target loss: about 0.12–0.24 kg per month. Expected time to target: about four to eight months.
- Review: in three months, or sooner if weight is static for a month (then reduce food by 10%).
- Exercise: two 25-minute walks a day, plus play. No food immediately before or after vigorous exercise.
- Veterinary note: none — Milo is healthy. If he develops any illness, the plan is reviewed with the veterinarian.

**Worked example 10.2 — A complete feeding plan**

**Luna, spayed female domestic shorthair cat, 6 years old, 4.2 kg, ideal weight, BCS 5/9.**

- Food: a complete and balanced adult wet food, FEDIAF complete statement, 85 kcal per 100 g, plus a small amount of dry food for dental variety and convenience.
- RER: 70 × 4.2^0.75 ≈ 70 × 2.93 ≈ 205 kcal/day.
- MER (neutered adult, factor 1.2): 205 × 1.2 ≈ 246 kcal/day.
- Daily food: 200 g wet food (170 kcal) plus 20 g dry food at 3,800 kcal/kg (76 kcal) = 246 kcal.
- Meals: wet food split into two meals (morning and evening), dry food offered in a puzzle feeder during the day.
- Treats: maximum 25 kcal per day — about five small cat treats, or a teaspoon of plain cooked chicken.
- Weighing: monthly. Water: fresh water in two locations, plus a fountain.
- Review: every three months and at the annual veterinary check.

### Your next steps

1. Complete the workbook exercises, especially the feeding plan (Exercise 10.1).
2. Weigh your pet and your pet's food this week.
3. Read the label of the food you feed today and check its adequacy statement.
4. Book a veterinary check if anything in this course has raised a concern — a body condition score above ideal, unexplained weight change, or a diet that may be unbalanced.
5. Revisit this course every six months, or whenever your pet's life stage changes.

Good feeding is not complicated, but it is specific. It is a complete and balanced food, fed in the right amount, adjusted to the individual animal, and reviewed regularly. Everything else is detail — and now you have the detail too.

---

## Appendix A — Toxic Foods Quick Reference

**Call your veterinarian or an animal poison control service immediately if your pet eats any of these. Do not wait for symptoms. Do not induce vomiting unless a veterinarian tells you to.**

| Food / substance | Dogs | Cats | Notes |
|---|---|---|---|
| Chocolate (especially dark and baking) | Toxic | Toxic | Theobromine; darker = more dangerous |
| Xylitol (birch sugar; in sugar-free gum, sweets, some peanut butters) | Toxic — can cause dangerously low blood sugar and liver failure | Toxic | Check labels on sugar-free products |
| Grapes and raisins (including currants and sultanas) | Toxic — can cause kidney failure | Toxic | Even small amounts; the toxic dose is unpredictable |
| Onions, garlic, chives, leeks | Toxic | Toxic | Damages red blood cells; cats more sensitive |
| Macadamia nuts | Toxic | Toxic | Weakness, tremors, vomiting |
| Alcohol | Toxic | Toxic | Even small amounts |
| Caffeine (coffee, tea, energy drinks) | Toxic | Toxic | Stimulant; dangerous in small doses |
| Cooked bones | Dangerous | Dangerous | Splinter and can perforate the gut |
| Raw dough with yeast | Dangerous | Dangerous | Expands in the stomach; alcohol produced |
| Lilies (all parts, including pollen and vase water) | Mildly toxic | **Highly toxic — kidney failure** | Even a small exposure can be fatal to cats |
| Other nuts (walnuts, pecans) | Harmful | Harmful | High fat; some mouldy nuts produce toxins |

**Foods that are safe in small amounts as occasional treats** (plain, cooked, unseasoned, boneless, and counted in the 10% treat allowance): carrot, cucumber, green beans, courgette, apple slices without seeds or core, blueberries, banana in small pieces, plain cooked chicken or turkey, plain cooked white fish, plain cooked egg. Always introduce new foods one at a time and watch for digestive upset. A fuller safe-foods and toxic-foods reference is in the templates folder.

---

## Appendix B — Glossary

- **AAFCO:** Association of American Feed Control Officials; publishes nutrient profiles and labelling guidelines for pet food in the United States.
- **BCS:** Body condition score; a 9-point (or 5-point) scale for assessing fat cover.
- **Balancer:** A vitamin-mineral supplement added to homemade diets to make them complete.
- **Complete and balanced:** A diet containing all essential nutrients in the right proportions for a stated life stage.
- **Dry matter basis (DMB):** Nutrient percentages calculated with all water removed, allowing fair comparison between foods.
- **FEDIAF:** European Pet Food Industry Federation; publishes nutritional guidelines for pet food in Europe.
- **Guaranteed analysis:** The legally required minimum/maximum nutrient percentages on a pet food label.
- **MER:** Maintenance energy requirement; daily calories needed, equal to RER × a life-stage/activity factor.
- **Metabolisable energy (ME):** The energy in food available to the animal after digestion; expressed in kcal.
- **Obligate carnivore:** An animal (such as the cat) that must eat animal tissue to meet certain nutrient needs.
- **RER:** Resting energy requirement; 70 × (body weight in kg)^0.75 kcal/day.
- **Taurine:** An amino acid essential for cats; deficiency causes heart disease and blindness.

---

## Appendix C — Sources and Further Reading

- AAFCO Dog and Cat Food Nutrient Profiles (current edition) — the nutrient standards referenced throughout this course.
- FEDIAF Nutritional Guidelines for Complete and Complementary Pet Food for Cats and Dogs (current edition).
- National Research Council, *Nutrient Requirements of Dogs and Cats* (National Academies Press, 2006) — the scientific basis for AAFCO and FEDIAF profiles.
- WSAVA Global Nutrition Guidelines and Global Nutrition Toolkit (World Small Animal Veterinary Association) — practical guidance for veterinarians and owners, including body condition scoring and calorie calculations.
- American Animal Hospital Association (AAHA) nutrition and weight management resources.
- Veterinary Oral Health Council (VOHC) list of accepted dental products.
- US Food and Drug Administration (FDA) reports on diet-associated dilated cardiomyopathy in dogs (2018 onward).
- Your veterinarian, and a board-certified veterinary nutritionist (ACVIM Nutrition or ECVCN diplomate) for individual diet formulation.

*This course was written for general education. Nutrient standards, product formulations, and veterinary guidance change over time; check current published sources and consult your veterinarian for advice about your individual pet.*

---

*Pet Nutrition Foundations — complete written course manual. Education only; not a substitute for veterinary care. See the disclaimer at the front of this manual.*
