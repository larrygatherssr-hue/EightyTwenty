# Customer Onboarding Guide — Pet Nutrition Foundations

Welcome, and thank you for purchasing Pet Nutrition Foundations. This guide tells you what to do first, how to use the materials, and how to get support.

## Important — what you bought

This is a **complete written course manual** (plus workbook and templates). It is **not a video course**. Everything is delivered as readable, printable documents you can work through at your own pace and keep for reference.

## Disclaimer

This course is general nutrition education only. It is not veterinary advice and never replaces veterinary care or a consultation with a board-certified veterinary nutritionist. If your pet has a medical condition, is pregnant, nursing, very young, very old, underweight, or recovering from illness, consult your veterinarian before changing anything about their diet.

## What you received

| File | What it is |
|---|---|
| content.md | The full course: 10 modules, appendices, toxic-foods reference, glossary, sources |
| workbook.md | Companion workbook — one exercise per module, using your own pet's numbers |
| templates/weight-management-planner.csv | Weight-loss targets, RER quick reference, fortnightly weight log |
| templates/life-stage-feeding-charts.md | MER factors and example rations for dogs and cats at every life stage |
| templates/safe-foods-toxic-foods-reference.md | Safe treats and toxic foods, with warnings |
| templates/label-reading-guide.md | The five-minute label audit, with worked examples |
| templates/meal-planning-worksheet.md | Weekly meal plan, treat plan, and check-in |
| cover.png | Course cover image |
| sales-page.md | The product sales page (for your reference) |
| listing.json | Marketplace listing data |
| README.md | Index of the product's files |

## What to do first (Day 1, about 30 minutes)

1. **Read the disclaimer** at the front of content.md.
2. **Weigh your pet** and write the number down with today's date (Workbook Exercise 1.1). If you do not have a pet scale, weigh yourself holding your pet and then alone, and subtract — or use your veterinary clinic's scale.
3. **Buy or borrow a digital kitchen scale** if you do not own one. Weighing food is the single most useful habit in this course.
4. **Read the label of the food you feed today** and find its adequacy statement (Module 3). Copy it into Workbook Exercise 3.1.

## Suggested schedule

**Week 1 — Foundations (Modules 1–3, about 2–3 hours)**
Read Modules 1–3 and complete Workbook Exercises 1.1, 2.1, and 3.1. By the end of the week you will know your pet's baseline weight, water needs, and whether their current food is complete and balanced for their life stage.

**Week 2 — Labels and calories (Modules 4–5, about 2–3 hours)**
Read Modules 4–5 and complete Exercises 4.1, 4.2, 5.1, 5.2, and 5.3. Calculate your pet's daily calorie target, convert it to grams of their current food, and compare it with what you have actually been feeding. Start weighing food at every meal.

**Week 3 — Weight and life stage (Modules 6–7, about 2–3 hours)**
Read Modules 6–7 and complete Exercises 6.1 and 7.1. Score your pet's body condition, and if they are above ideal, agree a target weight with your veterinarian and start the weight tracker. Check that the food matches your pet's life stage.

**Week 4 — Treats, homemade, and raw (Modules 8–9, about 2 hours)**
Read Modules 8–9 and complete Exercises 8.1 and 9.1. Audit every treat and supplement, and check any homemade or raw diet against the safety criteria in Module 9.

**Week 5 — Your feeding plan (Module 10, about 1 hour)**
Read Module 10 and complete Exercises 10.1 and 10.2. Write your pet's one-page feeding plan, post it on the fridge, and share it with everyone who feeds your pet.

**Ongoing**
Weigh your pet every two weeks (monthly once weight is stable), review the feeding plan every three months, and revisit the course whenever your pet's life stage, weight, activity, or health changes.

## Tips for getting the most from the course

- Do the workbook exercises with your own pet's numbers — reading alone will not change how you feed.
- Print the templates you use most (weight tracker, meal planner, toxic-foods reference) and keep them where you feed your pet.
- Change one thing at a time. If you change the food, the portion, and the treats all at once, you will not know what worked.
- If you are a pet sitter or groomer, the one-page feeding plan (Exercise 10.1) is the template to use with clients.

## How to get support

For questions about the course materials, your download, or a refund request, contact EightyTwenty marketplace support and include your order number and the product SKU (PET-08). Please allow up to 2 business days for a reply.

Support covers the course materials and delivery. It does not include one-to-one nutrition consultations or veterinary advice. For advice about your individual pet, contact your veterinarian or a board-certified veterinary nutritionist.

## If your pet stops eating

If your pet stops eating for more than 24 hours (especially a cat), vomits repeatedly, has persistent diarrhoea, or loses weight unexpectedly, contact your veterinarian promptly. If you suspect your pet has eaten something toxic, contact your veterinarian or an animal poison control service immediately — do not wait for symptoms.
