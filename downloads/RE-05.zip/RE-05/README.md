# RE-05 — The Portfolio Builder: From First Property to Financial Freedom

- **SKU:** RE-05
- **Category:** Real Estate
- **Price:** $997 (99700 cents), one-time
- **Target customer:** Investors who already own 1–3 rentals and want to scale to 10+ units within 3–5 years.
- **Headline:** From one property to ten — scale your portfolio with BRRRR, refinancing, and a real roadmap.

## Files

| File | Contents |
|---|---|
| `content.md` | Full course — 18 modules + appendices, 14,016 words |
| `workbook.md` | Companion workbook — 8 worksheets |
| `templates/brrrr-calculator.csv` | BRRRR calculator with worked example pre-filled, stress tests, failed-deal comparison |
| `templates/refinance-decision-worksheet.md` | Refinance decision worksheet |
| `templates/portfolio-tracking-template.csv` | Monthly portfolio tracker (one row per property) |
| `templates/annual-portfolio-review.md` | Annual portfolio review template |
| `sales-page.md` | Full sales page (headline, problem/solution, module list, who it is/is not for, $997 price, 14-day guarantee, 10 FAQs, disclaimers) |
| `listing.json` | Marketplace listing data (validated; price_cents 99700, billing one_time) |
| `cover.md` | Cover design brief (black-and-gold luxury) |
| `cover.webp` | Generated cover image (208,436 bytes) |
| `onboarding.md` | Customer onboarding guide |

## Notes

- All content original. No testimonials, sales figures, certifications, or reviews — none fabricated.
- Education only, not individualized financial, legal, tax, or investment advice. No guaranteed returns or income claims.
- BRRRR and refinancing risks shown honestly, including a fully worked BRRRR deal that does NOT work (Module 3) and a cash-flow-negative outcome on the deal that does recycle capital.
- Entity (Module 12), tax (Module 13), and 1031 exchange (Module 15) sections are general education only, with instructions to consult a licensed attorney/CPA.
- Two fully worked portfolio examples with real numbers in Module 18 (a 3-property start and a path to 10).
