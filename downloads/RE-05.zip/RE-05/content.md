# The Portfolio Builder: From First Property to Financial Freedom

## A Note Before You Begin

This course is education, not individualized financial, legal, tax, or investment advice. Real estate investing involves real risk: values can fall, tenants can leave, repairs can cost more than expected, and interest rates can move against you. Nothing in this course guarantees a return, a rent level, an appraisal value, or a timeline. The numbers in the worked examples are illustrations built from stated assumptions so you can see how the math works — they are not predictions about any real property or market. Before you buy, refinance, form an entity, or make a tax decision, talk to licensed professionals in your state: a real estate attorney, a CPA, and a licensed lender. Your job in this course is to learn the frameworks, run your own numbers honestly, and make decisions you can defend to yourself on a bad day, not just a good one.

This course is written for an investor who already owns one to three rental properties and wants to scale to ten or more units within three to five years. If you have never bought a property, start with the fundamentals first — this course assumes you know what a mortgage, a lease, and a rent roll are. If you already own rentals, you are in the right place.

---

## Module 1: Where You Are Now — The Portfolio Audit

Every scaling plan that fails starts the same way: with a guess about where the investor stands. Before you buy property number four, you need a ruthless, written picture of properties one through three.

### Why the audit comes first

Scaling is not buying more of what you already have. It is building a system that can carry more. A portfolio that looks fine at three doors can break at six if the first three are quietly bleeding cash, underinsured, or financed in ways that block the next loan. The audit finds those cracks while they are still cheap to fix.

### Step 1: List every property on one page

For each property, record: address, property type, units, purchase date, purchase price, current estimated value and how you estimated it, total cash invested (down payment plus closing costs plus rehab plus any later capital), current loan balance, interest rate, loan type, monthly payment (principal, interest, taxes, insurance), monthly rent actually collected over the last twelve months (not the rent on the lease — the rent that hit your account), vacancy days in the last twelve months, and average monthly maintenance, repairs, and capital-expenditure reserves.

If you cannot fill in a line, that gap is itself a finding. Most stalled investors discover at this step that they do not actually know their true cash flow. They know the rent. They do not know the twelve-month average after vacancy, turnover costs, and the water heater that died in March.

### Step 2: Calculate true cash flow per property

Use this formula for each property, on a twelve-month trailing basis:

Cash flow = (Gross rent actually collected) − (mortgage payment) − (taxes and insurance, if not escrowed) − (property management, even if you self-manage — price your time) − (maintenance and repairs actually spent) − (vacancy reserve) − (capital-expenditure reserve).

A common, defensible reserve is 5 percent of gross rent for vacancy and 5 percent for capital expenditures on a property in average condition, more for older properties. These are not pessimism. They are the cost of owning a physical asset over time. A roof does not ask whether this is a good year.

Work the numbers property by property. A portfolio can show a positive total while one property quietly loses money every month and is carried by the others. That property is not a scaling foundation. It is a decision waiting to be made — fix the rent, fix the expenses, refinance, or sell — and Module 16 will give you the framework for making it.

### Step 3: Calculate equity and return on cash invested

For each property: equity = current estimated value − loan balance. Cash-on-cash return = annual cash flow ÷ total cash invested. Return on equity = annual cash flow ÷ current equity. The second number matters more as you scale, because equity trapped in a property earning a 2 percent return on equity is capital that could be working harder elsewhere — but only if you can move it safely, which is what the BRRRR and refinance modules are about.

### Step 4: Audit your financing capacity

Write down: your credit score and the date you last checked it, your debt-to-income ratio as a lender would calculate it, how many conventional mortgages you currently hold (conventional financing has limits on the number of financed properties — currently ten for most investors, with stricter reserve requirements after four), your liquid cash reserves, and any untapped equity in your primary residence or rentals.

This is the honest constraint map for your scaling plan. If your debt-to-income ratio is already tight, the next deal may need a DSCR loan or a partner rather than another conventional mortgage. If your reserves are thin, your next deal should be smaller or later. Scaling plans fail when they ignore the lender's math.

### Step 5: Audit your time

Track, for two weeks, every hour you spend on your rentals: tenant messages, showings, repairs, bookkeeping, driving. Multiply by fifty. That is your annual landlord time. Now ask: if you doubled the portfolio, would that number double too? If the answer is yes, you do not have a scaling problem — you have a systems problem, and Module 12 is where you fix it before you buy anything else.

### Your audit deliverable

By the end of this module you should have a one-page portfolio snapshot: each property's cash flow, equity, cash-on-cash return, and return on equity; your total portfolio cash flow; your total equity; your financing headroom; and your weekly landlord hours. The workbook's Portfolio Audit worksheet walks you through it line by line. Do not skip this. Every later module builds on these numbers.

---

## Module 2: Setting a Scaling Target and Timeline

A goal like "get rich in real estate" is not a plan. A scaling target is a number, a date, and a definition of done.

### Define what "ten units" actually means to you

Ten units could mean ten single-family houses, or five duplexes, or one ten-unit apartment building, or a mix. Those are very different businesses. Ten scattered single-family homes mean ten roofs, ten lawns, ten sets of tenants, and ten sets of property taxes. A ten-unit building means one roof and one location — but also commercial financing, a larger single point of failure, and a different management profile. Neither is right for everyone. Your target should name the property type, not just the unit count.

### Work backward from the income you need

Start with the monthly cash flow you want the portfolio to produce, then work backward. Suppose you want $5,000 per month in portfolio cash flow after all expenses and reserves. If your market realistically produces $200 per door per month in true cash flow after reserves, you need twenty-five doors, not ten. If it produces $400 per door, you need thirteen. This single calculation is where most scaling plans quietly break: the investor picks a unit count from a podcast and never checks whether that count produces the income they actually want.

Be honest about the per-door number. Use your own audited numbers from Module 1, not a guru's. If your current properties produce $150 per door, planning on $500 per door for the next seven is not a plan — it is a wish.

### Set a timeline you can actually fund

Scaling is limited by two things: capital and deal flow. Capital is the binding constraint for most investors, and capital recycling — the subject of Module 3 — is how you loosen it. But even with recycling, each deal takes time: finding it, closing it, rehabbing it, seasoning it, refinancing it. A realistic cycle for a BRRRR deal is four to nine months from purchase to refinance. If your plan requires four BRRRR cycles a year and you have a full-time job and no contractor team, the plan is fiction.

A reasonable starting frame: one to two acquisitions per year for a part-time investor with a job, two to four per year once systems and a team are in place. Map your target against that pace. If the math says five years, say five years. A five-year plan you follow beats a two-year plan you abandon in month eight.

### Write the target down in one paragraph

Example: "By December 31, 2029, I will own twelve units — my current three single-family rentals plus nine more, a mix of single-family homes and small multifamily in my target market — producing at least $3,600 per month in true cash flow after reserves, with no more than ten hours per week of my own time, managed by a property manager."

That paragraph has a date, a unit count, a property mix, an income number, and a time budget. Everything after this module is about closing the gap between that paragraph and today.

### The three numbers to review monthly

Once the target is set, track three numbers every month: doors owned, trailing-twelve-month cash flow per door, and total equity. If doors are growing but cash flow per door is falling, you are scaling the wrong way. If equity is growing but cash flow is flat, you may be over-improving or under-renting. The monthly review takes twenty minutes and is the difference between a plan and a hope.

---

## Module 3: Capital Recycling — How BRRRR Works, Step by Step

BRRRR stands for Buy, Rehab, Rent, Refinance, Repeat. It is the core engine of most portfolio scaling, because it is the main way a small investor recycles the same capital into multiple properties instead of waiting years to save each new down payment. It is also the strategy most often misunderstood, and the one where sloppy math causes the most damage. This module walks through it completely, with real numbers.

### The five steps

**Buy.** You purchase a property below its after-repair value (ARV) — the value it will have once repaired. The discount is the whole game. If you pay full retail value, there is nothing to recycle.

**Rehab.** You repair and improve the property to a rent-ready standard: safe, clean, functional, and competitive for the rent you intend to charge. Not a luxury renovation. A rent-ready rehab.

**Rent.** You place a qualified tenant at market rent and establish a payment history. Lenders want to see the property performing.

**Refinance.** After a seasoning period (often six months, depending on the lender and loan type), you refinance based on the new appraised value. If the appraisal supports it, the new loan pays off the original financing and returns some or all of your invested cash.

**Repeat.** You take the returned cash and use it as the capital for the next deal.

### A fully worked example: a BRRRR deal that works

Here is a complete example with line-item numbers. Assumptions are stated so you can change them and re-run the math yourself. The accompanying BRRRR calculator spreadsheet has this example pre-filled.

**The property:** A three-bedroom, one-bathroom single-family home, 1,150 square feet, built in 1972, in a working-class neighborhood with stable rents. Comparable renovated homes nearby have sold recently between $185,000 and $205,000.

**Purchase:**
- Purchase price: $120,000
- Closing costs: $4,000
- Total acquisition cost: $124,000

**Financing the purchase:** You buy with cash from savings plus a short-term source, or with a hard-money loan. For this example, assume you use $124,000 of your own cash to buy, keeping the math clean. (If you use hard money, add the interest and points to the "cash invested" total — see the warning in the calculator notes.)

**Rehab (line items):**
- Roof repair (partial, two slopes): $4,500
- Kitchen: paint cabinets, new counters, new faucet, new appliances (refrigerator, range): $7,000
- Bathroom: new vanity, toilet, tub surround, fixtures: $3,500
- Flooring throughout (luxury vinyl plank): $5,000
- Interior paint: $2,500
- HVAC service and one duct repair: $1,200
- Electrical: panel tidy-up, replace outlets and fixtures: $1,800
- Plumbing: fix two leaks, replace water heater: $1,600
- Exterior: clean-up, minor siding repair, front steps: $1,500
- Trash-out, cleaning, and miscellaneous: $1,400
- Rehab contingency (10 percent, actually spent): $3,000
- **Total rehab: $33,000**

**All-in cost:** $124,000 + $33,000 = **$157,000 total cash invested.**

**Rent:** The renovated home rents for $1,650 per month. A comparable unrenovated home nearby rents for $1,250. The rehab bought $400 per month in rent.

**Refinance:** After six months of seasoning with a tenant in place, the property appraises at $195,000 (the ARV, supported by comparable sales). Your lender offers a cash-out refinance at 75 percent loan-to-value: 0.75 × $195,000 = $146,250 new loan. Closing costs on the refinance: $4,500.

**Cash returned to you:** $146,250 − $4,500 = $141,750. Your total cash invested was $157,000. Cash left in the deal: $157,000 − $141,750 = **$15,250.**

**The result:** You own a property worth $195,000 with a $146,250 mortgage — $48,750 in equity — and only $15,250 of your own cash remains in it. You got $141,750 of your $157,000 back to use on the next deal. That is the recycle.

**Cash flow check:** Monthly rent $1,650. New mortgage payment on $146,250 at 7.5 percent over 30 years: about $1,023 per month (principal and interest). Property taxes: $210 per month. Insurance: $140 per month. Property management (8 percent): $132 per month. Maintenance reserve (5 percent): $83. Vacancy reserve (5 percent): $83. Capital-expenditure reserve (5 percent): $83. Total expenses: $1,754. Cash flow: $1,650 − $1,754 = **−$104 per month.**

Stop and read that again. This deal recycled capital beautifully and loses about $100 per month on true cash flow at these assumptions. That is not a contradiction — it is the central tension of BRRRR. Pulling maximum cash out raises the mortgage payment, and the higher payment eats the cash flow. You have three honest choices: accept a smaller cash-out (refinance at a lower loan-to-value and leave more cash in, but keep positive cash flow); raise the rent if the market supports it; or accept slightly negative cash flow in exchange for equity growth and future rent increases — a trade-off you should make deliberately, with eyes open, never by accident.

If instead you refinance at 70 percent loan-to-value ($136,500 loan, about $955 per month principal and interest), the payment drops by about $68 per month, cash flow moves to roughly −$36 per month, and cash left in the deal rises to about $25,000. If the rent were $1,750 instead of $1,650, cash flow at the 75 percent refinance would be roughly break-even. Small changes in rent, rate, and loan-to-value move the outcome more than most investors expect. Run the numbers at three rent levels and two rates before you commit to any deal.

### The refinance math, generalized

Cash left in the deal = (purchase price + closing costs + rehab + holding costs) − (ARV × refinance loan-to-value − refinance closing costs).

For a perfect "infinite return" BRRRR — all cash out — you need ARV × LTV to exceed your all-in cost. In the example: $195,000 × 0.75 = $146,250, against $157,000 all-in. Close, but not all the way. Getting all cash out usually requires buying deeper below ARV, rehabbing cheaper, or an appraisal at the top of the comparable range — none of which you control fully. Plan for leaving $10,000 to $30,000 in each deal. A plan that requires a perfect refinance on every deal is not a plan.

### Where BRRRR breaks: a worked example of a deal that does NOT work

Same property type, different numbers. Purchase price $145,000 (you paid more because you competed with other buyers). Closing costs $4,500. Rehab: the contractor finds a cracked sewer line ($6,500), the electrical panel needs full replacement ($3,500), and the rehab runs six weeks over schedule. Total rehab: $48,000. Holding costs during the extra six weeks (taxes, insurance, utilities, loan interest): $3,500. All-in cost: $145,000 + $4,500 + $48,000 + $3,500 = **$201,000.**

The appraisal comes in at $190,000 — below your expected $200,000 ARV, because two comparable sales closed low while you were rehabbing. A 75 percent refinance gives a $142,500 loan, minus $4,500 in closing costs: $138,000 returned. Cash left in the deal: $201,000 − $138,000 = **$63,000.** You have $63,000 trapped in a property worth $190,000 with a $142,500 mortgage. Your capital is stuck, your next deal is delayed by a year or more, and if the rent is $1,600, the cash flow on that mortgage is negative by roughly $150 to $200 per month after reserves.

That is how a BRRRR deal fails: overpaying at purchase, rehab overruns, and an appraisal shortfall arriving together. None of those is rare. Every one of them is foreseeable, which is why Modules 4 and 6 exist — the 70 percent rule and the buy box are your defenses.

### The discipline that makes BRRRR work

First, never buy without an ARV supported by at least three recent comparable sales of renovated homes, adjusted honestly for size, condition, and location. Second, budget a 10 to 15 percent rehab contingency and assume you will spend it. Third, underwrite the refinance at an appraisal 5 to 10 percent below your expected ARV, and at a rate half a point above today's quote. If the deal still works under those stressed numbers, it is a real deal. If it only works at the optimistic appraisal and the lowest rate, walk away. Fourth, keep a cash reserve outside the deal — at least six months of expenses per property — so a delayed refinance is an inconvenience, not a crisis.

---

## Module 4: The 70% Rule and ARV for BRRRR Deals

### What the 70 percent rule is

The 70 percent rule is a quick screening tool: the maximum you should pay for a property equals 70 percent of its after-repair value, minus the cost of repairs. In formula form:

Maximum purchase price = (ARV × 0.70) − repair costs.

In the worked example from Module 3: ARV $195,000 × 0.70 = $136,500, minus $33,000 in repairs = $103,500 maximum purchase price. We paid $120,000 — above the rule. That is exactly why $15,250 stayed in the deal instead of coming out. The rule is not a moral judgment; it is arithmetic. Paying above it means leaving more cash in. Paying below it means recycling more.

### When to use it — and when not to

The 70 percent rule was built for flips and heavy BRRRR deals, where the margin is the profit. It is a useful screen, not a law. In a market where you plan to hold long term, where rents are strong and appreciation is steady, paying 75 or 80 percent of ARV can still be a sound investment if the cash flow works and you are comfortable leaving more capital in. The mistake is not violating the rule — it is violating it without knowing you did, and without adjusting your expectations for how much capital comes back.

Use the rule as your first filter on every BRRRR candidate. If a deal fails the rule by a wide margin, it needs an exceptional reason to proceed: unusually strong rent, a value-add you can execute cheaply, or a long hold horizon that justifies the trapped capital.

### Determining ARV honestly

ARV is the single most manipulated number in real estate investing, including by investors fooling themselves. Do it properly:

1. Find at least three comparable sales from the last three to six months, within roughly half a mile (closer in dense areas, wider in rural ones), of similar size (within about 20 percent of square footage), similar age and style, and — critically — in renovated condition similar to what your property will be after rehab. A sale of an unrenovated home is not a comparable for your ARV.
2. Adjust for real differences: an extra bedroom, a garage, a larger lot, a busy road. Appraisers adjust in the hundreds or low thousands per feature, not tens of thousands. If your "adjustments" are doing heavy lifting, your comparable is wrong.
3. Weight the most recent and most similar sales heaviest. A sale from eleven months ago in a moving market is a hint, not evidence.
4. Take the conservative end of the range. If your comparables support $185,000 to $205,000, underwrite at $190,000. The appraisal may come in anywhere in that range, and your plan should survive the low end.

### The appraisal is not your ARV

An appraisal is one licensed professional's opinion on one day, constrained by the comparable sales available that week and by the lender's guidelines. It can come in below your ARV for reasons that have nothing to do with your rehab quality: a thin comparable set, a conservative appraiser, a down market. Module 6 covers appraisal risk and your options when it happens. For now, internalize this: your ARV estimate is a hypothesis. The appraisal is the test. Underwrite so you pass even if the test is unkind.

---

## Module 5: Financing the Next Deal — Conventional, DSCR, Portfolio Lenders, HELOC, Private Money

As you scale past your first few properties, the financing question changes. It stops being "can I get a mortgage?" and becomes "which loan, for which property, in which order, without choking off the next deal?" This module compares the five main tools honestly.

### Conventional mortgages

A standard Fannie Mae or Freddie Mac loan on a one-to-four-unit investment property. Typical terms: 20 to 25 percent down, rates usually the lowest available, 30-year fixed common. Limits: most investors can hold up to ten financed properties, and after the fourth, lenders typically require six months of reserves per property and tighter documentation. Rental income counts toward qualification, but usually only 75 percent of gross rent, and often only after you have landlord history or the property is already leased.

Best for: your first several properties, stable long-term holds, and any deal where you want the lowest rate and longest fixed term. Worst for: deals that need fast closing, properties that are not yet habitable, and investors already at the financed-property limit.

### DSCR loans (Debt Service Coverage Ratio)

A DSCR loan qualifies based on the property's income rather than your personal income. The lender compares the property's monthly rent to its monthly mortgage payment (the DSCR). A ratio of 1.0 means rent exactly covers the payment; most lenders want 1.20 to 1.25. Your personal debt-to-income ratio matters far less, and there is generally no limit on the number of properties.

Trade-offs: rates are typically 1 to 2 percentage points above conventional, down payments are usually 20 to 25 percent, and some lenders require a prepayment penalty period. Because qualification depends on rent, a property that barely cash-flows may not qualify at all — the DSCR test is the underwriting.

Best for: investors who have hit conventional limits, self-employed investors whose tax returns understate their income, and scaling past four properties. Worst for: thin cash-flow deals and anyone who needs the lowest possible rate.

### Portfolio lenders

Local banks and credit unions that keep loans on their own books instead of selling them. Because they hold the risk, they can be flexible: they may lend on a property a conventional lender would reject, adjust terms for a strong local relationship, or offer commercial-style loans on five-plus-unit properties. Terms vary widely — five- or seven-year fixed periods with a longer amortization is common, sometimes with a balloon payment, which is a real risk you must plan for.

Best for: small multifamily, mixed-use, and properties that do not fit agency guidelines; investors who value a banking relationship. Worst for: anyone who needs a standardized 30-year fixed rate, and any deal where a balloon payment would arrive before you have an exit plan.

### HELOCs (Home Equity Lines of Credit)

A line of credit secured by equity in a property you own — often your primary residence, sometimes a rental. You draw what you need, pay interest only on what you draw, and repay and redraw as deals cycle. This is a powerful BRRRR funding tool: draw for the purchase and rehab, repay when the refinance returns cash.

Risks, stated plainly: the rate is usually variable, so your borrowing cost can rise; the line can be reduced or frozen by the lender if values fall; and you are putting your home (or a paid-off rental) at risk to fund investment deals. A HELOC is a tool for short-term capital, not a permanent source of down payments. Never fund a long-term hold with a draw you cannot repay from the refinance or from reserves.

Best for: bridging BRRRR purchase and rehab costs when you have substantial equity and a clear repayment path. Worst for: covering negative cash flow, funding a deal with no refinance plan, or borrowing against your primary home for a speculative purchase.

### Private money

Loans from individuals — friends, family, local investors, retirement-account holders — usually secured by the property, with terms you negotiate: interest rate, term, points, and repayment schedule. Rates are typically higher than bank loans (often 8 to 12 percent plus points), but closing can be fast and terms flexible.

Risks: the relationship risk is as real as the financial risk. A private loan that goes wrong can damage a friendship or family relationship permanently. Use written loan documents, a promissory note, and a recorded mortgage or deed of trust, prepared with an attorney — even with people you trust. Especially with people you trust. And be honest with yourself about whether you would take the same deal from a stranger at the same terms.

Best for: fast closings, deals banks will not touch yet, and short-term bridge funding with a clear exit. Worst for: long-term holds at high rates, and any loan where the lender does not fully understand the risk.

### How to choose: a decision framework

Ask four questions in order: (1) Does the property qualify for the loan — habitable, appraised, rented? (2) Does the loan qualify for you — property count, reserves, DSCR? (3) Does the monthly payment leave real cash flow after reserves? (4) Does this loan block or enable the next deal — does it consume your conventional slots, tie up your HELOC, or create a balloon you must refinance later? The cheapest rate is not always the best loan. The best loan is the one that fits this deal and leaves the next one possible.

### A note on leverage

Every loan in this module increases your return when things go well and increases your losses when they do not. Higher leverage means higher sensitivity to vacancy, rate changes, and value declines. There is no leverage level that is right for everyone. A useful gut check: if a six-month vacancy in one property, or a two-point rate rise on your next refinance, would force you to sell something, you are over-leveraged for your reserves. Build reserves first, then add leverage.

---

## Module 6: Refinancing Decisions — Rate, Cash-Out, Seasoning, Appraisal Risk

Refinancing is where scaling either compounds or stalls. A good refinance returns capital and improves your position. A bad one raises your payment, traps you in a higher rate, or fails entirely and leaves your capital locked in the property.

### The three refinance questions

Before any refinance, answer three questions in writing: (1) What is the purpose — lower rate, pull cash out, remove mortgage insurance, change term, or consolidate? (2) What is the break-even — how many months until the savings or the returned cash justify the closing costs? (3) What happens if the appraisal comes in 10 percent low — does the deal still work?

If you cannot answer all three, you are not ready to refinance.

### Rate-and-term versus cash-out

A rate-and-term refinance changes the interest rate or the loan term without taking cash out. It makes sense when the rate drop is large enough to recover closing costs within a reasonable period — commonly 18 to 24 months or less — and when you plan to hold the property past break-even. A cash-out refinance takes additional cash beyond the existing loan balance, secured by the property's equity. It is the BRRRR engine, but it raises your balance and your payment, and lenders typically charge a slightly higher rate for cash-out loans and cap the loan-to-value lower than a rate-and-term refinance.

Do not cash out to fund lifestyle spending. Cash-out proceeds should go to the next income-producing asset or to reserves. Every dollar you pull out is a dollar of debt service you will pay for the next thirty years.

### Seasoning

Seasoning is the period a lender requires you to own a property before it will refinance based on the new appraised value rather than your purchase price. Six months is the common requirement for conventional cash-out refinances; some lenders and loan types require twelve months, and some portfolio lenders have shorter seasoning or none at all. Delayed-financing rules exist for buyers who paid cash and want to refinance quickly — they have their own conditions and documentation requirements.

Plan your BRRRR timeline around seasoning, not around your enthusiasm. A deal that needs a refinance in month three with a lender that requires six months is a deal that needs a different lender or a longer holding plan — and six months of holding costs you must be able to carry.

### Appraisal risk and what to do about it

The appraisal can come in low for reasons outside your control. Your options, in order of preference: (1) Challenge it with a reconsideration of value, supplying comparable sales the appraiser missed — factual, documented, and polite. (2) Accept a smaller cash-out and leave more capital in the deal, if the cash flow still works. (3) Wait and re-apply later, if the low value was driven by a thin comparable set that may improve. (4) Bring a second lender and a second appraisal — expensive, and not guaranteed to differ. (5) Sell, if the numbers no longer work and the capital is needed elsewhere.

What not to do: pressure an appraiser, shop for an appraiser who will hit your number, or inflate your ARV estimate next time to compensate. The discipline is to underwrite at the low end of the comparable range (Module 4) so a soft appraisal is survivable.

### The refinance decision worksheet

The templates folder includes a refinance decision worksheet. Use it for every refinance. It forces you to write down the current loan, the proposed loan, the monthly payment change, the closing costs, the break-even month, the cash returned, the cash flow after the refinance, and the stressed scenario (appraisal 10 percent low, rate half a point higher). A refinance that only works in the optimistic column is not a refinance — it is a gamble.

---

## Module 7: House Hacking as a Scaling Tool

House hacking — living in one unit of a property you own while renting out the others, or renting out rooms in your own home — is the most underrated scaling tool for investors who already own rentals, because it attacks the biggest obstacle to scaling: the down payment and the living expense that competes with it.

### How it works after your first property

You may already have house-hacked your first property without calling it that. The scaling version is deliberate: you buy a two-to-four-unit property as your primary residence, which typically qualifies for owner-occupied financing — a lower down payment (often 3.5 percent with an FHA loan or 5 percent conventional, versus 20 to 25 percent for an investment property), a lower rate, and more forgiving qualification. You live in one unit and rent the others. The rents offset your mortgage, and in a good deal they cover most or all of it.

After a year (the typical owner-occupancy requirement — check your loan documents; do not misrepresent your intent), you can move out, keep the property as a rental, and repeat the process with another owner-occupied purchase. Each cycle converts a low-down-payment primary residence into a rental at a cost basis no investor loan could match.

### The math that matters

Compare the out-of-pocket cost honestly. A $300,000 duplex bought as an investment property at 25 percent down requires $75,000 plus closing costs. The same duplex bought owner-occupied at 5 percent down requires $15,000 plus closing costs. That $60,000 difference is two or three BRRRR deals' worth of capital. The trade-off is real too: you live next to your tenants, you move more often, and owner-occupied loans come with occupancy rules you must honor. But for an investor scaling from three doors to ten, the capital efficiency is hard to beat.

### Rules and risks

First, occupancy rules are loan terms, not suggestions. Your mortgage documents state how long you must live in the property. Violating them is mortgage fraud, and it is not a gray area. Second, FHA loans require mortgage insurance and have their own rules about prior FHA loans and self-sufficiency tests for three- and four-unit properties. Third, living with your tenants changes the landlord relationship — set boundaries early, keep communication professional, and use the same lease and screening standards you would for any tenant. Fourth, house hacking does not exempt you from the audit: the property still needs to cash-flow as a rental after you move out. Underwrite it as a rental first and a home second. If it only works while you live there rent-free, it is a housing subsidy, not an investment.

### When house hacking fits a scaling plan

It fits best when you are willing to move, when your market has two-to-four-unit properties at reasonable prices, and when capital — not deal flow — is your binding constraint. It fits poorly when your life does not allow a move, when small multifamily is scarce or overpriced in your market, or when you already have a home you intend to stay in for years. It is a tool, not an obligation.

---

## Module 8: Choosing the Right Next Market

Investors stall because they keep buying where they already own, even when that market no longer supports the numbers. Or they chase a distant "hot market" they have never visited. Both are avoidable. Market selection is a disciplined comparison, not a feeling.

### Start with your own portfolio's evidence

Your audited numbers from Module 1 tell you what your current market actually delivers: rent per door, vacancy, maintenance costs, appreciation. If your market delivers $150 per door and you need $300, you have two choices: a different strategy in the same market (small multifamily instead of single-family, for example), or a different market. Do not keep buying the same product in the same place and expecting a different result.

### The market scorecard

Score any candidate market on these factors, using public data and local sources rather than headlines:

- **Rent-to-price ratio.** Monthly rent divided by purchase price. A ratio of 1 percent ($1,500 rent on a $150,000 home) is a traditional cash-flow screen; many markets today are at 0.7 to 0.8 percent, which can still work with the right financing and low expenses, but demands honest underwriting. Compare markets on this ratio, not on absolute rent.
- **Vacancy and demand.** Population trend, job growth, employer diversity, and rental vacancy rates. A market with one dominant employer is a concentration risk. A market losing population is a demand risk, however cheap the houses.
- **Landlord law and taxes.** Property tax rates, insurance costs (especially in storm, wildfire, and flood zones), rent-control rules, and eviction timelines vary enormously by state and city. A market with low prices and hostile landlord law can be more expensive than a pricier market with predictable rules. Read the actual statutes or a local attorney's summary before investing in a new state.
- **Supply.** Permits and new construction in the pipeline. A market with a flood of new apartments coming online will face rent pressure. A market with constrained supply and steady demand supports rents.
- **Your edge.** Do you have a team there, a property manager you trust, local knowledge, or a reason to be there? Distance is a cost: travel, slower response to problems, and dependence on people you cannot easily check on. A slightly worse market where you have a strong team often beats a slightly better market where you have nobody.

### How to research a new market without moving there

Use census and labor data for population and employment trends; listing sites for current rents and days on market; local property-manager interviews (ask what they charge, what vacancy they see, and what tenant issues are common — managers will tell you more in one call than a week of reading); and a visit. Visit before you buy in a new market. Walk the streets at different times of day. Talk to a local agent, a contractor, and a property manager in person. If you cannot visit, you need a team member on the ground you trust deeply — and you should still visit before the second purchase.

### The market decision

Write a one-page market brief for any market you are considering: the rent-to-price ratio for your property type, the vacancy rate, the top three employers, the property tax rate, the insurance environment, the landlord-law summary, and your team's names. If you cannot fill in the brief, you are not ready to buy there. Choose one primary market for your next three to five acquisitions. Focus beats scattering. You can add a second market later, deliberately, once the first is systematized.

---

## Module 9: Building a Buy Box for Scale

A buy box is a written set of criteria that defines exactly what you will buy — and, just as importantly, what you will not. Without one, every listing looks like an opportunity, and you waste months evaluating deals that were never right. With one, you can screen a deal in five minutes and say no quickly, which is the skill that protects your time.

### What goes in a buy box

- **Property type and size:** for example, three-bedroom, one-to-two-bathroom single-family homes, 1,000 to 1,600 square feet, built after 1960; or two-to-four-unit multifamily.
- **Location:** named neighborhoods or zip codes, with the boundaries written down. "A good area" is not a boundary.
- **Price range:** maximum purchase price and maximum all-in cost.
- **ARV range and the 70 percent rule threshold:** the maximum you will pay relative to ARV (Module 4).
- **Rent and cash-flow minimums:** minimum monthly rent, minimum cash flow per door after reserves, minimum cash-on-cash return. State the numbers.
- **Condition:** the maximum rehab scope you will accept (cosmetic only, or light structural, never foundation work, for example).
- **Financing fit:** which loan types the property must qualify for.
- **Deal-breakers:** a written list. Examples: properties in a flood zone without affordable insurance, homes with unpermitted additions you cannot verify, properties with active code violations you cannot clear, and any deal where the seller will not allow an inspection.

### Why the buy box must be written

A buy box in your head changes with your mood. A written buy box holds you accountable when a charming house or a persuasive agent tempts you to stretch. It also lets you delegate: your agent can send you only properties that fit, and your contractor can estimate rehab against a known scope. The workbook's Buy-Box Worksheet is your template. Fill it in, date it, and review it every six months — markets change, and the box should change with evidence, not with enthusiasm.

### Using the buy box at scale

At scale, the buy box does two additional jobs. First, it standardizes your portfolio: similar properties mean similar rehab scopes, similar maintenance, similar tenant profiles, and similar management. Standardization is what makes ten units manageable. A portfolio of ten wildly different properties is ten different businesses. Second, it speeds up decisions: when a deal fits the box, you can move fast, which matters in competitive markets. Speed comes from preparation, not from rushing.

### When to break your own rules

Occasionally a deal outside the box is genuinely worth it — a larger multifamily property, a different neighborhood with strong fundamentals, a seller-financed opportunity. When that happens, write down why this deal is an exception, what is different about it, and what would have to be true for it to work. If you cannot write that paragraph, it is not an exception. It is an impulse.

---

## Module 10: Team Building — Agent, Contractor, Property Manager, Lender, Accountant

You cannot scale to ten units alone. Not because you lack ability, but because your time is the bottleneck. The team is the scaling mechanism. Build it before you need it, because building it during a crisis — a vacant property, a failed rehab, a tax deadline — is how bad hires happen.

### The five core roles

**Real estate agent.** Your deal-finder and market expert. The right agent for an investor is not the agent who sells the most expensive homes; it is the agent who understands your buy box, sends you off-market and pre-market opportunities, gives honest ARV opinions (including telling you when a deal is overpriced), and responds quickly. Interview at least three. Ask: how many investor clients do you work with, how many of your deals last year were below-market purchases, and what would you tell me not to buy?

**Contractor.** Your rehab partner. The most consequential hire in a BRRRR strategy, because rehab cost and timeline determine whether the refinance works. Vet thoroughly: licensed and insured (verify, do not take their word), references from at least three recent clients, a written scope of work with line-item pricing, a draw schedule tied to completed work (never pay most of the money up front), and a written change-order process. Get two bids on any rehab over $10,000. The cheapest bid is often the most expensive rehab.

**Property manager.** The person who converts your portfolio from a second job into an investment. A good manager handles leasing, rent collection, maintenance coordination, and tenant communication. Interview managers with specific questions: what is your fee structure (leasing fee, monthly percentage, maintenance markup, vacancy fee), what is your average vacancy, how do you screen tenants, how do you handle maintenance requests, and what does your monthly owner statement look like? Ask to see a sample statement. A manager who cannot produce a clear statement will not produce clear accounting.

Self-management versus hiring a manager is a real choice, not a moral one. Self-managing three doors can make sense. Self-managing ten usually does not, unless landlording is your full-time work. Price your own time honestly (Module 1) and decide based on the number, not on pride.

**Lender.** Not just a loan officer — a lending partner who understands investors. You need someone who can tell you, before you make an offer, whether a property qualifies for the loan you intend to use, what the seasoning rules are, and what your debt-to-income picture looks like after this purchase. Cultivate relationships with at least two lenders: a conventional/DSCR lender and a portfolio lender or credit union. When one lender's guidelines change, the other may still work.

**Accountant (CPA).** The person who keeps your scaling from becoming a tax surprise. Your CPA should understand real estate: depreciation, cost segregation (a formal study that can accelerate depreciation on components of a property — discuss whether it fits your situation), entity taxation, and the record-keeping the IRS expects. Meet your CPA before tax season, not during it. A planning conversation in October is worth far more than a filing conversation in April.

### How to build the team

Start with one role at a time, beginning with the role your next deal needs most. Ask other investors for referrals — local real estate investor groups, online communities, and your agent's network are good sources. Interview like you are hiring an employee, because you are. Check licenses, insurance, and references. Start with a small engagement — one rehab, one lease-up, one loan — before committing a large share of your portfolio to anyone.

### Managing the team

Set expectations in writing: response times, reporting formats, approval thresholds (for example, the manager may approve repairs under $300 without calling you, and must call above that). Review performance quarterly: vacancy, rent collection, maintenance costs, rehab timelines, and communication quality. Replace a weak team member early. The cost of keeping a bad contractor or manager for an extra year dwarfs the discomfort of replacing them.

---

## Module 11: Systems for Managing 10+ Units Without Burnout

Systems are what separate an investor with ten units and a life from an investor with ten units and a second full-time job. A system is a written process that someone else can follow without you. If only you know how it works, it is not a system — it is a habit, and it dies when you are busy, sick, or on vacation.

### The five systems every scaling portfolio needs

**1. Leasing system.** A written screening standard applied identically to every applicant: minimum credit score, income requirement (commonly gross monthly income of three times the rent), rental history, and background and eviction checks, applied consistently and in compliance with fair-housing law. A standard lease, a standard move-in checklist with photos, and a standard security-deposit process. Consistency is not just efficient — it is legally protective.

**2. Rent collection system.** Rent due on the first, late after the fifth (or per your lease and local law), with automated reminders and a written late-fee and follow-up process. Online payment preferred. The system should work without you sending a single message.

**3. Maintenance system.** Tenants report issues through one channel (a portal, an email address, or a form — not your personal phone at midnight). Requests are triaged: emergency (water, heat in winter, security) within hours; urgent within 48 hours; routine within a week. Your property manager or contractor handles dispatch. You approve spending above your threshold. Every completed repair is logged with a photo and a receipt. Over a year, this log becomes your maintenance history, which tells you which properties are aging and where capital expenditures are coming.

**4. Bookkeeping system.** Every dollar in and out, categorized by property, recorded monthly, reconciled against bank statements. Use dedicated accounts: one operating account for the portfolio, and ideally a separate account per property or per entity as your CPA advises. Never commingle rental money with personal money. At tax time, clean books save you money and stress; at refinance time, they prove your income to the lender; at sale time, they prove your basis.

**5. Communication system.** Tenants, manager, contractor, and lender each have a defined channel and a defined response expectation. Tenants do not have your personal cell number unless you have deliberately chosen that. Your manager sends you a monthly statement and flags exceptions. You review the portfolio for thirty minutes a week and one hour a month — scheduled, not reactive.

### The weekly and monthly rhythm

Weekly (thirty minutes): review rent collection, open maintenance requests, and any vacancies. Monthly (one hour): review the financials per property, compare cash flow against your targets, check reserves, and update the portfolio tracker. Quarterly (two hours): review the team, the market, insurance, and any upcoming capital expenditures. Annually: the full portfolio review in Module 15, plus a tax-planning conversation with your CPA.

### The burnout test

Ask yourself each quarter: if I added three more doors tomorrow, what would break first — my time, my cash, my team, or my systems? Fix that thing before you add the doors. Scaling is not about tolerating more strain. It is about building capacity and then using it.

---

## Module 12: Entity and Liability Overview (General Education Only)

This module is general education about how real estate investors commonly think about entities and liability. It is not legal advice, and it is not a recommendation for your situation. Entity choice affects your taxes, your liability exposure, your financing options, and your estate plan. Before forming, changing, or moving properties into any entity, consult a licensed real estate attorney and a CPA in your state. Laws vary by state, and the right structure for one investor can be the wrong structure for another.

### Why investors talk about entities

Two reasons dominate: liability protection and organization. Liability protection means separating your personal assets from the risks of owning rental property — a tenant injury, a contractor dispute, a slip on an icy step. Organization means holding properties in a structure that makes bookkeeping, banking, taxes, and eventual sale or inheritance cleaner.

The most commonly discussed entity for rental property is the limited liability company (LLC). An LLC, properly formed and properly maintained, can limit your personal liability for the debts and claims of the business — but it is not a magic shield. Courts can disregard an LLC that is not treated as a separate business (a concept sometimes called "piercing the corporate veil"), which is why maintenance matters as much as formation.

### What proper maintenance looks like

If you form an LLC, treat it as a real business: separate bank accounts, separate books, contracts and leases in the LLC's name, adequate insurance in the LLC's name, annual state filings and fees paid on time, and no commingling of personal and business funds. Paying your personal groceries from the LLC account, or signing a lease in your own name for an LLC property, undermines the separation the entity is meant to create. Your attorney can explain your state's specific requirements.

### Common structures investors discuss with their attorneys

- **Holding properties in your own name.** Simplest, easiest financing (conventional loans are generally simpler in a personal name), but no entity liability shield — insurance becomes your primary protection.
- **One LLC per property.** Maximum separation between properties, so a claim on one property does not reach the others — but also maximum cost and paperwork, with a separate filing, bank account, and tax treatment per entity.
- **One LLC holding several properties.** Simpler and cheaper, but a claim on one property can reach the other properties in the same LLC.
- **A holding company plus operating entities.** A structure some larger investors use, with a parent entity and separate entities per property or group of properties. More complex, more expensive, and only worth discussing once the portfolio is large enough to justify it.

There is no universally correct answer. The right structure depends on your state, your portfolio size, your risk tolerance, your financing, and your estate plan — which is why this is a conversation with your attorney, not a decision from a course.

### Insurance: your first line of defense

Regardless of entity structure, insurance is the protection that actually pays claims. At minimum, discuss with a licensed insurance agent: landlord liability coverage, property coverage at replacement cost (not market value), loss-of-rents coverage, and an umbrella liability policy that sits above your property policies. Review coverage annually and whenever you add a property. An entity without insurance is a shield with no one behind it; insurance without an entity is often sufficient for a small portfolio — again, a question for your attorney and agent.

### Financing and entities: a real trade-off

Here is the trade-off many investors discover too late: conventional and DSCR lenders often prefer or require properties to be held in a personal name, or require a personal guarantee even when the property is in an LLC. Transferring a property with a conventional mortgage into an LLC can trigger the loan's due-on-sale clause — the lender's right to demand full repayment if the property is transferred. Some investors do it anyway and some lenders do not enforce it, but "probably fine" is not a legal strategy. Discuss any transfer with your attorney and your lender before you do it. The order matters: many investors buy in their personal name, then transfer to an LLC only after consulting counsel — and some never transfer, relying on insurance instead.

### Your action step

Do not form an entity this week because a course mentioned it. Instead, book a one-hour consultation with a real estate attorney in your state. Bring your portfolio audit from Module 1, your scaling target from Module 2, and a list of your questions. Ask: what structure fits my portfolio size and state, what will it cost to form and maintain, what are the financing implications, and what insurance do I need regardless? That consultation is one of the highest-value hours in your scaling plan.

---

## Module 13: Taxes at Portfolio Scale (General Education Only)

This module is general education about how rental real estate is commonly taxed. It is not tax advice, and it is not a recommendation for your situation. Tax law is complex, it changes, and its application depends on your income, your filing status, your state, and your specific facts. Before making any tax decision — including entity choice, depreciation strategy, or a 1031 exchange — consult a licensed CPA who works with real estate investors. The goal of this module is to help you ask your CPA better questions, not to answer them yourself.

### The basic picture

Rental income is generally taxable, but rental activity also generates deductions: mortgage interest, property taxes, insurance, repairs, property management, travel for business purposes, and depreciation. Depreciation is the deduction that surprises new investors most: the tax code allows you to deduct a portion of a property's value each year as if it were wearing out, even while the property may be appreciating in market value. Residential rental property is generally depreciated over 27.5 years (land is not depreciable — only the building). That deduction can make a property that cash-flows positively show a paper loss for tax purposes. A paper loss is not the same as a losing property, and it is not a reason to buy a bad deal.

### What changes as you scale

At one property, taxes are a line on your return. At ten, they are a planning exercise:

- **Record-keeping becomes the deduction.** Every deduction you cannot document is a deduction you cannot defend. The bookkeeping system from Module 11 is your tax system. Keep receipts, log mileage, and categorize expenses by property.
- **Passive activity rules matter more.** Rental income is generally passive income, and passive losses are generally limited in how they can offset other income, with exceptions — including one for real estate professionals, which has strict requirements (including a minimum number of hours and the requirement that real estate be your primary professional activity). Whether you qualify is a determination for your CPA, based on your actual hours and facts. Do not assume you qualify because you own rentals.
- **Depreciation recapture appears at sale.** When you sell a property you have depreciated, the tax code generally requires you to pay tax on the depreciation you claimed (or could have claimed), at a special rate. This is one reason a sale that looks profitable on the surface can produce a larger tax bill than expected. Your CPA can model this before you sell — never after.
- **Cost segregation is a conversation, not a do-it-yourself project.** A cost segregation study identifies components of a property (appliances, flooring, landscaping, and other items) that can be depreciated over shorter periods than 27.5 years, accelerating deductions into earlier years. It costs money, it requires a qualified professional, and it is generally most valuable on larger or higher-value properties. Ask your CPA whether it fits your portfolio.

### Common mistakes at portfolio scale

Claiming personal expenses as rental expenses. Failing to track basis (your tax cost in a property, which changes with improvements, depreciation, and refinances). Forgetting that a cash-out refinance is generally not taxable income when you receive it — the tax consequences arrive later, at sale, through basis and recapture. Mixing properties' books so you cannot tell which property is performing. And the most expensive mistake of all: making an investment decision (buying, selling, or exchanging) for tax reasons alone, without checking whether the underlying investment makes sense.

### Your action step

Meet your CPA twice a year: once in the fall for planning (what should you do before year-end — repairs, purchases, sales?), and once before filing. Bring your portfolio tracker and your books. Ask three questions every time: what is my projected tax liability this year, what decisions before year-end would change it, and what records do you need from me that I am not currently keeping? Good tax planning is boring, regular, and done in advance. It is never a scramble in April.

---

## Module 14: Tracking Portfolio Performance — Cash Flow, Equity, ROI per Property

What gets measured gets managed, and what gets measured per property gets fixed. Portfolio-level averages hide problems. This module gives you the metrics that matter and the discipline to use them.

### The metrics

- **Cash flow per property per month.** Trailing twelve months, after all expenses and reserves (Module 1). This is your operating truth.
- **Cash-on-cash return.** Annual cash flow divided by total cash invested. Useful for comparing properties against each other and against your next deal.
- **Return on equity.** Annual cash flow divided by current equity. This tells you whether your equity is working. A property with $100,000 in equity producing $2,400 a year in cash flow earns a 2.4 percent return on equity. That equity may be better deployed elsewhere — or it may be fine, if the property is appreciating and the rent is growing. The number does not decide for you. It forces the question.
- **Equity growth.** Change in equity over the year from loan paydown plus market appreciation. Track it separately from cash flow — they are different kinds of return, and a property can be strong on one and weak on the other.
- **Total return.** Cash flow plus equity growth (paydown plus appreciation), divided by cash invested. The most complete single number, and also the most sensitive to your appreciation estimate — so always show it with and without appreciation.
- **Vacancy rate and turnover cost.** Days vacant per year and the cost of each turnover (lost rent plus make-ready costs). A property that looks profitable but turns over every year is less profitable than it appears.
- **Rent growth.** Year-over-year rent change per property, compared with your market. If your rents are flat while the market rises, you are leaving money on the table — or your properties are falling behind competitively.

### The portfolio tracking template

The templates folder includes a portfolio tracking spreadsheet. One row per property, updated monthly: rent collected, expenses by category, cash flow, loan balance, estimated value, equity, and the returns above. Fifteen minutes a month, once the template is set up. The spreadsheet does the arithmetic; your job is to enter honest numbers and read the results.

### How to use the numbers

Monthly, look for exceptions: any property whose cash flow moved by more than 20 percent from its average, any expense category that spiked, any rent that did not arrive. Quarterly, compare properties against each other and ask the hold-or-fix question for the weakest one. Annually, run the full review in Module 15. The point of tracking is not the spreadsheet. It is the decisions the spreadsheet makes obvious.

### A caution about appreciation

Appreciation is real wealth when you sell or refinance, and it is not income until then. Do not fund your lifestyle from estimated appreciation, and do not justify a negative-cash-flow property solely because "it will appreciate." It might. It might not. Markets fall. Cash flow is what pays the mortgage when the market is flat.

---

## Module 15: When to Sell, Hold, or 1031 Exchange (General Education Only)

This module is general education about the sell/hold/exchange decision. It is not tax or legal advice. A 1031 exchange is a tax provision with strict rules and deadlines, and the discussion below is a general overview only. Before selling or exchanging any property, consult your CPA and a qualified intermediary and a real estate attorney. Do not attempt a 1031 exchange without professional guidance.

### The hold-or-sell framework

Evaluate each property annually against four questions:

1. **Is it meeting its cash-flow target?** Compare its trailing-twelve-month cash flow per door against your buy-box minimum. If it has missed for two consecutive years and you cannot identify a fix (rent increase, expense reduction, refinance), it is a candidate for sale.
2. **Is its return on equity competitive?** If a property holds $120,000 in equity and produces $2,000 a year in cash flow, that equity earns under 2 percent. Could that equity earn more in your next acquisition? If the answer is clearly yes, selling — even a "good" property — can be the right scaling move.
3. **Is the property consuming disproportionate time or stress?** A property with chronic maintenance issues, a difficult location, or a tenant pattern that drains your time has a cost that does not appear in the spreadsheet. Price it honestly.
4. **Does it still fit the portfolio?** A property that fit when you owned two may not fit a ten-unit portfolio: wrong market, wrong property type, wrong management profile. Portfolios evolve. Letting go of a property that no longer fits is not failure. It is portfolio management.

### When holding is right

Hold when the property cash-flows at or above target, the return on equity is competitive, the market fundamentals are stable or improving, and the property fits your systems. Holding is the default. Selling should require a reason, not the other way around.

### When selling is right

Sell when the property chronically underperforms and cannot be fixed, when the equity can earn materially more elsewhere, when the property no longer fits your strategy, or when your life circumstances require the capital. Sell deliberately, in a season that favors sellers if you can choose, with the tax consequences modeled by your CPA before you list — not discovered at filing time.

### The 1031 exchange: a general overview

A 1031 exchange, named for Section 1031 of the Internal Revenue Code, generally allows an investor to defer capital-gains tax when selling an investment property and reinvesting the proceeds into a like-kind investment property. The rules are strict and unforgiving: the replacement property must generally be identified within 45 days of the sale, the exchange must generally close within 180 days, the proceeds must be held by a qualified intermediary (you cannot touch them), and the replacement property must generally be of equal or greater value with equal or greater debt to fully defer the tax. Miss a deadline or touch the funds, and the exchange generally fails and the tax becomes due.

Whether a 1031 exchange fits your situation depends on your tax picture, your portfolio, and your plans — and the rules have changed over time and may change again. This is a decision for your CPA and a qualified intermediary, made before you sell. Never list a property "planning to 1031" without professional guidance already engaged.

### The decision log

Whatever you decide for each property each year, write it down: hold, fix, or sell — and why, in one sentence. A year later, that log is the most honest teacher you have.

---

## Module 16: Common Scaling Mistakes and How to Avoid Them

Most scaling failures are not bad luck. They are the same handful of mistakes, repeated. Learn them here, cheaply, instead of in your own portfolio.

**1. Buying the next property before fixing the last one.** A leaking roof on property two does not get cheaper while you buy property four. Fix the problem property first, or sell it. Scaling a broken operation multiplies the breakage.

**2. Underwriting with gross rent instead of collected rent.** Vacancy, late payment, and turnover are real. Underwrite with trailing-twelve-month collected rent and explicit vacancy and maintenance reserves. If a deal only works at 100 percent occupancy and zero repairs, it does not work.

**3. Trusting the seller's numbers.** Sellers and their agents present the best version of a property's financials. Verify rent with leases and bank deposits, verify expenses with tax returns or actual bills, and verify condition with your own inspection and contractor. "Pro forma" means "made up." Treat it accordingly.

**4. Rehabbing to your taste instead of the tenant's.** Granite counters and designer fixtures do not rent for proportionally more in a working-class rental. Rehab to a clean, durable, competitive standard for the rent you intend to charge — and stop. Every dollar over that standard is a dollar that must be recovered from rent that may not rise to meet it.

**5. Over-leveraging.** Maximum leverage on every deal leaves no room for a bad appraisal, a vacancy, or a rate rise. Keep reserves of at least six months of expenses per property, and stress-test every deal at a higher rate and a lower rent before you buy.

**6. Hiring the cheapest contractor or manager.** The cheapest bid usually becomes the most expensive outcome: unfinished work, callbacks, tenant complaints, turnover. Hire on references, communication, and track record. Pay a fair price for a good job.

**7. Scaling in too many markets at once.** Each new market is a new team, new laws, new taxes, new knowledge. Master one market for your next three to five deals before adding a second.

**8. Ignoring the refinance until it is urgent.** Refinancing takes time — seasoning, appraisal, underwriting. Start the conversation with your lender months before you need the cash. A refinance you need next week is a refinance that will cost you.

**9. Letting one bad property poison the portfolio.** A chronically underperforming property drains cash, time, and attention that the rest of the portfolio needs. Use the Module 15 framework annually and act on it. Hope is not a management strategy.

**10. Confusing activity with progress.** Looking at listings, attending meetings, and talking about deals feel productive. Progress is measured in audited cash flow, doors owned, and equity — the three numbers from Module 2. If those are not moving, the activity is not working.

---

## Module 17: Your 3-Year Scaling Roadmap

This module turns everything before it into a dated plan. A roadmap is not a prediction — it is a sequence of decisions with dates attached, so you know what to do next and when to do it.

### Year 1: Foundation

- Complete the portfolio audit (Module 1) and set your target (Module 2).
- Build or rebuild your buy box (Module 9).
- Interview and hire the two team members your next deal needs most — usually an investor-friendly agent and a lender.
- Set up the five systems from Module 11, or hand them to a property manager with written expectations.
- Acquire one to two properties that fit the buy box, underwritten at stressed numbers.
- Execute your first BRRRR cycle if that is your strategy, and complete the refinance on schedule.
- Hold a tax-planning meeting with your CPA in the fall.

### Year 2: Momentum

- Acquire two to three more properties, recycling capital from Year 1 refinances.
- Hire a property manager if you have not already, once the portfolio reaches the size where self-management costs you more than it saves.
- Complete the annual portfolio review (Module 15) and act on it: fix, hold, or sell the weakest property.
- Consult a real estate attorney about entity structure (Module 12) as the portfolio grows.
- Deepen your market knowledge: one market, thoroughly, rather than two markets superficially.

### Year 3: Scale

- Acquire two to three more properties, reaching your target unit count or coming close.
- Evaluate whether small multifamily or a larger property fits your next step, now that your systems and team are proven.
- Review financing capacity: have you reached conventional limits, and is a DSCR or portfolio lender the right next step?
- Run the annual portfolio review and the tax-planning meeting as established routines, not special events.
- Decide, deliberately, whether to keep scaling at the same pace, consolidate, or pause and let the portfolio season. All three are legitimate. The wrong choice is drifting.

### Milestones and decision points

Build your roadmap around decision points, not just acquisitions: the date you will review your buy box, the date you will interview property managers, the date you will meet your CPA, the date you will complete your annual portfolio review. Acquisitions are events. Decisions are the plan.

### When the plan changes

It will. A deal falls through, an appraisal comes in low, a market shifts, life intervenes. When that happens, return to Module 1: re-audit, re-check the target, and adjust the timeline. A roadmap that cannot change is a fantasy. A roadmap that changes deliberately, with the numbers in front of you, is how portfolios actually get built.

---

## Module 18: Two Complete Portfolio Examples — From 3 Properties to 10

### Example A: The 3-Property Start

Meet a hypothetical investor, Dana. Dana owns three single-family rentals in one Midwestern market. The numbers below are illustrative, built from stated assumptions.

**Property 1:** Purchased 2021 for $110,000, $22,000 down plus $5,000 closing costs, $8,000 in initial repairs — $35,000 total cash invested. Current value $155,000, loan balance $82,000, equity $73,000. Rent $1,400 per month. Mortgage (principal, interest, taxes, insurance) $780. Management $112. Maintenance reserve $70. Vacancy reserve $70. Capital-expenditure reserve $70. Cash flow: $1,400 − $1,102 = **$298 per month**, $3,576 per year. Cash-on-cash return: $3,576 ÷ $35,000 = 10.2 percent. Return on equity: $3,576 ÷ $73,000 = 4.9 percent.

**Property 2:** Purchased 2022 for $135,000, $27,000 down plus $5,500 closing costs, $12,000 in repairs — $44,500 total cash invested. Current value $175,000, loan balance $102,000, equity $73,000. Rent $1,550 per month. Mortgage $920. Management $124. Maintenance $78. Vacancy $78. Capital-expenditure $78. Cash flow: $1,550 − $1,278 = **$272 per month**, $3,264 per year. Cash-on-cash return: 7.3 percent. Return on equity: 4.5 percent.

**Property 3:** Purchased 2023 for $150,000, $30,000 down plus $6,000 closing costs, $10,000 in repairs — $46,000 total cash invested. Current value $180,000, loan balance $115,000, equity $65,000. Rent $1,500 per month. Mortgage $1,010. Management $120. Maintenance $75. Vacancy $75. Capital-expenditure $75. Cash flow: $1,500 − $1,355 = **$145 per month**, $1,740 per year. Cash-on-cash return: 3.8 percent. Return on equity: 2.7 percent.

**Dana's starting position:** Three properties, $211,000 in total equity, $8,580 per year in combined cash flow ($715 per month), $125,500 total cash invested. Property 3 is the weak link: a 2.7 percent return on equity and the lowest cash-on-cash return. Dana's first scaling decision is not to buy property four — it is to fix or sell property three. Raising its rent from $1,500 to $1,600 at renewal (supported by comparable rents) would add $1,200 a year and lift its cash flow to $245 per month. If the market does not support that rent, Dana should model a sale: selling at $180,000, after roughly $12,000 in selling costs and paying off the $115,000 loan, would return about $53,000 in cash (before taxes — consult a CPA), which could fund the next two acquisitions.

### Example B: The Path to 10

Dana's target: ten units in three years, producing at least $3,000 per month in true cash flow, managed by a property manager, with no more than five hours a week of Dana's time.

**Year 1:** Dana fixes property 3 (rent raised to $1,600, cash flow $245 per month) and completes a BRRRR deal modeled on Module 3: purchase $120,000, rehab $33,000, all-in $157,000, appraised at $195,000, refinanced at 75 percent ($146,250), $15,250 left in the deal, rent $1,650. Dana also house-hacks a duplex as a primary residence: purchase $260,000, 5 percent down ($13,000) plus $7,000 closing costs, rents the other unit for $1,300 while living in one side. End of Year 1: six units (three original, one BRRRR single-family, two duplex units), with the duplex converting to a full rental in Year 2.

**Year 2:** The duplex is fully rented ($1,300 + $1,250 = $2,550 per month gross). Dana completes two more BRRRR deals using recycled capital from the Year 1 refinance plus savings, each leaving roughly $15,000 to $20,000 in the deal. A property manager is hired at 8 percent. End of Year 2: eight units.

**Year 3:** Dana completes one more BRRRR deal and buys a four-unit property with a DSCR loan (conventional limits are approaching), reaching twelve units — above the ten-unit target, with a mix of single-family and small multifamily.

**Year 3 portfolio (illustrative, using the per-property cash flows from the examples):** Twelve units producing approximately $3,200 to $3,800 per month in true cash flow after reserves and management, with total equity of roughly $450,000 to $550,000 depending on market appreciation. The exact figures depend on the actual rents, rates, and appraisals Dana achieves — which is why the plan is built on stressed underwriting and reviewed annually, not on these illustrative numbers.

**What made it work:** Dana fixed the weak property before scaling, used BRRRR to recycle capital, used house hacking to acquire a duplex at low down payment, hired a manager before burnout, and reviewed the portfolio annually. What could break it: a low appraisal on any BRRRR refinance, a rehab overrun, a vacancy cluster, or a rate rise at refinance. Dana's defenses are the reserves (six months of expenses per property), the stressed underwriting, and the annual review.

**What Dana did not do:** Dana did not buy seven properties in Year 1, did not skip inspections, did not trust pro forma numbers, and did not finance lifestyle spending with cash-out proceeds. Scaling is a sequence of sound decisions, not a single bold one.

---

## Closing: The Work Ahead

You now have the frameworks: the audit, the target, the BRRRR math, the financing comparison, the refinance discipline, the market scorecard, the buy box, the team, the systems, and the roadmap. None of them makes you money on their own. What makes you money is using them — on real deals, with real numbers, reviewed honestly every month.

Start this week. Complete the portfolio audit. Set the target. Fill in the buy box. Book the CPA meeting and the attorney consultation. Then find one deal that fits, underwrite it at stressed numbers, and decide. That is the whole business, repeated: audit, underwrite, buy, manage, review, repeat. Ten units is not a leap. It is the same careful step, taken seven more times.

*This course is educational content only. It is not individualized financial, legal, tax, or investment advice. Consult licensed professionals before making investment, financing, entity, or tax decisions. Real estate investing involves risk, including the possible loss of capital. Past performance and illustrative examples do not guarantee future results.*

---

## Appendix A: The 15-Minute Deal Screen

Use this screen on every property before you spend money on an inspection or an appraisal. If a deal fails the screen, pass quickly and move on. Your time is the scarcest resource in scaling.

**Step 1 (2 minutes): Does it fit the buy box?** Property type, location, price range, condition. If any answer is no, stop. No exceptions without the written exception paragraph from Module 9.

**Step 2 (3 minutes): What is the ARV?** Find three comparable renovated sales. Take the conservative end of the range. If you cannot find three, the ARV is a guess — treat it as one and discount it by 10 percent.

**Step 3 (3 minutes): What is the maximum purchase price?** Apply the 70 percent rule: (ARV × 0.70) − repair costs. Compare it with the asking price. If the asking price is more than 10 percent above your maximum, the deal needs a negotiation that may not happen. Decide now whether you will offer your number and walk away if it is refused.

**Step 4 (3 minutes): What is the rent?** Check at least three comparable rentals — same size, same condition, same neighborhood, currently listed or recently leased. Take the middle value, not the highest. If the seller's rent claim is above your comparable range, use your number.

**Step 5 (4 minutes): Does it cash-flow at stressed numbers?** Run the monthly math with rent 5 percent below your estimate, a rate half a point above today's quote, and full reserves (5 percent vacancy, 5 percent maintenance, 5 percent capital expenditures). If cash flow is negative under stress, decide deliberately whether you are accepting that — and why — before you offer.

A deal that passes all five steps deserves an offer, an inspection, and a contractor walk-through. A deal that fails two or more steps deserves a polite no. Most deals will fail. That is normal. A scaling investor reviews many deals and buys few. The screen is what makes that pace sustainable.

## Appendix B: Underwriting Quick Reference

**Gross rent multiplier (GRM):** Purchase price ÷ annual gross rent. A rough comparison tool between similar properties in the same market. Lower generally means more cash flow per dollar, but it ignores expenses entirely — never use it alone.

**Capitalization rate (cap rate):** Net operating income (annual rent minus operating expenses, excluding mortgage payments) ÷ purchase price. Useful for comparing properties and markets, especially multifamily. A higher cap rate generally means a higher return and higher risk. Compare cap rates only within the same market and property type.

**Cash-on-cash return:** Annual cash flow ÷ total cash invested. Your most practical comparison metric for deals you fund with your own money. Compare it with your buy-box minimum and with your current portfolio's average.

**Debt service coverage ratio (DSCR):** Monthly rent (or net operating income, depending on the lender) ÷ monthly mortgage payment. Lenders commonly require 1.20 to 1.25. Calculate it the way your lender calculates it — ask them for their exact formula before you rely on your own.

**Loan-to-value (LTV):** Loan balance ÷ property value. Lenders cap it by loan type. Your refinance proceeds are ARV × LTV minus closing costs. Every point of LTV is real money at refinance — and real payment every month after.

**Break-even occupancy:** The occupancy rate at which a property's income exactly covers its expenses. Calculate it per property: (annual operating expenses + annual mortgage payments) ÷ (annual gross potential rent). If break-even occupancy is above 90 percent, the property has little room for vacancy. If it is below 75 percent, it can survive a rough year.

**Reserves — the non-negotiable line:** Six months of mortgage payments, taxes, insurance, and operating expenses per property, held in cash, separate from deal capital. This is not a suggestion for cautious people. It is the difference between a bad quarter and a forced sale. Build reserves before you buy the next property, not after.

## Appendix C: Glossary

**After-repair value (ARV):** The estimated market value of a property after renovations are complete, supported by comparable sales of renovated properties.

**BRRRR:** Buy, Rehab, Rent, Refinance, Repeat — a strategy for recycling capital through successive properties.

**Buy box:** A written set of criteria defining exactly what an investor will and will not buy.

**Capital expenditures (CapEx):** Large, infrequent replacements — roof, HVAC, water heater, major appliances — budgeted as a monthly reserve.

**Cash-out refinance:** A new mortgage larger than the existing loan balance, with the difference paid to the borrower in cash.

**Debt service coverage ratio (DSCR):** A measure of whether a property's income covers its mortgage payments, used by lenders to qualify loans.

**Due-on-sale clause:** A mortgage provision allowing the lender to demand full repayment if the property is transferred, for example into an LLC.

**HELOC:** Home equity line of credit — a revolving line of credit secured by equity in a property.

**1031 exchange:** A tax provision that may allow deferral of capital-gains tax when an investment property is sold and the proceeds are reinvested in like-kind property, subject to strict rules and deadlines. Consult a CPA and a qualified intermediary before attempting one.

**Seasoning:** The period a lender requires you to own a property before refinancing based on its new appraised value.

**Return on equity:** Annual cash flow divided by current equity in a property.

---

## Appendix D: Your First 90 Days With This Course

A course only works if it changes what you do next week. Here is a concrete 90-day plan.

**Days 1–7: Know where you stand.** Complete the portfolio audit from Module 1 using the workbook's Portfolio Audit worksheet. Fill in every line. If a number is missing, find it — call your lender for the loan balance, check your bank statements for collected rent, ask your property manager for the twelve-month maintenance total. Write your scaling target paragraph from Module 2 and put it where you will see it weekly.

**Days 8–14: Build the tools.** Fill in your buy box from Module 9. Set up the portfolio tracking spreadsheet from the templates folder with your current properties. Open a dedicated bank account for the portfolio if you have not already, and separate your rental bookkeeping from your personal spending. Book two appointments: a tax-planning conversation with a CPA and a consultation with a real estate attorney about entity structure. Even if both meetings are a month away, having them booked changes your behavior now.

**Days 15–30: Build the team.** Interview at least two investor-friendly agents and two lenders (one conventional/DSCR, one portfolio lender or credit union). Tell each of them your buy box and your target. Ask the lender to review your debt-to-income picture and tell you what you qualify for today — and what would need to change for the next deal. If you self-manage, interview two property managers now, before you need one, so you know the cost and the standard.

**Days 31–60: Find and screen deals.** Ask your agent for every property that fits your buy box. Run the 15-minute screen from Appendix A on each one. Expect to screen ten or more and offer on one or two. For any offer, run the BRRRR calculator or the purchase underwriting at stressed numbers: rent 5 percent low, rate half a point high, appraisal 10 percent low. Get a contractor walk-through and a full inspection before you commit. A deal you pass on costs you nothing. A deal you buy wrong costs you years.

**Days 61–90: Execute and review.** Close on a deal that passed the screen, or — if none did — write down why each candidate failed and what that tells you about your market or your buy box. Either outcome is progress if it is documented. Begin the rehab with a written scope of work and a draw schedule. Set up the leasing, rent collection, maintenance, and bookkeeping systems from Module 11 for the new property. At day 90, review the three numbers from Module 2: doors owned, cash flow per door, and total equity. Then set the next 90 days.

Ninety days from now you will either own one more good property with systems around it, or you will know exactly why you do not — and what to change. Both are far better than ninety days of looking at listings.

---

## A Final Word on Risk

Every strategy in this course carries risk, and the honest investor plans for the risks, not just the returns. Appraisals can come in low. Contractors can disappear. Tenants can stop paying. Rates can rise between purchase and refinance. A roof can fail in the same month a tenant moves out. None of this means you should not invest. It means you should invest with reserves, with stressed underwriting, with insurance, with a team, and with a written plan you revisit every year.

The investors who build lasting portfolios are rarely the boldest or the fastest. They are the ones who underwrite honestly, keep cash in reserve, fix problems early, and keep going after a deal goes wrong — because one bad deal, handled well, is a lesson, while one bad deal handled badly can end the portfolio. Your edge is not a secret strategy. It is discipline, repeated over years. This course gives you the frameworks. The discipline is yours to supply.

*If you take one idea from this course, let it be this: scale the systems before you scale the doors. A portfolio built on honest numbers, real reserves, and a team you trust will carry you through the years when the market does not cooperate — and those are the years that decide who still owns their portfolio at the end.*
