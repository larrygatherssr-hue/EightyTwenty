# Annual Portfolio Review

Complete once a year for every property you own. Set aside two hours. Bring your portfolio tracking spreadsheet, your books, and last year's review so you can compare.

*Educational material only. Not individualized financial, legal, tax, or investment advice. Consult a CPA and a licensed attorney before selling, exchanging, or restructuring any property.*

## Review year: ______ Date completed: ______

## 1. Portfolio Summary

| Metric | This year | Last year | Change |
|---|---|---|---|
| Doors / units owned | | | |
| Total portfolio value (estimated) | $ | $ | $ |
| Total loan balances | $ | $ | $ |
| Total equity | $ | $ | $ |
| Total rent collected | $ | $ | $ |
| Total expenses (all categories) | $ | $ | $ |
| Total cash flow | $ | $ | $ |
| Cash flow per door per month | $ | $ | $ |
| Average vacancy days per property | | | |
| Total landlord hours per week (average) | | | |

## 2. Property-by-Property Review

| Property | Cash flow (T12) | Return on equity | Rent vs. market | Condition / CapEx due in next 12 months | Decision: Hold / Fix / Sell |
|---|---|---|---|---|---|
| | $ | ___% | Below / At / Above | | |
| | $ | ___% | Below / At / Above | | |
| | $ | ___% | Below / At / Above | | |
| | $ | ___% | Below / At / Above | | |
| | $ | ___% | Below / At / Above | | |

For each property marked **Fix**, write the fix and the deadline:
- Property ______: Fix ____________________ by __________
- Property ______: Fix ____________________ by __________

For each property marked **Sell**, write the reason and the tax question to ask your CPA:
- Property ______: Reason ____________________. CPA question: ____________________
- Property ______: Reason ____________________. CPA question: ____________________

## 3. Hold-or-Sell Check (per property — see Module 15)

For the weakest property, answer all four questions:
1. Is it meeting its cash-flow target? Yes / No
2. Is its return on equity competitive with my next acquisition? Yes / No
3. Is it consuming disproportionate time or stress? Yes / No
4. Does it still fit the portfolio (market, type, management)? Yes / No

Decision: ____________________ Reason in one sentence: ____________________

## 4. Financing and Insurance Check

- [ ] Loan statements reviewed; rates, balances, and any upcoming rate adjustments or balloon dates noted
- [ ] Conventional financed-property count: ______ (limit is generally 10 — check current guidelines with your lender)
- [ ] Reserves: ______ months of expenses per property held in cash (target: at least 6)
- [ ] Insurance reviewed with agent; coverage at replacement cost; umbrella policy in place: Yes / No
- [ ] Any upcoming refinances or seasoning dates: ____________________

## 5. Team and Systems Check

- [ ] Property manager performance reviewed (vacancy, collection, communication)
- [ ] Contractor performance reviewed (quality, timeline, cost)
- [ ] Lender relationship current; next deal's financing discussed
- [ ] Bookkeeping clean and reconciled by property
- [ ] Lease and screening standards applied consistently

Team changes needed: ____________________

## 6. Tax and Legal Check

- [ ] Tax-planning meeting with CPA held — date: __________
- [ ] Entity structure reviewed with attorney — date: __________
- [ ] Depreciation and basis records current
- [ ] Any planned sale or 1031 exchange discussed with CPA and qualified intermediary BEFORE listing: Yes / No / N/A

## 7. Market and Buy Box

- Buy box still accurate for my market? Yes / No
- Changes needed: ____________________
- Market fundamentals (rents, vacancy, employers, taxes, insurance) changed this year? How: ____________________

## 8. Next Year's Plan

- Acquisition target next year: ______ properties, in ____________________ (market), using ____________________ (strategy)
- Capital needed: $______ Capital source: ____________________
- Systems or team changes planned: ____________________
- Scaling target still on track? Yes / No — adjustment: ____________________

## 9. Decision Log

Write down this year's decisions so next year's review has a record:

| Property | Decision | Reason (one sentence) | Date |
|---|---|---|---|
| | | | |
| | | | |
| | | | |
