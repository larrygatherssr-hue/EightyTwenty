# Refinance Decision Worksheet

Use this worksheet for every refinance. Fill it in before you apply — not after the appraisal comes back.

*Educational material only. Not individualized financial, legal, tax, or investment advice.*

## 1. Purpose

What is the purpose of this refinance? (Check one — a refinance with two purposes is usually a refinance with no clear purpose.)
- [ ] Lower interest rate (rate-and-term)
- [ ] Pull cash out for the next investment (cash-out)
- [ ] Change loan term
- [ ] Remove mortgage insurance
- [ ] Other: ____________________

If cash-out: what exactly will the proceeds be used for? ____________________
(Cash-out proceeds should go to the next income-producing asset or to reserves — not to lifestyle spending. Every dollar pulled out is debt service for the next thirty years.)

## 2. Current Loan vs. Proposed Loan

| Item | Current loan | Proposed loan |
|---|---|---|
| Lender | | |
| Balance | $ | $ |
| Interest rate | ___% | ___% |
| Loan type | | |
| Monthly payment (P&I) | $ | $ |
| Remaining term | ___ years | ___ years |
| Cash out (if any) | — | $ |
| Closing costs | — | $ |

## 3. Break-Even

- Monthly payment change: $______ (savings / increase)
- Closing costs: $______
- Break-even month (closing costs ÷ monthly savings): ______ months
- Will I hold this property past the break-even month? Yes / No
- If this is a cash-out refinance, break-even does not apply the same way — the question is whether the returned cash earns more in its next use than the extra debt service costs. My answer: ____________________

## 4. Cash Flow After the Refinance

| Item | Monthly amount |
|---|---|
| Rent (middle comparable, not highest) | $ |
| New mortgage payment (P&I) | $ |
| Taxes | $ |
| Insurance | $ |
| Property management | $ |
| Maintenance reserve (5%) | $ |
| Vacancy reserve (5%) | $ |
| CapEx reserve (5%) | $ |
| **Cash flow** | **$** |

## 5. Seasoning

- Date I purchased the property: __________
- Lender's seasoning requirement: ______ months
- Date I become eligible: __________
- Is the requirement met today? Yes / No
- If no, what are the holding costs until eligibility? $______ per month

## 6. Stressed Scenario

Fill this in before you apply. A refinance that only works in the optimistic column is a gamble.

| Item | Expected | Stressed (appraisal 10% low, rate 0.5 points higher) |
|---|---|---|
| Appraised value | $ | $ |
| New loan amount | $ | $ |
| Cash returned | $ | $ |
| Monthly payment | $ | $ |
| Monthly cash flow | $ | $ |

Does the deal still work under the stressed scenario? Yes / No — explain: ____________________

## 7. Appraisal Risk Plan

If the appraisal comes in low, my plan is (check in order of preference):
- [ ] Request a reconsideration of value with documented comparable sales the appraiser missed
- [ ] Accept a smaller cash-out and leave more capital in the deal (cash flow still works: Yes / No)
- [ ] Wait and re-apply later
- [ ] Try a second lender (accepting the cost of a second appraisal)
- [ ] Sell, if the numbers no longer work

## 8. Decision

- [ ] Proceed with this refinance
- [ ] Wait until ____________________
- [ ] Do not refinance

Reason in one sentence: ____________________

Property: ____________________ Date: __________ Prepared by: __________
