# The Portfolio Builder — Companion Workbook

Use this workbook alongside the course. Print it or copy it into your own notes. Work through one worksheet at a time, in order. Do not skip the Portfolio Audit — every later worksheet depends on its numbers.

*This workbook is educational material only. It is not individualized financial, legal, tax, or investment advice. Consult licensed professionals before making investment, financing, entity, or tax decisions.*

---

## Worksheet 1: Portfolio Audit

Complete one row per property you own. Use trailing-twelve-month figures for rent collected and expenses.

| Field | Property 1 | Property 2 | Property 3 |
|---|---|---|---|
| Address | | | |
| Property type / units | | | |
| Purchase date | | | |
| Purchase price | | | |
| Closing costs | | | |
| Rehab / initial repairs | | | |
| Total cash invested | | | |
| Current estimated value (and how estimated) | | | |
| Current loan balance | | | |
| Loan type / interest rate | | | |
| Monthly mortgage payment (P&I) | | | |
| Monthly taxes | | | |
| Monthly insurance | | | |
| Monthly rent (lease amount) | | | |
| Rent actually collected, last 12 months (total) | | | |
| Vacancy days, last 12 months | | | |
| Maintenance & repairs spent, last 12 months | | | |
| Property management cost per month | | | |
| Monthly cash flow (after reserves — see below) | | | |
| Equity (value − loan balance) | | | |
| Cash-on-cash return (annual cash flow ÷ cash invested) | | | |
| Return on equity (annual cash flow ÷ equity) | | | |

**Reserves used:** Vacancy reserve ___% of gross rent. Maintenance reserve ___%. Capital-expenditure reserve ___%.

**Portfolio totals:** Total equity $_______. Total annual cash flow $_______. Total monthly cash flow $_______. Average cash flow per door $_______.

**Findings:** Which property is strongest? ____________________. Which is weakest, and why? ____________________. What is the one fix that would help the most? ____________________.

**My weekly landlord hours (tracked over two weeks):** ______ hours/week. If I doubled the portfolio, would that double too? ______

---

## Worksheet 2: Scaling-Target Worksheet

Write your target as one paragraph, then break it into numbers.

**My target paragraph:** "By __________ (date), I will own ______ units — ________________________________ (property mix) — producing at least $__________ per month in true cash flow after reserves, with no more than ______ hours per week of my own time."

- Target date: __________
- Target unit count: __________
- Property mix: __________
- Target monthly cash flow: $__________
- Realistic cash flow per door in my market (from my audit, not a podcast): $__________
- Doors needed to reach the income target at that per-door figure: __________
- Maximum hours per week I will spend: __________
- Acquisitions per year I can realistically complete: __________
- Years to reach the target at that pace: __________
- Capital I need per acquisition (typical cash left in deal): $__________
- Where that capital comes from (savings / refinance / HELOC / partner): __________

**Three numbers I will review monthly:** (1) Doors owned ______ (2) Trailing-12-month cash flow per door $______ (3) Total equity $______

---

## Worksheet 3: BRRRR Deal Worksheet

Use with the BRRRR calculator spreadsheet (templates/brrrr-calculator.csv).

| Item | Amount |
|---|---|
| Purchase price | $ |
| Closing costs | $ |
| Rehab — itemized total (attach contractor scope) | $ |
| Rehab contingency (10–15%) | $ |
| Holding costs during rehab (taxes, insurance, utilities, loan interest) | $ |
| **Total cash invested (all-in cost)** | **$** |
| After-repair value (ARV) — conservative end of comparable range | $ |
| Comparable sales used (addresses + sale prices) | 1. ___ 2. ___ 3. ___ |
| 70% rule maximum purchase price: (ARV × 0.70) − rehab | $ |
| Did I pay above the 70% rule maximum? By how much? | $ |
| Expected monthly rent (middle comparable, not highest) | $ |
| Refinance loan-to-value | ___% |
| Expected new loan (ARV × LTV) | $ |
| Refinance closing costs | $ |
| Cash returned at refinance | $ |
| **Cash left in the deal** | **$** |
| Monthly mortgage payment after refinance | $ |
| Monthly taxes / insurance / management / reserves | $ |
| **Monthly cash flow after refinance** | **$** |

**Stress test:** Appraisal 10% low → ARV $______ → new loan $______ → cash left in deal $______ → cash flow $______.
**Stress test:** Rate 0.5 points higher → payment $______ → cash flow $______.
**Stress test:** Rent 5% lower → $______ → cash flow $______.

**Decision:** Proceed / Negotiate lower / Walk away. Reason in one sentence: ____________________.

---

## Worksheet 4: Refinance Decision Worksheet

(Also available as a standalone template in templates/refinance-decision-worksheet.md.)

| Item | Current loan | Proposed loan |
|---|---|---|
| Balance | $ | $ |
| Interest rate | ___% | ___% |
| Monthly payment (P&I) | $ | $ |
| Remaining term | ___ years | ___ years |
| Cash out (if any) | — | $ |
| Closing costs | — | $ |

- Purpose of this refinance (rate / cash-out / term / remove mortgage insurance): ____________________
- Monthly payment change: $______ (savings / increase)
- Break-even month (closing costs ÷ monthly savings): ______ months. Will I hold past break-even? ______
- Cash flow after refinance: $______ per month
- Seasoning requirement met? Yes / No — date eligible: __________
- Stressed scenario (appraisal 10% low, rate 0.5 points higher): cash returned $______ , cash flow $______
- What will the cash-out proceeds be used for? ____________________
- Decision: Proceed / Wait / Do not refinance. Reason: ____________________

---

## Worksheet 5: Buy-Box Worksheet

**Property type and size:** ________________________________________________
**Neighborhoods / zip codes (boundaries written down):** ________________________________________________
**Maximum purchase price:** $__________ **Maximum all-in cost:** $__________
**ARV range:** $__________ to $__________ **70% rule threshold I will use:** __________%
**Minimum monthly rent:** $__________ **Minimum cash flow per door after reserves:** $__________
**Minimum cash-on-cash return:** __________%
**Maximum rehab scope I will accept:** ________________________________________________
**Financing types the property must qualify for:** ________________________________________________

**Deal-breakers (automatic no):**
1. ________________________________________________
2. ________________________________________________
3. ________________________________________________
4. ________________________________________________

**Date this buy box was written:** __________ **Next review date (6 months):** __________

---

## Worksheet 6: Team-Builder Worksheet

| Role | Name | Contact | Date interviewed | References checked? | Hired? | Notes |
|---|---|---|---|---|---|---|
| Real estate agent | | | | | | |
| Contractor | | | | | | |
| Property manager | | | | | | |
| Lender (conventional / DSCR) | | | | | | |
| Portfolio lender / credit union | | | | | | |
| CPA / accountant | | | | | | |
| Real estate attorney | | | | | | |
| Insurance agent | | | | | | |

**Questions I asked each candidate:** ________________________________________________
**My approval thresholds:** Manager may approve repairs up to $______ without calling me. Contractor draw schedule: ____________________.
**Quarterly team review date:** __________

---

## Worksheet 7: Annual Portfolio Review Template

(Also available as a standalone template in templates/annual-portfolio-review.md.)

Complete once a year, for every property.

| Property | Cash flow (T12) | Return on equity | Rent vs. market | Condition / CapEx due | Decision: Hold / Fix / Sell |
|---|---|---|---|---|---|
| | $ | ___% | | | |
| | $ | ___% | | | |
| | $ | ___% | | | |
| | $ | ___% | | | |
| | $ | ___% | | | |

- Portfolio cash flow this year vs. last year: $______ vs. $______
- Total equity this year vs. last year: $______ vs. $______
- Weakest property and the decision for it: ____________________
- Insurance reviewed and updated? Yes / No — date: __________
- Tax-planning meeting with CPA held? Yes / No — date: __________
- Attorney consultation (entity review) held? Yes / No — date: __________
- Buy box still accurate? Changes needed: ____________________
- Next year's acquisition target: ______ properties, in ____________________ (market)

---

## Worksheet 8: 3-Year Roadmap Planner

| | Year 1 | Year 2 | Year 3 |
|---|---|---|---|
| Target doors by year-end | | | |
| Acquisitions planned | | | |
| Strategy per acquisition (BRRRR / house hack / DSCR / conventional) | | | |
| Capital needed | $ | $ | $ |
| Capital source | | | |
| Team hires / changes | | | |
| Systems to build or hand off | | | |
| CPA meeting date | | | |
| Attorney consultation date | | | |
| Annual portfolio review date | | | |

**Decision points (not just acquisitions):** Write the dates you will review your buy box, interview managers, meet your CPA, and complete your annual review.

**What would make me pause or change the plan?** ________________________________________________

**My commitment for the next 90 days:** ________________________________________________
