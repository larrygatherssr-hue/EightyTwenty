# Welcome — The Portfolio Builder: From First Property to Financial Freedom

Welcome. You already own rental property — this course is about turning those first few doors into a portfolio of ten or more, with your capital working harder and your time working less.

## What You Received

| File | What it is |
|---|---|
| `content.md` | The complete course — 18 modules plus appendices (deal screen, underwriting reference, glossary, 90-day action plan) |
| `workbook.md` | Companion workbook with 8 worksheets |
| `templates/brrrr-calculator.csv` | BRRRR calculator with the course's worked example pre-filled, plus stress tests and a failed-deal comparison |
| `templates/refinance-decision-worksheet.md` | Refinance decision worksheet |
| `templates/portfolio-tracking-template.csv` | Monthly portfolio tracker, one row per property |
| `templates/annual-portfolio-review.md` | Annual review template |
| `sales-page.md` | The product sales page (reference copy) |
| `cover.webp` | Product cover image |
| `listing.json` | Marketplace listing data |
| `cover.md` | Cover design brief |

## What to Do First (Week 1)

1. **Read the note at the top of the course.** This is education, not individualized financial, legal, tax, or investment advice. The worked examples use illustrative numbers — always re-run them with your own figures.
2. **Complete the Portfolio Audit (Module 1 + Workbook Worksheet 1).** Use trailing-twelve-month figures for rent actually collected and expenses actually spent. If a number is missing, find it before moving on — every later module builds on these numbers.
3. **Write your scaling target (Module 2 + Worksheet 2).** One paragraph: unit count, property mix, target monthly cash flow, target date, and your weekly time budget. Put it where you will see it weekly.
4. **Fill in your buy box (Module 9 + Worksheet 5).** Date it. This is the filter every future deal must pass.

## How to Use the Materials

- **Read the course in order the first time.** Modules 1–6 build the foundation (audit, target, BRRRR math, financing, refinancing). Modules 7–11 cover the growth levers (house hacking, markets, buy box, team, systems). Modules 12–16 cover protection and decisions (entities, taxes, tracking, sell/hold/exchange, mistakes). Modules 17–18 turn it into a plan.
- **Use the workbook as you read.** Each worksheet matches a module. Do the worksheet when you finish its module, while the ideas are fresh.
- **Use the BRRRR calculator on every candidate deal.** Replace the pre-filled example numbers with your own. Run the stress tests (appraisal 10% low, rate 0.5 points higher, rent 5% lower) before you offer.
- **Use the portfolio tracker monthly.** Fifteen minutes a month: enter rent collected and expenses per property, and read the cash flow, equity, and return figures. Monthly exceptions are where problems are cheapest to fix.
- **Use the annual review once a year.** Two hours, every property, hold/fix/sell decision written down with a reason. Bring last year's review to compare.

## Suggested Schedule

- **Weekend 1:** Read Modules 1–6 and complete Worksheets 1–4.
- **Weekend 2:** Read Modules 7–12 and complete Worksheets 5–6; book your CPA tax-planning meeting and attorney consultation.
- **Weekend 3:** Read Modules 13–18 and complete Worksheets 7–8; start the 90-day action plan (Appendix D).
- **Ongoing:** Monthly tracker update (15 minutes), quarterly team and market check, annual portfolio review.

## A Few Honest Warnings

- **Underwrite at stressed numbers.** If a deal only works at the optimistic appraisal and the lowest rate, walk away.
- **Keep six months of expenses per property in reserve, in cash.** A delayed refinance should be an inconvenience, not a crisis.
- **Talk to licensed professionals before you act.** A real estate attorney before forming or changing an entity or transferring a property; a CPA before any tax decision or 1031 exchange; a licensed lender before you commit to a financing plan.
- **No guaranteed returns.** Nothing in this course guarantees income, appreciation, rents, or appraisals. The examples are illustrations, not predictions.

## How to Get Support

For help with your order or the course files, email the marketplace support address with your order number and a description of the issue, and the support team will respond. For questions about your specific properties, financing, taxes, or legal structure, contact a licensed professional in your state — the course explains what to ask, but it cannot advise on your situation.

## Refund Policy

14-day money-back guarantee. If you are not satisfied within 14 days of purchase, contact support with your order number for a full refund, no questions asked.
