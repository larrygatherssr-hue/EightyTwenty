# Onboarding Guide — The Complete Composting System: Turn Waste into Garden Gold

Welcome. This guide will get you started in your first hour, and show you how to use the materials over your first month.

**Format note:** This is a complete written course manual, not a video course. There are no video lessons. Everything is in the written files listed below.

## What You Received

- **content.md** — The full written course manual (6 modules, over 15,000 words). Read this first.
- **workbook.md** — The companion workbook, with exercises for every module, a waste audit worksheet, and a compost log.
- **templates/compost-troubleshooting-flowcharts.md** — Eight flowcharts for when something goes wrong.
- **templates/seasonal-compost-calendar.md** — A printable year-round checklist.
- **templates/waste-audit-worksheet.csv** — A spreadsheet version of the waste audit worksheet.
- **templates/vermicompost-setup-guide.md** — A step-by-step guide to keep near your worm bin.
- **templates/bokashi-setup-guide.md** — A step-by-step guide to keep near your bokashi bucket.
- **sales-page.md** — The product sales page, kept with the files for reference.
- **cover.png** — The product cover image.
- **README.md** — An index of all the files.

All files are standard formats (Markdown documents, a CSV spreadsheet, and a PNG image) that open in any text editor, word processor, or spreadsheet app. No special software is required.

## What to Do First (Your First Hour)

1. **Read the Introduction and Module 1 of content.md.** Module 1 is the shortest route to every later decision. It explains carbon and nitrogen, moisture, air, and heat. Do not skip it, even if you are impatient to start.
2. **Do Workbook Exercise 1.1.** List the materials you already have, sort them into browns and greens, and see what you are short of.
3. **Choose your method.** Read the "Choosing and combining methods" table in Module 6. Most households do best with one main method and one supporting method — for example, a slow pile plus a worm bin, or a hot pile plus bokashi. Pick one method to start. Get it working before you add a second.
4. **Check your local rules.** Before you build a pile or set up a bin, check your town, county, or state rules about composting and food waste, especially if you live in an apartment or a managed community.

## Your First Week

- **Day 1–2:** Read Modules 2 and 3 if you are starting with a pile, Module 4 if you are starting with a worm bin, or Module 5 if you are starting with bokashi. Read only the module for the method you chose — you can read the others later.
- **Day 3–4:** Gather your materials and set up your system. Use the setup checklist in the workbook for your method, or the vermicompost or bokashi setup guide in the templates folder.
- **Day 5–7:** Start your compost log (in the workbook). Record what you added, the temperature if you have a hot pile, and the moisture. Do the one-week household waste audit (Workbook Exercise 6.2, or the CSV worksheet) when you have a normal week.

## Suggested Schedule

### Weeks 1–2: Learn and set up

Read the Introduction and Module 1, then the module for your chosen method. Set up your pile, bin, or bucket. Start the compost log.

### Weeks 3–4: Run the system

Follow the weekly routine: take kitchen scraps to the pile, bin, or bucket; bury scraps; drain the bokashi bucket if you use one; check moisture. Do the waste audit in a normal week.

### Month 2: Read the rest

Read the modules for the other methods, even if you are not using them yet. You may want to add a supporting method later. Read Module 6 in full and keep the troubleshooting flowcharts near your compost area.

### Months 2–6: Keep going

Follow the monthly routine: turn the pile, check moisture and temperature, harvest castings if the worm bin is ready, and bury fermented bokashi when a bucket has finished. Use the seasonal calendar as your checklist.

### Month 12: Review

Do the one-year review in the workbook (Exercise 6.4). Repeat the waste audit in the same season as your first audit and compare the results.

## How to Use the Materials Day to Day

- **When something goes wrong:** Open the troubleshooting flowcharts first. Start with the symptom, answer each question, and follow the branch to the fix.
- **When you are not sure what to add:** Check the materials quick reference in the appendix of content.md. If in doubt, leave it out.
- **When the seasons change:** Check the seasonal compost calendar. It tells you what to do in spring, summer, autumn, and winter.
- **When you want to know if your pile is working:** Check the temperature with a thermometer, do the squeeze test for moisture, and check the smell. All three are covered in Module 1.

## How to Get Support

Email the marketplace support address with your order number and a description of your question. Support can help with downloads and access to the files, and with questions about how to apply the worksheets and templates. Support cannot provide individualized agronomic, legal, medical, or professional advice.

When you contact support, include:

- Your order number.
- The file you need help with (for example, content.md, workbook.md, or a template name).
- A short description of the problem or question.

## A Note on Expectations

Composting takes time. A hot pile takes 6–16 weeks depending on conditions, plus 4–8 weeks of curing. A slow pile takes 6–18 months. A worm bin gives its first harvest in 3–6 months. These are ranges depending on climate, materials, space, and effort, not promises. Your first pile may not heat. Your first worm bin may be overfed. That is normal. The log, the flowcharts, and the calendar exist so that each pile teaches you something, and the next one is better.

## Safety Reminders

- Handle compost with gloves and wash your hands after handling it.
- Keep compost away from food-preparation surfaces.
- Do not compost meat, fish, dairy, fats, or oils in an open pile or a worm bin — use bokashi for these.
- Never compost pet waste from dogs or cats, or human waste, in a home system.
- Check your local rules before you start.
- If you have a medical condition or a compromised immune system, or you are composting material that may carry pathogens, seek advice from a qualified local professional.

*This guide is for general education only. It is not professional, legal, medical, or agronomic advice. Results vary with climate, materials, space, and effort, and no specific yield, saving, or garden result is guaranteed.*
