# Workbook — The Complete Composting System: Turn Waste into Garden Gold

## A Complete Written Course Manual (Not a Video Course)

This workbook belongs to *The Complete Composting System* (GRN-09). It is a written companion to the written course manual. There are no video lessons. Work through the exercises in order the first time, then reuse the worksheets — the waste audit, the compost log, and the troubleshooting exercises — as often as you need them. Print the pages you use most, or copy them into a notebook.

**Education-only disclaimer:** This workbook is for general education only. It is not professional, legal, medical, or agronomic advice. Check your local rules before you start composting, handle compost with gloves, wash your hands after handling it, and seek qualified local advice if you are unsure about any material or method. Results vary with climate, materials, space, and effort, and no specific yield, saving, or garden result is guaranteed.

---

## How to Use This Workbook

- Do one module's exercises after reading that module in the course manual.
- Write in the workbook. The act of writing down what you added, what the temperature was, and what you changed is what turns composting from guesswork into a skill.
- Keep your compost log going for at least a full year. A year of logs will tell you more about your household's composting than any book can.
- Reuse the worksheets. The waste audit worksheet, the compost log, and the troubleshooting record are designed to be copied and used again.

---

## Module 1 Exercises: Compost Science

### Exercise 1.1 — Sort your materials

List every material you currently have available for composting — kitchen scraps, garden waste, paper, cardboard, and anything else. For each one, mark it Brown (carbon-rich) or Green (nitrogen-rich), and note its approximate C:N ratio from the table in Module 1.

| Material I have | Brown or Green? | Approximate C:N ratio | How much do I have? |
|---|---|---|---|
| | | | |
| | | | |
| | | | |
| | | | |
| | | | |
| | | | |
| | | | |
| | | | |

**Reflection:** Do you have more browns or more greens? What are you short of? Where could you get more of what you are short of — for example, saving dry leaves in autumn, asking a neighbour for grass clippings, or shredding cardboard?

Write your answer here:

### Exercise 1.2 — Plan a balanced pile

Using the materials from Exercise 1.1, plan a pile. What browns will you use, and how much? What greens will you use, and how much? What is your planned brown-to-green ratio by volume?

- Browns I will use:
- Greens I will use:
- Planned ratio (browns : greens by volume):
- What I will do if the pile smells of ammonia (too much nitrogen):
- What I will do if the pile stays cold and dry (too much carbon, or too little water):

### Exercise 1.3 — The squeeze test

Take a handful of material from your pile or from a handful of damp leaves and kitchen scraps. Squeeze it firmly. Record what happens.

- Did any water come out? How much — none, one or two drops, or a stream?
- Did the material feel dry, damp like a wrung-out sponge, or wet and soggy?
- What does this tell you about what your pile needs?

Repeat the squeeze test each time you turn the pile, and record the result in your compost log.

### Exercise 1.4 — Temperature check

If you have a compost thermometer, record the temperature of your pile each day for a week. If you do not have one yet, note the date you will buy one, and record the temperature by feel for now — is the centre warm, hot, or the same temperature as the air?

| Date | Temperature (centre of pile) | What I did today | Notes |
|---|---|---|---|
| | | | |
| | | | |
| | | | |
| | | | |
| | | | |
| | | | |
| | | | |

---

## Module 2 Exercises: Hot Composting

### Exercise 2.1 — Hot pile plan

Answer these before you build a hot pile.

- Where will the pile go? (Level, drained, near water, room to turn?)
- How big will it be? (Aim for about 1 cubic metre.)
- What materials have you gathered? List browns and greens and their volumes.
- Do you have a thermometer, a fork, a watering can, and a cover?
- What date will you build the pile?
- Who will help you turn it, if anyone?

### Exercise 2.2 — Hot pile log

Use this log during the hot phase. Record the temperature before each turning, what you added, and what you noticed.

| Date | Temperature before turning | Temperature after turning (next day) | What I added (browns / greens / water) | Smell | Appearance | Notes |
|---|---|---|---|---|---|---|
| | | | | | | |
| | | | | | | |
| | | | | | | |
| | | | | | | |
| | | | | | | |
| | | | | | | |
| | | | | | | |
| | | | | | | |

### Exercise 2.3 — Curing check

When the pile stops reheating, answer these questions before you use the compost.

- Does it smell earthy, or does it still smell sour or like ammonia?
- Can you still recognise the original materials?
- Is it dark, crumbly, and cool to the touch?
- If you pile it up and wet it, does it reheat within a few days? (If yes, it needs more curing.)
- How long has it been curing? (Aim for 4 to 8 weeks.)

### Exercise 2.4 — Where will your compost go?

List the beds, pots, or lawn areas where you will use your finished compost, and how much each one needs.

| Area | Size | How much compost (litres or cm depth) | When will I apply it? |
|---|---|---|---|
| | | | |
| | | | |
| | | | |
| | | | |

---

## Module 3 Exercises: Cold and Slow Composting

### Exercise 3.1 — Slow pile setup

- Where is your slow pile or bin?
- Is it on soil or on a hard surface?
- Do you have a second bin for finishing, or will you harvest from the bottom?
- How will you bury kitchen scraps each time you add them?

### Exercise 3.2 — Monthly slow-pile check

Copy this table and fill it in once a month.

| Month | Turned? (yes/no) | Moisture (dry / damp / wet) | Smell | What I added this month | Notes |
|---|---|---|---|---|---|
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |

### Exercise 3.3 — Harvest plan

- When do you expect your slow pile to be ready? (Remember: 6 to 12 months is typical, 12 to 18 months in a cold climate.)
- How will you harvest — from the bottom, or by resting a full bin?
- What will you do with the unfinished material on top?

---

## Module 4 Exercises: Vermicomposting

### Exercise 4.1 — Worm bin setup checklist

- [ ] Bin chosen: dark, opaque, 40 to 60 litres, with a lid.
- [ ] Air holes drilled around the upper sides; drainage holes in the bottom.
- [ ] Bedding prepared: shredded newspaper or cardboard, dampened to wrung-out sponge feel, fluffed up, two-thirds full.
- [ ] A handful of soil or finished compost mixed into the bedding.
- [ ] Red wigglers ordered or bought (about 250 to 500 grams to start).
- [ ] Bin placed in a spot that stays between 13 and 25°C.
- [ ] Tray underneath to catch liquid, if keeping the bin indoors.

### Exercise 4.2 — Feeding log

Record each feeding. Feed only when the previous feeding has mostly disappeared.

| Date | What I fed | How much (grams, approx.) | Where in the bin? | Previous feeding gone? (yes/no) | Notes |
|---|---|---|---|---|---|
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |

### Exercise 4.3 — Weekly worm bin check

Each week, answer these four questions.

- Moisture: dry, damp, or wet? What did I do about it?
- Food: is the last feeding gone? Should I feed again or wait?
- Smell: earthy, or sour/rotten? If sour, what will I change?
- Worm behaviour: are the worms in the bedding, or clustered at the top trying to escape? What might that mean?

Week of __________:

### Exercise 4.4 — Harvest record

- Date of harvest:
- Method used (migration or light method):
- How much castings did I harvest (litres, approx.)?
- Where did I use the castings?
- What did I notice about the castings — colour, texture, smell?

---

## Module 5 Exercises: Bokashi

### Exercise 5.1 — Bokashi setup checklist

- [ ] Bokashi bucket(s) bought or made — two buckets if possible.
- [ ] Bokashi bran bought (1 to 2 kg to start).
- [ ] Tap closed, strainer plate in place, lid seals tightly.
- [ ] A place chosen to bury fermented material (garden bed, trench, or compost pile).
- [ ] A pen to write the sealing date on the lid.

### Exercise 5.2 — Bokashi log

| Bucket | Date started | Date sealed (full) | Date buried / added to pile | Smell on opening (pickled / rotten) | Mould (white / green / black / none) | Where buried | Notes |
|---|---|---|---|---|---|---|---|
| 1 | | | | | | | |
| 2 | | | | | | | |
| 1 | | | | | | | |
| 2 | | | | | | | |

### Exercise 5.3 — Draining the liquid

Record each time you drain the bucket.

| Date | Liquid drained? (yes/no) | How much (approx.) | What did I do with it? |
|---|---|---|---|
| | | | |
| | | | |
| | | | |
| | | | |

Remember: dilute bokashi liquid at least 100 parts water to 1 part liquid before using it on soil, and do not use it on seedlings or directly on plant leaves.

---

## Module 6 Exercises: Troubleshooting and Waste Audit

### Exercise 6.1 — Troubleshooting practice

For each problem below, write down what you would check first, and what fix you would try. Use the troubleshooting flowcharts in the templates folder if you need help.

1. **Your pile has not heated after five days.** What do you check first? What do you do?
2. **Your pile smells of ammonia.** What is the cause? What is the fix?
3. **Your pile smells sour and rotten.** What is the cause? What is the fix?
4. **Your worm bin smells sour and the worms are clustered at the top.** What do you do first?
5. **Your bokashi bucket smells rotten when you open it after two weeks.** What went wrong? What do you do with the contents?
6. **You see rats near your compost pile.** What do you remove? What do you change?

Write your answers in your own words. There are no trick questions — the point is to practise diagnosing before you have a real problem.

### Exercise 6.2 — Household waste audit worksheet

Do this audit for one normal week. Separate waste as you go, weigh each stream at the end of the week, and record the results. A copy of this worksheet is also in the templates folder as a CSV file (waste-audit-worksheet.csv).

| Waste stream | What goes in it | Weight (kg) | Share of total (%) | Could this be composted? How? |
|---|---|---|---|---|
| Kitchen scraps (fruit and vegetable) | Peelings, cores, coffee grounds, tea bags, eggshells | | | |
| Cooked food, meat, fish, dairy | Leftovers, meat trimmings, dairy | | | Bokashi only |
| Garden waste | Grass, leaves, prunings | | | |
| Compostable paper and cardboard | Shredded newspaper, plain cardboard | | | |
| Other waste | Plastic, glass, metal, non-compostable | | | |
| **Total** | | | 100% | |

**What surprised you?**

**What is your largest compostable stream?**

**What two or three changes will you make first?**

1.
2.
3.

**Repeat this audit in a year's time, in the same season, and compare the results.**

### Exercise 6.3 — My composting system

Now that you have worked through the course, design your own system. Fill in this plan and keep it where you can see it.

- My main composting method:
- My supporting method (if any):
- Where my pile/bin/bucket lives:
- What I compost:
- What I do NOT compost (and why):
- My weekly routine (what I do, and when):
- My monthly routine:
- My seasonal plan (spring / summer / autumn / winter):
- Where I will get browns in winter:
- What I will do if the pile smells:
- What I will do if the pile will not heat:

### Exercise 6.4 — One-year review

Set a date one year from now to review this workbook. When that date comes, answer these questions.

- Date of review:
- What method(s) did I actually use?
- How much finished compost or castings did I produce in the year (litres, approx.)?
- What worked best?
- What did not work, and what did I change?
- What will I do differently next year?

---

## Compost Log / Tracker

Copy this log and use one row per week, or one row per turning. Keep it going for a full year.

| Week starting | Method (hot / slow / worms / bokashi) | What I added | Temperature (if hot pile) | Moisture (dry / damp / wet) | Smell | Turned? | What I noticed / changed |
|---|---|---|---|---|---|---|---|
| | | | | | | | |
| | | | | | | | |
| | | | | | | | |
| | | | | | | | |
| | | | | | | | |
| | | | | | | | |
| | | | | | | | |
| | | | | | | | |
| | | | | | | | |
| | | | | | | | |
| | | | | | | | |
| | | | | | | | |

---

*This workbook is for general education only. It is not professional, legal, medical, or agronomic advice. Check your local rules, handle compost with gloves, wash your hands after handling it, and seek qualified local advice if you are unsure about any material or method. Results vary with climate, materials, space, and effort, and no specific yield, saving, or garden result is guaranteed.*
