# Compost Troubleshooting Flowcharts

Use these flowcharts when something goes wrong. Start with the symptom, answer each question, and follow the branch to the fix. Work through one flowchart at a time. If a fix does not work in three to five days, move to the next step in the same flowchart.

---

## Flowchart 1: Pile Will Not Heat

```
PILE HAS NOT HEATED AFTER 3-5 DAYS
  |
  +-- Is the pile damp like a wrung-out sponge?
  |     Squeeze a handful from the centre.
  |
  +-- NO, IT IS DRY
  |     -> Water slowly while turning, a little at a time,
  |        until the squeeze test passes.
  |     -> Cover the pile.
  |     -> Wait 3 days and check the temperature again.
  |
  +-- YES, IT IS DAMP
        |
        +-- Is the pile at least 0.75 cubic metres
        |   (about 90 cm on each side)?
        |
        +-- NO, IT IS TOO SMALL
        |     -> Add more material until the pile is
        |        about 1 cubic metre, or accept slow
        |        composting and use the slow-pile method.
        |
        +-- YES, IT IS LARGE ENOUGH
              |
              +-- Is the pile mostly browns
              |   (dry leaves, cardboard, straw)?
              |
              +-- YES
              |     -> Add greens: a bucket of grass
              |        clippings, kitchen scraps, or manure.
              |     -> Mix through the pile and water.
              |     -> Wait 3-5 days and check again.
              |
              +-- NO, BALANCE LOOKS RIGHT
                    |
                    +-- Has the pile already heated and cooled?
                    |   (Was it hot last week?)
                    |
                    +-- YES -> The hot phase may be finished.
                    |     Move the pile to curing for 4-8 weeks.
                    |
                    +-- NO -> Turn the pile, check moisture,
                          and wait 3 days.
                          If it still does not heat, add a
                          bucket of greens and a few shovelfuls
                          of finished compost or garden soil
                          as a starter, then wait 3-5 days.
```

## Flowchart 2: Pile Smells of Ammonia (Sharp, Like Cleaning Fluid)

```
PILE SMELLS OF AMMONIA
  |
  +-- Cause: too much nitrogen, not enough carbon.
  |
  +-- FIX
       1. Add browns: two parts shredded cardboard,
          dry leaves, or straw for every part of
          pile material you turn.
       2. Turn the pile to mix the browns through.
       3. Cover the pile.
       4. Do NOT add more greens.
       5. Do NOT add lime. Lime makes ammonia worse.
       6. Check again in 3 days.
           |
           +-- Smell gone? -> Continue normal turning.
           |
           +-- Smell still there? -> Add more browns
                and turn again.
```

## Flowchart 3: Pile Smells Sour or Rotten (Vinegar, Rotten Eggs)

```
PILE SMELLS SOUR OR ROTTEN
  |
  +-- Cause: too wet, too little air, or food packed
  |   in thick slabs. The pile has gone anaerobic.
  |
  +-- FIX
       1. Pull the pile apart.
       2. Add coarse browns for structure: straw,
          chopped stems, or wood chips.
       3. Add dry browns to absorb excess water.
       4. Rebuild the pile loosely. Do not pack it down.
       5. Bury kitchen scraps in future; do not layer
          them in thick slabs.
       6. If the pile is saturated by rain, leave the
          cover off for a day in dry weather.
       7. Check again in 3 days.
           |
           +-- Smell gone and temperature rising?
           |   -> Continue normal turning.
           |
           +-- Still smells? -> Turn again, add more
                coarse browns, and check drainage.
                Is the pile sitting in a hollow that
                collects water? If yes, move it to
                higher, drained ground.
```

## Flowchart 4: Pile Is Too Wet

```
PILE IS TOO WET (water runs out when squeezed)
  |
  +-- FIX
       1. Add dry browns: shredded cardboard, dry
          leaves, or straw.
       2. Turn the pile to mix the browns through
          and reintroduce air.
       3. Cover the pile against rain.
       4. Check drainage under the pile.
       5. Leave the cover off for a day in dry,
          sunny weather if the pile is saturated.
       6. Check again in 3 days with the squeeze test.
```

## Flowchart 5: Pile Is Too Dry

```
PILE IS TOO DRY (no water when squeezed, dusty)
  |
  +-- FIX
       1. Water slowly while turning, a little at
          a time. Do not water from the top only:
          water runs off a dry pile.
       2. Turn and water together until the squeeze
          test passes (one or two drops).
       3. Add greens if the pile is also mostly browns.
       4. Cover the pile to retain moisture.
       5. In hot, dry weather, check moisture weekly.
```

## Flowchart 6: Pests

```
PESTS AROUND THE PILE
  |
  +-- FRUIT FLIES
  |     -> Food is exposed on the surface.
  |     -> Bury scraps under 10-15 cm of browns.
  |     -> Cover the pile.
  |
  +-- HOUSEFLIES
  |     -> Pile is too wet or contains meat, dairy,
  |        or cooked food.
  |     -> Remove meat, dairy, and cooked food.
  |        (Use bokashi for these instead.)
  |     -> Add browns and turn.
  |
  +-- RATS OR MICE
  |     -> Remove meat, dairy, cooked food, and fats.
  |     -> Bury scraps deeply (at least 15 cm).
  |     -> Keep the pile damp, not dry and warm.
  |     -> Turn the pile more often.
  |     -> If rats persist, move kitchen scraps to
  |        a sealed worm bin or bokashi bucket and
  |        use the pile for garden waste only.
  |     -> Use a lidded bin if rats are a known
  |        problem in your area.
  |
  +-- ANTS
  |     -> Pile is too dry.
  |     -> Water while turning until damp.
  |
  +-- SLUGS, WOODLICE, BEETLES
        -> Normal. These are part of the decomposer
           community. Leave them alone.
```

## Flowchart 7: Worm Bin Problems

```
WORM BIN SMELLS SOUR OR ROTTEN
  |
  +-- STOP FEEDING immediately.
  +-- Add dry shredded cardboard or newspaper.
  +-- Add a handful of crushed eggshells.
  +-- Fluff the bedding gently to reintroduce air.
  +-- Leave the lid ajar for a day if the bin is wet.
  +-- Wait until the smell is gone and the last
  |   feeding has disappeared before feeding again.
  +-- Feed smaller amounts next time.

WORMS CLUSTERED AT THE TOP OR TRYING TO ESCAPE
  |
  +-- Check moisture first: too wet or too dry?
  +-- Check temperature: is the bin between 13 and 25 C?
  +-- Check food: is there rotting, uneaten food?
  +-- Fix what is wrong, then wait 24 hours.
  +-- If worms are still escaping, move them to fresh
  |   damp bedding in a clean bin.

BIN IS TOO WET, LIQUID POOLING AT THE BOTTOM
  |
  +-- Add dry bedding.
  +-- Drain the liquid.
  +-- Leave the lid ajar for a day.
  +-- Feed less, and feed drier food.
```

## Flowchart 8: Bokashi Problems

```
BOKASHI BUCKET SMELLS ROTTEN WHEN OPENED
  |
  +-- Fermentation failed. Air got in, the bucket
  |   was not drained, or too little bran was used.
  +-- Do NOT bury it near food crops.
  +-- Add the contents to a hot compost pile, or
  |   bury them deeply in a non-food bed.
  +-- Clean the bucket thoroughly before starting again.
  +-- Next time: press material down more firmly,
  |   sprinkle bran on every layer, keep the lid
  |   sealed, and drain the tap every 2-3 days.

GREEN OR BLACK MOULD IN THE BUCKET
  |
  +-- Fermentation failed. Same fix as above.
  +-- Note: white mould is normal. Green or black
  |   mould is a sign of failure.

NO LIQUID DRAINS
  |
  +-- This can be normal if the food waste is dry.
  +-- If the bucket is full and no liquid has drained
  |   in a week, add a few tablespoons of water with
  |   the next layer and check that the tap is not blocked.
```
