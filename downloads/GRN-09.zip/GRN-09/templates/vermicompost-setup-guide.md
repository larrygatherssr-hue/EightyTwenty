# Vermicompost Setup Guide

A step-by-step guide to setting up and running a worm bin. This guide is also covered in full in Module 4 of the course manual. Keep this guide near your bin for the first few months.

## What You Need

- A dark, opaque plastic box, roughly 40–60 litres, with a lid. Dark matters: worms avoid light.
- A drill, to make air holes and drainage holes.
- Bedding: shredded newspaper, shredded cardboard, coconut coir, or aged leaves.
- A handful of garden soil or finished compost.
- Red wigglers (Eisenia fetida), about 250–500 grams to start.
- A tray to catch liquid, if keeping the bin indoors.
- Crushed eggshells (save them from the kitchen; crush them finely).

## Setup, Step by Step

### Step 1 — Prepare the box

Drill 8–12 small holes (about 6 mm) around the upper sides of the box for air, and 8–12 small holes in the bottom for drainage. Cover the air holes with fine mesh or a piece of old curtain if you are concerned about fruit flies entering. Put the box on a tray if it will live indoors.

### Step 2 — Prepare the bedding

Fill the box about two-thirds full with bedding. Wet the bedding, then squeeze out excess water so it is damp like a wrung-out sponge. Fluff it up — do not pack it down. Worms need air in the bedding. Mix in a handful of soil or finished compost.

### Step 3 — Add the worms

Place the worms on top of the bedding, put the lid on, and leave the bin in a dark, quiet place for 24 hours. The worms will burrow down on their own. Do not feed them on the first day.

### Step 4 — First feeding

After 24 hours, add about 100–150 grams of chopped kitchen scraps, buried under the bedding in one corner. Cover with bedding. Next time, feed in a different corner. Rotate feeding spots so you can see whether the previous feeding has been eaten.

## Feeding

**Feed:** Most fruit and vegetable scraps, coffee grounds and filters, tea bags (remove staples; check the bag material is compostable), crushed eggshells, and small amounts of plain bread, rice, or pasta. Chop food into small pieces. Freezing scraps and thawing them before feeding softens them and speeds breakdown.

**Do not feed:** Meat, fish, dairy, fats, or oils; citrus in large amounts; onions and garlic in large amounts; spicy food; pet waste; treated wood.

**How much:** Start with 100–150 grams per feeding, two or three times a week. Increase only when the previous feeding has mostly disappeared. A healthy, established bin can process roughly its own weight in food per week — a bin with 500 grams of worms can process about 500 grams of scraps per week under good conditions. A new bin processes much less. Overfeeding is the most common beginner mistake.

## Weekly Maintenance (5–10 minutes)

1. **Moisture:** Bedding should feel like a wrung-out sponge. If dry, spray lightly with water. If wet with liquid pooling, add dry shredded cardboard and leave the lid ajar for a day.
2. **Food:** Is the last feeding mostly gone? If yes, feed again in a new spot. If no, wait.
3. **Smell:** A healthy bin smells earthy. A sour or rotten smell means overfeeding, excess moisture, or too much acidic food. Stop feeding, add dry bedding and crushed eggshells, and fluff the bedding gently.
4. **Worm behaviour:** Worms should be in the bedding. Worms clustered at the top or on the lid are telling you something is wrong — usually too wet, too acidic, too hot, or too cold. Check moisture and temperature first.

## Temperature

Keep the bin between 13 and 25°C (55–77°F). Below 10°C worms slow down and may die if it freezes. Above 30°C worms become stressed and may die. In summer, move the bin to the coolest shaded spot. In winter, move it indoors or insulate it.

## Harvesting Castings (after 3–6 months)

**Migration method (recommended):** Stop feeding for a week. Push all material to one side of the bin and add fresh damp bedding and food to the empty side. Over the next 2–3 weeks the worms will migrate to the fresh side. Remove the finished castings from the old side. Pick out any remaining worms and return them to the bin.

**Light method:** Spread the contents thinly on a tarp in bright light (not direct sun). Worms burrow down away from light. Scrape the top layer of castings off, wait, and repeat until only a mass of worms remains. Return the worms to fresh bedding.

Store castings in a breathable bag or bucket with a loose lid, kept damp but not wet. Use within a few months.

## Using Castings

- Pots and containers: 1 part castings to 3–4 parts potting mix.
- Seed starting: 1 part castings to 4 parts seed-starting mix.
- Garden beds: 1–2 cm spread over a bed, forked lightly into the top few centimetres, once or twice a year.
- Transplanting: a small handful in each planting hole.

## Quick Troubleshooting

| Problem | Likely cause | Fix |
|---|---|---|
| Sour smell | Overfeeding, too wet, too acidic | Stop feeding; add dry bedding and crushed eggshells; fluff bedding |
| Worms escaping | Too wet, too acidic, too hot, too cold | Check moisture and temperature; fix, then wait 24 hours |
| Fruit flies | Exposed food | Bury food under bedding; cover air holes with mesh |
| Bin too wet | Overfeeding wet food, poor drainage | Add dry bedding; drain liquid; leave lid ajar for a day |
| Bin too dry | Not enough water, hot weather | Spray bedding lightly; add damp bedding |
| Food not disappearing | Too much food, food too large, bin too cold | Feed less; chop food smaller; move bin to a warmer spot |

## Shopping List

- [ ] Dark plastic box, 40–60 litres, with lid
- [ ] Drill and 6 mm bit (or ask the supplier to drill the box)
- [ ] Shredded newspaper or cardboard for bedding
- [ ] Red wigglers, 250–500 grams
- [ ] Tray for underneath (if indoors)
- [ ] Spray bottle for water
- [ ] Small kitchen scale (useful for weighing feedings in the first month)

*This guide is for general education only. It is not professional, legal, medical, or agronomic advice. Results vary with climate, materials, space, and effort.*
