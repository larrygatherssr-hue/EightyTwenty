# Bokashi Setup Guide

A step-by-step guide to setting up and running a bokashi bucket. This guide is also covered in full in Module 5 of the course manual. Keep this guide near your bucket for the first few months.

## What You Need

- A bokashi bucket: a sealed bucket with a tight-fitting lid, a tap or drain at the bottom, and a strainer plate inside. A manufactured bucket with a proper tap and seal is more reliable for beginners than a homemade one. Buy two buckets if you can — one fills while the other ferments.
- Bokashi bran: sold by garden suppliers, typically in 1–2 kg bags. A 1 kg bag lasts a typical household about 2–4 months.
- Food waste: all food, including cooked food, meat, fish, dairy, bread, and small bones. Chop large pieces.
- A place to bury the fermented material: a garden bed, a trench, a large pot of soil, or a compost pile.
- A pen to write the sealing date on the lid.

## How Bokashi Works

Bokashi is fermentation, not decomposition. Food waste is layered in a sealed bucket with bokashi bran, which carries lactic acid bacteria, yeasts, and other microbes. The microbes ferment the food, lowering the pH to roughly 3.5–4.5. At that acidity, putrefying bacteria cannot thrive, so the food pickles instead of rotting. The fermented material must then be buried in soil or added to a compost pile, where soil microbes finish breaking it down in 2–4 weeks in warm soil, or 4–8 weeks in cool soil.

Bokashi needs the absence of air. The bucket must be sealed, the material pressed down to remove air pockets, and the liquid drained regularly.

## Setup, Step by Step

### Step 1 — Start clean

Make sure the bucket is clean and dry, the tap is closed, and the strainer plate is in place.

### Step 2 — Add the first layer

Add 2–3 cm of food waste. Chop it into small pieces. Spread it evenly and press it down firmly with a plate, a potato masher, or a gloved hand. Pressing removes air pockets.

### Step 3 — Sprinkle bran

Sprinkle a small handful of bokashi bran — about 1–2 tablespoons — evenly over the layer. You do not need a thick coating. The bran is an inoculant, not a bulk ingredient.

### Step 4 — Repeat

Each time you have food waste, add it in a layer, press it down, and sprinkle bran. Keep the lid sealed between additions. Open the lid only to add food, and close it immediately.

### Step 5 — Drain the liquid

Drain the tap every 2–3 days, or whenever liquid has collected. The liquid is acidic and has a sweet-sour, pickled smell when fermentation is working. Dilute it at least 100 parts water to 1 part liquid before using it on soil. Do not use it on seedlings or directly on plant leaves. If you do not want to use it, pour it down the drain diluted with water.

### Step 6 — Seal a full bucket

A standard bucket holds about 15–20 litres of food waste, which takes a typical household 2–4 weeks to fill. When it is full, press the material down one final time, sprinkle a final layer of bran, seal the lid, write the date on the lid, and leave it to ferment for 2 weeks without opening it. Use your second bucket while the first ferments.

## What Fermented Bokashi Should Look and Smell Like

After two weeks of sealed fermentation, the material should smell sweet-sour and pickled, like sauerkraut or vinegar. It may have white mould on the surface — this is usually a beneficial yeast or fungus associated with fermentation, and it is normal.

Green or black mould, or a strong rotten or putrid smell, means the fermentation failed — usually because air got in, the bucket was not drained, or not enough bran was used. If a bucket fails, do not bury it near food crops. Add it to a hot compost pile, or bury it deeply in a non-food bed and let it break down over several months. Clean the bucket thoroughly before starting again.

Fermented bokashi still looks like food. That surprises beginners. The transformation happens after burial, not in the bucket.

## Finishing: Burying Fermented Bokashi

Bury the fermented material in a trench or hole in the garden, about 20–30 cm deep, and cover it with at least 15–20 cm of soil. Do not bury it near the roots of plants you are about to harvest, and do not plant directly into the burial spot for at least 2–4 weeks — the material is acidic and still breaking down, and it can temporarily harm roots. Mark the burial spot and wait.

If you have a compost pile, add fermented bokashi to the centre of a hot pile instead, bury it under browns, and turn the pile. The heat and microbes will finish it quickly.

Do not add large amounts of bokashi to a worm bin — the acidity and salt content can harm worms.

If you have no garden, finish bokashi in a large pot or a "soil factory" — a large container filled with soil, into which you bury fermented bokashi in layers. After 4–8 weeks, the soil in the container is enriched and can be used for potted plants.

## What Can Go in a Bokashi Bucket

All food waste, including: cooked food, meat, fish, dairy, bread, pasta, rice, fruit and vegetable scraps, coffee grounds, tea bags, and small bones. Chop large pieces to speed fermentation.

Do not put in: large bones, liquids in large amounts, mouldy food in large amounts, or non-food waste. Do not put in pet waste.

## Quick Troubleshooting

| Problem | Likely cause | Fix |
|---|---|---|
| Rotten smell on opening | Air got in; not drained; too little bran | Add to a hot compost pile or bury deeply in a non-food bed; clean bucket; press down firmly and drain more often next time |
| Green or black mould | Fermentation failed | Same fix as above; white mould is normal, green/black is not |
| Bucket too wet | Not drained often enough | Drain every 2–3 days; press material down |
| Flies in the bucket | Lid not sealing; food left exposed | Check the seal; keep lid closed between additions; clean the rim |
| No liquid drains | Food waste is dry | Normal if waste is dry; add a few tablespoons of water with the next layer; check tap is not blocked |

## Shopping List

- [ ] Bokashi bucket with tap and strainer plate (two buckets recommended)
- [ ] Bokashi bran, 1–2 kg
- [ ] Plate or potato masher for pressing material down
- [ ] Gloves
- [ ] Pen for writing dates on lids
- [ ] Spade for burying fermented material

## Running Costs

The main ongoing cost of bokashi is bran. A 1 kg bag lasts a typical household about 2–4 months, depending on how much food waste they ferment. A household fermenting about 3–4 kg of food waste a week will use about 4–6 kg of bran a year. Whether that cost is worth it depends on what you value: the diversion of cooked food and meat from the bin, the soil improvement, and the ability to handle materials no other home method can take.

*This guide is for general education only. It is not professional, legal, medical, or agronomic advice. Check your local rules before you start, and seek qualified local advice if you are unsure about any material or method. Results vary with climate, materials, space, and effort.*
