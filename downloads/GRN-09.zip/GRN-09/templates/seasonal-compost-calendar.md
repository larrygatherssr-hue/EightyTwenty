# Seasonal Compost Calendar

A printable year-round checklist. Written for a temperate climate with four seasons. If you live in a warmer climate, composting continues through winter — shift the winter tasks to the coolest months. If you live in a colder climate, winter is a pause and spring is the restart. Southern hemisphere dates are given in brackets.

---

## Spring — March to May [September to November]

- [ ] Restart the pile: turn the slow pile, check moisture with the squeeze test, and add a bucket of greens to restart activity after winter.
- [ ] Harvest finished compost from piles that cured over winter. Screen it through a 1–2 cm mesh.
- [ ] Spread finished compost on beds before planting: 2–5 cm forked lightly into the top 10–15 cm of soil.
- [ ] Start a new hot pile if you have enough material from spring garden clearing. Aim for about 1 cubic metre, built in one day.
- [ ] Start or restart a worm bin. Worms become active as temperatures rise above 13°C.
- [ ] Begin bokashi if you stopped over winter. Bury fermented material in beds that will not be planted for at least 2–4 weeks.
- [ ] Save and shred any remaining dry leaves from autumn for use as browns.
- [ ] Review your compost log from last year. What worked? What will you change?

## Summer — June to August [December to February]

- [ ] Watch for drying out. Check pile moisture weekly in hot, dry weather. Water while turning.
- [ ] Turn the hot pile every 3–7 days while it is active, when the temperature peaks and falls.
- [ ] Add grass clippings in thin layers, mixed with browns. Do not dump thick layers of grass — they mat and smell.
- [ ] Keep the pile covered to retain moisture. Check that the temperature does not exceed 70°C; if it does, turn it immediately.
- [ ] Harvest worm castings. Worms are most active in warm weather. Keep the bin shaded and below 25°C.
- [ ] Bury bokashi in beds between plantings. Mark burial spots and wait 2–4 weeks before planting into them.
- [ ] Top-dress lawns with a thin layer of finished compost (0.5–1 cm) and water it in.

## Autumn — September to November [March to May]

- [ ] Gather leaves. This is the most important autumn job. Shred leaves with a mower or shredder and store them dry in bags or a bin, under cover, for use as browns through winter and spring.
- [ ] Build a new hot pile from autumn garden waste if you have enough material.
- [ ] Harvest finished compost and spread it on beds in autumn, or store it under cover for spring.
- [ ] Reduce feeding the worm bin as temperatures fall. Move an outdoor worm bin indoors before the first frost.
- [ ] Finish bokashi buckets before winter. Bury fermented material while the soil is still workable.
- [ ] Do your annual household waste audit this season, and compare it with last year's audit.

## Winter — December to February [June to August]

- [ ] Let the outdoor pile rest. Turn it rarely, if at all, in freezing weather — turning loses heat you cannot afford to lose.
- [ ] Keep the pile covered and insulated with a thick layer of straw or leaves around the outside.
- [ ] Keep adding material to a slow pile if you have it, but expect little decomposition until spring.
- [ ] Run the worm bin indoors. It will continue through winter at indoor temperatures (13–25°C).
- [ ] Run bokashi through winter. Fermentation continues indoors. Bury fermented material in spring when the soil thaws, or add it to a compost pile.
- [ ] Plan next year's system. Review your compost log, note what worked and what did not, and decide what to change.
- [ ] Order supplies you will need in spring: bokashi bran, a compost thermometer if yours is worn out, and any replacement bin parts.

---

## Monthly Quick Check (every month, all year)

- [ ] Kitchen scraps taken to the pile, worm bin, or bokashi bucket — buried, not left on the surface.
- [ ] Bokashi bucket drained (every 2–3 days while in use).
- [ ] Pile cover in place and secure.
- [ ] Moisture checked by eye; squeeze test done when turning.
- [ ] Compost log updated.

---

*This calendar is for general education only. It is not professional, legal, medical, or agronomic advice. Results vary with climate, materials, space, and effort.*
