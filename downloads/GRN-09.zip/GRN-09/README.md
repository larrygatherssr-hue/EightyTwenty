# GRN-09 — The Complete Composting System: Turn Waste into Garden Gold

- **SKU:** GRN-09
- **Price:** $97 (one-time)
- **Category:** Green Living & Sustainability
- **Format:** Complete written course manual (not a video course)

## Files in This Product

| File | What it is |
|---|---|
| `content.md` | The full written course manual — 6 modules (compost science, hot composting, cold/slow composting, vermicomposting, bokashi, troubleshooting and waste audits), seasonal compost calendar, worked examples, glossary, and materials quick reference. Over 15,000 words. |
| `workbook.md` | Companion workbook — exercises and worksheets for every module, waste audit worksheet, compost log/tracker, and troubleshooting exercises. |
| `templates/compost-troubleshooting-flowcharts.md` | Eight troubleshooting flowcharts (piles that will not heat, smells, wet/dry piles, pests, worm bin and bokashi problems). |
| `templates/seasonal-compost-calendar.md` | Printable seasonal compost calendar — a year-round checklist. |
| `templates/waste-audit-worksheet.csv` | Waste audit worksheet as a CSV spreadsheet. |
| `templates/vermicompost-setup-guide.md` | Step-by-step vermicompost (worm bin) setup guide. |
| `templates/bokashi-setup-guide.md` | Step-by-step bokashi setup guide. |
| `sales-page.md` | Full sales page — headline, problem, solution, what is inside, who it is for / not for, price and guarantee, FAQ (10 questions), and disclaimers. |
| `listing.json` | Marketplace listing data (SKU, name, category, price_cents 9700, billing, headline, description, delivery note, SEO keywords, refund policy, support). |
| `cover.md` | Cover design brief (black-and-gold luxury, 1280x1920 portrait). |
| `cover.png` | The product cover image (1280x1920, portrait, black-and-gold). |
| `onboarding.md` | Customer onboarding guide — what to do first, how to use the materials, suggested schedule, and how to get support. |
| `README.md` | This index. |

## Format Note

This product is a complete written course manual, not a video course. It does not contain video lessons. The sales page, listing description, and delivery note state this plainly.

## Disclaimer

All content is for general education only. It is not professional, legal, medical, or agronomic advice. Results vary with climate, materials, space, and effort, and no specific yield, saving, or garden result is guaranteed.
