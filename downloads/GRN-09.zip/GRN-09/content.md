# The Complete Composting System: Turn Waste into Garden Gold

## A Complete Written Course Manual (Not a Video Course)

**Format note:** This product is a complete written course manual. It contains the full course text, a companion workbook, templates, and guides in written form. It does not contain video lessons. If you were expecting video, please read this manual first — every step that would have been shown on screen is written out here in full, with measurements, worked examples, and checklists.

**Education-only disclaimer:** This manual is for general education only. It is not professional, legal, medical, or agronomic advice, and it does not certify you or your compost in any way. Composting rules, food-waste rules, and rules about what may be composted at home vary by town, county, and state, and they change over time. Check your local rules before you start, especially if you live in an apartment, a managed community, or an area with wildlife or rodent controls. If you have a medical condition, a compromised immune system, or you are composting material that may carry pathogens, seek advice from a qualified local professional. Finished compost should be handled with gloves, kept away from food-preparation surfaces, and never used on crops in a way that conflicts with local food-safety guidance. Results vary with climate, materials, space, and effort, and no specific yield, saving, or garden result is guaranteed.

---

## Table of Contents

- Introduction: Why Most Compost Piles Fail — and Why Yours Will Not
- How to Use This Manual
- Module 1: Compost Science — Carbon, Nitrogen, Air, Water, and Microbes
- Module 2: Hot Composting — Fast, Hot, and Thorough
- Module 3: Cold and Slow Composting — The Low-Effort Pile That Still Works
- Module 4: Vermicomposting — Letting Worms Do the Work
- Module 5: Bokashi — Fermenting What the Pile Cannot Take
- Module 6: Troubleshooting, Household Waste Audits, and Keeping It Going
- The Seasonal Compost Calendar
- Worked Examples: Three Households, Three Systems
- Glossary
- Appendix: Materials Quick Reference

---

## Introduction: Why Most Compost Piles Fail — and Why Yours Will Not

Most home compost piles fail in one of three ways. They smell, and the household gives up on them. They attract flies, rats, or raccoons, and a neighbour complains. Or they sit for a year and never break down, and the gardener concludes that composting does not work. In almost every case, the cause is the same: the pile was built without a working balance of carbon and nitrogen, without enough air, or without enough — or too much — water. The microbes that do the composting were never given the conditions they need, so they either worked too slowly or the wrong microbes took over.

This manual fixes that by teaching you the system, not just a recipe. You will learn why a pile heats up, what to do when it does not, how to read a pile by smell, temperature, and appearance, and how to choose the right method for your home: a hot pile if you have space and garden waste, a slow pile if you want the least work, a worm bin if you have little outdoor space, or bokashi if you want to handle cooked food and other materials a normal pile should not take.

Composting is, at its heart, controlled rotting. You are not making something happen that would not happen in nature. Fallen leaves rot on a forest floor, a dead plant breaks down in a field, and kitchen scraps rot in a bin. What you are doing is speeding that process up and steering it, by giving the decomposers — bacteria, fungi, worms, and other soil life — food, air, and water in the right proportions, in a place where the result is useful to you.

The payoff is real but modest and honest. A household that composts well can divert a large share of its kitchen and garden waste from the bin, and over a season it can produce a useful quantity of finished compost for beds, pots, and lawns. How much depends on how much material you put in, how warm your climate is, how often you turn and water the pile, and how much space you have. A small household with a worm bin will produce a few kilograms of worm castings over several months. A larger household with a cubic-metre hot pile, turned regularly in a warm climate, may produce 200 to 400 litres of finished compost over a year. Those are ranges, not promises. The value is not only in the volume. Finished compost improves soil structure, helps soil hold water, and returns nutrients slowly. It is free, it is made from material you already have, and it replaces at least some of the bagged compost you would otherwise buy.

This course is built for a gardener or an eco-conscious household that wants a system that works week after week, not a weekend project that is abandoned by spring. Work through the modules in order the first time. Then use the workbook, the troubleshooting flowcharts, and the seasonal calendar as your day-to-day tools.

### What you will be able to do when you finish

- Build a compost pile with a workable carbon-to-nitrogen balance, using materials you already have.
- Tell, by temperature, smell, and appearance, whether a pile is working, stalled, too wet, or too dry — and fix it.
- Run a hot pile that reaches and holds working temperatures, turn it on a sensible schedule, and know when it is finished.
- Run a slow pile with minimal effort and realistic expectations about timing.
- Set up and maintain a worm bin, feed it correctly, and harvest castings without harming the worms.
- Set up and run a bokashi bucket, ferment food waste safely, and finish it in soil or a compost pile.
- Audit your household waste, find the largest streams you can compost, and cut what goes to the bin.
- Keep composting going through the seasons, including winter slowdowns and summer drying.

### How to use this manual

Read Module 1 first, even if you are impatient to start. It is the shortest route to every later decision. Modules 2 to 5 are the four methods. You do not need to use all four. Most households use one main method and one supporting method — for example, a hot pile for garden waste plus a worm bin for kitchen scraps, or a slow pile plus bokashi for cooked food. Module 6 ties the system together: troubleshooting, the household waste audit, and a maintenance routine. The seasonal calendar at the end tells you what to do in each season, and the worked examples show how three different households put the pieces together.

Keep a compost log from day one. The workbook includes one. A log turns composting from guesswork into a skill: you will see which mixtures heated up, which stayed cold, and what you changed that made the difference.

---

## Module 1: Compost Science — Carbon, Nitrogen, Air, Water, and Microbes

### 1.1 What composting actually is

Composting is the aerobic decomposition of organic material by microorganisms, mainly bacteria and fungi, with help from larger organisms such as worms, beetles, and other soil animals. Aerobic means "with oxygen." When oxygen is present, decomposition produces carbon dioxide, water, and heat, and the end product smells earthy. When oxygen is absent, decomposition becomes anaerobic. Anaerobic decomposition produces methane, hydrogen sulfide, and other gases that smell like rotten eggs or sour milk. That is why a smelly pile is almost always a pile that has run out of air, or that has too much wet, nitrogen-rich material packed too tightly for air to move through it.

The microbes do the work. You do not need to buy them. They are already on every leaf, every peel, and every handful of soil. Your job is to create the conditions in which the right microbes thrive: a mix of food, air, water, and warmth, in a pile large enough to hold heat.

Think of a compost pile as a slow fire that burns without flame. The fuel is carbon. The microbes burn carbon for energy, and in doing so they release heat. Nitrogen is the building material the microbes need to grow and reproduce. Without enough nitrogen, there are too few microbes to do the work quickly, and the pile stays cold. Without enough carbon, there is too much nitrogen relative to the fuel, the excess nitrogen escapes as ammonia, and the pile smells. Getting the balance right is the single most important skill in composting.

### 1.2 Carbon and nitrogen: the balance that decides everything

Every organic material has a carbon-to-nitrogen ratio, written as C:N. It is the ratio, by weight, of carbon to nitrogen in the material. Dry leaves have a lot of carbon and little nitrogen, so their ratio is high — roughly 30:1 to 80:1 depending on the type of leaf and how dry it is. Fresh grass clippings have much more nitrogen relative to carbon, so their ratio is low — roughly 12:1 to 25:1. Kitchen scraps are also nitrogen-rich, roughly 15:1 to 25:1. Sawdust is almost all carbon, roughly 400:1 to 500:1. Cardboard is roughly 350:1.

The target for a working compost pile is a starting ratio of about 25:1 to 30:1. That is the range in which microbes have enough carbon for energy and enough nitrogen to build new cells, with little excess of either. You do not need to measure this precisely. Nobody weighs every handful of leaves. What you need is a practical rule that gets you close, and a way to read the pile and correct it if you are off.

The practical rule is this: mix roughly two to three parts carbon-rich "brown" material to one part nitrogen-rich "green" material, by volume. Browns are dry, carbon-rich materials: dry leaves, straw, shredded cardboard, shredded newspaper, sawdust, wood chips, and dry garden stems. Greens are moist, nitrogen-rich materials: fresh grass clippings, kitchen scraps, fresh weeds, coffee grounds, and manure. The volume rule works because browns are light and bulky and greens are dense and wet, so two to three buckets of browns to one bucket of greens lands near the target ratio in most household mixtures.

The table below gives approximate C:N ratios for common household materials. These are typical values, not exact measurements. The same material varies: leaves from different trees differ, grass cut in spring differs from grass cut in late summer, and kitchen scraps vary with what you eat. Use the table to judge direction, not to calculate to the decimal point.

| Material | Type | Approximate C:N ratio | Notes |
|---|---|---|---|
| Dry leaves (mixed) | Brown | 40:1 to 80:1 | Shred them; whole leaves mat together and exclude air |
| Straw | Brown | 60:1 to 100:1 | Good structure; keeps air channels open |
| Shredded cardboard | Brown | 300:1 to 400:1 | Remove tape and staples; wet it before adding |
| Shredded newspaper | Brown | 150:1 to 200:1 | Use plain newsprint; avoid glossy colour pages |
| Sawdust (untreated wood) | Brown | 400:1 to 500:1 | Use sparingly; a little goes a long way |
| Wood chips | Brown | 200:1 to 400:1 | Slow to break down; good for structure |
| Dry garden stems, chopped | Brown | 50:1 to 80:1 | Chop to 5–10 cm pieces |
| Fresh grass clippings | Green | 12:1 to 25:1 | Add in thin layers; thick layers mat and smell |
| Kitchen scraps (fruit and vegetable) | Green | 15:1 to 25:1 | Chop large pieces; bury in the pile |
| Coffee grounds (with filters) | Green | 20:1 | A useful nitrogen source; do not add in thick slabs |
| Fresh weeds (no seeds) | Green | 20:1 to 30:1 | Avoid weeds with mature seeds or persistent roots |
| Horse manure (with bedding) | Green | 25:1 to 35:1 | Hot; mix well and let it heat before use |
| Chicken manure | Green | 10:1 to 15:1 | Very hot; use in small amounts, well mixed |
| Cow manure | Green | 20:1 to 25:1 | Milder than chicken manure |
| Seaweed (rinsed) | Green | 15:1 to 20:1 | Rinse off salt; a useful trace-mineral source |

### Worked example 1: building a balanced pile from what you have

Suppose you have a large bag of dry autumn leaves (about 60 litres, loosely packed) and a bucket of kitchen scraps (about 10 litres) plus a bucket of fresh grass clippings (about 10 litres). The leaves are your browns; the scraps and clippings are your greens. By volume you have 60 litres of browns to 20 litres of greens — a 3:1 ratio, which is at the brown-heavy end of the rule and a good place to start.

Now check it with the ratio table. Take the leaves at roughly 60:1, the scraps at roughly 20:1, and the grass at roughly 20:1. Because the leaves dominate by volume but are light, and the greens are dense, the blended ratio will land somewhere in the high 20s to low 30s — close to the 25:1 to 30:1 target. That is good enough. Build the pile, wet it as you go, and watch what happens over the next three to five days. If it heats up, your balance was right. If it stays cold and dry, add water and a little more green. If it smells of ammonia, add browns and turn it.

### Worked example 2: correcting a pile that is too green

Suppose a pile was built mostly from grass clippings and kitchen scraps, with almost no browns. Within two days it smells sharp and sour, it is slimy, and it has slumped into a dense mat. The ratio is probably near 15:1 — too much nitrogen, too little carbon, and too little structure for air. The fix is mechanical as well as chemical: pull the pile apart, mix in two to three parts shredded cardboard or dry leaves for every part of the slimy material, and rebuild it loosely so air can move through. The added carbon gives the microbes fuel to process the excess nitrogen, and the added structure restores airflow. Within a few days the smell should fade and the temperature should rise into the working range.

### Worked example 3: correcting a pile that is too brown

Suppose a pile was built mostly from dry leaves and shredded cardboard, with only a handful of kitchen scraps. After a week it is still cold, dry, and unchanged. The ratio is probably above 50:1 — plenty of carbon, not enough nitrogen for a large microbe population. The fix is to add greens: a bucket of grass clippings, a bucket of kitchen scraps, or a few shovelfuls of manure, mixed through the pile, plus water. Within three to five days a corrected pile usually begins to warm. If it does not, add a little more green and check the moisture — a dry pile cannot heat no matter how good its ratio is.

### 1.3 Water: the wrung-out sponge test

Microbes need water to live and work, but they also need air, and water and air compete for the same pore spaces in a pile. Too little water and the microbes go dormant. Too much water and the pores fill, air is excluded, and the pile turns anaerobic and smelly.

The target moisture for a compost pile is roughly 40 to 60 percent by weight — that is, about half the weight of a handful of pile material is water. In practice, nobody weighs this. Use the wrung-out sponge test: take a handful of material from the centre of the pile and squeeze it firmly. It should feel damp like a wrung-out sponge. You should be able to squeeze out one or two drops of water, no more. If no water comes out and the material feels dry and dusty, the pile is too dry — add water slowly while turning. If water runs out in a stream, the pile is too wet — add dry browns and turn it to restore air.

Water the pile as you build it, layer by layer, rather than trying to wet a finished pile from the top. Water runs down the outside of a dry pile and leaves the centre dry. A watering can with a rose head, applied lightly to each layer as you build, is the most reliable method. In hot, dry weather, check moisture weekly. In wet weather, keep a cover on the pile — a tarp, a lid, or a piece of old carpet — so rain does not saturate it.

### 1.4 Air: why turning matters, and when it does not

Aerobic microbes consume oxygen quickly in a hot pile. Without turning, the centre of a pile can run out of oxygen within a few days. Turning does three things: it reintroduces oxygen, it mixes material from the cooler outside into the hot centre so it breaks down evenly, and it lets you check moisture and add water or browns where they are needed.

How often you turn depends on your method. A hot pile is turned every three to seven days while it is actively heating. A slow pile may be turned once a month, or not at all. A worm bin is never turned in the same way — the worms do the mixing. Bokashi is sealed and not turned at all. The method chapters give exact schedules. The principle is the same in all of them: air in, heat retained, moisture held.

Structure matters as much as turning. Materials that hold the pile open — straw, chopped stems, wood chips, crumpled cardboard — create air channels that persist between turnings. Materials that mat — whole leaves, thick layers of grass, wet newspaper in slabs — close those channels. Shred or chop bulky materials, add greens in thin layers rather than thick slabs, and mix rather than layering in thick bands.

### 1.5 Heat: what the temperature tells you

A working hot pile passes through temperature phases. In the first one to three days, mesophilic bacteria — those that work at moderate temperatures, roughly 20 to 45°C (68 to 113°F) — begin breaking down the easiest material, and the pile warms. As it passes about 45°C (113°F), thermophilic bacteria take over. These are the heat-loving microbes that break down tougher material quickly, and they can drive the pile to 55 to 65°C (131 to 149°F). That is the working range for a hot pile. Above about 70°C (158°F), even the thermophiles slow down and the pile can stall from its own heat — turning it will cool it and restore activity.

Temperature is your best diagnostic tool. A compost thermometer with a long probe (30 to 50 cm) is one of the few purchases this manual recommends without hesitation. Push the probe into the centre of the pile, wait a minute, and read it. A pile that is 55 to 65°C is working well. A pile that is 40 to 50°C is working slowly. A pile at ambient temperature after three to five days has a problem — usually moisture, balance, or size. A pile that has cooled after heating is either finished with its hot phase or has run out of food, air, or water.

Pile size matters for heat. A pile smaller than about 0.75 cubic metres (roughly 1 cubic yard, or a cube about 90 cm on each side) struggles to hold heat, because its surface area is large relative to its volume and heat escapes faster than the microbes produce it. A pile of about 1 cubic metre is the practical minimum for reliable hot composting. That is why the hot method in Module 2 asks you to gather enough material to build the whole pile at once, rather than adding a little at a time.

### 1.6 The microbes and the soil life: who does what

You do not need to memorise species names, but it helps to know the sequence. First, bacteria break down sugars, starches, and proteins — the easy material. Fungi follow, breaking down cellulose and lignin — the tough fibres in leaves, stems, and wood. Actinomycetes, a group of bacteria that look and smell like fungi (they give finished compost and forest soil their earthy smell), break down the toughest material late in the process. Worms, beetles, springtails, and other soil animals shred material, mix it, and leave behind castings that are rich in available nutrients. When the pile cools and cures, this whole community settles into the finished compost, which is why finished compost is more than the sum of its ingredients: it carries living soil biology into your garden.

Do not add commercial compost starters or activators unless you want to. They are not necessary. A handful of finished compost or garden soil mixed into a new pile introduces all the microbes you need, and the microbes already present on the raw materials will do the rest. Save your money for a thermometer and a good fork.

### 1.7 What finished compost looks like, smells like, and feels like

Finished compost is dark brown to black, crumbly, and earthy-smelling. You should not be able to recognise the original materials in it, except for a few woody pieces that take longer to break down. It should feel like a damp sponge that has been wrung out — moist but not wet — and it should not heat up again when you pile it and wet it. If it still smells sour or ammonia-like, or if you can still recognise kitchen scraps or leaves, it is not finished. Give it more time, turn it, and check the moisture. The curing stage, covered in Module 2, is what turns hot, rough compost into stable, garden-ready compost.

### 1.8 Safety and what not to compost

Most household composting is safe, but a few rules protect you, your garden, and your neighbours. Do not compost meat, fish, dairy, fats, or oils in an open pile or a worm bin — they attract pests, smell, and can carry pathogens that a home pile may not reliably kill. Bokashi, covered in Module 5, is the exception: it ferments these materials in a sealed, acidic environment, and the fermented material must then be buried or added to a hot pile to finish. Do not compost pet waste from dogs or cats, or human waste, in a home system. Do not compost diseased plants, or weeds with mature seeds, unless your pile reliably reaches and holds hot temperatures long enough to kill them — and if you are unsure, leave them out. Do not compost treated wood, painted wood, or wood with preservatives; the chemicals can persist. Do not compost glossy or heavily printed paper, or paper with plastic coatings. Wash your hands after handling compost, wear gloves, and avoid breathing in dust from dry compost — dampen dry material before turning it.

Check local rules before you compost. Some towns restrict open piles, some require bins with lids, and some have rules about food waste. The rules are there for good reasons — rats and odours affect neighbours — and a lidded bin or a well-managed pile will satisfy most of them.

### Module 1 summary

- Compost is aerobic decomposition. Oxygen is what keeps it sweet-smelling and fast.
- The target starting C:N ratio is about 25:1 to 30:1. In practice, use two to three parts browns to one part greens by volume.
- Moisture should feel like a wrung-out sponge: damp, with one or two drops when squeezed.
- Air matters as much as food and water. Structure and turning keep oxygen flowing.
- A pile of about 1 cubic metre holds heat. Smaller piles work, but more slowly.
- Temperature tells you what is happening. Measure it, log it, and correct by what it tells you.


---

## Module 2: Hot Composting — Fast, Hot, and Thorough

### 2.1 When hot composting is the right choice

Hot composting is the right choice when you have space, you have a good volume of garden waste, and you want finished compost quickly — typically in 6 to 12 weeks in warm weather, or 10 to 16 weeks in cooler conditions, depending on climate, materials, and how often you turn. It is also the best choice when you want to compost weeds with seeds or mildly diseased plant material, because sustained heat is the only home method that reliably reduces seeds and many plant pathogens. It is not the right choice if you have only a small balcony, if you can only add material a little at a time, or if you cannot turn a pile every few days during the hot phase. In those cases, use the slow method, a worm bin, or bokashi instead.

Hot composting needs a batch. You gather enough material to build a pile of about 1 cubic metre in one go, build it in a day, and then manage it as a single batch until it is finished. Adding fresh material to a hot pile restarts the process and delays finishing, so a second bin or a second pile is useful: one pile cooking, one pile being built.

### 2.2 What you need

- A site: a level, well-drained spot, in partial shade if possible, with access to water and room to turn the pile. Direct contact with soil is best — it lets worms and microbes enter from below and lets excess water drain. A paved or concrete base works, but you will need to add a few shovelfuls of soil or finished compost to introduce microbes.
- A bin or an open pile. A simple bin made from three pallets, wire mesh, or wooden slats, about 1 metre wide, 1 metre deep, and 1 metre high, works well. Two bins side by side are better than one, so you can turn from one into the other. A lid, a tarp, or a piece of old carpet keeps rain off and heat in.
- A compost thermometer with a 30 to 50 cm probe.
- A garden fork and a spade.
- A watering can or hose with a gentle spray.
- Materials: roughly 2 to 3 cubic metres of mixed browns and greens, gathered before you start. That sounds like a lot. It is. A cubic metre of loose leaves compresses to far less once it is wet and turned. Gather more than you think you need.

### 2.3 Building the pile, step by step

**Step 1 — Prepare the base.** Lay down 10 to 15 cm of coarse, bulky material — chopped stems, straw, or small twigs. This creates an air layer at the bottom and keeps the pile draining. Do not start with a thick layer of grass or kitchen scraps on bare ground; it will mat and go anaerobic.

**Step 2 — Add the first layer.** Add 15 to 20 cm of mixed browns and greens. Aim for the 2:1 to 3:1 brown-to-green volume ratio. Shred leaves, chop stems, and tear cardboard into pieces no larger than a hand. Add greens in thin layers, not thick slabs.

**Step 3 — Wet each layer.** Water each layer lightly as you build, until it feels like a wrung-out sponge. If you are adding dry leaves, wet them thoroughly — dry leaves repel water once they are buried, and a dry core will never heat.

**Step 4 — Add a starter.** Sprinkle a few shovelfuls of garden soil or finished compost over every second or third layer. This introduces microbes. It is not essential, but it helps a first pile start faster.

**Step 5 — Repeat to full height.** Keep adding layers, wetting as you go, until the pile is about 1 to 1.2 metres high. The pile will settle by 20 to 30 percent in the first week. That is normal.

**Step 6 — Cover it.** Put a lid or tarp over the pile, weighted at the edges. The cover keeps rain off and holds heat. Leave a small gap at the sides for air if you are using a tarp — do not seal the pile airtight.

**Step 7 — Wait and measure.** Check the temperature daily for the first week. A well-built pile should begin warming within 24 to 72 hours and reach 50 to 65°C within three to five days. Record the temperature in your log.

### 2.4 The hot phase: turning schedule

The hot phase is managed by temperature, not by the calendar. The rule is simple: when the temperature peaks and then begins to fall, turn the pile. When you turn, move the outside material into the centre and the centre material to the outside, so everything gets its time in the hot core. Add water if the material is dry, and add browns if it smells.

A typical schedule in warm weather looks like this:

- **Days 1–3:** Pile warms. Temperature climbs from ambient to 40–55°C.
- **Days 3–5:** Temperature peaks at 55–65°C. Do not turn yet — let it hold.
- **Day 5–7:** Temperature begins to fall, or it has held above 55°C for three days. Turn the pile. Temperature will drop after turning, then climb again over the next two to three days.
- **Days 7–21:** Turn every three to five days, whenever the temperature peaks and falls. Each turn, check moisture and smell. The pile will get smaller and darker with each turn.
- **Days 21–35:** Temperature peaks get lower — 45–55°C, then 40–45°C. Turning intervals stretch to five to seven days. The material is becoming recognisable as compost rather than as leaves and scraps.
- **Weeks 5–8:** The pile no longer reheats much after turning. The hot phase is ending. Move to curing.

In cooler weather, every stage takes longer. A pile built in late autumn may take 10 to 16 weeks to finish its hot phase, and a pile built in midwinter in a cold climate may stall until spring. That is normal. Insulate a winter pile with a thick layer of straw or leaves around the outside, keep it covered, and do not turn it in freezing weather — turning loses heat you cannot afford to lose.

If the pile exceeds 70°C, turn it immediately. Above that temperature, the microbes that do the work begin to die back, and the pile can stall. Turning cools it and reintroduces oxygen. If it keeps overheating, add more browns and turn more often.

### 2.5 Worked example: a hot pile from a garden clean-up

A household clears a garden in early spring. They have: 4 large bags of dry leaves saved from autumn (about 240 litres), 2 wheelbarrows of chopped perennial stems (about 160 litres), 1 wheelbarrow of fresh grass clippings (about 80 litres), a bucket of kitchen scraps saved over a week (about 15 litres), and a bucket of coffee grounds (about 5 litres). Total browns: about 400 litres. Total greens: about 100 litres. The volume ratio is 4:1 — a little brown-heavy, but the leaves are light and the grass is dense, and the stems will break down slowly, so this is a workable starting point. They build the pile in one afternoon, wetting each layer, and add a few shovelfuls of finished compost from a neighbour's pile as a starter.

Day 2: temperature 38°C. Day 4: 58°C. Day 6: 62°C, then falling. They turn on day 7. Day 10: 55°C. Day 14: turned again, 52°C after reheating. By week 4 the pile has shrunk to about half its original volume, the temperature peaks at 45°C after turning, and the material is dark and crumbly with a few woody pieces remaining. By week 7 the pile no longer reheats above 35°C. They move it to curing. Total time from build to curing: about 7 weeks, in a mild spring climate, with turning every 4 to 5 days. In a colder climate or with less turning, the same pile would have taken 10 to 14 weeks. Both outcomes are normal.

### 2.6 Curing: the stage most people skip, and should not

Curing is the slow, cool finishing stage. The pile is no longer hot, but it is not yet stable compost. During curing, fungi and actinomycetes break down the remaining tough fibres, the microbial community settles, and any remaining ammonia or organic acids dissipate. Compost that is used before curing can harm seedlings: it can tie up nitrogen in the soil as microbes continue breaking it down, and it can contain compounds that inhibit germination.

To cure, move the compost to a separate pile or bin, keep it moist but not wet, cover it, and leave it for 4 to 8 weeks. Turn it once or twice during curing, mainly to check moisture. Do not add fresh material to a curing pile. At the end of curing, the compost should be dark, crumbly, earthy-smelling, and cool — it should not reheat when you wet it and pile it up. If it does reheat, it needs more curing time.

Screening is optional but useful. Pass the cured compost through a 1 to 2 cm mesh screen. The fine material goes to the garden. The coarse material — woody pieces, avocado stones, corn cobs — goes back into the next hot pile, where it will break down further. Screening is a good job for a dry afternoon, and it makes the finished compost much easier to spread.

### 2.7 Using hot compost in the garden

Finished hot compost is a soil improver, not a fertiliser in the concentrated sense. It adds organic matter, improves structure, helps soil hold water, and releases nutrients slowly as soil life breaks it down further. A useful general application rate is 2 to 5 cm spread over a bed and forked lightly into the top 10 to 15 cm of soil, once or twice a year, typically in spring before planting and in autumn after clearing. For pots, mix one part compost to three or four parts potting mix. For a lawn, spread a thin layer — 0.5 to 1 cm — as a top dressing in spring or autumn and water it in.

Do not plant directly into pure compost, and do not use unfinished compost around seedlings. Finished, cured compost is safe for most garden uses. If you are growing food crops, follow local food-safety guidance about compost use, and wash produce thoroughly.

### 2.8 Hot composting checklist

- [ ] Site chosen: level, drained, near water, with room to turn.
- [ ] Enough material gathered for a pile of about 1 cubic metre.
- [ ] Browns and greens mixed at roughly 2:1 to 3:1 by volume.
- [ ] Each layer wetted as built; wrung-out sponge test passed.
- [ ] Pile covered; thermometer in place; first temperature logged.
- [ ] Turned when temperature peaks and falls, every 3–7 days in the hot phase.
- [ ] Cured for 4–8 weeks after the hot phase ends.
- [ ] Screened, stored dry-ish under cover, and used within the season.

### Module 2 summary

Hot composting is fast because it is managed: a full batch, the right balance, enough size to hold heat, and turning driven by temperature. It takes effort — gathering material, building in a day, turning every few days — and in return it gives you finished compost in 6 to 16 weeks depending on conditions, and it handles the widest range of garden materials.

---

## Module 3: Cold and Slow Composting — The Low-Effort Pile That Still Works

### 3.1 When slow composting is the right choice

Slow composting, also called cold composting, is the right choice when you want the least work, when you add material a little at a time rather than in batches, or when you do not have enough material at once to build a hot pile. It is the default method for many households: a bin in a corner of the garden, added to whenever there are scraps or garden waste, turned occasionally, and harvested when it is ready. It is not fast. A slow pile typically takes 6 to 12 months to produce finished compost, and in a cold climate it can take 12 to 18 months. That is not a failure. It is the trade-off for minimal effort.

Slow composting is not the right choice if you need compost quickly, if you want to compost weeds with mature seeds, or if you want to compost material that needs heat to be safe. Seeds and many plant pathogens can survive a cold pile. Keep those materials out of a slow pile, or accept that they may come back.

### 3.2 How a slow pile works

A slow pile works by the same biology as a hot pile, but without the heat. Mesophilic bacteria and fungi break material down at ambient temperature. Worms and other soil animals do much of the mixing and shredding. Because the pile never gets hot, the process is slower, but it is also more forgiving: you can add material gradually, you do not need to measure temperature, and you do not need to turn on a schedule.

The same balance rules apply, but loosely. Add browns with greens, keep the pile damp, and avoid thick layers of a single material. A slow pile that is built only from grass clippings will still mat and smell. A slow pile built only from dry leaves will still sit unchanged for a year. The 2:1 to 3:1 brown-to-green rule is still your guide, applied as you add material over weeks and months rather than in a single build.

### 3.3 Setting up a slow pile

Choose a spot in a corner of the garden, on soil, with room to add material and to turn occasionally. A single bin — a wire cylinder, a pallet bin, or a purchased compost bin with a lid — is enough. A two-bin setup is better: one bin you are adding to, and one bin that is finishing undisturbed. Without a second bin, you will keep adding fresh material to compost that is nearly finished, and you will never have a clean harvest.

Start with a base layer of coarse material, as in Module 2. Then add material as it comes: kitchen scraps buried in the centre of the pile, garden waste chopped and mixed in, dry leaves added as browns. Bury kitchen scraps under at least 10 to 15 cm of browns or finished compost each time you add them. This is the single most effective pest-control step in slow composting. Scraps left on the surface attract flies and rodents. Scraps buried in the pile do not.

Keep the pile covered if your bin has a lid, or cover it with a tarp. A covered pile stays damp in dry weather and does not become saturated in wet weather. Check moisture monthly. In a dry summer, a slow pile can dry out completely and stop working. If it is dry, water it while turning.

### 3.4 Managing a slow pile through the year

Turn the pile every four to eight weeks, or whenever you have time and the pile looks compacted. Turning mixes fresh material in, reintroduces air, and lets you check moisture. You do not need to turn on a strict schedule. A pile that is turned three or four times a year will still finish — it will just take longer than one turned monthly.

In winter, a slow pile in a cold climate will largely stop. That is normal. Keep adding material if you have it, keep the pile covered, and let it wait for spring. In spring, turn the pile, check moisture, and add a bucket of greens to restart activity. In summer, watch for drying out. In autumn, add the season's leaves as browns — shredded if possible — and mix them in rather than dumping them in a thick layer.

### 3.5 Harvesting a slow pile

A slow pile is ready when the bottom and centre are dark, crumbly, and earthy-smelling, and you cannot recognise the original materials. Because you have been adding material over time, the top will always be fresher than the bottom. Harvest from the bottom, or move the unfinished top material aside, take the finished compost from below, and return the unfinished material to the bin to continue. With a two-bin system, this is simple: when the first bin is full, stop adding to it, let it finish undisturbed for 2 to 4 months, and start filling the second bin. Then harvest the first bin and start again.

Expect a yield that reflects what you put in. A household adding a bucket of kitchen scraps a week plus seasonal garden waste might harvest 100 to 250 litres of finished compost per year from a slow pile, depending on climate and how much garden waste they add. A household with a large garden and a big pile will harvest more. The range is wide because the inputs are wide. Log what you put in and what you take out, and after a year you will know your own household's rate.

### 3.6 Slow composting mistakes and fixes

- **The pile smells.** It is too wet, too green, or the scraps are on the surface. Add browns, turn it, and bury scraps in future.
- **The pile is dry and unchanged.** Add water while turning, and add greens. A dry pile is a paused pile.
- **Flies around the pile.** Scraps are exposed. Bury them, cover the pile, and add a thick layer of browns on top.
- **Rats or mice.** The pile contains food they can reach, or it is dry and warm enough to nest in. Remove any meat, dairy, or cooked food (these should never be in a slow pile), bury scraps deeper, keep the pile damp, and turn it more often. If the problem persists, switch kitchen scraps to a sealed worm bin or bokashi bucket and use the slow pile for garden waste only.
- **The pile never finishes.** You keep adding fresh material to it. Stop adding, let it cure for 2 to 4 months, and start a second pile.

### Module 3 summary

Slow composting trades speed for ease. Add browns with greens, bury scraps, keep the pile damp, turn it when you can, and let time do the work. Expect 6 to 18 months depending on climate and effort, and harvest from the bottom or by resting a full bin. It is the right method for most households that want compost without a weekly chore.


---

## Module 4: Vermicomposting — Letting Worms Do the Work

### 4.1 When vermicomposting is the right choice

Vermicomposting — composting with worms — is the right choice when you have little or no outdoor space, when your main compostable stream is kitchen scraps, or when you want a high-quality soil amendment in small quantities. A worm bin fits on a balcony, in a garage, in a utility room, or under a kitchen counter. It works year-round indoors, it produces no smell when it is managed correctly, and it turns kitchen scraps into worm castings — a fine, dark, nutrient-rich material that is widely valued by gardeners for pots, seedlings, and beds.

Vermicomposting is not the right choice for large volumes of garden waste. Worms eat kitchen scraps and soft plant material; they do not process woody stems, large volumes of leaves, or grass clippings efficiently. A household with a large garden will still need a pile for garden waste, with a worm bin as a complement for the kitchen. It is also not the right choice if you cannot keep the bin within the worms' temperature range, roughly 13 to 25°C (55 to 77°F), or if you travel for long periods without someone to feed the bin. Worms are living animals. They need consistent care, even if that care is only a few minutes a week.

### 4.2 The worms

The worms used in vermicomposting are not ordinary garden earthworms. The standard species are red wigglers (Eisenia fetida) and, in warmer climates, African nightcrawlers or Indian blues. Red wigglers are the most widely available and the most forgiving for beginners. They live in the top layers of organic material, they reproduce quickly when conditions are good, and they tolerate the range of conditions a home bin provides. Garden earthworms live deeper in soil, eat soil as much as organic matter, and do poorly in a bin. Do not dig up garden worms for a worm bin. Buy red wigglers from a reputable supplier — typically sold by weight, around 250 grams to 500 grams to start a household bin — and check that they are a composting species, not bait worms of a different species.

A note on honesty: worm suppliers vary, and worm counts per gram vary with worm size. A starter of 500 grams of red wigglers is roughly 500 to 1,000 worms, depending on size. That is enough to start a standard household bin. The population will grow if you feed and house them well, and shrink if you do not. Do not expect a precise count, and do not buy more than you need to start — the worms will multiply.

### 4.3 Setting up a worm bin

You can buy a manufactured worm bin with stacked trays, or make one from a plastic storage box. A homemade bin is simple and cheap, and this manual describes it in full. You need:

- A dark, opaque plastic box, roughly 40 to 60 litres, with a lid. Dark matters: worms avoid light. Clear boxes stress them.
- A second, shallow tray or lid underneath to catch liquid (optional but useful).
- A drill, to make air holes and drainage holes.
- Bedding: shredded newspaper, shredded cardboard, coconut coir, or aged leaves, dampened.
- A handful of garden soil or finished compost, to add grit and microbes.
- Red wigglers.

**Step 1 — Prepare the box.** Drill 8 to 12 small holes (about 6 mm) around the upper sides of the box for air, and 8 to 12 small holes in the bottom for drainage. If you are keeping the bin indoors, put it on a tray to catch any liquid. Cover the air holes with fine mesh or a piece of old curtain if you are concerned about fruit flies entering.

**Step 2 — Prepare the bedding.** Fill the box about two-thirds full with damp bedding. Shredded newspaper and cardboard are the easiest bedding materials. Wet them, then squeeze out excess water so the bedding is damp like a wrung-out sponge. Fluff the bedding up — do not pack it down. Worms need air in the bedding. Add a handful of soil or finished compost and mix it in lightly.

**Step 3 — Add the worms.** Place the worms on top of the bedding, put the lid on, and leave the bin in a dark, quiet place for 24 hours. The worms will burrow down into the bedding on their own. Do not feed them on the first day. Let them settle.

**Step 4 — First feeding.** After 24 hours, add a small amount of food — about 100 to 150 grams of chopped kitchen scraps — buried under the bedding in one corner. Cover it with bedding. Do not spread food across the whole bin. Feed in one spot, and next time feed in a different spot. This rotation lets you see whether the previous feeding has been eaten.

### 4.4 What to feed, and what not to feed

Worms eat most fruit and vegetable scraps, coffee grounds and filters, tea bags (remove staples; check that the bag material is compostable — many tea bags contain plastic), crushed eggshells (a useful source of grit and calcium), and small amounts of plain bread, rice, or pasta. Chop or tear food into small pieces — the smaller the piece, the faster the worms and microbes can process it. Freezing scraps and then thawing them before feeding softens them and speeds breakdown. Many experienced worm keepers keep a container in the freezer for scraps and feed from it.

Do not feed: meat, fish, dairy, fats, or oils; citrus in large amounts (a small piece occasionally is fine, but large amounts of citrus make the bin acidic); onions and garlic in large amounts; spicy food; pet waste; or treated wood. Do not feed large amounts of any single food at once. Variety and moderation are the rules.

How much to feed: as a rough guide, a healthy, established bin can process roughly its own weight in food per week — a bin with 500 grams of worms can process about 500 grams of scraps per week, under good conditions. A new bin processes much less. Start with 100 to 150 grams per feeding, two or three times a week, and increase only when the previous feeding has mostly disappeared. Overfeeding is the most common beginner mistake. Uneaten food rots, the bin becomes acidic and smelly, and the worms suffer. If food remains after a week, stop feeding until it is gone, and add a handful of crushed eggshells and fresh bedding to buffer acidity.

### 4.5 Maintaining the bin

Check the bin once or twice a week. You are checking four things: moisture, food, smell, and worm behaviour.

- **Moisture:** The bedding should feel like a wrung-out sponge. If it is dry, spray it lightly with water. If it is wet and liquid pools at the bottom, add dry shredded cardboard or newspaper and leave the lid ajar for a day to let it dry.
- **Food:** Is the last feeding mostly gone? If yes, feed again in a new spot. If no, wait.
- **Smell:** A healthy worm bin smells earthy, like forest soil. A sour, vinegar, or rotten smell means overfeeding, excess moisture, or too much acidic food. Stop feeding, add dry bedding and crushed eggshells, and fluff the bedding gently to reintroduce air.
- **Worm behaviour:** Worms should be in the bedding, distributed through it. Worms clustered at the top, trying to escape, or massed on the lid are telling you something is wrong — usually too wet, too acidic, too hot, or too cold. Check moisture and temperature first, then food.

Temperature matters. Keep the bin between about 13 and 25°C. Below 10°C, worms slow down and may die if it freezes. Above 30°C, worms become stressed and may die. Indoors, a garage, utility room, or shaded balcony in mild weather is usually fine. In summer, move the bin to the coolest shaded spot you have. In winter, move it indoors or insulate it with blankets or straw.

Harvest the liquid, if your bin collects it, sparingly and with care. The liquid that drains from a worm bin is sometimes called "worm tea," but liquid from a bin that is too wet is leachate, not worm tea, and it can contain compounds you do not want on plants undiluted. True worm tea is made by steeping finished castings in aerated water, which is beyond the scope of this manual. If your bin produces liquid, it is usually a sign the bin is too wet. Drain it, dilute it heavily (at least 10 parts water to 1 part liquid) if you choose to use it on non-edible plants, or discard it. Do not pour undiluted leachate on seedlings or food crops.

### 4.6 Harvesting castings

After 3 to 6 months, depending on feeding rate and temperature, the bin will contain a substantial amount of dark, crumbly castings mixed with remaining bedding. It is time to harvest. There are two simple methods.

**The migration method (easiest, recommended for beginners).** Stop feeding the bin for a week. Then push all the material to one side of the bin and add fresh damp bedding and food to the empty side. Over the next two to three weeks, the worms will migrate to the fresh side to feed. You can then remove the finished castings from the old side without sorting worms by hand. A few worms will remain in the castings. Pick them out and return them to the bin, or accept that a few will go into the garden, where they will do no harm.

**The light method.** Spread the bin contents in a thin layer on a tarp in bright light (not direct sun). Worms avoid light and will burrow downward. Scrape the top layer of castings off, wait a few minutes for the worms to burrow deeper, and repeat until you are left with a concentrated mass of worms at the bottom. Return the worms to fresh bedding. This method is faster but more hands-on, and it stresses the worms more.

Store harvested castings in a breathable bag or bucket with a loose lid, kept damp but not wet. Use them within a few months. Castings are living material — they contain microbes that decline over time in storage.

### 4.7 Using worm castings

Worm castings are a gentle, slow-release soil amendment. They are not a concentrated fertiliser, and they will not burn plants the way fresh manure can, but they should still be used in moderation and mixed into soil rather than applied in thick layers on the surface. Useful rates:

- **Pots and containers:** Mix 1 part castings to 3 or 4 parts potting mix.
- **Seed starting:** Mix 1 part castings to 4 parts seed-starting mix. Castings can improve germination and early growth, but a mix that is mostly castings can hold too much water for seedlings.
- **Garden beds:** Spread 1 to 2 cm over a bed and fork lightly into the top few centimetres of soil, once or twice a year.
- **Transplanting:** Add a small handful of castings to each planting hole.

Results vary with soil, plants, and climate. Castings improve soil biology and structure over time. They are not a substitute for good watering, sunlight, and appropriate plant choice.

### 4.8 Vermicomposting worked example: a flat with no garden

A household of two in a flat has no garden and no outdoor space beyond a small balcony. They produce about 1.5 to 2 kg of fruit and vegetable scraps per week. They set up a 50-litre worm bin on the balcony in spring, starting with 500 grams of red wigglers and shredded cardboard bedding. In the first month they feed cautiously — 150 grams, twice a week — and the worms take time to settle. By month two they are feeding about 400 grams a week, and by month three the bin is processing roughly 500 grams a week, close to its capacity. The remaining scraps go to the household's food-waste collection.

After four months they harvest about 8 to 10 litres of castings by the migration method. They use the castings in pots on the balcony and give some to a neighbour with a garden. The bin continues, fed twice a week, with a second harvest about four months later. Over a year they divert roughly 20 to 25 kg of kitchen scraps from the bin and produce roughly 20 litres of castings. The numbers are modest, and that is the honest scale of a single household worm bin. The value is in the diversion, the quality of the castings, and the fact that the system runs in a few minutes a week.

### Module 4 summary

A worm bin is a small, indoor-friendly composting system for kitchen scraps. Start with red wigglers, damp bedding, and small feedings. Feed only what the worms have eaten, keep the bin damp and within 13 to 25°C, and harvest by migration after 3 to 6 months. Do not overfeed. Do not feed meat, dairy, or fats. A healthy bin smells earthy and runs on minutes of care a week.

---

## Module 5: Bokashi — Fermenting What the Pile Cannot Take

### 5.1 When bokashi is the right choice

Bokashi is the right choice when you want to compost cooked food, meat, fish, dairy, and other materials that should never go into an open pile or a worm bin. It is also the right choice when you have very little space — a bokashi bucket fits under a kitchen sink — or when you want to handle food waste in winter, when an outdoor pile is frozen and inactive. Bokashi does not produce finished compost on its own. It ferments food waste in a sealed, acidic environment, and the fermented material must then be buried in soil or added to a compost pile to finish breaking down. Think of bokashi as a pre-treatment, not a complete system.

Bokashi is not the right choice if you have nowhere to bury the fermented material and no compost pile to add it to. A household with no garden, no allotment, and no compost pile will struggle to finish bokashi waste. In that case, a worm bin for fruit and vegetable scraps, plus a municipal food-waste collection for the rest, is a better fit. Bokashi is also not a substitute for reducing food waste. The cheapest and most effective waste reduction is buying and cooking only what you will eat. Bokashi handles what remains.

### 5.2 How bokashi works

Bokashi is fermentation, not decomposition. You add food waste to a sealed bucket, sprinkle it with bokashi bran — a carrier, usually wheat bran, inoculated with effective microorganisms, including lactic acid bacteria, yeasts, and other microbes — and press the material down to exclude air. The microbes ferment the food, producing lactic acid and lowering the pH to roughly 3.5 to 4.5. At that acidity, putrefying bacteria cannot thrive, so the food does not rot or smell. Instead it pickles. The fermented material looks much like the original food — a fermented fish bone still looks like a fish bone — but it is acidic, stable, and ready to break down quickly once it is buried in soil or added to a compost pile, where soil microbes finish the job in 2 to 4 weeks.

The key difference from composting is oxygen. Composting needs air. Bokashi needs the absence of air. That is why the bucket must be sealed, the material must be pressed down to remove air pockets, and the bucket must be drained regularly. Liquid that collects in the bucket — bokashi leachate — must be drained every few days through the tap at the bottom of the bucket. If it is not drained, the material sits in liquid and the fermentation can go wrong.

### 5.3 What you need

- A bokashi bucket: a sealed bucket with a tight-fitting lid, a tap or drain at the bottom, and a strainer plate inside to keep food above the liquid. You can buy a manufactured bokashi bucket or make one from two nested buckets, but a manufactured bucket with a proper tap and seal is more reliable for beginners.
- Bokashi bran: sold by garden suppliers, typically in 1 to 2 kg bags. A 1 kg bag lasts a typical household about 2 to 4 months, depending on how much food waste they ferment. Store bran in a cool, dry place, sealed.
- Food waste: all food, including cooked food, meat, fish, dairy, bread, and small bones. Chop large pieces to speed fermentation.
- A place to bury the fermented material: a garden bed, a trench, a large pot of soil, or a compost pile.

### 5.4 Running a bokashi bucket, step by step

**Step 1 — Start with a clean, dry bucket.** Make sure the tap is closed and the strainer plate is in place.

**Step 2 — Add the first layer.** Add 2 to 3 cm of food waste. Chop it into small pieces. Spread it evenly and press it down firmly with a plate, a potato masher, or your hand in a glove. Pressing removes air pockets.

**Step 3 — Sprinkle bran.** Sprinkle a small handful of bokashi bran — about 1 to 2 tablespoons — evenly over the layer. You do not need a thick coating. The bran is an inoculant, not a bulk ingredient.

**Step 4 — Repeat.** Each time you have food waste, add it in a layer, press it down, and sprinkle bran. Keep the lid sealed between additions. Open the lid only to add food, and close it immediately.

**Step 5 — Drain the liquid.** Drain the tap every two to three days, or whenever liquid has collected. The liquid is acidic and has a sweet-sour, pickled smell when fermentation is working. Dilute it at least 100 parts water to 1 part liquid before using it on soil, and do not use it on seedlings or directly on plant leaves. If you do not want to use it, pour it down the drain diluted with water — it is not hazardous in household quantities, but check local rules if you are on a septic system.

**Step 6 — Know when the bucket is full.** A standard bokashi bucket holds about 15 to 20 litres of food waste, which takes a typical household 2 to 4 weeks to fill. When it is full, press the material down one final time, sprinkle a final layer of bran, seal the lid, and leave it to ferment for 2 weeks without opening it. Write the date on the lid. Use a second bucket while the first ferments, so you always have somewhere to put food waste. Two buckets are not a luxury; they are how the system works without interruption.

### 5.5 What fermented bokashi should look and smell like

After two weeks of sealed fermentation, the material should smell sweet-sour and pickled, like sauerkraut or vinegar. It may have a white mould on the surface — this is usually a beneficial yeast or fungus associated with fermentation, and it is normal. Green or black mould, or a strong rotten or putrid smell, means the fermentation failed — usually because air got in, the bucket was not drained, or not enough bran was used. If a bucket fails, do not bury it near food crops. Add it to a hot compost pile, where the heat and aerobic microbes will process it, or bury it deeply in a non-food bed and let it break down over several months. Clean the bucket thoroughly before starting again.

Fermented bokashi still looks like food. That surprises beginners. The transformation happens after burial, not in the bucket. Once buried, soil microbes break the fermented material down in 2 to 4 weeks in warm soil, or 4 to 8 weeks in cool soil. The material disappears, and the soil is enriched.

### 5.6 Finishing bokashi: burying it

The standard finishing method is to bury the fermented material in a trench or hole in the garden, about 20 to 30 cm deep, and cover it with at least 15 to 20 cm of soil. Do not bury it near the roots of plants you are about to harvest, and do not plant directly into the burial spot for at least 2 to 4 weeks — the material is acidic and still breaking down, and it can temporarily harm roots. Mark the burial spot and wait.

If you have a compost pile, you can add fermented bokashi to the pile instead. Add it in the centre of a hot pile, bury it under browns, and turn the pile. The heat and microbes will finish it quickly. Do not add large amounts of bokashi to a worm bin — the acidity and the salt content can harm worms. Small amounts, well mixed and only after the material has been buried and partially broken down, are sometimes used by experienced keepers, but for beginners the rule is simple: bokashi goes to soil or to a compost pile, not to worms.

If you have no garden, you can finish bokashi in a large pot or a "soil factory" — a large container filled with soil, into which you bury fermented bokashi in layers. After 4 to 8 weeks, the soil in the container is enriched and can be used for potted plants. This works, but it needs space and patience, and it is a workaround rather than the primary method.

### 5.7 Bokashi worked example: a household that cooks most meals

A household of four cooks most meals at home and produces about 3 to 4 kg of food waste per week, including cooked leftovers, meat trimmings, and dairy that a worm bin or open pile could not take. They buy two bokashi buckets and a 2 kg bag of bran. They fill the first bucket in about three weeks, seal it, date it, and start the second bucket. Two weeks later the first bucket has fermented. They bury its contents in a trench in a vegetable bed that will not be planted for a month, covering it with 20 cm of soil. The second bucket fills while the first is fermenting, and the cycle continues.

Over a year, they ferment roughly 150 to 200 kg of food waste — a substantial diversion from the bin — and they use about 4 to 6 kg of bran. The cost of bran is the main ongoing cost of bokashi. Whether that cost is worth it depends on what you value: the diversion, the soil improvement, and the ability to handle cooked food and meat. For households that produce a lot of cooked food waste and have a garden to bury it in, bokashi is often worth it. For households that produce mostly raw fruit and vegetable scraps, a worm bin is cheaper and simpler.

### 5.8 Bokashi mistakes and fixes

- **The bucket smells rotten.** Fermentation failed. Air got in, the bucket was not drained, or too little bran was used. Add the contents to a hot compost pile or bury them deeply in a non-food bed. Clean the bucket and start again, pressing material down more firmly and draining more often.
- **Green or black mould.** Same cause and same fix. White mould is normal; green or black mould is a sign of failure.
- **The bucket is too wet.** Drain the tap more often, press material down to squeeze out air and liquid, and add a little more bran.
- **Flies in the bucket.** The lid is not sealing, or food was left exposed. Check the seal, keep the lid closed between additions, and clean the rim.
- **No liquid drains.** That can be normal if the food waste is dry. If the bucket is full and no liquid has drained in a week, the waste may be too dry for good fermentation. Add a little water — a few tablespoons — with the next layer, and make sure the tap is not blocked.

### Module 5 summary

Bokashi ferments food waste — including cooked food, meat, and dairy — in a sealed, acidic bucket. Press each layer down, sprinkle bran, keep the lid sealed, drain the liquid every few days, and ferment a full bucket sealed for two weeks. Then bury the fermented material in soil or add it to a compost pile, and wait 2 to 4 weeks before planting into that spot. Two buckets keep the system running without interruption.


---

## Module 6: Troubleshooting, Household Waste Audits, and Keeping It Going

### 6.1 Reading a pile: the four signs

Every compost problem shows up in one or more of four signs: temperature, smell, appearance, and pests. Learn to read them, and you can fix almost any pile without guessing.

**Temperature.** A hot pile that is not heating is telling you it lacks food, water, air, or size. Check moisture first — a dry pile is the most common cause. Then check balance — add greens if the pile is mostly browns. Then check size — a pile smaller than about 0.75 cubic metres may never heat reliably. A pile that heated and then cooled is either finished with its hot phase or has run out of something. Turn it, check moisture, and see if it reheats. If it does not reheat after turning and watering, it is probably ready to cure.

**Smell.** An earthy smell is good. An ammonia smell — sharp, like cleaning fluid — means too much nitrogen and not enough carbon. Add browns and turn. A sour, vinegar smell means the pile is too wet or too acidic, often from too much kitchen waste in one place. Add browns, turn, and add crushed eggshells or a little garden lime if the sourness persists — but use lime sparingly, a handful at a time, because too much lime can drive off nitrogen as ammonia. A rotten-egg smell means the pile has gone anaerobic. Pull it apart, add coarse browns for structure, and rebuild it loosely. A pile that smells of nothing at all and is cold and dry is simply inactive. Add water and greens.

**Appearance.** A working pile darkens, shrinks, and becomes crumbly. White, thread-like growth in a pile is usually actinomycetes or fungi breaking down tough material — it is normal and a good sign in a curing pile. Slimy, matted layers are a sign of too much green material packed too tightly. Dry, dusty material that has not changed is a sign of too little water. Large, recognisable pieces after months are a sign that the material was too large to begin with — chop or shred more finely next time.

**Pests.** Fruit flies mean exposed food. Bury scraps. Houseflies mean the pile is too wet or contains inappropriate material. Remove meat, dairy, or cooked food. Rats and mice mean accessible food or a dry, warm nesting site. Remove inappropriate food, bury scraps deeply, keep the pile damp, and turn it. Ants in a pile usually mean it is too dry. Water it. Slugs and woodlice in a pile are normal and harmless — they are part of the decomposer community.

### 6.2 The troubleshooting flowcharts

The templates folder contains full troubleshooting flowcharts in Markdown. Use them as a diagnostic tool: start with the symptom, answer the question, and follow the branch to the fix. The flowcharts cover five problems: a pile that will not heat, a pile that smells, a pile that is too wet, a pile that is too dry, and pests. Keep a printed copy near your compost area. The flowcharts are summarised here, and given in full in the templates.

**Pile will not heat:** Check moisture (squeeze test) → if dry, water while turning → if damp, check size (is it at least 0.75 cubic metres?) → if too small, add material or accept slow composting → if large enough, check balance (is it mostly browns?) → if yes, add greens and turn → if balanced, check age (has it already finished heating?) → if yes, move to curing → if no, turn and wait three days, then re-check.

**Pile smells of ammonia:** Add browns (two parts browns to one part pile material), turn, and cover. Do not add more greens. Do not add lime — lime makes ammonia worse.

**Pile smells sour or rotten:** Pull the pile apart, add coarse browns for structure, rebuild loosely, and turn. Check that kitchen scraps are buried, not layered in slabs. If the pile is saturated, add dry browns and leave the cover off for a day in dry weather.

**Pile is too wet:** Add dry browns, turn, and cover the pile against rain. Check drainage — a pile sitting in a hollow that collects water will stay wet no matter what you add.

**Pile is too dry:** Water slowly while turning, a little at a time, until the squeeze test passes. Wetting a dry pile from the top does not work — water runs off. Turn and water together.

**Pests:** Identify the pest, remove the attractant (exposed food, meat, dairy, cooked food), bury scraps deeper, keep the pile damp, and turn more often. If rats persist, switch kitchen scraps to a sealed worm bin or bokashi bucket.

### 6.3 The household waste audit

A waste audit is a simple, structured look at what your household throws away, so you can see what can be composted, what can be reduced, and what is genuinely waste. You do not need special equipment. You need a week, a set of bags or bins, a kitchen scale, and the worksheet in the workbook and the templates folder.

**How to do a one-week audit:**

1. **Choose a normal week.** Do not choose a holiday week, a week when you are clearing a garden, or a week when you are away. You want a typical week.
2. **Separate as you go.** For one week, put waste into separate containers or bags: (a) kitchen scraps that can be composted — fruit and vegetable peelings, coffee grounds, tea bags, eggshells; (b) cooked food, meat, fish, and dairy — compostable by bokashi only, not by an open pile; (c) garden waste — grass, leaves, prunings; (d) paper and cardboard that can be composted — shredded newspaper, plain cardboard; (e) everything else — plastic, glass, metal, and non-compostable waste.
3. **Weigh each bag at the end of the week.** Use a kitchen scale or a bathroom scale. Record the weights on the waste audit worksheet. If you cannot weigh, count bags and estimate — a standard kitchen bin bag of kitchen scraps weighs roughly 3 to 5 kg when full, but weighing is more accurate.
4. **Record what you notice.** What is the largest stream? What surprised you? What is being thrown away that could have been eaten, or composted, or avoided?
5. **Decide on two or three changes.** Do not try to fix everything at once. Pick the largest compostable stream and the easiest reduction, and act on those first.

**Worked example: a household waste audit**

A household of three does a one-week audit in spring. They weigh: kitchen scraps (fruit and vegetable) 4.2 kg; cooked food, meat, and dairy 2.8 kg; garden waste 6.5 kg (a mowing and a pruning); compostable paper and cardboard 1.1 kg; other waste 5.4 kg. Total waste: 20.0 kg. Compostable by a pile or worm bin: 4.2 + 6.5 + 1.1 = 11.8 kg, or 59 percent of the week's waste. Compostable by bokashi in addition: 2.8 kg, bringing the total compostable share to 14.6 kg, or 73 percent. Other waste: 5.4 kg, or 27 percent.

Those percentages are for that household, in that week, in spring, when garden waste is high. In winter, garden waste falls and the compostable share falls with it. In a week with no garden work, the same household might find that kitchen scraps are the largest compostable stream. The audit is not about the exact percentage. It is about seeing your own household's pattern, so you can choose the right system: a household whose largest stream is kitchen scraps needs a worm bin or bokashi; a household whose largest stream is garden waste needs a pile.

**What to do with the results:**

- If kitchen scraps are the largest stream, set up a worm bin or a bokashi bucket, and start burying scraps in the pile.
- If garden waste is the largest stream, make sure you have a pile large enough to take it, and save dry leaves in autumn as browns for the rest of the year.
- If cooked food is a large stream, consider bokashi, and look at meal planning — the cheapest reduction is cooking only what you will eat.
- If paper and cardboard are a large stream, shred what is compostable and use it as browns. Do not compost glossy, plastic-coated, or heavily printed paper.
- Repeat the audit once a year, in the same season, to see whether your changes are working.

### 6.4 Reducing waste at the source

Composting is the last step in a waste hierarchy, not the first. The hierarchy is: reduce, reuse, recycle or compost, and only then dispose. Composting a large amount of food that could have been eaten is better than sending it to landfill, but eating it is better still. A few practical reductions that most households can make without effort:

- Plan meals for the week and shop from a list. The largest source of household food waste in many homes is food bought without a plan and left to spoil.
- Store food correctly. Most vegetables last longer in the fridge than on the counter. Herbs last longer in water. Bread freezes well.
- Use leftovers. A leftover roast becomes sandwiches, soup, or a stir-fry. A pot of rice becomes fried rice. This is cooking, not composting, but it reduces what the compost system has to handle.
- Buy loose produce where you can, and avoid over-packaged food. Packaging is not compostable, and it adds to the "other waste" stream.
- Keep a "use first" shelf in the fridge for food that is near its date. Check it before you shop.

None of this requires perfection. A household that reduces its food waste by a quarter and composts most of the rest has made a large change.

### 6.5 A maintenance routine that lasts

Composting fails when it becomes a chore that nobody wants to do. The routine below is designed to take a few minutes a week, plus a longer session once a month.

**Weekly (5 to 10 minutes):** Take kitchen scraps to the pile, worm bin, or bokashi bucket. Bury scraps in the pile or feed the worm bin. Drain the bokashi bucket if you use one. Check the pile's cover and moisture by eye. Log what you added.

**Monthly (30 to 60 minutes):** Turn the hot pile if it is in its hot phase, or turn the slow pile. Check moisture with the squeeze test. Check temperature if you have a hot pile. Add browns if the pile smells or looks too green. Harvest castings if the worm bin is ready. Check the bokashi buckets and bury fermented material if a bucket has finished its two-week ferment.

**Seasonally (1 to 2 hours):** In spring, restart the pile, harvest finished compost, and spread it on beds. In summer, check for drying out and water as needed. In autumn, gather and shred leaves for winter browns, and build a new hot pile if you have enough material. In winter, cover the pile, reduce turning, and let the system rest. Use the seasonal calendar in the next section as your checklist.

### 6.6 Choosing and combining methods

Most households do best with one main method and one supporting method. Here is a guide:

| Household | Main method | Supporting method |
|---|---|---|
| House with a garden, moderate garden waste | Hot pile (spring to autumn) or slow pile | Worm bin for kitchen scraps |
| House with a large garden, lots of waste | Hot pile, two bins | Bokashi for cooked food |
| Flat or house with no garden | Worm bin | Bokashi, finished in a soil factory or a community garden |
| Household that cooks a lot, with a garden | Bokashi for food waste | Slow pile for garden waste |
| Household that wants the least work | Slow pile | Worm bin for kitchen scraps |
| Household in a cold climate | Slow pile (spring to autumn), worm bin indoors in winter | Bokashi in winter, buried in spring |

You do not need to use all four methods. Choose the combination that fits your space, your waste, and the time you are willing to spend. Start with one method, get it working, and add a second method only when the first is running smoothly.

### 6.7 Common questions, answered honestly

**How long until I have finished compost?** A hot pile: 6 to 12 weeks in warm weather, 10 to 16 weeks in cooler conditions, plus 4 to 8 weeks of curing. A slow pile: 6 to 12 months, or 12 to 18 months in a cold climate. A worm bin: first harvest in 3 to 6 months. Bokashi: fermentation in 2 weeks, plus 2 to 4 weeks in soil to finish. All of these are ranges. Your climate, your materials, and your effort move you within the range.

**How much compost will I get?** A pile shrinks as it decomposes. A cubic metre of loose raw material typically becomes 200 to 400 litres of finished compost, depending on the material and how much is woody. A worm bin produces a few litres of castings per harvest. Bokashi produces no compost directly — it produces fermented material that enriches soil after burial. Do not expect a pile to produce the same volume you put in. Shrinkage is normal and expected.

**Will composting save me money?** It can reduce what you spend on bagged compost and on waste disposal, if you pay by volume for waste collection. How much you save depends on how much bagged compost you currently buy, what waste charges you pay, and how much compost you produce. This manual does not promise a specific saving, because the numbers vary too widely between households. The honest statement is: if you currently buy several bags of compost a year and you produce a comparable volume at home, you will spend less on bagged compost. If you buy little compost and produce little, the saving will be small. The value of composting is not only financial — it is also in soil improvement, waste reduction, and the satisfaction of making something useful from waste.

**Will composting attract rats?** A well-managed pile that contains no meat, dairy, cooked food, or fats, and in which scraps are buried, is unlikely to attract rats. A pile that contains those foods, or in which scraps are left on the surface, is much more likely to attract them. If rats are a known problem in your area, use a lidded bin, bury scraps deeply, keep the pile damp, and consider moving kitchen scraps to a sealed worm bin or bokashi bucket.

**Does composting smell?** A working aerobic pile smells earthy, not unpleasant. A smelly pile is a pile with a problem — too wet, too green, or lacking air — and the troubleshooting flowcharts in this manual will help you fix it. A worm bin and a bokashi bucket, managed correctly, should not smell beyond a faint earthy or pickled scent when opened.

### Module 6 summary

Troubleshooting is reading four signs — temperature, smell, appearance, and pests — and correcting the balance, moisture, or air that caused them. A waste audit shows you what your household actually throws away, so you can choose the right system and the right changes. A short weekly routine and a seasonal rhythm keep the system going without it becoming a burden.

---

## The Seasonal Compost Calendar

This calendar is written for a temperate climate with four seasons. If you live in a warmer or colder climate, shift the calendar: in a warm climate, composting continues through winter; in a cold climate, winter is a pause and spring is the restart. The templates folder contains a printable version of this calendar.

### Spring (March to May in the northern hemisphere; September to November in the southern hemisphere)

- Restart the pile. Turn the slow pile, check moisture, and add a bucket of greens to restart activity after winter.
- Harvest finished compost from piles that cured over winter. Screen it and spread it on beds before planting.
- Start a new hot pile if you have enough material from spring garden clearing.
- Start or restart a worm bin. Worms become active as temperatures rise.
- Begin bokashi if you stopped over winter, and bury fermented material in beds that will not be planted for a few weeks.
- Save and shred any remaining dry leaves from autumn for use as browns.

### Summer (June to August; December to February in the southern hemisphere)

- Watch for drying out. A pile in hot, dry weather can dry out in a week. Check moisture weekly and water while turning.
- Turn the hot pile every 3 to 7 days while it is active.
- Add grass clippings in thin layers, mixed with browns. Do not dump thick layers of grass.
- Keep the pile covered to retain moisture, but check that it is not overheating above 70°C.
- Harvest worm castings. Worms are most active in warm weather.
- Bury bokashi in beds between plantings.

### Autumn (September to November; March to May in the southern hemisphere)

- Gather leaves. This is the most important autumn job. Shred leaves with a mower or shredder and store them dry in bags or a bin for use as browns through winter and spring. Dry leaves stored under cover keep well.
- Build a new hot pile from autumn garden waste if you have enough material.
- Harvest finished compost and spread it on beds in autumn, or store it under cover for spring.
- Reduce feeding the worm bin as temperatures fall. Move an outdoor worm bin indoors before the first frost.
- Finish bokashi buckets before winter, and bury the fermented material while the soil is still workable.

### Winter (December to February; June to August in the southern hemisphere)

- Let the outdoor pile rest. Turn it rarely, if at all, in freezing weather. Keep it covered and insulated with a thick layer of straw or leaves.
- Keep adding material to a slow pile if you have it, but expect little decomposition until spring.
- Run the worm bin indoors. It will continue through winter at indoor temperatures.
- Run bokashi through winter. Fermentation continues indoors, and you can bury the fermented material in spring when the soil thaws, or add it to a compost pile.
- Plan next year's system. Review your compost log, note what worked and what did not, and decide what to change.

---

## Worked Examples: Three Households, Three Systems

### Household A: A house with a medium garden, two adults, one child

Waste audit: kitchen scraps 3.5 kg per week, garden waste moderate, cooked food 1.5 kg per week. System: a slow pile in a two-bin setup for garden waste and kitchen scraps, plus a worm bin in the garage for kitchen scraps in winter when the pile is slow. They turn the pile monthly, harvest about 150 litres of compost a year, and harvest worm castings twice a year. Time: about 10 minutes a week, plus an hour a month. The system fits their life because it asks little of them and still diverts most of their compostable waste.

### Household B: A house with a large garden, keen gardeners

Waste audit: kitchen scraps 4 kg per week, garden waste high — several wheelbarrows a month in the growing season, cooked food 2 kg per week. System: a hot pile in two bins, built in spring and autumn from garden clearings, turned every 4 to 5 days in the hot phase, plus a bokashi bucket for cooked food and meat. They produce 300 to 400 litres of finished compost a year and use it on vegetable beds. Time: about 30 minutes a week in the growing season, less in winter. The system fits because they enjoy the work and they use the compost.

### Household C: A flat with a balcony, two adults, no garden

Waste audit: kitchen scraps 2 kg per week, no garden waste, cooked food 1 kg per week. System: a worm bin on the balcony for fruit and vegetable scraps, and a bokashi bucket under the sink for cooked food. Fermented bokashi is buried in a large soil-factory container on the balcony and in a community garden plot they share with a neighbour. They produce about 20 litres of castings a year and enrich the soil in their pots and the community plot. Time: about 10 minutes a week. The system fits because it needs no garden and no outdoor pile.

---

## Glossary

- **Aerobic:** With oxygen. Aerobic decomposition is the process that makes good compost.
- **Anaerobic:** Without oxygen. Anaerobic decomposition produces smells and is what you are trying to avoid in a compost pile.
- **Bokashi:** A method of fermenting food waste in a sealed, acidic bucket using bokashi bran.
- **Browns:** Carbon-rich, dry materials such as leaves, straw, and cardboard.
- **C:N ratio:** The ratio of carbon to nitrogen in a material, by weight. A pile's target starting ratio is about 25:1 to 30:1.
- **Castings:** The excrement of worms; the finished product of vermicomposting. Also called worm castings or vermicompost.
- **Curing:** The cool, slow finishing stage after the hot phase, lasting 4 to 8 weeks.
- **Greens:** Nitrogen-rich, moist materials such as grass clippings, kitchen scraps, and manure.
- **Hot composting:** Composting in a large, managed pile that reaches 55 to 65°C and finishes in weeks.
- **Leachate:** Liquid that drains from a compost pile, worm bin, or bokashi bucket. It is not the same as finished compost tea and should be diluted heavily or discarded.
- **Mesophilic:** Working at moderate temperatures (about 20 to 45°C).
- **Thermophilic:** Working at high temperatures (about 45 to 70°C); the microbes that drive the hot phase.
- **Vermicomposting:** Composting with worms, usually red wigglers, in a bin.

## Appendix: Materials Quick Reference

**Always compost (in a pile or worm bin):** Fruit and vegetable scraps, coffee grounds and filters, tea bags (check for plastic), eggshells (crushed), dry leaves, straw, shredded cardboard and newspaper, grass clippings (in thin layers), soft garden prunings (chopped), seaweed (rinsed).

**Compost with care:** Manure (mix well, let it heat), weeds (only without mature seeds, or in a hot pile), citrus and onions (small amounts in a worm bin; fine in a pile), bread, rice, and pasta (small amounts, buried).

**Compost by bokashi only (not in an open pile or worm bin):** Cooked food, meat, fish, dairy, fats, and oils, small bones.

**Never compost at home:** Pet waste from dogs or cats, human waste, diseased plants (unless you are certain your pile holds heat long enough), treated or painted wood, glossy or plastic-coated paper, charcoal ash from treated wood or briquettes with additives, and any material prohibited by your local rules.

**If in doubt, leave it out.** A pile that contains only materials you are sure about will work better than a pile that contains a questionable item. You can always add a material later, once you have checked it.

---

## A Final Word

Composting is a skill, and like any skill it improves with practice. Your first pile may not heat. Your first worm bin may be overfed. Your first bokashi bucket may smell wrong. That is normal. The log, the flowcharts, and the seasonal calendar in this manual exist so that each pile teaches you something, and the next pile is better. Start with one method, keep it simple, and keep going. In a year, you will have a system that runs on minutes a week, a garden with better soil, and a bin with less in it. That is the whole point.

*This manual is for general education only. It is not professional, legal, medical, or agronomic advice. Check your local rules, handle compost with gloves, wash your hands after handling it, and seek qualified local advice if you are unsure about any material or method. Results vary with climate, materials, space, and effort, and no specific yield, saving, or garden result is guaranteed.*
