# Protect Your Family — Companion Workbook

**For use with the course "Protect Your Family: Wills, Trusts & Estate Planning Essentials" (FIN-07).**

## IMPORTANT DISCLAIMER — PLEASE READ FIRST

This workbook is **general education only. It is not legal advice, tax advice, or financial advice, and it does not create an attorney–client relationship.**

The exercises, worksheets, checklists, and templates in this workbook are educational planning tools. They help you gather information, organize your wishes, and prepare for a meeting with a licensed estate attorney in your state. They are **not legal documents** and must not be presented or used as a will, trust, power of attorney, or health care directive. Estate documents must be prepared and executed according to the laws of your state, and reviewed by a licensed attorney before you sign them. Laws vary by state and country, and they change over time.

Do not write passwords in this workbook if you store it where others can see it. Keep the completed workbook with your estate documents, in a safe place, and tell your executor where it is.

**How to use this workbook:** work through it module by module alongside the course. Print it, or copy each worksheet into your own notes. Bring the completed workbook to your attorney — it is designed to make that meeting faster, cheaper, and more productive.

---

## Worksheet 1 — The Five Questions (Course Module 1)

Answer each question in one or two sentences. Your answers will change as you learn; write your first answers now and revise them at the end of the course.

1. Who should get what? (Who receives your property, and in what shares?)
   - Answer: ___________________________________________________________________________

2. Who should be in charge? (Who carries out your wishes and settles your affairs?)
   - Answer: ___________________________________________________________________________

3. Who should raise your children if both parents die?
   - Answer: ___________________________________________________________________________

4. Who should decide for you if you cannot decide for yourself — for money, and for medical care?
   - Financial: ___________________________________________________________________________
   - Medical: ___________________________________________________________________________

5. How do you want your wishes carried out — what matters most to you: speed, privacy, low cost, or simplicity?
   - Answer: ___________________________________________________________________________

---

## Worksheet 2 — Estate Checklist

Check off each item as you complete it. This is your master progress list for the whole plan.

### People — choose and ask each person before you name them

- [ ] Executor chosen: ____________________________  Asked and agreed: [ ]
- [ ] Alternate executor chosen: ____________________________  Asked and agreed: [ ]
- [ ] Guardian for minor children chosen: ____________________________  Asked and agreed: [ ]
- [ ] Alternate guardian chosen: ____________________________  Asked and agreed: [ ]
- [ ] Trustee for children's trust chosen: ____________________________  Asked and agreed: [ ]
- [ ] Alternate trustee chosen: ____________________________  Asked and agreed: [ ]
- [ ] Financial agent (power of attorney) chosen: ____________________________  Asked and agreed: [ ]
- [ ] Alternate financial agent chosen: ____________________________  Asked and agreed: [ ]
- [ ] Health care agent chosen: ____________________________  Asked and agreed: [ ]
- [ ] Alternate health care agent chosen: ____________________________  Asked and agreed: [ ]

### Documents

- [ ] Will prepared and reviewed by a licensed attorney in my state
- [ ] Will signed correctly (witnesses / notary as my state requires)
- [ ] Revocable living trust prepared (if my attorney recommends one)
- [ ] Trust signed correctly
- [ ] Pour-over will prepared and signed (if I have a trust)
- [ ] Durable financial power of attorney signed
- [ ] Health care directive (living will + health care proxy) signed
- [ ] HIPAA authorization signed
- [ ] Letter of intent written for each child

### Beneficiaries and titles

- [ ] Life insurance beneficiary reviewed and updated
- [ ] Retirement account (401(k) / IRA) beneficiaries reviewed and updated
- [ ] Bank account POD designations reviewed and updated
- [ ] Investment account TOD designations reviewed and updated
- [ ] Contingent beneficiary named on every account that allows one
- [ ] Per stirpes selected where I intend it (confirmed with the institution or attorney)
- [ ] House deed checked — I know how the house is titled
- [ ] Vehicle titles checked

### Funding and storage

- [ ] Trust funded (if I have a trust): house deed recorded in the trust's name
- [ ] Trust funded: bank and investment accounts retitled
- [ ] Original will stored safely; executor told where it is
- [ ] Copies given to executor, trustee, and health care agent
- [ ] Document Organizer completed and stored with the will
- [ ] "First Steps for My Family" page completed

### Family conversations

- [ ] Executor told they were named and where documents are kept
- [ ] Guardian told they were named; letter of intent shared
- [ ] Trustee told they were named
- [ ] Adult children told the broad outline of the plan
- [ ] Attorney consultation booked: date ____________________

### Keeping it current

- [ ] Calendar reminder set: review beneficiary designations in 12 months (date: __________)
- [ ] Calendar reminder set: full plan review in 3 years (date: __________)
- [ ] Plan to review after any birth, death, marriage, divorce, move, or major purchase

---

## Worksheet 3 — Document Organizer

Fill in every line you can. Your executor will use this to find what they need without hunting. Keep it with your will and update it once a year. Do **not** write account passwords here — note where the passwords are kept instead (for example, "in my password manager; my executor has the master password location").

### Personal information

- Full legal name: ____________________________
- Spouse / partner full legal name: ____________________________
- Date of birth: ____________________________
- Address: ____________________________
- Phone: ____________________________  Email: ____________________________

### Key people

- Attorney (name, firm, phone, email): ____________________________________________________
- Financial professional / accountant: ____________________________________________________
- Insurance agent: ____________________________________________________
- Executor: ____________________________ Phone: ____________________________
- Trustee: ____________________________ Phone: ____________________________
- Guardian: ____________________________ Phone: ____________________________
- Financial agent: ____________________________ Phone: ____________________________
- Health care agent: ____________________________ Phone: ____________________________

### Where the documents are

- Original will kept at: ____________________________
- Trust documents kept at: ____________________________
- Powers of attorney kept at: ____________________________
- Health care directive kept at: ____________________________
- Safe / safe deposit box location and access: ____________________________

### Real estate

| Property | Address | How titled | Approximate value | Mortgage balance | Mortgage lender |
|---|---|---|---|---|---|
| 1 | | | | | |
| 2 | | | | | |
| 3 | | | | | |

### Bank and investment accounts

| Institution | Account type | Account owner(s) | POD / TOD beneficiary | Approximate balance |
|---|---|---|---|---|
| | | | | |
| | | | | |
| | | | | |
| | | | | |

### Retirement accounts

| Institution | Account type (401(k), IRA, etc.) | Primary beneficiary | Contingent beneficiary | Approximate balance |
|---|---|---|---|---|
| | | | | |
| | | | | |
| | | | | |

### Life insurance and annuities

| Company | Policy type | Face amount / value | Primary beneficiary | Contingent beneficiary |
|---|---|---|---|---|
| | | | | |
| | | | | |

### Debts (other than mortgages listed above)

| Creditor | Type of debt | Balance | Joint or individual? | Monthly payment |
|---|---|---|---|---|
| | | | | |
| | | | | |
| | | | | |

### Vehicles

| Vehicle | Year / make / model | How titled | Approximate value | Loan balance |
|---|---|---|---|---|
| | | | | |
| | | | | |

### Business interests

- Business name: ____________________________  Type: ____________________________
- My ownership share: ____________________________
- Business partner(s): ____________________________
- Buy-sell agreement in place? Yes / No
- Where business records are kept: ____________________________
- Who should run the business if I cannot: ____________________________

### Digital assets

- Password manager used: ____________________________
- How my executor can access it: ____________________________
- Important online accounts (email, photos, business, cryptocurrency): ____________________________
- Cryptocurrency recovery information stored at: ____________________________ (do not write seed phrases here — note the location only)

### Other important items

- Location of birth certificates, marriage certificate, Social Security cards: ____________________________
- Location of tax returns: ____________________________
- Burial / funeral wishes (if any, also state them in a separate document your family can find immediately — not only in the will): ____________________________

---

## Worksheet 4 — Beneficiary Worksheet (Course Module 5)

List **every** account and policy with a beneficiary designation. For each, record what is currently named, then what you intend to name after speaking with your attorney. Ask each institution for written confirmation when you change a designation, and keep the confirmations with your estate documents.

| Account / policy | Institution | Current primary beneficiary | Current contingent beneficiary | Intended primary beneficiary | Intended contingent beneficiary | Per stirpes? | Confirmation received? |
|---|---|---|---|---|---|---|---|
| Life insurance | | | | | | | |
| 401(k) / 403(b) | | | | | | | |
| IRA | | | | | | | |
| Bank account (POD) | | | | | | | |
| Investment account (TOD) | | | | | | | |
| Annuity | | | | | | | |
| HSA | | | | | | | |
| Other | | | | | | | |

**Five-mistake check (see Module 5). For each account, answer yes or no:**

1. Is a former spouse still named anywhere? Yes / No — If yes, which account? ____________________________
2. Is a minor child named directly as a beneficiary anywhere? Yes / No — If yes, which account? ____________________________
3. Is the contingent beneficiary blank anywhere? Yes / No — If yes, which account? ____________________________
4. Does any designation point in a different direction from my will? Yes / No — If yes, which account? ____________________________
5. Is "my estate" named as a beneficiary anywhere? Yes / No — If yes, which account? ____________________________

**Notes for my attorney about beneficiary designations:**
___________________________________________________________________________________________
___________________________________________________________________________________________

---

## Worksheet 5 — Will Planning Worksheet (Course Module 2)

Complete this before your attorney meeting. It is the starting point for your will — not a will itself.

### Executor

- Executor: ____________________________  Alternate: ____________________________
- Why this person: ___________________________________________________________________________

### Guardian (for minor children)

- Guardian: ____________________________  Alternate: ____________________________
- Why this person: ___________________________________________________________________________
- Should the guardian and the trustee be the same person? Yes / No — Why: ____________________________

### Trustee for children's trust

- Trustee: ____________________________  Alternate: ____________________________
- Distribution plan (choose one and fill in the ages or stages):
  - [ ] All at age ______
  - [ ] In stages: ______% at age ______, ______% at age ______, remainder at age ______
  - [ ] Trustee discretion for health, education, maintenance, and support, with final distribution at age ______
- If a child dies before receiving their full share, their share should go to:
  - [ ] Their own children (per stirpes)
  - [ ] My surviving children
  - [ ] Other: ____________________________

### How should property be divided?

- To my spouse (if surviving): ______%
- To my children, equally: ______% each / ______% total
- To others (name each person and percentage):
  - ____________________________ ______%
  - ____________________________ ______%
- To charity (full legal name and percentage):
  - ____________________________ ______%
- Total must equal 100%: ______%

### Specific bequests (items that go to a named person regardless of the percentages)

| Item | To whom |
|---|---|
| | |
| | |
| | |
| | |

### If a beneficiary dies before me

- Their share should go to: [ ] Their children (per stirpes) / [ ] My other beneficiaries / [ ] Other: ____________________________

### Things I want my attorney to know about my family

- (For example: a child with a disability, an estrangement, a second marriage, a business, property in another state, a large debt.)
___________________________________________________________________________________________
___________________________________________________________________________________________
___________________________________________________________________________________________

---

## Worksheet 6 — Will vs. Trust Comparison (Course Module 4)

Answer these questions and take the completed worksheet to your attorney. There is no score — the answers help your attorney recommend the right structure for you.

1. How many states do I own real estate in? ______
   - Property states: ____________________________
2. Do I value privacy (keeping the details out of public probate records)? Yes / No / Not sure
3. Do I want my family to receive property quickly, without waiting for probate? Yes / No / Not sure
4. Do I want a plan that manages my property if I become incapacitated? Yes / No / Not sure
5. Is my family situation complicated (blended family, child with a disability, business, large estate)? Yes / No — Details: ____________________________
6. Are most of my assets already passing by beneficiary designation (retirement accounts, life insurance)? Yes / No
7. Am I willing to do the funding work — retitling the house and accounts into a trust — and keep it funded when I buy new property? Yes / No / Not sure
8. Is keeping upfront costs low more important to me than avoiding probate? Yes / No

**My leaning before speaking with an attorney:** [ ] Will alone is probably enough / [ ] A trust is probably worth discussing / [ ] I genuinely do not know yet

**Questions for my attorney about wills vs. trusts:**
___________________________________________________________________________________________
___________________________________________________________________________________________

A blank comparison table is also provided in the templates folder (`templates/will-trust-comparison.md`) so you can compare the two options side by side with your attorney.

---

## Worksheet 7 — Medical Wishes (Course Module 3)

Write your wishes in plain language. This is a starting point for your living will and your conversation with your health care agent — it is not a health care directive itself. Your attorney will prepare the formal document in the form your state requires.

- My health care agent: ____________________________  Alternate: ____________________________
- My financial agent: ____________________________  Alternate: ____________________________
- My general wishes about life-sustaining treatment if I am terminally ill and cannot communicate:
  ___________________________________________________________________________________________
- My wishes about resuscitation:
  ___________________________________________________________________________________________
- My wishes about organ donation:
  ___________________________________________________________________________________________
- People I authorize to receive my medical information (HIPAA authorization):
  ___________________________________________________________________________________________
- My doctor's name and phone: ____________________________
- Allergies, conditions, and medications my agent should know about:
  ___________________________________________________________________________________________
- Anything else my health care agent should know:
  ___________________________________________________________________________________________

**Have I given a copy of my health care directive to my doctor?** Yes / No
**Have I given a copy to my health care agent?** Yes / No
**Does my agent know where the original is kept?** Yes / No

---

## Worksheet 8 — Letter of Intent to the Guardian

Write one letter per child, or one letter covering all your children. Update it once a year. This letter is personal, not legal — write it in your own voice.

**To my children's guardian:**

- About each child — personality, strengths, fears, what comforts them:
  ___________________________________________________________________________________________
  ___________________________________________________________________________________________
- Daily routines — school, meals, bedtime, activities, faith practices:
  ___________________________________________________________________________________________
  ___________________________________________________________________________________________
- Medical needs — doctors, medications, allergies, conditions:
  ___________________________________________________________________________________________
  ___________________________________________________________________________________________
- School — where they attend, learning needs, hopes for their education:
  ___________________________________________________________________________________________
  ___________________________________________________________________________________________
- People who matter — grandparents, friends, and family members, and how I would like those relationships to continue:
  ___________________________________________________________________________________________
  ___________________________________________________________________________________________
- My values and hopes for my children:
  ___________________________________________________________________________________________
  ___________________________________________________________________________________________
- Practical information — where school and medical records are kept, who to call:
  ___________________________________________________________________________________________

Signed: ____________________________  Date: ____________________________

---

## Worksheet 9 — Attorney-Review Checklist

Take this checklist to your first attorney meeting. Check each item as you discuss it, and write the attorney's answer in your own words.

### Before the meeting

- [ ] Workbook completed as far as I can (Worksheets 1–8)
- [ ] Asset and debt list prepared with approximate values
- [ ] Full legal names, addresses, and phone numbers for every person I want to name
- [ ] Copies of any current will, trust, or powers of attorney
- [ ] Deed to my house and titles to my vehicles
- [ ] List of beneficiary designations (Worksheet 4)
- [ ] Written questions prepared (below)

### Questions to ask

- [ ] Is a will alone enough for my situation, or should I consider a revocable living trust? Attorney's answer: ____________________________
- [ ] What does probate typically cost and how long does it take in my state for an estate like mine? Answer: ____________________________
- [ ] What are the witness and notarization requirements in my state for a will, a power of attorney, and a health care directive? Answer: ____________________________
- [ ] Does my state recognize transfer-on-death deeds for real estate? Answer: ____________________________
- [ ] Does my state have an estate or inheritance tax, and at what threshold? Answer: ____________________________
- [ ] Is my state a community property state, and how does that affect my plan? Answer: ____________________________
- [ ] How should my beneficiary designations be set up — and should any name a trust instead of a person? Answer: ____________________________
- [ ] Do I need a special needs trust or other protective trust for any child? Answer: ____________________________
- [ ] What should my documents say about digital assets in my state? Answer: ____________________________
- [ ] What is your fee for the plan you recommend, and what does it include? Answer: ____________________________
- [ ] Will you help with funding the trust, and is that included in the fee? Answer: ____________________________
- [ ] How should I store the originals, and will your office keep copies? Answer: ____________________________

### My additional questions

1. ___________________________________________________________________________________________
2. ___________________________________________________________________________________________
3. ___________________________________________________________________________________________

### After the meeting

- [ ] I understand the plan my attorney recommends and why
- [ ] I have the fee in writing
- [ ] Next appointment / draft review date: ____________________________
- [ ] Signing date: ____________________________

---

## Worksheet 10 — Trust Funding Checklist (Course Module 4)

Use this only if your attorney recommends a revocable living trust. A trust controls only the property transferred into it. Check each item as the transfer is confirmed — not when it is started.

- [ ] House deed recorded transferring the house into the trust (county: __________, recording date: __________)
- [ ] Vacation / rental property deed(s) recorded in the trust's name
- [ ] Bank account(s) retitled into the trust's name
- [ ] Investment / brokerage account(s) retitled into the trust's name
- [ ] Beneficiary designations updated as my attorney advised
- [ ] Business interest transferred into the trust (if my attorney advised it)
- [ ] New property purchased after the trust created — transferred into the trust at purchase
- [ ] Confirmation received from each bank / institution that the retitling is complete
- [ ] Pour-over will signed, so anything left outside the trust is caught at death

**Funding review date (check once a year that new accounts and property are in the trust):** ____________________________

---

## Family Conversation Scripts (Course Module 9)

Use these as starting points. Speak in your own words. The goal is clarity and calm — not a formal announcement.

### Script 1 — Telling someone you have named them executor or trustee

"I've been working on an estate plan, and I'd like you to be my executor [or trustee]. That means if something happens to me, you'd be the person who carries out my wishes, pays the bills, and makes sure everything goes where I intend. I've written down where all the documents and accounts are, and my attorney's name is __________. I'd like to give you a copy. Is that something you're willing to do? You don't have to decide today — but I'd like to know you're comfortable with it before I sign anything."

### Script 2 — Telling someone you have named them guardian

"We've named you as guardian for [children's names] in our will. That means if something happened to both of us, you'd be the person who raises them. We chose you because [give the real reason — your values, your stability, the relationship you have with the children]. We've written a letter explaining the children's routines, medical needs, and schooling, and we've set up a trust so the money for their care is managed separately. Would you be willing to do this? It's a big ask, and I want you to be honest with me."

### Script 3 — Telling adult children the broad outline

"I want you to know that we've made an estate plan. [Name] is the executor, and the documents are kept at [location]. We've made provision for [guardian / trust / etc.], and our attorney is [name, phone]. I'm telling you now so nothing is a surprise later. You don't need to worry about the details — I just want you to know the plan exists and who to call."

### Script 4 — Explaining an unequal distribution

"I want to explain a decision in our plan so you hear it from me. [Name] will receive [describe the difference] because [give the real reason — for example, 'we paid for your college and your sister's down payment, and this equalizes the help you each received,' or 'your brother's trust is structured differently because of his disability benefits']. We love you equally, and this is not about favoritism. It's about [the reason]. I've written this down in a letter kept with the will, so it's clear."

### Script 5 — Telling a family member they were not chosen as guardian or executor

"I want you to know about a decision we made, because I respect you and I don't want you to learn it later. We've named [name] as [guardian / executor] because [give the real reason — for example, 'they live nearby and the children know them well,' or 'they have experience managing finances']. This isn't a judgment about you — it's about who is best placed to do this particular job. You matter enormously to our children, and we've written down how we hope you'll stay part of their lives."

---

## "First Steps for My Family" — One-Page Summary

Complete this page, keep it where your family can find it immediately, and tell your family where it is. Do not keep this as the only record — it is a pointer to the full plan.

- My full legal name: ____________________________
- My executor is: ____________________________  Phone: ____________________________
- My attorney is: ____________________________  Phone: ____________________________
- My will is kept at: ____________________________
- My trust documents are kept at: ____________________________
- My powers of attorney and health care directive are kept at: ____________________________
- My Document Organizer (Worksheet 3) is kept at: ____________________________
- My life insurance company and policy number: ____________________________
- My bank(s): ____________________________
- Funeral / burial wishes (if any): ____________________________
- People to notify first: ____________________________
- Anything else my family needs to know right away:
  ___________________________________________________________________________________________

---

## My 30/60/90-Day Plan (Course Module 9)

**Days 1–30 — Organize and book**
- [ ] Worksheets 1–4 completed
- [ ] Attorney consultation booked: date ____________________
- [ ] Beneficiary designations reviewed

**Days 31–60 — Meet, draft, sign**
- [ ] Attorney meeting held: date ____________________
- [ ] Drafts reviewed and questions asked
- [ ] Documents signed correctly
- [ ] Copies given to executor, trustee, and health care agent

**Days 61–90 — Fund, store, tell**
- [ ] Trust funded (if applicable) — every item on Worksheet 10 confirmed
- [ ] Beneficiary confirmations received in writing
- [ ] Originals stored; family told where they are
- [ ] Letter of intent written
- [ ] Family conversations held
- [ ] Calendar reminders set: beneficiary review in 12 months; full review in 3 years

---

*This workbook is general education only and is not legal, tax, or financial advice. Estate documents require a licensed estate attorney in your state. Laws vary by state and change over time. Have all documents reviewed by a licensed attorney before signing.*

