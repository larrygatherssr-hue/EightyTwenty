# Protect Your Family: Wills, Trusts & Estate Planning Essentials

**A plain-English course for parents and homeowners who want their children, their property, and their wishes protected — without jargon, intimidation, or guesswork.**

---

## IMPORTANT DISCLAIMER — PLEASE READ FIRST

This course is **general education only. It is not legal advice, tax advice, or financial advice, and it does not create an attorney–client relationship.**

Estate planning law varies significantly by state and country, and it changes over time. Wills, trusts, powers of attorney, and health care directives must be prepared and executed according to the laws of the state where you live — and, for real estate, the state where the property is located. A document that is valid in one state may be invalid, incomplete, or interpreted differently in another.

**Do not use this course as a substitute for a licensed estate planning attorney in your state.** Use it to understand your options, ask better questions, organize your information, and have a productive, lower-cost conversation with a qualified attorney. Before you sign any estate document, have it reviewed by a licensed attorney in your state. If your situation involves a blended family, a child with a disability, a business, property in more than one state, significant debt, a large estate, or a dispute among family members, professional advice is especially important.

This course does **not** provide fill-in legal forms and does not present any document in this course as a valid will, trust, or power of attorney. The checklists, comparison guides, worksheets, and scripts in this course and in the companion workbook are educational planning tools. They help you gather information and prepare for a meeting with an attorney; they are not legal documents.

Costs, fees, timeframes, and tax figures in this course are **illustrative examples** created to teach concepts. They are labelled as examples. Actual probate fees, attorney fees, court timelines, and tax rules depend on your state, your estate, and the law in effect at the time. Always confirm current figures with a licensed attorney or tax professional in your state.

If you are facing an urgent situation — a loved one who has died, a family member who has become incapacitated, or a medical emergency — contact an estate attorney promptly rather than working through this course first.

---

## How to Use This Course

This course is designed as a video course companion text of 9 modules and about 7 hours of teaching. You can read it straight through, or work through one module at a time and complete the matching workbook exercises before moving on.

- **Each module ends with Action Steps.** Do them before moving on. Estate planning fails when it stays theoretical.
- **The companion workbook (`workbook.md`) is your working file.** Print it or copy it into your own notes. Fill in the Estate Checklist, the Document Organizer, the Beneficiary Worksheet, and the Attorney-Review Checklist as you go.
- **The templates folder contains reusable tools:** a will-versus-trust comparison guide, a beneficiary and document organizer (CSV), and an estate checklist (CSV).
- **Suggested pace:** one module per week for nine weeks, or two modules per weekend for a month. Module 9 gives you a 30/60/90-day plan to finish.
- **Bring this course to your attorney.** The Attorney-Review Checklist in the workbook is designed to be handed to a lawyer at your first meeting. It will save you time and money because you will arrive organized.

**Your outcome at the end of this course:** you will understand what a will does and does not do, how a revocable living trust works, how powers of attorney and health care directives protect you during your lifetime, how beneficiary designations can override a will, how probate works and how families commonly reduce its cost and delay, how to choose guardians for minor children, and exactly what to bring to an attorney so your plan gets finished — not just started.

---

## Table of Contents

- Module 1 — Estate Planning Foundations: What Happens If You Do Nothing
- Module 2 — Wills: The Document Every Parent Needs
- Module 3 — Powers of Attorney and Health Care Directives: Protecting Yourself While You Are Alive
- Module 4 — Revocable Living Trusts: How They Work and When They Make Sense
- Module 5 — Beneficiaries: The Designations That Override Your Will
- Module 6 — Probate, Titling, and Keeping Things Out of Court
- Module 7 — Protecting Children and Dependents
- Module 8 — Real Life Is Complicated: Blended Families, Businesses, and Property in More Than One State
- Module 9 — Putting Your Plan Together: Attorney Review, Funding, Storage, and the Family Conversation
- Appendix A — Glossary in Plain English
- Appendix B — Your First 30/60/90 Days
- Appendix C — State-Variation Notes: What to Ask About Where You Live

---

# Module 1 — Estate Planning Foundations: What Happens If You Do Nothing

**What you will learn:** what an estate plan actually is, what happens when someone dies without a will, what probate is in plain English, and why delay is itself a decision — one your family pays for.

## 1.1 What "estate planning" really means

An estate plan is not one document. It is a small set of decisions, written down in the right legal form, that answer five questions:

1. **Who gets what?** Which people — or charities — receive your property, and in what shares?
2. **Who is in charge?** Who carries out your wishes, pays your bills, and closes out your affairs?
3. **Who raises your children?** If your children are minors, who becomes their guardian?
4. **Who decides for you if you cannot decide for yourself?** If illness or injury leaves you unable to manage money or make medical decisions, who steps in?
5. **How do your wishes get carried out with the least cost, delay, and family conflict?**

That is the whole job. A will answers questions 1, 2, and 3. A trust can answer 1, 2, and 5, and sometimes 4. Powers of attorney and health care directives answer question 4. Beneficiary designations answer question 1 for specific accounts. No single document does all five jobs well, which is why a complete plan is a set of documents that work together.

"Estate" is a legal word for everything you own at death, minus what you owe: your home, bank accounts, retirement accounts, life insurance, vehicles, a business, personal belongings, and digital assets. You have an estate whether you think of yourself as wealthy or not. If you own a home, have children, or have a retirement account, you have enough at stake to plan.

## 1.2 What happens if you die without a will

If you die without a valid will, you are said to die "intestate." That does not mean the state takes your property. It means **your state's intestacy law writes a will for you** — and the state's version may not match what you would have chosen.

Every state has its own intestacy formula, but the pattern is similar in most states:

- If you are married with children, your spouse and your children usually share the estate in proportions set by state law. In some states the spouse receives a fixed share and the children share the rest. In others the spouse receives everything only if all the children are also the spouse's children.
- If you are unmarried with children, your children usually inherit in equal shares.
- If you have no spouse and no children, the law moves outward: parents, then siblings, then more distant relatives.
- Unmarried partners, stepchildren you never adopted, close friends, and charities generally receive nothing under intestacy law, no matter how close the relationship was or what you told people you wanted.

Three consequences follow that surprise most families:

**First, you lose the choice of guardian.** If both parents of minor children die, a court chooses the guardian. The court will listen to family members, but it is not bound by a wish you never wrote down in a valid document. Two sets of grandparents can end up in a painful court dispute that a single paragraph in a will would have prevented.

**Second, you lose the choice of who is in charge.** The court appoints an administrator — usually a close relative, but not necessarily the person you would have picked, and not necessarily the person best at the job. That person must report to the court, post a bond in some states, and follow court procedures that a named executor in a will can often avoid.

**Third, minor children inherit outright at the age of adulthood.** Under intestacy, a child who inherits typically receives the money outright at 18 (or 21, depending on the state) with no strings attached. An 18-year-old receiving a life insurance payout or a share of a house sale is a common outcome of dying without a plan. Most parents, given the choice, would prefer the money to be held and managed for the child until an older age, with a trusted person controlling distributions for education, housing, and living expenses. That requires a will with a trust provision, or a separate trust — it does not happen automatically.

## 1.3 Probate in plain English

Probate is the court-supervised process of settling a deceased person's estate: proving the will is valid (if there is one), paying debts and taxes, and distributing what remains to the people entitled to receive it.

Probate is not a punishment, and it is not always terrible. In many states, a simple estate with a clear will moves through probate in a matter of months with modest cost. But probate has three features families dislike:

1. **It takes time.** Even a straightforward probate commonly takes several months, and a contested or complicated one can take a year or more. During that time, property generally cannot be sold or distributed until the court authorizes it, and the family may be waiting for funds they need.
2. **It costs money.** Court fees, attorney fees, executor fees, appraisal fees, and bond premiums all come out of the estate before anyone inherits. The amount varies widely by state and by the size and complexity of the estate.
3. **It is public.** Probate filings are generally public records. The will, the inventory of assets, and the list of beneficiaries can be seen by anyone who looks.

Understanding probate matters because most of the planning in this course is, at its core, about deciding how much of your estate should go through probate, how much should pass outside it (through beneficiary designations and trusts), and how to make the probate that does happen as simple as possible.

### Worked example: an illustrative probate cost and timeline

The following is a **hypothetical, illustrative example** to teach the concepts. It is not a prediction for any real estate. Actual costs depend on state law, local court fees, attorney billing, and the complexity of the estate.

**The family:** Maria and James, married, two children aged 7 and 10. They own a home worth $350,000 with a $200,000 mortgage, have $60,000 in bank and retirement accounts, two cars, and $250,000 of term life insurance on James. James dies suddenly without a will.

**What happens:**

- The house, the bank accounts, and the cars are in James's name alone or in joint names without a right of survivorship or a transfer-on-death designation. Those assets must go through probate.
- The life insurance passes directly to Maria as the named beneficiary. It does **not** go through probate — beneficiary designations pass outside probate. That $250,000 is available to Maria relatively quickly, which is why the beneficiary section of this course (Module 5) matters so much.
- The retirement account also passes to its named beneficiary outside probate.
- The probate estate — the house equity ($150,000), the bank accounts, and the cars — must be inventoried, valued, and distributed under the state's intestacy formula. The court appoints an administrator, creditors are notified, and the house cannot be sold until the court authorizes it.

**Illustrative cost and time:** Suppose the court and attorney costs for this probate total $9,000 and the process takes 11 months. That is $9,000 that does not go to Maria and the children, and 11 months during which the house sale — and the equity in it — is delayed. If the family had a will naming Maria as executor and naming a guardian for the children, the process would still involve probate for the house and accounts, but the court would not have to decide who is in charge or who raises the children, and the distribution would follow James's wishes rather than the state's formula. If the house had been titled in a revocable living trust, the house might have passed to Maria without probate at all.

The lesson is not that probate is always ruinous. It is that **the same family, with the same assets, can have a very different experience depending on whether the paperwork was done in advance** — and that the cost of doing nothing is paid later, by the people left behind, at the worst possible time.

## 1.4 The five documents of a basic plan

Most families' plans are built from these five pieces. You will meet each one in detail in later modules.

| Document | What it does | When it works |
|---|---|---|
| Last will and testament | Names who inherits, who is executor, and who is guardian of minor children | After death, through probate |
| Revocable living trust | Holds property for your benefit during life and passes it to beneficiaries after death, often without probate | During life and after death |
| Financial power of attorney | Names someone to handle money, bills, and property if you cannot | During your lifetime, if you become unable to act |
| Health care directive (living will + health care proxy) | States your medical wishes and names someone to make medical decisions if you cannot | During your lifetime, if you cannot communicate |
| Beneficiary designations | Name who receives specific accounts and policies directly | After death, outside probate |

A complete plan also includes a list of where everything is — accounts, policies, passwords, debts, and key contacts — so the person in charge is not hunting for information while grieving. The Document Organizer in the workbook is built for exactly that.

## 1.5 Why people delay — and how to get past it

In conversations with families, the reasons for delay are remarkably consistent, and none of them is about laziness:

- **"Lawyers are expensive."** Estate planning can cost real money, but the cost of not planning — probate fees, delay, family disputes — is usually paid from the estate anyway, and is often larger. This course teaches you how to arrive at an attorney organized, so the attorney's time is spent on legal judgment rather than on gathering basic facts. That reduces the bill.
- **"It feels morbid."** Thinking about death and incapacity is uncomfortable. Reframe it: this is not a document about dying. It is a document about protecting the people you love while you are alive to do it. Parents buy car seats and life insurance for the same reason.
- **"I don't know what I want."** Most people do know the big answers — who should raise the children, who should be in charge — but have never said them out loud. Module 2 and Module 7 give you the questions in order. The family conversation scripts in the workbook help you say them.
- **"My situation will change."** It will. That is why estate plans are meant to be reviewed and updated, not carved in stone. Module 9 gives you a review schedule: after a birth, death, marriage, divorce, move, or major purchase — and at least every three to five years.
- **"I started and got stuck."** Many people buy a form online, get halfway through, and stop because a question confuses them. That is normal. This course is designed so that the confusing questions arrive in order, with plain-English explanations, and the Attorney-Review Checklist tells you exactly which questions to take to a lawyer instead of guessing.

### Action steps — Module 1

1. Write down, in one sentence each, your answers to the five questions in section 1.1. Keep them in the workbook. They will change as you learn; that is fine.
2. List every account, policy, and property you own, with approximate values. Use the Document Organizer in the workbook.
3. Check your beneficiary designations on your retirement accounts and life insurance today. Write down who is named. Most people are surprised by what they find.
4. Tell one trusted person — your spouse, a sibling, a close friend — that you are working on an estate plan, and that you will tell them where the documents are kept when they are done.

### Common mistakes — Module 1

- Assuming a will avoids probate. It does not. A will **goes through** probate. It directs probate; it does not avoid it. Trusts and beneficiary designations are the tools that pass property outside probate.
- Assuming a spouse automatically inherits everything. In many states, a spouse with children shares the estate with the children under intestacy law. A will is what makes "everything to my spouse" happen.
- Assuming a verbal promise counts. It generally does not. "I told my sister she could have the house" is not an estate plan unless it is written in a valid legal document, executed the way your state requires.

---

# Module 2 — Wills: The Document Every Parent Needs

**What you will learn:** what a will does and does not do, how to choose an executor and a guardian, how to divide property fairly, what happens to specific items, and why a will drafted for your state — and reviewed by an attorney — matters more than a generic form.

## 2.1 What a will does

A valid last will and testament does four things:

1. **Names your beneficiaries** — who receives your property, and in what shares.
2. **Names your executor** (called a personal representative in some states) — the person who carries out the will, pays debts, and distributes property.
3. **Names a guardian for minor children** — the person who will raise them if both parents die.
4. **Can create a trust for minor children** — a testamentary trust, which holds a child's inheritance and pays it out over time under rules you set, managed by a trustee you choose.

A will takes effect only at death. It does nothing while you are alive. It can be changed or revoked at any time while you have the mental capacity to do so. That last point matters: a will is not a trap. If your wishes change, you update the will.

## 2.2 What a will does not do

- **It does not avoid probate.** A will is the document the probate court follows. Expect probate; plan to make it simple.
- **It does not control beneficiary designations.** If your life insurance names your brother as beneficiary, your brother receives the insurance even if your will says "everything to my spouse." Beneficiary designations override the will for that asset. Module 5 covers this in detail.
- **It does not control jointly owned property with a right of survivorship.** If you and your spouse own a house as joint tenants with right of survivorship, the surviving owner receives the house automatically at the other's death, regardless of what the will says.
- **It does not control property already in a trust.** Property transferred into a revocable living trust passes under the trust's terms, not the will.
- **It does not make medical or financial decisions while you are alive.** That is the job of powers of attorney and health care directives (Module 3).

Understanding these limits prevents the most common estate planning error: writing a careful will and assuming it controls everything. It controls the probate estate — the property owned in your name alone without a beneficiary designation. That is often the house, the cars, and personal belongings. The rest passes by other routes, and all the routes need to point in the same direction.

## 2.3 Choosing an executor

The executor's job is practical and demanding: file the will with the court, notify beneficiaries and creditors, inventory assets, pay valid debts and taxes, manage property during probate, and distribute what remains. It typically takes months and involves paperwork, phone calls, and judgment calls.

Choose someone who is:

- **Organized and responsible** with money and paperwork, and likely to follow through over many months.
- **Trustworthy** — they will have access to your accounts and your family's money.
- **Willing.** Ask the person first. Do not surprise someone with the job at the reading of the will.
- **Local enough** to deal with the court, the house, and the accounts, or able to hire local help. An executor who lives far away can still serve, but distance adds cost and delay.
- **Younger than you, or at least in good health,** so they are likely to outlive you.

Many people choose a spouse first and a sibling or adult child as backup. Naming a backup executor matters: if your first choice cannot serve, the court appoints someone. Name at least one alternate in the will.

**Can you name a professional?** Yes. Some people name a bank, a trust company, or an attorney as executor, especially for large or complicated estates. Professionals charge fees, but they are experienced and neutral. Ask an attorney what that would cost in your state before deciding.

**Should co-executors be named?** It is possible, but two people must agree on every decision, and both must sign many documents. For most families, one executor and one alternate is simpler than two co-executors.

## 2.4 Choosing a guardian for minor children

For parents, this is the hardest decision in the will and the most important one. A guardian is the person who raises your children if both parents die before the children reach adulthood.

Consider:

- **Values and parenting style.** Would this person raise your children roughly the way you would — in the same faith tradition, with the same attitude toward education, discipline, and daily life?
- **Stability.** A stable home, a stable relationship, and the ability to take on children financially and emotionally.
- **Location.** Would your children have to move far away, change schools, and lose their friends and community? Sometimes the best guardian is not the closest relative but the one whose home keeps the children's lives most intact.
- **Age and health.** A grandparent in their seventies may be loving but may not be the best choice to raise a toddler for fifteen years.
- **Willingness.** This is a life-changing ask. Have the conversation in person, before you sign anything. A person who says no is giving you useful information.
- **Relationship with the children.** A guardian the children already know and trust will make an unbearable transition less frightening.

**Name a backup guardian.** If your first choice cannot serve, the court decides. A backup in the will prevents that.

**Separate the guardian from the money manager if that fits your family.** The best person to raise your children is not always the best person to manage their inheritance. A will can name one person as guardian and a different person — or a professional trustee — as trustee of the children's trust. That separation is common and sensible: it lets each person do the job they are best at, and it creates a natural check on the money.

**Talk to the guardian about your wishes.** A short letter of intent — not a legal document, but a personal letter — can tell the guardian about each child's routines, medical needs, schooling, faith, and your hopes for them. The workbook includes a letter-of-intent template.

## 2.5 Dividing property: equal is not always identical

Most parents divide their estate equally among their children. Equal shares are simple and usually feel fair. But "equal" and "identical" are different things, and families sometimes need to think about:

- **Specific items.** The house, a family business, a car, jewelry, or a collection may go to one person while others receive an equal value in money. The will can name specific bequests ("my wedding ring to my daughter Ana") and leave the rest to be divided equally.
- **A child who received help during your lifetime.** If you paid for one child's college and another's down payment, do you want to equalize? Some parents do; some do not. Either answer is fine — but write it down and, if the difference is large, explain your reasoning in a short letter so the decision does not look like favoritism after you are gone.
- **A child with a disability.** Leaving money outright to a child who receives government benefits can disqualify them from those benefits. This is a situation where an attorney's advice is essential; a special needs trust may be appropriate. Do not improvise this.
- **Charitable gifts.** If you want to leave money to a charity, a school, or a house of worship, name the organization precisely — full legal name and, if you know it, its address — and state the amount or percentage.

**Percentages beat fixed dollar amounts.** A will that says "$50,000 to my sister and the rest to my children" can produce a surprise if the estate shrinks. A will that says "10 percent to my sister and 90 percent to my children" scales automatically. Attorneys generally prefer percentages for that reason.

### Worked example: dividing an estate with a will

**Hypothetical example for teaching purposes only.**

**The family:** Daniel and Priya, married, two children aged 9 and 12. Their probate estate is worth $480,000 after debts: a house with $280,000 of equity, $120,000 in bank accounts, $50,000 in vehicles and personal property, and $30,000 in an investment account with no beneficiary designation.

**Their will says:** everything to the surviving spouse; if neither survives, the estate is divided equally between the two children, held in a testamentary trust until each child reaches age 25, with distributions before then for health, education, maintenance, and support. The trustee is Priya's brother, and the guardian is Daniel's sister. Specific bequests: Daniel's father's watch to the older child, Priya's grandmother's necklace to the younger child.

**What happens if both parents die:** the executor sells the house, pays debts, and places $480,000 (minus probate costs) into the testamentary trust. The trustee manages the money and pays for the children's living expenses, schooling, and medical care. At age 25, each child receives their remaining half. If the trust holds $440,000 after costs, each child's share is $220,000. The guardian raises the children; the trustee manages the money. The specific items go to the named children regardless of the equal split.

**The contrast:** without a will, the same $480,000 would be distributed under intestacy law, the children would receive their shares outright at 18, and a court would choose the guardian and the administrator. The will does not avoid probate — but it changes who is in charge, who raises the children, when the children receive money, and who gets the family keepsakes.

## 2.6 How a will must be signed — and why the formalities matter

Every state has formal requirements for a valid will. The details vary, but most states require:

- The person making the will (the testator) to be at least 18 and of sound mind.
- The will to be in writing.
- The will to be signed by the testator.
- The signing to be witnessed by at least two people who are not beneficiaries under the will, who watch the testator sign.

Some states recognize handwritten (holographic) wills; most do not, or impose strict conditions. Some states recognize oral wills in narrow emergencies; most do not. **Do not rely on exceptions.** Have your will prepared and witnessed the way your state requires, and have an attorney confirm that the execution was done correctly. A will that fails on a technicality is the same as no will at all — and your family discovers the problem only after you are gone, when it cannot be fixed.

Keep the original will somewhere safe and tell your executor where it is. A copy is useful for reference, but the court generally needs the original. A safe deposit box that no one can open after your death is a poor choice unless your executor has access; a fireproof home safe, or your attorney's office, is often better. Module 9 covers storage in detail.

## 2.7 Updating your will

Review your will after any of these events, and at least every three to five years:

- Birth or adoption of a child, or a child reaching adulthood
- Marriage, divorce, or remarriage
- Death of a beneficiary, executor, guardian, or trustee
- A move to another state (wills are usually recognized across states, but execution requirements and property rules differ)
- Buying or selling a home or business
- A large change in wealth
- A change in your wishes

Updating usually means signing a new will that revokes the old one, or signing a codicil (an amendment) for a small change. Ask your attorney which is appropriate. Never write changes in the margins of a signed will — handwritten additions to a signed will can create confusion and may be invalid.

### Action steps — Module 2

1. Choose your executor and one alternate. Ask them if they are willing.
2. Choose a guardian and one alternate for minor children. Have the conversation.
3. Decide how you want your property divided — percentages, specific bequests, and what happens if a beneficiary dies before you.
4. Write your answers in the workbook's Will Planning Worksheet.
5. Take the worksheet to your attorney. Do not sign a will you prepared from a generic form without an attorney reviewing the execution requirements for your state.

### Common mistakes — Module 2

- Naming a guardian in a conversation but not in a will. Conversations do not bind a court.
- Choosing an executor because they are the oldest child, rather than the most organized and trustworthy person.
- Leaving everything to minor children outright, with no trust provision, so they receive it all at 18.
- Forgetting to name alternates for executor, guardian, and trustee.
- Using a will from another state after moving, without having it reviewed.

---

# Module 3 — Powers of Attorney and Health Care Directives: Protecting Yourself While You Are Alive

**What you will learn:** the documents that protect you if illness or injury leaves you unable to manage your money or make medical decisions, who to choose for each role, and what happens when these documents do not exist.

## 3.1 The problem these documents solve

Most estate planning conversations focus on death. But incapacity — a stroke, a serious accident, dementia, a long hospitalization — is more common than sudden death, and it creates an immediate practical problem: **bills still need to be paid, and medical decisions still need to be made, but you cannot do either.**

Without a financial power of attorney, no one has the legal authority to access your bank accounts, pay your mortgage, file your taxes, or manage your property on your behalf — not even your spouse, in many situations. A spouse can often access joint accounts, but accounts in your name alone are frozen to them. The family must ask a court to appoint a guardian or conservator, a process that takes time, costs money, and is public.

Without a health care directive, doctors and family members must guess at your wishes, and family members may disagree with each other about what you would have wanted. That disagreement, at a hospital bedside, is one of the most painful experiences a family can have.

These documents are inexpensive compared with a will or trust, and they are the ones you are most likely to actually use during your lifetime.

## 3.2 Financial power of attorney

A financial power of attorney (called a durable power of attorney in most states) is a document in which you (the principal) name another person (your agent, or attorney-in-fact) to handle financial matters for you.

**"Durable" is the key word.** A durable power of attorney remains effective if you become incapacitated. A non-durable power of attorney ends when you lose capacity — which is exactly when you need it most. In almost every case, you want a durable power of attorney. Confirm with an attorney in your state that the document you sign is durable under your state's law.

**What an agent can do** depends on what the document authorizes, but commonly includes: paying bills, managing bank and investment accounts, filing taxes, buying or selling property, handling insurance claims, and managing a business. You can grant broad authority or limit it to specific tasks. Most families grant broad authority to a trusted spouse or adult child, because a narrow document can leave the agent unable to handle an unexpected problem.

**When does it take effect?** Two designs exist:

- **Immediately effective:** the agent can act as soon as the document is signed. This is the most common design for spouses, because it is simple and there is no delay when it is needed. It requires complete trust, because the agent could act while you are still capable.
- **Springing:** the document takes effect only when a doctor certifies that you are incapacitated. This feels safer to some people, but it can cause delay — the agent must obtain a doctor's certification, and the bank or institution must accept it, before they can act. Ask an attorney which design fits your state and your family.

**Who to choose:** the same qualities as an executor — organized, trustworthy, good with money, willing, and available. Your agent will have broad access to your money. Choose carefully, and name a backup agent.

**Practical tip:** give a copy to your bank and ask the bank to confirm it will accept the document. Some banks have their own power-of-attorney forms and are slow to accept others. Discovering that problem during an emergency is the worst time. Confirm acceptance now, while you are healthy.

## 3.3 Health care directive: living will and health care proxy

A health care directive has two parts, and they do different jobs:

**The living will** states your wishes about medical treatment if you cannot communicate — for example, whether you want life-sustaining treatment continued if you are terminally ill or permanently unconscious, your wishes about resuscitation, and your wishes about organ donation. It speaks for you when you cannot speak.

**The health care proxy** (also called a health care power of attorney or medical power of attorney) names a person to make medical decisions for you when you cannot make them yourself. This person — your health care agent — talks to your doctors, consents to or refuses treatment, and makes sure your living will is followed.

Choose a health care agent who:

- Knows your values and wishes, and will advocate for them even under pressure from other family members or medical staff.
- Can stay calm in a hospital and make hard decisions.
- Lives close enough to be present, or can travel quickly.
- Is willing to serve. This is an emotional job. Ask.

Your health care agent does not have to be the same person as your financial agent, and often is not. A spouse is commonly both. An adult child who is good with money might be the financial agent, while a different child who is calmer under pressure might be the health care agent. There is no rule that one person must do everything.

**Tell your doctors.** Give a copy of your health care directive to your primary care doctor and to the hospital if you are admitted. Keep a copy where your agent can find it quickly, and carry a card in your wallet stating that you have a health care directive and who your agent is.

## 3.4 HIPAA authorization

In the United States, federal privacy law (HIPAA) limits who can receive your medical information. Your health care agent needs access to your medical records to make informed decisions, and the health care proxy usually authorizes that access. But family members who are not named as agents may be blocked from receiving information — even a spouse, in some situations, if the paperwork is not in order.

A separate HIPAA authorization, naming the people who may receive your medical information, prevents that problem. Ask your attorney whether to include a standalone HIPAA authorization with your health care directive. It is a short document that solves a real, common frustration: a daughter calling the hospital about her father and being told "we cannot share that information with you."

## 3.5 What happens without these documents

If you become incapacitated without a financial power of attorney, a family member must petition a court for guardianship or conservatorship. That process typically involves a court hearing, a medical evaluation, a bond, ongoing court supervision, and periodic reports to the court. It is slower and more expensive than a power of attorney, and the court — not you — chooses who is in charge.

If you become incapacitated without a health care directive, the state's default rules decide who makes medical decisions — usually a spouse, then adult children, then parents — and those people must guess at your wishes. If family members disagree, the dispute may go to court or to a hospital ethics committee.

### Worked example: incapacity with and without documents

**Hypothetical example for teaching purposes only.**

**The family:** Robert, 58, married, homeowner, self-employed. He has a stroke and is hospitalized for six weeks, unable to speak or manage his affairs.

**Without documents:** His wife cannot access his business bank account, which is in his name alone. The mortgage is paid from their joint account, so the house is fine — but the business rent, the business insurance, and a quarterly tax payment are all due from the business account, and she has no authority to pay them. She petitions the court for conservatorship. The process takes five weeks and costs several thousand dollars in legal fees, during which the business falls behind. At the hospital, she and Robert's adult son disagree about a treatment decision, and neither can show the doctors what Robert would have wanted.

**With documents:** Robert signed a durable financial power of attorney naming his wife as agent, and a health care directive naming her as health care agent with his son as backup. She presents the power of attorney to the bank, pays the business bills the same week, and files the tax payment on time. At the hospital, she shows the doctors Robert's living will, which states his wishes clearly, and makes decisions consistent with it. The family still faces a frightening medical crisis — but the legal and financial crisis does not pile on top of it.

The documents did not change the medical outcome. They changed everything around it.

### Action steps — Module 3

1. Choose a financial agent and a backup. Ask them.
2. Choose a health care agent and a backup. Ask them.
3. Write down your medical wishes in plain language in the workbook — the starting point for your living will.
4. Ask your attorney to prepare a durable financial power of attorney, a health care directive, and a HIPAA authorization, and to confirm that your bank will accept the power of attorney.
5. Give copies to your agents, your doctor, and keep a copy where it can be found quickly.

### Common mistakes — Module 3

- Signing a power of attorney that is not durable, so it ends exactly when it is needed.
- Naming an agent but never giving them a copy or telling them where the original is.
- Assuming a spouse can automatically access all accounts. Joint accounts, yes. Accounts in your name alone, often no.
- Writing medical wishes in a will. A will is usually not read until after death. Medical wishes belong in a health care directive that your agent and doctors can find immediately.

---

# Module 4 — Revocable Living Trusts: How They Work and When They Make Sense

**What you will learn:** what a revocable living trust is, how it differs from a will, how "funding" works, when a trust is worth the cost, and when a will alone is enough.

## 4.1 What a revocable living trust is

A revocable living trust is a legal arrangement with three roles:

- **The grantor** (also called the settlor or trustor) — the person who creates the trust. That is you.
- **The trustee** — the person who manages the property in the trust. While you are alive and capable, you are usually your own trustee.
- **The beneficiary** — the person who benefits from the property. While you are alive, you are the beneficiary. After your death, the beneficiaries are the people you name — your spouse, your children, or others.

"Revocable" means you can change it or cancel it at any time while you are capable. "Living" means you create it during your lifetime, as opposed to a testamentary trust, which is created by a will and only comes into existence after death.

Here is how it works in practice: you create the trust document, and then you transfer property into the trust — your house, your bank accounts, your investment accounts. The trust owns the property, but you control the trust, so nothing changes in your daily life. You still live in your house, pay your bills, and manage your money. The difference appears in two situations:

1. **If you become incapacitated,** your successor trustee — the person you named to take over — steps in and manages the trust property for your benefit, without a court having to appoint a conservator.
2. **At your death,** the successor trustee distributes the trust property to your beneficiaries according to the trust's instructions — generally **without probate**, because the trust, not you, owns the property.

A trust does not replace a will. You still need a will — a short one, often called a "pour-over will" — that says any property you forgot to transfer into the trust should be transferred into it at your death. The pour-over will catches the leftovers.

## 4.2 Funding: the step people forget

A trust only controls the property that has been transferred into it. That transfer process is called **funding**, and it is the step most often left incomplete.

Funding means:

- Recording a new deed that transfers your house from your name into the trust's name.
- Retitling bank and investment accounts into the trust's name.
- Updating beneficiary designations where appropriate.
- Transferring business interests, if the trust is meant to hold them.

A trust document sitting in a drawer, with the house still titled in your individual name, does nothing for the house. The house will go through probate. This is the single most common trust failure, and it is entirely preventable: after the trust is signed, work through the funding checklist with your attorney, and confirm that each transfer is complete. The workbook's funding checklist is designed for this.

## 4.3 Will versus trust: a clear comparison

| Question | Will alone | Revocable living trust (plus pour-over will) |
|---|---|---|
| Controls who inherits | Yes | Yes |
| Names a guardian for minor children | Yes | No — the will does this; the trust cannot |
| Avoids probate for property in the trust | No — a will goes through probate | Yes, for property properly transferred into the trust |
| Manages property if you become incapacitated | No | Yes — successor trustee steps in |
| Is the process private? | Probate is generally public | Trust administration is generally private |
| Cost to set up | Generally lower | Generally higher (attorney fees plus funding costs such as deed recording) |
| Ongoing work | Little | Must keep the trust funded as you buy and sell property |
| Works in more than one state | Yes, but probate may be needed in each state where you own real estate | A trust holding property in multiple states can avoid probate in each of them |

## 4.4 When a trust makes sense — and when it does not

A revocable living trust is often worth considering when:

- **You own real estate in more than one state.** Without a trust, your estate may need a separate probate in each state. A trust can avoid that.
- **You value privacy.** Trust administration is generally private; probate filings are generally public.
- **You want to avoid delay for your family.** Trust distributions can often begin sooner than probate distributions.
- **You want a plan for incapacity.** A trust provides a smooth transition to a successor trustee.
- **You have a blended family or a complicated distribution plan.** A trust can set out staged distributions, conditions, and protections that are harder to administer through a will alone.
- **Your state has a slow or expensive probate process.** Probate cost and delay vary widely by state. Ask an attorney in your state what probate typically costs and how long it takes for an estate like yours.

A will alone may be enough when:

- **Your estate is modest and your wishes are simple** — everything to your spouse, then equally to your children.
- **Your main assets pass by beneficiary designation** — retirement accounts and life insurance with named beneficiaries already pass outside probate.
- **Your state's probate process is simple and inexpensive** for estates of your size. Some states have simplified procedures for small estates.
- **You are willing to accept probate** and prefer to spend less now.

There is no universal right answer. The right answer depends on your assets, your state, your family, and what you value — privacy, speed, cost, or simplicity. An attorney in your state can give you a straight answer for your situation, usually in a single consultation, once you arrive with the information this course helps you organize.

## 4.5 Trusts and taxes — what to know, and what not to assume

A revocable living trust **does not save income taxes** while you are alive. For tax purposes, the trust is generally treated as if you still own the property. You report the income on your own tax return, using your own Social Security number, exactly as you did before. Anyone who tells you a revocable living trust is a tax shelter is mistaken.

At death, the tax picture depends on the size of the estate and the law in effect at that time. Federal estate tax applies only to estates above a high threshold that changes with the law, and most families will never owe federal estate tax. A small number of states impose their own estate or inheritance tax at much lower thresholds. This is an area where the law changes and where professional advice matters: ask your attorney and, if your estate is large, a tax professional, whether any tax planning is needed. Do not make decisions based on tax rules you read in a general course, including this one.

## 4.6 Choosing a successor trustee

The successor trustee takes over when you cannot serve — because of incapacity or death. The qualities are the same as for an executor: organized, trustworthy, good with money, willing, and available. The successor trustee may serve for years if the trust holds money for minor children, so choose someone with staying power.

Many families name a spouse as successor trustee, then an adult child or sibling. Some name a professional trustee — a bank or trust company — especially when the trust will last a long time or the family situation is complicated. A professional trustee charges fees, but brings experience and neutrality. Some families name a family member and a professional as co-trustees, so the family member brings personal knowledge and the professional brings expertise. Ask your attorney what that arrangement would cost.

### Worked example: three families, three answers

**Hypothetical examples for teaching purposes only.**

**Family A — The Johnsons.** Married, two young children, one house in one state, modest savings, a retirement account and life insurance with named beneficiaries. Their wishes are simple: everything to the surviving spouse, then equally to the children in trust until age 25. **Answer:** a will with a testamentary trust, plus powers of attorney and health care directives. A revocable living trust would add cost and funding work without much benefit, because most of their wealth already passes by beneficiary designation and their state's probate process is straightforward.

**Family B — The Patels.** Married, three children, a house in their home state, a vacation cabin in another state, and a rental property in a third state. They value privacy and want their children to receive their shares without a long court process. **Answer:** a revocable living trust holding all three properties, plus a pour-over will. Without a trust, their estate could face probate in three states. With the trust funded correctly, the properties pass under the trust's terms.

**Family C — The Thompsons.** A second marriage. Each spouse has children from a prior marriage. They own a house together and each has separate savings. They want the surviving spouse to be able to live in the house for life, but the house to go to the first spouse's children after the surviving spouse dies. **Answer:** a trust, prepared with an attorney's guidance, that provides for the surviving spouse during their lifetime and preserves the remainder for the children. A simple will leaving everything to the surviving spouse would not guarantee that outcome — the surviving spouse could later leave the house to their own children. This is exactly the situation where a generic form is dangerous and an attorney is essential.

The same tool, different answers. The facts decide.

### Action steps — Module 4

1. List your real estate. How many states is it in? That answer alone often decides whether a trust is worth discussing.
2. Ask yourself: do I value privacy and speed enough to pay the higher upfront cost of a trust, and will I do the funding work?
3. Write your answer in the workbook's Will vs. Trust Comparison Guide, and take it to your attorney.
4. If you already have a trust, check whether it is funded. Pull the deed for your house and the titles of your accounts. If they are still in your individual name, the trust is not doing its job.

### Common mistakes — Module 4

- Creating a trust and never funding it.
- Funding the trust once and then buying a new house or opening a new account in your individual name, so the new property is outside the trust.
- Assuming a trust avoids all probate. Property left outside the trust still goes through probate, which is why the pour-over will exists.
- Assuming a trust saves taxes. A revocable living trust generally does not change your income taxes.
- Using an online trust form for a blended family or a multi-state estate without an attorney's review.


---

# Module 5 — Beneficiaries: The Designations That Override Your Will

**What you will learn:** how beneficiary designations work, which accounts have them, why they override your will, the mistakes that cause the most harm, and how to review them in under an hour.

## 5.1 What a beneficiary designation is

A beneficiary designation is an instruction you give to a financial institution or insurer: "When I die, pay this account to this person." It is a contract between you and the institution. When you die, the institution pays the named beneficiary directly. The money does not go through probate, and it does not follow your will.

Accounts and policies that commonly have beneficiary designations:

- Life insurance policies
- Retirement accounts: 401(k)s, 403(b)s, IRAs, pensions
- Bank accounts with a payable-on-death (POD) designation
- Investment and brokerage accounts with a transfer-on-death (TOD) designation
- Annuities
- Health savings accounts (HSAs) in some cases

**The rule to remember:** for any account with a beneficiary designation, the designation controls. Your will cannot change it. Your trust cannot change it (unless the trust itself is named as the beneficiary, which is a decision to make with an attorney). If the two disagree, the designation wins.

## 5.2 Primary and contingent beneficiaries

- **Primary beneficiary:** the person (or people) who receive the account first.
- **Contingent beneficiary:** the person who receives it if the primary beneficiary dies before you, or cannot be found.

Always name a contingent beneficiary. Without one, if your primary beneficiary dies before you, the account may fall into your probate estate — which is exactly the delay and cost the designation was meant to avoid.

You can name more than one primary beneficiary and give each a percentage. For example: "50 percent to my spouse, 25 percent to my daughter, 25 percent to my son." Make sure the percentages add up to 100. Institutions will reject forms that do not add up, and a rejected form may mean the old designation stays in place.

## 5.3 Per stirpes: the word that protects your grandchildren

If you name your three children as equal beneficiaries of a life insurance policy and one child dies before you, what happens to that child's share? The answer depends on a single phrase: **per stirpes**.

- **Per stirpes** means "by the branch." The deceased child's share passes to that child's own children (your grandchildren). The branch continues.
- **Per capita** means "by the head." The deceased child's share is divided among the surviving beneficiaries. The grandchildren receive nothing from that policy.

Most parents intend per stirpes — they want a deceased child's children to inherit that child's share. But many beneficiary forms default to per capita, or do not offer the choice clearly. When you review your designations, look for the per stirpes option and ask the institution or your attorney how to select it. It is a small box on a form with large consequences.

## 5.4 The five most common beneficiary mistakes

**Mistake 1: The ex-spouse is still named.** This is the most common and most painful error. People divorce, remarry, and never update the life insurance or retirement account they opened years earlier. In many states, divorce automatically revokes a designation naming a former spouse — but not in all states, and not for all types of accounts, and federal law can override state law for some employer retirement plans. Do not rely on automatic revocation. Update the form yourself, and confirm in writing that the change was recorded.

**Mistake 2: Minor children are named directly.** A minor child generally cannot receive a large sum directly. If a life insurance policy names a 9-year-old as beneficiary, the insurer may not be able to pay the child, and a court may have to appoint a guardian of the child's property to receive and manage the money until the child is an adult. The usual solution is to name a trust for the child's benefit as the beneficiary, or to name a custodian under your state's transfers-to-minors law — both are decisions to make with an attorney, not by writing a child's name on a form and hoping for the best.

**Mistake 3: No contingent beneficiary.** Covered above. It takes two minutes to add one, and its absence can send an account into probate.

**Mistake 4: The designation and the will point in different directions.** Your will says "everything to my spouse," but your retirement account still names your mother from before you were married. The retirement account goes to your mother. Review every designation against your will, side by side, at least every few years and after every major life event.

**Mistake 5: Naming "my estate" as beneficiary.** Naming your estate as the beneficiary of a retirement account or life insurance policy sends the money into probate and can create adverse tax consequences for retirement accounts. There are rare situations where it is appropriate, but it should be a deliberate choice made with an attorney, not a default.

## 5.5 Retirement accounts deserve special attention

Retirement accounts — 401(k)s, IRAs, and similar plans — have their own rules, and two deserve emphasis:

**Spousal rights.** Under federal law, a married person's 401(k) generally requires the spouse's written, notarized consent before the account owner can name someone else as primary beneficiary. An IRA does not have the same federal requirement, but state law may give a spouse rights. If you are married and want to name someone other than your spouse, expect paperwork and a signature from your spouse. Do not try to work around it.

**Taxes on inherited retirement accounts.** When a beneficiary inherits a traditional retirement account, withdrawals are generally taxable as income to the beneficiary. The tax rules for inherited retirement accounts changed significantly in recent years and depend on who the beneficiary is — a spouse, a minor child, or another person — and on the type of account. A beneficiary who takes a large lump sum can face a large tax bill in a single year. This is a subject for a tax professional, but the planning point is simple: **who you name as beneficiary affects not only who receives the money, but how much of it they keep after tax.** Ask your attorney or tax professional whether your beneficiary choices create an avoidable tax problem.

### Worked example: beneficiary designations in action

**Hypothetical example for teaching purposes only.**

**The family:** Angela, 44, divorced, two children aged 12 and 15. She has a $300,000 term life insurance policy, a $180,000 401(k), and a $40,000 bank account.

**Her designations before this course:**

- Life insurance: primary beneficiary is her former husband, named ten years ago. Contingent beneficiary: none.
- 401(k): primary beneficiary is her mother. Contingent beneficiary: none.
- Bank account: no POD designation.

**What would happen if Angela died today:** the $300,000 life insurance would go to her former husband — not because she wants that, but because she never updated the form. Her mother would receive the 401(k). Her children would receive nothing directly from those two accounts. The bank account would go through probate.

**Her corrected designations after this course (made with her attorney's guidance):**

- Life insurance: primary beneficiary is the testamentary trust for her children created in her will, so the money is managed for the children until they reach age 25. Contingent beneficiary: her sister, per stirpes.
- 401(k): primary beneficiary is the same trust for her children, after confirming with a tax professional that this is appropriate for her situation. Contingent beneficiary: her sister, per stirpes.
- Bank account: POD designation naming the trust for her children.

**The result:** the same $520,000 now goes where Angela intends — to her children, managed for them until adulthood — instead of to a former spouse and an outcome she never chose. The only thing that changed was paperwork. That paperwork took less than an hour, once she knew what to check.

### Action steps — Module 5

1. List every account and policy with a beneficiary designation. Use the Beneficiary Worksheet in the workbook.
2. For each one, write down the current primary and contingent beneficiaries, and the percentages.
3. Check for the five mistakes in section 5.4. Fix the ex-spouse, the missing contingent, and the minor child named directly — with your attorney's guidance on the right replacement.
4. Ask each institution for written confirmation that your updated designation was recorded. Keep the confirmations with your estate documents.
5. Put a reminder in your calendar to review all designations once a year and after every birth, death, marriage, divorce, or job change.

### Common mistakes — Module 5

- Assuming your will controls your life insurance and retirement accounts. It does not.
- Naming minor children directly as beneficiaries.
- Forgetting to update designations after divorce or remarriage.
- Leaving the contingent beneficiary blank.
- Never confirming that an updated designation was actually recorded by the institution.

---

# Module 6 — Probate, Titling, and Keeping Things Out of Court

**What you will learn:** how property passes at death by different routes, how the way property is titled changes everything, how to keep property out of probate where that is your goal, and the risks of shortcuts such as adding a child to a deed.

## 6.1 Four ways property passes at death

Every asset you own passes by one of four routes:

1. **By beneficiary designation** — life insurance, retirement accounts, POD and TOD accounts. Passes directly, outside probate.
2. **By trust** — property in a revocable living trust passes under the trust's terms, generally outside probate.
3. **By survivorship** — property owned jointly with a right of survivorship passes automatically to the surviving owner.
4. **By will or intestacy, through probate** — property owned in your name alone, with no beneficiary designation and not in a trust, passes through probate under your will or, if there is no will, under state intestacy law.

A good estate plan makes a deliberate choice about which route each asset takes, and makes sure the routes agree with each other. A plan that fails is usually a plan where the routes were never coordinated: the will says one thing, the beneficiary designations say another, and the house is titled a third way.

## 6.2 How titling works — and why it matters

The title to an asset — whose name is on the deed or the account — determines which route it takes. Common forms of ownership include:

- **Sole ownership:** the property is in your name alone. It passes through probate under your will (or intestacy).
- **Joint tenancy with right of survivorship:** two or more people own the property together, and when one dies, the survivor owns it all automatically. Common for married couples.
- **Tenancy by the entirety:** a form of joint ownership available to married couples in some states, with additional protection from the creditors of one spouse.
- **Tenancy in common:** each owner holds a separate share — for example, 50 percent each. When one owner dies, their share passes under their will or intestacy law, not automatically to the other owner. This surprises people who assume "we own it together" means "the survivor gets it all."
- **Community property:** in community property states, property acquired during marriage is generally owned equally by both spouses, with its own rules for what happens at death. If you live in a community property state, ask your attorney how it affects your plan.

**Check your deed.** Many homeowners do not know how their house is titled. Pull the deed or check your county's property records. If the deed says "joint tenants with right of survivorship," the surviving spouse receives the house automatically. If it says "tenants in common," the deceased spouse's share goes through probate. That one phrase changes the outcome.

## 6.3 Transfer-on-death and payable-on-death designations

Many states allow transfer-on-death (TOD) designations for real estate and vehicles, and payable-on-death (POD) designations for bank accounts. These work like beneficiary designations for the house or the car: you name a beneficiary, and at your death the property passes to that person without probate. During your lifetime, nothing changes — you still own and control the property, and you can change or revoke the designation.

TOD and POD designations are simple and inexpensive, and they are useful for straightforward situations — for example, naming a spouse as TOD beneficiary of a house. But they have limits:

- They do not provide management during incapacity. A trust does; a TOD designation does not.
- They pass property outright to the beneficiary. If the beneficiary is a minor, or has debt or creditor problems, or receives government benefits, an outright transfer can cause problems a trust would have avoided.
- If the beneficiary dies before you and there is no alternate named, the property may fall back into probate.
- In some states, a TOD deed for real estate must be recorded in a specific way to be valid. Ask an attorney in your state before relying on one.

TOD and POD designations are tools, not a complete plan. They work best as part of a coordinated plan, not as a substitute for one.

## 6.4 Digital assets

Your estate includes digital assets: email accounts, social media accounts, photo libraries, cryptocurrency, online businesses, domain names, and digital files. Without a plan, your family may be locked out of accounts they need — to close a business, recover photos, or pay a bill that only exists online.

Practical steps:

- **Make an inventory.** List your important online accounts, the email address associated with each, and where the passwords are kept. Do not write passwords in your will — a will becomes a public record in probate. Keep passwords in a password manager, and tell your executor how to access the password manager.
- **Use the tools the platforms provide.** Some services allow you to name a legacy contact or an inactive-account manager who can access or close the account after your death. Set those up where they exist.
- **Name a digital executor or authorize your executor** to handle digital assets, if your state allows it. Ask your attorney whether your state's law covers digital assets and what language your documents need.
- **Cryptocurrency needs special care.** If you hold cryptocurrency, your family cannot recover it without your private keys or seed phrase. Losing access to the keys means losing the assets permanently. Store the recovery information securely, tell your executor where it is, and ask your attorney how to document it without exposing it to theft.

## 6.5 Shortcuts that backfire

**Adding a child to the deed of your house.** Some parents add an adult child to the deed as a joint owner, thinking it will avoid probate. It can create serious problems:

- The child becomes a co-owner immediately, with rights to the property while you are alive.
- The child's creditors can reach their share of the house.
- If the child divorces, the house can become part of the divorce.
- The transfer can have gift tax consequences and can affect the tax basis of the property when the child later sells it, potentially costing the family far more in tax than probate would have cost.
- You cannot undo it without the child's agreement.

**Adding a child to a bank account for convenience.** A joint account gives the child immediate access to the money, exposes it to the child's creditors, and, at your death, the money generally passes to the surviving joint owner — even if your will says it should be divided among all your children. If the goal is to let a child pay your bills if you become ill, a financial power of attorney does that job without giving the child ownership of the money.

**Giving away property to qualify for benefits.** Transferring a house or savings to children to qualify for government benefits is a complex area with look-back periods and penalties. Do not do it without advice from an attorney who specializes in that area. A well-meaning transfer can disqualify you from benefits for years.

The pattern in all three shortcuts is the same: a simple fix that changes ownership today creates a problem that is larger, and harder to undo, than the probate it was meant to avoid.

### Worked example: titling the same house three ways

**Hypothetical example for teaching purposes only.**

**The house:** a home worth $400,000, owned by Elena, a widow with two adult children, Sam and Rosa.

**Option 1 — Sole ownership, will leaves the house equally to Sam and Rosa.** At Elena's death, the house goes through probate. The executor sells the house, pays costs, and divides the proceeds equally. The process takes months and the costs come out of the estate, but the outcome matches Elena's wishes.

**Option 2 — Joint tenancy with right of survivorship with Sam.** At Elena's death, Sam owns the house outright. Rosa receives nothing from the house, even if Elena's will says the house should be divided equally. Sam is not legally required to share it. If Sam has debts, his creditors can reach his interest in the house while Elena is still alive.

**Option 3 — TOD deed naming Sam and Rosa equally.** At Elena's death, the house passes to Sam and Rosa outside probate, in equal shares. Elena keeps full control while alive, and neither child's creditors can reach the house before her death. If Sam and Rosa disagree about whether to sell or keep the house, they must work it out — or one may need to buy out the other.

The same house, the same mother, the same two children — three different outcomes, decided entirely by the title. That is why this module asks you to check your deed rather than assume you know what it says.

### Action steps — Module 6

1. Pull the deed for your house and the title for each vehicle. Write down how each is titled.
2. List your bank and investment accounts. Note which have POD or TOD designations and who is named.
3. Make a digital asset inventory: accounts, email addresses, and where passwords are stored. Tell your executor where the inventory is.
4. If you have added a child to a deed or an account as a shortcut, ask an attorney to review whether that shortcut is helping or hurting you.
5. Decide, asset by asset, which of the four routes each asset should take, and write it in the workbook's Asset Route Map.

### Common mistakes — Module 6

- Not knowing how your house is titled.
- Adding a child to a deed or bank account to avoid probate, without understanding the risks.
- Writing passwords in a will.
- Leaving digital assets out of the plan entirely.
- Assuming a TOD designation manages property during incapacity. It does not.

---

# Module 7 — Protecting Children and Dependents

**What you will learn:** how to provide for minor children, how testamentary trusts work, how to plan for a child with a disability, and how to leave instructions that actually help the people who step in.

## 7.1 The guardian and the trustee: two jobs, sometimes two people

Module 2 introduced the guardian — the person who raises your children — and the trustee — the person who manages the money held for your children. They are different jobs, and naming different people for each is often the best choice.

- The guardian needs patience, love, stability, and a home your children can live in.
- The trustee needs financial judgment, organization, and the ability to say no to an unreasonable request — including, sometimes, a request from the guardian.

When the same person does both jobs, there is no check on spending. When different people do the jobs, the trustee reviews the guardian's requests for money, and the guardian can ask the trustee for funds the children need. That tension is healthy. It protects the children's inheritance from being spent too quickly, and it protects the guardian from the burden of managing a large sum alone.

If you name different people, say so clearly in the will, and tell both of them. Explain why: it is not a lack of trust in either person. It is a design choice, so each person can focus on what they do best.

## 7.2 Testamentary trusts for minor children

A testamentary trust is a trust created by your will. It comes into existence only at your death. Until then, it is just a set of instructions in the will.

A typical testamentary trust for minor children says:

- The trustee holds the children's inheritance.
- The trustee may use the money for the children's health, education, maintenance, and support — school fees, medical care, housing, food, clothing, and reasonable activities.
- The trustee distributes the remaining money to each child in stages — for example, one-third at age 25, one-third at 30, and the rest at 35 — or all at a single age you choose.
- If a child dies before receiving their full share, their share passes to their own children (per stirpes) or to the surviving siblings, as you direct.

**Choosing the distribution age.** There is no right age. Consider:

- Age 18 is the legal default without a trust, and most parents consider it too young for a large sum.
- Age 21 or 25 gives the child time to finish education and gain some experience.
- Staged distributions — a portion at 25, more at 30, the rest at 35 — give a young adult a chance to learn from a smaller sum before receiving the rest.
- A trustee with discretion to distribute early for education, a first home, or starting a business can be more useful than a fixed age. Ask your attorney about giving the trustee that discretion.

**Choosing the trustee.** The trustee may serve for many years. Choose someone financially responsible, organized, and likely to be available for the long term. Name a successor trustee in case the first cannot serve. Some families name a professional trustee for a trust that will last many years, or name a family member and a professional as co-trustees.

## 7.3 A child with a disability

If your child receives government benefits based on disability — such as Supplemental Security Income or Medicaid — leaving them money outright can disqualify them from those benefits, because eligibility depends on having very limited assets and income. A gift intended to help can instead take away the benefits the child depends on.

A special needs trust (also called a supplemental needs trust) is designed for this situation. It holds money for the child's benefit and pays for things the government benefits do not cover — such as recreation, travel, education, or additional care — without counting as the child's own assets for benefit purposes. The rules are detailed and strict, and they vary by state and by benefit program.

**Do not improvise this.** If your child has a disability, or may develop one, tell your attorney at the first meeting. A special needs trust is a standard tool for an estate attorney, but it must be drafted correctly, and the wrong language can defeat its purpose. This is one of the clearest cases in estate planning where professional advice is not optional.

The same caution applies to an adult child who has difficulty managing money, struggles with addiction, or has significant debts or legal problems. A trust with a trustee who controls distributions can protect the inheritance from being spent quickly or taken by creditors. Talk to your attorney about whether a trust with protective provisions fits your family.

## 7.4 The letter of intent

A letter of intent is a personal, non-legal letter you write to the guardian (and, if you wish, to the trustee) explaining your wishes for your children. It is not a legal document and does not replace the will, but it is one of the most valuable things you can leave, because it tells the person stepping into your life what you would have told them if you could.

A good letter of intent covers:

- Each child's personality, strengths, fears, and needs.
- Daily routines: school, bedtime, meals, activities, faith practices.
- Medical information: doctors, medications, allergies, conditions.
- Education: the school they attend, your hopes for their schooling, any learning needs.
- Relationships: grandparents, friends, and family members who matter to each child, and how you would like those relationships to continue.
- Values: what matters to you, and what you hope your children will learn.
- Practical information: where school records are kept, who to call, and any arrangements you have already made.

Update the letter once a year, on a birthday or at the start of the school year. Keep it with your will, and tell the guardian where it is. The workbook includes a letter-of-intent template.

## 7.5 Life insurance: the tool that funds the plan

For many young families, life insurance is what makes the estate plan work. The will and the trust decide where the money goes; life insurance is often where the money comes from.

A young family with a mortgage, two children, and modest savings may have an estate worth less than the cost of raising two children to adulthood. Life insurance fills that gap. Term life insurance — a policy that pays a fixed amount if you die during a set period, such as 20 or 30 years — is generally the most affordable way to provide a large sum for a young family, and it is the type most families in this course's audience use.

How much is enough? There is no single formula, but a useful starting point is to add up:

1. The remaining mortgage balance.
2. The cost of raising each child to adulthood, including education.
3. Outstanding debts.
4. A fund to replace your income for the years your family would need it.

Then subtract the savings and assets you already have. The difference is the gap life insurance needs to cover. An insurance agent or financial professional can help you calculate it precisely, and your attorney can help you make sure the policy's beneficiary designation points to the right place — usually the trust for your children, not the children directly (see Module 5).

Review your life insurance whenever your family grows, you buy a house, or your income changes. A policy bought when you were single and childless is rarely the right policy for a parent of two with a mortgage.

### Worked example: a testamentary trust in numbers

**Hypothetical example for teaching purposes only.**

**The family:** Marcus and Lena, married, one child, Sofia, aged 6. Their estate after debts is $600,000, including $400,000 of life insurance. Their will creates a testamentary trust for Sofia, managed by Lena's brother as trustee, with distributions of one-third at 25, one-third at 30, and the rest at 35. The trustee may distribute earlier for health, education, maintenance, and support.

**What happens if both parents die while Sofia is 6:**

- The trustee receives $600,000 (minus probate and administration costs — suppose $25,000, leaving $575,000).
- Over the next 19 years, the trustee pays for Sofia's living expenses, schooling, and medical care from the trust. Suppose the trustee distributes an average of $20,000 per year for 19 years — $380,000 in total — and the trust's investments grow modestly over that period. The exact figures depend on investment returns and spending, which cannot be predicted here; the point is the structure, not a forecast.
- At age 25, Sofia receives one-third of what remains. At 30, another third. At 35, the rest.
- If Sofia dies before 35, her remaining share passes to her own children, if any, or to the alternate beneficiaries named in the will.

**The contrast:** without the trust, Sofia would receive the entire $575,000 outright at 18 — an amount most parents would consider too much, too soon, for an 18-year-old. The trust does not change the amount. It changes the timing, the management, and the protection.

### Action steps — Module 7

1. Decide whether the guardian and the trustee should be the same person or different people. Write down your reasoning.
2. Choose distribution ages or stages for each child. Write them in the workbook.
3. Write a letter of intent for each child. Start with one page; add detail over time.
4. Review your life insurance: is the amount enough to cover the mortgage, debts, and the cost of raising your children? Is the beneficiary designation pointing to the trust, not directly to a minor child?
5. If any child has a disability or receives government benefits, tell your attorney at the first meeting — before any other planning decisions.

### Common mistakes — Module 7

- Naming a guardian but no trustee, so a child inherits outright at 18.
- Naming the same person as guardian and trustee without considering whether that person is good at both jobs.
- Naming minor children directly as life insurance beneficiaries.
- Writing a will and never writing a letter of intent, so the guardian inherits a legal document but no knowledge of the children's lives.
- Forgetting to update the plan when a child is born, or when a child reaches adulthood and no longer needs a guardian.


---

# Module 8 — Real Life Is Complicated: Blended Families, Businesses, and Property in More Than One State

**What you will learn:** how to plan when your family or your assets do not fit the simple pattern — second marriages, stepchildren, a small business, property in several states, and debts — and why these are the situations where an attorney's guidance matters most.

## 8.1 Blended families and second marriages

A second marriage with children from prior relationships is the most common complicated family situation in estate planning, and the one where a simple will most often fails.

The problem is straightforward: if you leave everything to your surviving spouse, the surviving spouse is free to leave it all to their own children, and your children may receive nothing. If you leave everything to your children, your surviving spouse may be left without a home or income. Neither outcome is what most couples intend.

Common solutions, all of which require an attorney's drafting:

- **A trust that provides for the surviving spouse for life, then passes the remainder to your children.** The surviving spouse can live in the house and receive income from the trust during their lifetime, but cannot give the house or the principal to someone else. After the surviving spouse dies, the remaining property passes to the children you named.
- **A life estate in the house.** The surviving spouse has the right to live in the house for life; after their death, the house passes to the children. The details — who pays taxes, insurance, and maintenance — need to be spelled out.
- **Separate property and a written agreement.** Some couples keep separate property and make a clear written plan, sometimes with a prenuptial or postnuptial agreement, about what each spouse's property will fund.
- **Life insurance for the children.** One spouse buys life insurance naming their own children as beneficiaries (through a trust), so the children are provided for regardless of what happens to the shared property.

**Stepchildren:** in most states, stepchildren do not inherit under intestacy law unless you adopted them. If you want a stepchild to inherit, you must name them in your will or trust. Do not assume the law will treat them as your children.

**Talk about it together.** Blended family planning fails most often not because the documents are wrong, but because the couple never discussed it honestly. Each spouse should say plainly what they want for their own children and for each other. An attorney can help the couple find a structure both accept — but the attorney cannot have the conversation for you.

## 8.2 Small business owners

If you own a small business — a shop, a practice, a rental portfolio, an online business — your estate plan must answer a question a will alone does not: **what happens to the business the day after you die?**

- **Who runs it?** If you are the only person who knows how the business works, it may stop the day you die. Name a successor manager in your plan, and write down the essential information: key clients, suppliers, passwords, bank accounts, and contracts. Keep that information where the successor can find it.
- **Who inherits it?** Do you want the business to pass to a child who works in it, to be sold and the proceeds divided, or to be wound down? If one child inherits the business and the others receive an equal value in other assets, the plan needs to say so explicitly — and the business needs to be valued.
- **Can the business be sold?** A buy-sell agreement — a contract between business partners that says what happens to a partner's share at death, and at what price — is the standard tool for businesses with more than one owner. If you have a business partner and no buy-sell agreement, ask an attorney about one. Without it, your family may become business partners with your partner, or may have to sell your share at a bad price.
- **What about debts?** Business debts, leases, and guarantees do not disappear at death. Your executor and your attorney need a complete list of business obligations.

A business owner who dies without a succession plan often leaves a business that loses value quickly. A short written succession plan — who runs it, who inherits it, and where the information is — preserves far more value than it costs to write.

## 8.3 Property in more than one state

Real estate is governed by the law of the state where it is located. If you own a house in your home state and a vacation property in another state, your estate may need a probate proceeding in each state — a main probate at home and an additional proceeding (called ancillary probate) where the other property is located. Each proceeding adds cost and delay.

A revocable living trust holding property in multiple states is the usual solution (see Module 4). The trust owns the property in each state, and the successor trustee administers it under the trust's terms, generally without a probate in any state. The key is funding: each property must actually be transferred into the trust, with a deed recorded in the county where the property is located.

If you buy property in a new state after creating your trust, transfer the new property into the trust at the time of purchase. It is far easier to do it at closing than to fix it later.

## 8.4 Debts, creditors, and what your family does — and does not — owe

A common fear is that a family will inherit a loved one's debts. The general rule is: **your family does not inherit your debts personally.** Debts are paid from your estate before anything is distributed to beneficiaries. If the estate does not have enough to pay all the debts, the debts generally go unpaid — the family does not have to pay them from their own money.

Exceptions and complications exist, and they matter:

- **Joint debts.** If your spouse co-signed a loan, or a credit card is a joint account, the surviving joint owner is responsible for the debt.
- **Secured debts.** A mortgage or car loan is secured by the property. If the family wants to keep the house or the car, the loan must be paid or refinanced. If they do not want it, the lender takes the property.
- **Debts in community property states.** In community property states, a surviving spouse may be responsible for debts incurred during the marriage even if they did not sign for them. Ask an attorney in your state.
- **Certain federal debts.** Federal student loans are generally discharged at the borrower's death. Private student loans depend on the loan agreement and whether there is a co-signer.

**Practical advice for the family:** after a death, do not pay the deceased person's unsecured debts from your own money until the executor and an attorney have reviewed which debts are valid and in what order they must be paid. Creditors sometimes contact grieving family members and pressure them to pay. The estate pays debts in an order set by state law, and family members are not personally liable for the deceased's separate debts.

## 8.5 When a family member contests the plan

A will or trust can be challenged in court — usually on the grounds that the person lacked mental capacity, was unduly influenced, or that the document was not executed correctly. Challenges are uncommon, but they are more likely when:

- A child is left out entirely, or receives much less than siblings, without explanation.
- The plan changes late in life, especially after a decline in health.
- A new spouse or a caregiver receives a large share.
- The documents were prepared without a lawyer.

You cannot prevent a challenge entirely, but you can reduce the risk:

- **Have an attorney prepare and supervise the signing.** An attorney's file notes and the witnesses' testimony are strong evidence that the document was executed correctly and that you had capacity.
- **Explain unequal treatment.** If you leave different amounts to different children, write a short letter explaining why — not in the will itself, which becomes public, but in a separate letter kept with the will. A reasoned explanation ("I paid for your brother's college and your sister's down payment; this equalizes the help you each received") is far better than silence, which invites a story about favoritism.
- **Keep the plan current.** A plan updated regularly is harder to challenge than one signed years ago and never revisited.
- **Be cautious about last-minute changes.** A major change made when you are ill or under pressure is the change most likely to be challenged. If your wishes have changed, make the change while you are healthy and can explain it clearly.

### Worked example: a blended family with a trust

**Hypothetical example for teaching purposes only.**

**The family:** Thomas, 62, and Elaine, 58, married for ten years. Thomas has two adult children from his first marriage; Elaine has one adult child from hers. They own a house worth $450,000 with no mortgage, and each has $150,000 in savings.

**The problem with a simple will:** if Thomas leaves everything to Elaine, Elaine could later leave everything — including the house Thomas brought into the marriage — to her own child. Thomas's children would receive nothing. If Thomas leaves everything to his children, Elaine could lose her home.

**Their plan, drafted with an attorney:** Thomas and Elaine create a trust. The trust says: at the first spouse's death, the surviving spouse may live in the house for life and receive income from the trust for their support. The surviving spouse may not sell the house or give it away. At the surviving spouse's death, the house is sold and the proceeds are divided: half to Thomas's children, half to Elaine's child. Each spouse also holds a $100,000 life insurance policy naming their own children (through a trust) as beneficiaries, so each set of children receives something directly regardless of what happens to the house.

**The result:** the surviving spouse is housed and supported for life. Neither set of children is disinherited. The plan is written down, witnessed, and explained to the children in advance, so there is no surprise and no reason to contest it. The documents cost more than a simple will — and they solve a problem a simple will could not solve.

### Action steps — Module 8

1. If you are in a second marriage, write down what you want for your spouse and what you want for your children from a prior relationship. Discuss it together before you see an attorney.
2. If you own a business, write a one-page succession plan: who runs it, who inherits it, and where the essential information is.
3. List property in every state. If it is in more than one, ask your attorney whether a trust makes sense.
4. List your debts, and note which are joint. Share the list with your executor.
5. If you plan to treat children unequally, write a short letter explaining why, and keep it with your will.

### Common mistakes — Module 8

- Leaving everything to a surviving spouse in a blended family and assuming the spouse will pass it to your children. They may not — and they are not legally required to.
- Assuming stepchildren inherit automatically. They generally do not.
- Owning a business with a partner and no buy-sell agreement.
- Owning property in several states and a will alone, guaranteeing multiple probates.
- Paying a deceased person's debts from your own money before the estate has been reviewed.

---

# Module 9 — Putting Your Plan Together: Attorney Review, Funding, Storage, and the Family Conversation

**What you will learn:** how to choose and work with an estate attorney, what to bring to the first meeting, how to finish the funding and storage steps that make the plan real, how to talk to your family about it, and how to keep the plan current for the rest of your life.

## 9.1 Choosing an estate attorney

Estate planning is a specialty. A general lawyer can draft a will, but an attorney who practices estate planning every day will know your state's probate rules, tax thresholds, and the drafting details that make a trust work. Look for:

- **A practice focused on estate planning.** Ask what percentage of their work is estate planning.
- **Clear fees.** Many estate attorneys charge a flat fee for a standard package (will, powers of attorney, health care directive) and a separate flat fee for a trust. Ask for the fee in writing before the work starts, and ask what is included — the first meeting, the drafts, the signing, and the funding help.
- **A state license where you live.** Estate law is state law. An attorney licensed in another state cannot reliably advise you on yours.
- **Someone you can talk to.** You will discuss your children, your money, and your family. Choose someone who listens, explains in plain language, and does not rush you.

Ways to find one: ask friends, family, or your financial professional for a referral; check your state bar association's lawyer referral service; or look for an attorney who belongs to a professional estate planning association in your state. A short initial consultation — often free or low-cost — is a reasonable way to judge whether the attorney is a good fit.

**What it costs:** fees vary widely by state, by the attorney's experience, and by the complexity of your plan. A simple will package generally costs less than a trust package, and a trust package costs more because it includes the trust document, the pour-over will, and the funding work. Get a written estimate. Compare it not with the cost of an online form, but with the cost of probate, delay, and family conflict if the plan is wrong. That is the honest comparison.

## 9.2 What to bring to the first meeting

Arrive organized and you will save time and money. Bring:

1. The completed workbook: the Estate Checklist, the Document Organizer, the Beneficiary Worksheet, and the Will Planning Worksheet.
2. The Will vs. Trust Comparison Guide from the templates folder, with your notes.
3. A list of your assets and debts, with approximate values.
4. A list of the people you want to name — executor, guardian, trustee, financial agent, health care agent — and their full legal names, addresses, and phone numbers.
5. Copies of your current will, trust, or powers of attorney, if any exist.
6. Copies of beneficiary designations, or at least a list of them.
7. The deed to your house and the titles to your vehicles.
8. Your questions — write them down in advance, so you do not forget them under the pressure of the meeting. The Attorney-Review Checklist in the workbook is designed for this.

The attorney's job at the first meeting is to understand your family and your wishes, explain your options, and recommend a structure. Your job is to arrive with the facts and to be honest about your family — including the difficult parts. An attorney who does not know about the estranged child, the business debt, or the second marriage cannot plan for them.

## 9.3 Funding, signing, and storage: making the plan real

A plan is not finished when the documents are signed. It is finished when three things are true:

**1. The documents are signed correctly.** The attorney supervises the signing, with the required witnesses and, where your state requires it, a notary. Do not take the documents home unsigned and sign them later without the attorney's guidance — the execution formalities are the part most often done wrong.

**2. The plan is funded.** If you have a trust, transfer the property into it: record the deed, retitle the accounts, update the beneficiary designations the attorney advises. Work through the funding checklist with the attorney and confirm each transfer. If you have no trust, confirm that your beneficiary designations and account titles match the will.

**3. The documents are stored where they can be found.** Tell your executor, your trustee, and your agents where the originals are. Good options include:

- A fireproof safe at home, with the combination or key location known to your executor.
- Your attorney's office, if they offer document storage.
- A safe deposit box — only if your executor has access to it after your death. In some states, a safe deposit box is sealed at death and cannot be opened without a court order, which defeats the purpose.

Keep copies at home and give copies to your executor, your trustee, and your health care agent. Keep the original will in one safe place and tell the executor exactly where it is. A will no one can find is the same as no will at all.

## 9.4 The family conversation

Estate planning is not a secret to keep from your family. It is a conversation to have with them — while you are alive, calm, and able to explain your reasoning.

**What to tell your executor and trustee:** that you have named them, where the documents are, where the money is, and who your attorney is. Give them a copy of the Document Organizer.

**What to tell your guardian:** that you have named them, what your wishes are for your children, and where the letter of intent is.

**What to tell your adult children:** the broad outline — who is in charge, where the documents are, and that you have made a plan so they will not have to guess. You do not need to disclose dollar amounts if you prefer not to. What matters is that they are not surprised.

**What to tell everyone:** where the plan is kept, and who to call first. In the days after a death, the family needs one clear instruction: who is in charge, and where the documents are. Put that on a single page — the workbook includes a "First Steps for My Family" page for exactly that purpose — and keep it where your family can find it.

The workbook's family conversation scripts give you exact words for these conversations, including the hardest one: telling an adult child that they will receive less than a sibling, or that a guardian has been chosen who is not a grandparent. Use them. A conversation now prevents a dispute later.

## 9.5 Keeping the plan current

An estate plan is not a one-time event. It is a document set that needs review on a schedule and after life changes.

**Review after every major life event:**

- Birth or adoption of a child
- Marriage, divorce, or remarriage
- Death of a beneficiary, executor, guardian, or trustee
- A move to another state
- Buying or selling a home or business
- A large change in wealth
- A diagnosis of a serious illness

**Review on a schedule even if nothing changes:** once a year, check your beneficiary designations — a 15-minute review. Every three to five years, review the whole plan with your attorney. Laws change, and so do families. A plan written when your children were toddlers may not fit when they are adults.

**The 30/60/90-day plan:**

- **Days 1–30:** complete the workbook. List your assets and debts, choose your executor, guardian, trustee, and agents, and review your beneficiary designations. Book the attorney consultation.
- **Days 31–60:** meet the attorney, review the drafts, ask your questions, and sign the documents correctly. Give copies to your executor, trustee, and agents.
- **Days 61–90:** fund the trust if you have one, confirm beneficiary designations in writing, store the originals, write your letter of intent, and have the family conversations.

Ninety days from now, your family can be protected. The work is not large. The cost of not doing it is.

### Action steps — Module 9

1. Book the attorney consultation this week. Put it on the calendar before you finish this module.
2. Complete the Attorney-Review Checklist in the workbook and bring it to the meeting.
3. After signing, work through the funding checklist until every item is confirmed.
4. Store the originals, give copies to the people named in the plan, and complete the "First Steps for My Family" page.
5. Have the family conversations — executor, guardian, and adult children — within two weeks of signing.
6. Set a calendar reminder: beneficiary review in one year, full plan review in three years.

### Common mistakes — Module 9

- Signing documents and never funding the trust.
- Storing the original will where no one can find it — or in a safe deposit box no one can open.
- Never telling the executor they were named.
- Never having the family conversation, so the plan is a surprise.
- Treating the plan as finished forever. It is finished for now — and it needs review.

---

# Appendix A — Glossary in Plain English

- **Administrator:** the person a court appoints to settle an estate when there is no will, or no named executor can serve. Similar to an executor, but court-appointed.
- **Beneficiary:** a person or organization who receives property under a will, trust, or beneficiary designation.
- **Contingent beneficiary:** the person who receives an asset if the primary beneficiary cannot.
- **Durable power of attorney:** a power of attorney that remains effective if you become incapacitated.
- **Executor / personal representative:** the person named in a will to carry out its instructions and settle the estate.
- **Funding:** transferring property into a trust so the trust controls it.
- **Guardian:** the person appointed to raise minor children (guardian of the person) or manage a minor's property (guardian of the estate).
- **Health care directive:** a document stating medical wishes and naming a health care agent. Includes a living will and a health care proxy.
- **Intestate:** dying without a valid will. State intestacy law then decides who inherits.
- **Living will:** the part of a health care directive that states your wishes about medical treatment if you cannot communicate.
- **Per stirpes:** a distribution method where a deceased beneficiary's share passes to their own children.
- **Pour-over will:** a will that transfers any property left outside a trust into the trust at death.
- **Probate:** the court-supervised process of settling a deceased person's estate.
- **Revocable living trust:** a trust created during your lifetime that you can change or cancel, which holds property for your benefit and passes it to beneficiaries after death, generally without probate.
- **Successor trustee:** the person who takes over managing a trust when the original trustee cannot serve.
- **Testamentary trust:** a trust created by a will, which comes into existence only at the maker's death.
- **Testator:** the person who makes a will.
- **Transfer-on-death (TOD) / payable-on-death (POD):** a designation that passes an asset directly to a named beneficiary at death, outside probate.
- **Trustee:** the person or institution that manages property held in a trust.

# Appendix B — Your First 30/60/90 Days

See Module 9, section 9.5. Copy this schedule into your calendar now:

- **Week 1:** read Modules 1–3, complete the Estate Checklist and Document Organizer.
- **Week 2:** read Modules 4–5, complete the Beneficiary Worksheet, book the attorney consultation.
- **Week 3:** read Modules 6–7, complete the Will Planning Worksheet and the letter of intent.
- **Week 4:** read Modules 8–9, complete the Attorney-Review Checklist.
- **Days 31–60:** attorney meeting, drafts, signing, copies distributed.
- **Days 61–90:** funding confirmed, storage settled, family conversations held, calendar reminders set.

# Appendix C — State-Variation Notes: What to Ask About Where You Live

Estate law is state law. The following questions are worth asking your attorney in your first meeting, because the answers vary by state:

1. What is the probate process like in this state for an estate of my size — how long does it typically take, and what does it typically cost?
2. Does this state recognize transfer-on-death deeds for real estate?
3. Does this state have a simplified probate procedure for small estates, and would my estate qualify?
4. Does this state impose an estate tax or an inheritance tax, and at what threshold?
5. Is this a community property state, and how does that affect my plan?
6. What are the witness and notarization requirements for a will, a power of attorney, and a health care directive in this state?
7. Does this state recognize a handwritten will? (Do not rely on it if the answer is yes — ask why a formally executed will is still preferable.)
8. How does this state treat a former spouse named as a beneficiary after divorce?
9. Does this state have a law covering digital assets, and what should my documents say about them?
10. If I move to another state, will my documents still be valid, and what should I have reviewed?

---

## A Final Word

You started this course because you love your family and you know that "someday" is not a plan. You now understand the five questions an estate plan answers, the documents that answer them, the mistakes that cause the most harm, and the exact steps to finish.

The plan does not need to be perfect. It needs to be **done** — signed correctly, funded, stored where it can be found, and explained to the people it protects. A good plan, finished, is worth far more than a perfect plan that stays in your head.

Book the attorney consultation. Bring the workbook. In ninety days, this can be finished — and your family will never have to guess what you would have wanted.

---

*This course is general education only and is not legal, tax, or financial advice. Estate planning documents require a licensed estate attorney in your state. Laws vary by state and change over time. Have all documents reviewed by a licensed attorney before signing.*

