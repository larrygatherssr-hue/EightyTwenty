# Will vs. Trust — Comparison Guide

**General education only. This guide is not legal advice. Whether a will alone or a revocable living trust fits your situation depends on your assets, your family, and your state's law. Discuss this guide with a licensed estate attorney in your state before deciding.**

## How to use this guide

Work through the questions in the left column, fill in your answers, and bring the completed guide to your attorney. The comparison is a starting point for that conversation — not a decision by itself.

## Side-by-side comparison

| Question | Will alone | Revocable living trust (plus pour-over will) |
|---|---|---|
| Does it name who inherits my property? | Yes | Yes |
| Does it name a guardian for minor children? | Yes — a trust cannot do this; the will does | No — you still need a will for this |
| Does it name an executor? | Yes | The trust names a trustee; the pour-over will names an executor for any property outside the trust |
| Does property avoid probate? | No — a will goes through probate | Yes, for property properly transferred into the trust |
| Does it manage property if I become incapacitated? | No | Yes — the successor trustee steps in |
| Is the process private? | Probate is generally public | Trust administration is generally private |
| What does it cost to set up? | Generally lower | Generally higher (attorney fees plus funding costs such as recording a deed) |
| How much ongoing work is there? | Little | Must keep the trust funded as you buy and sell property |
| What happens to property in another state? | Probate may be needed in each state where you own real estate | A trust holding property in multiple states can avoid probate in each of them |
| Does it save income taxes while I am alive? | No | No — a revocable living trust generally does not change your income taxes |
| Can I change it? | Yes, at any time while I have capacity | Yes, at any time while I have capacity |
| What happens to property I forget to include? | It passes under the will or intestacy law | The pour-over will transfers it into the trust at death (through probate) |

## Your situation — fill this in

| Question | My answer |
|---|---|
| How many states do I own real estate in? | |
| Do I value privacy? | |
| Do I want my family to receive property quickly, without waiting for probate? | |
| Do I want a plan that manages my property if I become incapacitated? | |
| Is my family situation complicated (blended family, child with a disability, business, large estate)? | |
| Are most of my assets already passing by beneficiary designation? | |
| Am I willing to do the funding work and keep the trust funded? | |
| Is keeping upfront costs low more important to me than avoiding probate? | |

## When a trust is often worth discussing

- You own real estate in more than one state.
- You value privacy and want to avoid a public probate.
- You want property to pass to your family without probate delay.
- You want a smooth plan for incapacity.
- You have a blended family or a complicated distribution plan.
- Your state's probate process is slow or expensive for estates of your size.

## When a will alone is often enough

- Your estate is modest and your wishes are simple.
- Your main assets pass by beneficiary designation (retirement accounts, life insurance).
- Your state's probate process is simple and inexpensive for estates of your size.
- You are willing to accept probate and prefer to spend less now.

## Worked scenarios (hypothetical, for teaching only)

**Scenario A — One house, one state, simple wishes.** A married couple with two young children, one house, a retirement account and life insurance with named beneficiaries. Wishes: everything to the surviving spouse, then equally to the children in trust until age 25. A will with a testamentary trust, plus powers of attorney and health care directives, is often enough.

**Scenario B — Property in three states.** A couple with a house, a vacation cabin in a second state, and a rental property in a third state. Without a trust, the estate could face probate in three states. A funded revocable living trust is often worth discussing.

**Scenario C — Second marriage, children from prior marriages.** Each spouse wants the surviving spouse housed for life, but their own children to inherit after the surviving spouse dies. A trust drafted by an attorney is usually needed — a simple will leaving everything to the surviving spouse does not guarantee that outcome.

## Questions to ask your attorney

1. Is a will alone enough for my situation, or should I consider a revocable living trust?
2. What does probate typically cost and how long does it take in my state for an estate like mine?
3. What would the trust package cost, including funding help, and what is included?
4. If I create a trust, what exactly must I transfer into it, and will you help me confirm each transfer?
5. Does my state recognize transfer-on-death deeds for real estate?

---

*General education only — not legal, tax, or financial advice. Discuss with a licensed estate attorney in your state.*
