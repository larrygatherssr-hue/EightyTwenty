# Customer Onboarding — Protect Your Family: Wills, Trusts & Estate Planning Essentials

Welcome, and thank you for purchasing this course. This guide tells you what you received, what to do first, and how to finish with a signed, funded estate plan in 90 days.

## IMPORTANT — PLEASE READ FIRST

This course is **general education only. It is not legal advice, tax advice, or financial advice, and it does not create an attorney–client relationship.**

Estate planning law varies by state and country, and it changes over time. Wills, trusts, powers of attorney, and health care directives must be prepared and executed according to the laws of your state, and reviewed by a licensed estate attorney in your state before you sign them. This course does **not** provide fill-in legal documents presented as valid legal forms. The checklists, comparison guides, worksheets, and scripts are educational planning tools to help you prepare for a meeting with an attorney.

If you are facing an urgent situation — a loved one who has died, a family member who has become incapacitated, or a medical emergency — contact an estate attorney promptly rather than working through this course first.

---

## What you received

After purchase you received these downloadable files:

| File | What it is |
|---|---|
| `content.md` | The complete course text — 9 modules, about 7 hours of teaching, plus a glossary and state-variation questions |
| `workbook.md` | The companion workbook — 10 worksheets, checklists, family conversation scripts, and a one-page "First Steps for My Family" summary |
| `templates/will-trust-comparison.md` | Will vs. trust comparison guide with worked scenarios |
| `templates/beneficiary-document-organizer.csv` | Reusable spreadsheet for accounts, policies, property, debts, and key contacts |
| `templates/estate-checklist.csv` | The full estate checklist in spreadsheet form |
| `sales-page.md` | The full sales page for this course (for your reference) |
| `cover.png` | The course cover image |
| `onboarding.md` | This guide |
| `listing.json` | Marketplace listing data (for the store, not needed for study) |

Save all files somewhere safe — ideally backed up — and keep the completed workbook with your estate documents once they are signed.

---

## What to do first (this week)

1. **Read the disclaimer at the top of `content.md`.** It explains what this course is and is not. It matters.
2. **Read Module 1 and complete Worksheet 1 and Worksheet 2 in the workbook.** Worksheet 1 asks the five questions every estate plan answers. Worksheet 2 is your master Estate Checklist for the whole plan.
3. **Complete the Document Organizer (Worksheet 3).** List your accounts, policies, property, debts, and key contacts. This is the single most useful thing you can do before seeing an attorney.
4. **Check your beneficiary designations today.** Look at your life insurance and retirement accounts and write down who is currently named. Most buyers are surprised by what they find. Worksheet 4 walks you through it.
5. **Book an estate attorney consultation.** Do this in week one, even if the appointment is a few weeks away. Look for an attorney whose practice focuses on estate planning, licensed in your state, with a clear written fee. Ask friends or your state bar association's referral service if you need a name.

---

## How to use the materials

- **Work module by module.** Each module in `content.md` ends with Action Steps. Do them before moving on — estate planning fails when it stays theoretical.
- **Fill in the workbook as you go.** Print it, or copy each worksheet into your own notes. The workbook is designed to be handed to your attorney at the first meeting.
- **Use the templates for tracking.** The CSV files open in any spreadsheet program. Use the Beneficiary and Document Organizer to keep a live record of your accounts and designations, and the Estate Checklist to track your progress through the plan.
- **Bring the workbook to your attorney.** The Attorney-Review Checklist (Worksheet 9) lists the exact questions to ask. Arriving organized saves you time and money, because the attorney's time goes to legal judgment rather than gathering basic facts.

---

## Suggested schedule

**Pace A — one module per week (9 weeks):**
One module and its workbook exercises each week. Book the attorney consultation in week 2, so the appointment falls after you have finished Modules 1–5.

**Pace B — two modules per weekend (about 1 month):**
Two modules each weekend, with the workbook exercises during the week. Book the attorney consultation in the first week.

**Either way, follow the 30/60/90-day finish line in Module 9:**

- **Days 1–30:** Organize. Complete Worksheets 1–4, review beneficiary designations, book the attorney.
- **Days 31–60:** Meet the attorney, review drafts, ask your questions, and sign the documents correctly (with the required witnesses / notary for your state).
- **Days 61–90:** Fund the trust if you have one (confirm every transfer), confirm beneficiary designations in writing, store the originals, write your letter of intent, and have the family conversations.

Set two calendar reminders now: review your beneficiary designations in 12 months, and review the full plan with your attorney in 3 years — and review after any birth, death, marriage, divorce, move, or major purchase.

---

## How to get support

- **For help with your order or the course files:** email the marketplace support address with your order number and a description of the issue, and the support team will respond.
- **For legal questions about your situation:** contact a licensed estate attorney in your state. Marketplace support cannot provide legal advice.
- **Refund:** 14-day money-back guarantee. If you are not satisfied within 14 days of purchase, contact support with your order number for a full refund.

---

## A final note

You bought this course because you want your family protected. The course gives you the understanding; the attorney gives you the valid documents; the 90-day plan gives you the finish line. A good plan, finished, is worth far more than a perfect plan that stays in your head. Book the consultation this week.
