# FIN-07 — Protect Your Family: Wills, Trusts & Estate Planning Essentials

**Price:** $397, one-time · **Category:** Finance & Wealth · **SKU:** FIN-07

A 9-module video course (7 hours) for parents and homeowners aged 35–60 with children, property, or a small business who have no will or trust in place. Plain-English teaching on wills, powers of attorney, revocable living trusts, beneficiaries, and probate avoidance — with worked examples using real numbers.

**General education only — not legal advice.** Estate documents require a licensed estate attorney in the buyer's state. No fill-in legal forms are provided.

## Files in this folder

| File | What it is |
|---|---|
| `content.md` | Full course text — all 9 modules fully written, plus glossary and state-variation appendix |
| `workbook.md` | Companion workbook — 10 worksheets, checklists, family conversation scripts, "First Steps for My Family" page |
| `templates/will-trust-comparison.md` | Will vs. trust comparison guide with worked scenarios |
| `templates/beneficiary-document-organizer.csv` | Reusable spreadsheet — accounts, policies, property, debts, key contacts |
| `templates/estate-checklist.csv` | Full estate checklist in spreadsheet form |
| `sales-page.md` | Full sales page — headline, problem, solution, module list, who it is/is not for, $397 + 14-day guarantee, 10 FAQs, disclaimers |
| `listing.json` | Marketplace listing data (sku FIN-07, price_cents 39700, billing one_time) |
| `cover.md` | Cover design brief — black-and-gold luxury branding |
| `cover.png` | Finished cover image (1120 × 2240 px, PNG) |
| `onboarding.md` | Customer onboarding guide — what to do first, schedule, support |
| `README.md` | This index |
