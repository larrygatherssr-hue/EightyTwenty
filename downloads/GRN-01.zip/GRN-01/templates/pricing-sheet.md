# Pricing Sheet

Work through this sheet for every crop you sell. The formula is:

**Cost per unit = (direct costs + your time) ÷ units produced**
**Minimum price = cost per unit × 1.2** (the extra 20% covers losses, unsold produce, and costs you forgot)
**Your price = the higher of your minimum price and a price your market will actually pay — checked against real local prices.**

Value your time at a real rate. Use at least the local minimum wage; $15–$25 an hour is a realistic rate for skilled growing work. If a crop cannot cover your time at a price customers will pay, it is the wrong crop for sale — grow it for yourself, or not at all.

## Local price research

Check these prices before you set yours. Record the date and the source.

| Crop | Farmers market price | Grocery / organic shop price | CSA box equivalent | My price |
|---|---|---|---|---|
| Mixed salad leaves (per bag / per lb) | | | | |
| Lettuce (per head) | | | | |
| Basil (per bunch) | | | | |
| Parsley (per bunch) | | | | |
| Cilantro (per bunch) | | | | |
| Cherry tomatoes (per punnet) | | | | |
| Slicing tomatoes (per lb) | | | | |
| Peppers (per lb) | | | | |
| Cucumbers (each) | | | | |
| Radishes (per bunch) | | | | |
| Carrots (per lb) | | | | |
| Beets (per bunch) | | | | |
| Microgreens (per punnet) | | | | |

**Research date:** ______________ **Sources:** ______________

## Cost-plus pricing — one row per crop

| Crop | Direct costs (seed, compost, water, packaging) | Hours spent | My hourly rate | Time cost (hours × rate) | Total cost | Units produced | Cost per unit | Minimum price (× 1.2) | My selling price |
|---|---|---|---|---|---|---|---|---|---|
| Example: salad leaves | $25 | 6 | $15 | $90 | $115 | 20 bags | $5.75 | $6.90 | $7.00 |
| | | | | | | | | | |
| | | | | | | | | | |
| | | | | | | | | | |
| | | | | | | | | | |
| | | | | | | | | | |
| | | | | | | | | | |

## Worked example — salad leaves

A bed of salad leaves costs $25 in seed, compost, and water for the season and takes 6 hours of work across the season. At $15 an hour, the time cost is $90, so the total cost is $115. The bed produces 20 sellable bags. Cost per bag is $115 ÷ 20 = $5.75. The minimum price is $5.75 × 1.2 = $6.90. If the local market price for a comparable bag is $5, this crop does not pay at this scale — costs must fall, yield must rise, or the crop should be dropped for sale. If the market price is $7, the crop works. That is the decision this sheet exists to make.

## Price list (fill in once your prices are set)

| Product | Unit | Price |
|---|---|---|
| | | |
| | | |
| | | |
| | | |
| | | |
| | | |

**Price review date (once a season):** ______________

## Policies

- **Discounts:** I will / will not offer standing discounts. End-of-day market discount: ______%. Glut discount: ______%.
- **Free samples:** Yes — a taste costs almost nothing and converts browsers into buyers.
- **Free produce for friends and family:** Track it. If a third of the harvest is given away, pricing is built on two-thirds of the yield.
- **Delivery:** Free delivery for orders over $______ within ______; delivery fee below that: $______.
- **Price changes:** Review once a season, not once a week. A small tested increase (about 10% on one crop) is better than guessing.
