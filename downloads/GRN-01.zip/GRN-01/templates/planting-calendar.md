# Planting Calendar — Template

Fill in your own frost dates first, then plan each crop. This template is set out for a temperate city with a last frost around mid-May and a first frost around mid-October. Adjust every date to your own climate — your local extension service or nursery can confirm your frost dates.

**My last frost date:** ______________ **My first frost date:** ______________

## How to read this calendar

- **Sow indoors:** start seed under cover, then transplant out after hardening off.
- **Sow outdoors:** sow direct in the bed.
- **Succession:** re-sow at the interval shown for a continuous harvest.
- **Harvest:** the expected window for the first sowing; later sowings harvest later.

## Spring

| Crop | Sow indoors | Sow outdoors | Transplant out | First harvest | Succession |
|---|---|---|---|---|---|
| Peas | — | 6–8 weeks before last frost | — | 60–70 days after sowing | Every 2 weeks until warm |
| Spinach | — | 6–8 weeks before last frost | — | 40–50 days | Every 2 weeks in cool weather |
| Radishes | — | 4–6 weeks before last frost | — | 25–30 days | Every 10–14 days |
| Lettuce / salad leaves | 4–6 weeks before last frost | 2–4 weeks before last frost | After hardening off | 30–50 days | Every 2 weeks |
| Kale | 4–6 weeks before last frost | 2–4 weeks before last frost | After hardening off | 50–60 days | Every 3–4 weeks |
| Beets | — | 2–4 weeks before last frost | — | 55–65 days | Every 3 weeks |
| Carrots | — | 2–4 weeks before last frost | — | 60–80 days | Every 3–4 weeks |
| Cilantro / parsley | — | 2–4 weeks before last frost | — | 45–60 days | Every 2–3 weeks |

## After last frost (warm season)

| Crop | Sow indoors | Sow outdoors | Transplant out | First harvest | Succession |
|---|---|---|---|---|---|
| Tomatoes | 6–8 weeks before last frost | — | After last frost | 60–80 days after transplant | One planting |
| Peppers | 8–10 weeks before last frost | — | After last frost | 70–85 days after transplant | One planting |
| Basil | 4–6 weeks before last frost | After last frost | After last frost | 60–70 days | Every 3 weeks |
| Cucumbers | 3–4 weeks before last frost | After last frost | After last frost | 50–60 days | Every 3 weeks |
| Bush beans | — | After last frost | — | 50–60 days | Every 2–3 weeks |
| Squash / courgette | 3–4 weeks before last frost | After last frost | After last frost | 50–60 days | One or two plantings |

## Late summer and autumn

| Crop | Sow indoors | Sow outdoors | Transplant out | First harvest | Notes |
|---|---|---|---|---|---|
| Lettuce / salad leaves | — | 8–10 weeks before first frost | — | 30–50 days | Shade sowings in heat |
| Spinach | — | 6–8 weeks before first frost | — | 40–50 days | Autumn crop; hardy |
| Kale / chard | 8–10 weeks before first frost | 6–8 weeks before first frost | 4–6 weeks before first frost | 50–60 days | Harvest into winter with cover |
| Radishes | — | Up to 4 weeks before first frost | — | 25–30 days | Fast autumn crop |
| Garlic | — | 4–6 weeks before first frost | — | Next summer | Plant cloves; mulch well |

## Year-round (indoors, trays)

| Crop | Sow | Harvest | Notes |
|---|---|---|---|
| Microgreens (radish, pea, sunflower, broccoli) | Any time | 7–14 days | Needs a weekly buyer; trays need daily attention |

## Monthly checklist

- **Late winter:** order seeds; check tools; plan beds; apply for market stall.
- **Early spring:** start tomatoes and peppers indoors; sow peas, spinach, radishes outdoors.
- **Mid-spring:** transplant hardy greens; sow lettuce, beets, carrots in succession.
- **Late spring:** transplant tomatoes, peppers, basil after last frost; set up drip irrigation.
- **Early summer:** first market harvests; keep sowing salad and radishes every two weeks.
- **Midsummer:** second sowing of beans; start autumn greens; watch watering daily.
- **Late summer:** transplant autumn greens; sow garlic; preserve or sell gluts.
- **Autumn:** last tomato harvest; keep cutting kale and chard; clear and mulch beds.
