# Buyer Outreach Scripts

Short, honest scripts for approaching each type of buyer. Adapt the words to your own voice — the structure is what matters: who you are, what you grow, what it costs, when you can deliver, and a clear next step. Never overpromise. If you are not sure you can deliver a quantity every week, say so and offer a smaller trial.

---

## 1. Neighbours and local direct sales

**Use for:** a note through the door, a message in a neighbourhood group, or a face-to-face chat.

> Hi, I'm [your name] — I grow vegetables in my garden at [street / area]. This season I'm selling a weekly salad bag: mixed leaves, herbs, and whatever else is ready, picked the morning you collect it. It's $[price] a week, collected from my door on [day], or I can drop it off nearby for orders over $[minimum]. If you'd like one this week, just let me know by [day] and I'll put your name down. No commitment — try one week and see what you think.

**Follow-up (if they tried one and you want them to continue):**

> Hi [name], hope you enjoyed the salad bag this week. I'm doing the same again next [day] — same price, and this week it will include [crop]. Would you like one again? Just let me know by [day].

---

## 2. Farmers market organisers

**Use for:** an email or a message to the market organiser, after visiting the market as a customer.

> Subject: New grower enquiry — [your area]
>
> Hello, my name is [your name] and I grow vegetables on [size] of growing space in [area]. I'd like to apply for a stall at [market name] this season. I grow salad leaves, herbs, tomatoes, and root vegetables, all picked the morning of the market and grown without synthetic pesticides. Could you tell me about stall availability, fees, and any rules I need to know? I'm hoping to start from [date] and can commit to [every week / fortnightly]. Thank you — [your name], [phone], [email].

**If there is a waiting list:**

> Thank you for letting me know. Could you add me to the waiting list, and is there a half stall, a shared stall, or a occasional-stall option in the meantime? I'm happy to start small.

---

## 3. Restaurants and cafés

**Use for:** a short visit in the quiet part of the day (mid-afternoon), bringing a sample. Ask for the chef or the buyer. Keep it under two minutes.

> Hi, I'm [your name] — I grow [herbs / salad leaves / microgreens] a few miles from here, in [area]. I brought a sample for the chef. I can supply [crop] at $[price] per [unit], delivered on [day] each week, in quantities of [amount]. Here's a one-page price list with my contact details. If you'd like to try a small order next week, I'll bring it on [day] — no commitment beyond that. Thank you for your time.

**Follow-up (one week later, by phone or in person):**

> Hi, it's [your name] — I dropped off a sample of [crop] last week. I just wanted to check whether it was useful, and whether you'd like a small trial order this week. I can deliver [quantity] on [day] at $[price]. If the timing isn't right, no problem — I'm here through the season.

**If they say yes:**

> Thank you. I'll deliver [quantity] of [crop] on [day] at [time]. I'll confirm by text the day before. If anything changes on my side — weather, a crop problem — I'll tell you as soon as I know, not on the delivery day.

---

## 4. CSA (community-supported agriculture) subscribers

**Use for:** a post in a local group, a flyer, or an email to people who have shown interest.

> Join my weekly veg box — grown in [area], picked the morning you collect it.
>
> I'm [your name], and I grow salad, herbs, tomatoes, and seasonal vegetables on [size] of growing space in [area]. This season I'm offering [number] weekly boxes for [number] weeks, starting [date].
>
> Each box costs $[price] a week and includes a mix of what's in season — usually salad leaves, herbs, and two or three other vegetables. You collect from [place] on [day], between [times].
>
> A veg box is a shared-risk arrangement: if one crop has a bad week, your box will have more of another. What I promise is a full, fresh box every week, grown without synthetic pesticides, and picked the same day.
>
> To join, message me by [date] — payment is upfront / in two instalments. There are [number] places, and I'll confirm yours as soon as I hear from you. Thank you — [your name], [phone / email].

---

## 5. Following up a missed delivery or a problem

**Use for:** the moment you know something has gone wrong — not on the delivery day.

> Hi [name], it's [your name]. I wanted to let you know early that [the basil has been hit by a cold night / the lettuce is behind by a few days], so this week's box will have [substitute] instead of [crop]. I'm sorry about the change — the rest of the box is as planned, and [crop] should be back next week. If you'd rather skip this week, that's fine — just let me know. Thank you for understanding.

---

## 6. Asking a happy customer for a referral

**Use for:** a regular customer who has bought from you several times.

> Thank you for buying from me this season — it genuinely makes a difference to a small grower. If you know a neighbour, a friend, or a local café who might like a weekly bag or box, I'd be grateful if you'd pass on my details. I'm keeping it small on purpose, so I can only take on a few more regulars — but I'd love to meet them if they're interested.
