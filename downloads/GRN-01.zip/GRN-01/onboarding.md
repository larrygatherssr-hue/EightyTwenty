# Customer Onboarding — The Profitable Urban Farm Blueprint

Welcome, and thank you for purchasing The Profitable Urban Farm Blueprint. This guide tells you what to do first, how to use the materials, and how to get help.

## What you received

| File | What it is |
|---|---|
| `content.md` | The complete 11-module course — read or watch it in order the first time. |
| `workbook.md` | The companion workbook — worksheets for every stage of the season. |
| `templates/crop-profitability-calculator.csv` | 18 crops with yield, price, revenue, cost, and profit per square foot. |
| `templates/planting-calendar.md` | Season planning template by frost date, with succession intervals. |
| `templates/buyer-outreach-scripts.md` | Scripts for neighbours, markets, restaurants, and CSA subscribers. |
| `templates/pricing-sheet.md` | Local price research and cost-plus pricing worksheet. |
| `sales-page.md` | The sales page for this product (for reference). |
| `cover.md` | The cover design brief. |
| `listing.json` | The marketplace listing data. |

## What to do first (your first hour)

1. **Read the Introduction and Module 1** of `content.md`. Do not skip ahead to crop lists — your space and sunlight decide everything else.
2. **Measure your space.** Go outside with a tape measure and fill in Worksheet 1 (Space Assessment) in the workbook. Note your sun hours, water source, and any weight or building rules.
3. **Check your local rules.** One quick check with your city council or market organiser: can you sell home-grown produce, and do you need a permit or registration? Write the answer in Worksheet 1.
4. **Write down your frost dates.** Your last frost in spring and your first frost in autumn. Your local extension service or nursery can confirm them. Enter them in Worksheet 3 (Planting Calendar).

## How to use the materials

- **Work through the modules in order** the first time. Modules 1–3 are the foundation; Modules 7–8 are the business half. Do the action steps at the end of each module before moving on.
- **Fill in the workbook as you go**, not at the end. A worksheet completed with your own numbers is the difference between a course you read and a business you started.
- **Use the calculator before you order seeds.** Replace the example prices in `crop-profitability-calculator.csv` with prices from your local market or shops, and only plant crops that clear a profit per square foot that justifies their space.
- **Do the buyer work before you plant.** Use the scripts in `templates/buyer-outreach-scripts.md` and the tracker in Worksheet 5. A crop without a named buyer is a risk, not a plan.

## Suggested schedule

- **Weeks 1–2:** Modules 1–2. Measure, map, test soil, build beds or containers, set up watering.
- **Weeks 3–4:** Modules 3–4. Research local prices, run the calculator, choose your crop mix, build your planting calendar, order seeds.
- **Weeks 5–6:** Modules 5–6. Learn your local pests and diseases, set up mesh and row cover, prepare your harvest kit.
- **Weeks 7–8:** Modules 7–8. Set prices, approach buyers, confirm your sales channel.
- **Weeks 9–10:** Modules 9–10. Set your weekly rhythm, start the profit-and-loss worksheet, begin selling.
- **Week 11:** Module 11. Review the season so far and plan what to scale, drop, or trial next season.

If you are starting mid-season, jump to Module 4 to plan what can still go in, then circle back to Modules 1–3. If you are starting in winter, the 11-week pace puts you at planting time with a plan, a calendar, and buyers already lined up.

## A realistic expectation

The first season is about learning and breaking even, not getting rich. A realistic goal on roughly 100 square feet is to cover your costs and end up a little ahead, while building the soil, skills, and customer list that make the second season stronger. Track your hours and your costs honestly — the numbers in Worksheet 6 are what turn a good season into a better next one.

## How to get support

If you have a problem with your order or the course files, email the marketplace support address with your order number and a description of the issue, and the support team will respond. Please include the file name if the problem is with a specific file.

## Refund policy

14-day money-back guarantee. If you are not satisfied within 14 days of purchase, contact support with your order number for a full refund, no questions asked.
