# The Profitable Urban Farm Blueprint

## Turn a Small Plot into Real Income — Grow the Right Crops and Sell Them Before You Plant

---

## Introduction: What This Course Is — and What It Is Not

This course is for city dwellers and side-hustlers who want to earn income growing food in small urban spaces: a backyard, a rooftop, a balcony, a rented allotment plot, or a shared community garden bed. It is not a gardening hobby course. It is a small-business course that happens to use plants as its product.

That distinction matters, because the two kinds of growing fail in different ways. A hobby gardener fails when a plant dies. A market grower fails when a plant lives but nobody buys it. Most aspiring urban growers know how to plant. Far fewer know how to choose crops that pay, line up buyers before the seed goes in, price honestly, and keep records that show whether the season actually made money. This course closes that second gap.

You will not find promises of easy riches here. Urban growing is real work, the margins are modest, and the first season is mostly about learning your space, your climate, and your customers. A realistic goal for a first season on roughly 100 square feet of growing space is to cover your costs and end up a little ahead — perhaps a few hundred dollars of profit — while building the skills, soil, and customer list that make the second season stronger. Growers who treat the first season as a paid education, rather than a payday, are the ones who are still selling in year three.

Everything in this course is written to be used, not admired. Each module ends with actions to take. The companion workbook gives you the worksheets to do them on. The templates give you a crop profitability calculator, a planting calendar, buyer outreach scripts, and a pricing sheet you can start using this week — before you buy a single seed.

### How to use this course

Work through the modules in order the first time. Modules 1 and 2 are about your space and your soil — skip them and everything else rests on guesswork. Module 3 is the heart of the course: choosing crops by profit per square foot, not by what looks nice in a catalogue. Modules 7 and 8 are the other half of the heart: pricing and finding buyers before you plant. Do not plant a commercial crop until you have done Module 8's buyer work for that crop.

A suggested pace is one module per week for eleven weeks, with the practical work done alongside. If you are starting in winter, that pace puts you at planting time with a plan, a calendar, and buyers already lined up. If you are starting mid-season, jump to Module 4 to plan what can still go in, then circle back.

### A note on numbers

Every number in this course is a realistic range, not a guarantee. Yields vary with climate, sunlight, soil, variety, and your own skill, which improves every season. Prices vary with your city, your market, and your customer. Where this course gives a figure, it gives a range and explains what moves it up or down. Never build a plan on the top of a range. Build it on the middle, and treat anything above that as a bonus.

---

## Module 1: Assessing Your Space and Sunlight

Before you spend a dollar on seeds or soil, you need an honest picture of what you actually have. Most urban growing failures are not caused by bad luck. They are caused by planting a sun-hungry crop in a spot that gets four hours of light, or by trying to grow forty square feet of vegetables on a balcony that holds twelve.

### Measuring your space

Start with a tape measure, a notebook, and an hour of your time. Measure every surface you could plausibly grow on: the backyard, the side strip beside the house, the flat part of the roof, the balcony, the patio, the windowsills. Write down length and width for each, and multiply to get square feet. Then subtract the space you cannot use — the path you need to walk, the area under the dripping gutter, the corner the dog claims. What is left is your real growing area.

Most beginners are surprised twice: first by how small the number is, and then by how much food a small number can produce when it is planted well. One hundred square feet of beds, managed in succession through a season, can produce a meaningful amount of food and a modest income. Ten square feet on a balcony can produce high-value herbs and salad leaves worth selling to a neighbour or a local café. The point is not to wish for more space. It is to know exactly how much you have, so every later decision — which crops, how many, what to charge — is built on a real number.

Draw a simple sketch of your space. Mark north, mark the house, the fences, the trees, and any structure that casts shade. You will use this sketch all season. Take a photograph of it and keep it with your workbook.

### Sunlight: the one input you cannot buy

Sunlight is the single biggest determinant of what you can grow, and the one you have least control over. Most vegetables need a minimum amount of direct sun — sunlight that falls straight on the leaves, not filtered through a tree or bounced off a wall.

- **Full sun (6+ hours of direct sun):** tomatoes, peppers, eggplant, squash, cucumbers, beans, corn, most fruiting crops.
- **Part sun (4–6 hours):** leafy greens, herbs, peas, beets, carrots, radishes, broccoli, cabbage.
- **Part shade (3–4 hours):** lettuce, spinach, chard, kale, mint, parsley, chives.
- **Deep shade (under 3 hours):** very little grows well enough to sell. Microgreens indoors under a grow light are a better use of that space.

To measure your sun, do a sun map. On a clear day, check each growing area once an hour from about 8 a.m. to 6 p.m. and note whether it is in direct sun or shade. Do this once in the season you plan to grow in, because the sun's path changes dramatically between spring and midsummer — a spot that is sunny in May can be shaded by a neighbour's tree in July, and a spot that is shady in March can be full sun by June. If you can only do one sun map, do it in late spring, when most of your crops will be growing.

A simpler version that still works: photograph each area at 9 a.m., noon, and 3 p.m. on a sunny day. The three photographs tell you most of what you need.

### Water, access, and weight

Three practical questions decide whether a space is usable, whatever the sun says.

**Water.** How far is the nearest tap, and can you run a hose or carry a watering can to the beds without a daily struggle? A bed that is hard to water gets watered late or not at all, and inconsistent watering is the most common cause of bitter lettuce, split tomatoes, and stunted growth. If the tap is far away, budget for a hose, a rain barrel, or a drip system early — it pays for itself in saved crops.

**Access.** Can you reach every part of each bed without stepping on the soil? Beds wider than about 4 feet (1.2 metres) are hard to work from one side; keep beds to 3–4 feet wide with paths between them. Can you carry a harvest basket, a bag of compost, and a crate of produce in and out without a fight? If the only route is through the living room, you will dread harvest day.

**Weight.** This matters most on rooftops and balconies. Wet soil is heavy — a cubic foot of saturated potting mix weighs roughly 60–75 pounds (27–34 kg). A balcony rated for people and furniture may not be rated for a dozen large planters full of wet soil. Check your building's rules and, if you are unsure, ask the building manager or a structural engineer before loading a roof or balcony. Never assume. A collapsed balcony is not a gardening problem; it is a safety disaster. If weight is limited, use lightweight containers, soilless mixes with perlite or coir, and shallow-rooted crops such as lettuce and herbs.

### Renting and sharing space

If you have no growing space of your own, rented plots and community gardens are a real option. Allotment plots, community garden beds, and private garden-sharing arrangements exist in most cities. Before you commit, check four things: the annual cost, the rules about selling what you grow (some community gardens forbid commercial sales), the water arrangements, and the waiting list. A plot that costs $50 a year and allows sales is a good deal; a plot that costs $200 and forbids selling is a hobby, not a business, and should be judged as one.

Also check your local rules. Some cities restrict selling produce grown at home, require a permit for a market stall, or have rules about rooftop structures. A quick call to your city council or a search of its website usually settles the question in an afternoon. Do this before you invest, not after.

### Your space inventory

By the end of this module you should be able to write down, without guessing: your total growing area in square feet, the sun hours for each area, your water source, your access route, and any weight or rule limits. That inventory is the foundation of the whole course. Fill in the space-assessment worksheet in the workbook now, before moving on.

**Module 1 actions:**
1. Measure every growing surface and sketch your space.
2. Do a sun map on a clear day (or take the three photographs).
3. Confirm your water source, access, and any weight or building rules.
4. Check local rules on selling home-grown produce.
5. Complete the space-assessment worksheet in the workbook.

---

## Module 2: Soil, Containers, and Water Basics

Good soil is the cheapest productivity tool you own. A bed with living, well-fed soil will out-produce a bed with tired dirt by a wide margin, using the same seeds and the same sun. This module covers what soil needs to be, how to build it cheaply, how to grow in containers when you have no ground at all, and how to water in a way that keeps plants productive instead of stressed.

### What good soil is

Healthy garden soil has four qualities: it holds moisture without staying soggy, it drains well enough that roots can breathe, it contains enough organic matter to feed plants and soil life, and it is loose enough for roots to push through. Most urban soil fails on at least one of these. City soil is often compacted from construction, low in organic matter, and sometimes contaminated with rubble, old paint, or other waste.

Before you plant food in ground you did not build yourself, consider a soil test. Many local agricultural extension services and garden centres offer basic tests for a modest fee, usually covering pH, major nutrients, and organic matter. A lead test is worth the money if your soil is near an old painted building, a busy road, or a former industrial site. If lead or other contamination is a concern, do not grow food directly in that ground — grow in raised beds or containers with imported soil instead. Your health is worth more than a season of vegetables.

Soil pH matters because it controls whether plants can take up the nutrients that are present. Most vegetables do best in soil with a pH between 6.0 and 7.0 — slightly acidic to neutral. A basic test will tell you where you stand. If your soil is very acidic (below 5.5), garden lime raises pH gradually. If it is very alkaline (above 7.5), adding compost and, where appropriate, sulphur can bring it down. Change pH slowly; a big sudden correction causes more problems than the original imbalance.

### Building soil cheaply

The fastest way to improve almost any soil is compost. Finished compost adds organic matter, feeds the microbes that make nutrients available to plants, improves drainage in clay and water-holding in sand, and buffers pH. You do not need a perfect compost system. A simple heap of kitchen scraps, leaves, and grass clippings, turned occasionally, produces usable compost in a few months. If you cannot make your own yet, buy compost by the bag or in bulk from a local supplier — bulk is far cheaper per volume if you can take delivery.

A practical starting recipe for a new raised bed: fill it with a mix of roughly 60 percent topsoil, 30 percent compost, and 10 percent perlite or coarse sand for drainage. Top it up each season with 1–2 inches (2.5–5 cm) of fresh compost before planting. That annual top-dressing is the single highest-return habit in this course.

Do not till your beds into dust every season. Digging breaks up soil structure and the fungal networks that help plants feed. Loosen the top few inches with a fork, add compost on top, and let the worms and rain do the mixing. This approach, often called no-dig, saves your back and improves the soil year on year.

### Raised beds

Raised beds are the default for urban growers, and for good reason. They warm up faster in spring, drain better than ground-level soil, keep the growing area defined, and let you control exactly what soil your food grows in. A bed 4 feet wide, 8 feet long, and 10–12 inches deep is a good standard size: wide enough to be productive, narrow enough to reach the middle from either side, and deep enough for most vegetables.

You can build a bed from untreated timber, stone, brick, or even stacked logs. Avoid treated timber that uses old-style preservatives, and avoid railway sleepers of unknown origin. The cheapest option is often scaffold boards or reclaimed timber from a local yard. Line the bottom with cardboard to suppress weeds, then fill with your soil mix. A bed this size holds roughly 27 cubic feet of soil — about one cubic yard — so budget for that volume when buying soil and compost.

### Containers

Balconies, patios, and rooftops run on containers. The rules are simple: the bigger the container, the better the result. A tomato in a 5-gallon pot will produce; the same tomato in a 1-gallon pot will struggle and need watering twice a day. As a guide: lettuce and herbs do well in 1–2 gallon pots; peppers and bush beans need 3–5 gallons; tomatoes, cucumbers, and squash need 5–10 gallons.

Use proper potting mix, not garden soil, in containers — garden soil compacts in pots and drains badly. Good potting mix is mostly peat or coir, perlite, and compost. Containers dry out fast, especially in sun and wind, so mulch the surface with straw or wood chips and check moisture daily in summer by pushing a finger an inch into the mix. If it is dry at that depth, water. Self-watering planters with a reservoir are worth the extra cost for anyone who works away from home all day.

Make sure every container has drainage holes. Roots sitting in standing water rot, and a pot without drainage is a plant funeral. Put a saucer underneath if you are on a balcony, but empty it after watering so the roots are not sitting in water.

### Watering well

Most vegetables need roughly 1 inch (2.5 cm) of water per week from rain and irrigation combined, more in hot or windy weather, more again in containers. The goal is deep, infrequent watering that encourages roots to grow down, not shallow daily sprinkles that keep roots at the surface.

Water in the morning when you can. The leaves dry during the day, which reduces fungal disease, and the plants have water available for the hottest part of the afternoon. Water the soil, not the leaves — a watering can aimed at the base, a soaker hose, or a simple drip line all do this. Overhead sprinklers waste water and invite disease.

Drip irrigation is the best investment a small grower can make after compost. A basic kit — a timer, a main line, and drip emitters — costs little, waters while you are at work, and uses far less water than a hose. It also keeps the foliage dry, which cuts disease sharply. If you can only buy one piece of equipment this year, make it a drip kit and a timer.

Mulch is the other half of watering. A 2–3 inch layer of straw, shredded leaves, or wood chips on the soil surface cuts evaporation, suppresses weeds, keeps soil temperature steady, and breaks down into organic matter. Mulch after the soil has warmed in spring, and keep it a couple of inches away from plant stems to avoid rot.

### Your first-season soil plan

Do not try to fix everything in year one. Test if you can, add compost generously, build or fill your beds, set up your watering, and mulch. The soil will be better in year two than year one, and better again in year three. Soil improvement compounds — that is one of the quiet advantages of staying in the same space and building it up.

**Module 2 actions:**
1. Get a basic soil test if you are growing in existing ground; add a lead test if contamination is possible.
2. Source compost — make it, buy bags, or arrange a bulk delivery.
3. Build or prepare your beds or containers with a proper soil mix.
4. Set up watering (hose or drip + timer) and mulch your beds.
5. Note your soil plan in the workbook setup checklists.

---

## Module 3: Choosing High-Value Crops

This is the module that makes or breaks your income. Most new growers choose crops by habit or affection — tomatoes because everyone grows tomatoes, or carrots because they like carrots. A market grower chooses crops by profit per square foot, by how fast they turn over, and by whether a buyer is waiting. This module teaches you to make that calculation for your own space and market.

### The measure that matters: profit per square foot

A crop's value to you is not its price per pound. It is how much money it earns from each square foot of your limited space, after costs, over the time it occupies that space. The formula is simple:

**Revenue per sq ft = yield per sq ft × price per unit**
**Profit per sq ft = revenue per sq ft − cost per sq ft**

A crop that yields 2 pounds per square foot and sells for $3 a pound earns $6 per square foot. A crop that yields half a pound per square foot and sells for $8 a pound earns $4 per square foot. The expensive crop is not always the better earner — yield matters as much as price.

Time matters too. A crop that earns $6 per square foot in three weeks (radishes, salad leaves) can be replanted several times a season, earning that $6 again and again from the same ground. A crop that earns $8 per square foot but occupies the bed for four months earns less per week. Always divide by the weeks the crop occupies the bed to compare fairly.

The crop profitability calculator in the templates folder does this arithmetic for you. Use it. Guessing at profitability is how growers spend a season tending a crop that was never going to pay.

### Crop categories, honestly assessed

**Leafy greens and salad mixes.** Lettuce, spinach, chard, kale, arugula, and mixed salad leaves are the backbone of most profitable small urban farms. They grow fast (30–50 days to harvest), can be cut repeatedly, occupy little space, and sell at good prices per pound because they are light, perishable, and best fresh — exactly what local buyers pay a premium for. A square foot of salad mix can yield roughly 0.5–1 pound per cutting, with several cuttings per planting, at $6–$10 per pound at a farmers market or direct sale. Their weakness is perishability: they must be sold within a day or two of harvest, so they depend on having buyers lined up. They also need steady water — dry spells make them bitter and bolt early.

**Herbs.** Basil, cilantro, parsley, dill, mint, and chives earn the highest revenue per square foot of any common crop, because they sell by the small bunch at a high price per pound. A square foot of basil can yield several bunches over a season at $2–$3 a bunch. They take little space, grow fast, and restaurants and market customers buy them weekly. Their weakness is volume: a customer buys one bunch, not ten pounds, so you need many customers or a restaurant buyer to move a large planting. Basil is also frost-sensitive and needs warm weather.

**Microgreens.** Shoots of radish, pea, sunflower, and broccoli, harvested 7–14 days after sowing, grown indoors or in a sheltered spot on trays. They sell for $15–$30 per pound because they are intensely flavoured, highly perishable, and labour-intensive to grow well — and because restaurants and health-conscious buyers pay for them. They need almost no space, no soil, and no season: you can grow them year-round. Their weakness is labour and consistency: trays need daily attention, and a failed batch is a lost week. They also need a buyer who orders every week, because a tray that is ready today is overgrown in three days.

**Root vegetables.** Carrots, beets, radishes, and turnips store well, are easy to sell, and are forgiving to grow. Radishes are fast (25–30 days) and earn well per square foot for their speed. Carrots and beets take longer (60–80 days) and earn less per square foot than greens, but they keep for weeks after harvest, which makes selling far less stressful. Their weakness is yield per square foot: a square foot of carrots produces roughly 1–2 pounds per season, at $2–$3 a pound, which is modest compared with salad leaves.

**Fruiting vegetables.** Tomatoes, peppers, cucumbers, squash, and beans. Tomatoes are the classic market crop and the one customers ask for first — a ripe, flavourful tomato sells itself. A productive tomato plant can yield 10–20 pounds over a season. But tomatoes need full sun, a long warm season, staking, pruning, and disease management, and they occupy a bed for months. Cherry tomatoes earn better per square foot than large slicing tomatoes, because they yield heavily, ripen earlier, and sell by the punnet at a good price. Peppers earn well but are slow and heat-loving. Cucumbers and squash yield heavily but take a lot of space — one squash plant can swallow four square feet — so they are a poor choice for a small plot unless you grow them vertically.

**High-value specialities.** Garlic, shallots, edible flowers, and hot peppers earn well per square foot and store or keep well, but they are slower or more specialised. Garlic is planted in autumn and harvested the following summer — nine months in the ground for one harvest — but it earns roughly $8–$12 per pound and stores for months. Edible flowers sell for high prices to restaurants but need a buyer before you plant them, because the market is small and specific.

### What not to grow for income

Some crops are wonderful to eat and terrible to sell from a small space. Sweetcorn takes a large block to pollinate properly and earns very little per square foot. Pumpkins and winter squash swallow space for months for a low-value harvest. Potatoes yield a lot of weight but sell for $1–$2 a pound, so the revenue per square foot is low, and digging them disturbs the bed. Cabbages and broccoli take months and a square foot each for a single head. Grow these for your own table if you enjoy them — but do not build your income plan on them.

### Choosing your crop mix

A sensible first-season mix for 100 square feet might look like this:

- **40 sq ft salad leaves and greens** (succession-planted, cut-and-come-again) — your steady weekly earner.
- **20 sq ft herbs** (basil, parsley, cilantro in rotation) — your highest revenue per square foot.
- **20 sq ft cherry tomatoes and peppers** (vertical, warm season) — your customer magnet.
- **10 sq ft radishes and beets** — fast and storable, filling gaps between slower crops.
- **10 sq ft trial crop** — one new thing each season (microgreens, edible flowers, garlic) to test a market without betting the season on it.

That mix gives you something to sell every week from early summer onward, spreads your risk across crops with different weaknesses, and leaves you room to learn. Do not plant all of one thing. A single crop failure — a pest, a heatwave, a buyer who cancels — should cost you a slice of the season, not the whole season.

### Varieties matter

Within every crop, variety choice changes yield and price. A cherry tomato bred for heavy production and disease resistance will out-earn a pretty heirloom that splits and succumbs to blight — even though the heirloom tastes better and sells at a higher price per pound. For a first season, choose reliable, disease-resistant varieties with a track record in your region. Ask at a local nursery or extension service which varieties do well in your area; local knowledge beats a catalogue description every time. Once you have a working system, you can experiment with premium varieties and charge for them.

### The calculator habit

Before you order seeds, run every candidate crop through the crop profitability calculator with your own local prices. Look up what salad, basil, tomatoes, and radishes actually sell for at your local market or grocery store, and use those prices — not prices from a book or another city. If a crop does not clear a profit per square foot that justifies its space and your time, do not plant it for sale. Plant it for yourself, or not at all.

**Module 3 actions:**
1. Research local prices for at least 8 candidate crops.
2. Run each through the crop profitability calculator.
3. Choose your first-season mix (no more than 6–8 crops) and write it in the crop-selection worksheet.
4. Order seed of reliable, locally proven varieties.
5. Reserve 10 percent of your space for one trial crop.


---

## Module 4: Succession Planting and Season Planning

One planting is a harvest. Succession planting is a business. The difference is planning so that something is always ready to pick, every week, for as long as your season allows — instead of a single glut in July followed by empty beds in August.

### Know your dates

Three dates govern your season. Write them down before you plan anything:

1. **Your last frost date in spring** — the average date after which frost is unlikely. Tender crops (tomatoes, peppers, basil, squash) go out after this date.
2. **Your first frost date in autumn** — the average date when frost returns. Tender crops end here; hardy crops keep going.
3. **The length of your growing season** — the days between those two dates. In many temperate cities this is roughly 150–180 days; in warmer cities it can be 200+ days, and in cooler ones under 120.

Your local extension service, a nearby nursery, or a gardening neighbour will know these dates. They are averages, so keep frost cloth on hand for a late cold snap — a $20 roll can save a $200 planting.

### Succession: the core technique

Succession planting means sowing the same crop in small batches every 1–3 weeks, instead of all at once. Lettuce sown on May 1, May 15, and June 1 gives you three staggered harvests instead of one pile of lettuce that all bolts in the same week. Radishes sown every 10 days give you a continuous supply all season.

As a rule of thumb, sow fast crops (radishes, salad leaves, spinach) every 10–14 days, medium crops (beets, beans, cilantro) every 2–3 weeks, and slow crops (carrots, kale) every 3–4 weeks. Stop sowing each crop when its days-to-maturity, counted forward from the sowing date, would land after your first frost — or, for heat-sensitive crops like lettuce, when the hottest part of summer arrives.

### Intercropping and relay planting

Succession is one way to keep beds full; intercropping and relay planting are the others. **Intercropping** means growing a fast crop alongside a slow one — radishes sown between rows of carrots, for example. The radishes are harvested in a month, long before the carrots need the space. **Relay planting** means sowing the next crop before the current one finishes — sowing beans where the spring peas are fading, so the bed is never empty.

A bed that is replanted the same week it is harvested earns roughly twice what a bed that sits empty for a month earns. That single habit — always having the next sowing ready — is worth more than any fertiliser.

### Planning the season on paper

Before the season starts, build a simple season plan. List each crop, its sowing dates, its transplant date (if started indoors), its expected first harvest, and its expected end. The planting calendar template in this course gives you the structure. A realistic season for a temperate city might look like this:

- **Early spring (6–8 weeks before last frost):** start tomatoes, peppers, and eggplant indoors under lights. Sow peas, spinach, and radishes outdoors as soon as the soil can be worked.
- **Spring (around last frost):** transplant hardy greens; sow lettuce, beets, carrots, and herbs in succession.
- **After last frost:** transplant tomatoes, peppers, basil, squash, cucumbers, and beans.
- **Midsummer:** keep sowing salad leaves and radishes every two weeks; sow a second round of beans; start autumn crops (kale, chard, spinach) indoors or in a shaded spot.
- **Late summer:** transplant autumn greens; sow garlic in autumn for next summer's harvest.
- **Autumn:** harvest the last tomatoes; keep cutting kale and chard until hard frost; clear and mulch beds.

Keep a garden diary — even a few lines a week — noting sowing dates, first harvests, weather, and problems. After one season, your diary is the most valuable planning document you own, because it is written for your exact space and climate.

### Starting seeds indoors

Starting seeds indoors gives you a head start of 4–8 weeks on tender crops, which can mean the difference between a full harvest and green tomatoes at first frost. You do not need an expensive setup: a sunny windowsill works for a few plants, and a simple shop light hung over a table works for many. What matters is strong light close to the seedlings (a few inches above them), consistent moisture, and good air movement. Leggy, pale seedlings come from too little light — move the light closer or add a second one.

Start seeds in small cells or pots with seed-starting mix, water from below, and thin to one strong seedling per cell. Harden seedlings off before transplanting — set them outside for a few hours a day over a week, increasing the time — or the shock of sun and wind will set them back by weeks.

### Extending the season

Simple season extension turns a 150-day season into a 200-day one. Floating row cover (lightweight fabric) protects seedlings from light frost and warms the soil by a few degrees. A cold frame — a bottomless box with a clear lid — lets you grow salad leaves weeks earlier in spring and weeks later in autumn. A small unheated hoop house or polytunnel, if your space and rules allow it, is the biggest single step up a small grower can take: it protects crops from rain, wind, and frost, and lets you sell weeks before and after outdoor growers. None of these need to be expensive to start; a row cover and a cold frame built from old windows will do for year one.

### A realistic season plan

Do not plan a perfect season. Plan a workable one, with slack in it. Leave one bed unassigned at the start of the season — it will absorb the crop that fails, the trial you want to try, or the late sowing you forgot. Build in a week off in midsummer if you can; burnout in August kills more small farms than pests do. And remember that the first season's plan is a draft. The second season's plan, corrected by your diary, will be far better.

**Module 4 actions:**
1. Write down your last frost, first frost, and season length.
2. Build your planting calendar for the season using the template.
3. Set up a seed-starting spot (windowsill or shop light) if you are growing tender crops.
4. Buy row cover and plan at least one season-extension measure.
5. Start a garden diary and keep it going all season.

---

## Module 5: Pest and Disease Management Without Harsh Chemicals

Pests and disease are inevitable. The goal is not a garden with no insects — that is neither possible nor desirable — but a garden where pest damage stays below the level that costs you sales. The approach in this module is integrated pest management: prevention first, observation second, and targeted, low-impact action only when it is needed.

### Prevention is the cheapest control

Most pest and disease problems are prevented by the decisions you made in Modules 1–4, before any pest appears:

- **Healthy soil and plants.** A well-watered, well-fed plant resists pests far better than a stressed one. Inconsistent watering and overcrowding are the two biggest invitations to trouble.
- **Spacing and airflow.** Plants packed tightly together stay damp, and damp foliage is where fungal disease starts. Give plants the spacing the seed packet recommends, prune tomatoes to let air through, and water at the base, not on the leaves.
- **Rotation.** Do not plant the same family in the same bed year after year. Tomatoes, peppers, and eggplant are one family (nightshades); cabbage, kale, and broccoli are another (brassicas); carrots and parsley are a third. Rotating families breaks the cycle of soil-borne disease and pests that build up around one crop. Even a simple three-bed rotation — nightshades, brassicas, and everything else — is a big improvement over planting tomatoes in the same spot every year.
- **Diversity.** A bed with five crops supports a wider range of insects, including the predators that eat pests, than a bed with one crop. Mixed planting also slows disease spread: a fungus that jumps easily from tomato to tomato stalls when the next plant is basil.

### Know your common pests

You do not need to identify every insect. Learn the handful that cause most of the damage in your area:

- **Aphids:** small green or black clusters on new growth, sucking sap and spreading disease. Often controlled by a strong jet of water, or by ladybirds and lacewings that eat them. A heavy infestation can be treated with insecticidal soap — a low-impact option that does not persist in the environment.
- **Slugs and snails:** worst in damp weather and on young seedlings. Hand-pick at dusk, use beer traps or copper tape around vulnerable beds, and keep mulch pulled back from stems. A board laid on the soil overnight gives slugs a place to hide — lift it in the morning and remove them.
- **Caterpillars and cabbage white butterflies:** the white butterfly lays eggs on brassicas; the caterpillars eat the leaves. Cover brassicas with fine insect mesh from the day they are planted, and hand-pick any caterpillars you find. Mesh is the most reliable control and uses no spray at all.
- **Flea beetles:** tiny black beetles that pepper small holes in leaves of radishes, arugula, and young brassicas. Row cover from sowing prevents them; healthy plants usually outgrow the damage.
- **Squash bugs and cucumber beetles:** harder to control once established. Hand-pick adults and eggs (check leaf undersides), use row cover early in the season, and remove badly infested plants rather than letting them spread the problem.

### Diseases: the big three

- **Damping off** kills seedlings at the soil line. Prevent it with clean pots, fresh seed-starting mix, good airflow, and watering from below. There is no cure once it starts; remove affected seedlings immediately.
- **Powdery mildew** appears as white powder on leaves, especially squash, cucumbers, and peas in late summer. Improve airflow, avoid overhead watering, and remove badly affected leaves. A spray of diluted milk or baking soda solution can slow it, but prevention is far more effective.
- **Blight** (on tomatoes and potatoes) is the most serious disease for urban growers. It spreads in warm, wet weather and can destroy a crop in days. Prevent it by spacing plants for airflow, watering at the base, mulching to stop soil splashing onto leaves, and choosing resistant varieties. Remove any plant that shows the dark, spreading leaf spots of blight, and do not compost it — bag it and dispose of it with household waste.

### The observation habit

Walk your beds at least twice a week, and look at the undersides of leaves, not just the tops. Most pest problems are cheap to fix when they involve ten insects and expensive when they involve ten thousand. The walk takes ten minutes and is the highest-return routine in this module. Keep a note of what you see and when — patterns emerge over a season, and next year you will know which pest arrives in which week and can cover or act before it does.

### What about sprays?

This course recommends avoiding harsh chemical pesticides and herbicides. They kill the beneficial insects that do most of your pest control for free, they can leave residues on food you intend to sell, and many customers at farmers markets actively choose growers who do not use them. That is a selling point — but only if it is true, so never claim "pesticide-free" or "organic" unless you meet the legal definition in your area. "Grown without synthetic pesticides" is a safer, honest claim if that is what you do, and "organic" should only be used if you are certified or your local rules allow the term for uncertified growers.

When you do need to act, start with the least disruptive option: hand-picking, water jets, barriers and mesh, traps, and insecticidal soap or neem oil for specific problems. Read the label, apply in the evening when pollinators are less active, and never spray a crop the day before harvest — observe the waiting period on the label.

### Accepting some loss

A realistic expectation is to lose 5–15 percent of a crop to pests and disease in a normal season. Budget for it. Plant 10 percent more than you need to sell, so losses do not leave you short on orders. A grower who expects perfection will spray too much, too late, and too often. A grower who plans for some loss keeps the system healthy and the produce clean.

**Module 5 actions:**
1. Learn the five pests and three diseases most common in your area.
2. Put insect mesh on brassicas and row cover on vulnerable crops.
3. Set up a twice-weekly bed walk and a pest diary.
4. Plan your rotation for next season now, while this season's planting is fresh in your mind.
5. Decide and write down your spray policy — what you will and will not use — so you can state it honestly to customers.

---

## Module 6: Harvesting and Post-Harvest Handling

The sale is won or lost after the picking. Produce that is harvested at the right time, handled gently, cooled quickly, and kept clean looks better, tastes better, and lasts longer — and customers come back for it. Produce that is picked too late, bruised, or left warm in the sun wilts, spoils, and costs you repeat buyers.

### Harvest at the right time

Harvest in the morning, after the dew has dried but before the heat of the day. Plants are crisp and full of water in the morning; by afternoon they have lost moisture and are more likely to wilt. For leafy greens, morning harvesting is the single easiest quality improvement you can make.

Learn the harvest window for each crop. Lettuce and salad leaves are best picked young and tender — overgrown lettuce is bitter. Radishes become woody and hot if left too long. Beans are best picked when the pods are slender and the seeds inside are still small. Tomatoes should be picked when fully coloured but still firm — a tomato left on the vine until soft will split or attract pests. Herbs are most flavourful when picked before they flower. When in doubt, pick a little early rather than a little late: most vegetables are better young than old.

Cut, do not pull. Use a sharp knife or scissors for greens and herbs — tearing damages the plant and shortens its life for repeat cuttings. For cut-and-come-again lettuce, cut about an inch above the base and the plant will regrow for a second and third cutting. Handle everything as if it bruises — because it does, even when the bruise does not show until the customer opens the bag.

### Cooling and washing

Field heat is the enemy. Get harvested produce into shade immediately, and into a cool place as soon as you can. A cool box with ice packs, a shaded porch, or a refrigerator all work. Greens that are cooled within an hour of picking last days longer than greens left in the sun.

Wash gently and only as much as needed. A rinse in clean, cool water removes soil and most field dirt. Do not wash produce hours before sale and then leave it wet — wet greens in a closed bag rot quickly. Wash, spin or shake dry (a salad spinner is a good investment), and store in a breathable bag or container. Root vegetables can be brushed clean rather than washed, and they store better unwashed.

Use clean water, clean containers, and clean hands. This is not just good practice — it is food safety. If you sell to restaurants or at a market, customers and inspectors will expect it. Keep harvest containers off the ground, wash them between uses, and keep produce away from compost, tools, and pets.

### Storage and shelf life

Know the shelf life of what you sell, and do not sell past it:

- **Salad leaves and herbs:** 3–5 days refrigerated, best sold within 1–2 days.
- **Radishes, beets, carrots:** 2–4 weeks refrigerated.
- **Tomatoes:** 5–7 days at room temperature once ripe; refrigeration damages flavour, so sell them ripe and advise customers to keep them on the counter.
- **Peppers, cucumbers, beans:** 5–7 days refrigerated.
- **Microgreens:** 3–5 days refrigerated, best sold the day they are cut.
- **Garlic, onions, squash:** weeks to months in a cool, dry place.

Sell the most perishable crops first and plan your harvest around your selling day. If your market is on Saturday, harvest Friday evening or Saturday morning — not Wednesday. A grower who harvests to order, picking on the morning of market day, sells visibly fresher produce than a grower who picked three days earlier, and customers notice.

### Packing and presentation

Packaging does not need to be expensive, but it does need to be clean, appropriate, and honest. Salad leaves in a clear bag or a paper punnet look good and show the quality. Herbs tied in a small bunch with a paper band sell better than a loose handful. Cherry tomatoes in a punnet look like a product; cherry tomatoes in a plastic bag look like an afterthought.

Weigh or count consistently. If you sell lettuce by the bag, every bag should be roughly the same weight. If you sell by the bunch, every bunch should look like the same bunch. Customers forgive a lot, but they do not forgive feeling short-changed, and inconsistent sizing is the fastest way to lose a regular.

Label clearly: what it is, the variety if it matters, the weight or count, and your name or farm name. A simple label with your name turns a bag of lettuce into a product from a person, and that is what brings people back.

### Food safety basics

Food safety is not optional when you sell to others. The essentials are simple and non-negotiable:

- Wash your hands before harvesting and packing.
- Use clean water for washing produce.
- Keep harvest and packing surfaces clean.
- Keep produce cool and out of the sun.
- Do not harvest from beds that have recently had fresh manure applied — compost should be fully finished before it goes on food beds, and raw manure should be applied months before harvest, not weeks.
- If you are ill with a stomach bug, do not harvest or pack food for sale that day.

Check whether your local authority requires a food hygiene certificate, a market stall permit, or a food business registration for selling produce. In many places, selling whole, uncut vegetables at a market is lightly regulated; selling cut salad, prepared food, or value-added products is more heavily regulated. Find out which side of that line you are on before you sell.

**Module 6 actions:**
1. Buy or borrow a sharp harvest knife, scissors, a salad spinner, and clean harvest crates.
2. Set up a cool, shaded harvest station and a cooling method (cool box or fridge space).
3. Write down the harvest window and shelf life of each crop you grow.
4. Plan your harvest day around your selling day — pick as close to the sale as possible.
5. Check local food business rules for selling produce in your area.

---

## Module 7: Pricing Your Produce

Pricing is where many growers quietly lose money. They price by copying the supermarket, or by guessing, or by charging what feels polite — and then discover at the end of the season that they earned less per hour than a minimum-wage job. Pricing properly is not greedy. It is the only way the business survives long enough to serve its customers.

### The cost-plus starting point

Your price must cover three things: your direct costs (seeds, compost, water, packaging), your time, and a margin for the losses and risks that every season carries. The pricing sheet template gives you the structure. The formula is:

**Minimum price = (direct costs per unit + your time per unit) × 1.2** (the extra 20 percent covers losses, unsold produce, and the costs you forgot).

Work through an example. Suppose a bed of salad leaves costs you $25 in seed, compost, and water for the season, takes you 6 hours of work across the season, and you value your time at $15 an hour. Your total cost is $25 + $90 = $115. If that bed produces 20 sellable bags of salad, your cost per bag is $5.75. A minimum price of $6.90 (with the 20 percent margin) would be the floor — and if the local market price is $5 a bag, you have a problem: either your costs are too high, your yield is too low, or salad is the wrong crop for your setup. That is information worth having before you plant, not after.

### What the market will pay

Cost-plus gives you the floor. The market gives you the ceiling — and the ceiling in direct sales is usually higher than the supermarket, because your produce is fresher, local, and sold by a person the customer knows. Research real prices before you set yours:

- Visit your local farmers market and note the prices of every crop you plan to sell.
- Check local grocery stores and organic shops for the same crops.
- Look at community-supported agriculture (CSA) box prices in your area for a per-week comparison.

In most cities, farmers market prices for salad leaves run roughly $6–$10 per pound, herbs $2–$3 a bunch, cherry tomatoes $4–$6 a punnet, radishes $2–$3 a bunch, and eggs from a market are not your competition — but the price of a comparable bag of supermarket salad is your customer's reference point, and you need to be able to explain why yours costs more: it was picked this morning, it was grown a few miles away, and it will still be crisp in three days.

### Pricing by the unit that suits the crop

Match the unit to the crop and the customer:

- **By weight (per pound or per bag of a set weight):** salad leaves, loose greens, beans, tomatoes.
- **By the bunch:** herbs, radishes, beets with tops, spring onions.
- **By the punnet or container:** cherry tomatoes, microgreens, edible flowers.
- **By the head:** lettuce, cabbage, cauliflower.

Whatever unit you choose, keep it consistent from week to week. Customers learn your prices; changing them every week confuses and annoys. Review prices once a season, not once a week, and if you do raise a price, do it once and explain why — for example, that packaging costs have risen.

### The value of your time

This is the part growers resist most, and the part that matters most. If you do not charge for your time, you are not running a business; you are running a hobby that happens to take money in. Value your time at a real rate — at least the local minimum wage, and more realistically $15–$25 an hour for skilled growing work. Then look at the hours each crop takes and ask whether the revenue justifies them. A crop that earns $40 and takes 4 hours of work has paid you $10 an hour before costs. A crop that earns $40 and takes 1 hour has paid you $40 an hour. Grow more of the second crop.

Keep a simple time log for a few weeks — even rough notes of hours spent per bed. You will be surprised which crops eat your time. Hand-watering, daily pest checks, and fiddly harvesting add up, and the crops that look most profitable on paper are sometimes the least profitable once your hours are counted.

### Discounts, deals, and the price of free

Be careful with discounts. A "buy two, get one free" offer on a perishable crop can be a smart way to move a glut before it spoils — but a standing discount trains customers to wait for the discount. Free samples are worth it: a taste of a cherry tomato or a leaf of salad costs you almost nothing and converts browsers into buyers. Free produce for friends and family is a personal choice, but track it — if a third of your harvest is given away, your pricing is built on two-thirds of your yield, and your numbers will never add up.

Never compete on price with the supermarket. You cannot win: they buy by the tonne and sell at a loss to bring people into the store. Your advantage is freshness, flavour, locality, and the relationship with the buyer. Price for that, and let the supermarket have the customers who only care about the lowest number.

### When to raise prices

Raise prices when your costs rise, when demand consistently exceeds supply (you sell out every week), or when you add something of real value — a new variety, better packaging, home delivery. Selling out every week is a signal, not a success: it means your price is too low or your planting is too small. Raise the price a little, or plant a little more, and see what happens. A small, tested increase — say 10 percent on one crop — tells you more about your market than a year of guessing.

**Module 7 actions:**
1. Research local market and shop prices for every crop you plan to sell.
2. Complete the pricing sheet for each crop, including your time.
3. Set your first-season prices and write them down.
4. Start a simple time log for your growing work.
5. Decide your policy on discounts and free samples before your first sale.


---

## Module 8: Finding Buyers Before You Plant

This is the module most growers skip, and it is the one that decides whether the season pays. The rule is simple and absolute: **find the buyer before you plant the crop.** A bed of beautiful lettuce with nobody to sell it to is a compost heap with extra steps.

### Who buys from small urban growers

There are four realistic buyer types for a small grower, and each wants something different:

**1. Farmers market customers.** They buy weekly, they pay the best prices, and they value freshness, variety, and a friendly face. They buy small quantities — a bag of salad, a bunch of herbs, a punnet of tomatoes — so you need many of them. A market stall takes a full morning, a table, and a permit or fee, but it is also the fastest way to learn what your customers want, because they tell you to your face.

**2. Community-supported agriculture (CSA) subscribers.** They pay upfront for a weekly box of whatever is in season, usually for 8–20 weeks. The upfront payment is the great advantage: it funds your seeds and compost in spring, when you have costs and no income. The challenge is commitment: you must deliver a full, varied box every week, rain or shine, even when a crop fails. Start small — 5 to 10 subscribers, people you know — and grow only when you are confident you can fill the box every week.

**3. Restaurants and cafés.** A chef who wants fresh herbs, salad leaves, or microgreens every week is a steady, high-value buyer. Restaurants pay wholesale prices — usually 60–70 percent of retail — but they buy in volume, they buy every week, and they pay reliably. The catch is consistency and professionalism: they need the same product, the same quality, delivered on the same day, every week. A restaurant will not forgive two missed deliveries. Approach chefs with a sample, a price list, and a clear delivery day, and start with one restaurant before you promise five.

**4. Neighbours and local direct sales.** The simplest channel of all: a regular box or bag for neighbours, a small stall outside your house, a weekly order collected from your door. Prices are close to market prices, there are no stall fees, and the customers are already nearby. The limit is volume — there are only so many neighbours — but for a first season, ten regular neighbours buying $10 of produce a week is $100 a week of reliable income, and it teaches you everything about what people actually want.

### How to find them

Start with people you already know. Tell friends, neighbours, colleagues, and local groups what you are growing and when it will be ready. Post in a local community group or neighbourhood forum with a photograph of your beds and a simple offer: a weekly salad bag, available from a date, at a price, collected from your door or delivered locally. The first buyers are almost always people who already know you.

For markets, visit the market first as a customer. Talk to the organisers, ask about stall fees, rules, and waiting lists, and watch what sells. Some markets have long waiting lists; others welcome new growers. Apply early — in winter for a spring market — and start with a half stall or a shared stall if that is offered.

For restaurants, visit in the quiet part of the day (mid-afternoon, between lunch and dinner), bring a sample, and ask for the chef or the buyer. Keep it short: what you grow, what it costs, when you can deliver, and a sample they can taste. Leave a one-page price list and your contact details. Then follow up once, a week later, by phone or in person. If they are not interested, thank them and move on — a polite no costs you nothing, and the chef may remember you next season.

For a CSA, start with a simple offer: a weekly box for 10 weeks, a set price, a set pickup day and place, and a list of what is likely to be in the box each week. Take payment upfront or in two instalments. Be honest about the risk: a CSA is a shared-risk arrangement, and subscribers should know that a bad week for one crop means more of another, not an empty box.

### The pre-season buyer list

Before you sow your first commercial seed, you should be able to write down the name of at least one buyer for each crop you plan to grow in volume. Not "the market" — a person, a restaurant, or a list of subscribers. Use the buyer-outreach tracker in the workbook: who they are, what they want, how much, how often, at what price, and when you last spoke to them.

A realistic first-season target: 10 regular direct customers, or 5 CSA subscribers, or 1 restaurant plus a market stall. Any one of those is enough to absorb the output of 100 square feet. Do not try to build all four channels in year one.

### Selling the story honestly

Customers buy from small growers partly because of the story: grown nearby, picked this morning, grown without harsh chemicals. Tell that story, and tell it truthfully. Say where you grow, how you grow, and when it was picked. Put your name on the label. Answer questions about your methods honestly — if you use insecticidal soap occasionally, say so. The trust you build by being straight is worth more than any claim, and it is the reason customers pay a premium and come back.

Do not invent a farm name that implies a scale you do not have, do not claim certifications you do not hold, and do not describe your produce as something it is not. Honesty is not just an ethic here; it is a business strategy, because a customer who discovers a false claim does not just stop buying — they tell their neighbours.

**Module 8 actions:**
1. Choose your first sales channel (market, CSA, restaurant, or direct neighbours).
2. List at least one named buyer for each crop you plan to grow in volume.
3. Visit your local market as a customer and talk to the organisers.
4. Approach one restaurant with a sample and a price list, or invite ten neighbours to subscribe to a weekly bag.
5. Record every buyer and conversation in the buyer-outreach tracker.

---

## Module 9: Selling and Delivery Systems

Finding buyers is the first half. Serving them reliably, week after week, is the second half — and it is where small growers earn their reputation. A simple, repeatable system beats a brilliant one-off every time.

### The weekly rhythm

Design a weekly rhythm and protect it. A workable pattern for a market grower might be:

- **Monday:** sow succession crops, check beds, water, and plan the week's harvest.
- **Wednesday:** harvest herbs and early crops for a midweek delivery or order.
- **Friday:** harvest the main crop for Saturday market; wash, pack, and label.
- **Saturday:** market day — sell, talk to customers, note what sold out and what did not.
- **Sunday:** rest, and record the week's sales and costs.

For a CSA or restaurant grower, the rhythm is built around the delivery day: harvest the day before or the morning of delivery, pack to order, and deliver on time. Whatever your rhythm, write it down and keep it. A system you can repeat without thinking is a system that survives a busy week, a bad back, or a heatwave.

### Taking orders

Keep ordering simple. A text message, an email, or a simple online form is enough for a first season. What matters is that you know, by a fixed cut-off time, exactly what each customer wants this week — and that the customer knows the cut-off. A standing order (the same bag every week unless the customer cancels) is simpler than a fresh order every week, and it gives you a predictable harvest.

Confirm orders the day before delivery. It takes five minutes and prevents the two most common failures: harvesting produce nobody ordered, and a customer expecting a delivery you did not know about.

### Delivery

If you deliver, keep the delivery area small — a few streets, a single neighbourhood, or a single drop-off point. Delivery time is time you are not growing, and fuel or fares eat margin fast. Charge for delivery, or build it into the price, or set a minimum order for free delivery. A minimum order of $15–$20 for free local delivery is a reasonable starting point; below that, charge a small delivery fee or ask the customer to collect.

Pack deliveries in a way that survives the journey: sturdy bags or boxes, greens on top, heavy items at the bottom, and a cool bag in hot weather. Include a short note — what is in the box, how to store it, and one idea for using it. That note costs almost nothing and is the thing customers remember.

### Market stall basics

A good market stall is clean, clear, and welcoming. A table, a clean cloth, a clear price list, and produce displayed at eye level, not in a heap on the ground. Put your best-looking produce at the front. Keep prices visible — customers who have to ask the price often walk away rather than ask. Have bags, change, and a way to take card payments (a phone card reader is inexpensive and most customers now expect it). Arrive early, set up calmly, and stay until the end — the last hour is often when regulars come by for the end-of-day deal.

Talk to your customers. Ask what they liked, what they want next week, and what they cooked with last week's box. That conversation is market research you cannot buy, and it is the reason people come back to a stall instead of going to a supermarket.

### Handling the glut and the gap

Every grower faces two problems: too much of one crop at once, and too little of another. Plan for both. For a glut, have a plan before it happens: a discount at the end of market day, a bonus in the CSA box, a message to regular customers offering extra at a reduced price, or preserving (freezing herbs, making pesto, pickling) for your own use. For a gap, be honest: tell customers what is coming next week, offer a substitute, and do not pretend a crop is available when it is not. Customers forgive a gap; they do not forgive being misled.

### Records at the point of sale

Record every sale, the same day, while you remember it. The simplest version is a notebook or a phone note: date, customer or channel, what was sold, quantity, and amount received. That record is the raw material for Module 10's profit tracking, and it is also your evidence if a customer queries an order or a market organiser asks about your sales. Five minutes a day saves hours of reconstruction at the end of the season.

**Module 9 actions:**
1. Write down your weekly rhythm (harvest days, selling days, admin day).
2. Choose one ordering method and a weekly cut-off time.
3. Set your delivery area, minimum order, and delivery fee.
4. Prepare your market kit (table, cloth, price list, bags, card reader, change).
5. Start recording every sale on the day it happens.

---

## Module 10: Costs, Records, and Tracking Profit

A business that does not know whether it made money is a hobby with a cash register. This module is about knowing, to the dollar, what the season cost, what it earned, and what it earned per hour of your time — so you can make next season better on evidence instead of feeling.

### What to record

Record four things, every week:

1. **Income:** every sale, by date, channel, and crop if you can.
2. **Costs:** every purchase — seeds, compost, soil, containers, tools, packaging, market fees, fuel. Keep receipts in one place (a folder, an envelope, a phone album).
3. **Hours:** roughly how long you spent growing, harvesting, packing, selling, and delivering.
4. **Yield:** what you harvested from each bed, in weight or units, and how much of it was sold, given away, or lost.

The season profit-and-loss worksheet in the workbook gives you the structure. Fill it in weekly, not at the end of the season — a weekly habit takes five minutes; reconstructing a season from memory takes a weekend and is wrong anyway.

### The season profit-and-loss

At the end of the season, add up the four numbers:

**Revenue − total costs = profit**
**Profit ÷ hours worked = your effective hourly rate**

Be honest about the costs. Include the market stall fee, the packaging, the compost, and the seeds you bought and never used. Include the cost of replacing a tool that broke. Do not include the cost of food you grew for yourself — but do not count its value as income either, unless you want a separate line for "food grown for home use," valued at what it would have cost to buy. Many growers find that the home-use food is a real part of the return, and it is worth recording separately so it does not confuse the cash picture.

### Worked example: a sample 100 sq ft bed budget

This example is for a first-season grower with 100 square feet of raised beds in a temperate city, selling at a farmers market and to neighbours. All figures are realistic mid-range estimates — your own figures will differ, and that is expected.

**Start-up costs (year one, mostly reusable):**

| Item | Cost |
|---|---|
| 4 raised beds (timber, 4 ft × 8 ft) | $160 |
| Soil and compost to fill the beds | $120 |
| Basic tools (fork, trowel, knife, watering can) | $60 |
| Drip kit and timer | $45 |
| Harvest crates, bags, and packaging | $30 |
| Market stall fee deposit or first month | $40 |
| **Total start-up** | **$455** |

**Season running costs:**

| Item | Cost |
|---|---|
| Seeds (salad, herbs, tomatoes, radishes, beets) | $45 |
| Compost top-up and fertiliser | $40 |
| Water | $25 |
| Packaging for the season | $35 |
| Market stall fees (12 weeks × $25) | $300 |
| Fuel and miscellaneous | $30 |
| **Total running costs** | **$475** |

**Total first-season cost: $930** (of which $455 is start-up that will not repeat next season).

**Revenue (honest mid-range estimates):**

| Crop | Area | Estimated season yield | Price | Revenue |
|---|---|---|---|---|
| Salad leaves and greens | 40 sq ft | 60 bags | $6 per bag | $360 |
| Herbs (basil, parsley, cilantro) | 20 sq ft | 80 bunches | $2.50 per bunch | $200 |
| Cherry tomatoes | 15 sq ft | 60 punnets | $5 per punnet | $300 |
| Peppers | 5 sq ft | 25 lbs | $4 per lb | $100 |
| Radishes and beets | 10 sq ft | 40 bunches | $2.50 per bunch | $100 |
| Trial crop (microgreens) | 10 sq ft | 20 punnets | $5 per punnet | $100 |
| **Total revenue** | | | | **$1,160** |

**First-season result: $1,160 revenue − $930 costs = $230 profit.**

That is the honest picture for a first season: a small profit, and a set of beds, tools, and skills that are already paid for. In year two, the start-up costs largely disappear — the beds, tools, and drip kit are already there — so the same revenue on roughly $475 of running costs would give a profit of about $685, before any improvement in yield or price. And if the grower's yields improve by 20 percent in year two, which is a realistic expectation as skill and soil improve, revenue rises to roughly $1,390 and profit to about $915.

These are illustrative figures, not a promise. A bad season — a heatwave, a pest outbreak, a market that does not work out — can cut revenue by a third. A good season, a strong market, and a restaurant buyer can raise it by a third. The point of the example is not the exact number. It is the shape: the first season covers its costs and a little more, the second season is where the profit appears, and the biggest costs are the ones you only pay once.

### Your hourly rate

If that first season took 120 hours of work — a realistic figure for 100 square feet over a 20-week season, including market days — the effective rate is $230 ÷ 120 = about $1.90 an hour. That is a poor wage and a good education. In year two, at $685 profit for the same 120 hours, the rate is about $5.70 an hour. At $915 profit, it is about $7.60 an hour. These are still modest rates, and they are the reason this course is honest that urban growing is a side income, not a replacement for a full-time job, at this scale. The rate rises with scale, with better crops, with a restaurant buyer, and with systems (drip irrigation, succession planning, a standing order list) that cut the hours per dollar earned. Track it every season, and make decisions that raise it.

### Pricing your own labour in the records

Even if you do not pay yourself a wage in cash, record your hours and value them in the worksheet. A season that "made $230" but took 120 hours is a different fact from a season that made $230 in 40 hours. The first tells you the system needs work; the second tells you it is already working. Without the hours, you cannot tell which one you have.

### Tax and legal basics

Keep your records because your tax authority may want them. In many places, small amounts of income from selling home-grown produce are taxable, and there may be a threshold below which no tax is due or no registration is needed. The rules vary widely by country and city, and this course does not give tax advice. Check your local rules, keep your receipts and sales records, and speak to a tax adviser or your local small-business service if your sales grow beyond a casual level. The records you keep for this module are exactly the records a tax adviser will ask for.

**Module 10 actions:**
1. Start the season profit-and-loss worksheet now, with your start-up costs already entered.
2. Set up one place for receipts (a folder or envelope) and one place for sales records.
3. Log your hours weekly, even roughly.
4. Review the numbers monthly — not just at the end of the season — and adjust (drop a crop that loses money, plant more of one that pays).
5. Check your local tax rules for small-scale produce sales.

---

## Module 11: Scaling from Side Income to a Real Micro-Farm

Scaling does not mean doing more of everything. It means doing more of what already works, dropping what does not, and adding capacity only when demand is proven. Growers who scale too fast — more beds, more markets, more restaurants, all in one season — usually scale their problems faster than their income.

### When you are ready to scale

You are ready to add capacity when three things are true at the same time:

1. **You sell out regularly.** Your produce sells out most weeks, and customers are asking for more or for crops you do not grow yet.
2. **You know your numbers.** You can say, from your records, which crops earn the most per square foot and per hour, and which ones lose money.
3. **You have time to spare — or a system that saves it.** Your weekly rhythm works, your watering is automated, and your harvesting and packing take no longer than they should.

If any one of those is not true, fix it before you expand. More beds will not fix a crop that loses money; they will lose more money. A second market will not fix a first market that does not sell; it will cost a second stall fee.

### Ways to scale

**Grow more of what pays.** The simplest scale-up: double the area of your two or three best crops and drop your worst one. If salad and basil earn the most per square foot, give them more beds. If carrots earn the least, stop growing them for sale.

**Add a second sales channel.** If your market stall sells out every week, add a small CSA or a restaurant buyer — one at a time, with a trial period. A second channel also protects you: if one market has a bad week, the other still pays.

**Extend the season.** A cold frame, a small polytunnel, or a set of row covers can add 4–8 weeks of selling at each end of the season, when prices are higher because fewer growers have produce. Season extension is often a better investment than more beds, because it earns from the space you already have.

**Add a high-value crop.** Microgreens, edible flowers, or a specialist herb for a restaurant can earn far more per square foot than a standard vegetable, and they need little extra space. Test any new crop on a small area with a named buyer before you commit a bed to it.

**Grow indoors or under cover.** A small indoor setup for microgreens or herbs, with grow lights, gives you a year-round product that does not depend on the weather. It adds an electricity cost and a daily routine, so run the numbers first — but for growers in cold climates, it is often the most reliable winter income.

**Rent more space.** An allotment plot, a neighbour's unused garden, or a shared growing space can double your area without buying land. Check the rules on selling before you commit, and cost the rent into your profit-and-loss before you sign anything.

### What not to scale

Do not scale by buying expensive equipment you have not proven you need. A $500 greenhouse is a good investment when you have a buyer waiting for winter greens; it is an expensive ornament when you do not. Do not scale by hiring help before your own system works — an employee cannot fix a broken routine, they can only do it faster. And do not scale by taking on debt for a growing business that has not yet shown a profit. Grow the business from its own earnings where you can; a small, debt-free micro-farm that earns a steady side income is a better asset than a large one that owes money.

### The micro-farm picture

A realistic picture of a small urban micro-farm after two or three seasons: 200–400 square feet of growing space, a polytunnel or cold frames, a weekly market stall, 10–20 CSA subscribers or a couple of restaurant buyers, and a season revenue of roughly $3,000–$6,000 against costs of roughly $1,000–$2,000 — a profit of roughly $2,000–$4,000 a season for 200–300 hours of work. That is a meaningful side income, not a full-time living, and it is an honest target to aim for. Growers who reach further — a full-time income from urban growing — usually do so by adding value: prepared products, workshops, a farm shop, or a larger site with paid help. Those are real paths, but they are beyond this course, and they should only be attempted once the small system is proven.

### Your next-season plan

At the end of your first season, before the details fade, write a one-page next-season plan: the three crops you will grow more of, the one crop you will drop, the one new crop you will trial, the one system you will improve (watering, succession, packing, selling), and the one buyer you will approach. That page is the bridge between one season and the next, and it is worth more than any new tool.

---

## Your Outcome: What You Should Have at the End of This Course

If you have worked through the modules and done the actions, you should have:

- A measured, mapped growing space with known sun hours and a working water system.
- Soil that is improving every season, in beds or containers you can manage.
- A crop plan chosen by profit per square foot, not by habit, with local prices behind it.
- A planting calendar that keeps something ready to harvest every week of the season.
- A pest and disease routine that protects your crops without harsh chemicals.
- Harvest and packing habits that deliver produce customers come back for.
- Prices that cover your costs, value your time, and reflect what your market will pay.
- Named buyers for your main crops — found before you planted them.
- A selling and delivery system you can repeat every week without thinking.
- Records that tell you, honestly, what the season earned and what your time was worth.
- A plan for next season, built on this season's evidence.

That is a real small business, built on a small plot, with your own hands. It will not make you rich in a season. It can give you a steady side income, food you grew yourself, skills that compound every year, and customers who know your name. Start small, sell before you plant, keep your records, and let the second season be better than the first.

