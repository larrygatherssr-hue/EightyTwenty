# The Profitable Urban Farm Blueprint — Companion Workbook

Use this workbook alongside the course. Print it, or copy it into a notebook or spreadsheet — what matters is that you fill it in with your own numbers, for your own space, in your own market. A workbook filled in badly is worth more than a perfect one left blank.

---

## Worksheet 1: Space Assessment

Complete this after Module 1.

| Area (e.g. back garden, balcony, roof) | Length × width | Area (sq ft) | Sun hours (direct sun) | Water source | Notes (access, weight limits, rules) |
|---|---|---|---|---|---|
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| **Total growing area** | | **______ sq ft** | | | |

**Sun map notes** (record the result of your sun map or three photographs):

- Sunniest area: ______________________, ______ hours of direct sun
- Part-sun area: ______________________, ______ hours of direct sun
- Shadiest area: ______________________, ______ hours of direct sun

**Local rules checked?** Selling home-grown produce: yes / no — notes: ______________________
**Market stall rules checked?** yes / no — notes: ______________________
**Building / weight limits checked?** yes / no — notes: ______________________

---

## Worksheet 2: Crop Selection

Complete this after Module 3. Research local prices first, then run each crop through the crop profitability calculator (templates/crop-profitability-calculator.csv).

| Crop | Variety | Days to harvest | Yield per sq ft | Local price | Revenue per sq ft | Cost per sq ft | Profit per sq ft | Weeks in bed | Profit per sq ft per week | Grow? |
|---|---|---|---|---|---|---|---|---|---|---|
| | | | | | | | | | | |
| | | | | | | | | | | |
| | | | | | | | | | | |
| | | | | | | | | | | |
| | | | | | | | | | | |
| | | | | | | | | | | |
| | | | | | | | | | | |
| | | | | | | | | | | |

**My first-season crop mix (no more than 6–8 crops):**

| Crop | Area (sq ft) | Why this crop? | Named buyer |
|---|---|---|---|
| | | | |
| | | | |
| | | | |
| | | | |
| | | | |
| | | | |

**Trial crop (10% of space):** ______________________

---

## Worksheet 3: Planting Calendar

Complete this after Module 4. Copy the structure into a fresh table each season. Fill in your own frost dates first.

**My last frost date:** ______________ **My first frost date:** ______________ **Season length:** ______ days

| Crop | Sow indoors | Transplant / sow outdoors | First harvest | Last harvest | Succession sow every | Notes |
|---|---|---|---|---|---|---|
| | | | | | | |
| | | | | | | |
| | | | | | | |
| | | | | | | |
| | | | | | | |
| | | | | | | |
| | | | | | | |
| | | | | | | |

**Season-extension measures planned:** ______________________
**Garden diary started?** yes / no — where kept: ______________________

---

## Worksheet 4: Harvest Log

One row per harvest. Fill it in on the day you pick.

| Date | Crop | Variety | Bed / area | Amount harvested | Amount sold | Amount given away / lost | Price received | Notes (quality, pests, weather) |
|---|---|---|---|---|---|---|---|---|
| | | | | | | | | |
| | | | | | | | | |
| | | | | | | | | |
| | | | | | | | | |
| | | | | | | | | |
| | | | | | | | | |
| | | | | | | | | |
| | | | | | | | | |
| | | | | | | | | |
| | | | | | | | | |

**Season totals (add up at the end of the season):**

- Total harvested (by crop): ______________________
- Total sold: ______________________
- Total given away: ______________________
- Total lost to pests, disease, or spoilage: ______________________

---

## Worksheet 5: Buyer-Outreach Tracker

Complete this after Module 8. One row per buyer or prospect. Update it every time you speak to them.

| Buyer name | Type (market / CSA / restaurant / neighbour) | What they want | Quantity per week | Price agreed | Delivery / pickup day | First contact date | Last contact | Status (prospect / trial / regular / lost) | Notes |
|---|---|---|---|---|---|---|---|---|---|
| | | | | | | | | | |
| | | | | | | | | | |
| | | | | | | | | | |
| | | | | | | | | | |
| | | | | | | | | | |
| | | | | | | | | | |
| | | | | | | | | | |
| | | | | | | | | | |

**My first-season sales channel:** ______________________
**Target for the season (e.g. 10 regular customers, 5 CSA subscribers, 1 restaurant):** ______________________

---

## Worksheet 6: Season Profit-and-Loss

Fill this in weekly during the season. Add up the totals at the end.

### A. Start-up costs (year one, mostly reusable)

| Item | Cost |
|---|---|
| Raised beds / containers | $ |
| Soil and compost to fill beds | $ |
| Tools | $ |
| Drip kit and timer | $ |
| Harvest crates, bags, packaging | $ |
| Market stall deposit / fees | $ |
| Other: | $ |
| **Total start-up costs** | **$** |

### B. Season running costs

| Item | Cost |
|---|---|
| Seeds | $ |
| Compost top-up and fertiliser | $ |
| Water | $ |
| Packaging | $ |
| Market stall fees | $ |
| Fuel / transport | $ |
| Other: | $ |
| **Total running costs** | **$** |

### C. Revenue

| Week | Market sales | CSA / subscriptions | Restaurant | Direct / neighbours | Other | Week total |
|---|---|---|---|---|---|---|
| 1 | | | | | | |
| 2 | | | | | | |
| 3 | | | | | | |
| 4 | | | | | | |
| 5 | | | | | | |
| 6 | | | | | | |
| 7 | | | | | | |
| 8 | | | | | | |
| 9 | | | | | | |
| 10 | | | | | | |
| 11 | | | | | | |
| 12 | | | | | | |
| 13 | | | | | | |
| 14 | | | | | | |
| 15 | | | | | | |
| 16 | | | | | | |
| 17 | | | | | | |
| 18 | | | | | | |
| 19 | | | | | | |
| 20 | | | | | | |
| **Total revenue** | | | | | | **$** |

### D. Season result

| | Amount |
|---|---|
| Total revenue (C) | $ |
| Less total costs (A + B) | $ |
| **Profit / (loss)** | **$** |
| Hours worked this season | |
| **Effective hourly rate (profit ÷ hours)** | **$ per hour** |
| Value of food grown for home use (at shop prices) | $ |

**What earned the most per square foot?** ______________________
**What earned the least?** ______________________
**What will I change next season?** ______________________

---

## Worksheet 7: Setup Checklists

### Before the season starts

- [ ] Space measured and sketched; sun map done
- [ ] Soil tested (and lead test if needed)
- [ ] Compost sourced
- [ ] Beds built or containers ready; soil mix in place
- [ ] Watering set up (hose or drip + timer)
- [ ] Mulch bought or gathered
- [ ] Local rules on selling checked
- [ ] Crop plan chosen using the profitability calculator
- [ ] Seeds ordered (reliable, locally proven varieties)
- [ ] Buyers identified — at least one named buyer per main crop
- [ ] Prices set using the pricing sheet
- [ ] Market stall applied for, or CSA / restaurant / neighbour channel confirmed
- [ ] Harvest kit ready (knife, scissors, salad spinner, crates, bags, labels, cool box)
- [ ] Card reader and change ready (if selling at a market)
- [ ] Profit-and-loss worksheet started with start-up costs entered

### Weekly routine

- [ ] Walk the beds twice; check leaf undersides for pests
- [ ] Water as needed (check soil moisture, not the calendar)
- [ ] Sow succession crops due this week
- [ ] Harvest on schedule, cool produce immediately
- [ ] Confirm orders before the cut-off time
- [ ] Record all sales the same day
- [ ] Log hours worked
- [ ] Update the garden diary (sowing dates, harvests, weather, problems)

### End of season

- [ ] Add up the profit-and-loss worksheet
- [ ] Work out profit per crop and per square foot
- [ ] Note the three crops to grow more of, and the one to drop
- [ ] Choose one trial crop for next season
- [ ] Choose one system to improve (watering, succession, packing, selling)
- [ ] Identify one new buyer to approach
- [ ] Clear beds, add compost, mulch for winter
- [ ] Store tools clean and dry; drain hoses and drip lines before frost
