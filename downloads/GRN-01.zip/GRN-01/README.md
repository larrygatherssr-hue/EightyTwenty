# The Profitable Urban Farm Blueprint — GRN-01

An 11-module video course and toolkit for city dwellers and side-hustlers who want to earn income growing food in small urban spaces. **$397, one-time payment.**

## Files

| File | Description |
|---|---|
| `content.md` | The complete 11-module course (10,000+ words of full instructional prose, with worked examples). |
| `workbook.md` | Companion workbook: space-assessment, crop-selection, planting calendar, harvest log, buyer-outreach tracker, season profit-and-loss, and setup checklists. |
| `templates/crop-profitability-calculator.csv` | 18 crops with yield, price, revenue, cost, and profit per square foot. |
| `templates/planting-calendar.md` | Season planning template by frost date, with succession intervals and a monthly checklist. |
| `templates/buyer-outreach-scripts.md` | Outreach scripts for neighbours, market organisers, restaurants, CSA subscribers, problem follow-ups, and referrals. |
| `templates/pricing-sheet.md` | Local price research table and cost-plus pricing worksheet with a worked example. |
| `sales-page.md` | Full sales page: headline, problem, solution, module list, who it is for / not for, price, guarantee, 8 FAQs, disclaimers. |
| `listing.json` | Marketplace listing data (SKU GRN-01, $397, one-time). |
| `cover.md` | Cover design brief (black-and-gold luxury palette, typography, imagery, layout). |
| `cover.webp` | The generated cover image. |
| `onboarding.md` | Customer onboarding guide: first steps, how to use the materials, suggested 11-week schedule, support. |
