# The Real Estate Lead Generation Engine

## Stop Chasing Deals — Build a Pipeline of Motivated Sellers That Fills Itself

**By Larry J Gathers Sr**

---

## Important Disclaimer — Read First

This course teaches lead-generation methods for real estate investors and agents. It is educational material, not legal, financial, or tax advice.

**No results are guaranteed.** This course makes no promise of any number of leads, appointments, deals, or income. Your results depend on your market, your budget, your consistency, your skill, and factors outside anyone's control. Any numbers in this course are worked examples for teaching arithmetic — they are illustrations, not predictions and not typical results.

**Cold calling, text messaging (SMS), and direct mail are regulated.** In the United States, telemarketing and texting are governed by laws including the Telephone Consumer Protection Act (TCPA), the National Do Not Call Registry, and state-level rules that vary by location. Texting generally requires prior express consent, and calling numbers on the Do Not Call Registry can expose you to penalties. Direct mail has its own postal and state rules. You are responsible for understanding and complying with all federal, state, and local laws that apply to your outreach, and for consulting a qualified attorney before launching any cold-call or SMS campaign. If you are not willing to do that compliance work, do not use those channels.

**Real estate licensing:** Some activities described here — such as representing buyers or sellers, or marketing properties you do not own — may require a real estate license in your state. Wholesaling and marketing contracts are regulated differently in different states. Check your state's rules before you act.

**Do not misrepresent yourself.** Never claim to be a buyer when you are not, never make false statements about a property's value or condition, and never pressure a distressed homeowner. Honest, transparent outreach is both the right approach and the one that builds a business that lasts.

---

## How to Use This Course

This is a video course in written form: 11 modules, designed to be completed in order over two weeks, then implemented over a 90-day campaign (Module 11 and the companion workbook give you the day-by-day plan).

Each module ends with an **Action Step** — a concrete task to complete before moving on. Do not skip them. A lead-generation system is built by doing, not by reading.

You will need:

- A notebook or the companion workbook (`workbook.md`)
- The lead-tracking CRM spreadsheet in `templates/`
- A budget you can sustain for 90 days (even a modest one — the course shows you how to size it)
- Two to five hours per week for implementation

**The outcome:** By the end of the 90 days, you will have a documented, repeatable system — five channels, tracked weekly, with known costs per lead and per appointment — instead of a pile of one-off efforts you cannot measure.

---

## Table of Contents

- Module 1 — The Engine: Why Most Investors Have No Pipeline
- Module 2 — Know Your Seller: Motivated-Seller Segments and Lists
- Module 3 — Direct Mail: The Workhorse Channel
- Module 4 — Cold Calling: Conversations That Convert
- Module 5 — SMS: Short, Compliant, and Tracked
- Module 6 — Online Ads: Paid Traffic That Pays for Itself
- Module 7 — Referrals and Partnerships: The Channel That Compounds
- Module 8 — Capture and Track: Your CRM and Your Numbers
- Module 9 — Follow-Up and Nurture: Where Most Deals Actually Come From
- Module 10 — From Lead to Contract: Conversion, Offers, and Disposition
- Module 11 — The 90-Day Campaign: Launch, Measure, Improve, Scale
- Appendix A — The Math Reference: Every Formula in One Place
- Appendix B — Compliance Checklist
- Appendix C — Glossary

---

# Module 1 — The Engine: Why Most Investors Have No Pipeline

## The problem

Most investors doing zero to five deals a year do not have a deal problem. They have a pipeline problem. They find a deal, spend weeks working it, close it (or lose it), and then start from zero again. The business lurches from feast to famine because nothing is generating the next lead while the current deal is being worked.

A pipeline is different from a deal. A pipeline is a system that produces a predictable flow of conversations with motivated sellers, week after week, whether or not you closed something last week.

## What a lead-generation engine actually is

An engine has four parts:

1. **Channels** — the ways leads enter (direct mail, cold calling, SMS, online ads, referrals).
2. **Capture** — a single place every lead lands, with its source recorded.
3. **Follow-up** — a defined sequence of touches over weeks and months.
4. **Measurement** — weekly numbers that tell you what to keep, fix, or stop.

If any one part is missing, you do not have an engine. You have activity. Activity feels productive and produces nothing you can repeat.

## The funnel, in plain numbers

Every lead-generation system is a funnel. Here is a worked example using round numbers so you can see the shape. These are **illustrative numbers only** — your market will differ.

| Stage | Count | Conversion from previous stage |
|---|---|---|
| People contacted (mail sent, calls made, ads shown to) | 5,000 | — |
| Responses / leads | 50 | 1% response rate |
| Conversations with a real seller | 25 | 50% of leads |
| Appointments / property walkthroughs | 10 | 40% of conversations |
| Offers made | 6 | 60% of appointments |
| Contracts signed | 2 | 33% of offers |

Two contracts from 5,000 contacts. That is not a failure — it is a normal funnel. The point of the funnel is that you can work it backwards: if you want two contracts a month, and your funnel converts at the rates above, you need roughly 5,000 contacts a month. If your rates are better, you need fewer. If they are worse, you need more — or you need to fix a stage.

**The single most important habit in this course:** track every stage, every week, in the CRM spreadsheet. Without stage-by-stage numbers you cannot tell whether your problem is too few contacts, weak follow-up, or offers that do not fit the market. Guessing is what keeps people at zero to five deals a year.

## The five channels at a glance

| Channel | Best for | Speed | Cost profile | Skill needed |
|---|---|---|---|---|
| Direct mail | Consistent, trackable seller leads | Slow (2–4 weeks to first replies) | Per-piece cost; scales with volume | List selection, copy |
| Cold calling | Fast conversations, immediate feedback | Fast (same day) | Time-heavy; low cash cost | Conversation skill, resilience |
| SMS | Quick replies from younger sellers | Fast | Low per-message cost; compliance-heavy | Brevity, consent management |
| Online ads | Buyer leads and seller leads at scale | Medium (days to optimise) | Daily budget; variable cost per lead | Targeting, landing pages |
| Referrals / partnerships | Highest-quality, lowest-cost leads | Slow to build, then compounding | Relationship time | Networking, follow-through |

No single channel should carry your whole business. The course recommends starting with two channels — direct mail plus one conversation channel (calling or SMS) — and adding a third only when the first two are tracked and stable.

## Your weekly rhythm (the non-negotiable)

A pipeline dies without a rhythm. Block these times every week and protect them:

- **Monday (1 hour):** Review last week's numbers. What came in, from where, at what cost?
- **Tuesday–Thursday:** Outreach blocks — calls, mail drops, ad checks. Two hours per day is enough to start.
- **Friday (30 minutes):** Follow-up block. Every lead older than 7 days without a touch gets one.
- **Monthly (2 hours):** Channel review. Keep, fix, or stop each channel based on cost per appointment, not on feelings.

## Action Step — Module 1

1. Open the CRM spreadsheet in `templates/` and enter your current pipeline honestly: how many leads, conversations, appointments, and offers do you have right now? If the answer is "I don't know," write zero. That is your baseline.
2. Choose your two starting channels and write them in the workbook (Worksheet 1).
3. Block your weekly rhythm in your calendar for the next 12 weeks.

---

# Module 2 — Know Your Seller: Motivated-Seller Segments and Lists

## Motivation beats demographics

A motivated seller is not a type of person. It is a person in a situation. The same house, owned by the same person, is not a lead in a normal year and is a lead in a year when life changes. Your job is to find situations, not stereotypes.

Common situations that create motivation to sell:

- **Inherited property (probate):** Heirs who live elsewhere, do not want to manage a property, and want to settle an estate.
- **Pre-foreclosure / financial distress:** Owners behind on payments who need an exit before foreclosure.
- **Absentee owners with long tenure:** Owners who have held a rental for many years, are tired of managing it, or live far away.
- **Vacant properties:** A house sitting empty costs money every month and signals a problem to solve.
- **Divorce:** Two owners who need to divide an asset and move on.
- **Tax-delinquent properties:** Owners behind on property taxes, facing penalties or tax sale.
- **Tired landlords:** Owners with problem tenants, deferred maintenance, or burnout.
- **Relocation / job change:** Owners who need to move quickly and cannot wait for a traditional listing.

None of these situations guarantees a deal. Many owners in these situations will list with an agent, fix the house themselves, or simply not sell. Your job is to be present, professional, and helpful when the timing is right — which is why follow-up (Module 9) matters as much as first contact.

## Building a list without buying trouble

You can build lists from public records (county tax assessor, recorder, probate court filings) and from list providers. Whichever route you take:

- **Verify the data.** Lists decay. People move, properties sell, owners die. Expect 10–20% of any purchased list to be stale. Budget for it.
- **Start small and local.** One county, one or two segments, 500–1,000 records. A small clean list beats a large dirty one.
- **Record the source and date** for every record in your CRM. When a lead converts in six months, you need to know which list produced it.
- **Never buy a list of phone numbers for cold texting without understanding consent rules.** Module 5 explains why this matters legally. A list is not permission.

## Segmenting: the 3-question test

Before you mail or call a segment, answer three questions:

1. **Can I reach them?** (Do I have a valid mailing address or phone number?)
2. **Is the situation real?** (Is there a verifiable event — a filing, a vacancy, a tax delinquency — or am I guessing?)
3. **Can I help them?** (Is there a realistic outcome — a fast cash close, a clean exit, help with a difficult property — that I can actually deliver?)

If the answer to any question is no, drop the segment or fix the gap before spending money on it.

## Worked example: sizing a list

Suppose you target absentee owners in one county. The county has 40,000 residential properties. Roughly 25% are absentee-owned — about 10,000. Of those, you filter to owners who have held the property for 10+ years and whose property shows signs of distress (code violations, tax delinquency, or vacancy). That narrows the list to roughly 1,500–2,500 records. That is a workable starting list: large enough to produce replies, small enough to mail repeatedly over 90 days without exhausting your budget.

Do not start with 20,000 records. You cannot follow up on 20,000 records, and you cannot afford to mail them consistently. Start narrow, learn your response rate, then expand.

## Action Step — Module 2

1. Pick two seller segments for your market and complete Worksheet 2 in the workbook.
2. Obtain or build a list of 500–1,000 records for your primary segment. Record the source, date, and cost.
3. Score each record (or a sample of 50) against the 3-question test and remove any that fail.

---

# Module 3 — Direct Mail: The Workhorse Channel

## Why mail still works

Direct mail is slow, unglamorous, and — for motivated sellers — still one of the most reliable channels. A letter arrives at a kitchen table. It can be read, kept, and answered weeks later. Unlike a phone call, it does not interrupt. Unlike an ad, it does not disappear when the budget runs out.

Its weakness is cost and patience: you pay for every piece, and replies arrive over weeks. Its strength is consistency: the same list, mailed on a schedule, produces a steadier flow than any single burst of effort.

## The pieces: letters, postcards, and what to send

- **Yellow letters (handwritten-style):** Personal, short, and direct. Best for high-value segments like probate and pre-foreclosure. More expensive per piece, higher response rate.
- **Typed letters:** Professional and scalable. Best for larger lists where a personal tone still matters.
- **Postcards:** Cheapest per piece, lowest response rate, but excellent for repetition — the seller sees your name again and again. Best as a follow-up touch, not a first touch.
- **Multi-touch sequences:** The same seller receives a letter, then a postcard two weeks later, then another letter. Repetition is the point: most replies come on the second or third touch, not the first.

## Writing mail that gets answered

Good direct mail follows four rules:

1. **One idea per piece.** "I buy houses in [County]. I can close quickly and pay cash. Call or text me." That is enough.
2. **Speak to the situation, not the house.** "Managing a rental from out of state is exhausting" speaks to an absentee owner. "Three bedrooms, two baths" does not.
3. **Make responding easy.** One phone number. One clear next step. No website maze, no form with ten fields.
4. **Be honest about who you are.** If you are an investor, say so. If you may assign the contract, say so where your state requires disclosure. Deception produces angry calls, not deals.

A sample first letter (adapt and make it your own — do not copy it word for word without checking it fits your market and your state's rules):

> Dear [Owner Name],
>
> My name is [Your Name]. I buy houses in [County], and I noticed you own the property at [Address].
>
> If you have ever thought about selling — especially if managing the property has become more trouble than it is worth — I would like to make you a fair cash offer and close on your timeline. There are no fees, no commissions, and no obligation.
>
> You can reach me directly at [Phone Number]. If now is not the right time, please keep this letter — I will follow up in a few weeks.
>
> Thank you for your time,
> [Your Name]

## Direct-mail math — worked example

These are **illustrative numbers** for teaching the arithmetic. Your costs and response rates will differ.

| Item | Value |
|---|---|
| Pieces mailed | 1,000 |
| Cost per piece (printing + postage) | $0.85 |
| Total campaign cost | $850 |
| Response rate | 1.5% |
| Leads (responses) | 15 |
| Cost per lead | $850 ÷ 15 = **$56.67** |
| Leads that become appointments | 6 (40%) |
| Cost per appointment | $850 ÷ 6 = **$141.67** |
| Contracts signed | 2 (33% of appointments) |
| Cost per contract | $850 ÷ 2 = **$425** |

Read that table carefully. At these illustrative rates, each contract costs $425 in mail alone — before any other expense. Whether that is a good number depends entirely on your profit per deal. If your average profit per deal is $10,000, spending $425 to acquire it is a strong return. If your average profit is $1,500, it is not. **Always judge a channel by cost per contract against profit per deal, never by cost per lead alone.**

### The repetition effect

Mailing the same list once is a test. Mailing it four times over 90 days is a campaign. A typical pattern (illustrative):

| Touch | Pieces | Response rate | Leads |
|---|---|---|---|
| 1st mailing | 1,000 | 1.0% | 10 |
| 2nd mailing | 1,000 | 0.8% | 8 |
| 3rd mailing | 1,000 | 0.6% | 6 |
| 4th mailing | 1,000 | 0.5% | 5 |
| **Total** | **4,000** | — | **29** |

Total cost at $0.85 per piece: $3,400. Cost per lead: $3,400 ÷ 29 = $117.24. The cost per lead rises with each touch — but so does the total number of leads, and the later leads are often the most motivated, because they have seen your name four times and are now ready.

## Tracking mail

Use a unique phone number or a simple code on each campaign ("Mention code MAIL-03 when you call") so you know which mailing produced each reply. Without source tracking, you cannot compare mail to your other channels, and you will keep spending on the wrong list.

## Action Step — Module 3

1. Write your first letter using the structure above. Keep it under 150 words.
2. Price a 1,000-piece mailing in your market (printing + postage) and complete the mail-math worksheet with your real costs.
3. Schedule four mail drops, two weeks apart, for your primary list.

---

# Module 4 — Cold Calling: Conversations That Convert

## Why calling still matters

Calling is the fastest way to learn whether a seller is motivated. A letter takes weeks to answer; a call takes two minutes. Calling also teaches you faster than any other channel — every conversation tells you what sellers actually care about, which objections come up, and which language works.

Its cost is time and rejection. Expect most calls to go unanswered, and most answered calls to end quickly. That is normal. The skill is in the conversations that do happen.

## Before you dial: compliance first

Cold calling is regulated. Before you make a single call:

- **Scrub your list against the National Do Not Call Registry** and any applicable state registry. Do not call numbers on it unless you have a lawful basis to do so.
- **Know your state's rules.** Some states restrict calling hours, require identification at the start of the call, or have their own do-not-call lists.
- **Keep records** of when you called, what number you called, and the outcome. Records are your defence if a complaint is ever made.
- **Use a compliant dialling approach.** Predictive diallers and automated calling systems have specific legal restrictions. If you do not understand them, dial manually.

If you are unsure about any of this, get legal advice before calling. This course cannot substitute for it.

## The call structure (five parts, two minutes)

1. **Permission (10 seconds):** "Hi, is this [Name]? I'm [Your Name], I buy houses in [County]. Do you have 30 seconds?"
2. **Reason (15 seconds):** "I'm calling because you own the property at [Address], and I wanted to ask if you have ever thought about selling it."
3. **Listen (60 seconds):** Let them talk. Ask one open question: "What would need to be true for selling to make sense for you?" Then stop talking.
4. **Qualify (30 seconds):** Condition, timeline, motivation, price expectation. Four questions, no more.
5. **Next step (15 seconds):** Book the appointment or agree the follow-up. Never end a good call without a next step and a date.

## The four qualifying questions

1. **Condition:** "How is the property doing — does it need much work, or is it in good shape?"
2. **Timeline:** "If you did sell, when would you want that to happen?"
3. **Motivation:** "What has you thinking about selling now, rather than a year from now?"
4. **Price:** "If you were to sell, what price would you need to see?"

Write the answers in your CRM before you make the next call. Memory is not a system.

## Handling the common objections

- **"I'm not interested."** — "I understand. If anything changes, would it be all right if I checked back in a few months?" (Then do it — Module 9.)
- **"How much will you pay?"** — "It depends on the condition and the repairs needed. That is why I would like to see the property. Would [day] work for a quick walkthrough?"
- **"Send me something in writing."** — "Happy to. What is the best email or mailing address? And while I send that, can I ask what your timeline looks like?"
- **"I already have an agent."** — "That is fine — I am glad you have someone representing you. If that changes, my number is [number]."

Never argue. Never pressure. A seller who feels pushed will not call you back, and will tell other sellers about the experience.

## Worked example: calling math

Illustrative numbers only:

| Item | Value |
|---|---|
| Numbers dialled in a week | 500 |
| Answered | 100 (20% answer rate) |
| Real conversations | 60 |
| Leads (motivated enough to continue) | 12 |
| Appointments | 5 |
| Contracts | 1–2 |

At roughly 3 minutes per dial including notes, 500 dials is about 25 hours — a full week of calling. That is why calling is time-heavy: the cash cost is low, but the hours are real. If your time is worth more than the leads are worth, mail or ads may be a better use of that time. Track both.

## Action Step — Module 4

1. Write your 30-second opening script using the five-part structure. Practise it aloud five times.
2. Scrub a 200-number test list against the Do Not Call Registry and record the scrub date.
3. Make 50 calls. Log every outcome in the CRM. Review what you learned before making 50 more.

---

# Module 5 — SMS: Short, Compliant, and Tracked

## What SMS is good for — and what it is not

SMS gets replies fast. A short text can start a conversation within minutes. It is also the most legally sensitive channel in this course, and the easiest to get wrong.

**The compliance rule that matters most:** In the United States, sending marketing text messages generally requires the recipient's prior express consent, and the TCPA provides for significant penalties per violation. Cold texting a purchased list without consent is a legal risk, not a growth hack. This course does not teach you how to evade that rule. It teaches you how to use SMS lawfully — primarily with people who have already engaged with you (replied to mail, filled in a form, asked for information) or through a compliant opt-in process.

**Before you send any marketing text:** consult a qualified attorney, use a compliant messaging platform that handles opt-outs (STOP requests) automatically, keep consent records, and honour every opt-out immediately. If you cannot do those things, do not use SMS for cold outreach.

## Lawful SMS uses in a lead-generation engine

- **Follow-up to a mail reply:** A seller calls or texts you from your letter; you continue by text with their permission.
- **Follow-up to a web-form opt-in:** A seller enters their number on your landing page and consents to be contacted.
- **Appointment reminders and confirmations:** Short, useful, and expected.
- **Nurture touches to warm leads:** Brief check-ins with sellers who have already spoken with you.

## Writing texts that get replies

- **Under 160 characters when possible.** One idea, one question.
- **Identify yourself immediately.** "Hi [Name], this is [Your Name] — I buy houses in [County]."
- **Ask one question.** "Are you still thinking about selling the property on [Street]?"
- **Never send more than one text without a reply.** A second text after silence is a follow-up; a fifth is spam.
- **Honour STOP instantly.** Your platform should do this automatically. Check that it does.

Sample lawful follow-up texts (for people who have already engaged with you):

- "Hi [Name], this is [Your Name]. Thanks for reaching out about [Address]. Would a quick call tomorrow work to talk through your timeline?"
- "Hi [Name], checking in — are you still considering selling [Address]? Happy to make an offer whenever you are ready. — [Your Name]"
- "Hi [Name], just confirming our walkthrough on [Day] at [Time] for [Address]. Reply YES to confirm or let me know a better time."

The full SMS script library is in `templates/sms-scripts.md`.

## SMS math — worked example (illustrative)

| Item | Value |
|---|---|
| Opted-in contacts messaged | 200 |
| Replies | 40 (20%) |
| Conversations | 25 |
| Appointments | 6 |
| Contracts | 1–2 |

SMS response rates look high because the audience is warm — these are people who already engaged. Do not compare a warm SMS response rate to a cold mail response rate. Compare cost per appointment, channel to channel, on a like-for-like basis.

## Action Step — Module 5

1. Decide whether you will use SMS at all. If yes, choose a compliant platform and confirm in writing how it handles consent records and STOP requests.
2. Write three follow-up texts for warm leads (use the samples above as a starting point).
3. Set a rule in your CRM: no cold SMS to any number without documented consent. No exceptions.

---

# Module 6 — Online Ads: Paid Traffic That Pays for Itself

## What ads do well

Online ads (search and social) can reach sellers and buyers at scale, and they produce data fast: within days you can see which message, image, and audience produces leads at what cost. They are also the easiest channel to waste money on, because spending is frictionless and optimisation takes discipline.

Use ads for two jobs:

1. **Seller leads:** "We buy houses" ads targeted to homeowners in your market, sending people to a simple landing page.
2. **Buyer leads:** Ads for your available properties or your buyers list, building the other side of your business.

Do one job at a time. Start with seller leads.

## The landing page (keep it simple)

Your ad is a promise; your landing page keeps it. A good seller landing page has:

- One headline that matches the ad ("We Buy Houses in [County] — Cash Offer in 24 Hours")
- Three bullet points: fast close, no fees or commissions, any condition
- One form: name, phone, property address — nothing else on the first step
- A phone number, large and visible, for people who prefer to call
- A short privacy note: how you will use their information

Every extra field reduces completions. Every extra paragraph delays the decision. Test one change at a time.

## Budgeting and the cost-per-lead test

Start with a small daily budget you can sustain for 30 days — for many beginners that is $10–$20 per day. Do not judge an ad after two days. Judge it after 100 clicks or 30 days, whichever comes first.

### Worked example: ad math (illustrative)

| Item | Value |
|---|---|
| Monthly ad spend | $600 ($20/day) |
| Clicks | 300 |
| Cost per click | $2.00 |
| Landing-page conversion rate | 10% |
| Leads | 30 |
| Cost per lead | $20.00 |
| Appointments (20% of leads) | 6 |
| Cost per appointment | $100.00 |
| Contracts (33% of appointments) | 2 |
| Cost per contract | $300.00 |

Compare that cost per contract ($300, illustrative) with direct mail ($425, illustrative, Module 3) and calling (time cost, Module 4). The cheapest channel is not automatically the best — the best channel is the one with the lowest cost per contract at a volume you can sustain. Run the same arithmetic for every channel, every month.

## What to test, in order

1. **Audience:** One county vs. a wider area; homeowners vs. a lookalike audience.
2. **Message:** "Fast cash offer" vs. "Sell without repairs" vs. "Avoid foreclosure."
3. **Creative:** A house photo vs. a plain text-style ad vs. a short video.
4. **Landing page:** Form length, headline, and phone-number placement.

Change one variable at a time. If you change the audience, the message, and the page in the same week, you will not know what worked.

## Action Step — Module 6

1. Write one ad and one landing page using the structure above.
2. Set a 30-day test budget you can afford to lose while you learn.
3. Decide in advance your kill rule: "If cost per lead exceeds $X after 100 clicks, I pause and change one variable." Write X in the workbook before you launch.

---

# Module 7 — Referrals and Partnerships: The Channel That Compounds

## Why referrals are different

Every other channel rents attention: you pay, you get leads, you stop paying, the leads stop. Referrals compound. A divorce attorney who sends you one client this year may send you three next year, because trust grows with each good outcome. Referral leads also convert better — they arrive pre-sold on your credibility — and cost less per contract than any paid channel.

The trade-off is speed. Referrals take months to build and cannot be bought. Start them now, alongside your paid channels, so they are producing when your paid channels need a rest.

## Who to partner with

People who meet motivated sellers before you do:

- **Divorce and probate attorneys**
- **Estate-sale and auction companies**
- **Property managers** (tired landlords are their clients too)
- **Contractors and handymen** (they see distressed properties first)
- **Real estate agents** who list properties that do not sell, or who work with investors
- **Financial advisors and CPAs** (clients facing tax or estate decisions)
- **Other investors** (deals that do not fit their criteria may fit yours)

## How to approach a partner (without being a nuisance)

1. **Give before you ask.** Share a useful resource, a market update, or a referral of your own.
2. **Be specific about what you do.** "I buy distressed single-family houses in [County] and close in 14 days" is referable. "I do real estate" is not.
3. **Make referring easy.** One page that explains your process, your criteria, and how to reach you. Leave it behind after every meeting.
4. **Close the loop.** When a partner refers someone, tell them what happened (respecting privacy). Partners who hear nothing stop referring.
5. **Stay in touch on a schedule.** A short monthly check-in beats a frantic ask when you need a deal.

## The referral tracker

Record every partner, the date you met, what you discussed, and every referral they send — with the outcome. Review it monthly. Your top three partners will eventually produce more than your bottom twenty combined. Spend your time accordingly.

## Worked example: referral value (illustrative)

Suppose over a year, five active partners send you 20 referrals. Ten become conversations, four become appointments, two become contracts. Your cash cost is near zero — a few lunches and thank-you notes, perhaps $500 for the year. Cost per contract: roughly $250, plus your time. Compare that with $300–$425 per contract for paid channels in the earlier examples. Referrals are not free — they cost relationship time — but on a cash basis they are usually your cheapest contracts. That is why the channel is worth building even though it is slow.

## Action Step — Module 7

1. List ten potential partners in your market with names and contact details.
2. Contact three this week with a specific, useful opening — not a generic "let's network" message.
3. Create a one-page partner sheet explaining what you buy and how to refer.

---

# Module 8 — Capture and Track: Your CRM and Your Numbers

## One inbox for every lead

Every lead — from mail, calls, SMS, ads, or referrals — goes into one place, the same day it arrives, with four fields filled in without exception:

1. **Name and property address**
2. **Source** (which channel, which campaign)
3. **Date of first contact**
4. **Next action and its date**

A lead without a next action is a lead you have already lost. A lead without a source is a lead you cannot learn from.

## The CRM spreadsheet

The template in `templates/lead-tracking-crm.csv` has columns for all of the above plus condition, timeline, motivation, price expectation, status, and notes. Use it exactly as provided for the first 90 days. You can move to a paid CRM later; do not let choosing software delay generating leads. A spreadsheet you actually use beats a CRM you never open.

## The five numbers you review every week

1. **Contacts made** (pieces mailed, calls dialled, ad clicks, texts sent)
2. **Leads** (responses from a real seller)
3. **Appointments** (walkthroughs booked and completed)
4. **Offers made**
5. **Contracts signed**

And the three ratios that matter:

- **Cost per lead** = total channel spend ÷ leads
- **Cost per appointment** = total channel spend ÷ appointments
- **Cost per contract** = total channel spend ÷ contracts

Review these weekly, by channel. A channel with a low cost per lead but a high cost per contract is producing the wrong leads. A channel with a high cost per lead but a low cost per contract is producing the right ones. Judge by contracts, not by leads.

## The weekly scorecard (worked example, illustrative)

| Channel | Spend | Leads | Cost/lead | Appointments | Cost/appt | Contracts |
|---|---|---|---|---|---|---|
| Direct mail | $850 | 15 | $56.67 | 6 | $141.67 | 2 |
| Cold calling | $0 cash / 25 hrs | 12 | time only | 5 | time only | 1 |
| Online ads | $600 | 30 | $20.00 | 6 | $100.00 | 2 |
| Referrals | ~$40 | 4 | ~$10.00 | 2 | ~$20.00 | 1 |
| **Total** | **~$1,490** | **61** | — | **19** | — | **6** |

Six illustrative contracts from a month of multi-channel work. Your numbers will differ. The point is the discipline: one table, every week, every channel, same definitions.

## Action Step — Module 8

1. Set up the CRM spreadsheet and enter every live lead you have today.
2. Build your weekly scorecard (the workbook has a blank version) and fill it in every Monday for 12 weeks.
3. Define your kill rule for each channel in writing before the month starts.

---

# Module 9 — Follow-Up and Nurture: Where Most Deals Actually Come From

## The uncomfortable truth

Most sellers do not sell the first time you contact them. They are not ready, the timing is wrong, the price is not right yet, or life has not forced a decision. The investors who close deals are usually not the ones who contacted the seller first — they are the ones who were still there, professionally and helpfully, when the seller became ready.

Industry experience consistently shows that a large share of closed deals comes from leads contacted multiple times over weeks or months. Treat every "not now" as the start of a follow-up sequence, not as a rejection.

## The follow-up sequence

A practical sequence for a warm lead (someone who responded and spoke with you):

| Touch | Timing | Method | Purpose |
|---|---|---|---|
| 1 | Day 0 | Call or text (with consent) | Thank them, confirm next step |
| 2 | Day 3 | Text or email | Send the information you promised |
| 3 | Day 7 | Call | Check in: any questions? |
| 4 | Day 14 | Mail (postcard) | Stay visible, low pressure |
| 5 | Day 30 | Call | Revisit timeline and motivation |
| 6 | Day 60 | Mail (letter) | New angle: market update or reminder |
| 7 | Day 90 | Call | "Still thinking about selling?" |
| 8+ | Monthly | Rotate call / mail / text | Stay in touch until they sell, list, or ask you to stop |

**If a seller asks you to stop contacting them, stop immediately and record it.** Continuing after a clear opt-out is not persistence — it is harassment, and for calls and texts it can create legal exposure.

## What to say on a follow-up call

Follow-up calls are shorter and easier than first calls. You already know the situation. Open with context, not a pitch:

> "Hi [Name], this is [Your Name] — we spoke a few weeks ago about the property on [Street]. I wanted to check in and see whether anything has changed on your side, or whether your timeline has moved."

Then listen. If nothing has changed, confirm the next check-in date and end the call politely. A two-minute call that respects their time keeps the door open. A ten-minute pitch closes it.

## Nurture for cold leads

Leads who never responded to mail still have value if you keep them in rotation. A quarterly postcard to your full list — a market update, a reminder that you buy houses, a seasonal note — costs little and keeps your name familiar. When their situation changes, you are the name they remember.

## Action Step — Module 9

1. Take your five oldest live leads and give each one a next touch with a date. Enter it in the CRM.
2. Write your follow-up call script (three sentences) and your follow-up postcard text.
3. Set a recurring Friday follow-up block in your calendar.

---

# Module 10 — From Lead to Contract: Conversion, Offers, and Disposition

## The appointment

The walkthrough is where trust is built. Arrive on time. Walk the property with the seller, not ahead of them. Ask about the house's history, what they like about it, and what has become difficult. Take notes and photographs (with permission). Do not make an offer on the spot unless you have enough information to make a fair one — a rushed low offer damages trust more than a delayed fair offer does.

After the visit, send a short thank-you the same day and deliver your offer within the timeframe you promised — usually 24 to 48 hours.

## Making an offer honestly

A sound offer starts from the property's after-repair value (ARV), minus repair costs, minus your costs of holding and selling, minus your profit margin. The exact formula varies by strategy and market; the principle does not: **know your numbers before you name a price, and be able to explain them to the seller.**

Present the offer in writing, in plain language, with the key terms clear: price, closing timeline, who pays which costs, and any contingencies. If you intend to assign the contract, disclose that where your state requires it. Never present an offer you cannot close or do not intend to honour.

## Disposition: what happens after the contract

A signed contract is not a closed deal. Your exit options include:

- **Fix and flip:** Renovate and resell. Highest profit potential, highest capital and risk.
- **Buy and hold:** Renovate and rent. Long-term income, requires financing and management.
- **Wholesale (assign the contract):** Sell your position in the contract to another investor for a fee. Lowest capital required, but regulated differently by state — check your state's rules, including any disclosure or licensing requirements.
- **Novation or listing:** In some markets, an agreement to list the property with an agent at an agreed price. Check local rules before using this structure.

Choose the exit before you sign, not after. An offer priced for a flip may not work as a wholesale deal, and vice versa.

## When to walk away

Walk away when: the numbers do not work at a price the seller will accept; the title has problems you cannot resolve; the seller is being pressured by someone else; or you cannot close on the timeline promised. Walking away from a bad deal is a skill. Chasing it is how investors lose money.

## Action Step — Module 10

1. Write your offer worksheet: ARV, repairs, holding costs, profit margin, maximum allowable offer. Test it on a real property (yours, a listing, or a past lead).
2. Draft your written offer template in plain language.
3. Decide your primary exit strategy for the next 90 days and write down why.

---

# Module 11 — The 90-Day Campaign: Launch, Measure, Improve, Scale

## The campaign in one page

| Phase | Weeks | Focus |
|---|---|---|
| Launch | 1–2 | Lists built, mail drop 1 sent, calling starts, ads live, CRM running |
| Learn | 3–6 | First replies analysed, scripts adjusted, follow-up sequence running |
| Optimise | 7–10 | Weak channel fixed or paused, budget shifted to the best cost per contract |
| Decide | 11–12 | Full review: keep, scale, or replace each channel; plan the next 90 days |

## Week by week

- **Week 1:** Finalise two segments and lists (Module 2). Write mail piece and call script. Set up CRM. Launch mail drop 1 and start calling.
- **Week 2:** Ads live. First referral outreach (three partners). First weekly scorecard.
- **Weeks 3–4:** Mail drop 2. Follow-up sequence starts on every lead. First channel review: anything with zero leads after 500 contacts gets its message or list questioned.
- **Weeks 5–8:** Mail drops 3 and 4. Ads optimised once (one variable). Calling list refreshed. Monthly partner check-ins.
- **Weeks 9–10:** Shift budget toward the channel with the lowest cost per contract. Pause anything with no appointments after 90 days of consistent effort.
- **Weeks 11–12:** Full review. Document what worked, what did not, and the exact numbers. Plan the next 90 days: same channels at higher volume, or one new channel added.

The full day-by-day calendar is in the workbook and in `templates/90-day-campaign-calendar.md`.

## The 90-day budget — worked example (illustrative)

| Item | 90-day cost |
|---|---|
| Direct mail (4 drops × 1,000 pieces × $0.85) | $3,400 |
| Online ads ($20/day × 90 days) | $1,800 |
| List purchases and data | $300 |
| Phone and messaging platform | $150 |
| Referral lunches and thank-yous | $150 |
| **Total** | **$5,800** |

That is one illustrative budget, not a recommendation. Scale it to what you can sustain for the full 90 days — a smaller budget sustained for 90 days beats a larger budget abandoned after three weeks. If your budget is $1,500, cut the mail volume and the ad spend proportionally; do not cut the tracking or the follow-up, which cost almost nothing and produce most of the value.

### What the illustrative budget might produce

Using the funnel rates from Modules 3 and 6 (illustrative only): roughly 29 mail leads plus 90 ad leads over 90 days, plus calling and referral leads. At the illustrative conversion rates, that could produce several appointments and a small number of contracts. It could also produce none — rates vary by market, list quality, and execution. **Do not treat this as a forecast.** Treat it as the arithmetic you must do with your own real numbers after 30 days.

## Scaling (only after the numbers work)

Scale a channel only when you know its cost per contract and that cost is acceptable against your profit per deal. Scaling means more volume to the same list type, the same message, and the same follow-up — not a new message to a new list. When you scale, increase volume by 25–50% at a time and watch the cost per contract for two weeks before scaling again. If it rises sharply, you have saturated the list or the audience; pause and refresh the list before spending more.

## Your next 90 days after this one

At the end of the campaign, you will have something most investors at your level do not have: 90 days of real data on your market, your lists, and your conversion rates. That data is the asset. Use it to set the next campaign's budget, to choose which channel deserves more money, and to decide — honestly — whether to add a third channel or to deepen the two you have.

## Action Step — Module 11

1. Complete the 90-day campaign calendar in the workbook with your real dates.
2. Write your budget using the table above as a template, with your real prices.
3. Schedule your Week 12 review now, before you launch.

---

## Your Outcome

If you do the work — two channels, a CRM you actually use, a follow-up sequence you actually run, and a weekly scorecard you actually review — then in 90 days you will not be guessing about lead generation. You will know, in numbers, what a lead costs you, what an appointment costs you, and what a contract costs you, in your market, with your lists, and your message. That knowledge is the engine. Keep feeding it, and it keeps producing.

Good luck — and go make the calls.

---

# Appendix A — The Math Reference: Every Formula in One Place

- Response rate = responses ÷ contacts
- Cost per lead = total channel spend ÷ leads
- Cost per appointment = total channel spend ÷ appointments
- Cost per contract = total channel spend ÷ contracts
- Lead-to-appointment rate = appointments ÷ leads
- Appointment-to-offer rate = offers ÷ appointments
- Offer-to-contract rate = contracts ÷ offers
- Profit per deal (for judging a channel) = revenue from the deal − all costs of acquiring, renovating, holding, and selling it
- Channel test: keep a channel if cost per contract < profit per deal with a margin you are comfortable with; fix it if it is close; stop it if it exceeds profit per deal after a fair test (at least 30 days and enough volume to judge).

# Appendix B — Compliance Checklist

- [ ] Lists scrubbed against the National Do Not Call Registry (and state registries where applicable) before calling, with the scrub date recorded.
- [ ] SMS only sent with documented prior express consent, via a platform that handles opt-outs automatically.
- [ ] Every opt-out honoured immediately and recorded.
- [ ] Calling hours comply with federal and state rules.
- [ ] No false or misleading statements in mail, calls, texts, or ads.
- [ ] Disclosure made where required (for example, assignment intentions) under your state's rules.
- [ ] Licensing requirements checked for your state and your activities.
- [ ] Consent and call records retained.
- [ ] Legal advice obtained before launching cold-call or SMS campaigns.

# Appendix C — Glossary

- **ARV (After-Repair Value):** The estimated value of a property after renovations are complete.
- **Absentee owner:** A property owner who does not live at the property.
- **Cost per lead / appointment / contract:** Total channel spend divided by the number of leads, appointments, or contracts that channel produced.
- **CRM:** Customer relationship management system — here, the spreadsheet where every lead and its history is recorded.
- **Direct mail:** Printed letters or postcards sent by post to property owners.
- **DNC Registry:** The National Do Not Call Registry (United States).
- **Motivated seller:** An owner whose situation gives them a reason to sell relatively quickly or on flexible terms.
- **Probate:** The legal process of settling a deceased person's estate, often involving the sale of property.
- **TCPA:** The Telephone Consumer Protection Act (United States), which regulates telemarketing calls and text messages.
- **Wholesaling:** Contracting to buy a property and then assigning that contract to another buyer for a fee (rules vary by state).

---

*The Real Estate Lead Generation Engine — Larry J Gathers Sr. Educational material only; not legal, financial, or tax advice. No results are guaranteed. Comply with all applicable laws, including the TCPA, Do Not Call rules, and your state's real estate regulations.*
