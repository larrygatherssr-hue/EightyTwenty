# RE-08 — The Real Estate Lead Generation Engine

**Price:** $397 (one-time) | **Category:** Real Estate | **SKU:** RE-08

A complete lead-generation system for investors and agents doing 0–5 deals a year: an 11-module course covering direct mail, cold calling, SMS, online ads, and referral partnerships, with scripts, tracking tools, and a 90-day campaign calendar.

## Files in This Folder

| File | What it is |
|---|---|
| `content.md` | The full 11-module course text — foundations, seller segments, all five channels, CRM and tracking, follow-up, conversion, and the 90-day campaign, with worked examples and real numbers |
| `workbook.md` | Companion workbook — 12 fill-in worksheets and checklists, including the weekly scorecard, channel comparison, offer worksheet, and 90-day campaign planner |
| `templates/lead-tracking-crm.csv` | Lead-tracking CRM spreadsheet (CSV) — every lead, its source, next action, and history |
| `templates/script-library.md` | Direct-mail and SMS script library — 5 mail letters, 2 postcards, 5 SMS scripts, cold-call scripts with objection responses |
| `templates/90-day-campaign-calendar.md` | Day-by-day 90-day campaign calendar in four phases (Launch, Learn, Optimise, Decide) |
| `sales-page.md` | Full sales page — headline, problem, solution, module list, who it is for / not for, price, guarantee, FAQ, disclaimers |
| `listing.json` | Marketplace listing data (SKU, price, billing, headline, description, SEO keywords, refund and support terms) |
| `cover.md` | Cover design brief (black-and-gold luxury branding) |
| `cover.png` | Generated product cover image (1344 × 1792 px PNG) |
| `onboarding.md` | Customer onboarding guide — what to do first, how to use each file, two-week schedule, support |
| `README.md` | This file |

## Key Facts

- Price: $397, one-time payment, 14-day money-back guarantee
- No guaranteed lead counts, deal counts, or income claims anywhere in the product
- Compliance guidance included for cold calling, SMS, and direct mail (TCPA, Do Not Call, state rules); buyers are directed to consult an attorney
- All content original, written for this product
