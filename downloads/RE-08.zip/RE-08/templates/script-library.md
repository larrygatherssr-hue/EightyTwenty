# Direct-Mail and SMS Script Library

**For use with The Real Estate Lead Generation Engine (RE-08).**

## Disclaimer

These are starting-point templates, not legal advice. Adapt them to your market and your state's rules. Cold calling, SMS, and direct mail are regulated (including the TCPA, the National Do Not Call Registry, and state rules). Do not send marketing texts without documented prior express consent. Scrub calling lists against the Do Not Call Registry. Consult a qualified attorney before launching cold-call or SMS campaigns.

---

## Part 1 — Direct-Mail Letters

### Letter 1: First touch — general absentee owner

> Dear [Owner Name],
>
> My name is [Your Name]. I buy houses in [County], and I noticed you own the property at [Address].
>
> If you have ever thought about selling — especially if managing the property has become more trouble than it is worth — I would like to make you a fair cash offer and close on your timeline. There are no fees, no commissions, and no obligation.
>
> You can reach me directly at [Phone Number]. If now is not the right time, please keep this letter — I will follow up in a few weeks.
>
> Thank you for your time,
> [Your Name]

### Letter 2: Probate / inherited property

> Dear [Owner Name],
>
> My name is [Your Name]. I buy houses in [County]. I understand you may have recently inherited the property at [Address], and I am sorry for your loss.
>
> If selling the property would help settle the estate, I can make a fair cash offer and close on your family's timeline, with no fees or commissions. There is no obligation, and I am happy to answer any questions first.
>
> You can reach me directly at [Phone Number].
>
> With sympathy,
> [Your Name]

### Letter 3: Pre-foreclosure / financial difficulty

> Dear [Owner Name],
>
> My name is [Your Name]. I buy houses in [County], including properties where the owner needs to sell quickly.
>
> If you are facing a difficult situation with the property at [Address], I may be able to help with a fast, straightforward cash purchase — no fees, no commissions, and no need to make repairs.
>
> You can reach me directly and confidentially at [Phone Number]. There is no obligation.
>
> Sincerely,
> [Your Name]

### Letter 4: Tired landlord

> Dear [Owner Name],
>
> My name is [Your Name]. I buy rental properties in [County]. If managing the property at [Address] — tenants, repairs, vacancies — has become more trouble than it is worth, I would like to make you a fair cash offer and take it off your hands.
>
> I can close on your timeline, with no fees or commissions and no obligation.
>
> You can reach me directly at [Phone Number].
>
> Thank you,
> [Your Name]

### Letter 5: Follow-up letter (third touch)

> Dear [Owner Name],
>
> I wrote to you a few weeks ago about the property at [Address]. I am following up briefly in case the timing is better now.
>
> I buy houses in [County] and can make a fair cash offer and close on your timeline — no fees, no commissions, no obligation, and no need to make repairs.
>
> If selling is something you are considering, now or in the future, my number is [Phone Number].
>
> Thank you,
> [Your Name]

---

## Part 2 — Postcards

### Postcard A: General (follow-up touch)

Front: "We Buy Houses in [County] — Cash Offer, Fast Close, No Fees."

Back: "Hi, I'm [Your Name]. I buy houses in [County] in any condition. If you are thinking about selling [Address], call or text me at [Phone Number] for a fair cash offer. No obligation."

### Postcard B: Market-update style (quarterly nurture)

Front: "Thinking about selling in [County]?"

Back: "The market has changed since my last note. If you would like a no-obligation cash offer on [Address], call or text [Your Name] at [Phone Number]."

---

## Part 3 — SMS Scripts (warm leads only)

**Use these only with people who have already engaged with you (replied to mail, submitted a form with consent, or asked to be contacted). Do not use them for cold outreach to purchased lists. Honour every STOP request immediately.**

### Follow-up after a mail reply

> Hi [Name], this is [Your Name]. Thanks for reaching out about [Address]. Would a quick call tomorrow work to talk through your timeline?

### Check-in with a warm lead

> Hi [Name], checking in — are you still considering selling [Address]? Happy to make an offer whenever you are ready. — [Your Name]

### Appointment confirmation

> Hi [Name], just confirming our walkthrough on [Day] at [Time] for [Address]. Reply YES to confirm or let me know a better time.

### After an appointment

> Hi [Name], thanks for showing me [Address] today. I will have your offer to you by [Day]. Any questions in the meantime, just reply here. — [Your Name]

### Re-engagement after 30 days of silence

> Hi [Name], this is [Your Name]. We spoke about [Address] a while back. Has anything changed on your side? No pressure either way — just checking in.

---

## Part 4 — Cold-Call Scripts

### Opening script (30 seconds)

> Hi, is this [Name]? I'm [Your Name], I buy houses in [County]. Do you have 30 seconds?
>
> I'm calling because you own the property at [Address], and I wanted to ask if you have ever thought about selling it.

### Qualifying questions (ask after they engage)

1. How is the property doing — does it need much work, or is it in good shape?
2. If you did sell, when would you want that to happen?
3. What has you thinking about selling now, rather than a year from now?
4. If you were to sell, what price would you need to see?

### Objection responses

- **"I'm not interested."** — "I understand. If anything changes, would it be all right if I checked back in a few months?"
- **"How much will you pay?"** — "It depends on the condition and the repairs needed. That is why I would like to see the property. Would [day] work for a quick walkthrough?"
- **"Send me something in writing."** — "Happy to. What is the best email or mailing address? And while I send that, can I ask what your timeline looks like?"
- **"I already have an agent."** — "That is fine — I am glad you have someone representing you. If that changes, my number is [number]."
- **"Don't call me again."** — "Of course, I will remove you from my list right away. Thank you for your time." (Then do it, immediately, and record it.)

### Follow-up call script

> Hi [Name], this is [Your Name] — we spoke a few weeks ago about the property on [Street]. I wanted to check in and see whether anything has changed on your side, or whether your timeline has moved.

---

*Script library for RE-08. Educational material only; not legal advice. Comply with all applicable laws.*
