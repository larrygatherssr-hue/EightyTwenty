# 90-Day Lead-Generation Campaign Calendar

**For use with The Real Estate Lead Generation Engine (RE-08).**

Set your start date, then fill in the calendar dates. This is a template — adjust the days to fit your schedule, but keep the sequence and the spacing.

**Campaign start date:** ______________

## Phase 1 — Launch (Weeks 1–2)

| Day | Task |
|---|---|
| Day 1 | Finalise two seller segments and obtain lists (500–1,000 records each). Record source, date, cost. |
| Day 2 | Write first mail letter and call script. Set up CRM spreadsheet. |
| Day 3 | Scrub calling list against the National Do Not Call Registry. Record scrub date. |
| Day 4 | Send mail drop 1 (1,000 pieces). Start calling (first 50 calls). |
| Day 5 | Enter all replies and call outcomes in the CRM. Set next actions for every lead. |
| Day 8 (Week 2, Mon) | First weekly scorecard. Review: contacts, leads, appointments, offers, contracts by channel. |
| Day 9 | Launch online ads (one campaign, seller leads, small daily budget). |
| Day 10 | Contact three referral partners. |
| Day 11–12 | Calling blocks. Follow up every lead from Week 1. |
| Day 14 | End-of-Phase-1 check: mail, calling, and ads all live; CRM current; weekly rhythm in place. |

## Phase 2 — Learn (Weeks 3–6)

| Week | Task |
|---|---|
| Week 3 | Mail drop 2 (same list, second touch). Follow-up sequence running on all Week 1–2 leads. |
| Week 4 | Monthly review: which channel has produced leads? Any channel with zero leads after 500 contacts gets its message or list questioned. Refresh calling list. |
| Week 5 | Mail drop 3. Optimise ads once — change one variable only (audience, message, creative, or landing page). |
| Week 6 | Partner check-ins (monthly). Review follow-up tracker: every lead older than 7 days without a touch gets one. |

## Phase 3 — Optimise (Weeks 7–10)

| Week | Task |
|---|---|
| Week 7 | Mail drop 4. Shift a small amount of budget toward the channel with the lowest cost per contract so far. |
| Week 8 | Monthly review. Pause or fix any channel with no appointments after consistent effort. |
| Week 9 | Refresh lists (remove sold properties, bad addresses, opt-outs). Add one new segment only if the first two are stable. |
| Week 10 | Review ad performance after the optimisation. Review referral partners: who has referred, who has not, and why. |

## Phase 4 — Decide (Weeks 11–12)

| Week | Task |
|---|---|
| Week 11 | Full data review: 90-day totals by channel — spend, leads, cost per lead, appointments, cost per appointment, contracts, cost per contract. |
| Week 12 | Final review meeting (with yourself). Document: what worked, what did not, exact numbers. Decide the next 90 days: scale the best channel by 25–50%, keep or replace the weakest, add a third channel only if the first two are tracked and stable. Schedule the next campaign start date. |

## Weekly Rhythm (every week, all 12 weeks)

- **Monday (1 hour):** Weekly scorecard — fill in the workbook's Worksheet 8.
- **Tuesday–Thursday:** Outreach blocks (calls, mail preparation, ad checks).
- **Friday (30 minutes):** Follow-up block — every lead older than 7 days without a touch gets one.
- **Monthly (2 hours):** Channel review — keep, fix, or stop each channel based on cost per appointment and cost per contract.

## Milestone Checklist

- [ ] Day 4: Mail drop 1 sent
- [ ] Day 9: Ads live
- [ ] Day 10: Three referral partners contacted
- [ ] Week 2: First weekly scorecard complete
- [ ] Week 3: Mail drop 2 sent
- [ ] Week 4: First monthly review complete
- [ ] Week 5: Mail drop 3 sent; ads optimised once
- [ ] Week 7: Mail drop 4 sent
- [ ] Week 8: Second monthly review complete
- [ ] Week 12: Final review complete; next 90 days planned

---

*90-day campaign calendar for RE-08. Educational material only; not legal, financial, or tax advice. No results are guaranteed.*
