# The Real Estate Lead Generation Engine — Companion Workbook

**By Larry J Gathers Sr**

Use this workbook alongside `content.md`. Print it or copy it into your own notebook. Every worksheet is meant to be filled in with your real numbers — blank worksheets are a plan; completed ones are a business.

## Disclaimer

This workbook is educational material, not legal, financial, or tax advice. No results are guaranteed. Cold calling, SMS, and direct mail are regulated (including the TCPA, the National Do Not Call Registry, and state rules). You are responsible for complying with all applicable laws and for consulting a qualified attorney before launching cold-call or SMS campaigns. Do not send marketing texts without documented prior express consent. Honour every opt-out immediately.

---

## Worksheet 1 — My Starting Channels

**My two starting channels (from Module 1):**

1. Channel: ______________________ Why this one: ______________________
2. Channel: ______________________ Why this one: ______________________

**Channel I will add later (only when the first two are tracked and stable):**

Channel: ______________________ Condition for adding it: ______________________

**My weekly rhythm (block these in your calendar for 12 weeks):**

- Monday review (1 hour): Day/time: ______________________
- Outreach blocks (Tue–Thu, 2 hours/day): Days/times: ______________________
- Friday follow-up (30 minutes): Day/time: ______________________
- Monthly channel review (2 hours): Date: ______________________

**My baseline today (be honest — zero is a valid baseline):**

- Live leads: ______
- Conversations in progress: ______
- Appointments booked: ______
- Offers outstanding: ______
- Contracts signed: ______

---

## Worksheet 2 — Seller Segments and Lists (Module 2)

**Segment 1**

- Situation: ______________________
- How I will find these owners: ______________________
- List source: ______________________
- List date: ______________________
- Records: ______
- Cost: $______
- Can I reach them? (Y/N) ______
- Is the situation verifiable? (Y/N) ______
- Can I genuinely help them? (Y/N) ______

**Segment 2**

- Situation: ______________________
- How I will find these owners: ______________________
- List source: ______________________
- List date: ______________________
- Records: ______
- Cost: $______
- Can I reach them? (Y/N) ______
- Is the situation verifiable? (Y/N) ______
- Can I genuinely help them? (Y/N) ______

**List quality check (sample 50 records):**

- Valid mailing addresses: ______ / 50
- Valid phone numbers: ______ / 50
- Records removed as stale or wrong: ______
- Notes: ______________________

---

## Worksheet 3 — Direct-Mail Math (Module 3)

Fill in with your real prices.

| Item | Your number |
|---|---|
| Pieces mailed | ______ |
| Cost per piece (printing + postage) | $______ |
| Total campaign cost | $______ |
| Responses (leads) | ______ |
| Response rate (leads ÷ pieces) | ______% |
| Cost per lead | $______ |
| Appointments | ______ |
| Cost per appointment | $______ |
| Contracts | ______ |
| Cost per contract | $______ |
| Average profit per deal (your estimate) | $______ |
| Is cost per contract acceptable? (Y/N) | ______ |

**My four mail drops (two weeks apart):**

| Drop | Date | Pieces | List segment | Code on piece |
|---|---|---|---|---|
| 1 | ______ | ______ | ______ | ______ |
| 2 | ______ | ______ | ______ | ______ |
| 3 | ______ | ______ | ______ | ______ |
| 4 | ______ | ______ | ______ | ______ |

**My first letter (draft it here, under 150 words):**

________________________________________________________________________
________________________________________________________________________
________________________________________________________________________

---

## Worksheet 4 — Cold-Calling Plan (Module 4)

**My 30-second opening script (write it out, then practise aloud five times):**

________________________________________________________________________
________________________________________________________________________

**Compliance check (complete before dialling):**

- [ ] List scrubbed against the National Do Not Call Registry on (date): ______
- [ ] State do-not-call rules checked: ______
- [ ] Calling hours confirmed compliant: ______
- [ ] Legal advice obtained if unsure: ______

**Calling log (first 50 calls — use the CRM for the full log):**

| Week | Numbers dialled | Answered | Conversations | Leads | Appointments |
|---|---|---|---|---|---|
| 1 | ______ | ______ | ______ | ______ | ______ |
| 2 | ______ | ______ | ______ | ______ | ______ |
| 3 | ______ | ______ | ______ | ______ | ______ |
| 4 | ______ | ______ | ______ | ______ | ______ |

**What I learned from my first 50 calls:**

- Most common objection: ______________________
- Best-performing opening line: ______________________
- One thing to change next week: ______________________

---

## Worksheet 5 — SMS Plan (Module 5)

**Will I use SMS? (Y/N)** ______

If yes:

- Compliant platform chosen: ______________________
- How it handles consent records: ______________________
- How it handles STOP/opt-out requests: ______________________
- Legal advice obtained (date): ______

**Rule:** No marketing text to any number without documented prior express consent. No exceptions.

**My three follow-up texts (for people who have already engaged):**

1. ________________________________________________________________________
2. ________________________________________________________________________
3. ________________________________________________________________________

---

## Worksheet 6 — Online Ads Test (Module 6)

**Ad job (seller leads / buyer leads — pick one):** ______________________

**Headline:** ______________________

**Landing-page headline:** ______________________

**Form fields (keep to name, phone, address):** ______________________

**Daily budget:** $______ **Test length:** ______ days **Total test budget:** $______

**Kill rule (decide before launching):** "If cost per lead exceeds $______ after 100 clicks, I pause and change one variable."

**Test results:**

| Item | Result |
|---|---|
| Spend | $______ |
| Clicks | ______ |
| Cost per click | $______ |
| Leads | ______ |
| Cost per lead | $______ |
| Appointments | ______ |
| Cost per appointment | $______ |
| Contracts | ______ |
| Cost per contract | $______ |

**One variable I changed, and what happened:** ______________________

---

## Worksheet 7 — Referral Partners (Module 7)

| # | Partner name | Type (attorney / agent / contractor / other) | Contact | Date met | What I offered | Referrals sent | Outcome |
|---|---|---|---|---|---|---|---|
| 1 | | | | | | | |
| 2 | | | | | | | |
| 3 | | | | | | | |
| 4 | | | | | | | |
| 5 | | | | | | | |
| 6 | | | | | | | |
| 7 | | | | | | | |
| 8 | | | | | | | |
| 9 | | | | | | | |
| 10 | | | | | | | |

**My one-page partner sheet (draft the key lines here):**

- What I buy: ______________________
- My market: ______________________
- How to refer: ______________________

**Monthly check-in dates:** ______________________

---

## Worksheet 8 — Weekly Scorecard

Copy this table every Monday for 12 weeks. Judge channels by cost per contract, not by cost per lead.

**Week of:** ______

| Channel | Spend | Contacts | Leads | Cost/lead | Appointments | Cost/appt | Offers | Contracts | Cost/contract |
|---|---|---|---|---|---|---|---|---|---|
| Direct mail | $______ | ______ | ______ | $______ | ______ | $______ | ______ | ______ | $______ |
| Cold calling | $______ | ______ | ______ | $______ | ______ | $______ | ______ | ______ | $______ |
| SMS | $______ | ______ | ______ | $______ | ______ | $______ | ______ | ______ | $______ |
| Online ads | $______ | ______ | ______ | $______ | ______ | $______ | ______ | ______ | $______ |
| Referrals | $______ | ______ | ______ | $______ | ______ | $______ | ______ | ______ | $______ |
| **Total** | $______ | ______ | ______ | — | ______ | — | ______ | ______ | $______ |

**This week's decision:**

- Keep: ______________________
- Fix (what, and how): ______________________
- Stop: ______________________

---

## Worksheet 9 — Channel Comparison

Complete after 30 days of tracking, then again at 90 days.

| Channel | Cost/lead | Cost/appointment | Cost/contract | Hours/week | Verdict (keep / fix / stop) |
|---|---|---|---|---|---|
| Direct mail | $______ | $______ | $______ | ______ | ______ |
| Cold calling | $______ | $______ | $______ | ______ | ______ |
| SMS | $______ | $______ | $______ | ______ | ______ |
| Online ads | $______ | $______ | $______ | ______ | ______ |
| Referrals | $______ | $______ | $______ | ______ | ______ |

**My best channel by cost per contract:** ______________________

**My worst channel, and what I will do about it:** ______________________

---

## Worksheet 10 — Offer Worksheet (Module 10)

Use for every property before you name a price.

- Property address: ______________________
- After-repair value (ARV): $______
- Estimated repair costs: $______
- Holding costs: $______
- Selling/closing costs: $______
- Desired profit margin: $______
- Maximum allowable offer: $______
- Offer I will make: $______
- Exit strategy (flip / hold / wholesale / other): ______________________
- Why this exit fits this property: ______________________

---

## Worksheet 11 — 90-Day Campaign Calendar

See `templates/90-day-campaign-calendar.md` for the full day-by-day plan. Use this page for your dates.

- Campaign start date: ______
- Mail drop 1: ______ Drop 2: ______ Drop 3: ______ Drop 4: ______
- Ads launch date: ______
- First referral outreach: ______
- Week 4 review: ______
- Week 8 review: ______
- Week 12 final review: ______

**My 90-day budget:**

| Item | Budget |
|---|---|
| Direct mail | $______ |
| Online ads | $______ |
| Lists and data | $______ |
| Phone / messaging platform | $______ |
| Referral lunches and thank-yous | $______ |
| **Total** | $______ |

**My 90-day targets (targets, not guarantees):**

- Leads: ______
- Appointments: ______
- Offers: ______
- Contracts: ______

---

## Worksheet 12 — Follow-Up Tracker

| Lead name | Property | Last contact | Next touch (date + method) | Touch # | Notes |
|---|---|---|---|---|---|
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |

**Rule:** Every lead has a next action and a date. A lead without one is a lead already lost. If a seller asks you to stop contacting them, stop immediately and record it.

---

## Pre-Launch Checklist

Complete before Day 1 of your campaign:

- [ ] Two seller segments chosen and lists obtained (Worksheet 2)
- [ ] Two starting channels chosen (Worksheet 1)
- [ ] First mail piece written and priced (Worksheet 3)
- [ ] Call script written and practised (Worksheet 4)
- [ ] DNC scrub completed and recorded (Worksheet 4)
- [ ] SMS platform chosen, or SMS deliberately excluded (Worksheet 5)
- [ ] Landing page and first ad written (Worksheet 6)
- [ ] Three referral partners contacted (Worksheet 7)
- [ ] CRM set up with all current leads entered
- [ ] Weekly rhythm blocked in calendar for 12 weeks
- [ ] 90-day budget written (Worksheet 11)
- [ ] Week 12 review scheduled

---

*The Real Estate Lead Generation Engine — Companion Workbook. Educational material only; not legal, financial, or tax advice. No results are guaranteed.*
