# Customer Onboarding Guide — The Real Estate Lead Generation Engine (RE-08)

Welcome. This guide tells you what to do first, how to use each file, and how to get through your first two weeks without getting overwhelmed.

## What You Bought

A complete lead-generation system for investors and agents doing 0–5 deals a year:

- `content.md` — the full 11-module course
- `workbook.md` — companion workbook with 12 fill-in worksheets
- `templates/lead-tracking-crm.csv` — lead-tracking CRM spreadsheet
- `templates/script-library.md` — direct-mail letters, postcards, SMS scripts, cold-call scripts
- `templates/90-day-campaign-calendar.md` — day-by-day 90-day plan
- `cover.png` — product cover
- `sales-page.md`, `listing.json`, `cover.md`, `README.md` — product and listing information

## Important Note Before You Start

This product is educational material, not legal, financial, or tax advice. No results are guaranteed. Cold calling, SMS, and direct mail are regulated (including the TCPA, the National Do Not Call Registry, and state rules). You are responsible for complying with all applicable laws and for consulting a qualified attorney before launching cold-call or SMS campaigns. Do not send marketing texts without documented prior express consent.

## What to Do First (Day 1)

1. **Read the disclaimer** at the top of `content.md`. It matters.
2. **Read Module 1.** It explains the whole system in one sitting.
3. **Open the CRM spreadsheet** (`templates/lead-tracking-crm.csv`) in Excel or Google Sheets. Delete the example row. Enter every live lead you have today — even if that is zero. Zero is a valid baseline.
4. **Complete Workbook Worksheet 1.** Choose your two starting channels. Do not start with all five.
5. **Block your weekly rhythm in your calendar for 12 weeks:** one hour Monday (review), outreach blocks Tuesday–Thursday, 30 minutes Friday (follow-up).

## Suggested Two-Week Schedule

**Week 1**

- Day 1: Read Modules 1–2. Complete Worksheets 1–2. Pick your two seller segments.
- Day 2: Read Module 3. Write your first mail letter (Worksheet 3). Price a 1,000-piece mailing.
- Day 3: Read Module 4. Write your call script. Scrub your calling list against the National Do Not Call Registry and record the date.
- Day 4: Send mail drop 1. Make your first 50 calls. Log everything in the CRM.
- Day 5: Read Module 8. Fill in your first weekly scorecard (Worksheet 8). Set a next action for every lead.

**Week 2**

- Day 8 (Monday): Second weekly scorecard. Review what came back from mail and calls.
- Day 9: Read Module 6. Launch your first ad (one campaign, small daily budget, seller leads).
- Day 10: Read Module 7. Contact three referral partners.
- Day 11–12: Read Module 9. Start the follow-up sequence on every lead from Week 1.
- Day 14: End-of-Week-2 check — mail, calling, and ads all live; CRM current; weekly rhythm in place.

## How to Use Each File

| File | How to use it |
|---|---|
| `content.md` | Read in order, one module at a time. Do the Action Step at the end of each module before moving on. |
| `workbook.md` | Fill in as you go. Print it or keep it open alongside the course. |
| `templates/lead-tracking-crm.csv` | Your single source of truth for leads. Update it the same day a lead arrives or changes. |
| `templates/script-library.md` | Copy, adapt, and make the scripts your own. Do not read them word for word without checking they fit your market and your state's rules. |
| `templates/90-day-campaign-calendar.md` | Your day-by-day plan after the first two weeks. Follow the four phases: Launch, Learn, Optimise, Decide. |

## After the First Two Weeks

Follow the 90-day campaign calendar. Every Monday, fill in the weekly scorecard. Every Friday, do your follow-up block. At Week 4 and Week 8, do the monthly channel review. At Week 12, do the full review and plan your next 90 days.

## How to Get Support

- **Delivery or access problems:** Contact EightyTwenty marketplace support with your order number and the product SKU (RE-08).
- **Questions about using the materials:** Re-read the module that covers the topic — most questions are answered there, and the workbook has a worksheet for each one.
- **Legal, licensing, or compliance questions:** Consult a qualified attorney in your state. The seller does not provide legal advice.

## One Last Thing

A pipeline is built by doing, not by reading. Read Module 1 today, send your first mail drop and make your first calls this week, and track everything. In 90 days you will have real numbers — and real numbers are the engine.

Good luck.
