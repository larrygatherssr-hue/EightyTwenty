# Customer Onboarding — The Complete Pet Care & Wellness Guide

Welcome, and thank you. This guide will walk you through your first week with the product so you get the most from it quickly.

> This product is education only. It provides general information about everyday care for dogs and cats. It does not replace veterinary care. If your pet is injured or unwell, contact your veterinarian or an emergency veterinary clinic immediately.

## What you received

- **content.md** — the full 180-page illustrated digital guide (13 chapters, plus appendices)
- **workbook.md** — the companion workbook with 9 worksheets
- **templates/** — first-aid quick-reference cards, vaccination and vet-visit tracker (CSV and printable Markdown), senior-care checklist, seasonal care calendar
- **sales-page.md** — the full sales page for this product
- **cover.png** and **cover.md** — the cover image and its design brief
- **README.md** — an index of all files

## What to do first (Day 1, about 30 minutes)

1. Read the disclaimer at the top of content.md, then read Chapter 1 (How to Use This Guide) and Chapter 2 (Knowing Your Pet: What "Normal" Looks Like).
2. Save your vet's phone number and the nearest emergency veterinary clinic's number and address in your phone, and write them on the first-aid cards.
3. Print the first-aid quick-reference cards from the templates folder. Put one set on the fridge, one in the car, and one inside your pet first-aid kit.
4. Fill in Worksheet 1 (My Pet's Baseline) in the workbook: weight, food amount, feeding times, medications, vaccination dates, and your vet's details.

## Your first week

- **Day 2–3:** Read Chapter 3 (dogs) or Chapter 4 (cats) — whichever applies to your pet — and start the daily routine in it.
- **Day 4:** Read Chapter 5 (Nutrition Basics) and work through the feeding example for your pet's weight. Measure the food from now on.
- **Day 5:** Read Chapter 6 (Grooming) and Chapter 7 (Exercise and Enrichment). Start the grooming schedule and the exercise plan in the workbook.
- **Day 6:** Read Chapter 8 (First Aid Basics and Emergency Recognition) and build your first-aid kit from the list in that chapter.
- **Day 7:** Read Chapter 13 (Putting It All Together) and complete Worksheet 9 (My Everyday Care Plan). Pick one change to make this week, and do it for two weeks before picking the next one.

## Suggested schedule after the first week

- **Daily:** the routine in Chapter 3 or 4 (about 20–30 minutes for dogs, 15–20 for cats), plus the five-minute daily check from Chapter 2.
- **Weekly:** a grooming session from Chapter 6, and a review of the Health Observation Log in the workbook.
- **Monthly (1st of the month):** weigh your pet, check body condition, check flea and worming dates, check the food supply, and complete the senior-care checklist if your pet is a senior.
- **Every six months:** a vet check for senior pets; an annual check and dental check for all pets.
- **Seasonally:** work through the relevant section of the seasonal care calendar in the templates folder.

## How to use the materials

- The guide is a reference, not a book to read once. Use the table of contents to find the chapter you need, when you need it.
- The workbook worksheets are designed to be printed and filled in by hand. Photocopy the daily checklist and the health observation log so you always have a fresh copy.
- The vaccination and vet-visit tracker (CSV) opens in any spreadsheet app. Keep it updated at every vet visit and treatment date.
- The seasonal care calendar is a year-round planner — work through one season at a time.

## How to get support

For questions about your order, file delivery, or the 14-day money-back guarantee, contact EightyTwenty marketplace support through the marketplace help or contact page, quoting your order number and the product SKU PET-10. For questions about the guide content, include the chapter number in your message. Support replies within two business days.

This product does not include one-to-one coaching or veterinary advice. For any concern about an individual pet's health, contact your veterinarian or an emergency veterinary clinic.
