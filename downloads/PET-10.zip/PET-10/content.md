# The Complete Pet Care & Wellness Guide: Everyday Health, Safety, and Happiness

## Important Disclaimer — Please Read First

This guide is education only. It is general information about everyday care for dogs and cats. It does not replace veterinary care, and it is not a substitute for professional advice, diagnosis, or treatment for any individual animal. Every dog and cat is different: age, breed, size, health history, medications, and living situation all change what is right for them.

If your pet is injured, is in pain, cannot breathe normally, has collapsed, is bleeding heavily, has eaten something toxic, is vomiting repeatedly, has not passed urine, or is behaving in a way that alarms you, contact your veterinarian or an emergency veterinary clinic immediately. Do not wait to finish reading this guide. When in doubt, call your vet — a phone call costs nothing and can save a life.

The first-aid information in this guide describes simple, sensible steps you can take while you get professional help. It does not teach you to diagnose or treat disease at home. Never give your pet human medicine unless your veterinarian has specifically told you to do so for that pet, at that dose, at that time. Common human medicines — including ibuprofen, paracetamol/acetaminophen, and aspirin — can seriously harm or kill dogs and cats.

Throughout this guide, wherever a sign could be urgent, it is flagged as **Call your vet now** or **Emergency — go now**. Take those flags seriously.

---

## Table of Contents

1. How to Use This Guide
2. Knowing Your Pet: What "Normal" Looks Like
3. Daily Care Routines for Dogs
4. Daily Care Routines for Cats
5. Nutrition Basics: Feeding the Right Amount
6. Grooming: Coat, Skin, Nails, Ears, Teeth, and Eyes
7. Exercise and Enrichment: A Tired Pet Is a Happy Pet
8. First Aid Basics and Emergency Recognition
9. Recognising Illness: Early Warning Signs
10. Senior Care: Caring for an Older Dog or Cat
11. Seasonal Care: Heat, Cold, Holidays, and Travel
12. Preparing for Vet Visits
13. Putting It All Together: Your Everyday Care Plan
Appendix A: Quick-Reference Numbers
Appendix B: Household Hazards Checklist
Appendix C: Glossary

---

## Chapter 1: How to Use This Guide

You bought this guide because you want one trusted place to look things up instead of searching the internet at midnight while your dog is vomiting or your cat is hiding under the bed. That is exactly what this is for.

This is a written guide, not a video course. Read it in order the first time if you can, but you do not have to. Each chapter stands on its own. When something happens, use the table of contents, find the chapter, and read the relevant section. The companion workbook gives you checklists and logs to fill in, and the templates folder holds printable first-aid cards, a vaccination and vet-visit tracker, a senior-care checklist, and a seasonal care calendar. Print the first-aid cards and put them where you can grab them — on the fridge, in the car, and in your pet first-aid kit.

A few principles run through everything in this book:

**Prevention is cheaper and kinder than treatment.** Most of the misery in pet ownership — dental disease, obesity, fleas, preventable infections — is avoidable with small, regular habits. A five-minute daily check beats a five-hundred-dollar emergency visit.

**Know your own pet's normal.** A guide can tell you the normal range for a dog's resting heart rate, but only you know that your dog normally sleeps curled in a tight ball, or that your cat normally greets you at the door. Changes from normal are the earliest warning sign you will ever get, and you are the only person who can spot them. That is why Chapter 2 comes before everything else.

**Small numbers, kept consistently, beat heroic efforts.** Feeding the right amount every day matters more than one perfect week. A short walk every day matters more than a three-hour hike once a month. Brushing teeth three times a week matters more than a single heroic scrub.

**When in doubt, call the vet.** This is not a cop-out. It is the single most useful sentence in this book. Veterinarians would far rather take a two-minute phone call that turns out to be nothing than see a pet twelve hours too late. If you take one habit from this guide, take that one.

### Who this guide is for

First-time dog and cat owners who want a reliable reference, and busy owners who want to stop guessing. It covers dogs and cats kept as companion animals in a home. It does not cover breeding, working dogs, exotic pets, or farm animals, and it does not cover the care of very young orphaned puppies or kittens in detail — if you are hand-raising a puppy or kitten under eight weeks old, ask your vet for a specific plan.

### What you will be able to do by the end

- Run a calm, repeatable daily routine for a dog or a cat, in about 20 to 30 minutes a day.
- Feed the right amount for your pet's weight and life stage, and judge body condition by feel, not by the bowl.
- Groom safely at home and know when a professional groomer or vet is the right call.
- Give your pet enough exercise and mental stimulation for their age and breed.
- Recognise the signs that need a routine vet visit, the signs that need a same-day visit, and the signs that are an emergency.
- Give basic first aid while you get to a vet, including what to do for choking, wounds, heatstroke, and poisoning.
- Care for a senior pet with confidence, and plan for the seasons, holidays, and travel.

---

## Chapter 2: Knowing Your Pet — What "Normal" Looks Like

Before you can recognise a problem, you need a baseline. Spend one quiet week noticing your pet, and write the answers in the Health Observation Log in the workbook. The numbers below are typical ranges for healthy adult dogs and cats. They are guides, not rules — a large dog's heart beats more slowly than a small dog's, and a kitten's heart beats faster than an adult cat's. Your vet can confirm what is normal for your pet at a routine visit.

### Vital signs at rest

| Measure | Dog (adult) | Cat (adult) |
|---|---|---|
| Temperature | 38.3–39.2 °C (101–102.5 °F) | 38.1–39.2 °C (100.5–102.5 °F) |
| Heart rate (resting) | 60–120 beats per minute; small dogs up to 140 | 140–220 beats per minute |
| Breathing rate (resting, asleep) | 10–30 breaths per minute | 20–30 breaths per minute |
| Water intake | About 40–60 ml per kg of body weight per day | About 40–60 ml per kg of body weight per day |

A sleeping breathing rate is one of the most useful numbers you can learn. Count breaths while your pet is asleep and relaxed, not after play. A sleeping breathing rate consistently above 30 breaths per minute in a dog, or above 40 in a cat, is worth a vet call. A rate above 40 at rest in either species is a reason to call the same day.

To take a temperature at home you need a digital thermometer designed for pets and a little water-based lubricant. It is a rectal measurement, and many pets dislike it. You do not need to do this routinely. Learn it once, with your vet or vet nurse showing you, so you can do it calmly if your vet asks for a reading over the phone. A temperature above 39.5 °C (103 °F) or below 37.5 °C (99.5 °F) in a dog or cat is a reason to call your vet.

### The five-minute daily check

Do this once a day, ideally at the same time — while your pet is relaxed, not during play. Run through it in the same order every time so it becomes habit:

1. **Eyes:** Clear and bright, no cloudiness, no yellow or green discharge, no squinting, pupils roughly equal.
2. **Ears:** Clean, dry, no strong smell, no redness or dark discharge, no head shaking or scratching.
3. **Nose:** Dogs' noses vary from wet to dry through the day; what matters is change — persistent discharge, crusting, or bleeding.
4. **Mouth:** Gums pink (not pale, white, blue, or brick red), breath not suddenly foul, no broken teeth, no lumps on the gums.
5. **Coat and skin:** No new lumps, bald patches, redness, flaking, or sores. Run your hands over the whole body — this is also how you find ticks.
6. **Body shape:** Ribs easy to feel under a thin layer of fat, waist visible from above and tucked up from the side. (More on this in Chapter 5.)
7. **Movement:** Walking, running, and jumping as usual; no limping, stiffness, or reluctance to move.
8. **Eating, drinking, toileting:** Appetite normal, water intake normal, stools formed, urination normal in frequency and colour.
9. **Behaviour:** The usual level of interest in you, in food, in play, and in their surroundings.

If one thing is slightly off and your pet is otherwise bright and eating, watch it for 24 hours and write it down. If two or more things are off, or any single thing is markedly wrong, call your vet. Trust the pattern, not the single data point.

### Worked example: building a baseline

Maya is a 14 kg adult mixed-breed dog. Her owner spends a week noting: sleeping breathing rate 16–20 breaths per minute; drinks about 700 ml of water a day (about 50 ml per kg — right in range); eats twice a day with enthusiasm; stools firm and twice daily; coat glossy; gums pink. Six months later, Maya is drinking 1,400 ml a day, urinating more often, and her sleeping breathing rate is 34. Because her owner knows the baseline, she calls the vet the same day instead of waiting a week. The vet finds an early problem that is much easier to manage because it was caught early. That is the whole point of a baseline: it turns a vague worry into a concrete, actionable observation.

### Records worth keeping

Keep a simple file — paper or digital — with: your pet's microchip number, vaccination dates, worming and flea treatment dates and product names, any medications with doses, your vet's phone number and the nearest emergency clinic's number and address, your pet insurance details if you have them, and a recent photo of your pet from the side and the front. The vaccination and vet-visit tracker in the templates folder is built for exactly this. If your pet ever goes missing or needs emergency care away from home, this file is worth its weight in gold.

---

## Chapter 3: Daily Care Routines for Dogs

A dog's day has a shape, and dogs are happiest when that shape is predictable. You do not need a rigid timetable — you need a reliable rhythm. The routine below takes about 20 to 30 minutes of active attention spread across the day, plus walks. Adjust the times to your life; keep the order steady.

### Morning (10 minutes)

1. **Toilet break first.** Let your dog out or take them for a short walk as soon as they wake. Most dogs need to urinate within minutes of waking, and puppies, seniors, and dogs on medication may need to go urgently.
2. **Fresh water.** Empty the bowl, rinse it, and refill with fresh water. Wash food and water bowls daily — a slimy biofilm builds up in bowls within 24 hours, and it carries bacteria.
3. **Breakfast.** Feed the measured amount (see Chapter 5). Do not free-feed an adult dog — a bowl left full all day makes it impossible to know how much they ate, and it is the fastest route to obesity.
4. **Quick body check.** While your dog is eating or settling, do the five-minute check from Chapter 2 in shortened form: eyes, ears, coat, movement, stool from the morning toilet break.
5. **Medication, if any.** Give any prescribed medication with or after food as your vet directed, and tick it off in your log so you never double-dose.

### Midday

- **Toilet break and short walk or play.** An adult dog should not routinely be left without a toilet break for more than 6 to 8 hours. Puppies need a break every 2 to 4 hours; seniors every 4 to 6 hours.
- **Mental stimulation.** A food puzzle, a stuffed chew toy, or a short training session (five minutes of practising "sit", "stay", "come") tires a dog out more effectively than an extra half-hour of walking, and it prevents boredom behaviours like chewing and barking.

### Evening (10–15 minutes)

1. **Main walk.** The longest walk of the day, with time to sniff. Sniffing is not wasted time — it is how dogs gather information, and it is mentally tiring. Let them sniff.
2. **Dinner.** Same measured amount as breakfast, at roughly the same time each day.
3. **Grooming touch.** A quick brush (two minutes for a short-coated dog, five for a long-coated one), a check of paws for cuts, thorns, or cracked pads, and a wipe of the face for breeds with skin folds.
4. **Settle-down routine.** Dogs sleep 12 to 14 hours a day. A calm final toilet break, fresh water, and a comfortable, draught-free sleeping spot complete the day.

### Toileting: what is normal

Most adult dogs urinate 3 to 5 times a day and pass stools 1 to 3 times a day. Stools should be firm, moist, and easy to pick up — the classic description is "like a firm sausage". Very hard, dry pellets suggest not enough water or fibre; loose or watery stools for more than 24 hours, blood in the stool, or straining without producing anything are all reasons to call your vet. **Straining to urinate with little or no urine produced is an emergency, especially in male dogs and male cats — a blocked bladder can be fatal within a day.**

### Puppies: the first six months

Puppies need more of everything, more often: feeding 3 to 4 times a day until about six months, toilet breaks every 2 to 4 hours, and short, frequent play sessions instead of long walks. A useful rule for walk length is about 5 minutes of formal exercise per month of age, twice a day — so a 4-month-old puppy gets about 20 minutes twice a day. More than that risks strain on growing joints. Socialisation — calm, positive exposure to people, other dogs, sounds, and places — is the most important job of the first 16 weeks, and it should happen after the first vaccinations, following your vet's advice about what is safe in your area.

### Worked example: a day for a 20 kg adult dog

- 7:00 — toilet break, fresh water, breakfast: 250 g of a complete dry food (about half the daily ration), medication with food.
- 7:15 — five-minute body check while he settles.
- 12:30 — toilet break, 15-minute walk, food puzzle with a few kibbles.
- 17:30 — 45-minute walk with sniffing time and a short training game.
- 18:30 — dinner: 250 g dry food.
- 19:00 — brush, paw check, teeth brushing (three times a week).
- 22:00 — final toilet break, fresh water, bed.

Total active care time: about 25 minutes plus walks. That is the whole job, done well, every day.

---

## Chapter 4: Daily Care Routines for Cats

Cats are often described as low-maintenance. That is half true: they groom themselves, use a litter tray, and sleep for much of the day. But a cat's needs are just as real as a dog's — they are simply quieter about them, and a cat that is unhappy or unwell will often hide it. Your job is to notice.

### The daily routine (15–20 minutes)

1. **Fresh water, every day.** Cats are fussy about water. Wash the bowl daily, place it away from the food bowl (cats prefer to drink away from where they eat), and consider a second water station in another room. Many cats drink more from a wide, shallow bowl or a pet water fountain. A cat that suddenly drinks much more, or much less, than usual needs a vet call.
2. **Food.** Feed measured meals rather than leaving a full bowl down all day, especially for indoor cats. Two meals a day suits most adult cats. See Chapter 5 for amounts.
3. **Litter tray.** Scoop at least once a day, ideally twice. A dirty tray is the most common reason cats start toileting elsewhere. The rule is one tray per cat, plus one extra, in quiet, accessible places. A cat that cries while toileting, strains, passes blood, or stops using the tray needs a vet — **a male cat that strains to urinate and produces nothing is an emergency**.
4. **Play.** Two short play sessions of 5 to 10 minutes — a wand toy, a crinkly ball, a cardboard box — mimic hunting and keep an indoor cat fit and mentally well. End the session by letting the cat "catch" the toy, then offer a small treat or a meal: hunt, catch, eat, groom, sleep is the natural cycle.
5. **Grooming touch.** A quick brush (daily for long-haired cats, weekly for short-haired), a look at the eyes and ears, and a check for mats, especially under the legs and behind the ears.
6. **Watch, don't chase.** The daily check for a cat is mostly observation: is she eating, drinking, using the tray, moving normally, and showing her usual interest? A cat that hides for a whole day, stops eating for more than 24 hours, or stops grooming is telling you something is wrong. **A cat that has not eaten for 48 hours needs a vet the same day — cats can develop a serious liver problem from not eating.**

### The home environment: what cats need

- **Vertical space.** A tall scratching post, a shelf, or a cat tree lets a cat climb and survey its territory. This matters most in multi-cat homes.
- **Hiding places.** A box, a covered bed, or a quiet cupboard. A cat that can hide when it wants to is a calmer cat.
- **Scratching posts.** One tall, sturdy post per cat, placed near sleeping areas. Scratching is normal behaviour — it maintains claws and marks territory. You cannot train it away; you can only redirect it to the right surface.
- **Safe outdoor access, or none.** Indoor cats live longer on average and avoid traffic, fights, and many infections. If your cat goes outside, a secure garden, a catio, or supervised time is safer than free roaming. Either way, identification (microchip) is essential.

### Kittens: the first six months

Kittens eat 3 to 4 small meals a day, play in short, intense bursts, and sleep a great deal — up to 20 hours a day. Handle them gently and often, introduce them calmly to household sounds and visitors, and start litter training, scratching-post use, and gentle grooming early. Kittens need their first vaccinations at around 8 to 9 weeks, with a second set a few weeks later, and should be kept indoors until your vet says it is safe to go out. Discuss neutering/spaying timing with your vet — usually around 4 to 6 months.

### Multi-cat homes

Cats are not naturally group-living animals in the way dogs are. In a multi-cat home, provide separate resources: separate food bowls in different spots, separate water stations, one litter tray per cat plus one, and separate resting places. Tension between cats often shows up quietly — one cat blocking a doorway, one cat eating only when the other is asleep, one cat over-grooming its belly. If you see that, add resources and space before the situation becomes a vet visit for stress-related illness.

### Worked example: a day for a 4.5 kg indoor adult cat

- 7:00 — breakfast: 60 g wet food plus 15 g dry food; fresh water in two stations; scoop litter tray.
- 7:30 — five-minute play session with a wand toy.
- 12:30 — scoop litter tray; short play session; brush (two minutes).
- 18:00 — dinner: 60 g wet food plus 15 g dry food.
- 19:00 — ten-minute play session, then a small treat; check eyes, ears, coat.
- 22:00 — scoop litter tray, fresh water, quiet.

Total active care time: about 15 minutes. The rest is observation — and that counts.

---

## Chapter 5: Nutrition Basics — Feeding the Right Amount

Food is the single biggest lever you have over your pet's health, and the single most common place where good owners go wrong. The problem is rarely the brand of food. It is the amount — and the extras.

### The obesity problem, stated plainly

Around half of pet dogs and cats in many countries are overweight or obese. An overweight dog lives, on average, up to two years less than a lean dog of the same breed, and carries a higher risk of joint disease, diabetes, and heart problems. The good news: weight is almost entirely within your control, and it is fixed by measuring food, not by willpower.

### How much food does my pet actually need?

Start with the food manufacturer's feeding guide, then adjust by body condition — because the guide is written for an average pet, and yours may not be average. The most reliable method is to calculate daily energy needs from body weight, then check the result against body condition every two weeks.

A widely used veterinary formula for resting energy requirement (RER) is:

**RER (kcal/day) = 70 × (body weight in kg)^0.75**

Daily energy needs are RER multiplied by a factor for life stage and activity:

| Pet | Factor × RER |
|---|---|
| Neutered adult dog, normal activity | 1.6 |
| Intact adult dog, normal activity | 1.8 |
| Inactive or overweight-prone dog | 1.2–1.4 |
| Active or working dog | 2.0–3.0 |
| Puppy under 4 months | 3.0 |
| Puppy 4 months to adult | 2.0 |
| Neutered adult cat, indoor | 1.2 |
| Intact adult cat | 1.4 |
| Active outdoor cat | 1.4–1.6 |
| Kitten under 6 months | 2.0–2.5 |
| Overweight cat (weight loss) | 0.8–1.0 |

### Worked example 1: a 10 kg neutered adult dog

RER = 70 × 10^0.75 = 70 × 5.62 = about 394 kcal/day. Daily needs = 394 × 1.6 = about 630 kcal/day. If the food contains 3,600 kcal per kg, that is 630 ÷ 3.6 = about 175 g of dry food per day, split into two meals of about 88 g each. If the dog gains weight over two weeks, reduce by 10 percent (to about 158 g/day) and re-check. If the dog loses weight and should not, increase by 10 percent.

### Worked example 2: a 4.5 kg neutered indoor cat

RER = 70 × 4.5^0.75 = 70 × 3.09 = about 216 kcal/day. Daily needs = 216 × 1.2 = about 260 kcal/day. A typical wet food provides about 80–100 kcal per 100 g, and dry food about 350–400 kcal per 100 g. A practical split: 120 g wet food (about 100 kcal) plus 40 g dry food (about 150 kcal) = about 250 kcal/day. Adjust by body condition every two weeks.

### Worked example 3: a 25 kg active adult dog

RER = 70 × 25^0.75 = 70 × 11.18 = about 783 kcal/day. Daily needs at a factor of 2.0 = about 1,566 kcal/day, or about 435 g per day of a 3,600 kcal/kg food. The same dog, neutered and inactive at a factor of 1.4, needs about 1,096 kcal/day — about 305 g. That is a difference of 130 g a day, or nearly a kilogram a week. Same dog, same food, very different ration. Activity matters.

### Body condition scoring — the test that matters more than the scales

Weigh your pet monthly if you can (stand on the scales holding them, then subtract your own weight; or use the vet's scales at a routine visit). But the daily tool is your hands and eyes. The 9-point body condition scale, simplified to five checks:

1. **Ribs:** You should be able to feel the ribs easily under a thin layer of fat, without pressing hard. If you cannot feel them at all, your pet is overweight. If they are visible with no fat cover, your pet is underweight.
2. **Waist:** Looked at from above, there should be a visible waist behind the ribs.
3. **Tummy tuck:** Looked at from the side, the belly should tuck up behind the ribs, not hang level with the chest.
4. **Fat pads:** No thick pads of fat over the hips or at the base of the tail.
5. **Muscle:** You should feel firm muscle over the shoulders and thighs, not soft fat.

Ideal is a score of 4 or 5 out of 9. If your pet scores 6 or above, reduce food by 10 percent and cut out treats for two weeks, then re-check. If your pet is losing weight without trying, or has a body condition score of 3 or below, call your vet — unexplained weight loss is a warning sign, not a success.

### Choosing a food

Look for a food labelled "complete and balanced" for your pet's life stage (puppy/kitten, adult, senior). That phrase means the food meets recognised nutritional standards for that life stage. Beyond that, the differences between reputable brands are smaller than the marketing suggests. Choose a food your pet eats willingly, that produces firm stools, and that you can afford consistently. Change foods gradually over 7 to 10 days, mixing increasing amounts of the new food with the old, to avoid digestive upset. Raw diets, home-cooked diets, and grain-free diets all carry specific risks — raw meat can carry bacteria that affect pets and people, home-cooked diets are frequently unbalanced without veterinary nutritionist input, and some grain-free diets have been associated with heart disease in dogs. If you want to feed anything other than a standard complete food, discuss it with your vet first.

### Treats and extras

Treats should be no more than 10 percent of daily calories. For the 10 kg dog above, that is about 63 kcal a day — roughly one medium commercial dog biscuit, or a small handful of kibble taken from the daily ration. The easiest trick in this book: measure the day's food, set aside 10 percent of it in a separate pot, and use that as treats and training rewards. The dog gets the same number of calories and still gets rewarded all day. Human foods that are safe in small amounts include plain cooked chicken, carrot pieces, and cucumber. Foods that are dangerous include chocolate, xylitol (a sweetener in sugar-free gum and some peanut butters), grapes and raisins, onions and garlic, macadamia nuts, cooked bones, and alcohol. Keep them out of reach, and check the household hazards checklist in Appendix B.

### Water

Fresh water always available, changed daily, in a clean bowl. Typical intake is 40–60 ml per kg of body weight per day — so a 10 kg dog drinks about 400–600 ml, and a 4.5 kg cat about 180–270 ml. Intake varies with temperature, activity, and whether the pet eats wet or dry food. What matters is change: a pet drinking far more or far less than usual, for more than a day or two, needs a vet call.

### Feeding pitfalls

- **The "one more biscuit" problem.** A 20 kcal biscuit is nothing to a person and 3 percent of a small dog's daily calories. It adds up fast.
- **Feeding from the table.** It teaches begging, unbalances the diet, and risks toxic foods.
- **The guilt meal.** A pet that skips one meal is usually fine. A pet that skips meals for more than 24 hours (dogs) or 24–48 hours (cats) needs a vet call, not a tastier dinner.
- **Feeding a puppy like an adult.** Puppies and kittens need more calories per kilogram and food formulated for growth. Do not feed an adult food to a puppy under 12 months (small breeds) or 18 months (large breeds).
- **Large-breed puppies and calcium.** Over-supplementing calcium in large-breed puppies can harm bone development. Do not add supplements without veterinary advice.

---

## Chapter 6: Grooming — Coat, Skin, Nails, Ears, Teeth, and Eyes

Grooming is not cosmetic. It is health care with a brush. A grooming session is also a full-body examination — you will find lumps, ticks, sore spots, and skin problems weeks before they become visible.

### Brushing

- **Short-coated dogs and cats:** once a week with a rubber brush or bristle brush, two minutes.
- **Medium and long-coated dogs:** two to three times a week, five minutes, working in sections to prevent mats. Mats pull on the skin and can hide sores and infections underneath.
- **Long-haired cats:** daily, two minutes, paying attention to the armpits, behind the ears, and the belly where mats form first.
- Always brush in the direction of hair growth, gently. If you find a mat, work it apart with your fingers or a mat splitter — do not pull it out, and never cut a mat out with scissors close to the skin, because the skin is often pulled up into the mat and is easily cut. A vet or groomer can remove severe mats safely.

### Bathing

Most dogs need a bath every 4 to 8 weeks, or when they are dirty or smelly. Over-bathing strips natural oils and dries the skin. Use a shampoo made for dogs — human shampoo is the wrong pH for dog skin. Wet the coat thoroughly, lather, rinse until the water runs clear, and dry well, especially in cold weather. Cats rarely need baths; if a cat gets something toxic or sticky on its coat, wash it off with warm water and a small amount of cat-safe shampoo, and call your vet if the substance was poisonous. Never use essential oils, flea shampoos meant for dogs, or insecticides on a cat unless the product is labelled safe for cats — permethrin, found in some dog flea products, can kill cats.

### Nails

Nails need trimming when you can hear them clicking on a hard floor, or when they start to curl. For most pets that is every 3 to 4 weeks. Trim a small amount at a time, cutting at an angle, and avoid the quick — the pink blood vessel visible inside pale nails. In dark nails, trim a little at a time and stop when you see a dark dot in the centre of the cut surface. If you cut the quick, it will bleed: press a clean cloth or a styptic pencil against it for a few minutes. If bleeding does not stop within 10 minutes, call your vet. If your pet will not tolerate nail trimming at home, a vet nurse or groomer can do it in minutes — this is not a failure, it is a sensible choice.

### Ears

Check ears weekly. Healthy ears are clean, dry, and odour-free. Clean only the outer ear with a cotton ball and a vet-approved ear cleaner — never push anything down the ear canal, and never use cotton buds inside the ear. Signs of an ear problem: head shaking, scratching at the ears, redness, a strong smell, or dark or yellow discharge. Ear infections are painful and common, especially in floppy-eared dogs, and they need veterinary treatment — do not try to treat them with home remedies.

### Teeth

Dental disease is the most common health problem in adult dogs and cats, and the most preventable. By the age of three, most dogs and cats have some degree of gum disease. The signs — bad breath, red or bleeding gums, tartar on the teeth, reluctance to chew hard food — are easy to miss until the disease is advanced, and advanced dental disease causes pain and can affect the heart, liver, and kidneys.

- **Brush teeth** two to three times a week with a pet toothpaste (never human toothpaste — it contains fluoride and foaming agents that are unsafe to swallow in quantity) and a finger brush or small soft brush. Daily is better. Start slowly: let your pet lick the toothpaste first, then brush one or two teeth, and build up over two weeks.
- **Dental chews and diets** can help, but they do not replace brushing.
- **Annual dental check** at the vet, who can tell you whether a professional clean is needed. A pet that needs a dental clean will need an anaesthetic — that is normal and safe for most pets, and it is the only way to clean under the gum line.

### Eyes

Healthy eyes are clear and bright, with no discharge beyond a small amount of clear tearing. Wipe away any sleep in the corner with a damp cloth. **Squinting, pawing at the eye, cloudiness, a sudden change in eye colour, or a bulging eye is a reason to call your vet the same day.** Eye problems can worsen quickly, and some are emergencies.

### When to use a professional groomer

A professional groomer is the right choice for breed-specific cuts, de-matting, hand-stripping, and any pet that is anxious or difficult to handle safely at home. Tell the groomer about any lumps, sore spots, or sensitivities. A good groomer will tell you if they find anything that needs a vet — listen to them.

---

## Chapter 7: Exercise and Enrichment — A Tired Pet Is a Happy Pet

Most behaviour problems in dogs and cats are not bad behaviour. They are boredom. A dog that chews the furniture, barks all day, or digs up the garden is usually a dog with too much energy and too little to do. A cat that scratches the sofa, wakes you at 3 a.m., or over-grooms is often a cat with too little stimulation. Exercise and enrichment are not optional extras; they are basic care.

### Dogs: how much exercise?

Exercise needs vary hugely by breed, age, and health. These are starting points for a healthy adult dog; adjust for your individual pet and check with your vet if your dog has joint problems, heart disease, or is overweight.

| Dog type | Daily exercise (walks + play) |
|---|---|
| Small companion breeds (e.g., Pug, Cavalier, Shih Tzu) | 30–45 minutes |
| Medium breeds (e.g., Cocker Spaniel, Beagle, Border Terrier) | 60–90 minutes |
| Large active breeds (e.g., Labrador, Golden Retriever) | 90–120 minutes |
| High-energy working breeds (e.g., Border Collie, Husky, German Shepherd) | 2+ hours, plus mental work |
| Giant breeds (e.g., Great Dane, Newfoundland) | 45–60 minutes, gentle |
| Puppies | 5 minutes per month of age, twice daily |
| Senior dogs | 20–45 minutes, gentle, in shorter sessions |

Two important notes. First, mental exercise counts: 15 minutes of scent games or training tires a dog as effectively as 30 minutes of walking. Second, more is not always better — an overweight, unfit, or elderly dog pushed into long runs will be injured, not improved. Build up gradually: increase total exercise by no more than 10 percent a week.

### Safe exercise for dogs

- **Warm up and cool down.** Five minutes of gentle walking before and after vigorous play.
- **Avoid the hottest part of the day.** Exercise in the early morning or evening in summer. See Chapter 11 for heat safety.
- **Watch the surfaces.** Hot pavement burns paws; icy or rough ground cuts them. Check paws after every walk.
- **Swimming** is excellent low-impact exercise for dogs with joint problems, but never leave a dog unsupervised near water, and rinse off afterwards.
- **Never exercise a dog hard straight after a meal.** Wait at least an hour after eating before vigorous exercise, and an hour after exercise before feeding. This reduces the risk of bloat (gastric dilatation-volvulus), a life-threatening emergency in deep-chested breeds.
- **Off-lead play** is wonderful where it is safe and legal. If your dog's recall is not reliable, use a long training lead in an open space instead of letting them off.

### Cats: exercise and enrichment

Indoor cats need deliberate play, because they do not get exercise by going out. Aim for two play sessions a day, 5 to 10 minutes each, using toys that mimic prey: a wand toy dragged along the floor, a small ball, a crinkly toy. Vary the toys — cats lose interest in a toy they see every day. Rotate a small set weekly. Puzzle feeders, where a cat must work to get kibble out of a ball or a board, turn mealtime into a hunting session and slow down fast eaters. A window perch, a bird feeder outside the window, and a tall cat tree all add stimulation without any effort from you.

### Enrichment ideas that cost nothing

- **Scent games for dogs:** hide treats around a room or garden and let the dog find them. Start easy, make it harder over time.
- **The muffin-tin game:** put treats in a muffin tin and cover each cup with a tennis ball. The dog must remove the balls to get the treats.
- **Cardboard boxes for cats:** a box with holes cut in it is a hiding place, a toy, and a scratching post in one.
- **Frozen treats:** freeze a dog's kibble in a little water or low-salt broth in a chew toy for a long-lasting challenge on a hot day.
- **Training:** five minutes a day teaching a new trick is enrichment, bonding, and obedience in one package.

### Worked example: a week of enrichment for a bored Labrador

Monday: 60-minute walk plus a scent game with treats hidden in the garden. Tuesday: 45-minute walk plus 10 minutes of training (recall and "leave it"). Wednesday: 60-minute walk plus a puzzle feeder at dinner. Thursday: swimming or a long sniffy walk in a new place. Friday: 45-minute walk plus a frozen chew toy. Saturday: a longer hike (90 minutes) with a rest day the next day. Sunday: rest — a gentle 30-minute walk and a chew. The owner reports the chewing stopped within two weeks, not because the dog was punished, but because the dog was tired and satisfied.

---

## Chapter 8: First Aid Basics and Emergency Recognition

First aid for pets has one purpose: to keep your pet safe and stable until a veterinarian can take over. It is not treatment. The best first aid is usually simple, calm, and fast — and it starts before anything goes wrong, with a kit and a plan.

### Build a pet first-aid kit (keep it in one box, labelled, where everyone in the house knows it is)

- Your vet's number and the nearest emergency clinic's number and address, written on a card inside the lid.
- Clean gauze pads and bandages, adhesive tape, blunt-ended scissors.
- A clean towel or blanket (for warmth, for carrying, for a muzzle in an emergency).
- Saline solution (for flushing eyes and wounds) — or clean, cool water.
- A digital thermometer and water-based lubricant.
- Tweezers (for ticks and splinters).
- A torch.
- A muzzle or a strip of soft cloth — even the gentlest pet may bite when in pain. Do not muzzle a pet that is vomiting, coughing, choking, or having difficulty breathing.
- A copy of the first-aid quick-reference cards from the templates folder.

Check the kit every six months and replace anything used or expired.

### The first five minutes of any emergency

1. **Stay calm, and keep yourself safe.** A frightened, injured animal may bite or scratch. Approach slowly, speak quietly, and restrain gently.
2. **Check breathing and responsiveness.** Is your pet breathing? Is it responsive to its name or a touch? If your pet is not breathing and you have been trained in pet CPR, begin it — but only if you have been trained. Untrained chest compressions can do harm. The single most useful action in most emergencies is to get to a vet quickly.
3. **Control serious bleeding.** Press a clean gauze pad or cloth firmly onto the wound and hold it. Do not keep lifting it to look — that disturbs clotting. If blood soaks through, add another pad on top. Do not use a tourniquet unless your vet tells you to.
4. **Keep your pet warm and still.** Wrap them in a blanket, keep them lying down, and move them as little as possible. Do not give food or water.
5. **Call the vet while you travel, or have someone else call.** Tell them what happened, what your pet's condition is, and when you will arrive. This lets them prepare.

### Choking

Signs: pawing at the mouth, gagging, retching, distress, difficulty breathing, blue gums. Open the mouth carefully and look — if you can see the object and can remove it easily with your fingers, do so. If you cannot see it or cannot remove it easily, do not push your fingers blindly down the throat — you may push the object further in. For a small dog or cat, hold them with the head down and give four or five sharp taps between the shoulder blades. For a larger dog, stand behind them, place your hands under the ribcage, and give four or five quick upward thrusts (the animal version of the Heimlich manoeuvre). Then check the mouth again. **Even if the object comes out, call your vet the same day — the throat may be injured.**

### Wounds

- **Minor cuts and scrapes:** rinse with clean, cool water or saline, pat dry, and keep an eye on it. Do not apply antiseptic creams made for people unless your vet advises it.
- **Deeper cuts or bites:** apply pressure to stop bleeding, cover with a clean dressing, and go to the vet. Bite wounds often look small on the surface and are much worse underneath, and they frequently become infected. **All bite wounds need a vet visit the same day.**
- **Do not use hydrogen peroxide, alcohol, or TCP on wounds** unless your vet tells you to — they damage tissue and delay healing.

### Heatstroke — a summer emergency

Dogs do not sweat the way people do; they cool themselves mainly by panting. In hot weather, in a hot car, or after over-exercise, a dog can overheat fast. Cats are less prone but not immune. Signs: heavy panting, drooling, bright red or pale gums, weakness, wobbliness, vomiting, collapse, a temperature above 40 °C (104 °F).

**What to do:** move the pet to a cool, shaded place immediately. Cool them with lukewarm water — wet the belly, paws, and ears, and put a fan on them. Do not use ice-cold water or ice, which constricts blood vessels and slows cooling. Offer small amounts of cool water to drink. **Go to the vet immediately, even if the pet seems to recover** — heatstroke can damage internal organs hours later. Prevention is simple: never leave a pet in a parked car, even with the windows open; exercise in the cool of the day; always provide shade and fresh water.

### Poisoning

Common poisons: chocolate, xylitol, grapes and raisins, onions and garlic, rat poison, slug pellets, antifreeze, lilies (extremely toxic to cats — even the pollen), and human medicines. Signs vary: vomiting, diarrhoea, drooling, shaking, seizures, collapse, or nothing at all for hours.

**What to do:** do NOT make your pet vomit unless your vet or a poison helpline specifically tells you to — vomiting can make some poisons worse. Note what your pet ate, how much, and when, and take the packaging with you. **Call your vet or an animal poison helpline immediately.** In the UK, the Animal PoisonLine is 01202 509000; in the US, the ASPCA Animal Poison Control Center is (888) 426-4435. Save the number for your country in your phone now.

### Seizures

A seizure usually lasts one to two minutes. The pet may fall over, paddle its legs, drool, and lose bladder or bowel control. Do not put your hands near the mouth — a seizing pet cannot swallow its tongue, and you will be bitten. Move furniture away, dim the lights, keep the room quiet, and time the seizure. If it lasts more than five minutes, or if there are repeated seizures without recovery in between, **that is an emergency — go to the vet now.** After a single short seizure, keep your pet calm and call your vet the same day. Note the time, the duration, and what happened before and after — your vet will want to know.

### Broken bones and suspected fractures

Do not try to splint a fracture yourself unless your vet tells you to — a badly applied splint can do more harm. Keep the pet still, support the injured limb gently with a folded towel if you must move them, and carry them (small pets) or help them walk slowly (large dogs) to the car. **Go to the vet now.**

### Bloat (gastric dilatation-volvulus) — deep-chested dogs

Signs: a swollen, tight abdomen, retching without producing vomit, restlessness, pacing, drooling, rapid breathing, pale gums. This is most common in large, deep-chested breeds (Great Danes, German Shepherds, Labradors, Standard Poodles). **This is a life-threatening emergency — go to the vet immediately, do not wait.** Prevention: feed two or three smaller meals instead of one large one, avoid vigorous exercise for an hour before and after meals, and use a slow-feeder bowl for dogs that gulp their food.

### When to go now, when to call today, when to watch

- **Go now (emergency):** difficulty breathing, collapse, seizure lasting more than five minutes, uncontrolled bleeding, suspected poisoning, heatstroke, bloat, straining to urinate with no urine, a male cat straining to urinate, a pet that has been hit by a car, a broken bone, or an eye injury.
- **Call today (same-day vet visit):** repeated vomiting or diarrhoea, not eating for more than 24 hours (dogs) or 24–48 hours (cats), a wound or bite, limping, a sudden change in behaviour, drinking far more or far less than usual, a lump that has appeared quickly, or a pet that is clearly in pain.
- **Watch and book a routine visit:** a single episode of vomiting or soft stool in an otherwise bright, eating pet; a small, slow change such as gradual weight gain; a mild, occasional cough; a small skin lump that is not growing, painful, or bleeding. If in doubt, call — that is what the phone is for.

---

## Chapter 9: Recognising Illness — Early Warning Signs

Pets hide illness. It is an instinct: in the wild, a sick animal is a vulnerable animal. By the time a dog or cat looks obviously ill, the problem may have been developing for days or weeks. Your best tool is noticing small changes early.

### The warning signs that matter most

Learn this list. If you notice one of these, note it in the Health Observation Log, and if it persists or if two or more appear together, call your vet.

**Eating and drinking**
- Appetite reduced or lost for more than 24 hours (dogs) or 24 hours (cats — and see the 48-hour rule in Chapter 4).
- Drinking much more than usual for more than two days, or much less.
- Eating non-food items (stones, socks, soil) — this can indicate a deficiency, boredom, or a gut problem, and it can cause a blockage.
- Dropping food, chewing on one side, or crying while eating.

**Toileting**
- Diarrhoea lasting more than 24 hours, or diarrhoea with blood.
- Vomiting more than once in 24 hours, or vomiting that contains blood or looks like coffee grounds.
- Straining to urinate or defecate, blood in urine or stool, or accidents in a previously house-trained pet.
- Much more frequent urination, or much less.

**Movement and energy**
- Limping, stiffness, reluctance to jump, climb stairs, or go for a walk.
- Sleeping far more than usual, or restlessness and pacing at night.
- Weakness, wobbliness, or a sudden loss of coordination.

**Body and coat**
- A new lump or bump, or a lump that is growing, changing colour, bleeding, or painful. Most lumps are harmless, but any new lump should be checked by a vet — a simple needle test can usually tell whether it needs further attention.
- Sudden weight loss or weight gain.
- A dull coat, hair loss, bald patches, excessive shedding, or a sudden increase in scratching or licking one area.
- A swollen face, belly, or limb.

**Behaviour**
- Hiding, withdrawal, or a sudden change in temperament — a friendly pet becoming grumpy, or a quiet pet becoming clingy.
- Excessive vocalisation, or a pet that has gone unusually quiet.
- Confusion, staring into space, getting stuck in corners, or forgetting learned routines (especially in older pets — see Chapter 10).
- Aggression when touched in a particular place — this often means pain, not bad temper.

**Breathing and heart**
- Persistent coughing, especially at night or after exercise.
- Laboured breathing, wheezing, or a sleeping breathing rate consistently above 30 breaths per minute (dogs) or 40 (cats).
- Fainting or collapsing, even briefly.

### Common conditions, in plain language

This is not a diagnostic manual. It is a short guide to what the names mean when your vet mentions them, so you can ask better questions.

- **Arthritis:** joint inflammation, common in older and larger dogs and in older cats. Signs: stiffness after rest, reluctance to jump, a "bunny-hopping" gait. It is manageable with weight control, gentle exercise, pain relief prescribed by your vet, and a comfortable bed. Never give human painkillers — many are toxic to pets.
- **Dental disease:** gum inflammation and tartar build-up. See Chapter 6. It causes real pain and affects the whole body if left untreated.
- **Diabetes:** the body cannot regulate blood sugar. Signs: drinking and urinating far more than usual, weight loss despite a good appetite, lethargy. It is treatable with insulin and diet, but it needs a vet diagnosis and a management plan.
- **Kidney disease:** the kidneys gradually lose function, especially in older cats. Signs: drinking more, urinating more, weight loss, reduced appetite, a dull coat. Caught early, diet and care can slow it down significantly.
- **Thyroid disease:** an overactive thyroid is common in older cats (weight loss despite a big appetite, restlessness, a fast heart rate); an underactive thyroid is common in middle-aged dogs (weight gain, lethargy, a dull coat). Both are treatable.
- **Allergies:** itchy skin, ear infections, or stomach upsets, often seasonal or food-related. Your vet can help identify the trigger — do not guess and change foods repeatedly without a plan.
- **Urinary problems:** crystals or stones in the bladder, or urinary infections. Signs: frequent attempts to urinate, blood in the urine, crying while toileting. **A blocked bladder is an emergency.**
- **Parasites:** fleas, ticks, and worms. They are preventable with regular treatment. Fleas cause itching and can transmit tapeworm; ticks can transmit serious diseases; worms can cause weight loss, diarrhoea, and, in puppies and kittens, serious illness. Use a vet-recommended product on schedule, and treat all pets in the household at the same time.

### Parasite prevention: the simple schedule

Ask your vet which products suit your pet and your area, and put the dates in the tracker. As a general guide: flea treatment every 4 weeks (or as the product directs), worming every 1 to 3 months for adult pets and more often for puppies and kittens, and tick checks after every walk in grass or woodland — run your hands over the whole body, and remove any tick with a tick hook or tweezers, grasping it close to the skin and pulling straight out. Do not squeeze the tick's body. Note the date and watch the area for redness over the next few days.

### Vaccinations

Vaccinations protect against diseases that are often fatal and always unpleasant: parvovirus, distemper, and infectious hepatitis in dogs; feline leukaemia virus, cat flu, and panleukopenia in cats; rabies where it is required by law or for travel. Puppies and kittens need a course of vaccinations starting at around 8 weeks, with boosters at intervals your vet will set. Adult pets need boosters — the interval depends on the vaccine and your pet's risk, and your vet will advise. Keep the dates in the tracker in the templates folder. If you are unsure whether your pet's vaccinations are up to date, call your vet's reception — they can check in a minute.

### When to worry, and when not to

A single vomit after eating too fast, a soft stool after a change of routine, a day of being a little quiet after a vaccination, a sneeze — these are usually nothing. What matters is the pattern: how long it lasts, whether it is getting better or worse, and whether other signs are appearing alongside it. Write it down. Owners who bring a short, dated note to the vet ("vomited twice on Tuesday, once on Wednesday, eating normally, drinking normally") get better advice, faster, than owners who say "he's been sick for a while." The Health Observation Log in the workbook exists for exactly this.

---

## Chapter 10: Senior Care — Caring for an Older Dog or Cat

When is a pet "senior"? Roughly: small dogs from about 10 years, medium dogs from about 8, large and giant dogs from about 6 to 7, and cats from about 10 to 11. But age is a number; what matters is the individual. Some 12-year-old cats are sprightly; some 7-year-old large dogs are already stiff. Senior care is not a different kind of care — it is the same care, done more attentively, with a few adjustments.

### What changes with age

- **Joints:** arthritis is the most common senior problem. Stiffness after rest, hesitation before stairs, and a slower walk are the early signs.
- **Teeth:** dental disease accumulates over a lifetime. A senior pet with bad teeth may eat less, drop food, or eat only soft food.
- **Kidneys and other organs:** kidney function declines gradually, especially in cats. Early signs are subtle: drinking a little more, a slightly duller coat, a small weight loss.
- **Senses:** hearing and sight fade. A senior pet may startle more easily, bump into things, or become anxious in the dark.
- **Brain:** some older pets develop cognitive dysfunction — the pet equivalent of dementia. Signs include disorientation, staring, getting stuck in corners, toileting in the house after years of being clean, and changes in sleep patterns (awake and restless at night, asleep all day).
- **Muscle:** muscle mass declines. A senior pet needs enough protein and gentle exercise to keep what muscle it has.
- **Weight:** seniors can go either way — some gain weight as they slow down, others lose weight because of illness or a reduced appetite. Both need attention.

### The senior routine: adjustments that help

**Twice-yearly vet checks.** A healthy adult pet needs an annual check. A senior pet benefits from a check every six months, with blood and urine tests. These tests catch kidney disease, thyroid problems, diabetes, and liver problems months before symptoms appear, when they are far easier to manage. Ask your vet about a senior wellness blood panel.

**Food.** Senior pets usually need fewer calories because they move less, but they still need good-quality protein to maintain muscle. Do not switch to a "senior" food automatically — many senior foods are simply lower in calories, and a thin senior pet needs the opposite. Ask your vet whether a senior diet suits your pet, and if your pet has a diagnosed condition (kidney disease, for example), a prescription diet may help significantly.

**Exercise, gentler and more often.** Replace one long walk with two or three shorter ones. Keep the total similar, but reduce the intensity: more sniffing, less running, no jumping off high places. For cats, keep play sessions short and gentle, and make sure the toys are easy to catch — a senior cat that never catches the toy will stop playing.

**Comfort at home.** An orthopaedic or well-padded bed, in a warm, draught-free spot. A ramp or steps to the sofa, the bed, or the car, so the pet does not have to jump. Non-slip mats or rugs on slippery floors — a senior dog that slips on a wooden floor will quickly become afraid to walk across it. A night light in the hallway for a pet with fading sight. Litter trays with low sides for a stiff cat, and an extra tray on each floor of the house.

**Grooming.** Older pets groom themselves less, so they need more help from you: more frequent brushing, more attention to mats, and a check for overgrown nails (an older, less active pet wears its nails down less). Be gentle — an arthritic pet may be sore in places that were fine a year ago.

**Mental stimulation.** Keep the brain working: gentle training, scent games, puzzle feeders, new (calm) experiences. A bored senior pet declines faster than a stimulated one.

### Cognitive dysfunction: what to do

If your older pet is disoriented, restless at night, or forgetting housetraining, talk to your vet. There are diets, supplements, and medications that can help some pets, and there are management strategies that help all of them: a strict routine (same feeding times, same walk route, same sleeping place), night lights, a consistent layout of furniture, and patience. Do not punish a senior pet for toileting accidents — it is not defiance, it is confusion or a medical problem. Rule out medical causes first, every time.

### Pain: the question to ask at every visit

Pain in pets is under-recognised because pets hide it. Ask your vet at every senior check: "Do you think my pet is in pain, and what can we do about it?" Modern veterinary pain relief is safe and effective for most pets when prescribed and monitored properly. A pet that is stiff in the morning and fine by midday, that hesitates before jumping, or that has stopped playing, may be in pain that is entirely treatable. The change in a pet that starts proper pain relief is often dramatic — owners say, "I got my old dog back."

### Worked example: a senior care plan for a 12-year-old, 18 kg Labrador

- Vet check and blood panel every six months; weight checked monthly, target 18 kg, body condition score 5 out of 9.
- Food: 380 g per day of a complete adult food (about 1,370 kcal), split into two meals, adjusted by weight. No extra treats beyond a few kibbles from the daily ration.
- Exercise: three walks a day, 15 to 20 minutes each, on flat ground, with sniffing time. No ball chasing or jumping.
- Home: orthopaedic bed in a warm corner, non-slip rugs on the kitchen floor, a ramp to the car, a night light on the landing.
- Grooming: brushing three times a week, nails every three weeks, teeth brushed three times a week.
- Monitoring: owner notes water intake, appetite, toileting, and mobility in the senior-care assessment in the workbook, monthly.
- Medication: a vet-prescribed joint supplement and pain relief, reviewed at each six-month check.

The cost is mostly attention, not money. That is the point: senior care is ordinary care, done carefully, with a vet involved twice a year instead of once.

### End-of-life planning (a short, honest note)

Every pet owner will one day face this. It is kinder to think about it before the crisis than during it. Talk to your vet, in a calm moment, about what a good end looks like for your pet: what signs would tell you that quality of life has gone, what options exist, and what you would want. Quality of life can be judged simply: is my pet eating, drinking, moving without severe pain, interested in me and in life, and having more good days than bad days? When the bad days outnumber the good, it is time for an honest conversation with your vet. You do not need to decide anything now. You only need to know that you can ask.

---

## Chapter 11: Seasonal Care — Heat, Cold, Holidays, and Travel

### Summer and heat

- **Never leave a pet in a parked car.** Even on a mild day, a car heats up to dangerous levels within minutes, and opening a window does not make it safe.
- **Exercise early or late.** Walk dogs before 10 a.m. or after 6 p.m. on hot days. Test the pavement with the back of your hand: if it is too hot for your hand for five seconds, it is too hot for paws.
- **Water and shade, always.** Fresh water in the shade, at home and in the garden. A paddling pool or a damp towel can help a dog cool down.
- **Know the signs of heatstroke** (Chapter 8) and act fast.
- **Sunburn.** White-coated dogs and cats, and cats with white ears, can get sunburn. A vet-approved sunscreen on the ears and nose helps; keep them out of strong midday sun.
- **Barbecues and picnics.** Cooked bones, corn cobs, skewers, and alcohol are all dangerous. Keep food out of reach and watch for dropped items.

### Winter and cold

- **Short-coated, small, elderly, and very young pets feel the cold.** A dog coat is sensible, not silly, for a short-coated dog in freezing weather.
- **Wipe paws after walks.** Road salt and grit irritate paws and are toxic if licked off. Rinse or wipe paws with warm water after every winter walk.
- **Antifreeze is extremely toxic** and tastes sweet to pets. Clean up any spill immediately and store it safely.
- **Outdoor cats** need a warm, dry shelter and unfrozen water. Check under car bonnets before starting the engine — cats shelter there for warmth.
- **Keep the routine.** Shorter walks in bad weather are fine, but replace the lost exercise with indoor play and training so boredom does not set in.

### Spring and autumn

- **Spring:** pollen can trigger allergies in some pets (itchy skin, red eyes, sneezing). Fleas and ticks become active — restart or continue prevention. Watch for spring bulbs (daffodils, tulips, lilies) which are toxic if eaten.
- **Autumn:** fallen leaves hide hazards, and conkers and acorns are toxic. Mushrooms appear — some are poisonous, and you cannot tell which by looking. Keep pets from eating wild mushrooms.

### Fireworks and thunderstorms

Many pets are terrified of fireworks. Prepare in advance: walk the dog early, keep cats indoors, close curtains, turn on the television or music to mask the sound, provide a safe hiding place (a den made from a crate covered with a blanket works well), and stay calm yourself. Do not punish a frightened pet. If your pet is severely distressed, talk to your vet well before firework season — there are medications and calming strategies that help, but they need to be planned in advance. The same applies to thunderstorm phobias.

### Holidays: Christmas and other celebrations

- **Festive foods:** chocolate, mince pies (grapes/raisins), Christmas pudding, stuffing with onions, cooked turkey bones, and xylitol in sugar-free sweets are all dangerous. Keep them out of reach and tell guests not to feed the pet.
- **Decorations:** tinsel, baubles, ribbon, and fairy lights are attractive to cats and can cause blockages or electric shocks if chewed. Keep them high or out of reach.
- **Visitors and noise:** give your pet a quiet room to retreat to, with water, a bed, and a litter tray for cats. A pet that is overwhelmed will be calmer if it can choose to leave.
- **New Year's Eve and other noisy nights:** see the fireworks advice above.

### Travel

- **Car travel:** use a carrier for cats and small dogs, and a harness or crate for larger dogs. Never let a pet travel loose in a car. Take breaks every two hours on long journeys, offer water, and never leave a pet in a parked car.
- **Motion sickness:** some pets, especially puppies, get car sick. Ask your vet about medication if travel is unavoidable. Do not feed a large meal just before travelling.
- **Identification:** a microchip is essential, and a collar tag with your phone number is a useful backup. Check that the microchip details are up to date — a chip with an old phone number is no help.
- **Boarding and pet sitters:** book early for holiday periods, visit the facility first, and leave written instructions: feeding amounts, medication, vet details, and your pet's routine. A good boarding facility will ask for vaccination records. If your pet is anxious, a pet sitter at home may be a better choice than a kennel.
- **Travelling abroad:** rules vary by country and change over time. Check the current requirements well in advance — vaccinations, microchip, parasite treatment, and paperwork. Do not leave it to the last week.

---

## Chapter 12: Preparing for Vet Visits

A vet visit is a partnership. You bring knowledge of your pet; the vet brings medical expertise. The better prepared you are, the better the visit goes — and the less it costs, because the vet spends less time gathering basic information.

### Routine visits: the annual (or six-monthly) check

Bring:
- The vaccination and vet-visit tracker, up to date.
- A note of anything you have observed: changes in appetite, drinking, toileting, weight, behaviour, or mobility, with dates.
- A list of current medications and their doses.
- A fresh stool sample if the vet asked for one (a small sample in a clean bag is fine).
- Your questions, written down. Owners forget questions in the consulting room. Write them down.

During the visit, ask:
- What is my pet's weight, and is it where it should be?
- What is my pet's body condition score?
- How do the teeth look?
- Is there anything you would like me to watch between now and the next visit?
- When should I come back?

### When your pet is unwell

Before the visit, write down:
- When the problem started, and whether it is getting better, worse, or staying the same.
- What the symptoms are, in plain language, with numbers where you have them (how many times they vomited, how much they are drinking, how many breaths per minute while asleep).
- What your pet has eaten, including anything unusual, and any medicines or supplements given.
- Whether other pets in the house are affected.

At the visit, tell the vet the whole story, including things that seem unrelated. A pet that is vomiting and also drinking more than usual is a different problem from a pet that is vomiting alone. Be honest about what happened — if your pet ate chocolate, say so immediately. Vets do not judge; they need the information to help.

### Reducing stress at the vet

Many pets hate the vet. You can make it easier:
- **Cats:** use a carrier they are used to — leave it out at home with a blanket inside for a week before the visit, so it is familiar. Cover the carrier with a towel in the waiting room. Ask the practice whether they have a cat-only waiting area or a quiet time to come in.
- **Dogs:** a short, calm walk before the visit; bring a favourite treat; reward calm behaviour. If your dog is very anxious, ask your vet about a pre-visit calming plan — there are safe options.
- **Both:** keep your own voice calm. Pets read your tension. If you are stressed, they are stressed.

### Costs and insurance

Veterinary care costs money, and emergencies cost more. Ask for an estimate before treatment, and ask what each part of the estimate is for. A good vet will explain the options, including the cost of each, and will not pressure you. Pet insurance can help spread the cost — if you have it, read the policy carefully (what is covered, what the excess is, whether pre-existing conditions are excluded) and keep the details in your file. If you do not have insurance, consider setting aside a small amount each month in a dedicated savings account. The point is to have a plan before the emergency, not during it.

### Second opinions

If you are unsure about a diagnosis or a recommended treatment, you are entitled to ask for a second opinion from another vet. This is normal, professional, and common. A good vet will not be offended. Bring your pet's records and test results with you.

---

## Chapter 13: Putting It All Together — Your Everyday Care Plan

You have read the guide. Now make it yours. A care plan is not a document you frame; it is a short list of habits, kept consistently, and reviewed twice a year. Here is how to build one in an afternoon.

### Step 1: Write down the facts (30 minutes)

Fill in the workbook's Daily Care Checklist and the vaccination and vet-visit tracker. Record: your pet's weight, body condition score, daily food amount, feeding times, exercise routine, grooming schedule, flea and worming dates, vaccination dates, your vet's number, and the nearest emergency clinic's number and address. This is your baseline.

### Step 2: Fix one thing this week

Do not try to change everything at once. Pick the single change that would help your pet most:
- If your pet is overweight, measure the food and cut treats to 10 percent of daily calories.
- If you have never brushed your pet's teeth, buy a pet toothpaste and start with one tooth a day.
- If your pet is bored, add one play session a day.
- If your pet's vaccinations are out of date, book the appointment.
- If you have no first-aid kit, build one this weekend.

Do that one thing for two weeks, until it is a habit. Then pick the next one.

### Step 3: Set a monthly rhythm

- **First of the month:** weigh your pet, check body condition, check the flea and worming dates, check the food supply.
- **Every three months:** review the Health Observation Log. Is anything drifting — weight, drinking, energy, coat? If so, call the vet.
- **Every six months:** senior pets get a vet check. All pets get a dental check at the annual visit.
- **Every year:** annual vet check, vaccinations as advised, and a fresh look at the whole plan — has anything changed? A new home, a new baby, a new pet, a change in your working hours? Adjust the plan to fit your life as it is now, not as it was a year ago.

### Step 4: Keep learning, in small doses

You do not need to become a vet. You need to stay curious. When your vet mentions a condition, ask what it means and what to watch for. When you read a pet-care article, check the source — is it a veterinary organisation, a university, or a company selling something? The most reliable sources are your own vet, veterinary schools, and recognised animal welfare organisations.

### The outcome

If you follow this guide, here is what changes: you stop guessing. You know what your pet eats, how much, and why. You know what normal looks like for your pet, so you spot problems early. You know what to do in the first five minutes of an emergency, and you know when to call the vet instead of waiting. Your pet gets the right food, enough exercise, regular grooming, and a home that suits them. None of that requires special skill, special equipment, or a large budget. It requires attention, a measuring cup, a notebook, and a vet's phone number.

That is the whole guide, in one paragraph. Everything else is detail — and the detail is here whenever you need it.

---

## Appendix A: Quick-Reference Numbers

| Measure | Dog | Cat |
|---|---|---|
| Normal temperature | 38.3–39.2 °C (101–102.5 °F) | 38.1–39.2 °C (100.5–102.5 °F) |
| Resting heart rate | 60–120 bpm (small dogs up to 140) | 140–220 bpm |
| Sleeping breathing rate | 10–30 breaths/min; call vet if consistently above 30 | 20–30 breaths/min; call vet if consistently above 40 |
| Water intake | 40–60 ml per kg per day | 40–60 ml per kg per day |
| Treats | No more than 10% of daily calories | No more than 10% of daily calories |
| Sleep | 12–14 hours per day (adults) | 12–16 hours per day (adults); kittens up to 20 |
| Toilet breaks (dogs) | 3–5 urinations per day; stools 1–3 times per day | N/A |
| Litter trays (cats) | N/A | One per cat, plus one extra |
| Nail trimming | Every 3–4 weeks, or when clicking on hard floors | Every 3–4 weeks, as needed |
| Teeth brushing | 2–3 times a week minimum; daily is better | 2–3 times a week minimum; daily is better |
| Flea treatment | Every 4 weeks, or as the product directs | Every 4 weeks, or as the product directs |
| Worming | Every 1–3 months for adults | Every 1–3 months for adults |

## Appendix B: Household Hazards Checklist

Go through your home once with this list and tick off each item as you deal with it.

- [ ] Chocolate, cocoa, and sweets containing xylitol stored out of reach (high cupboards, closed containers).
- [ ] Grapes, raisins, currants, onions, garlic, and macadamia nuts stored safely; no food left on low tables.
- [ ] Human medicines in a closed cabinet; never given to a pet without veterinary instruction.
- [ ] Rat poison, slug pellets, and insecticides stored securely; note where they are in case of an accident.
- [ ] Antifreeze stored safely; spills cleaned immediately.
- [ ] Cleaning products, bleach, and detergents in closed cupboards.
- [ ] Lilies removed from any home with a cat (all parts of a lily are toxic to cats, including the pollen and the water in the vase).
- [ ] Electrical cables and chargers kept out of reach of chewing puppies, kittens, and bored pets.
- [ ] Small objects that could be swallowed (socks, hair ties, children's toys, coins) kept off the floor.
- [ ] Cooked bones never given to a pet; bones from meals disposed of in a closed bin.
- [ ] The garden checked for toxic plants and for mushrooms in autumn.
- [ ] The pet's microchip details up to date, and a collar tag with a current phone number.
- [ ] Your vet's number and the emergency clinic's number saved in your phone and written on the fridge.

## Appendix C: Glossary

- **Body condition score:** a 1–9 scale for judging whether a pet is underweight, ideal, or overweight, based on feeling the ribs and looking at the waist and tummy from above and from the side. Ideal is 4 or 5.
- **Complete and balanced:** a label on pet food meaning it meets recognised nutritional standards for a stated life stage.
- **RER (resting energy requirement):** the calories a pet needs at rest, calculated from body weight. Daily needs are RER multiplied by a factor for life stage and activity.
- **Bloat (gastric dilatation-volvulus):** a life-threatening emergency in which a dog's stomach fills with gas and twists. Signs include a swollen abdomen and retching without vomiting.
- **Cognitive dysfunction:** age-related decline in brain function in older pets, causing disorientation, changes in sleep, and loss of housetraining.
- **Heatstroke:** dangerous overheating, caused by hot weather, a hot car, or over-exercise. An emergency.
- **Microchip:** a tiny identification chip implanted under the skin, carrying a unique number linked to the owner's contact details on a register.
- **Neutering/spaying:** the surgical procedure that prevents a pet from breeding. Discuss timing with your vet.
- **Tartar:** hardened plaque on the teeth, which causes gum disease if not removed.
- **The quick:** the blood vessel inside a pet's nail. Cutting it causes bleeding and pain.

---

## A Final Word

Your pet does not need a perfect owner. Your pet needs a present one — someone who notices, who measures the food, who makes the vet appointment, who plays for ten minutes, and who calls the vet when something is wrong. That is not a high bar, and it is the whole job.

Keep this guide where you can reach it. Use the workbook. Print the first-aid cards. And when in doubt, call your vet.

*This guide is education only and does not replace veterinary care. If your pet is unwell or injured, contact your veterinarian or an emergency veterinary clinic promptly.*
