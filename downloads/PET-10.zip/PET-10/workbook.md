# Companion Workbook — The Complete Pet Care & Wellness Guide

## Important Disclaimer

This workbook is education only. It is general information about everyday care for dogs and cats. It does not replace veterinary care, and it is not a substitute for professional advice, diagnosis, or treatment for any individual animal. If your pet is injured, unwell, or behaving in a way that alarms you, contact your veterinarian or an emergency veterinary clinic immediately. Never give your pet human medicine unless your veterinarian has specifically told you to do so for that pet, at that dose, at that time.

Print these worksheets and fill them in by hand, or copy them into a notebook or a document. The value is in using them regularly, not in filling them in once and filing them away.

---

## Worksheet 1: My Pet's Baseline

Fill this in during your first quiet week with the guide (Chapter 2 of the guide).

- Pet's name:
- Species and breed:
- Age:
- Sex (male/female, neutered/spayed or intact):
- Weight (kg):
- Body condition score (1–9):
- Microchip number:
- Vet's name and phone number:
- Emergency vet clinic name, phone number, and address:
- Insurance provider and policy number (if any):
- Current food (brand and type):
- Daily food amount (grams):
- Feeding times:
- Current medications (name, dose, time of day):
- Flea treatment (product, date last given, next due):
- Worming treatment (product, date last given, next due):
- Vaccinations up to date? (yes/no — if no, date of appointment booked):
- Sleeping breathing rate (breaths per minute, counted while asleep):
- Typical daily water intake (ml):
- Normal stool frequency and appearance:
- Normal behaviour notes (how my pet usually acts, sleeps, plays, greets me):

## Worksheet 2: Daily Care Checklist

Tick each item daily. Photocopy this page or copy it into a notebook for a fresh week.

| Task | Mon | Tue | Wed | Thu | Fri | Sat | Sun |
|---|---|---|---|---|---|---|---|
| Fresh water, bowls washed | | | | | | | |
| Breakfast — measured amount | | | | | | | |
| Dinner — measured amount | | | | | | | |
| Toilet break / litter tray scooped (morning) | | | | | | | |
| Toilet break / litter tray scooped (evening) | | | | | | | |
| Walk or play session 1 | | | | | | | |
| Walk or play session 2 | | | | | | | |
| Five-minute body check (eyes, ears, coat, movement) | | | | | | | |
| Brushing (dogs: daily for long coats; cats: daily for long hair) | | | | | | | |
| Medication given (if any) | | | | | | | |
| Treats kept within the 10% limit | | | | | | | |

End-of-week note: anything unusual this week? (Appetite, drinking, toileting, energy, coat, behaviour — write it here, with dates.)

## Worksheet 3: Health Observation Log

Use one line per observation. Bring this log to vet visits — a dated note is far more useful than "he's been sick for a while."

| Date | Time | What I noticed | Eating? | Drinking? | Toileting? | Energy/behaviour? | Action taken |
|---|---|---|---|---|---|---|---|
| | | | | | | | |
| | | | | | | | |
| | | | | | | | |
| | | | | | | | |
| | | | | | | | |
| | | | | | | | |
| | | | | | | | |
| | | | | | | | |

Guidance: a single mild sign (one soft stool, one vomit) in an otherwise bright, eating pet can be watched for 24 hours. Two or more signs together, or any single sign that is severe (repeated vomiting, blood, collapse, difficulty breathing, straining to urinate with no urine produced), means call your vet the same day. Straining to urinate with no urine, difficulty breathing, collapse, or a seizure lasting more than five minutes is an emergency — go to the vet now.

## Worksheet 4: Grooming Schedule

| Task | How often | Day(s) | Notes |
|---|---|---|---|
| Brushing | Short coat: weekly; long coat: 2–3 times a week; long-haired cat: daily | | |
| Bathing | Dogs: every 4–8 weeks or when dirty; cats: only when needed | | |
| Nail trimming | Every 3–4 weeks, or when nails click on hard floors | | |
| Ear check | Weekly; clean only the outer ear, never push anything into the canal | | |
| Teeth brushing | 2–3 times a week minimum; daily is better | | |
| Eye check | Weekly; wipe away sleep with a damp cloth | | |
| Full-body hands-on check | Daily (part of the five-minute check) | | |
| Professional groomer | As needed for breed cuts, de-matting, or difficult pets | | |

My pet's grooming notes (sensitive spots, mats to watch, products that work, what the groomer said):

## Worksheet 5: Exercise Plan

My pet's daily exercise target (from Chapter 7 of the guide, adjusted for age, breed, and health):

- Walks per day and length:
- Play sessions per day and length:
- Mental stimulation (training, scent games, puzzle feeders):
- Rest days:

Weekly exercise log:

| Day | Walks (minutes) | Play (minutes) | Training / enrichment | Notes (energy, stiffness, mood) |
|---|---|---|---|---|
| Monday | | | | |
| Tuesday | | | | |
| Wednesday | | | | |
| Thursday | | | | |
| Friday | | | | |
| Saturday | | | | |
| Sunday | | | | |

Rules to remember: build up by no more than 10 percent a week; avoid vigorous exercise in the heat of the day; wait at least an hour after a meal before vigorous exercise, and an hour after exercise before feeding; puppies get about 5 minutes of formal exercise per month of age, twice a day.

## Worksheet 6: Feeding and Weight Tracker

My pet's daily calorie target (from Chapter 5 of the guide):

- Body weight (kg):
- Resting energy requirement (RER) = 70 × (weight in kg)^0.75:
- Activity factor used:
- Daily calories:
- Food (brand, kcal per kg or per 100 g):
- Daily amount (grams), split into ___ meals of ___ g:
- Treat allowance (10% of daily calories):

Monthly weight and body condition log:

| Date | Weight (kg) | Body condition score (1–9) | Ribs easy to feel? | Waist visible? | Tummy tuck? | Action (keep / reduce 10% / increase 10% / call vet) |
|---|---|---|---|---|---|---|
| | | | | | | |
| | | | | | | |
| | | | | | | |
| | | | | | | |
| | | | | | | |
| | | | | | | |

If weight is rising and the pet should not gain: reduce food by 10 percent and cut treats to the 10 percent limit for two weeks, then re-check. If weight is falling without trying, call your vet — unexplained weight loss is a warning sign.

## Worksheet 7: Senior-Care Assessment

For pets aged about 7+ (large dogs) or 10+ (small dogs and cats), or any pet your vet considers senior. Complete monthly.

| Area | This month | Change since last month? | Notes |
|---|---|---|---|
| Weight and body condition | | | |
| Appetite | | | |
| Water intake | | | |
| Mobility (stairs, jumping, stiffness after rest) | | | |
| Toileting (frequency, accidents, straining) | | | |
| Teeth and breath | | | |
| Coat and skin | | | |
| Eyes and hearing | | | |
| Sleep pattern (restless at night? sleeping more?) | | | |
| Behaviour (confusion, staring, getting stuck, withdrawal) | | | |
| Pain signs (hesitation, crying when touched, reluctance to move) | | | |

Vet checks: last senior check (date): ___ Next senior check due (date): ___ Blood/urine tests done? ___

Home comfort checklist: orthopaedic or padded bed in a warm spot; ramp or steps to sofa/bed/car; non-slip mats on slippery floors; night light for fading sight; low-sided litter tray for a stiff cat; extra litter tray on each floor.

Question to ask at every senior vet visit: "Do you think my pet is in pain, and what can we do about it?"

## Worksheet 8: Vet-Visit Prep Sheet

Fill this in before every vet visit and take it with you.

- Pet's name and date of visit:
- Reason for the visit:
- When did the problem start?
- Is it getting better, worse, or staying the same?
- Symptoms (plain language, with numbers: how many times, how much, how long):
- Eating: normal / reduced / not eating (since when?)
- Drinking: normal / more / less (since when?)
- Toileting: normal / diarrhoea / vomiting / blood / straining (details):
- Energy and behaviour: normal / quieter / restless / hiding / other:
- Anything unusual eaten, or any new medicine or supplement given?
- Are other pets in the house affected?
- Current medications and doses:
- My questions for the vet:
  1.
  2.
  3.
- What the vet said (fill in during or after the visit):
- Treatment given and next steps:
- Follow-up appointment date:

## Worksheet 9: My Everyday Care Plan

Write your plan in one page. Review it every six months.

- My pet's daily routine (feeding times, walks/play, grooming touch, bedtime):
- The one change I am making this week:
- The next change after that:
- Monthly check date (weigh, body condition, flea/worming dates):
- Next vet visit date:
- My vet's number and the emergency clinic's number (write them here and on the fridge):
