# First-Aid Quick-Reference Cards

Print these cards, cut them out, and keep them where you can grab them: on the fridge, in the car, and inside your pet first-aid kit. Fill in your vet's details at the top.

**My vet:** ____________________ **Phone:** ____________________
**Emergency vet clinic:** ____________________ **Phone:** ____________________ **Address:** ____________________
**Animal poison helpline:** ____________________

> These cards are education only. They describe simple steps to take while you get professional help. They do not replace veterinary care. If your pet is injured or unwell, contact your veterinarian or an emergency veterinary clinic immediately.

---

## Card 1: The First Five Minutes of Any Emergency

1. Stay calm. Keep yourself safe — a frightened, injured animal may bite or scratch. Approach slowly and speak quietly.
2. Check breathing and responsiveness. Is your pet breathing? Does it respond to its name or a touch?
3. Control serious bleeding: press a clean gauze pad or cloth firmly on the wound and hold it. Do not keep lifting it to look. If blood soaks through, add another pad on top.
4. Keep your pet warm and still. Wrap in a blanket, keep lying down, move as little as possible. Do not give food or water.
5. Call the vet while you travel, or have someone else call. Tell them what happened, your pet's condition, and when you will arrive.
6. Do not muzzle a pet that is vomiting, coughing, choking, or having difficulty breathing.

## Card 2: Choking

Signs: pawing at the mouth, gagging, retching, distress, difficulty breathing, blue gums.

- Open the mouth carefully and look. If you can see the object and remove it easily, do so.
- If you cannot see it, do NOT push fingers blindly down the throat — you may push it further in.
- Small dog or cat: hold with the head down, give 4–5 sharp taps between the shoulder blades.
- Larger dog: stand behind, hands under the ribcage, 4–5 quick upward thrusts.
- Check the mouth again. Even if the object comes out, call your vet the same day — the throat may be injured.

## Card 3: Wounds and Bleeding

- Minor cuts: rinse with clean, cool water or saline, pat dry, watch for redness or swelling.
- Deeper cuts or bites: press a clean pad firmly to stop bleeding, cover with a clean dressing, go to the vet. **All bite wounds need a same-day vet visit** — they often look small on the surface and are worse underneath.
- Do not use hydrogen peroxide, alcohol, or TCP on wounds unless your vet tells you to.
- If bleeding does not stop after 10 minutes of firm pressure, go to the vet now.

## Card 4: Heatstroke

Signs: heavy panting, drooling, bright red or pale gums, weakness, wobbliness, vomiting, collapse, temperature above 40 °C (104 °F).

- Move the pet to a cool, shaded place immediately.
- Cool with lukewarm water — wet the belly, paws, and ears; use a fan. Do NOT use ice-cold water or ice.
- Offer small amounts of cool water to drink.
- **Go to the vet immediately, even if the pet seems to recover.** Heatstroke can damage internal organs hours later.
- Prevention: never leave a pet in a parked car; exercise in the cool of the day; always provide shade and fresh water.

## Card 5: Poisoning

Common poisons: chocolate, xylitol, grapes and raisins, onions and garlic, rat poison, slug pellets, antifreeze, lilies (extremely toxic to cats — even the pollen), human medicines.

- Do NOT make your pet vomit unless your vet or a poison helpline specifically tells you to.
- Note what was eaten, how much, and when. Take the packaging with you.
- **Call your vet or an animal poison helpline immediately.**

## Card 6: Seizures

- A seizure usually lasts 1–2 minutes. The pet may fall over, paddle its legs, drool, and lose bladder or bowel control.
- Do NOT put your hands near the mouth — a seizing pet cannot swallow its tongue, and you will be bitten.
- Move furniture away, dim the lights, keep the room quiet, and time the seizure.
- If it lasts more than 5 minutes, or there are repeated seizures without recovery in between, **go to the vet now — this is an emergency.**
- After a single short seizure, keep your pet calm and call your vet the same day. Note the time, duration, and what happened before and after.

## Card 7: Bloat (Deep-Chested Dogs) — Emergency

Signs: swollen, tight abdomen; retching without producing vomit; restlessness and pacing; drooling; rapid breathing; pale gums.

- **Go to the vet immediately. Do not wait.** Bloat is life-threatening.
- Prevention: feed two or three smaller meals instead of one large one; avoid vigorous exercise for an hour before and after meals; use a slow-feeder bowl for dogs that gulp food.

## Card 8: Go Now, Call Today, or Watch?

**Go now (emergency):** difficulty breathing; collapse; seizure over 5 minutes; uncontrolled bleeding; suspected poisoning; heatstroke; bloat; straining to urinate with no urine (especially male dogs and male cats — a blocked bladder can be fatal within a day); hit by a car; broken bone; eye injury.

**Call today (same-day vet visit):** repeated vomiting or diarrhoea; not eating for more than 24 hours (dogs) or 24–48 hours (cats); a wound or bite; limping; sudden behaviour change; drinking far more or far less than usual; a lump that appeared quickly; a pet clearly in pain.

**Watch and book a routine visit:** a single vomit or soft stool in an otherwise bright, eating pet; gradual weight gain; a mild occasional cough; a small lump that is not growing, painful, or bleeding. If in doubt, call — that is what the phone is for.
