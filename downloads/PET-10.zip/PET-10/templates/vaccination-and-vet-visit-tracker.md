# Vaccination and Vet-Visit Tracker

Pet name: ____________________  Species/breed: ____________________  Date of birth: ____________________
Microchip number: ____________________  Vet name and phone: ____________________
Emergency vet clinic name, phone, and address: ____________________
Insurance provider and policy number (if any): ____________________

## Vaccinations

| Vaccine | Date given | Next due | Vet / clinic | Notes |
|---|---|---|---|---|
| | | | | |
| | | | | |
| | | | | |
| | | | | |
| | | | | |

## Flea and Worming Treatments

| Treatment | Product name | Date given | Next due | Notes |
|---|---|---|---|---|
| Flea | | | | |
| Flea | | | | |
| Flea | | | | |
| Worming | | | | |
| Worming | | | | |
| Worming | | | | |
| Tick check after walks | | | | |

## Vet Visits

| Date | Reason for visit | Weight (kg) | Body condition score (1–9) | What the vet found | Treatment / advice | Follow-up date |
|---|---|---|---|---|---|---|
| | | | | | | |
| | | | | | | |
| | | | | | | |
| | | | | | | |
| | | | | | | |
| | | | | | | |

## Medications

| Medication | Dose | How often | Start date | End date | Prescribed by | Notes |
|---|---|---|---|---|---|---|
| | | | | | | |
| | | | | | | |
| | | | | | | |

## Notes

- Puppies and kittens need a course of vaccinations starting at around 8 weeks, with boosters at intervals your vet will set.
- Adult pets need boosters — the interval depends on the vaccine and your pet's risk; your vet will advise.
- If you are unsure whether your pet's vaccinations are up to date, call your vet's reception — they can check in a minute.
- This tracker is education only and does not replace veterinary advice. Keep your vet's records as the authoritative source.
