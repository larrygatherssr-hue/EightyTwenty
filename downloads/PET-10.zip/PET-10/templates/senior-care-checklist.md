# Senior-Care Checklist

For dogs aged about 7+ (large breeds) or 10+ (small breeds), and cats aged about 10+. Complete monthly, and bring it to vet visits.

Pet name: ____________________  Age: ____________________  Weight (kg): ____________________

> This checklist is education only. It does not replace veterinary care. If your pet is unwell or you are worried, contact your veterinarian.

## Monthly Health Check

- [ ] Weight recorded and compared with last month (target weight: ______ kg)
- [ ] Body condition score recorded (1–9; ideal 4–5)
- [ ] Appetite normal (eating willingly, finishing meals)
- [ ] Water intake normal (note any increase or decrease)
- [ ] Toileting normal (frequency, consistency, any accidents or straining)
- [ ] Mobility checked (stairs, jumping, stiffness after rest, limping)
- [ ] Teeth and breath checked (red gums, tartar, bad breath, dropping food)
- [ ] Coat and skin checked (dull coat, hair loss, lumps, sores)
- [ ] Eyes and hearing checked (cloudiness, bumping into things, not responding to name)
- [ ] Sleep pattern noted (restless at night, sleeping much more than usual)
- [ ] Behaviour noted (confusion, staring, getting stuck, withdrawal, new anxiety)
- [ ] Pain signs checked (hesitation before moving, crying when touched, reluctance to play)

## Vet Care

- [ ] Vet check booked every 6 months (last check: __________; next due: __________)
- [ ] Senior blood and urine panel done at last check (yes/no)
- [ ] Medications reviewed at last check (joint supplement, pain relief, other)
- [ ] Question asked at the visit: "Do you think my pet is in pain, and what can we do about it?"

## Food

- [ ] Daily food amount measured and recorded (______ g per day, split into ______ meals)
- [ ] Food amount adjusted for weight change (reduce 10% if gaining, call vet if losing without trying)
- [ ] Good-quality protein maintained to preserve muscle
- [ ] Fresh water always available, changed daily

## Exercise

- [ ] Exercise adjusted to shorter, gentler sessions (2–3 short walks rather than one long one for dogs)
- [ ] Play sessions kept short and easy to win for cats
- [ ] No jumping from high places; no ball chasing or rough play if joints are sore

## Comfort at Home

- [ ] Orthopaedic or well-padded bed in a warm, draught-free spot
- [ ] Ramp or steps to the sofa, bed, or car
- [ ] Non-slip mats or rugs on slippery floors
- [ ] Night light in the hallway for fading sight
- [ ] Low-sided litter tray for a stiff cat; extra tray on each floor of the house
- [ ] Grooming help increased (older pets groom themselves less; check for mats and overgrown nails)

## Mental Stimulation

- [ ] Gentle training, scent games, or puzzle feeders offered regularly
- [ ] Routine kept consistent (same feeding times, same walk route, same sleeping place)
- [ ] Furniture layout kept stable for a pet with fading sight or confusion

## When to Call the Vet

Call the same day if you notice: unexplained weight loss; drinking much more or less than usual; repeated vomiting or diarrhoea; not eating for more than 24 hours; stiffness or limping that is new or worsening; confusion, disorientation, or loss of housetraining; or any sign that your pet is in pain. Go now if your pet collapses, has difficulty breathing, has a seizure lasting more than five minutes, or strains to urinate with no urine produced.
