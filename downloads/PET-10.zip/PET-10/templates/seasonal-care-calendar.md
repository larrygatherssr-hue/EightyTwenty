# Seasonal Care Calendar

A year-round planner for dog and cat owners. Tick off each item as you do it, and adjust the dates to your local climate.

> This calendar is education only and does not replace veterinary care.

## Spring (March – May)

- [ ] Flea and tick prevention restarted or continued as the weather warms
- [ ] Worming treatment checked and given if due
- [ ] Vaccinations checked — are boosters due?
- [ ] Allergy watch: itchy skin, red eyes, sneezing — note and tell your vet if it persists
- [ ] Garden checked for toxic spring bulbs (daffodils, tulips, lilies — lilies are extremely toxic to cats)
- [ ] Grooming: shedding season — brush more often; check for mats as the winter coat comes out
- [ ] Weight check after winter: has your pet gained weight over the colder months?

## Summer (June – August)

- [ ] Never leave a pet in a parked car — not even for a minute, not even with the windows open
- [ ] Walks moved to early morning or evening; pavement tested with the back of your hand (too hot for your hand = too hot for paws)
- [ ] Fresh water and shade always available, at home and in the garden
- [ ] Heatstroke signs reviewed (Chapter 8 of the guide) — heavy panting, drooling, weakness, collapse
- [ ] Sun protection for white-coated pets and cats with white ears (vet-approved sunscreen; keep out of strong midday sun)
- [ ] Barbecues: cooked bones, corn cobs, skewers, and alcohol kept out of reach
- [ ] Fireworks planned for (summer festivals and events): safe hiding place, curtains closed, background noise on
- [ ] Holiday care booked early (boarding or pet sitter); written instructions prepared

## Autumn (September – November)

- [ ] Flea and tick prevention continued (fleas can be active well into autumn)
- [ ] Garden checked for conkers, acorns, and wild mushrooms — all potentially toxic
- [ ] Fireworks season (late October to early November): walk the dog early, keep cats indoors, provide a safe den, stay calm
- [ ] Weight check: adjust food as activity drops with shorter days
- [ ] Grooming: check the coat as it thickens for winter; check paws after walks on wet, muddy ground
- [ ] Antifreeze stored safely; any spills cleaned immediately (antifreeze is extremely toxic and tastes sweet)

## Winter (December – February)

- [ ] Short-coated, small, elderly, and very young pets given a coat for cold walks
- [ ] Paws wiped or rinsed with warm water after every walk (road salt and grit irritate paws and are toxic if licked)
- [ ] Outdoor cats given a warm, dry shelter and unfrozen water; check under car bonnets before starting the engine
- [ ] Christmas hazards kept out of reach: chocolate, mince pies, Christmas pudding, stuffing with onions, cooked turkey bones, xylitol in sugar-free sweets, tinsel, baubles, ribbon, fairy lights
- [ ] Quiet room provided for visitors and celebrations, with water, a bed, and a litter tray for cats
- [ ] Indoor play and training increased to replace shorter walks
- [ ] New Year's Eve fireworks: same plan as autumn fireworks season

## Every Month, All Year

- [ ] Pet weighed; body condition score checked (ribs easy to feel, waist visible, tummy tucked up)
- [ ] Flea treatment given on schedule
- [ ] Food supply checked; daily amount still measured, not guessed
- [ ] Health Observation Log reviewed — anything drifting (weight, drinking, energy, coat)?

## Every Six Months, All Year

- [ ] Vet check (senior pets); annual check and dental check for all pets
- [ ] First-aid kit checked and restocked
- [ ] Microchip details checked and updated if you have moved or changed phone numbers
- [ ] This calendar reviewed — has anything in your life changed (new home, new baby, new pet, new working hours)? Adjust the care plan to fit.
