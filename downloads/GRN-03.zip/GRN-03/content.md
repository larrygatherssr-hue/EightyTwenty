# Green Business Launchpad: Start a Profitable Eco Business in 90 Days

**GRN-03 — Green Living & Sustainability — $297 (one-time)**

---

## Important Disclaimer — Please Read First

This program is business education. It teaches you how to validate an idea, price a product or service, find suppliers, and plan a launch. It is not a guarantee of income, profit, or business success. Results vary widely depending on your niche, effort, budget, location, and market conditions. Many new businesses earn little or nothing in their first months, and some fail. The numbers in this program are realistic worked examples and planning illustrations — they are not promises, forecasts, or typical results. Do your own research, check local laws and regulations before selling anything, and consult a qualified professional (accountant, lawyer, or business advisor) before making financial or legal decisions. Nothing in this program is legal, tax, or financial advice.

---

## How to Use This Program

This is a self-paced written course manual. It contains the full teaching of all 10 modules. Work through it in order the first time: each module builds on the one before it. Then use the companion workbook (`workbook.md`) to do the exercises as you go — the workbook is where the learning turns into decisions.

**Suggested pace:** about 60–90 minutes a day, five days a week, for 90 days. Modules 1–3 take roughly the first three weeks; Modules 4–7 take the middle five weeks; Modules 8–10 cover the final four weeks and your launch. If you can only give 30 minutes a day, stretch the plan to 120 days — the sequence matters more than the speed.

**What you need:** a notebook or the workbook, a spreadsheet (any free one works), internet access, and a small test budget. You do not need a website, a logo, or a registered company to start Modules 1–3. You will not be asked to spend real money on inventory until Module 5, after you have validated demand.

---

## Table of Contents

- Module 1 — Start With the Problem, Not the Product
- Module 2 — Choose a Niche You Can Actually Win
- Module 3 — Pick a Business Model That Pays
- Module 4 — Pricing: Charge Enough to Survive
- Module 5 — Suppliers, Materials, and Certifications
- Module 6 — Branding Without Greenwashing
- Module 7 — Sales Channels: Where Your Customers Already Are
- Module 8 — Your 90-Day Launch Plan
- Module 9 — Getting Your First 10 Customers
- Module 10 — From Launch to a Business That Lasts
- Appendix A — Worked Example: The 90-Day Launch Budget
- Appendix B — Worked Example: First-Month Revenue, Three Scenarios
- Appendix C — Glossary and Further Reading

---

# Module 1 — Start With the Problem, Not the Product

Most green businesses fail for the same reason most businesses fail: they start with a product nobody asked for. A founder loves the idea of a bamboo toothbrush subscription, or a refill station, or a line of upcycled tote bags — and spends months perfecting it before discovering that the people they imagined buying it either do not exist in their area, already buy something similar, or will not pay the price the product needs to survive.

This module flips the order. You will start with a problem that real people already pay to solve, then design a green business around it.

## 1.1 What "green" actually means for a business

"Green" is not one market. It is a value that cuts across many markets. A customer does not wake up wanting "green." They wake up wanting clean clothes without harsh chemicals, a lower electricity bill, a gift that does not feel wasteful, a home that smells fresh without synthetic fragrance, or a way to stop throwing away single-use plastic. The environmental benefit is often the second reason they buy — the first reason is a practical problem.

That matters because it changes how you sell. If your only pitch is "this is good for the planet," you are competing with every other green product on virtue alone, and virtue is a weak buying motive when money is tight. If your pitch is "this solves your problem and happens to be better for the planet," you have two reasons to buy instead of one.

Write this down and keep it visible through the whole program: **people buy outcomes, not values.** Your environmental mission is the reason you started. The customer's problem is the reason they pay.

## 1.2 The three questions every idea must pass

Before you invest a dollar, every idea must answer three questions honestly:

1. **Who exactly has this problem?** Not "eco-conscious consumers." A named group you can find: parents of toddlers in your city, owners of small cafes, renters in apartments without composting, dog owners who buy treats weekly. If you cannot name the group and say where they gather, you do not have a market yet — you have a hope.
2. **What do they do about it today?** Every problem already has a solution, even if it is a bad one. People buy conventional cleaning products, throw food scraps in the trash, or pay a regular cleaner. Your business has to beat the current solution on something the customer cares about — price, convenience, performance, health, or conscience. "It is greener" only wins when the customer already cares and the other factors are close.
3. **Will they pay for a better answer?** Willingness to pay is not the same as liking your idea. People will praise a refill station at a farmers market and then buy the cheaper bottle at the supermarket. The only evidence that counts is money changing hands — a pre-order, a deposit, a paid pilot, a booking. Everything before that is encouragement, and encouragement does not pay rent.

If an idea fails any of these three questions, it is not a bad idea — it is an untested one. Testing is what the rest of this module is about.

## 1.3 Finding problems worth solving

You do not need a brainstorming app. You need conversations and observation. Spend the first week of this program doing three things:

**Listen where your future customers complain.** Search local community groups, neighborhood forums, and review sections for complaints, not praise. Look for phrases like "I wish someone would…", "I hate that…", "I keep buying… and throwing away…", "there is nothing local that…". Complaints are unmet demand wearing plain clothes. Collect at least 20 real complaints before you pick an idea.

**Watch what people throw away, replace, and repeat-buy.** Walk through a home, an office, or a small business and list everything that gets used up and bought again: cleaning supplies, packaging, coffee cups, food containers, personal care products, pet supplies, office paper. Repeat purchases are the lifeblood of a small business because you only have to win the customer once. A one-off purchase, like a piece of furniture, has to be re-won every single time.

**Ask ten people, properly.** A proper interview is short and specific. Do not ask, "Would you buy a green cleaning service?" — people say yes to be kind. Ask about their life: "What cleaning products do you buy every month? What do you spend? What frustrates you about them? What would you change if you could?" Then ask about the last time they actually spent money to fix the problem. Past behavior predicts future behavior far better than opinions about the future.

Write every answer down. After ten interviews you will start seeing patterns — the same frustration mentioned three or four times is a signal worth following.

## 1.4 The validation ladder: from free to paid

Validation is a ladder. Each rung costs a little more and proves a little more. Do not skip rungs.

- **Rung 1 — Conversations (free).** Ten interviews, as above. You are looking for a repeated, specific problem and a group you can reach.
- **Rung 2 — A simple offer page (free or nearly free).** Describe the product or service, the price, and what the buyer gets. Share it where your group gathers. Count clicks, sign-ups, and questions — not likes.
- **Rung 3 — A paid test (small money).** Offer a pre-order, a deposit, or a founding-customer price to a small group. Even five paying customers prove more than five hundred likes. If nobody pays, you have learned something cheap instead of learning it after ordering inventory.
- **Rung 4 — A pilot (your first real sales).** Deliver to those first customers, watch what happens, ask what they would change, and fix it before you scale.

A common mistake is treating Rung 1 as validation and jumping straight to ordering stock. Another is treating a failed Rung 3 as a personal failure. It is not. It is the system working: a small, cheap "no" now is worth far more than an expensive "no" later.

## 1.5 Worked example: from vague idea to testable problem

Consider Maya, a fictional founder. Her first idea was "eco-friendly home products" — too broad to act on. After a week of listening, she noticed a repeated complaint from parents in her neighborhood group: they were buying dish soap and laundry detergent in single-use plastic every month, disliked the waste, but found the nearest refill shop a 25-minute drive away. The problem was specific: busy parents wanted refills without the trip.

Her testable offer became: "Refill delivery — laundry detergent and dish soap delivered in reusable containers to your door, collected and refilled on the next delivery, in our neighborhood only." She interviewed twelve parents, built a one-page offer, and offered a founding-customer deal: a first delivery for $18, with the container deposit included. Seven parents paid. That was her validation — not the idea, but seven payments from real people in a group she could reach again.

Notice what Maya did not do: she did not rent a shop, order a thousand bottles, or design a logo first. She proved the problem and the payment, then built the business around the proof.

## 1.6 Your Module 1 actions

1. Write down three green business ideas you are drawn to.
2. For each one, answer the three questions in section 1.2 in writing.
3. Collect 20 real complaints from online groups or conversations.
4. Interview ten people in your most promising group.
5. Complete the Idea Validation Worksheet in the workbook before moving to Module 2.

**Module 1 checkpoint:** you can describe your customer group in one sentence, state their problem in their own words, and name what they do about it today. If you cannot, repeat the interviews — do not move on and hope Module 2 fixes it.

---

# Module 2 — Choose a Niche You Can Actually Win

A niche is not a topic. "Eco products" is a topic. "Plastic-free lunch kits for primary-school children in one city" is a niche: a specific customer, a specific problem, and a place you can reach them. The narrower your niche, the easier everything else becomes — your message is clearer, your marketing is cheaper, and your customers feel like you made this for them, because you did.

## 2.1 Why narrow wins

New founders resist narrowing because it feels like turning customers away. In practice the opposite happens. A broad offer — "sustainable products for everyone" — competes with every large retailer that already sells green products at scale, and you cannot win on price or range against them. A narrow offer competes with almost nobody, because nobody else is serving that exact group with that exact problem.

Narrow also makes your marketing affordable. Reaching "everyone who cares about the planet" would cost a fortune in advertising. Reaching "owners of independent cafes in your county who want compostable packaging" means you can list every cafe, visit them, and talk to the owner by name. For a business with a small budget, that is the only kind of marketing that works reliably.

Finally, narrow makes you an expert faster. When you serve one group deeply, you learn their language, their suppliers, their regulations, and their buying cycle. That knowledge becomes your competitive edge, and it is very hard for a generalist to copy.

## 2.2 The four niche tests

Score each candidate niche from 1 to 5 on each test, and be honest. A niche needs to pass all four — a high score on three and a fail on one is still a fail.

**Test 1 — Reachable.** Can you find and contact these people without spending a fortune? A niche you cannot reach is a theory. Good signs: they gather in specific groups, attend specific events, buy from specific shops, or search specific phrases online. Bad signs: they are scattered, anonymous, or only reachable through expensive advertising.

**Test 2 — Paying.** Do they already spend money on this problem or something close to it? A group that spends nothing on the problem will need to be convinced to start spending, which is slow and expensive. A group already buying a conventional solution has a budget you can redirect.

**Test 3 — Underserved.** Is the current solution genuinely bad for them — inconvenient, overpriced, low quality, or misaligned with their values? If the current solution is fine, you are fighting habit for no clear gain. The best niches are places where customers are quietly dissatisfied and nobody has bothered to fix it.

**Test 4 — You can serve it.** Do you have, or can you realistically learn, the skills, suppliers, and time this niche needs? A niche that requires a food license, a commercial kitchen, and daily deliveries is a different business from a niche that needs a laptop and a postal account. Match the niche to your real life, not to a fantasy version of it.

Use the Niche Selector in the workbook to score at least three candidate niches side by side. The winner is rarely the one you loved most at the start — it is the one that scores best across all four tests.

## 2.3 Three green niche families

Most green businesses fall into one of three families. Knowing which family you are in helps you borrow proven patterns instead of inventing everything from scratch.

**Eco products.** Physical goods with a sustainability story: reusable, refillable, compostable, recycled, or plastic-free products. Strengths: easy to understand, easy to photograph, easy to sell online. Challenges: inventory costs money up front, margins are squeezed by shipping and packaging, and you compete with large retailers. Works best when the product is a repeat purchase or solves a specific problem better than the conventional version.

**Green services.** Doing something for a customer in a greener way: eco cleaning, green gardening, energy-saving home assessments, sustainable event planning, compost collection. Strengths: no inventory, you can start with almost no money, and local services are hard for big companies to copy. Challenges: your time is the product, so growth means hiring or raising prices, and you are limited by geography until you build a team.

**Sustainable consulting and education.** Helping businesses or households become greener: waste audits for small businesses, sustainability advice for cafes and offices, workshops, and digital guides. Strengths: high margins, no stock, and your expertise is the product. Challenges: you need credibility before people pay, sales cycles are longer, and you must be able to prove the value of your advice in money saved or risk reduced.

None of these is better than the others. The right family is the one that fits your skills, your budget, and the niche you chose in section 2.2. Many founders combine two — for example, a green cleaning service that also sells its refill products to clients.

## 2.4 How to research a niche in a weekend

You do not need expensive market research. You need focused observation:

- **Count the competition.** Search for businesses already serving your niche in your area and online. List them: what do they sell, at what price, and what do their customers complain about in reviews? Five competitors with unhappy customers is a good sign; zero competitors usually means zero demand, not a goldmine.
- **Check the price floor and ceiling.** Find the cheapest and most expensive options your customers currently buy. Your price has to live somewhere in that range, or you must be able to explain clearly why it sits outside it.
- **Find where they gather.** List three specific places — online or physical — where your group spends time. If you cannot name three, the niche fails Test 1.
- **Estimate the size.** You do not need an exact number. You need an order of magnitude: are there 200 potential customers in your area, or 20,000? A niche with 200 potential customers can still work if each spends well and buys repeatedly — but you must know which one you are dealing with before you build for the wrong scale.

## 2.5 The niche statement

By the end of this module, write your niche in one sentence using this format:

> "I help [specific customer group] solve [specific problem] with [your green solution], so they can [outcome they care about]."

Example: "I help busy parents in our town get laundry and dish refills delivered in reusable containers, so they can cut single-use plastic without an extra trip to the shops."

If you cannot fill in every bracket with something specific, your niche is still too broad. Narrow it one more step — a smaller group, a sharper problem, or a tighter geography — and try again.

## 2.6 Your Module 2 actions

1. List three candidate niches from your Module 1 research.
2. Score each one on the four niche tests in the workbook.
3. Research the competition, prices, and gathering places for your top niche.
4. Write your one-sentence niche statement and read it aloud. If it sounds like it could describe a hundred businesses, narrow it.
5. Pick your niche — and write down what you are deliberately NOT doing, so you can say no to distractions later.

**Module 2 checkpoint:** you have one niche, one sentence, and evidence that the group is reachable, already spending, and underserved. If two niches tie, choose the one whose customers you can reach this week.

---

# Module 3 — Pick a Business Model That Pays

A business model is simply how you make money: who pays you, for what, how often, and what it costs you to deliver. Two businesses can sell the same green product and have completely different fortunes because one has a model that works and the other does not. This module helps you choose a model that fits your niche, your budget, and your life.

## 3.1 The six models that work for green businesses

**1. Sell a product (one-off sales).** You make or source a product and sell it, usually online or at markets. You get paid per sale. This is the simplest model to understand and the hardest to make profitable at small scale, because every sale carries product, packaging, and shipping costs, and you must win each customer again for the next sale — unless the product is a repeat purchase.

**2. Subscription or refill plan.** Customers pay regularly — monthly or quarterly — for refills, a box, or a service. This is the strongest model for a small green business because revenue becomes predictable and you only have to win the customer once. It also fits green values naturally: refills and reuse are the point. The challenge is that you must deliver reliably every cycle, and early cancellations can hurt.

**3. Service by the job or by the hour.** Green cleaning, gardening, energy assessments, event support. You get paid for work done. Margins can be good and startup costs low, but income stops when you stop working, and growth means hiring people you must train and manage.

**4. Retainer or contract.** A business client pays you monthly for ongoing work — for example, a monthly waste audit and reporting service for a cafe group, or regular sustainable sourcing advice for a small retailer. Retainers are the service equivalent of a subscription and are worth pursuing once you have proven results with one-off jobs.

**5. Digital products and education.** Guides, templates, courses, and workshops sold online. Very high margins once created, no inventory, and no shipping. The trade-off is that you must build an audience before sales arrive, and digital products in a crowded field need genuine depth to stand out.

**6. Marketplace or commission.** You connect buyers and sellers — for example, a local directory of verified green suppliers that charges a listing fee or a small commission. This is the hardest model to start because it needs both sides at once, and it is not recommended as a first business.

Most successful small green businesses use one main model and one supporting model — for example, a refill subscription as the core, plus one-off product sales to non-subscribers.

## 3.2 How to compare models honestly

For each model you consider, answer these five questions in writing:

- **How much money do I need before the first sale?** Product models need stock; service models need almost nothing; digital models need time.
- **How much do I earn per customer, per year?** A customer who buys a $25 product once is worth $25. A subscriber paying $22 a month is worth $264 a year if they stay. That difference changes everything about how much you can spend to win a customer.
- **How repeatable is it?** Does the customer naturally come back, or do you have to persuade them every time?
- **What breaks first when I get busy?** In a product model it is packing and shipping. In a service model it is your calendar. In a subscription model it is fulfilment reliability. Know your bottleneck before it arrives.
- **Can I do this for a year without burning out?** A model that needs you to work every weekend at a market stall is a different life from a model that ships twice a month from your kitchen table. Be honest about the life you want.

Use the Business Model Canvas in the workbook to lay your chosen model out on one page. If you cannot fill in the boxes — especially "who pays," "what it costs," and "how they find me" — the model is not ready yet.

## 3.3 Revenue, costs, and the math that matters

Three numbers decide whether a model works. Learn them now, because Modules 4 and 10 will use them constantly.

**Gross margin** is what is left after the direct cost of what you sold. If you sell a product for $25 and it costs you $11 to make, package, and ship it, your gross margin is $14, or 56%. A service has a gross margin too: if you charge $60 for a clean and spend $12 on supplies and travel, your margin is $48. Low-margin models need high volume to survive; high-margin models can survive on fewer customers.

**Customer acquisition cost (CAC)** is what you spend to win one paying customer — advertising, market stall fees, free samples, and your time at its real value. If you spend $150 on a market stall and win 10 customers, your CAC is $15 per customer. If each of those customers is worth $25 once, you have a problem. If each is worth $264 a year as a subscriber, you have a business.

**Lifetime value (LTV)** is what a customer is worth to you over the whole time they stay. As a rule of thumb, a healthy small business wants LTV to be at least three times CAC. If it is not, either your acquisition is too expensive or your customers are not staying long enough — and you must fix one of those two things before spending more on marketing.

You do not need exact figures yet. You need honest estimates, written down, that you will replace with real numbers once you start selling.

## 3.4 A realistic first-year shape

New founders often imagine a straight line up. Real first years look more like this: a slow start while you find customers, a wobbly middle while you fix what is not working, and — if the model is sound and you keep going — steadier months toward the end of the year. Many green businesses earn very little in the first three months. That is normal, and it is why Module 8 budgets for a slow start instead of pretending launch week pays for everything.

Plan for three phases: **prove** (months 1–3: a small number of paying customers and proof the model works), **stabilise** (months 4–8: repeatable sales, systems that do not depend on heroic effort), and **grow** (months 9–12: more customers, better margins, and the first decisions about hiring or expanding range). If the prove phase fails, you change the offer — you do not double the advertising spend and hope.

## 3.5 Your Module 3 actions

1. List the two models that best fit your niche and your budget.
2. Complete the Business Model Canvas for your first choice in the workbook.
3. Estimate gross margin, CAC, and LTV for that model — even roughly.
4. Decide your main model and your supporting model, and write down why.
5. Name the phase you are in (prove, stabilise, grow) and what would tell you it is time to move to the next one.

**Module 3 checkpoint:** you can explain in two minutes how your business makes money, what it costs to deliver, and what a customer is worth over a year. If you cannot, your model needs more work before you think about pricing.

---

# Module 4 — Pricing: Charge Enough to Survive

Pricing is where green businesses most often fail — not because the product is bad, but because the price is too low. Founders undercharge for three reasons: they compare themselves to mass-market prices they cannot match, they feel guilty charging for something they care about, or they have never added up their true costs. This module fixes all three.

## 4.1 Why underpricing is the most common fatal mistake

A price that is too low does not just mean less profit. It means you cannot afford good materials, you cannot pay yourself, you cannot absorb a supplier price rise, and you cannot spend money reaching new customers. A business that loses a little on every sale cannot fix the problem by selling more — selling more just loses money faster.

There is also a trust problem. In green markets, a price that looks too cheap can make customers suspicious: is the material really what it claims? Will it last? Customers who care about quality and ethics often read a very low price as a warning sign, not a bargain.

The goal of this module is not the highest price you can charge. It is the lowest price at which the business genuinely works — and then a fair margin above it for the value you add.

## 4.2 Cost-plus pricing: the floor

Your price floor is your true cost plus a margin. "True cost" means everything, not just the obvious materials. Work through this list for every product or service:

- **Direct costs:** materials, ingredients, packaging, labels.
- **Delivery costs:** postage, courier, fuel, your time packing and travelling.
- **Selling costs:** marketplace or payment fees (typically 3–5% of the sale, plus any platform commission), market stall fees spread across the day's sales.
- **Overhead:** a fair share of phone, internet, storage, insurance, accounting, and any licences.
- **Your time:** the hours you spend making, packing, delivering, answering customers, and doing admin — valued at a real hourly rate, not zero. If you value your time at zero, you have built yourself a hobby, not a business.

Add those up. That is your cost per unit. Now add a margin. For physical products, a gross margin of 50–60% is a healthy target for a small business; for services, aim higher, because your time is the main cost and you need room for quiet weeks. If the resulting price looks far above what customers pay for the conventional version, you have learned something important: either your costs are too high, or you need to sell on value (quality, convenience, ethics) rather than competing on price — or both.

## 4.3 Value-based pricing: the ceiling

Cost-plus tells you the lowest price you can survive. Value-based pricing tells you the highest price a customer will happily pay, based on what your product or service is worth to them. That worth includes things that never appear on a cost sheet: time saved, health concerns addressed, waste avoided, a problem solved without a trip to the shops, and the feeling of buying from someone whose values match their own.

To find the ceiling, listen to your validation interviews. What did people say the problem costs them today — in money, time, or frustration? A parent who spends $40 a month on single-use cleaning products and hates the waste may gladly pay $35 a month for a refill delivery that saves them a trip and removes the plastic. A cafe owner who pays $200 a month for waste collection may pay $150 for a composting service that cuts that bill and gives them a story to tell customers. Price lives in that gap between what the problem costs now and what your solution is worth.

Never set a price by copying a competitor's price without knowing their costs. A large company with cheap materials and automated packing can profit at a price that would bankrupt you. Your price must be built from your costs and your customers' value — not from someone else's shelf.

## 4.4 Worked example: pricing an eco product from scratch

This is a realistic build-up for a small product a founder might sell: a set of three reusable beeswax food wraps (small, medium, large), sold online.

| Cost item | Per set |
|---|---|
| Organic cotton fabric, beeswax, tree resin, jojoba oil | $3.80 |
| Packaging (kraft sleeve, label, care card) | $0.90 |
| Postage and mailer (tracked, domestic) | $3.40 |
| Payment processing fee (about 3% of a $24 price) | $0.72 |
| Your time: making, packing, admin (25 minutes at $18/hour) | $7.50 |
| Share of overhead (phone, storage, insurance, accounting) | $1.20 |
| **Total true cost per set** | **$17.52** |

At a $24 retail price, the gross margin after direct costs is only about $6.48 — and that is before any discount, return, or advertising spend. That is too thin. At $29, the margin is $11.48, which leaves room for a market-stall fee, a small ad test, or a wholesale discount to a local shop. At $32, the margin is $14.48, but the founder must be confident customers see $32 of value in three wraps.

The honest conclusion from this build-up is not "charge $32." It is that the founder has three levers: reduce costs (buy fabric in larger cuts, batch production to cut time per set), raise the price (sell the value: a set that replaces a year of cling film), or change the offer (sell a bundle with a storage bag at $39, where the extra item costs little but adds perceived value). Most pricing problems are solved by a combination of all three — not by hoping customers will pay more for the same thing.

Do this exact exercise for your own product or service in the workbook's Pricing Worksheet. If the numbers do not work on paper, they will not work in real life either — and it is far cheaper to discover that now.

## 4.5 Pricing structures that help green businesses

- **Bundles.** Group products that are used together (a kitchen starter set, a bathroom refill set). Bundles raise the average order value and let you include a low-cost item that makes the set feel generous.
- **Subscriptions.** A monthly refill price should be slightly cheaper per unit than buying one-off — the customer gets a small saving, and you get predictable revenue. Make cancelling easy; a subscription people feel trapped in generates complaints that cost more than the retained revenue.
- **Founding-customer pricing.** Offer your first 20–50 customers a lower price for life, or for the first three months, in exchange for feedback and a testimonial. This rewards early trust and gives you real users to learn from. Do not make the founding price your permanent price — it was a launch tool, not a business model.
- **Tiered service pricing.** For services, offer two or three clear tiers (for example: a basic clean, a deep clean, a deep clean plus restocking). Most customers choose the middle tier, and the top tier shows what is possible. Three options is enough; more than that creates confusion.
- **Wholesale, carefully.** Selling to a local shop at wholesale usually means giving the shop 40–50% of the retail price. Check that your margin survives that cut before agreeing. Wholesale works when volume makes up for the thinner margin — it fails when you are doing the same work for half the money.

## 4.6 Raising prices without losing customers

Prices rise over time: materials get more expensive, your skills improve, and your reputation grows. Raise prices openly and rarely — once a year, with notice — rather than in small, unexplained jumps. Tell existing customers first, explain what has changed (better materials, new certification, rising supplier costs), and thank them for staying. Loyal customers who understand the reason usually stay; customers who leave over a fair increase were often the ones costing you the most time anyway.

## 4.7 Your Module 4 actions

1. List every true cost of your product or service — including your time.
2. Build your price from the floor up in the Pricing Worksheet.
3. Test the ceiling: ask five people from your niche what they currently spend on the problem and what a good solution would be worth to them.
4. Choose your launch price, your bundle or subscription price, and one price you will test later.
5. Write down the price you will NOT go below, and why.

**Module 4 checkpoint:** you have a launch price built from real costs, a margin you can live with, and a reason the customer will see the value. If the margin is under 40% for a product or under 50% for a service, revisit your costs or your offer before moving on.

---

# Module 5 — Suppliers, Materials, and Certifications

Your green claims are only as strong as your supply chain. A product marketed as plastic-free that arrives in three layers of plastic packaging, or a "natural" cleaning service using conventional chemicals, will be found out quickly — and in a small, local market, one disappointed customer can undo months of work. This module is about building a supply chain you can stand behind.

## 5.1 Finding suppliers you can trust

Start with three supplier types, and talk to all three before committing:

- **Local suppliers** — makers, wholesalers, and distributors in your region. Advantages: short shipping, easier to visit, faster problem-solving, and a local story your customers like. Disadvantages: smaller range and sometimes higher prices.
- **Specialist online suppliers** — companies that focus on eco materials (organic textiles, compostable packaging, refill ingredients). Advantages: wide range, detailed specifications, and often small minimum orders for samples. Disadvantages: shipping costs and distance make quality checks harder.
- **Direct makers and small producers** — the people who grow, make, or process your raw materials. Advantages: the best prices and the most authentic story. Disadvantages: minimum orders, longer lead times, and more work managing the relationship.

For each supplier, ask for samples before ordering in bulk, and ask the same five questions every time: What is the minimum order? What is the lead time? What are the payment terms? What happens if a delivery is damaged or wrong? Can you provide documentation for your environmental claims? A supplier who cannot answer these clearly is a risk, however good their prices look.

## 5.2 Minimum orders, lead times, and the cash trap

The most dangerous moment for a new product business is the first bulk order. Minimum order quantities (MOQs) exist because suppliers need to make production worthwhile — but they can leave you with a garage full of stock that takes a year to sell. Before any bulk order:

- **Order samples first** — small quantities to test quality, packaging, and how the product behaves in real use.
- **Start with the smallest MOQ** you can negotiate, even if the per-unit price is higher. Paying more per unit on 100 units beats paying less per unit on 1,000 units that do not sell.
- **Map lead times onto your launch plan.** If a supplier needs four weeks plus shipping, your 90-day plan must order in week 5, not week 10. Late stock is the most common reason launches slip.
- **Keep a buffer.** Budget for one order going wrong — a damaged delivery, a wrong colour, a delayed shipment. If your plan only works when everything goes perfectly, it is not a plan.

A practical rule: never spend more than 30% of your launch budget on your first stock order. The rest is for reaching customers, packaging, fees, and the mistakes you have not foreseen yet.

## 5.3 Materials: what the words actually mean

Green language is full of words that sound similar and mean different things. Using them wrongly is not just embarrassing — in many countries it can be a legal problem. Learn the differences:

- **Recycled** means made from material that has been used before. Ask what percentage is recycled content, and whether it is post-consumer (from used products) or pre-consumer (factory offcuts).
- **Recyclable** means it can be recycled in theory. It does not mean it will be recycled where your customer lives. Check local recycling rules before claiming it.
- **Compostable** means it breaks down in composting conditions. Home compostable and industrially compostable are different standards, and many "compostable" items only break down in industrial facilities your customers may not have access to.
- **Biodegradable** means it breaks down over time — but almost everything biodegrades eventually, including some plastics over decades. Without a timeframe and conditions, the word means very little.
- **Natural** and **eco-friendly** are not regulated terms in most places. They describe a feeling, not a standard. Avoid them as your main claim; use specific, checkable facts instead ("made with 80% post-consumer recycled paper," "free from synthetic fragrance").

When in doubt, say less and prove more. One specific, true statement beats five vague green adjectives.

## 5.4 Certifications: useful, expensive, and optional at first

Certifications can build trust, but they cost money and time, and you do not need them all on day one. Here is an honest overview of the landscape — check the current requirements in your country before applying for any of them, as schemes and fees change:

- **Organic certifications** (for food, textiles, and cosmetics) verify how ingredients or fibres were grown and processed. They are credible and widely recognised, but certification can take months and cost hundreds to thousands of dollars a year. Relevant if your core claim is organic.
- **Fairtrade and similar ethical labels** verify labour and trading conditions for producers, mainly for food and textiles from developing countries. Valuable if your story involves producer fairness.
- **Forestry labels (such as FSC)** verify that paper and wood come from responsibly managed forests. Relatively accessible for packaging and printed materials.
- **Compostability marks** verify that a material breaks down under specified composting conditions. Useful if compostability is your main selling point — and a good way to avoid making the claim without proof.
- **Cruelty-free and vegan labels** verify that products were not tested on animals or contain no animal-derived ingredients. Important in personal care and household products.
- **B Corp certification** assesses a whole company's social and environmental performance. It is a serious undertaking, best considered after your first year, not before launch.

**What to do instead at launch:** buy certified materials from suppliers who already hold the relevant certification, keep their documentation on file, and state exactly what is certified and by whom. You can truthfully say "made with FSC-certified paper" if your paper supplier holds that certification and you keep the invoice. You cannot claim the certification for your whole business unless you hold it yourself.

## 5.5 Packaging: the part customers judge first

Customers form an opinion about your business from the packaging before they try the product. Good green packaging follows three rules:

1. **Use less of it.** Every layer must earn its place. If the product is sturdy, a single mailer may be enough.
2. **Make it reusable or genuinely recyclable where your customers live.** A beautiful compostable mailer is useless if your customers have no composting service.
3. **Print honestly.** Put the disposal instructions on the pack, in plain language. Customers appreciate being told what to do with it — and it stops your compostable mailer ending up in landfill because nobody knew.

## 5.6 Your Module 5 actions

1. List every material and component your product or service needs.
2. Contact at least three suppliers and compare MOQ, lead time, price, and documentation.
3. Order samples of your top choice and test them as a customer would.
4. Write down every green claim you plan to make — and next to each one, the evidence you hold for it.
5. Complete the Supplier Research Sheet in the workbook and decide your launch supplier.

**Module 5 checkpoint:** you have a named supplier, a sample you have tested, a first order size you can afford, and evidence for every claim on your label or listing. If a claim has no evidence, remove it.

---

# Module 6 — Branding Without Greenwashing

Branding is not a logo. It is the promise a customer believes before they buy, and the experience that either confirms it or breaks it. For a green business, branding has a special danger: greenwashing — making a business look more environmentally friendly than it is. Customers are increasingly alert to it, and the damage from being caught is far worse than the benefit of a slightly greener-sounding claim.

## 6.1 What your brand really is

Your brand is made of four things: what you sell, how it works, how you talk about it, and how you treat people. The visual parts — name, colours, packaging — support those four things; they do not replace them. A beautiful logo on a mediocre product with slow replies to customers is not a brand. It is decoration.

Start with positioning: the one idea you want customers to remember. It should be short enough to say in a sentence and specific enough that a competitor could not say the same thing. "We deliver refills so busy parents can cut plastic without an extra trip" is positioning. "Eco-friendly products for a better planet" is not — any business could say it, and customers will forget it instantly.

## 6.2 Naming your business

A good name for a small green business is short, easy to spell after hearing it once, and free of confusion. Test any name you like by saying it out loud on a phone call, typing it into a search engine, and checking whether the web address and social media handles are available. Avoid names that are hard to pronounce, names that lock you into one product (if you later want to expand), and names that make a claim you cannot prove — "100% Plastic-Free Co." becomes a liability the day you use a plastic label.

Check for existing businesses with the same or a similar name in your country before you print anything. A quick search of your national business register and trademark database is worth an hour of your time and can save you a forced rename later.

## 6.3 The honest brand voice

Green brands often fall into one of two traps: sounding preachy ("you should care more") or sounding vague ("good for you, good for the planet"). Neither sells well. The voice that works is plain, warm, and specific:

- Say what the product does first, and the environmental benefit second.
- Use real numbers when you have them ("each set replaces about a year of cling film for a typical household" is stronger than "saves the planet").
- Admit what you are still working on. A brand that says "our mailers are compostable; we are still looking for a plastic-free tape that holds in wet weather" earns more trust than one that claims perfection.
- Write like you talk to a customer in person. If you would not say it to someone's face, do not put it on your website.

## 6.4 Greenwashing: what it is and how to avoid it

Greenwashing is any claim that makes a business look greener than it is. The common forms are easy to fall into accidentally:

- **Vague claims:** "eco-friendly," "natural," "green" — with no explanation of what makes it so.
- **Hidden trade-offs:** highlighting one green feature while hiding a bigger problem (a "recyclable" bottle that can only be recycled in a handful of facilities).
- **Irrelevant claims:** boasting about something that is legally required anyway, or that every competitor does.
- **False labels:** using words, colours, or symbols that suggest a certification you do not hold.
- **Cherry-picking:** advertising the one green product in a range while the rest of the business is unchanged.

The defence is simple: **claim only what you can prove, in words a customer can check.** If you say your packaging is compostable, name the standard and the conditions. If you say you plant a tree per order, name the organisation and how a customer can verify it. If you are not sure a claim is true, leave it out — the absence of a claim is never a problem, but a false one always is.

## 6.5 Visual identity on a small budget

You do not need an agency. You need consistency: the same name, the same two or three colours, the same readable typeface, and the same tone everywhere a customer meets you — your listing, your packaging, your social posts, and your emails. Choose colours you can reproduce cheaply (a dark green and a warm neutral print well and look honest; metallic gold can look premium on a cover but is expensive in print — use it sparingly and deliberately). Make sure your text is readable at a small size, because most customers will first see you on a phone screen.

If you use photos, use your own. Photos of your actual product, your actual hands packing an order, and your actual customers (with permission) will always outperform stock photos of forests and leaves. Stock imagery of nature is the visual equivalent of the word "eco-friendly" — everybody uses it, and it says nothing about you.

## 6.6 Your Module 6 actions

1. Write your positioning sentence (one sentence, specific, not copyable by any competitor).
2. Choose a name and check it against the business register, search engines, and social handles.
3. Write a short list of words your brand will use — and words it will never use (vague green adjectives belong on the never list).
4. Audit every claim you plan to make against the greenwashing checklist above.
5. Decide your colours, typeface, and photo style — and use them consistently from now on.

**Module 6 checkpoint:** a stranger can look at your listing or packaging for ten seconds and say what you sell, who it is for, and one specific reason to believe you. If they cannot, your branding is decoration, not communication.

---

# Module 7 — Sales Channels: Where Your Customers Already Are

A sales channel is a place where a customer can buy from you. New founders usually pick a channel because it is fashionable — an online shop, a market stall, social media — instead of picking it because their customers are there. This module matches channels to your niche, your product, and your budget.

## 7.1 The channel menu

**Your own online listing or shop.** A product page on a marketplace or your own small shop. Advantages: open all hours, customers can buy without talking to you, and you control the message. Disadvantages: you must bring the traffic yourself — a shop with no visitors sells nothing.

**Online marketplaces.** Large platforms where customers already search for products. Advantages: built-in traffic and trust. Disadvantages: fees on every sale, rules you do not control, and competition sitting one click away. Read the fee structure carefully: a 10% commission plus payment fees can erase a thin margin.

**Local markets and pop-ups.** Farmers markets, craft fairs, and community events. Advantages: you meet customers face to face, get instant feedback, and can sell at full price with no platform fee. Disadvantages: stall fees, weather, travel, and a full day of your time for one day of sales. Markets are excellent for validation and first customers, and exhausting as a permanent model.

**Local shops and stockists.** Independent shops, cafes, and zero-waste stores that stock your product. Advantages: someone else sells for you, and their customers trust their taste. Disadvantages: wholesale margins are thin (see Module 4), and you need to supply reliably and support the shop with display material.

**Direct service and word of mouth.** For service businesses, most early work comes from people who know you or were referred by someone who does. Advantages: no fees, high trust, and customers who already believe in you. Disadvantages: slow to scale, and you must actively ask for referrals — they rarely arrive on their own.

**Social media.** A place to be found and to build trust — not, for most new businesses, a place where sales happen by themselves. Treat social media as a shop window and a conversation, and send people to a place where they can actually buy. A beautiful feed with no working buy link is a hobby.

## 7.2 Choosing your first two channels

Start with two channels, not six. Choose them with three tests:

1. **Are my customers already there, buying things like mine?** If your customers buy cleaning products at the supermarket and the local market, a market stall and a local shop beat an online marketplace.
2. **Can I afford the true cost?** Count fees, stall costs, travel, time, and packaging — not just the headline fee.
3. **Can I serve it well every week?** A channel that needs daily posting, daily packing, or daily travel will fail if your life does not allow it. Pick channels that fit your real week.

A common strong pairing for a product business is one face-to-face channel (a market or local shops) plus one online channel (a marketplace listing or small shop). The face-to-face channel gives you feedback and first customers; the online channel gives you sales while you sleep and a link to share. For a service business, the pairing is usually direct outreach plus referrals, with social media as a supporting window.

## 7.3 The maths of a market stall

Markets feel profitable because you take cash home. Do the full maths before you commit to a regular stall:

- Stall fee for the day, plus travel and parking.
- The cost of the stock you sell that day (your true cost per unit, from Module 4).
- Your time: setting up, selling, packing down — valued at your hourly rate.
- Any samples or freebies you give away.

Example: a stall costs $60, you travel $15, and you sell 20 sets at $29. Revenue is $580. Your cost per set is $17.52 (from Module 4), so stock cost is $350.40. Stall plus travel is $75. That leaves $154.60 before valuing your time. If the day took 8 hours including travel and setup, and you value your time at $18 an hour ($144), your real profit for the day is about $10.60. That is not a failure — you also won 20 customers, gathered feedback, and handed out cards — but it shows why a market that looks like a good day can be a poor business if you do it every week without raising prices, selling bundles, or collecting repeat customers.

The fix is not to avoid markets. It is to use them for what they are good at: launching, testing, and winning subscribers and repeat buyers — and to measure each market honestly, so you keep the ones that pay and drop the ones that do not.

## 7.4 Listing pages that convert

Whether you sell on a marketplace or your own shop, your listing page does the selling when you are not there. A good listing has:

- **A clear title** that says what it is and who it is for, in plain words a customer would search for.
- **Photos that answer questions:** the product in use, the size (shown next to something familiar), the packaging, and what is included. At least four photos; one hero shot is not enough.
- **A first paragraph that names the problem and the outcome** — not your life story. The story belongs further down the page, after the customer knows what they are buying.
- **Specifics, not adjectives:** materials, size, weight, care instructions, what is included, delivery time, and returns policy. Every unanswered question is a reason not to buy.
- **Proof you can offer honestly:** how many you have sold (once you have sold some), a real customer comment (with permission), or a clear statement of your materials and their source. Never invent reviews, sales figures, or testimonials.
- **A simple next step:** one buy button, one price, no confusion.

## 7.5 Your Module 7 actions

1. List every channel you could use, and score each one on the three tests in section 7.2.
2. Choose your first two channels and write down why the others wait.
3. Work out the full maths of one market day or one month of marketplace fees for your business.
4. Draft your listing page using the structure in section 7.4.
5. Set a date for your first appearance on each chosen channel.

**Module 7 checkpoint:** you can name your two launch channels, what each one costs you per month or per day, and what a good result looks like on each. If you cannot, you are choosing channels by fashion, not by fit.

---

# Module 8 — Your 90-Day Launch Plan

This is the module the whole program has been building toward. A launch is not a single day. It is 90 days of planned work, with the actual selling starting well before launch day and continuing well after it. Follow the plan in order; do not skip the preparation weeks to get to the exciting part faster.

## 8.1 The shape of the 90 days

- **Days 1–21 — Validate and choose.** Modules 1–3. Interviews, niche selection, business model. No spending on stock yet. End of this phase: a niche, a model, and evidence that real people will pay.
- **Days 22–42 — Build the offer.** Modules 4–6. Pricing, supplier samples, branding, listing draft. End of this phase: a priced offer, a tested sample, and a listing page ready to publish.
- **Days 43–63 — Prepare to sell.** Module 7 plus the launch build: order your first small batch of stock (or prepare your service), set up your two channels, prepare packaging, and line up your first customers. End of this phase: everything a customer needs to buy exists and works.
- **Days 64–90 — Launch and learn.** Open for sales, serve your first customers, gather feedback, fix what breaks, and decide what happens next. End of this phase: real sales data, real customer feedback, and a clear decision about the next 90 days.

The 90-day plan template in the templates folder breaks this into weekly tasks with space to record what actually happened. Plans change — that is normal. The template is there so that when they do, you can see what changed and why, instead of guessing later.

## 8.2 Week by week

**Weeks 1–3: Prove the problem.** Complete Modules 1–3. Talk to people. Score niches. Choose a model. Write it all down. If the evidence is weak at the end of week 3, change the idea — you have spent time, not money, and that is the cheapest possible lesson.

**Weeks 4–6: Build the offer.** Price your product or service from real costs (Module 4). Contact suppliers, order samples, test them (Module 5). Name the business, write the positioning, audit your claims (Module 6). Draft the listing page. By the end of week 6 you should be able to show a stranger your offer and have them understand it in ten seconds.

**Weeks 7–9: Prepare to sell.** Place your first small stock order, or prepare your service kit and booking system. Set up your two channels. Prepare packaging and any printed material. Tell your early audience — the people you interviewed — that launch is coming, and offer them the founding-customer price. Build a simple launch list: the names of people who have said they want to hear when you open. Even 20 names is a good start; 20 people who asked to be told beat 2,000 followers who never asked for anything.

**Weeks 10–11: Soft launch.** Open quietly to your launch list first. Serve them well. Ask every customer two questions: what worked, and what would you change? Fix the biggest problem before you tell the wider world. A soft launch is not a failed launch — it is a launch with a safety net.

**Weeks 12–13: Public launch.** Now tell everyone: your social channels, your local groups, your market stall, your stockists. Share the story of the first customers (with permission) and what you learned. Run one simple promotion — a launch bundle, a founding price ending on a date, or a free sample with a first order — and give it a clear end date so people have a reason to act now.

## 8.3 The launch budget

A realistic 90-day launch budget for a small product business is worked out in full in Appendix A. The shape of it matters more than the exact numbers: roughly a third on stock and packaging, a third on reaching customers (stall fees, a small amount of advertising, printed material), and a third held back for fees, mistakes, and the second order. The single most common budgeting mistake is spending everything on stock and having nothing left to tell anyone the product exists.

For a service business, the budget is smaller and mostly time: insurance, basic supplies, a booking or payment method, and a small amount for local promotion. The principle is the same — keep a reserve. A service business with no reserve cannot survive a quiet month or a cancelled booking.

## 8.4 What can go wrong — and what to do

- **Stock arrives late.** Build two weeks of slack into the plan and tell customers honestly if a date moves. People forgive a delay they are told about; they do not forgive silence.
- **Nobody buys on launch day.** This is normal. Most sales come from repeated contact, not a single announcement. Follow up with your launch list, ask what stopped them, and fix the most common answer.
- **You sell out.** A good problem, but still a problem: have your supplier's lead time written down and tell customers when the next batch arrives. Take pre-orders if you can fulfil them reliably.
- **A customer is unhappy.** Respond fast, apologise plainly, fix it or refund it, and learn from it. One well-handled complaint creates more loyalty than ten smooth sales.
- **You run out of energy.** Launching is tiring. Build rest into the plan — one day a week with no business work — and remember that a sustainable business cannot be built by an exhausted founder.

## 8.5 Your Module 8 actions

1. Copy the 90-day plan template and fill in your dates, starting from your chosen launch date and working backwards.
2. Write your launch budget using Appendix A as a guide, with your own real quotes.
3. Build your launch list: every person who asked to hear when you open.
4. Decide your soft launch date and your public launch date — two different dates.
5. Choose one launch promotion and its end date.

**Module 8 checkpoint:** you have a dated plan, a budget with a reserve, a launch list with real names, and a soft launch date. If any of those is missing, the launch is a wish, not a plan.

---

# Module 9 — Getting Your First 10 Customers

Your first ten customers matter more than your next hundred. They will teach you what works, tell their friends if you serve them well, and give you the feedback that shapes the business. This module is about winning them deliberately, not hoping they appear.

## 9.1 Start with people who already know you

Your first customers are almost never strangers. They are the people you interviewed in Module 1, friends of those people, members of the groups where you listened, and local contacts who watched you build the offer. Go back to them first — personally, by name, with a specific offer and a specific date. A personal message ("We open on Saturday — I would love you to be one of our first customers, and the founding price is $X until Sunday") works far better than a general post to hundreds of people.

Do not be embarrassed about asking. You are not begging. You are offering something you built for them, at a price they helped you set, and you are asking them to be first. Most people like being first.

## 9.2 The founding-customer offer

Your founding offer should be simple, time-limited, and genuinely good — but not so cheap that it becomes your permanent price. Good founding offers include:

- A lower price for the first 20 customers, ending on a stated date.
- A bundle at the single-item price (buy the set, get the extra item included) for launch week only.
- A free sample or small extra with a first order.
- A lifetime small discount for subscribers who join in the first month.

Whatever you choose, write the terms down: who qualifies, when it ends, and what happens after. Confusion about an offer creates complaints that cost more than the discount saved.

## 9.3 Where to find customers beyond your circle

Once your warm circle is served, expand in this order — cheapest and most trusted first:

1. **Referrals.** Ask every happy customer: "Do you know one person who might like this?" Offer a small thank-you — a discount on their next order, or a free sample — for introductions that lead to a sale. One referral is worth more than a hundred ad impressions.
2. **Local presence.** Markets, community events, local shops, notice boards, and community groups. For a local business, being physically present where customers already gather is still the most reliable marketing there is.
3. **Content that helps.** Short, useful posts that solve a small problem for your niche — how to store wraps so they last, how to cut plastic in a lunchbox, how to read a cleaning product label. Helpful content builds trust slowly and steadily; constant selling builds resistance.
4. **Small, measured advertising.** Only after you know your price, your margin, and your customer acquisition cost from real sales. Start with a small test budget ($50–$100), one audience, one message, and a clear way to measure whether it produced sales. If it does not produce sales at a cost you can afford, stop it — do not increase the budget and hope.

## 9.4 The first sale conversation

Whether you sell in person, by message, or through a listing page, the conversation follows the same shape:

1. **Name the problem** in the customer's words. ("You mentioned the plastic from detergent bottles bothers you.")
2. **Show the outcome** — what changes when they use your product or service. ("Refills delivered, bottles collected, nothing to throw away.")
3. **Answer the real objection.** The objection is rarely the price. It is usually "Will it work?", "Will it arrive?", or "What if I don't like it?" Answer with specifics: how it works, when it arrives, and what happens if they are unhappy.
4. **Make the next step easy.** One price, one button, one date. Never make a customer work out how to buy from you.

If someone says no, thank them and ask — gently — what would have to change for it to be a yes. That answer is market research you could not buy.

## 9.5 Serving the first ten brilliantly

Your first ten customers deserve more attention than any later group, because their experience becomes your reputation. Pack orders carefully. Include a short handwritten note. Follow up a few days after delivery: did it arrive well, did it work as expected, is anything unclear? Fix problems fast and without argument. Then — only if they are happy — ask for a short review or a few words you can share, and ask who else they think might like it.

Keep a simple record for each of your first ten customers: what they bought, what they said, what you learned. Patterns in those ten records will tell you more about your business than any analytics dashboard.

## 9.6 Your Module 9 actions

1. Write the names of the 20 people most likely to be your first customers.
2. Write your founding-customer offer, with its terms and end date.
3. Send personal messages to your top ten — not a group post — and record the replies.
4. Decide your referral thank-you and write it down.
5. After each of your first ten sales, record what the customer said and what you learned.

**Module 9 checkpoint:** you have ten named people, a founding offer with an end date, and a plan for what happens after each of the first ten sales. If you have fewer than ten names, go back to Module 1 and talk to more people before launch.

---

# Module 10 — From Launch to a Business That Lasts

Launching is a sprint. Running a business is a long walk. This final module is about what happens after the excitement of launch week fades: the systems, habits, and decisions that turn a launch into a business that can last — and the honest signs that tell you when to change direction.

## 10.1 The weekly rhythm

A business without a rhythm drifts. Set a simple weekly pattern and keep it:

- **One day for making or delivering.** Production, packing, service visits.
- **One block for customers.** Replying to messages, following up, asking for feedback, handling problems.
- **One block for reaching new customers.** One market, one post, one outreach — not all three every day.
- **One block for the numbers.** Record sales, costs, and cash every week, while it is fresh. A business that does not know its numbers is guessing.
- **One day off.** Non-negotiable. A founder who never rests makes worse decisions, treats customers worse, and quits sooner.

The exact days do not matter. The rhythm does. Write yours down and protect it.

## 10.2 Know your numbers: the five-minute weekly check

Every week, write down five numbers:

1. **Sales this week** — total money taken, and how many customers that was.
2. **Costs this week** — stock, fees, travel, and anything else you spent.
3. **Cash in the bank** — what you actually have, not what you expect to have.
4. **New customers** — how many, and where they came from.
5. **Repeat customers** — how many came back, and what they bought.

Five minutes, five numbers, every week. After a month you will see patterns: which channel works, which product sells, which week is quiet. After three months you will be making decisions from evidence instead of feelings. This is the single most valuable habit in this whole program.

## 10.3 When to grow, and how

Growth is not always the right move. Grow when three things are true at once: you have steady demand you cannot meet, your margins are healthy, and you have systems that work without you doing everything by hand. If any one of those is missing, fix it first.

Growth options, in order of risk:

- **Sell more to existing customers.** A new product that fits the same niche, a subscription for existing buyers, a bundle. Cheapest growth there is, because you already have the customer.
- **Reach more of the same niche.** A second market, a second local shop, a neighbouring town. Same offer, wider reach.
- **Add a related offer.** A service business adds a product; a product business adds a service or a workshop. Related, not random.
- **Hire help.** Start with a few hours a week for the task you dislike most or do slowest — packing, bookkeeping, deliveries. Hire for a specific job, with clear instructions, and pay fairly and on time.
- **Expand the range or the geography.** The highest-risk option. Only after the first four are working.

## 10.4 When to change direction

Not every business works, and changing direction is not failure — it is the skill this whole program teaches. Consider a real change if, after an honest 90 days of following the plan:

- You have had real conversations and real offers, but almost nobody pays — the problem may not be painful enough, or the price may be wrong, or the niche may be wrong.
- Your costs are consistently higher than your price allows, and no cost saving or price rise fixes it — the model may not work at your scale.
- You dread the work itself, week after week — a business you hate will not survive your own reluctance.

When that happens, do not abandon everything. Keep the customers, the knowledge, and the relationships, and change one thing: the niche, the offer, or the model. The validation ladder from Module 1 works just as well the second time, and faster, because you already know how to use it.

## 10.5 Staying green as you grow

Growth creates new temptations: cheaper materials that are less sustainable, packaging that is easier but more wasteful, suppliers you have not checked. Protect your standards with three habits:

- **Re-check suppliers once a year.** Ask for current documentation. If a supplier's standards have slipped, find out before your customers do.
- **Review every claim on your listing once a year.** Remove anything you can no longer prove, and update anything that has changed.
- **Measure one environmental number.** It could be the weight of plastic avoided, the number of refills delivered, or the share of packaging that is compostable. One real number, measured honestly, is worth more than a page of adjectives. Report it plainly, including the limits of what you measured.

## 10.6 Your next 90 days

At the end of this program, sit down with your workbook and your weekly numbers, and write your next 90-day plan. It will be shorter than this one, because you now know what your customers want, what your costs are, and what your week can hold. Set three goals only: one for customers, one for money, and one for the business itself (a new product, a better system, a certification). Review them every month. Adjust them when the evidence changes. Keep going.

You started this program with a green idea and no map. You now have a validated niche, a priced offer, a supplier you can trust, a brand you can stand behind, two channels, a launch plan, and ten customers who chose you first. That is a business — small, real, and yours to grow.

## 10.7 Your Module 10 actions

1. Set your weekly rhythm and your five-number weekly check.
2. Write your three goals for the next 90 days — customers, money, business.
3. Schedule your annual supplier and claims review.
4. Choose the one environmental number you will measure and report.
5. Decide your next step, and put a date on it.

**Module 10 checkpoint:** you have a weekly rhythm, a numbers habit, three goals for the next 90 days, and a date for your next review. The program is finished. The business is not — and that is the point.

---

# Appendix A — Worked Example: The 90-Day Launch Budget

This is a realistic launch budget for a small eco-product business (the beeswax wrap sets from Module 4), selling online and at one local market a month. It assumes the founder already owns a phone and a laptop. All figures are planning illustrations, not promises — replace them with your own quotes.

| Item | Estimated cost |
|---|---|
| First stock order (100 sets at $8.10 materials + packaging each, before labour) | $810 |
| Samples and supplier testing | $60 |
| Packaging extras (mailers, tape, thank-you cards) | $90 |
| Market stall fees (3 markets at $60) | $180 |
| Travel and parking for markets | $45 |
| Marketplace / payment fees on early sales (estimate) | $80 |
| Small advertising test ($50, one campaign, measured) | $50 |
| Insurance (basic product liability, 3 months) | $120 |
| Business registration and licences (varies by location) | $100 |
| Contingency reserve (for the order that goes wrong) | $265 |
| **Total 90-day launch budget** | **$1,800** |

Notes: labour (your time) is not in this table because it is not a cash cost — but track it, because it is the difference between a business and an expensive hobby. If $1,800 is more than you can afford, shrink the launch: order 50 sets instead of 100, do two markets instead of three, and keep the reserve — never cut the reserve to zero. A smaller launch that you can afford beats a bigger launch that leaves you with no money to fix the first problem.

For a green service business, the equivalent budget is typically much smaller — often $300–$600 for insurance, basic supplies, a payment method, and local promotion — because there is no stock to buy. The principle is identical: spend on proving demand before spending on scale.

---

# Appendix B — Worked Example: First-Month Revenue, Three Scenarios

These scenarios show what the first month after launch might look like for the same beeswax wrap business, selling sets at $29. They are illustrations to help you plan — not predictions. Real results vary widely, and many new businesses earn less than the low scenario in month one.

**Low scenario — slow start.** 15 sets sold (10 online, 5 at one market). Revenue: $435. Cost of goods and fees: about $263. Gross profit before your time: about $172. This is a normal slow start. The value is in the learning: which channel sold, what customers asked, what to fix.

**Middle scenario — steady start.** 35 sets sold (20 online, 15 at markets). Revenue: $1,015. Cost of goods and fees: about $613. Gross profit before your time: about $402. This is a good first month for a small launch, and it suggests the offer works well enough to keep going and to test a small subscription or bundle.

**Strong scenario — good start.** 60 sets sold (35 online, 25 at markets, including a small wholesale order to one local shop at $17 per set). Revenue: about $1,660. Cost of goods and fees: about $1,050. Gross profit before your time: about $610. This is a strong first month, and it would usually mean word of mouth or a good market day helped. Even here, the founder is not yet paying themselves a full wage — and that is normal in month one.

The honest lesson from all three scenarios: a small product business rarely replaces an income in its first month. It proves the model, builds the customer base, and grows from there. Budget your personal finances accordingly, and do not borrow money against the strong scenario.

---

# Appendix C — Glossary and Further Reading

**Business model canvas** — a one-page map of how a business works: customers, offer, channels, costs, and revenue.

**CAC (customer acquisition cost)** — what it costs, on average, to win one paying customer.

**Gross margin** — the money left from a sale after the direct cost of what was sold.

**LTV (lifetime value)** — what a customer is worth over the whole time they buy from you.

**MOQ (minimum order quantity)** — the smallest order a supplier will accept.

**Greenwashing** — making a business or product look more environmentally friendly than it is.

**Further reading (general, not endorsements):** your national small-business agency's startup guides; your local consumer-protection authority's guidance on environmental claims; the documentation pages of any certification scheme you consider; and the supplier documentation you collect in Module 5. Check that any source you rely on is current for your country before acting on it.

---

*End of Green Business Launchpad (GRN-03). Remember: this is business education, not a guarantee of income. Results vary. Do your own research, check local rules before selling, and get professional advice before making financial or legal decisions.*
