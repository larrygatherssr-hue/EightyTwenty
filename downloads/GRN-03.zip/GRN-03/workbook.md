# Green Business Launchpad — Companion Workbook

**GRN-03 — Green Living & Sustainability**

> **Disclaimer:** This workbook is business education, not a guarantee of income. Results vary widely. The exercises help you plan; they do not predict your results. Check local laws and regulations before selling anything, and consult a qualified professional before making financial or legal decisions.

## How to Use This Workbook

Work through the worksheets in order, alongside the matching module in `content.md`. Write in this file, print it, or copy each worksheet into your own notebook — whichever you will actually use. An exercise done roughly beats an exercise left blank.

---

## Worksheet 1 — Idea Validation (Module 1)

**Your three ideas:**

| # | Idea (one line) | Who has this problem? | What do they do about it today? | Will they pay? (evidence, not hope) |
|---|---|---|---|---|
| 1 | | | | |
| 2 | | | | |
| 3 | | | | |

**20 complaints you collected (where you heard each one):**

1.
2.
3.
4.
5.
6.
7.
8.
9.
10.
11.
12.
13.
14.
15.
16.
17.
18.
19.
20.

**Interview notes (10 people — name or initials, problem in their words, what they spend now):**

| Person | Problem (their words) | Current solution | Monthly spend | Would they pay for better? |
|---|---|---|---|---|
| 1 | | | | |
| 2 | | | | |
| 3 | | | | |
| 4 | | | | |
| 5 | | | | |
| 6 | | | | |
| 7 | | | | |
| 8 | | | | |
| 9 | | | | |
| 10 | | | | |

**Validation ladder — record your results:**

- Rung 1 (conversations): date completed ___ / repeated problem found? ___
- Rung 2 (offer page): link ___ / sign-ups or enquiries ___
- Rung 3 (paid test): price offered $___ / paying customers ___
- Rung 4 (pilot): customers served ___ / what they would change ___

**Decision:** My validated idea is: ___

---

## Worksheet 2 — Niche Selector (Module 2)

Score each candidate niche from 1 (weak) to 5 (strong) on each test.

| Test | Niche A: ___ | Niche B: ___ | Niche C: ___ |
|---|---|---|---|
| Reachable — I can find and contact these people affordably | | | |
| Paying — they already spend money on this problem | | | |
| Underserved — the current solution is genuinely bad for them | | | |
| I can serve it — skills, suppliers, time, and budget fit my life | | | |
| **Total (out of 20)** | | | |

**Competition check for the winning niche:**

| Competitor | What they sell | Price | What customers complain about |
|---|---|---|---|
| 1 | | | |
| 2 | | | |
| 3 | | | |

**Where my niche gathers (name three specific places):** 1. ___ 2. ___ 3. ___

**My niche statement:** "I help ___ solve ___ with ___, so they can ___."

**What I am deliberately NOT doing:** ___

---

## Worksheet 3 — Business Model Canvas (Module 3)

Fill in one page for your chosen model.

| Canvas block | Your answer |
|---|---|
| Customers — who exactly? | |
| Problem — what pain do they pay to solve? | |
| Offer — what do they get? | |
| Channels — where do they buy? | |
| Relationships — how do you stay in touch? | |
| Revenue — who pays, how much, how often? | |
| Key activities — what must happen every week? | |
| Key resources — suppliers, skills, tools? | |
| Key partners — who helps you? | |
| Costs — what does it cost to run each month? | |

**Model maths (rough estimates, to be replaced with real numbers):**

- Price per sale: $___
- Direct cost per sale: $___
- Gross margin per sale: $___ (___%)
- Cost to win one customer (CAC): $___
- Value of a customer over a year (LTV): $___
- LTV divided by CAC: ___ (aim for 3 or higher)

**Main model:** ___ **Supporting model:** ___

---

## Worksheet 4 — Pricing Worksheet (Module 4)

**True cost build-up (per unit, or per job for a service):**

| Cost item | Amount |
|---|---|
| Materials / ingredients | $ |
| Packaging and labels | $ |
| Postage / delivery / travel | $ |
| Payment processing fees | $ |
| Your time (hours × hourly rate $___) | $ |
| Share of overhead (phone, storage, insurance, accounting) | $ |
| **Total true cost** | **$** |

**Price test:**

- Cost-plus floor price (cost + margin): $___
- What customers currently spend on the problem: $___
- My launch price: $___
- My margin at launch price: $___ (___%)
- Bundle / subscription price: $___
- Price I will never go below: $___
- Why: ___

**Levers if the margin is too thin (tick what you will try):**

- [ ] Reduce a cost (which one? ___)
- [ ] Batch production to cut time per unit
- [ ] Raise the price and sell the value more clearly
- [ ] Change the offer (bundle, set, or tier)

---

## Worksheet 5 — 90-Day Launch Plan (Module 8)

Start from your launch date and work backwards. Fill in real dates.

| Week | Dates | Focus | Key tasks | Done? |
|---|---|---|---|---|
| 1 | | Prove the problem | Interviews, complaint list | |
| 2 | | Prove the problem | Niche scoring, model choice | |
| 3 | | Prove the problem | Paid test, decide the idea | |
| 4 | | Build the offer | Pricing from real costs | |
| 5 | | Build the offer | Supplier samples ordered | |
| 6 | | Build the offer | Branding, listing draft | |
| 7 | | Prepare to sell | First stock order / service kit | |
| 8 | | Prepare to sell | Channels set up, packaging ready | |
| 9 | | Prepare to sell | Launch list built, founding offer set | |
| 10 | | Soft launch | Serve launch list, collect feedback | |
| 11 | | Soft launch | Fix the biggest problem found | |
| 12 | | Public launch | Announce everywhere | |
| 13 | | Public launch | Launch promotion ends, review numbers | |

**My launch budget (total $___):** stock $___ / reaching customers $___ / fees $___ / reserve $___

**Soft launch date:** ___ **Public launch date:** ___

**Launch promotion:** ___ **Ends on:** ___

---

## Worksheet 6 — Supplier Research Sheet (Module 5)

| Supplier | Product / material | MOQ | Lead time | Unit price | Payment terms | Documentation provided? | Sample tested? (Y/N + notes) |
|---|---|---|---|---|---|---|---|
| 1 | | | | | | | |
| 2 | | | | | | | |
| 3 | | | | | | | |

**My launch supplier:** ___ **Why:** ___

**Every green claim I plan to make — and the evidence I hold for it:**

| Claim (exact words) | Evidence (document, supplier, standard) |
|---|---|
| | |
| | |
| | |

**Claims I removed because I could not prove them:** ___

---

## Worksheet 7 — Launch Checklist

**Before soft launch:**

- [ ] Niche chosen and written in one sentence
- [ ] Business model canvas completed
- [ ] Launch price built from real costs
- [ ] Supplier chosen, sample tested, first order placed
- [ ] Every green claim has evidence on file
- [ ] Listing page drafted with at least four photos
- [ ] Two sales channels set up and tested (can a customer actually buy?)
- [ ] Packaging ready, disposal instructions included
- [ ] Founding-customer offer written with terms and end date
- [ ] Launch list has at least 20 names

**Before public launch:**

- [ ] Soft-launch customers served and feedback collected
- [ ] Biggest problem found in soft launch fixed
- [ ] First ten customer records started
- [ ] Referral thank-you decided
- [ ] Weekly numbers sheet set up (sales, costs, cash, new and repeat customers)

**After launch (first month):**

- [ ] Weekly five-number check completed every week
- [ ] First ten customers followed up with
- [ ] Reviews or feedback requested (only from happy customers, with permission)
- [ ] Next 90-day goals written: customers ___, money ___, business ___

---

*End of workbook. Keep this file with your course materials and update it as your real numbers replace your estimates.*
