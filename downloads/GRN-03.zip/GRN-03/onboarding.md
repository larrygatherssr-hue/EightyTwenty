# Customer Onboarding Guide — Green Business Launchpad (GRN-03)

Welcome, and thank you for choosing Green Business Launchpad. This guide tells you what to do first, how to use your materials, and how to get support.

## What You Have Received

Your purchase includes these files:

- **content.md** — the full 10-module course, written in full.
- **workbook.md** — the companion workbook with 7 worksheets and a launch checklist.
- **templates/pricing-calculator.csv** — build your price from true costs.
- **templates/business-model-canvas.md** — your business on one page.
- **templates/90-day-launch-plan.md** — your week-by-week plan with dates.
- **templates/pitch-deck-outline.md** — a 10-slide outline for stockists and partners.
- **templates/supplier-directory.md** — supplier types, certification schemes, and your own records.
- **sales-page.md** — the full sales page for your reference.
- **cover.png** — the product cover image.
- **cover.md** — the cover design brief.

## What to Do First

1. **Save your files somewhere safe** and make a backup. These are your working copies — you will write in the workbook and templates as you go.
2. **Read the disclaimer at the top of content.md.** This program is business education, not a guarantee of income. The numbers in it are worked examples, not promises.
3. **Pick your start date** and write it in the 90-day launch plan template. Count 90 days forward and write down your public launch date.
4. **Read Module 1 and complete Worksheet 1** (Idea Validation) before moving on. Do not skip ahead to pricing or suppliers — the early modules are what make the later ones work.

## How to Use the Materials

- **Work in order the first time.** Each module builds on the one before it.
- **Do the workbook exercise for each module as you finish it.** The learning turns into decisions in the workbook.
- **Use the templates as working documents.** Fill in the pricing calculator with your real costs, the canvas with your real model, and the launch plan with your real dates.
- **Keep everything in one place.** Your workbook, templates, supplier notes, and weekly numbers together are your business record — keep them updated as real numbers replace your estimates.

## Suggested Schedule

- **About 60–90 minutes a day, five days a week, for 90 days.**
  - Days 1–21: Modules 1–3 (validate, choose a niche, pick a model)
  - Days 22–42: Modules 4–6 (pricing, suppliers, branding)
  - Days 43–63: Module 7 and launch preparation
  - Days 64–90: Modules 8–10 (launch, first customers, what lasts)
- **If you can only give 30 minutes a day,** stretch the plan to 120 days. The sequence matters more than the speed.
- **Take one full day off each week.** A sustainable business cannot be built by an exhausted founder.

## How to Get Support

- **File access or download problems:** contact support through the EightyTwenty marketplace help channel listed at checkout, quoting SKU GRN-03 and your order number.
- **Questions about how to use the materials:** include a short description of where you are stuck (which module and worksheet) so support can point you to the right section.
- **Refunds:** a 14-day money-back guarantee applies. Contact marketplace support within 14 days of purchase if you have worked through Module 1 and decided the program is not for you.
- **What support cannot do:** provide legal, tax, or financial advice, or make business decisions for you. For those, consult a qualified professional in your country.

## A Final Note

You do not need to be perfect to start. You need a real problem, a real group of people who have it, and a plan you follow one week at a time. Do the interviews. Fill in the worksheets. Launch small, learn fast, and keep going.

Good luck — and welcome to the launch.
