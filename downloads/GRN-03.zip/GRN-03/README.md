# GRN-03 — Green Business Launchpad: Start a Profitable Eco Business in 90 Days

**Category:** Green Living & Sustainability

**Price:** $297 (one-time)

**Headline:** From green idea to paying customers in 90 days — validate, price, and launch.

## Files in This Folder

| File | What it is |
|---|---|
| `content.md` | Full 10-module course (written, self-paced), with worked examples and appendices |
| `workbook.md` | Companion workbook: 7 worksheets plus a launch checklist |
| `templates/pricing-calculator.csv` | Pricing calculator — build your price from true costs |
| `templates/business-model-canvas.md` | Business model canvas template |
| `templates/90-day-launch-plan.md` | Week-by-week 90-day launch plan template |
| `templates/pitch-deck-outline.md` | 10-slide pitch deck outline for stockists and partners |
| `templates/supplier-directory.md` | Supplier and certification directory template |
| `sales-page.md` | Full sales page (headline, problem, solution, module list, FAQs, disclaimer) |
| `listing.json` | Marketplace listing data (SKU, price, keywords, refund and support info) |
| `cover.png` | Cover image (premium black-and-gold) |
| `cover.md` | Cover design brief |
| `onboarding.md` | Customer onboarding guide |
| `README.md` | This index |

## Target Customer

Aspiring founders who want to start an environmentally focused business (eco products, green services, or sustainable consulting).

## Note

All content is original. No testimonials, sales figures, certifications, or reviews are fabricated. Worked numbers are realistic planning illustrations, and the disclaimer in content.md, workbook.md, and sales-page.md states that results vary and this is business education, not a guarantee of income.
