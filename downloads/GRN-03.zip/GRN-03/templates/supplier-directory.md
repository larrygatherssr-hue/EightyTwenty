# Supplier and Certification Directory — Green Business Launchpad (GRN-03)

A starter directory to research and record suppliers and certification schemes. Verify every entry yourself before relying on it — suppliers, prices, and scheme requirements change, and this list is a starting point for your own research, not a recommendation.

## How to Use This Directory

1. Copy a row into your Supplier Research Sheet (workbook, Worksheet 6) for each supplier you contact.
2. Ask every supplier for samples and documentation before ordering in bulk.
3. Keep invoices and certificates on file — they are the evidence behind your green claims.

## Supplier Types to Research

| Type | What to look for | Questions to ask |
|---|---|---|
| Local wholesalers and makers | Short shipping, visitable, small minimum orders | Minimum order? Lead time? Can I visit? |
| Specialist eco-material suppliers (online) | Organic textiles, compostable packaging, refill ingredients | Specifications? Certifications held? Sample cost? |
| Direct producers | Best prices, most authentic story | Minimum order? Payment terms? What if a delivery is wrong? |
| Packaging suppliers | Mailers, boxes, labels, tape | Recycled content %? Compostable standard? Local recyclability? |
| Printers (labels, care cards) | Small runs, recycled paper options | Paper certification (e.g. FSC)? Minimum run? |

## Certification Schemes to Know About

_Check current requirements and fees in your country before applying. Schemes change._

| Scheme / label | What it verifies | Most relevant for |
|---|---|---|
| Organic certification | How ingredients or fibres were grown and processed | Food, textiles, cosmetics |
| Fairtrade and similar ethical labels | Labour and trading conditions for producers | Food, textiles |
| FSC (forestry) | Paper and wood from responsibly managed forests | Packaging, printed materials |
| Compostability marks | Material breaks down under specified composting conditions | Packaging, disposable products |
| Cruelty-free / vegan labels | Not tested on animals; no animal-derived ingredients | Personal care, household products |
| B Corp certification | Whole-company social and environmental performance | Established businesses (consider after year one) |

## My Suppliers

| Supplier name | Contact | Product / material | MOQ | Lead time | Unit price | Certifications / documentation | Notes |
|---|---|---|---|---|---|---|---|
| | | | | | | | |
| | | | | | | | |
| | | | | | | | |

## My Claims and Evidence

| Claim (exact words I use) | Evidence held (document, supplier, standard) |
|---|---|
| | |
| | |
| | |

**Reminder:** Claim only what you can prove, in words a customer can check. If you cannot prove it, leave it out.
