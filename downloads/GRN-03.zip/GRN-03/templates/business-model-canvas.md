# Business Model Canvas — Green Business Launchpad (GRN-03)

Fill in one page for your business. Keep every box to two or three sentences — if you cannot explain it briefly, you do not understand it yet.

## Customers — Who exactly?

_Who is your specific customer group? Name them, not a vague category._

## Problem — What pain do they pay to solve?

_What problem do they already spend money on, and what frustrates them about the current solution?_

## Offer — What do they get?

_What product or service do you sell, and what changes for the customer when they use it?_

## Channels — Where do they buy?

_Your two launch channels, and how customers find you on each one._

## Relationships — How do you stay in touch?

_How do you follow up, ask for feedback, and earn repeat business?_

## Revenue — Who pays, how much, how often?

_Price, bundle or subscription, and how often the customer pays._

## Key Activities — What must happen every week?

_The work that has to happen for the business to run: making, packing, delivering, serving, marketing._

## Key Resources — Suppliers, skills, tools?

_What you need to deliver: your launch supplier, your skills, your equipment._

## Key Partners — Who helps you?

_Suppliers, local shops, markets, collaborators, advisors._

## Costs — What does it cost to run each month?

_Fixed costs (insurance, phone, storage) and variable costs (stock, packaging, fees, travel)._

---

## Model Maths

- Price per sale: $___
- Direct cost per sale: $___
- Gross margin per sale: $___ (___%)
- Cost to win one customer (CAC): $___
- Value of a customer over a year (LTV): $___
- LTV divided by CAC: ___ (aim for 3 or higher)

**Main model:** ___

**Supporting model:** ___
