# 90-Day Launch Plan — Green Business Launchpad (GRN-03)

**Launch date (public):** ___

**Soft launch date:** ___

Work backwards from your public launch date. Fill in real dates and check off each week as you complete it.

## Phase 1 — Validate and Choose (Days 1–21)

### Week 1 — Prove the problem
- [ ] List three business ideas
- [ ] Collect 20 real complaints from groups or conversations
- [ ] Interview 3 people

### Week 2 — Prove the problem
- [ ] Interview 7 more people (10 total)
- [ ] Answer the three validation questions for each idea
- [ ] Build a simple offer page for the strongest idea

### Week 3 — Prove the problem
- [ ] Run a paid test (pre-order, deposit, or founding-customer price)
- [ ] Score three niches on the four niche tests
- [ ] Choose your niche and write your one-sentence niche statement
- [ ] Choose your business model and complete the canvas

**Phase 1 checkpoint:** one niche, one model, and evidence that real people will pay.

## Phase 2 — Build the Offer (Days 22–42)

### Week 4 — Pricing and suppliers
- [ ] Build your price from true costs in the pricing calculator
- [ ] Contact three suppliers and compare MOQ, lead time, and price

### Week 5 — Suppliers and samples
- [ ] Order samples from your top supplier
- [ ] Test samples as a customer would
- [ ] List every green claim you plan to make, with the evidence for each

### Week 6 — Branding and listing
- [ ] Choose a name and check it (business register, search, social handles)
- [ ] Write your positioning sentence
- [ ] Audit every claim against the greenwashing checklist
- [ ] Draft your listing page (title, photos, problem, specifics, price)

**Phase 2 checkpoint:** a priced offer, a tested sample, and a listing page ready to publish.

## Phase 3 — Prepare to Sell (Days 43–63)

### Week 7 — Stock and channels
- [ ] Place your first small stock order (or prepare your service kit)
- [ ] Set up your two sales channels and test that a customer can buy

### Week 8 — Packaging and promotion
- [ ] Prepare packaging with disposal instructions
- [ ] Prepare any printed material (care cards, thank-you notes)

### Week 9 — Launch list
- [ ] Build your launch list (aim for at least 20 names)
- [ ] Tell them the launch date and the founding-customer offer
- [ ] Confirm your soft launch date

**Phase 3 checkpoint:** everything a customer needs to buy exists and works.

## Phase 4 — Launch and Learn (Days 64–90)

### Week 10 — Soft launch
- [ ] Open to your launch list first
- [ ] Serve every customer well and record feedback
- [ ] Ask each customer: what worked, and what would you change?

### Week 11 — Fix and improve
- [ ] Fix the biggest problem found in soft launch
- [ ] Update the listing, packaging, or offer based on feedback

### Week 12 — Public launch
- [ ] Announce on all channels
- [ ] Start your launch promotion (with a clear end date)

### Week 13 — Review
- [ ] Launch promotion ends
- [ ] Review your weekly numbers: sales, costs, cash, new and repeat customers
- [ ] Write your next 90-day goals (customers, money, business)

**Phase 4 checkpoint:** real sales data, real customer feedback, and a clear decision about the next 90 days.

## Launch Budget

| Item | Budgeted | Actual |
|---|---|---|
| First stock order | $ | $ |
| Samples and testing | $ | $ |
| Packaging extras | $ | $ |
| Market stall fees | $ | $ |
| Travel and parking | $ | $ |
| Marketplace / payment fees | $ | $ |
| Advertising test | $ | $ |
| Insurance | $ | $ |
| Registration and licences | $ | $ |
| Contingency reserve | $ | $ |
| **Total** | **$** | **$** |

## Notes and Changes

_Record what changed from the plan and why — this is how the next 90 days get better._

-
-
-
