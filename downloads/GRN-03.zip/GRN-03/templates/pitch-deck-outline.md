# Pitch Deck Outline — Green Business Launchpad (GRN-03)

Use this outline when you need to explain your business to a potential stockist, partner, market organiser, or local supporter. Keep the whole deck to 10 slides or fewer, and use plain language and real numbers — no invented figures.

## Slide 1 — Title
- Business name
- One-line description: who you help and what changes for them
- Your name and contact details

## Slide 2 — The Problem
- The specific problem, in your customers' own words
- How many people have it (your interview and research evidence)
- What they do about it today, and why that is not good enough

## Slide 3 — Your Solution
- What you sell, in one or two sentences
- What makes it different: the green benefit and the practical benefit
- A photo of the real product or service in action

## Slide 4 — Your Customer
- Who exactly: the niche, in one sentence
- Where they gather and how you reach them
- What they already spend on this problem

## Slide 5 — Business Model
- How you make money: price, bundle or subscription, and how often customers pay
- Your two sales channels
- Gross margin per sale (from your pricing calculator)

## Slide 6 — Proof So Far
- Only what is true: interviews completed, paid test results, first customers, markets attended
- One short, real customer comment (with permission) if you have one
- Never invent testimonials, sales figures, or reviews

## Slide 7 — Market and Competition
- Who else serves this niche, and what they charge
- What customers complain about with the current options
- Why your offer fits the gap

## Slide 8 — Suppliers and Sustainability
- Your launch supplier and what is certified or verified
- The evidence behind your green claims (name the standard, not just the adjective)
- What you are still working on — honesty builds trust

## Slide 9 — The Ask
- What you are asking for: a stockist order, a market pitch, a partnership, a trial
- Exactly what you need from them, and what they get in return
- Your launch date and next step

## Slide 10 — Thank You and Contact
- Your name, email, and phone
- A clear next step and a date for it

---

**Tips:** Rehearse the deck out loud and keep it under ten minutes. Bring a sample of the product if you can. If you do not know the answer to a question, say so and follow up — never guess a number in front of a potential partner.
