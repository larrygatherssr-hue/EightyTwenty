# Cleaning and Turnover Standard Operating Procedure (SOP)

**SKU:** RE-04 — The Short-Term Rental Mastery Program

**Standard:** hotel clean, every time. Every surface cleaned, every linen fresh, every towel fresh, every bin emptied, every supply restocked, and the property inspected as a guest would inspect it — before the next guest arrives. Do not rely on memory. Follow this checklist at every turnover.

**Time allowed:** check-out [10 a.m.] to check-in [3 p.m.] — five hours for a two-bedroom property in most cases. Do not agree to an early check-in until the property is actually ready.

**Supplies:** cleaning products, vacuum, mop, cloths, gloves, stain remover, bin liners, and spare linen are stored in [location]. Check the stock list at every turnover and note anything running low.

---

## Step 1 — Check-Out Inspection (as soon as the guest leaves)

- Walk through every room and note any damage, missing items, or excessive mess.
- Photograph anything damaged or missing, with the date.
- Check under beds, behind doors, and inside cupboards a guest may have used.
- Note anything that needs a repair or a replacement, and report it to the host the same day.
- Do not start cleaning until the inspection is done — the inspection is your evidence.

## Step 2 — Strip and Start Laundry

- Remove all used linen, towels, bath mats, and kitchen cloths.
- Start the wash immediately so laundry is running while you clean.
- Put fresh linen on every bed: fitted sheet, flat sheet or duvet cover, pillowcases, and a spare blanket where provided.
- If laundry cannot be finished before check-in, use the spare set — never put damp or used linen back on a bed.
- White linen: check for stains, treat promptly, and replace stained items rather than hoping the next guest will not notice.

## Step 3 — Kitchen

- Clear all surfaces; wipe down counters, table, chairs, and handles.
- Clean the hob, oven exterior, microwave inside and out, and the outside of the fridge.
- Check inside the fridge; remove anything left by the previous guest; wipe shelves.
- Wash or run the dishwasher for any dishes left; put all dishes, glasses, and cutlery away clean.
- Clean the sink and taps; check the bin, empty it, and fit a new liner.
- Check that there are enough plates, glasses, and cutlery for the maximum number of guests.
- Restock tea, coffee, and any other kitchen consumables to the standard level.

## Step 4 — Bathroom(s)

- Clean the toilet, basin, shower or bath, taps, mirror, and tiles.
- Check the shower drain and remove any hair.
- Wipe all surfaces; clean the floor.
- Hang fresh towels: one bath towel and one hand towel per guest, plus a spare set.
- Restock toilet paper (at least two spare rolls visible), soap, and shampoo.
- Check the bath mat is clean and dry; replace if damp or stained.
- Empty the bin and fit a new liner.

## Step 5 — Bedrooms

- Make every bed properly: sheets tucked, duvet straight, pillows plumped, throw or runner in place.
- Dust all surfaces, including bedside tables, lamps, and windowsills.
- Check wardrobes and drawers are empty of the previous guest's belongings.
- Check the heating, lights, and any bedside chargers work.
- Vacuum or mop the floor, including under the bed.
- Leave a spare blanket in the room where provided.

## Step 6 — Living and Dining Areas

- Dust all surfaces, including shelves, the TV, and lamps.
- Clean the sofa and chairs: check cushions, remove crumbs and debris, check for stains.
- Wipe the dining table and chairs; set the table if that is your standard.
- Clean windows and mirrors where they are visibly marked.
- Vacuum or mop the floor, including under the sofa and tables.
- Check remote controls, books, and games are in place and working.

## Step 7 — Entrance, Hallways, and Outside

- Clean the entrance area, hallway, and any stairs.
- Check the front door, lock, and lights work.
- Wipe the entrance mirror and any hooks or rails.
- Check the outside area, balcony, or garden: tidy, bins in place, no rubbish.
- Check parking area instructions are visible where provided.

## Step 8 — Restock and Supplies Check

- Toilet paper, soap, shampoo, tea, coffee: restocked to the standard level.
- Cleaning products and bin liners: check the supplies cupboard.
- Note anything running low on the stock list for reorder before it runs out.
- Check the first-aid kit is in place and in date.

## Step 9 — Guest Inspection Walk-Through

Walk through the property as if you have just arrived:

- The entrance: well lit, welcoming, no clutter.
- Every room: lights on, curtains open, bed made, towels hung, surfaces clear.
- Run the shower briefly; check the water is hot.
- Check the Wi-Fi connects in the bedroom, not just next to the router.
- Sit on the sofa. Look in the mirrors. Open the cupboards a guest will open.
- Check the heating or cooling is set to a comfortable level.
- If something is not right, fix it now — not after the guest arrives.

## Step 10 — Photograph, Reset, and Confirm

- Take a quick photograph of each room after cleaning. Keep the photos with the booking record.
- Set the heating or cooling, lock up, and confirm to the host that the property is ready.
- Record the turnover: date, cleaner, time taken, and any damage or issues noted.

---

## Supplies — Standard Stock List

| Item | Standard level | Location |
|---|---|---|
| Toilet paper | 2 rolls in use + 2 spare per bathroom | Bathroom / supplies cupboard |
| Hand soap | 1 full dispenser per bathroom + spare | Bathroom / supplies cupboard |
| Shampoo / shower gel | 1 full bottle per bathroom | Bathroom / supplies cupboard |
| Tea and coffee | Enough for the stay length + spare | Kitchen |
| Bin liners | Full roll in supplies cupboard | Supplies cupboard |
| Cleaning products | Full set, in date | Supplies cupboard |
| Spare linen | 1 full set per bed, clean and ready | Linen cupboard |
| Spare towels | 1 set per guest, clean and ready | Linen cupboard |

**Cleaner:** ______________________ · **Backup cleaner:** ______________________

**Host contact for problems during a turnover:** ______________________
