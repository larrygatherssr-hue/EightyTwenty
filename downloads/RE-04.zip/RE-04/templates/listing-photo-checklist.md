# Listing Photo Checklist

**SKU:** RE-04 — The Short-Term Rental Mastery Program

**Goal:** 20–30 bright, honest, well-composed photos that show every room, the entrance, the outside, and the details that matter. Every photo must show the property as a guest will find it — nothing hidden, nothing added that will not be there on arrival.

## Before You Shoot

- [ ] Shoot in daylight, with all lights on and curtains open.
- [ ] Make every bed properly; clear all counters; hide bins, cables, and cleaning products.
- [ ] Remove personal belongings and clutter from every room.
- [ ] Clean the property to the turnover standard first — the photos are the standard guests will expect.
- [ ] Charge the camera or phone fully; clean the lens.
- [ ] Shoot from a doorway or corner so the whole room is visible; keep the camera level, not tilted.
- [ ] Take each shot at the height a guest would see the room; take more photos than you need and choose the best.

## Shot List

### First Photo (seen in search results)
- [ ] Best room — usually the living room or primary bedroom, bright and inviting, bed made, room tidy.

### Living Room
- [ ] Wide shot from the doorway showing the whole room.
- [ ] Sofa and seating area, with cushions and throw in place.
- [ ] TV and seating from the sofa's point of view.
- [ ] Detail: coffee table, books, or decor.

### Primary Bedroom
- [ ] Wide shot showing the whole room and the bed made properly.
- [ ] Bed close-up: bedding, pillows, throw.
- [ ] Bedside tables and lamps.
- [ ] Wardrobe or storage (door open, empty and tidy, or closed if that photographs better).

### Second Bedroom
- [ ] Wide shot showing the whole room and the bed made properly.
- [ ] Bed close-up.
- [ ] Storage and bedside details.

### Bathroom(s)
- [ ] Wide shot showing the shower or bath, basin, and mirror.
- [ ] Towels hung neatly; toilet paper and soap visible.
- [ ] Detail: clean taps, mirror, and tiles.

### Kitchen
- [ ] Wide shot showing the full kitchen.
- [ ] Hob, oven, and worktops clear and clean.
- [ ] Fridge, kettle, and coffee-making area.
- [ ] Dining table set, if the kitchen includes dining.

### Dining Area
- [ ] Table set for the number of guests the property sleeps.
- [ ] Wide shot showing dining in context with the living area.

### Entrance and Outside
- [ ] Front door and entrance, well lit.
- [ ] Hallway.
- [ ] Outside of the building (honest, current photo).
- [ ] Garden, balcony, or terrace, if any.
- [ ] Parking area, if any.
- [ ] View from a window, if there is one worth showing — only if it is the real view.

### Details (2–4 photos)
- [ ] Wi-Fi details / house manual location (do not photograph passwords — show the manual, not the code).
- [ ] A thoughtful detail: fresh flowers, a welcome tray, or a local guidebook.
- [ ] Heating controls, smart lock, or other features a guest will use.

## Ordering the Photos

1. Best photo first (living room or primary bedroom).
2. Other main rooms.
3. Kitchen and bathroom.
4. Details.
5. Outside, entrance, and view last.

## What Not to Do

- Do not use photos of a different property, or of the property before a renovation that has not happened.
- Do not use heavily filtered photos that change the colour of the walls or the size of the rooms.
- Do not include photos of people, of your personal belongings, or of cluttered cupboards.
- Do not leave the listing with five photos when the property has eight rooms and a garden. Guests assume what you do not show is what you are hiding.

## After the Shoot

- [ ] Review every photo on a phone screen, as a guest would see it.
- [ ] Remove any photo that is dark, blurred, tilted, or misleading.
- [ ] Check that the photos match the listing copy — bed sizes, seating, and features must agree.
- [ ] Re-photograph any room that has changed significantly since the last shoot.
- [ ] Date of shoot: ______________ · Photographer: ______________
