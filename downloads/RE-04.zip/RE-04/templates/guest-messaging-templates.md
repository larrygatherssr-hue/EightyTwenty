# Guest Messaging Templates

**SKU:** RE-04 — The Short-Term Rental Mastery Program

Adapt every template to your property before use: fill in the bracketed details, remove anything that does not apply, and read each message as a guest before you send it. Keep all booking communication on the platform. Do not offer anything in exchange for a review, and do not promise anything you cannot deliver.

---

## 1. Inquiry Reply

> Hi [Guest Name], thank you for your message. Yes, the property is available for [dates] for [number] guests. The total for your stay is [$ amount], including the cleaning fee, before taxes. [Answer their specific question directly here — for example: "Yes, there is free parking on the street outside, and the Wi-Fi speed is [speed]."]
>
> Check-in is from [3 p.m.] and check-out is by [10 a.m.]. You can book through the listing link, and I will send the access details the morning of your arrival. Please let me know if you have any other questions.
>
> Best wishes, [Your Name]

**Use when:** a guest inquires but has not booked. Reply within an hour during the day where possible.

## 2. Booking Confirmation

> Hi [Guest Name], thank you for booking — I am delighted you chose [Property Name]. Your stay is confirmed for [check-in date] to [check-out date] for [number] guests.
>
> Check-in is from [3 p.m.] and check-out is by [10 a.m.]. I will send your access code and the full arrival information [1–2 days before / on the morning of] your arrival.
>
> If you need anything before then — an early check-in, a cot, or a recommendation for the area — please just ask. I look forward to welcoming you.
>
> Best wishes, [Your Name]

## 3. Pre-Arrival Message (1–2 days before check-in)

> Hi [Guest Name], your stay is almost here. Here is everything you need for arrival:
>
> **Address:** [Full address]
> **Access:** [Smart lock code / lockbox code and location — send only close to arrival, as your platform advises]
> **Parking:** [Where to park]
> **Wi-Fi:** Network [name] — Password [password]
> **Check-in:** from [3 p.m.] · **Check-out:** by [10 a.m.]
>
> The house manual is in the property and has the heating, appliance, and emergency information. If you have any trouble on arrival, please message me here and I will help straight away.
>
> Safe travels, [Your Name]

## 4. Check-In Day Message (morning of arrival)

> Hi [Guest Name], the property is ready for you. Your access code is [code], and the full arrival details are in my previous message. I hope you have a smooth journey and a comfortable stay. Please let me know once you have settled in, and message me any time if you need anything.
>
> Best wishes, [Your Name]

## 5. First-Evening Check-In

> Hi [Guest Name], I hope you have settled in well and that everything is comfortable. Please let me know if you need anything at all during your stay — extra towels, a recommendation, or help with anything in the property. Enjoy your evening.
>
> Best wishes, [Your Name]

Send once only. Do not message the guest again without a reason.

## 6. Check-Out Reminder (day before check-out)

> Hi [Guest Name], I hope you have had a good stay. A quick reminder that check-out is tomorrow by [10 a.m.]. When you leave, please:
>
> - Leave the used towels in the bath
> - Take out the rubbish
> - Lock the door behind you [and return the keys to — location]
>
> There is no need to strip the beds or clean. Thank you, and safe travels home.
>
> Best wishes, [Your Name]

Keep the list short — three or four items, not a page of chores.

## 7. Review Request (after check-out)

> Hi [Guest Name], thank you for staying at [Property Name]. I hope you enjoyed your visit. If you have a moment, a review would mean a lot — and I have left one for you too. I hope to welcome you back one day.
>
> Best wishes, [Your Name]

Do not offer anything in exchange for a review, and do not ask for a five-star review directly.

## 8. Problem Response

> Hi [Guest Name], I am sorry [the heating is not working / you are having trouble with — describe the problem]. I have [called the engineer / arranged — say what you are doing] and [they will be there within — time / it will be fixed by — time]. In the meantime, [practical help — extra blankets / a kettle / an alternative].
>
> I will message you again as soon as I have an update. Thank you for letting me know, and I am sorry for the inconvenience.
>
> Best wishes, [Your Name]

**Rules:** reply quickly, acknowledge the problem without arguing about fault, say what you will do and by when, then do it. Keep the conversation on the platform.

## 9. Noise / House Rules Reminder (polite)

> Hi [Guest Name], I hope you are enjoying your stay. A quick note that quiet hours in the building are [10 p.m. to 8 a.m.], so I would be grateful if you could keep the volume down after [10 p.m.]. Thank you for understanding — I appreciate it.
>
> Best wishes, [Your Name]

Do not accuse the guest of hosting a party unless you have evidence. If the problem continues, follow the platform's process and document what happened.

## 10. Late Check-Out Request — Reply

> Hi [Guest Name], thank you for asking. [A late check-out until — time — is possible, and there is no extra charge / I am sorry, a late check-out is not possible on this occasion because the next guest arrives at — time. You are welcome to leave your luggage — arrangement — until — time.]
>
> Best wishes, [Your Name]

Decide your policy in advance and answer consistently.
