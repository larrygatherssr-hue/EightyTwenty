# The Short-Term Rental Mastery Program — Companion Workbook

**SKU:** RE-04 · **Price:** $597 one-time

Work through this workbook alongside `content.md`. Write in your real numbers — a workbook filled with your property's figures is a business plan; a blank one is just paper.

> **Disclaimer:** Education only — not individualized legal, tax, investment, or financial advice. Short-term rental rules, permits, HOA rules, lease terms, zoning, taxes, and platform policies vary by location and change often. Verify everything for your specific property before listing.

---

## 1. Property-Numbers Worksheet

Complete one column per scenario. Use the method in Module 3 and the calculator in `templates/str-pricing-occupancy-calculator.csv`.

| Item | Low scenario | Expected scenario | High scenario |
|---|---|---|---|
| Nightly rate | $ ______ | $ ______ | $ ______ |
| Available nights per year | ______ | ______ | ______ |
| Occupancy | ______ % | ______ % | ______ % |
| Booked nights | ______ | ______ | ______ |
| Gross nightly rent | $ ______ | $ ______ | $ ______ |
| Average stay (nights) | ______ | ______ | ______ |
| Number of stays | ______ | ______ | ______ |
| Cleaning fee per stay | $ ______ | $ ______ | $ ______ |
| Cleaning fees collected | $ ______ | $ ______ | $ ______ |
| **Total gross income** | **$ ______** | **$ ______** | **$ ______** |
| Mortgage / rent | $ ______ | $ ______ | $ ______ |
| Property tax | $ ______ | $ ______ | $ ______ |
| Insurance | $ ______ | $ ______ | $ ______ |
| Utilities and internet | $ ______ | $ ______ | $ ______ |
| Cleaning cost per turnover × stays | $ ______ | $ ______ | $ ______ |
| Laundry per turnover × stays | $ ______ | $ ______ | $ ______ |
| Supplies and restocking | $ ______ | $ ______ | $ ______ |
| Platform host fee | $ ______ | $ ______ | $ ______ |
| Maintenance and replacement reserve | $ ______ | $ ______ | $ ______ |
| Software and miscellaneous | $ ______ | $ ______ | $ ______ |
| Cleaner / co-host fees (if hired) | $ ______ | $ ______ | $ ______ |
| **Total expenses** | **$ ______** | **$ ______** | **$ ______** |
| **Net profit before tax (per year)** | **$ ______** | **$ ______** | **$ ______** |
| **Net profit before tax (per month)** | **$ ______** | **$ ______** | **$ ______** |

**My break-even occupancy:** ______ % ( ______ booked nights per year)

**My furnishing budget:** $ ______

**Furnishing payback period at expected occupancy:** ______ months

**My minimum acceptable monthly net profit before tax:** $ ______

**Decision:** Proceed / Wait / Do not proceed — Reason: ______________________________

---

## 2. Furnishing Budget

Palette: Neutrals ______ / ______ · Accent ______ · Metal ______ · Wood ______

| Room / category | Planned | Actual | Notes |
|---|---|---|---|
| Primary bedroom (bed, mattress, bedding, tables, lamps) | $ ______ | $ ______ | |
| Second bedroom | $ ______ | $ ______ | |
| Living room (sofa, chairs, tables, TV) | $ ______ | $ ______ | |
| Dining (table and chairs) | $ ______ | $ ______ | |
| Kitchen (cookware, dinnerware, appliances) | $ ______ | $ ______ | |
| Bathroom (towels, mat, mirror, storage) | $ ______ | $ ______ | |
| Linens and spares (two sets per bed) | $ ______ | $ ______ | |
| Decor, art, cushions, throws | $ ______ | $ ______ | |
| Smart lock, Wi-Fi, electronics | $ ______ | $ ______ | |
| Cleaning supplies and equipment | $ ______ | $ ______ | |
| Contingency (10%) | $ ______ | $ ______ | |
| **Total** | **$ ______** | **$ ______** | |

Measurements taken (room / doorway / stairs): ______

Receipts filed: Yes / No · Inventory list started: Yes / No

---

## 3. Listing-Copy Worksheet

**Title (short, specific):** ______________________________________________________

**Summary (2–3 sentences):** ____________________________________________________
______________________________________________________________________________

**Who this property suits (one sentence):** ______________________________________

**Bedrooms:** ___________________________________________________________________

**Bathroom:** ____________________________________________________________________

**Kitchen:** _____________________________________________________________________

**Living / dining:** ____________________________________________________________

**Outside / parking:** __________________________________________________________

**Wi-Fi speed:** ______ · **Heating / cooling:** ________________________________

**Check-in method and time:** ___________________________________________________

**Check-out time:** ________________

**Honest limitations (stairs, noise, parking — state them):** ______________________
______________________________________________________________________________

**House rules (short list only):**
1. ______________________________ 2. ______________________________
3. ______________________________ 4. ______________________________
5. ______________________________ 6. ______________________________

**Neighborhood (nearest shop, station, café, park — verified):** __________________
______________________________________________________________________________

---

## 4. Pricing Worksheet

| Item | Amount |
|---|---|
| Base nightly rate | $ ______ |
| High-season rate (base + 20–40%) | $ ______ |
| Shoulder-season rate | $ ______ |
| Low-season rate (base − 15–30%) | $ ______ |
| Weekend rate | $ ______ |
| Weekday rate | $ ______ |
| Weekly discount | ______ % |
| Monthly discount | ______ % |
| Cleaning fee (close to actual cleaning cost) | $ ______ |
| Minimum stay — high season | ______ nights |
| Minimum stay — low season | ______ nights |
| **Pricing floor (never price below this)** | **$ ______** |

Variable cost per booked night (cleaning + laundry per stay ÷ average stay + platform fee): $ ______

Local events to price for (date / event / planned rate): _________________________
______________________________________________________________________________

Pricing review rhythm: Weekly check on ______ · Monthly review on ______

---

## 5. Guest-Message Planner

Fill in your real details, then copy the adapted messages into `templates/guest-messaging-templates.md`.

| Message | When sent | Key details to include |
|---|---|---|
| Inquiry reply | Within 1 hour | Availability, total price, answer to guest's question |
| Booking confirmation | On booking | Dates, guest count, check-in time and method |
| Pre-arrival | 1–2 days before | Address, access code, parking, Wi-Fi |
| Check-in day | Morning of arrival | Property ready, access repeated |
| During stay (first evening) | First evening | Settled in? Offer help |
| Check-out reminder | Day before check-out | Time, short task list |
| Review request | After check-out | Thank you, polite review request |

**My reply-time standard:** ______

**My policy:** Early check-in ______ · Late check-out ______ · Extra guests ______ · Pets ______ · Discounts ______

---

## 6. Turnover Checklist

Use with `templates/cleaning-turnover-sop.md`. Tick each item at every turnover.

- [ ] Check-out inspection done; damage photographed and noted
- [ ] All used linen and towels stripped; laundry started
- [ ] Fresh linen on all beds; spare set available
- [ ] Kitchen cleaned (including fridge and microwave)
- [ ] Bathroom cleaned (including shower, toilet, mirror, floor)
- [ ] Living and dining areas cleaned and dusted
- [ ] Bedrooms cleaned; under beds checked
- [ ] Floors vacuumed / mopped throughout
- [ ] Bins emptied; new bin liners in place
- [ ] Toilet paper, soap, shampoo restocked
- [ ] Tea, coffee, and consumables restocked
- [ ] Supplies cupboard checked; low items noted for reorder
- [ ] Lights, heating / cooling, Wi-Fi, shower tested
- [ ] Guest inspection walk-through done (as a guest would see it)
- [ ] Photos of each room after cleaning taken
- [ ] Heating / cooling set; property locked; ready confirmed

**Cleaner:** ______________________ · **Backup cleaner:** ______________________

**Turnover time (check-out to ready):** ______ hours

---

## 7. Local-Regulation Research Checklist

Record the source and date for every answer. "Probably allowed" is not an answer. Rules vary by location and change often — verify in writing.

| Question | Answer | Source | Date checked |
|---|---|---|---|
| What is the property's zoning, and does it allow short-term rental? | | | |
| Is registration, a license, or a permit required? | | | |
| Permit / registration number (if any) | | | |
| Is there a cap on nights per year? How many? | | | |
| What taxes must be collected / remitted? Does the platform handle any? | | | |
| Safety requirements (detectors, extinguisher, occupancy limit)? | | | |
| HOA / condo / building rules — short-term rental allowed? Conditions? | | | |
| Written HOA / board confirmation obtained? | | | |
| Lease — subletting allowed? Written landlord permission obtained? | | | |
| Mortgage — does the lender allow short-term rental? | | | |
| Insurance — does the policy cover short-term rental? Written confirmation? | | | |
| Platform requirements (verification, registration number, policies)? | | | |

**Annual re-check reminder set for:** ______________________

---

## 8. Monthly Profit Tracker

Copy one table per month. Compare each month with your Module 3 plan.

| Month: ______________ | Planned | Actual | Difference |
|---|---|---|---|
| Nights available | | | |
| Nights booked | | | |
| Occupancy | % | % | |
| Average nightly rate | $ | $ | |
| Gross nightly rent | $ | $ | |
| Cleaning fees collected | $ | $ | |
| **Total gross income** | **$** | **$** | |
| Mortgage / rent | $ | $ | |
| Utilities and internet | $ | $ | |
| Cleaning | $ | $ | |
| Laundry | $ | $ | |
| Supplies | $ | $ | |
| Platform fees | $ | $ | |
| Maintenance / replacements | $ | $ | |
| Other | $ | $ | |
| **Total expenses** | **$** | **$** | |
| **Net profit before tax** | **$** | **$** | |

**Why this month differed from plan:** ___________________________________________
**What needs attention next month:** ____________________________________________
**Receipts and platform statement filed:** Yes / No

---

## 9. First-90-Days Plan

| Phase | Dates | Key tasks | Done |
|---|---|---|---|
| Days 1–14: Decide and research | ______ | Modules 1–3; permits; written confirmations | [ ] |
| Days 15–45: Set up | ______ | Furnish; practice turnover; listing live | [ ] |
| Days 46–90: Host and improve | ______ | First guests; track monthly; fix top complaint | [ ] |

**90-day review — three questions:**
1. Did the property earn what the plan said it would, and if not, why? ____________
2. What do guests praise most? What do they mention as a problem? _______________
3. What will I change in the next 90 days? ______________________________________
