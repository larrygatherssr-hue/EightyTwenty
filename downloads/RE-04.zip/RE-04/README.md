# The Short-Term Rental Mastery Program — RE-04

**Price:** $597 one-time · **Category:** Real Estate · **SKU:** RE-04

*Turn a property into a profitable short-term rental — pricing, listing, and guest systems that work.*

## Files in This Product

| File | Description |
|---|---|
| `content.md` | The complete 13-module course — full prose with worked examples using real numbers (sample property at 65% vs 80% occupancy), action steps at the end of every module, and a full education-only disclaimer |
| `workbook.md` | Companion workbook — property-numbers worksheet, furnishing budget, listing-copy worksheet, pricing worksheet, guest-message planner, turnover checklist, local-regulation research checklist, and monthly profit tracker |
| `templates/str-pricing-occupancy-calculator.csv` | STR pricing and occupancy calculator — enter nightly rate, occupancy, gross, expenses, and net, with the sample property's 65% and 80% examples and break-even calculation |
| `templates/guest-messaging-templates.md` | Guest messaging templates — inquiry, booking confirmation, check-in, check-out, review request, and problem response |
| `templates/cleaning-turnover-sop.md` | Cleaning and turnover SOP — room-by-room hotel-clean standard with a supplies stock list |
| `templates/listing-photo-checklist.md` | Listing photo checklist — every shot, room by room, in viewing order |
| `sales-page.md` | Full sales page — headline, problem, solution, 13-module contents, who it is for / not for, price and 14-day guarantee, 9 FAQs, and disclaimers |
| `listing.json` | Marketplace listing data (SKU, name, category, price in cents, headline, description, delivery note, SEO keywords, refund policy, support) |
| `cover.md` | Cover design brief — black-and-gold luxury branding, typography, imagery, and layout direction |
| `cover.webp` | Generated product cover image (portrait, black-and-gold, home at dusk) |
| `onboarding.md` | Customer onboarding guide — what to do first, how to use each file, a suggested 90-day schedule, and how to get support |
| `README.md` | This file — index of the product's files |

## Key Facts

- **Worked example throughout:** a two-bedroom condo at $175/night — 65% occupancy: $48,505 gross, $34,084 expenses, $14,421 net per year; 80% occupancy: $59,745 gross, $36,073 expenses, $23,672 net per year; break-even about 41% occupancy. Furnishing budget $9,500.
- **Disclaimer:** Education only — not individualized legal, tax, or investment advice. Local short-term rental rules, permits, HOA rules, and platform policies vary by location and change often; the buyer must verify them before listing. Stated in `content.md`, `workbook.md`, `sales-page.md`, and `onboarding.md`. No guaranteed income or occupancy claims.
- **Guarantee:** 14-day money-back guarantee, full refund, no questions asked.
