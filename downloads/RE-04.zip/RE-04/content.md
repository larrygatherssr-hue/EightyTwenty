# The Short-Term Rental Mastery Program

**SKU:** RE-04 · **Category:** Real Estate · **Price:** $597 one-time

*Turn a property into a profitable short-term rental — pricing, listing, and guest systems that work.*

---

## Important Notice — Please Read First

This program is education only. It is not individualized legal, tax, investment, or financial advice, and it is not a promise of income, occupancy, or profit. Short-term rental rules, permits, homeowners association (HOA) rules, lease terms, zoning, taxes, and platform policies vary by city, county, state, and country, and they change often. You must verify the rules that apply to your specific property, in writing, with the relevant local authority, your HOA or landlord, and the platform you plan to use, before you list, furnish, or accept a booking. Nothing in this course replaces a licensed attorney, tax professional, insurance agent, or financial adviser for your situation.

No income or occupancy figure in this course is guaranteed. Every worked example uses stated assumptions for teaching purposes only. Your nightly rate, occupancy, expenses, and profit will differ — sometimes by a lot — depending on your location, property, season, competition, pricing, reviews, and how the property is managed. Treat the examples as a method for doing your own math, not as a forecast for your property.

---

## Welcome: What This Program Will Help You Do

A short-term rental — a home, condo, apartment, or room rented by the night, usually through a platform such as Airbnb or Vrbo — can earn more per month than a long-term rental in the right location, with the right property, at the right price, run with good systems. It can also lose money, attract complaints, and create legal trouble when a host guesses at the price, overspends on furniture, ignores local rules, or has no system for cleaning and guest communication.

This program exists to close that gap. It is written for a homeowner or investor with one property — a home you already own, a second property, or a property you lease specifically to re-rent by the night (known as rental arbitrage) — who wants a clear, honest, step-by-step way to decide whether short-term rental makes sense, set it up properly, price it well, present it well, host guests well, and keep it running without the work taking over your life.

You do not need prior hosting experience. You do need patience, attention to detail, and a willingness to do the research in Module 2 before you spend money on furniture or publish a listing. The hosts who struggle most are usually not the ones with the least attractive property. They are the ones who skipped the numbers, skipped the rules, or tried to run a nightly business on memory and good intentions.

### How to Use This Course

Work through the modules in order the first time. Modules 1 to 3 are the decision: is this right for you, is it allowed where your property sits, and do the numbers work? Do not skip them. Modules 4 to 8 are the setup: furnishing, listing, pricing, and guest communication. Modules 9 to 11 are the operation: cleaning, problems, and taxes and records. Modules 12 and 13 are the honest comparisons and the question of growth: arbitrage versus ownership, and whether a second unit makes sense.

Each module ends with action steps. Do them before you move on where the module says so, especially in Modules 2 and 3. The companion workbook (`workbook.md`) gives you the worksheets to complete as you go, and the `templates/` folder gives you the calculator, message templates, cleaning standard operating procedure (SOP), and photo checklist to use in real operation. Print the workbook or fill it in digitally — either way, write your real numbers in it. A course you only read is a course you will forget. A course you work through becomes a business plan.

### The Outcome

By the end of this program you will be able to:

- Decide, with evidence, whether short-term rental fits your property, your location, your finances, and your available time.
- Research and document the local rules, permits, HOA or lease restrictions, and platform requirements that apply to you.
- Calculate a realistic nightly rate, occupancy range, gross income, expenses, and net profit — and know which assumptions drive the result.
- Furnish a property to a clear budget that photographs well and survives guest use.
- Write listing copy and take or commission photos that show guests exactly what they will get.
- Set prices that respond to season, weekday, events, and booking lead time without constant manual work.
- Communicate with guests from first inquiry to review request in a warm, professional, consistent way.
- Run a reliable cleaning and turnover system, handle damage and difficult situations calmly, and keep records that make tax time straightforward.
- Compare owning and arbitrage honestly, and decide whether — and when — a second unit is a sensible next step.

That is the whole job. Nothing here is magic, and nothing here is a shortcut around the rules or the math. What follows is the work, in order, explained plainly.

### The Sample Property Used Throughout This Course

To keep the numbers consistent, this course follows one sample property through the worked examples:

**The sample property:** a two-bedroom, one-bathroom condo, sleeps four, in a mid-sized city with year-round visitors — a mix of weekend leisure guests, visiting family, and weekday workers on short assignments. It is furnished for short-term rental, professionally cleaned between stays, and listed on one major platform.

**The sample assumptions (stated, not promised):**

- Nightly rate: $175 per night (before cleaning fee and taxes)
- Cleaning fee charged to guests: $95 per stay
- Average stay length: 3.2 nights
- Platform host service fee: 3% of the nightly rent (the cleaning fee is passed through separately in this example; check your platform's current fee structure, because it changes)
- Furnishing budget: $9,500 one time (see Module 4 for the breakdown)
- Monthly fixed costs: mortgage, taxes, and insurance $1,450; utilities and internet $260; supplies and restocking $150; software and miscellaneous $60
- Variable costs per turnover: professional cleaning $85; laundry $15
- Annual maintenance and replacement reserve: $2,400 per year ($200 per month)

You will see this property at 65% occupancy and at 80% occupancy in Module 3. The difference between those two numbers — about $9,600 in gross rent a year — is the difference between a solid listing with good reviews and a listing that is priced wrong, photographed poorly, or slow to answer guests. Occupancy is not luck. It is the result of the systems in Modules 5 through 9.

Keep in mind that this sample is deliberately ordinary. It is not a beach house, not a luxury cabin, and not a city-center apartment with a view. Most first hosts start with something ordinary, and ordinary properties can host well when they are clean, honest, well-priced, and well-run. If your property is very different — a studio, a large house, a rural cabin — the method in Module 3 still applies. Change the inputs; keep the method.

---

## Module 1 — Is Short-Term Rental Right for You and Your Property?

Short-term rental suits some owners and some properties very well, and others not at all. The purpose of this module is to help you make that judgment before you spend money or make promises to anyone. A good decision here saves you the cost of furnishing a property that should never have been listed, and it saves you the disappointment of discovering the rules or the numbers only after you have committed.

### What Short-Term Rental Actually Is

A short-term rental is a furnished property rented by the night, usually for stays of one night to about a month, booked through an online platform. The host — you — provides the home, the furniture, the linens, the basic supplies, the cleaning between guests, and the communication before, during, and after each stay. The platform provides the marketplace, the booking and payment system, and, to a limited degree, guest verification and host protection. The platform does not clean the property, answer your guests at midnight, or check whether your listing is legal in your city. Those are your responsibilities.

That is a different business from long-term rental. A long-term tenant signs a lease for months or a year, pays monthly, and usually furnishes the home themselves. A short-term host turns the property over many times a year — in our sample property, about 74 turnovers a year at 65% occupancy — and each turnover is a cleaning, an inspection, a restock, and a new guest relationship. The income per night can be higher. The work per month is much higher, and the income is less predictable.

It is also different from running a hotel. You have one property, not fifty rooms. You cannot absorb a bad month by filling the room next door. Your reputation is concentrated in a single listing and a single review score. One careless turnover, one misleading photo, or one slow reply can cost you bookings for weeks. The advantage of one property is focus: you can know every corner of it, every quirk of the heating, every stain on the carpet, and you can fix problems fast. Use that advantage.

### The Four Questions

Before anything else, answer four questions honestly.

**1. Is the property suitable?** Not every home makes a good short-term rental. The strongest candidates share several traits: a location guests actually want to visit — near a city center, a beach, a lake, a university, a hospital, a business district, or a tourist area; safe, walkable surroundings; reliable parking or public transport; a layout that sleeps guests comfortably without awkward conversions; good natural light for photographs; and a condition that is clean, sound, and presentable without major renovation. A property that needs a new roof, has persistent damp, has thin walls with noisy neighbors, or is a long drive from anything guests want will struggle, however nicely you furnish it.

Walk through your property as a guest would. Arrive at the front door with a suitcase. Where do you park? How do you get in? Is the entrance well lit? Is the first thing you see welcoming or tired? Open every cupboard and drawer. Sit on every seat. Lie on the bed. Run the shower — is the water hot, and is the pressure acceptable? Turn on the heating and the cooling. Check the Wi-Fi speed in the bedroom, not just next to the router. Guests notice all of this, and they write about it in reviews. A property that is merely adequate as a home can be a poor short-term rental if its flaws are the kind guests experience every day: a lumpy mattress, a shower that runs cold, a front door that sticks, a street that is loud at night.

Also consider the building and the neighbors. If you are in a condo or apartment building, other residents will notice frequent turnover. Some buildings welcome it; some tolerate it; some forbid it outright. That is a rules question, covered in Module 2, but it is also a relationship question. A host who ignores neighbors' concerns about noise, parking, and late arrivals will eventually face complaints, and complaints lead to rule changes. Think about whether your property can be hosted quietly and considerately before you decide it can be hosted at all.

**2. Is the demand real?** Demand is not the same as hope. "People visit this city" is not evidence. Evidence looks like this: comparable listings near you with calendars that show bookings, reviews spread across the year (not only in summer), and nightly rates you can observe; local events, employers, hospitals, universities, and attractions that bring overnight visitors in different seasons; and a clear sense of who your guest is — a couple on a weekend break, a family visiting relatives, a worker on a short contract, a patient or a patient's family near a hospital.

Spend an evening doing this research. Search your platform of choice for properties like yours in your area. Note their nightly rates, their review counts, and how far ahead their calendars are booked. Read their reviews — guests will tell you what they loved and what they complained about, and that is free market research. If every comparable listing has only a handful of reviews and long gaps in its calendar, demand may be thin, seasonal, or already served by better properties. If comparable listings are busy and well-reviewed, there is demand — and there is also competition you must match or beat on cleanliness, photos, price, or location.

Be careful with the two most common demand mistakes. The first is assuming that because a city is popular, every neighborhood in it is popular. Guests choose a neighborhood, not a city. The second is assuming that your own affection for a place means guests will pay to stay there. You may love a quiet street twenty minutes from town. A guest without a car may not.

**3. Can you afford the setup and the slow months?** Short-term rental has real upfront costs and real slow periods. Furnishing a two-bedroom property properly — beds, sofas, tables, kitchen equipment, linens, towels, and the small things guests expect — commonly costs $7,000 to $15,000, depending on quality and whether you buy new or good secondhand pieces. Our sample budget in Module 4 is $9,500. On top of that there may be permit fees, insurance changes, professional photography, a smart lock, and a few months of mortgage and utilities before the listing earns enough to cover itself.

Then there is seasonality. Most markets have a low season — weeks when demand falls, rates must fall, or the calendar sits empty. If your mortgage, utilities, and insurance must be paid every month whether or not guests arrive, you need a cash reserve. A sensible minimum is three months of the property's fixed costs set aside before you list, separate from your furnishing budget. If you cannot fund both the setup and that reserve, wait. A host who must fill every night at any price to pay the mortgage will discount too far, accept guests they should decline, and burn out. Financial pressure makes bad hosting decisions.

Work out, in plain terms, what happens if the property earns nothing for the first two months while you build reviews, and what happens if it earns half what you hope in the low season. If the answer is that you would be in trouble, the timing is wrong, even if the property and the demand are right.

**4. Do you have the time — or a reliable way to buy it?** A short-term rental needs someone to answer inquiries quickly (ideally within an hour during the day), coordinate cleaning, handle check-ins, respond to problems, and restock supplies. For one property with moderate occupancy, that is commonly five to ten hours a week of your time if you do it yourself, plus being reachable when guests need you. If you live far from the property, you will need a cleaner you trust, a co-host or property manager, and a way to handle emergencies without being there. That is possible — many hosts manage remotely — but it costs money and it requires systems, which this course covers in Modules 8 and 9.

Be honest about your life. If you travel often, work long unpredictable hours, or dislike being contacted by strangers, self-managing a short-term rental will wear on you. That does not mean you cannot do it. It means you should plan from the start to pay for the help you need — a cleaner, a co-host, or a manager — and include that cost in your numbers in Module 3. A business that only works if you are available at all hours is not a business; it is a trap.

### Who Short-Term Rental Suits — and Who It Does Not

It tends to suit owners who enjoy hospitality, are organized and responsive, live reasonably near the property or have a trusted local team, have a financial cushion, and can treat guest feedback as useful information rather than personal criticism. It tends not to suit owners who want fully passive income with no guest contact, who cannot tolerate variable monthly income, who are uncomfortable with strangers in their property, or who hope to ignore local rules and hope nobody notices. That last group should stop here. The rules are real, the neighbors notice, and the platforms enforce their policies.

### A Note on Expectations

New hosts often expect full occupancy within weeks. That is rarely how it works. A new listing starts with no reviews. Guests prefer listings with reviews, so your first bookings often come at a lower price, from guests who are flexible, or from people who know you. As reviews accumulate — if they are good — occupancy and rate usually improve. Plan for a ramp-up of two to four months, and treat your first ten reviews as the most valuable asset your listing will ever earn. Everything in this course is designed to help you earn them.

### Module 1 — Action Steps

1. Walk your property as a guest and write down every flaw a guest would notice in the first hour. Be specific: mattress, shower, lighting, noise, parking, entrance.
2. Search your platform for ten comparable listings nearby. Record their nightly rate, review count, and how busy their calendars look.
3. Write down who your most likely guest is, in one sentence, and what they need most from your property.
4. Add up your furnishing budget and your three-month reserve. Can you fund both without borrowing? Write the answer down.
5. Estimate your honest weekly hours available for hosting. If it is under five, decide now what help you will pay for.

---

## Module 2 — Local Rules, Permits, and HOA/Lease Restrictions

This is the least exciting module in the course and the most important. A beautiful listing that breaks local rules can be shut down, fined, or removed from the platform — and the money spent furnishing it is not refunded by anyone. Do the research in this module before you spend on furniture, before you publish a listing, and before you accept a booking. Then do it again once a year, because rules change.

**A clear statement:** short-term rental rules, permits, HOA rules, lease terms, zoning, taxes, and platform policies vary by location and change often. This module teaches you a research method. It does not and cannot tell you the rules for your city, because the author does not know your city and the rules may have changed since this course was written. You must verify everything for your specific property, in writing, with the relevant authority. If a rule is unclear, get the answer in writing before you proceed.

### Why Rules Exist and Why They Are Enforced

Cities regulate short-term rentals for reasons that have little to do with you personally: housing supply, neighborhood character, noise, parking, safety, and tax collection. Some cities welcome short-term rentals and simply require registration and a tax payment. Some limit the number of nights per year, or require the host to live in the property. Some restrict short-term rental to certain zones. Some ban it in residential buildings altogether. HOAs and landlords have their own reasons: they answer to residents and long-term tenants who did not agree to live next to a nightly business.

Enforcement is real and it is getting more systematic. Platforms in many places now ask for a registration or permit number before a listing can be published, and they remove listings that do not provide one. Cities use listing data, neighbor complaints, and tax records to find unregistered rentals. Fines can run into thousands of dollars, and in some places a single violation can lead to a listing being removed permanently. "I did not know" is not a defense that helps. Do the research.

### The Research Method — Step by Step

Work through these steps in order and record everything in the local-regulation research checklist in the workbook and in `templates/` — no, the checklist is in the workbook and as a template file; use one copy and keep it with your property records. For each item, write the source, the date you checked, and the exact answer. A vague note such as "probably allowed" is not an answer.

**Step 1: Identify every authority that could apply.** Your property may be governed by more than one layer: a city or town, a county, a state or province, a national government, an HOA or condo association, a building management company, a landlord (if you lease), and the platform itself. List them all. If you are unsure which city department handles short-term rentals, start with the city planning or zoning department, or the city's website search for "short-term rental."

**Step 2: Check zoning first.** Zoning decides what a property in a given area may be used for. Some zones allow short-term rental; some allow it only with a permit or a conditional use approval; some do not allow it at all. Find your property's zoning designation — usually available on the city or county planning website by address — and then find what that designation permits. If the zoning does not permit short-term rental, that is usually the end of the question for that property unless you apply for and receive a change or exception, which is a formal process with no guaranteed outcome. Do not assume that because a neighbor lists their home, the zoning allows it. They may be operating without permission, or their property may be zoned differently from yours.

**Step 3: Check for a registration, license, or permit requirement.** Many cities require short-term rental hosts to register, obtain a license or permit, and display a registration number on the listing. There may be an application fee, an inspection, a requirement to notify neighbors, or a limit on the number of nights per year — commonly 90, 120, or 180 nights, though the number varies widely and some places have no limit. Ask the relevant department: Is registration required? What is the application process? What does it cost? How long does it take? Is there a cap on nights? Is there a waiting list or a cap on the number of permits? Is the permit tied to you or to the property? What happens if the rules change after you are registered?

**Step 4: Check taxes.** Short-term rental income is usually taxable, and in many places you must also collect and remit occupancy, lodging, or tourist taxes on top of the nightly rate. Some platforms collect and remit these taxes on your behalf in some locations; in others, you must register with the tax authority and remit them yourself. Ask your city and state or national tax authority what applies, whether the platform handles it, and what records you must keep. Do not assume the platform handles it. Check. Module 10 covers record-keeping; this step is about knowing which taxes exist before you set your price.

**Step 5: Check safety and building requirements.** Some jurisdictions require smoke detectors and carbon monoxide detectors in specific locations, a fire extinguisher, an emergency exit plan, a maximum occupancy limit, or a safety inspection. Your insurance policy may have its own requirements. Check both. A property that is safe and compliant is also a property you can describe with confidence in your listing.

**Step 6: Check HOA, condo, and building rules.** If your property is in an HOA, condo association, or managed building, read the governing documents — the declaration, bylaws, and rules and regulations — for any mention of short-term rental, leasing, minimum lease terms, guest policies, or commercial use. Many associations set a minimum lease term, commonly 30 days or six months, which effectively prohibits nightly rental. Some require board approval. Some allow it with conditions, such as a limit on the number of units that may be rented short-term, or a requirement to register guests. Get the answer in writing from the board or management company. A verbal "I think it is fine" from a neighbor is not permission. If the documents are silent, ask in writing and keep the reply.

**Step 7: Check your lease, if you lease.** If you rent the property yourself and plan to re-rent it by the night (arbitrage, Module 12), your lease almost certainly addresses subletting. Many leases prohibit subletting entirely; some allow it with written landlord consent; a few are silent. Read your lease word for word. If subletting is prohibited, arbitrage is not an option for that property unless the landlord agrees in writing to change the lease. Do not rely on the landlord not noticing. Short-term rental is visible — guests arrive with suitcases, cleaners come and go, and platforms publish the listing.

**Step 8: Check your mortgage and insurance.** Some mortgage agreements restrict short-term rental or require the lender to be notified. Some standard homeowner insurance policies do not cover short-term rental activity, or cover it only partially, and a claim arising from a guest stay could be denied. Call your insurer and your lender and ask directly: does my current policy cover short-term rental, and if not, what policy or endorsement do I need? Get the answer in writing and keep it with your records. This is one phone call that can save you an enormous problem later.

**Step 9: Check platform requirements.** Each platform has its own rules: identity verification, listing standards, cancellation policies, host protection terms, and, in many places, a requirement to provide a registration number. Read the platform's hosting terms for your location before you list. Understand what the platform's host protection does and does not cover — it is not a substitute for proper insurance — and understand the cancellation policy you choose, because it affects both your income and your ranking.

**Step 10: Write it all down and keep it current.** Record every answer with the source, the date, and the name of the person you spoke with. Keep permits, licenses, written permissions, and insurance confirmations in one folder — digital or paper — with your property records. Set a calendar reminder to re-check the rules once a year and whenever you hear that a local rule has changed. Rules that were permissive when you started can become restrictive, and the host who learns about the change from a fine is the host who was not paying attention.

### Common Situations and How to Think About Them

**"My city has no specific short-term rental rules."** That does not mean there are no rules. Zoning, building codes, tax obligations, HOA rules, and platform policies may still apply. It also means rules may be introduced later. Proceed only after checking the other layers, and stay alert for new regulation.

**"My neighbor does it, so it must be allowed."** Your neighbor may have a permit, a different zoning designation, a different HOA status, or no permission at all. Their situation tells you nothing reliable about yours. Check your own property.

**"I will list first and sort out the permit later."** This is the most expensive shortcut in short-term rental. If a permit takes weeks and your listing is removed in the meantime, you lose bookings and reviews. If a permit is denied, you have furnished a property for a business you cannot run. Get the permit first.

**"The platform will tell me if there is a problem."** The platform may, eventually. It is not your compliance department. The responsibility is yours.

### What to Do If the Answer Is No

If the rules do not allow short-term rental for your property, that is useful information, not a failure. It means you do not spend $9,500 furnishing a property for a business that would be shut down. Your options are to choose a different property, apply for a permit or exception if one exists (with no guarantee), rent the property long-term, or wait and re-check if the rules are under review. Do not proceed in the hope that nobody will notice. The neighbors notice, the platform notices, and the city notices — usually in that order.

### Module 2 — Action Steps

1. Complete the local-regulation research checklist for your property, with a source and date for every answer.
2. Obtain any required registration, license, or permit before you furnish or list.
3. Get written confirmation from your HOA or landlord if one applies, and written confirmation from your insurer that short-term rental activity is covered.
4. Note the night cap, if any, and the taxes you must collect or remit. Write both into your Module 3 numbers.
5. File everything in one folder and set an annual reminder to re-check.

---

## Module 3 — The Numbers: Nightly Rate, Occupancy, Expenses, and Profit

This module is the financial heart of the course. If you do the math honestly here, you will know whether your property can make money, at what occupancy, and what would have to change if it cannot. If you skip the math, you will learn the answer from your bank balance, months later, when it is harder to fix.

All figures in this module are worked examples using stated assumptions. They are not predictions, guarantees, or market data. Use the method with your own numbers — the companion calculator in `templates/str-pricing-occupancy-calculator.csv` is built for exactly that.

### The Five Numbers That Matter

Every short-term rental profit calculation comes down to five things:

1. **Nightly rate** — what a guest pays per night for the stay itself, before cleaning fees and taxes.
2. **Occupancy** — the share of available nights that are actually booked.
3. **Gross income** — nightly rate multiplied by booked nights, plus cleaning fees collected, plus any extra-guest or pet fees.
4. **Expenses** — everything it costs to own, run, clean, and maintain the property.
5. **Net profit** — gross income minus expenses, before income tax (tax is covered in Module 10; keep it separate here so you can see the operating result clearly).

Occupancy deserves a careful definition, because hosts use the word loosely. Occupancy is booked nights divided by available nights. If your property is available 365 nights a year and booked for 237 nights, occupancy is 65%. If you block 30 nights for your own use or for maintenance, your available nights are 335, and the same 237 booked nights would be about 71% occupancy of available nights. Be consistent. In this course, occupancy is calculated on 365 available nights unless stated otherwise, and blocked personal-use nights are treated as unbooked nights, because they earn nothing.

### How to Set a Realistic Nightly Rate

Your nightly rate is not what you wish the property were worth. It is what guests in your market will pay for a property like yours, at a given time of year, compared with the alternatives they can see on the same platform. To find it, look at comparable listings — same neighborhood, same size, same sleep capacity, similar quality — and note their rates for the same dates you plan to be available. Look at weekday and weekend rates separately, and at high-season and low-season rates separately. A rate that is right in June may be far too high in January.

Three common pricing mistakes: pricing from your costs instead of from the market (guests do not care what your mortgage is); pricing from the most expensive comparable you can find instead of the typical one; and setting one rate for the whole year and never changing it. The market moves by season, by day of the week, and by local events. Your price should move with it. Module 7 covers how to do that without spending your life adjusting prices.

For the worked examples below, the sample property's base nightly rate is $175. That figure is an assumption for teaching, chosen because it sits in the middle of the range for an ordinary two-bedroom condo in a mid-sized city. Your rate will be different. The method is what matters.

### Worked Example A — The Sample Property at 65% Occupancy

Assumptions: nightly rate $175; 365 available nights; 65% occupancy; cleaning fee $95 per stay; average stay 3.2 nights; platform host fee 3% of nightly rent.

**Booked nights:** 365 × 65% = 237.25, rounded to 237 nights.
**Gross nightly rent:** 237 × $175 = $41,475.
**Number of stays:** 237 ÷ 3.2 = about 74 stays.
**Cleaning fees collected:** 74 × $95 = $7,030.
**Total gross income:** $41,475 + $7,030 = $48,505.

**Expenses for the year:**

| Expense | Calculation | Annual amount |
|---|---|---|
| Mortgage, property tax, and insurance | $1,450 × 12 | $17,400 |
| Utilities and internet | $260 × 12 | $3,120 |
| Cleaning (professional, per turnover) | 74 stays × $85 | $6,290 |
| Laundry | 74 stays × $15 | $1,110 |
| Supplies and restocking | $150 × 12 | $1,800 |
| Platform host fee (3% of nightly rent) | 3% × $41,475 | $1,244 |
| Maintenance and replacement reserve | $200 × 12 | $2,400 |
| Software and miscellaneous | $60 × 12 | $720 |
| **Total expenses** | | **$34,084** |

**Net operating result:** $48,505 − $34,084 = **$14,421 per year**, or about **$1,202 per month**, before income tax and before any mortgage principal is considered (part of the $1,450 monthly payment is principal, which builds equity, but this course treats the full payment as a cost to keep the cash picture honest).

Note what the cleaning fee does in this example. The guest pays $7,030 in cleaning fees and the host pays $6,290 for cleaning plus $1,110 for laundry — a total cleaning cost of $7,400 against $7,030 collected. The cleaning fee does not quite cover the full cleaning cost, which is common. Do not treat the cleaning fee as profit. Treat it as a partial contribution to a real cost, and check your own numbers: if your cleaner charges more than your cleaning fee collects, you are subsidizing every turnover.

Also note the single largest cost: the mortgage, tax, and insurance at $17,400 a year. That is why the property decision matters more than any pricing trick. A property with a high fixed cost needs high occupancy and a high rate to work. A property with a low fixed cost — a home you own outright, for example — can be profitable at much lower occupancy. Run your own fixed costs through the same table.

### Worked Example B — The Same Property at 80% Occupancy

Same assumptions, except occupancy is 80%.

**Booked nights:** 365 × 80% = 292 nights.
**Gross nightly rent:** 292 × $175 = $51,100.
**Number of stays:** 292 ÷ 3.2 = about 91 stays.
**Cleaning fees collected:** 91 × $95 = $8,645.
**Total gross income:** $51,100 + $8,645 = $59,745.

**Expenses for the year:**

| Expense | Calculation | Annual amount |
|---|---|---|
| Mortgage, property tax, and insurance | $1,450 × 12 | $17,400 |
| Utilities and internet | $260 × 12 | $3,120 |
| Cleaning (professional, per turnover) | 91 stays × $85 | $7,735 |
| Laundry | 91 stays × $15 | $1,365 |
| Supplies and restocking | $150 × 12 | $1,800 |
| Platform host fee (3% of nightly rent) | 3% × $51,100 | $1,533 |
| Maintenance and replacement reserve | $200 × 12 | $2,400 |
| Software and miscellaneous | $60 × 12 | $720 |
| **Total expenses** | | **$36,073** |

**Net operating result:** $59,745 − $36,073 = **$23,672 per year**, or about **$1,973 per month**, before income tax.

The difference between 65% and 80% occupancy is $9,251 a year in net profit in this example — even though expenses also rise, because more stays mean more cleaning. That is the leverage of occupancy: your fixed costs stay the same, so each additional booked night contributes most of its rate toward profit, after cleaning and the platform fee. It is also why the work in Modules 5 to 9 matters so much. Good photos, fair pricing, fast replies, and clean turnovers are not cosmetic. They are the difference between 65% and 80%.

### Worked Example C — A Smaller Property at Lower Occupancy

To show that the method works at a different scale, consider a one-bedroom apartment: nightly rate $140, 55% occupancy, cleaning fee $75, average stay 2.8 nights, monthly mortgage, tax, and insurance $950, utilities and internet $180, cleaning $65 per turnover, laundry $12, supplies $100 a month, platform fee 3%, maintenance reserve $120 a month, software $40 a month.

Booked nights: 365 × 55% = 201 nights (rounded). Gross nightly rent: 201 × $140 = $28,140. Stays: 201 ÷ 2.8 = about 72 stays. Cleaning fees collected: 72 × $75 = $5,400. Total gross: $33,540.

Expenses: mortgage etc. $11,400; utilities $2,160; cleaning $4,680; laundry $864; supplies $1,200; platform fee $844; maintenance $1,440; software $480. Total: $23,068. Net: $33,540 − $23,068 = **$10,472 per year**, about $873 a month before tax.

This smaller property earns less in total than the two-bedroom sample, but it also costs less to set up and to run, and its furnishing budget would be lower. The right question is never "which property earns more?" It is "which property earns a good return on the money and time it requires, with risks I understand?" A modest property that runs smoothly beats an ambitious one that strains your finances.

### The Break-Even Occupancy

Every host should know the occupancy at which the property exactly covers its costs. You can find it with the calculator, but the logic is simple: fixed annual costs divided by the contribution each booked night makes after its variable costs.

For the sample property at $175 a night: fixed annual costs (mortgage, utilities, supplies, maintenance, software) are $17,400 + $3,120 + $1,800 + $2,400 + $720 = $25,440. Each booked night brings $175 in rent, minus the 3% platform fee ($5.25), minus the cleaning and laundry cost per night — the per-stay cleaning and laundry cost is $100, spread over a 3.2-night stay, which is $31.25 per night — plus the cleaning fee contribution per night, $95 ÷ 3.2 = $29.69. So the net contribution per booked night is roughly $175 − $5.25 − $31.25 + $29.69 = $168.19. Break-even nights: $25,440 ÷ $168.19 = about 151 nights, or about 41% occupancy. Below 41%, the sample property loses money on an operating basis. Above it, it makes money. Your break-even will differ, but knowing it changes how you think about pricing: a discount that fills a night above break-even is worth taking; a discount that fills a night below your variable cost is not.

Do not confuse break-even with success. Break-even is survival. A property that sits at break-even all year pays its bills and nothing else, and it has not repaid its furnishing cost. Include the furnishing cost in your thinking: at $9,500, the sample property at 65% occupancy repays furnishing in about eight months of net profit ($9,500 ÷ $1,202 per month); at 50% occupancy it would take far longer. Work out your own payback period and decide whether you are comfortable with it.

### Costs Hosts Commonly Forget

The following are left out of beginners' budgets more than any others. Check each one against your situation:

- **Your own time.** If you clean, manage, and message guests yourself, your time has value even if no money leaves your account. If you would pay a cleaner $85 and a co-host 15% of rent, those are the true costs of the work, whether you do it or hire it. Price the business as if you paid for the labor, so you know whether it works when you eventually cannot do it all yourself.
- **Replacement.** Towels stain, sheets wear, a toaster breaks, a chair leg loosens. The $200-a-month reserve in the sample is not pessimism; it is the cost of keeping a property looking like its photos a year later.
- **Vacancy between long-term and short-term use.** If you block nights for your own use, for family, or for maintenance, those nights earn nothing and still cost you the fixed monthly bills.
- **Platform fee changes and tax collection.** Platforms change their fee structures. Taxes you must collect or remit affect your effective income. Check the current position, not last year's.
- **Insurance differences.** A short-term rental policy or endorsement usually costs more than a standard homeowner policy. Include the real premium.
- **Seasonal utility swings.** Heating in winter and cooling in summer can double a utility bill. Use a full year's utility history, not one mild month.
- **Furnishing wear from higher turnover.** A sofa used by 74 different groups a year wears faster than a sofa used by one family. Budget accordingly.

### Sensitivity: What Moves the Result Most?

Change one assumption at a time in the calculator and watch the net profit move. You will find that the result is most sensitive to, in order: occupancy, nightly rate, and fixed monthly costs — especially the mortgage or rent. It is least sensitive to small items such as software subscriptions. That tells you where to spend your effort: on the listing quality and pricing that drive occupancy and rate, and on choosing a property whose fixed costs leave room for profit. Haggling over a $10-a-month tool while ignoring a $200-a-month pricing error is a poor use of attention.

### A Warning About Projections

You will see short-term rental projections online that promise high occupancy and high rates with little evidence. Treat any projection you did not build yourself with caution, especially if the person presenting it is selling you something. The honest way to forecast is the way this module teaches: start with comparable listings you can observe, use a range rather than a single number (for example, 55% to 75% occupancy, not "70%"), and run the low end of the range as your planning case. If the property only works at the top of the range, it is a speculation, not a plan.

### Module 3 — Action Steps

1. Complete the property-numbers worksheet in the workbook with your real costs and three scenarios: low, expected, and high occupancy.
2. Find your break-even occupancy and your furnishing payback period. Write both down.
3. Enter your numbers in the calculator and change occupancy by 10 points in each direction. Note how much the net profit moves.
4. Decide your minimum acceptable monthly net profit before tax. If no realistic scenario reaches it, do not proceed with this property at this price.

---

## Module 4 — Furnishing on a Budget

Furnishing is where new hosts most often overspend, and where overspending is most visible in the photos. The goal is not the most expensive furniture. It is furniture that photographs well, survives guest use, is easy to clean, and makes guests comfortable — for a total cost you decided in advance and did not exceed.

### The Principle: Durable, Cleanable, Photogenic

Every furnishing decision should pass three tests. Is it durable enough for dozens of different guests a year, including children and people who will not treat it as gently as you would? Is it easy to clean between stays — surfaces that wipe down, fabrics that wash, no fiddly details that trap dust? Does it look good in a photograph, which is how every guest will first meet it? A beautiful white sofa that stains in the first month fails the first two tests. A sturdy brown sofa that photographs like a waiting room fails the third. The sweet spot is commercial in spirit and residential in appearance: solid frames, washable covers, hard-wearing fabrics in mid-tones, and a consistent style across the property.

Consistency matters more than any single piece. A property furnished in one coherent style — the same wood tone, the same metal finish, the same cushion palette through the rooms — reads as intentional and cared for. A property furnished from whatever was on sale reads as an afterthought, and guests notice. Choose a palette before you buy anything: two main neutrals, one accent color, one metal finish, one wood tone. Write them down and carry the list when you shop.

### The Sample Furnishing Budget: $9,500 for a Two-Bedroom Property

The table below is the sample budget for the two-bedroom property used throughout this course. It is a worked example, not a prescription. Your property may need more or less, but the structure — a line for every room and every category, with a total you hold yourself to — is the method.

| Item | Budget |
|---|---|
| Primary bedroom: bed frame, mattress, bedding, bedside tables, lamps | $1,800 |
| Second bedroom: bed frame, mattress, bedding, bedside tables, lamps | $1,400 |
| Living room: sofa, armchair, coffee table, TV and stand, lamps | $1,900 |
| Dining: table and four chairs | $600 |
| Kitchen: cookware, dinnerware, glasses, cutlery, small appliances, basics | $700 |
| Bathroom: towels, bath mat, shower curtain, mirror, storage | $350 |
| Linens and spares: two full sets per bed, extra towels | $600 |
| Decor, art, cushions, throws, plants (artificial where sensible) | $600 |
| Smart lock, Wi-Fi, small electronics, chargers | $400 |
| Cleaning supplies, vacuum, iron, first stock of consumables | $350 |
| Contingency (10% of the above) | $800 |
| **Total** | **$9,500** |

Three things to notice. First, the mattress and the sofa are the two largest single items, and rightly so: guests judge a stay by how they sleep and where they sit. Do not save money on the mattress. A good mattress in a mid-price range, with a washable protector, is one of the best investments in the whole property. Second, linens and spares have their own line, because a host without a spare set cannot turn a property over when laundry is delayed. Third, the contingency is real money, not a rounding error. You will forget something, break something, or find that a piece does not fit. The contingency is for that.

### Where to Spend and Where to Save

**Spend on:** the mattress and pillows; the sofa frame and cushions; blackout curtains or good blinds in bedrooms; a reliable smart lock; good lighting (warm, bright, layered — a dark property photographs badly and feels unwelcoming); and the kitchen basics guests actually use, such as a decent set of pans, sharp knives, and enough plates and glasses for the maximum number of guests.

**Save on:** decorative objects, which can be simple and few; art, which can be inexpensive prints in matching frames; and anything guests will not touch or notice. A $400 vase does not earn a better review than a $40 one. Save also by buying floor models, good secondhand solid-wood furniture, and end-of-line bedding — provided each piece passes the durability and cleanability tests and fits your palette. Do not save by buying the cheapest mattress, the cheapest towels, or the cheapest cleaning equipment. Guests feel the first two and your cleaner will curse the third.

**Do not buy yet:** anything you have not measured for, anything that does not fit through the door or up the stairs, and anything for a property whose rules you have not yet confirmed under Module 2. Measure every room, every doorway, and every stair turn before you order. Photograph the measurements and keep them with you when you shop.

### The Guest's First Hour — Furnish for It

Think about the first hour of a guest's stay, because that is when they decide whether the property matches its photos. They arrive, they find the key or the code, they put down their bags, they look for the Wi-Fi password, they open the fridge, they use the bathroom, they sit down. Furnish for that hour: a clear place to put luggage, hooks or a rail for coats, a full-length mirror, the Wi-Fi details visible without searching, a kettle and mugs within reach, a clean bathroom with fresh towels and a spare toilet roll visible, and a bed that is made properly with a spare blanket in the room. Small, obvious comforts in the first hour prevent a surprising number of complaints later.

Also furnish for the stay as a whole. Guests need enough seating for everyone the property sleeps, enough dining seats for everyone, enough plates and cutlery for a full meal without washing up halfway through, enough towels for a stay of several days, and storage space that is actually empty — not filled with your belongings. Clear every cupboard and drawer you do not need for hosting. Guests should not have to move your things to use the property.

### Safety and Practical Details

Fit smoke detectors and carbon monoxide detectors where your local rules and your insurer require them, and test them before the first guest. Provide a fire extinguisher in the kitchen if required or sensible, and a simple emergency information sheet: the property address, the local emergency number, the location of the fuse box and water shut-off, and your contact number. Keep a first-aid kit in an obvious place. Check that windows open and close, that doors lock properly, and that there are no trip hazards, loose rugs, or broken steps. These are not optional extras. They are part of hosting responsibly, and they are part of what a good review means when a guest writes that they felt safe and looked after.

Child safety deserves a thought even if you do not market to families: secure heavy furniture to the wall where sensible, cover accessible sockets if you provide a cot, and keep cleaning products out of reach. If you provide a cot or high chair, buy it new, check it meets current safety standards, and inspect it between stays.

### The Furnishing Order

Buy in this order: beds and mattresses first, because they take longest to deliver and matter most; then the sofa and dining set; then kitchen and bathroom essentials; then linens; then lighting and window coverings; then decor and the small things. Photograph each room when it is finished and compare it with your listing photos plan in Module 5. If a room does not photograph well, fix the lighting and remove clutter before you buy another decorative object. A room that looks good with nothing extra in it is a well-furnished room.

Keep every receipt. You will need them for your records and for tax (Module 10), and you will need them if a guest damages something and you need to show its value. Keep a simple inventory list — item, purchase date, cost, and a photograph — in the same folder as your property records.

### Module 4 — Action Steps

1. Choose your palette: two neutrals, one accent, one metal, one wood tone. Write them down.
2. Complete the furnishing budget worksheet with your property's real requirements and a total you will not exceed without a written reason.
3. Measure every room, doorway, and stair turn before ordering anything.
4. Buy beds and mattresses first. Do not buy decor until the rooms work.
5. Keep every receipt and start the inventory list.

---

## Module 5 — Listing Copy and Photos That Convert

A guest cannot visit your property before booking. They have only your listing: your photos, your title, your description, and your reviews. Of those, photos do most of the work. Copy does the rest. This module covers both, in the order a guest experiences them.

### Photos: The Listing Is the Photos

Guests scroll through photos before they read a word. A listing with bright, honest, well-composed photos will be opened, read, and booked more often than a listing with dark, cluttered, or misleading photos at the same price. That is not a matter of taste. It is how people shop online.

**The standard to aim for:** twenty to thirty photos that show every room, the entrance, the outside, and the details that matter — the bed made properly, the bathroom clean and bright, the kitchen equipped, the dining table set, the view from the window if there is one, and the parking or entrance. Every photo should be honest: the property as a guest will find it, on an ordinary day, with nothing hidden and nothing added that will not be there when they arrive. A misleading photo earns a booking and then a bad review, and the bad review costs you far more than the booking was worth.

**How to get them:** professional photography is worth the cost for most hosts, because a photographer brings wide-angle lenses, lighting, and an eye for composition that a phone cannot match. If you photograph the property yourself, use these rules: shoot in daylight with all lights on and curtains open; shoot from the doorway or a corner so the whole room is visible; keep the camera level, not tilted; make the bed, clear the counters, hide the bins, cables, and cleaning products; and take each shot at the height a guest would see the room, not from above or below. Take more photos than you need and choose the best. The listing-photo checklist in `templates/listing-photo-checklist.md` walks through every shot, room by room.

**Order matters.** Put your best photo first — usually the living room or the primary bedroom, bright and inviting, with the bed made and the room tidy. Follow with the other main rooms, then the kitchen and bathroom, then the details and the outside. The first photo is the one guests see in search results. It is your advertisement. Make it count.

**What not to do:** do not use photos of a different property, or of the property before a renovation that has not happened; do not use heavily filtered photos that change the color of the walls or the size of the rooms; do not include photos of people, of your personal belongings, or of cluttered cupboards; and do not leave the listing with five photos when the property has eight rooms and a garden. Guests assume that what you do not show is what you are hiding.

### Listing Copy: Honest, Specific, Useful

Good listing copy does three things: it tells the guest exactly what they will get, it tells them who the property suits, and it tells them what to do next. It does not oversell, it does not use vague superlatives, and it does not hide the things a guest would want to know — the stairs, the parking, the noise, the check-in method.

**The title.** Keep it short and specific: the property type, the location or neighborhood, and one genuine highlight. "Bright two-bedroom condo, five minutes from the station, sleeps four" tells a guest more than "Stunning luxury paradise." Avoid words you cannot prove — luxury, stunning, perfect, best — and avoid promises about things outside your control, such as the weather or the neighborhood's nightlife.

**The summary.** The first two or three sentences are what guests read in search results. Use them to say who the property suits and what makes it a good choice: "A quiet, light-filled two-bedroom condo for four guests, a short walk from the station and the old town. Fast Wi-Fi, a full kitchen, and a comfortable living room for evenings in." That is enough. Save the detail for the body of the listing.

**The body.** Describe each space in plain language: the bedrooms (bed sizes, who sleeps where), the bathroom (shower or bath), the kitchen (what is provided), the living and dining areas, the outside space, the parking, the Wi-Fi speed, the heating and cooling, and the check-in method. Be specific about numbers: bed sizes, the number of seats, the distance to the station in minutes on foot. Specificity builds trust; vagueness destroys it.

**The honest limitations.** If the property is up two flights of stairs with no lift, say so. If parking is on the street and can be busy, say so. If the street is lively on a Friday night, say so. Guests who book knowing the limitations rarely complain about them. Guests who discover them on arrival almost always do. Honesty in the listing is not a cost. It is a filter that brings you guests who will be happy.

**The house rules.** State the rules plainly in the listing: maximum occupancy, no smoking, no parties, quiet hours, pet policy, check-in and check-out times, and any additional charges. Keep the rules reasonable and enforceable. A list of twenty rules reads as hostile. A short list of the rules that genuinely matter reads as professional. The full house manual belongs in the property, not in the listing.

**The neighborhood.** A short paragraph about the area helps guests imagine their stay: the nearest shop, the nearest station, a good café, a park, a walk. Keep it factual and current. Do not describe businesses that have closed or distances you have not checked.

Use the listing-copy worksheet in the workbook to draft your title, summary, body, and rules before you type them into the platform. Write them, leave them for a day, read them as a guest, and then publish. A listing is easy to change later, but the first version is the one your first guests will judge.

### Pricing in the Listing

The nightly rate guests see is the rate for the dates they search, before cleaning fees and taxes. Be aware that platforms show the total price differently, and that a low nightly rate with a high cleaning fee can look cheap in search and expensive at checkout, which frustrates guests. Keep the cleaning fee close to your actual cleaning cost, as Module 3 explains, and do not use the cleaning fee to hide the real price. Guests compare total prices, and they remember feeling misled.

### Module 5 — Action Steps

1. Complete the listing-copy worksheet: title, summary, room-by-room description, honest limitations, house rules.
2. Work through the listing-photo checklist room by room. Book a photographer or plan a daylight shoot.
3. Publish the listing only when every room is photographed honestly and the copy is specific and complete.
4. Read the finished listing as a guest who has never seen the property. Would you book it? Fix whatever makes you hesitate.

---

## Module 6 — Pricing Strategy and Seasonal Adjustments

Pricing is the most powerful lever you have, and the one new hosts handle worst. They set one price, leave it alone, and then wonder why the property is empty in the low season and underpriced in the high season. Good pricing is not guessing. It is a base rate, adjusted for season, day of the week, lead time, and length of stay, reviewed regularly.

### Start with a Base Rate

Your base rate is the nightly rate for an ordinary week in an ordinary season — the rate you would charge if there were no events, no holidays, and no seasonal swing. For the sample property it is $175. Find yours from the comparable listings in Module 1, adjusted for your property's real differences: a better location or a recent renovation justifies a higher rate; a smaller space or a longer walk to the center justifies a lower one. Test the base rate in the market. If you receive many inquiries but few bookings, the rate may be too high for what the listing shows. If you are booked solid weeks ahead at the base rate, it is probably too low.

Do not set your base rate by adding a margin to your costs. Guests do not pay your costs; they pay the market rate for a property like yours. Your costs decide whether the market rate is enough. That is a different question, answered in Module 3.

### Seasonal Adjustments

Most markets have seasons. A summer beach town, a ski town, a university city, and a business district all have different patterns, but almost every market has a high season, a shoulder season, and a low season. Your pricing should reflect that.

A practical way to structure it:

- **High season** (the busiest eight to twelve weeks): base rate plus 20% to 40%. For the sample property at $175, that is $210 to $245 a night.
- **Shoulder season** (the weeks either side of high season): base rate, or base rate plus 10%. For the sample property, $175 to $193.
- **Low season** (the quietest weeks): base rate minus 15% to 30%. For the sample property, $123 to $149.

These ranges are illustrative, not market data. Your market's swing may be larger or smaller. The point is that a single rate all year leaves money on the table in high season and leaves nights empty in low season. If you are unsure of your seasons, look at comparable listings' rates across the year and at their calendars: the weeks that are booked first are your high season.

Length-of-stay pricing also matters. A guest who books seven nights costs you one turnover instead of two or three, so a weekly discount of 10% to 15% often earns you more in total than three short stays at full price, once cleaning costs are counted. A monthly discount of 25% to 40% can fill a low-season month that would otherwise sit empty, but check your local rules first: in some places a stay over 28 or 30 nights changes the legal position, the tax treatment, or the platform's terms. Verify before you offer it.

### Weekday, Weekend, and Events

In many city markets, Friday and Saturday nights earn a premium of 10% to 25% over weekdays. In business markets, the pattern may reverse: weekdays are strong and weekends are quiet. Learn your market's pattern from your own bookings and from comparable listings, and set weekday and weekend rates accordingly.

Local events — a festival, a conference, a sports fixture, a graduation — can double demand for a few nights. If you know an event is coming, raise the rate for those nights in advance, and require a minimum stay if that is normal in your market. Do not raise the rate after a guest has inquired, and do not raise it to a level that invites a bad review when the guest arrives and finds an ordinary property at an extraordinary price. Event pricing should reflect real demand, not opportunism.

### Lead Time and Last-Minute Pricing

Nights that are far in the future can be priced at your standard rate. Nights that are close and still empty are a different problem: an empty night tonight earns nothing, while a night sold at a discount earns something. A sensible approach is to reduce the rate for the next seven to fourteen nights if they are unbooked, by 10% to 20%, and to reduce it further for the next two or three nights if they remain empty — but never below your variable cost for the night (cleaning, laundry, and the platform fee), because a booking that loses money is worse than an empty night.

Conversely, do not discount nights that are already in demand. If your calendar fills six weeks ahead, your rate is too low. Raise it gradually — 5% at a time — and watch what happens to bookings. Small, regular adjustments teach you more about your market than one large change.

### Minimum Stays

A minimum stay of two or three nights is common and sensible for most properties: it reduces turnovers, reduces cleaning costs, and tends to bring guests who treat the property better. A one-night minimum fills gaps but increases your workload and your cleaning bill. A long minimum stay in the low season can leave the property empty. Adjust the minimum by season: longer in high season when demand is strong, shorter in low season when you need to fill gaps.

### Using Pricing Tools — With Judgment

Most major platforms offer a pricing tool that suggests a nightly rate based on demand, season, and comparable listings. These tools are useful as a starting point and as a way to automate small adjustments, but they are not a substitute for your judgment. They do not know your property's fixed costs, your break-even occupancy, or your local rules. They may suggest a rate that fills nights at a loss. Use them if you wish, but set a minimum rate — your floor — below which the tool may not price, and review the suggestions regularly. Your floor should be above your variable cost per night and, in normal seasons, above the rate that keeps you on track for your break-even occupancy. The pricing worksheet in the workbook helps you set that floor.

### Reviewing Your Pricing

Set a regular rhythm: a quick check weekly (are the next two weeks priced sensibly?), a fuller review monthly (how did last month's occupancy and average rate compare with your plan?), and a seasonal review before each season (are the seasonal rates set, are the event dates covered, are the minimum stays right?). Keep a simple record: month, nights available, nights booked, occupancy, average nightly rate, gross rent, and net result. Over a year, that record becomes the most valuable pricing data you own, because it is about your property, not someone else's.

### Module 6 — Action Steps

1. Set your base rate, your seasonal rates, your weekday and weekend rates, and your pricing floor using the pricing worksheet.
2. Set your weekly and monthly discounts and your minimum stay for each season.
3. Check your local rules before offering any stay over 28 nights.
4. Put a weekly pricing check and a monthly review in your calendar.

---

## Module 7 — Guest Communication from Inquiry to Review

Guests judge a host as much by communication as by the property. Fast, warm, clear, and consistent messages prevent most problems before they happen. Slow, vague, or inconsistent messages create problems that no amount of cleaning can fix. This module covers the whole guest journey, and the message templates in `templates/guest-messaging-templates.md` give you the words to use.

### The Principle: Answer Quickly, Say What Happens Next

Most guests message several hosts at once and book the one who replies first with a clear, helpful answer. Aim to reply to inquiries within an hour during the day, and set up an automated reply for the night that acknowledges the message and says when you will respond. Speed matters, but so does completeness: a fast reply that does not answer the guest's question is not helpful. Read the inquiry properly. If the guest asks whether the property suits a toddler, whether parking is included, or whether a late check-in is possible, answer that question directly before you add anything else.

Every message should tell the guest what happens next. "Thank you for your inquiry" is not enough. "Thank you — the property is available for those dates, the total is $X including the cleaning fee, and you can book through the platform link. Check-in is from 3 p.m. and I will send the access code the morning of your arrival" is a message that moves a guest toward booking.

### The Guest Journey

**Inquiry.** The guest asks a question or requests dates. Reply promptly, confirm availability, give the total price including the cleaning fee, answer the specific question, and invite the booking. Do not move the conversation off the platform, do not offer a discount in private messages that contradicts your listing, and do not ask for personal information the platform does not require. Keep all booking communication on the platform, where it is recorded and where the platform's protections apply.

**Booking confirmation.** As soon as a booking is confirmed, send a short welcome message: thank the guest, confirm the dates and the number of guests, confirm the check-in time and method, and tell them what you will send before arrival and when. This message sets the tone. Warm, professional, and organized is the tone you want.

**Before arrival.** One to two days before check-in, send the practical information: the address, the access code or key instructions, the parking details, the Wi-Fi password, and anything the guest needs to know about the entrance. Send it early enough that the guest can read it before they travel, not when they are standing outside in the rain. If your check-in is self-check-in with a smart lock, make the instructions simple enough to follow on a phone in the dark. Test them yourself, at night, as a guest would.

**Check-in day.** On the morning of arrival, send a short message confirming that the property is ready and repeating the access instructions. Do not overload the guest with information at this point. They need to get in, put their bags down, and settle. The house manual is in the property for the rest.

**During the stay.** Be reachable, but do not intrude. A brief message on the first evening — "I hope you have settled in well; please let me know if you need anything" — is welcome. After that, respond promptly when the guest contacts you, and do not message them without a reason. If something in the property needs attention, tell the guest before they discover it, and tell them what you are doing about it. Honesty during a stay prevents most bad reviews.

**Check-out.** The day before check-out, send a short message reminding the guest of the check-out time and the few things you ask them to do: strip the beds or leave the towels in the bath, take out the rubbish, lock the door, and leave the keys where you asked. Keep the list short — three or four items, not a page of chores. Guests who are asked to do a reasonable amount leave the property in a reasonable state. Guests who are handed a long list of chores write about it in their review.

**Review request.** After check-out, thank the guest and ask for a review, and leave a review for the guest in return. Keep it simple and genuine: "Thank you for staying. I hope you enjoyed your visit. If you have a moment, a review would mean a lot — and I have left one for you too." Do not offer anything in exchange for a review, and do not ask for a five-star review directly. Platforms prohibit incentivized reviews, and guests can tell when they are being managed. A good review is earned by the stay, and asked for politely once.

### Handling Questions and Special Requests

Guests will ask for early check-in, late check-out, extra guests, a cot, a pet, a longer stay, or a discount. Have a policy for each before you are asked, and answer consistently. Early check-in is possible only when the property is ready — say so plainly, and offer luggage storage or a suggestion for the wait if you cannot accommodate it. Extra guests above the property's capacity should be declined politely, with the reason: the property sleeps four, and the insurance and local rules are set for four. A discount request can be answered with a weekly or monthly discount if you offer one, or declined politely if you do not. Consistency is what matters. A guest who is told one thing and then sees another guest receive something different will feel unfairly treated, even if the difference was reasonable.

### Tone and Language

Write as you would speak to a welcome guest: warm, clear, and professional. Use the guest's name. Use short sentences. Avoid slang, avoid jokes that could be misunderstood, and avoid any language that could be read as discriminatory. Be careful with automated messages: they save time, but they should read as if a person wrote them, and they should be accurate for the specific booking. A message that says "your check-in is at 3 p.m." when the guest has arranged a 5 p.m. check-in is worse than no message at all. Review your automated messages regularly and update them when anything changes.

If you host guests who speak another language, keep your messages simple and use the platform's translation where available. Simple sentences translate better than complex ones, and a clear message in plain language is better than a clever one that is misunderstood.

### When Communication Goes Wrong

Sometimes a guest is unhappy, confused, or angry. The principles are the same as in any service situation: reply quickly, acknowledge the problem without arguing about whose fault it is, apologize for the inconvenience, say what you will do and by when, and then do it. "I am sorry the heating is not working. I have called the engineer and they will be there within two hours. In the meantime, there are extra blankets in the bedroom cupboard" is a message that turns a problem into evidence that you are a good host. A slow reply, a defensive reply, or no reply turns a small problem into a bad review and a platform dispute. Module 9 covers difficult situations in more detail.

### Module 7 — Action Steps

1. Adapt the guest-messaging templates to your property: fill in the real times, codes, and details, and remove anything that does not apply.
2. Set up your booking-confirmation, pre-arrival, and check-out messages, and test them by reading them as a guest.
3. Decide your policy on early check-in, late check-out, extra guests, pets, and discounts — and write it down.
4. Set a personal standard for reply time and keep to it.

---

## Module 8 — Cleaning and Turnover Systems

Cleaning is the single most important operational system in short-term rental. Guests forgive a dated sofa. They do not forgive a dirty bathroom, a stained sheet, or a floor that was clearly not cleaned. Your cleaning system is your reputation, and it must work every time, including when you are tired, when the last guest left late, and when the next guest arrives early.

### The Standard: Hotel Clean, Every Time

The standard is simple to state and demanding to meet: every surface cleaned, every linen fresh, every towel fresh, every bin emptied, every supply restocked, and the property inspected as a guest would inspect it, before the next guest arrives. The cleaning and turnover SOP in `templates/cleaning-turnover-sop.md` sets out the room-by-room standard. Use it. Do not rely on memory, and do not let a cleaner rely on memory either. A written checklist that is followed every time beats a good intention that is followed most of the time.

### Self-Cleaning Versus a Professional Cleaner

Many hosts clean the property themselves at first, and that is a good way to learn what the work involves. It is also the fastest way to learn whether you want to keep doing it. A full turnover of a two-bedroom property — cleaning, laundry, restocking, and inspection — commonly takes two to four hours, depending on the state the guests left it in. If you host 74 stays a year, that is 150 to 300 hours a year of cleaning. Be honest about whether you will sustain that, and at what cost to your time and your willingness to host.

A professional cleaner costs money — $85 a turnover in the sample property — but brings reliability, speed, and a standard you can hold them to. If you hire a cleaner, treat them as a partner: pay fairly and on time, provide the cleaning supplies and the checklist, give them enough time between check-out and check-in, and inspect their work regularly. A cleaner who is rushed, underpaid, or given no clear standard will not deliver a hotel clean, and you will be the one who reads about it in the reviews.

Whether you clean yourself or hire someone, have a backup. Cleaners get sick, go on holiday, and have emergencies. Know who your second option is before you need them. A turnover with no cleaner and a guest arriving in three hours is a crisis that a backup plan prevents.

### The Turnover Workflow

A reliable turnover follows the same order every time:

1. **Check-out inspection.** As soon as the guest leaves, walk through the property and note any damage, missing items, or excessive mess. Photograph anything that is damaged or missing. This is the moment to catch a problem, not after the next guest has arrived.
2. **Strip and start laundry.** Remove all used linen and towels, start the wash, and put fresh linen on the beds. If laundry cannot be finished before the next check-in, use your spare set — this is why Module 4 budgets for two full sets per bed.
3. **Clean room by room.** Follow the SOP: kitchen first or bathroom first, depending on your cleaner's preference, but the same order every time so nothing is missed. Clean inside the fridge and the microwave, not just the surfaces. Check under the beds and behind the doors.
4. **Restock.** Replace toilet paper, soap, shampoo, tea, coffee, and any other consumables to the standard level. Check the supplies cupboard and note anything running low so it can be reordered before it runs out.
5. **Inspect as a guest.** Walk through the property as if you have just arrived: the entrance, the lights, the Wi-Fi, the heating, the shower, the bed, the towels, the kitchen. Sit on the sofa. Look in the mirrors. Open the cupboards a guest will open. If something is not right, fix it now.
6. **Photograph and reset.** Take a quick photograph of each room after cleaning — it protects you if a guest later claims the property was not clean, and it helps you spot a decline in standards over time. Set the heating or cooling to a comfortable level, lock up, and confirm to the host (or to yourself) that the property is ready.

Keep the gap between check-out and check-in realistic. A 10 a.m. check-out and a 3 p.m. check-in gives five hours, which is enough for a thorough turnover of a two-bedroom property in most cases. A shorter gap invites rushed cleaning. If you offer early check-in, confirm that the property is actually ready before you agree to it.

### Linen, Laundry, and Supplies

Linen is a system, not a purchase. You need at least two full sets per bed: one on the bed, one clean and ready. You need enough towels for the maximum number of guests for the length of the longest stay you accept, plus spares. You need a laundry routine that works whether you wash on site or use a laundry service: dirty linen out, clean linen in, no pile of unwashed linen waiting for the next turnover. White linen is easier to keep looking clean and easier to bleach or replace than colored linen, and guests associate white linen with cleanliness. If you use white, keep a stain remover on hand and replace stained items promptly rather than hoping the next guest will not notice. They will.

Supplies should be standardized: the same soap, shampoo, toilet paper, tea, coffee, and cleaning products every time, bought in bulk where it makes sense, and stored in a locked cupboard or a separate storage space that guests do not use. Keep a simple stock list and check it at every turnover. Running out of toilet paper is a small failure that feels large to a guest who discovers it at midnight.

### Dealing with Mess and Wear

Some guests leave a property in a poor state. That is part of hosting. Your turnover system should be able to handle it without drama: extra time built into the schedule, a stain remover and a spare set of linen, and a clear policy on when to charge a guest for excessive cleaning or damage through the platform's process. Do not charge a guest for ordinary use — a few extra towels in the wash, a kitchen that needs a normal clean — but do document and claim for damage or for cleaning that goes clearly beyond normal use, following the platform's rules and time limits. Photographs taken at check-out are your evidence. Keep them.

Wear is different from damage. A carpet that is worn after two years of hosting is not a guest's fault; it is the cost of running the business, and it is what the maintenance reserve in Module 3 is for. Replace worn items before guests start mentioning them in reviews. A property that looks tired earns tired reviews.

### Module 8 — Action Steps

1. Adopt the cleaning and turnover SOP and adapt it to your property room by room.
2. Decide whether you will clean yourself or hire a cleaner, and name your backup.
3. Buy your spare linen sets and set up your supplies cupboard and stock list.
4. Do a full practice turnover before your first guest, timed, and fix anything that takes too long or is missed.

---

## Module 9 — Handling Problems, Damage, and Difficult Guests

Problems are not a sign that hosting has failed. They are part of hosting. A pipe leaks, a guest locks themselves out, a neighbor complains about noise, a guest damages a chair, a booking is cancelled at the last minute. What matters is not whether problems happen, but how quickly and calmly you respond, and whether you have a plan before the problem arrives.

### The First Rule: Respond, Do Not React

When a guest reports a problem, reply quickly, acknowledge it, and say what you will do. Do not argue about whose fault it is in the first message. Do not ignore the message and hope it goes away. Do not promise something you cannot deliver. A calm, prompt, practical reply — "I am sorry this has happened. I am doing X now and it will be fixed by Y" — is the single most effective thing you can do in almost every situation. Most guests are reasonable people who want the problem fixed, not a fight. Give them the fix.

Keep all communication about a problem on the platform, in writing. That protects both you and the guest, and it gives the platform a clear record if a dispute arises later. Do not move a dispute to a private phone call or a personal email, and do not agree to a refund or a payment outside the platform.

### Common Problems and How to Handle Them

**The guest cannot get in.** This is the most stressful problem for a guest, and the most avoidable. Test your access instructions regularly, keep the smart lock batteries fresh, and have a backup: a lockbox with a key, a neighbor or co-host who can help, or a clear instruction for what to do if the code does not work. If a guest is locked out, reply immediately, stay on the phone or in messages with them until they are inside, and apologize. A guest who is locked out for an hour will remember it for the whole stay unless you handle it exceptionally well.

**Something is broken.** Heating, hot water, Wi-Fi, a washing machine, a television — any of these can fail during a stay. Have the number of a reliable plumber, electrician, and handyman saved before you need them, and know where the fuse box, water shut-off, and boiler controls are so you can talk a guest through a simple reset. If a repair cannot be done during the stay, offer a practical alternative: extra heaters, a kettle if the cooker fails, or a partial remedy that is honest about what you can and cannot do. Do not leave a guest without hot water or heating and no plan.

**Noise complaints.** If a neighbor complains, or a guest complains about noise from outside, take it seriously. Contact the guest politely, remind them of the quiet hours in your house rules, and ask them to keep the volume down. Do not accuse the guest of hosting a party unless you have evidence. If the noise continues and the guest is breaking the house rules, follow the platform's process for the situation, and document what happened. Preventing noise is better than handling it: state quiet hours clearly in the listing and the house manual, set a maximum occupancy, and do not accept bookings that are likely to cause problems — for example, a one-night booking for a large group on a Friday night in a quiet residential building.

**Damage.** Inspect at every check-out, photograph any damage, and keep the receipts for the item. If the damage is minor — a broken glass, a stained towel — absorb it as a cost of hosting and move on. If the damage is significant — a broken chair, a stained mattress, a damaged appliance — report it through the platform's damage process promptly, within the platform's time limit, with photographs and evidence of the item's value. Be reasonable and factual in your claim. A claim for a fair amount, well documented, is far more likely to succeed than an inflated claim made in anger. Remember that the platform's host protection is not insurance and does not cover everything. Your own insurance, checked in Module 2, is the backstop.

**A difficult guest.** Some guests are demanding, rude, or unreasonable. Stay polite and professional, keep your messages short and factual, and do not engage in an argument. Offer what you can offer within your policies, and decline what you cannot offer, politely and once. If a guest threatens you, harasses you, or behaves in a way that makes you feel unsafe, contact the platform's support and follow their guidance, and if necessary contact the local authorities. Your safety matters more than a booking. After the stay, leave an honest, factual review for the guest — other hosts rely on those reviews — and do not retaliate in a way that damages your own listing.

**A bad review.** It will happen. A guest will leave a review you think is unfair, or a review that describes a real problem you have since fixed. Do not reply in anger. If the platform allows a public response, write a short, calm, factual reply that acknowledges the guest's experience and says what you have done since: "Thank you for your feedback. We are sorry the Wi-Fi was unreliable during your stay. We have since replaced the router and the connection is now stable." Future guests read your response more than they read the complaint. A gracious response to a bad review can earn you more bookings than a defensive one ever will. If a review breaks the platform's review policy — for example, it contains discriminatory language or describes something that did not happen — you can ask the platform to review it, but do not expect every review you dislike to be removed.

**Cancellations.** Guests cancel, and sometimes you will need to cancel. Understand your cancellation policy before you choose it: a strict policy protects your income but may put off guests; a flexible policy attracts bookings but leaves you exposed to last-minute cancellations. If a guest cancels, follow the platform's process and do not try to re-book the guest privately. If you must cancel — because of a maintenance emergency or a rules issue — contact the guest and the platform promptly, apologize, and help the guest find an alternative if you can. Cancellations by the host damage your ranking and your reputation, so avoid them wherever possible by keeping the property maintained and the calendar accurate.

### Protecting Yourself

Three habits protect a host more than any other: keep all booking communication on the platform; photograph the property at every turnover; and keep records of every incident, with dates, messages, and photographs. Those records are what you need if a dispute arises, and they are what your insurer will ask for if you make a claim. A host who can show a clear record is a host who is taken seriously.

### Module 9 — Action Steps

1. Save the numbers of a plumber, electrician, and handyman, and write down where the fuse box and water shut-off are.
2. Decide your policy on damage claims: what you will absorb, what you will claim, and what evidence you will keep.
3. Write your calm first-response message for a problem — the words you will use when you are under pressure — and keep it where you can find it.
4. Check your cancellation policy and make sure you understand it.

---

## Module 10 — Taxes and Record-Keeping Basics

This module gives you the basics of keeping records and understanding that short-term rental income is usually taxable. It is education only, not tax advice. Tax law varies by country, state, and city, and it changes. For advice about your specific tax position, speak to a qualified tax professional in your jurisdiction before you file a return or make a decision based on this module.

### The Principle: If You Cannot Prove It, You Cannot Claim It

Good record-keeping is not bureaucratic. It is the difference between a tax return you can defend and a tax return you cannot, between a damage claim you can prove and one you cannot, and between knowing whether your property made money and guessing. Keep records from the first booking, not from the end of the first year. It is far easier to record things as they happen than to reconstruct them months later.

### What to Keep

Keep the following, in one folder — digital or paper — for each tax year:

- **Income:** every booking's nightly rent, cleaning fee, and any other fees, with the dates and the guest's name as recorded by the platform; any income received outside the platform (there should be none if you keep all bookings on the platform); and any refunds or adjustments.
- **Platform statements:** the monthly or annual statements from each platform you use, showing gross bookings, fees deducted, and amounts paid to you.
- **Expenses:** every receipt and invoice, with the date, the supplier, the amount, and what it was for — mortgage interest (not the full mortgage payment, in many jurisdictions), property tax, insurance, utilities, internet, cleaning, laundry, supplies, maintenance, repairs, furnishing, photography, software, and professional fees. Keep the receipt, not just a note of the amount.
- **Furnishing and capital items:** the purchase date, cost, and a photograph of each significant item, so you can show what it cost and when you bought it if a guest damages it or if your tax adviser asks.
- **Mileage and travel:** if you travel to the property for hosting purposes, keep a log of the date, the purpose, and the distance. Your tax adviser can tell you whether and how this is deductible in your jurisdiction.
- **Rules and permits:** your registration, license, or permit, any written permissions from your HOA or landlord, and your insurance confirmations, as collected in Module 2.
- **Occupancy and personal use:** a record of which nights were booked, which were blocked for your own use, and which were vacant. The distinction matters for tax in many jurisdictions, because personal-use nights are often treated differently from rental nights.

Keep these records for as long as your tax authority requires — commonly several years after the tax year they relate to. Check the requirement in your jurisdiction and do not delete records early.

### Understanding the Tax Picture in General Terms

In most jurisdictions, short-term rental income is taxable income and must be declared, whether it is paid through a platform or directly. In many places you must also collect and remit occupancy, lodging, or tourist taxes on the nightly rate, as discussed in Module 2. Some platforms collect and remit those taxes on your behalf in some locations; in others you must do it yourself. Check the position for your location and do not assume.

Expenses that are genuinely incurred to run the rental may be deductible, subject to the rules in your jurisdiction — but the rules are specific, and they differ on questions such as: whether mortgage interest is deductible and how much; how furnishing is treated (as an immediate expense or depreciated over several years); how personal-use nights affect the deduction; and whether losses can be offset against other income. Those are questions for a tax professional who knows your jurisdiction and your circumstances. Do not take a deduction because you read online that someone else took it.

If you earn income in a place where you do not live, or if you host through a company or a partnership, the position may be more complex. Get advice before you structure anything.

### A Simple Monthly Routine

At the end of each month, spend thirty minutes on the monthly profit tracker in the workbook:

1. Record the month's booked nights, occupancy, gross rent, cleaning fees, and platform fees from your platform statement.
2. Record the month's expenses from your receipts: mortgage, utilities, cleaning, laundry, supplies, maintenance, and anything else.
3. Calculate the month's net result and compare it with your Module 3 plan. If it is below plan, note why: low occupancy, a low rate, an unexpected repair, or a seasonal dip.
4. File the receipts and the platform statement in the month's folder.
5. Note anything that needs attention next month: a supply running low, a repair to book, a price to review.

That thirty minutes a month saves you hours at tax time, and it gives you the information you need to run the business well. A host who knows their monthly numbers can make good decisions. A host who does not is guessing.

### When to Get Professional Help

Get professional tax advice before your first tax return as a host, and again if any of the following apply: your income from hosting is substantial; you own the property through a company; you host in more than one jurisdiction; you have personal-use nights mixed with rental nights; or you are unsure about any deduction you plan to claim. The cost of an hour with a tax professional is small compared with the cost of a tax return that is wrong.

### Module 10 — Action Steps

1. Set up your records folder and your monthly profit tracker before your first booking.
2. Confirm, in writing, which taxes you must collect or remit and whether the platform handles any of them.
3. Keep every receipt from the first day. Do not wait until tax time.
4. Book a tax professional before your first return as a host.

---

## Module 11 — Arbitrage Versus Ownership Compared Honestly

Two different ways to host a short-term rental are often presented as if they were the same business. They are not. In ownership, you own the property and host it. In arbitrage, you lease a property from a landlord and re-rent it by the night, keeping the difference between the nightly income and the rent and costs you pay. Both can work. Both can fail. This module compares them honestly so you can choose with your eyes open.

### Ownership

**How it works.** You own the property — outright or with a mortgage — and you host it. You pay the mortgage, tax, insurance, and maintenance. You keep the nightly income after expenses. You also keep any long-term increase in the property's value, and you build equity as you pay down the mortgage.

**Advantages.** You control the property: you can renovate, furnish, and change it as you wish, subject to local rules and any HOA restrictions. You are not dependent on a landlord's permission to host. You benefit from the property's value over time. Your fixed costs are usually more stable than a lease that can be renegotiated or ended.

**Disadvantages.** You need capital to buy, or you already own a property that suits hosting. Your money is tied up in the property. You bear the maintenance and repair costs, including the large ones — a roof, a boiler, a damp problem. If the market falls or the rules change, you cannot simply walk away from the lease; you own the problem.

**When it suits.** Ownership suits a host who already owns a suitable property, or who can afford to buy one for hosting with a realistic deposit and a mortgage they can service even in the low season. It suits a host who wants a long-term asset as well as an income.

### Arbitrage

**How it works.** You lease a property from a landlord, usually on a one-year or longer lease, with the landlord's written permission to re-rent it by the night. You furnish it, list it, host it, and pay the rent, utilities, cleaning, and other costs. You keep the difference between the nightly income and your costs. You do not own the property and you do not benefit from its increase in value.

**Advantages.** You need far less capital to start: a deposit, the first month's rent, and the furnishing cost, rather than a deposit on a purchase. You can test a market or a neighborhood without buying. You can scale faster, in theory, by leasing more properties. If a property does not work, you can leave at the end of the lease, rather than selling a property.

**Disadvantages.** The landlord can refuse permission, withdraw it, or decline to renew the lease — and if they do, you lose the business and the furnishing you paid for, unless your lease protects you. Your margin is thinner, because you pay rent on top of all the hosting costs, and rent is a fixed cost that does not fall when occupancy falls. You do not control the property: you cannot renovate without permission, and you are responsible for returning it in the condition the lease requires. You are also dependent on the landlord's mortgage, insurance, and compliance: if the landlord's position changes, yours may change with it.

**The permission question.** Arbitrage is only possible with the landlord's written permission to sublet for short-term rental, in the lease itself or in a separate written agreement. A verbal "that sounds fine" is not permission. A lease that is silent on subletting is not permission. A lease that prohibits subletting is a prohibition. If you proceed without written permission, you risk eviction, a claim for damages, and the loss of your furnishing and your bookings. Get the permission in writing, before you sign the lease or spend money on furniture, and keep it with your records.

**The numbers for arbitrage.** Run the Module 3 numbers with rent instead of a mortgage. For example, a two-bedroom property leased at $1,600 a month: rent $19,200 a year, plus utilities, cleaning, and the other costs from Module 3, against the same gross income. At 65% occupancy on the sample property's income of $48,505, expenses would be roughly $19,200 (rent) + $3,120 (utilities) + $6,290 (cleaning) + $1,110 (laundry) + $1,800 (supplies) + $1,244 (platform fee) + $2,400 (maintenance reserve — though the landlord may bear some maintenance, check the lease) + $720 (software) = $35,884, for a net of about $12,621 before tax — similar to ownership in this example, but without the equity built by mortgage payments and without the long-term value of the property, and with the risk that the rent rises or the lease is not renewed. At 50% occupancy, the same property would earn far less, and the rent would still be due in full. Arbitrage is more sensitive to occupancy than ownership, because the rent cannot be reduced when bookings fall.

### The Honest Comparison

| Factor | Ownership | Arbitrage |
|---|---|---|
| Capital needed to start | High (deposit or existing property) | Lower (deposit, first rent, furnishing) |
| Monthly fixed cost | Mortgage, tax, insurance | Rent, plus utilities and hosting costs |
| Control of the property | High | Limited by the lease |
| Benefit from property value | Yes | No |
| Risk if rules change | You own the property; you can switch to long-term rental | Lease may end; furnishing may be lost |
| Risk if occupancy falls | Mortgage still due, but may be lower than rent | Rent still due in full |
| Exit | Sell the property | Leave at lease end |

Neither model is right for everyone. Ownership is a longer-term commitment with a larger capital requirement and a larger potential reward. Arbitrage is a lower-capital, higher-risk way to start, whose success depends on the lease, the landlord, and sustained occupancy. If you choose arbitrage, choose a landlord who understands and supports the model, negotiate a lease that protects you — a term long enough to repay your furnishing, a clear written permission, and a clear statement of who pays for what — and run the numbers at 50% occupancy, not at 80%, before you sign.

### Module 11 — Action Steps

1. Decide which model you are in — ownership or arbitrage — and write down why.
2. If arbitrage, obtain the landlord's written permission and read the lease in full before signing or furnishing.
3. Run the Module 3 numbers for your model at 50%, 65%, and 80% occupancy. If the 50% case loses money you cannot afford, reconsider.
4. Note the lease end date and the renewal terms in your calendar if you are in arbitrage.

---

## Module 12 — Scaling to a Second Unit

A first property that runs well raises an obvious question: should you add a second? The answer is not automatically yes. A second unit doubles the income potential, but it also doubles the cleaning, the guest communication, the maintenance, and the risk. Scale because the first unit proves the model, not because the first unit is exciting.

### The Test Before You Scale

Do not consider a second unit until the first has passed all of these tests:

- **It has been running for at least six months**, including a low-season period, so you know what the quiet months look like.
- **It is profitable on the numbers in Module 3**, after all costs including your time or the cost of the help you pay for, not just on the nightly rate.
- **Its review score is consistently good**, and you know why: the cleaning is reliable, the communication is fast, and the property matches its photos.
- **Its systems work without you being involved in every detail.** The cleaner knows the standard, the messages are templated, the turnover runs on a checklist, and a problem does not require you to drop everything.
- **You have a cash reserve** that covers three months of fixed costs for both properties, plus the furnishing cost of the second unit, without borrowing.
- **The rules allow it.** Check the local rules, the HOA, and the platform position for the second property separately. Rules that allow one property do not necessarily allow two, and some places limit the number of short-term rentals one host may operate.

If any of those tests fails, fix the first unit before you add a second. A second unit does not fix a first unit that is unprofitable, poorly reviewed, or dependent on you being available at all hours. It multiplies the problem.

### What Changes with Two Units

The work changes in kind, not just in amount. With one property, you can hold the details in your head. With two, you need systems that hold them for you: a calendar that shows both properties' bookings, cleanings, and maintenance at a glance; a cleaner or a cleaning team that can cover both; a stock of linen and supplies for both; a single set of message templates adapted to each property's details; and a way to track each property's numbers separately, so you know whether the second unit is helping or hurting.

The most common scaling mistake is to treat the second property as a copy of the first without checking whether the second property's location, rules, and numbers are as good. Every property needs its own Module 1, Module 2, and Module 3. A second property in a weaker location, with higher fixed costs, or with a night cap that the first property does not have, can lose the money the first property earns. Run the numbers for the second property as if it were your first, because it is.

### Hiring Help as You Scale

At two units, most hosts need more help: a reliable cleaner for both properties, and often a co-host or a part-time manager who can answer messages, coordinate turnovers, and handle problems when you are unavailable. Budget for that help in the second property's numbers from the start, not as an afterthought. A co-host typically charges a percentage of the nightly rent — the exact figure varies by market — and a cleaner charges per turnover. Include both in your Module 3 table for the second property, and check whether the property is still profitable after them. If it is only profitable when you do all the work yourself for free, it is not a scalable business.

Choose help carefully. A cleaner or co-host who is unreliable will damage both listings, not just one. Pay fairly, give clear standards, inspect the work, and keep a backup. The systems in this course — the SOP, the templates, the checklists — are what make it possible for someone else to do the work to your standard. Without them, you are not scaling a business. You are scaling your own workload.

### Financing a Second Unit

A second unit needs furnishing, a deposit or a purchase cost, and a reserve. Do not fund it from the first property's income before the first property has repaid its own furnishing and built its reserve. Do not borrow to furnish a property whose profitability is unproven. The disciplined order is: first unit profitable and reserved; second unit funded from savings, not from debt taken on hope; second unit's numbers run at 50% occupancy before you commit. If the second unit cannot meet that test, wait. The market will still be there in six months, and you will be in a stronger position to enter it.

### Knowing When to Stop

Not every host should scale. Some hosts are happiest and most profitable with one well-run property that fits their life. Others build a small portfolio of two or three and stop. A few build larger operations, which is a different business — with staff, with formal management, and with a level of regulation and risk that this course does not cover. There is no prize for the most units. The prize is a property — or two, or three — that earns a good return, is well reviewed, complies with the rules, and does not take over your life. Decide in advance what "enough" looks like for you, and stop when you reach it.

### Module 12 — Action Steps

1. Score your first property against the six scaling tests. Write the result down.
2. If it passes, run Modules 1 to 3 in full for the second property — location, rules, and numbers — before you commit.
3. Budget for the cleaner and co-host help the second unit will need, and include those costs in its numbers.
4. Decide in advance what "enough" means for you: how many units, and why.

---

## Module 13 — Your First 90 Days: Putting It All Together

This final module brings the course together into a practical plan for your first 90 days. It is a sequence, not a suggestion: the order matters, because each step depends on the one before it.

### Days 1–14: Decide and Research

Complete Module 1's property assessment and Module 2's rules research. Obtain any required registration, license, or permit, and written confirmation from your HOA or landlord and your insurer. Run the Module 3 numbers at 50%, 65%, and 80% occupancy. Decide, in writing, whether to proceed. If the answer is yes, set your furnishing budget and your reserve, and do not exceed either without a written reason.

### Days 15–45: Set Up

Furnish the property in the order in Module 4. Fit the smart lock, test the Wi-Fi in every room, and test the heating, cooling, shower, and appliances. Do a full practice turnover, timed, using the SOP. Draft your listing copy with the workbook, photograph the property in daylight, and publish the listing only when the copy is specific and the photos are honest. Set your base rate, seasonal rates, minimum stays, and discounts. Set up your message templates and your reply-time standard.

### Days 46–90: Host, Learn, Improve

Welcome your first guests. Reply quickly, clean to the standard every time, and ask for reviews politely after each stay. Track every booking in the monthly profit tracker: nights, occupancy, average rate, gross income, expenses, and net result. After your first five stays, review what guests said — in messages and in reviews — and fix the most common complaint or suggestion first. After your first ten reviews, review your pricing: if you are booked solid, raise the rate gradually; if you have gaps, check the photos, the price, and your reply speed before you discount.

At the end of 90 days, sit down with the tracker and answer three questions: Did the property earn what the Module 3 plan said it would, and if not, why? What is the single most common thing guests praise, and the single most common thing they mention as a problem? What will you change in the next 90 days? Write the answers down. That review is the difference between a host who improves and a host who repeats the same season twice.

### The Host You Are Becoming

Short-term rental rewards the host who is organized, honest, responsive, and consistent. It does not reward the host who is clever about pricing but careless about cleaning, or the host who has beautiful photos of a property that does not match them. The work is ordinary: a clean bathroom, a made bed, a fast reply, a fair price, a property that is what the listing said it was. Done well, week after week, that ordinary work earns good reviews, and good reviews earn bookings, and bookings earn the income that makes the work worthwhile.

You now have the method, the numbers, the templates, and the checklists. Use them. Start with Module 2, not with furniture. Start with the math, not with the listing. And when you welcome your first guest, remember that they chose your property from a long list of alternatives. Make the stay worthy of that choice.

### Module 13 — Action Steps

1. Write your 90-day plan with dates: research, setup, first listing, first guests, first review.
2. Set your calendar reminders: weekly pricing check, monthly profit review, annual rules re-check.
3. Publish only when Modules 1 to 3 are complete and the property is ready to be photographed honestly.
4. After 90 days, complete the three-question review above and write down what you will change next.

---

## Final Disclaimer

This program is education only. It is not individualized legal, tax, investment, or financial advice. Short-term rental rules, permits, HOA rules, lease terms, zoning, taxes, and platform policies vary by location and change often. You must verify the rules that apply to your specific property, in writing, with the relevant local authority, your HOA or landlord, your insurer, and the platform you plan to use, before you list, furnish, or accept a booking. No income, occupancy, or profit figure in this course is guaranteed. All worked examples use stated assumptions for teaching purposes only. Your results will differ. For advice about your specific legal, tax, insurance, or financial situation, speak to a qualified professional in your jurisdiction.

*End of course.*
