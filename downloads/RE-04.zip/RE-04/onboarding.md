# Customer Onboarding Guide — The Short-Term Rental Mastery Program (RE-04)

Welcome. This guide tells you what to do first, how to use each file, and how to work through the program in about 90 days.

> **First, the important notice:** this program is education only — not individualized legal, tax, investment, or financial advice. Short-term rental rules, permits, HOA rules, lease terms, zoning, taxes, and platform policies vary by location and change often. Verify everything for your specific property, in writing, before you list, furnish, or accept a booking. No income or occupancy figure in this program is guaranteed.

## What You Received

| File | What it is | Use it for |
|---|---|---|
| `content.md` | The complete 13-module course | Read in order the first time; each module ends with action steps |
| `workbook.md` | Companion workbook | Fill in your real numbers as you work through the course |
| `templates/str-pricing-occupancy-calculator.csv` | Pricing and occupancy calculator | Enter your rate, occupancy, and costs; see gross, expenses, net, and break-even |
| `templates/guest-messaging-templates.md` | Guest message templates | Adapt with your real details; use from inquiry to review request |
| `templates/cleaning-turnover-sop.md` | Cleaning and turnover SOP | Follow at every turnover; give a copy to your cleaner |
| `templates/listing-photo-checklist.md` | Listing photo checklist | Every shot, room by room, before you publish |
| `sales-page.md` | Sales page copy | Reference only — what the program promises |
| `listing.json` | Marketplace listing data | Marketplace use |
| `cover.md` / `cover.webp` | Cover brief and cover image | Marketplace use |
| `README.md` | Index of the product's files | Orientation |

## What to Do First (Days 1–14)

1. **Read the notice at the top of `content.md`, then Module 1.** Walk your property as a guest and complete the Module 1 action steps.
2. **Do Module 2 before you spend any money.** Complete the local-regulation research checklist in the workbook. Obtain any required registration, license, or permit, and written confirmation from your HOA or landlord and your insurer. Do not furnish or list until this is done.
3. **Do Module 3 with your real numbers.** Complete the property-numbers worksheet and enter your figures in the calculator. Run low, expected, and high occupancy. Find your break-even occupancy and your furnishing payback period. Decide, in writing, whether to proceed.

## How to Use the Materials

- **Work in order the first time.** Modules 1–3 are the decision. Modules 4–8 are the setup. Modules 9–11 are the operation. Modules 12–13 are growth and your first 90 days.
- **Write in the workbook.** Print it or fill it in digitally. A workbook with your property's figures is a business plan.
- **Adapt the templates, do not just read them.** Fill in your real check-in times, access details, rates, and policies in the guest messages, the SOP, and the photo checklist before you use them.
- **Keep everything in one folder** with your property records: the completed checklists, permits, written permissions, insurance confirmations, receipts, and your monthly profit tracker.

## Suggested Schedule — First 90 Days

| Phase | Dates | Focus |
|---|---|---|
| Days 1–14 | Decide and research | Modules 1–3; permits; written confirmations; numbers decision |
| Days 15–45 | Set up | Modules 4–6; furnish; practice turnover; listing live |
| Days 46–90 | Host and improve | Modules 7–10 in use; first guests; track monthly; fix the top complaint |

After 90 days, complete the three-question review in Module 13 and write down what you will change next.

## Ongoing Rhythm

- **Weekly:** quick pricing check — are the next two weeks priced sensibly?
- **Monthly:** complete the monthly profit tracker in the workbook; file receipts and the platform statement; compare with your Module 3 plan.
- **Annually:** re-check the local rules, permits, HOA rules, and platform policies for your property, and update the research checklist.

## How to Get Support

For help with your order or the course files, email the marketplace support address with your order number and a description of the issue, and the support team will respond.

For questions about your specific legal, tax, insurance, or financial situation, speak to a qualified professional in your jurisdiction — this program is education only and cannot advise you individually.

## Quick Checklist Before Your First Guest

- [ ] Modules 1–3 complete; rules verified in writing; numbers run
- [ ] Property furnished to budget; practice turnover done
- [ ] Listing copy specific and honest; photos complete and honest
- [ ] Pricing, minimum stays, and discounts set; pricing floor set
- [ ] Guest messages adapted; cleaner and backup cleaner named
- [ ] Records folder set up; monthly profit tracker ready
