# Client Intake and Consent Form Pack

*For use by licensed beauty professionals. Adapt this pack to your services and your state board requirements, and have it reviewed by your insurer or attorney if you are unsure. Keep completed forms securely and privately. Do not leave them where other clients can see them.*

---

## Form A — Client Intake Form

**Business name:** ____________________ **Date:** __________

### Personal details

- Full name: ____________________
- Date of birth: ____________________
- Phone: ____________________
- Email: ____________________
- Emergency contact (name and phone): ____________________
- How did you hear about us? ____________________

### Treatment details

- Service booked today: ____________________
- What would you like help with today? ____________________
- What have you tried before for this, and how did it go? ____________________
- What result are you hoping for? ____________________

### Health and skin information

*Please answer honestly. This information helps your practitioner choose safe, suitable products and techniques for you. It is kept confidential.*

- Do you have any skin conditions (for example eczema, psoriasis, rosacea, acne, dermatitis)? Yes / No — details: ____________________
- Do you have any allergies (including to skincare ingredients, latex, fragrances, or adhesives)? Yes / No — details: ____________________
- Are you currently taking any medication that affects your skin, including acne medication, blood thinners, or photosensitising medication? Yes / No — details: ____________________
- Are you pregnant, breastfeeding, or trying to conceive? Yes / No
- Have you had any recent cosmetic, dermatological, or medical treatment on the area to be treated (for example peels, laser, injectables, surgery)? Yes / No — details and date: ____________________
- Do you have any cuts, broken skin, rashes, infections, or sunburn on the area to be treated today? Yes / No — details: ____________________
- Have you ever had a reaction to a beauty treatment or product? Yes / No — details: ____________________
- Anything else your practitioner should know? ____________________

**Note:** This form is general information, not a medical assessment. If you have a skin condition or a health concern, please consult a dermatologist or physician. Cosmetic treatments do not treat medical conditions.

### Skin and hair notes (practitioner to complete)

- Skin type / observations (general, non-medical description): ____________________
- Products used today: ____________________
- Patch test done? Yes / No / Not required — date and result: ____________________
- Notes for next visit: ____________________

---

## Form B — Treatment Consent Form

**Business name:** ____________________ **Date:** __________

- Client name: ____________________
- Service: ____________________
- Practitioner: ____________________

Please read each statement and initial beside it.

1. I have completed the intake form honestly and I have told my practitioner about any allergies, skin conditions, medications, and recent treatments. Initials: ____
2. My practitioner has explained the treatment to me in plain language, including what will happen, how long it will take, and what I should expect afterwards. Initials: ____
3. I understand that cosmetic treatments are not medical treatments and do not treat medical conditions. I understand that results vary from person to person and no specific result has been promised to me. Initials: ____
4. I understand that mild, temporary redness, sensitivity, or irritation can sometimes occur after a beauty treatment, and I have been told what to do if I am concerned. Initials: ____
5. I agree to follow the aftercare guidance given to me, and to contact my practitioner — or a physician if I am worried — if I have an unexpected reaction. Initials: ____
6. I consent to photographs being taken for my treatment record: Yes / No. I consent to photographs being used for marketing (social media, website): Yes / No. (Photographs will never be used for marketing without your separate, written consent.)
7. I understand the price of today's treatment is $__________ and the cancellation policy is: ____________________.

**Client signature:** ____________________ **Date:** __________

**Practitioner signature:** ____________________ **Date:** __________

---

## Form C — Aftercare Sheet (give to the client after treatment)

**Treatment:** ____________________ **Date:** __________

Thank you for visiting. Here is how to care for your skin after today's treatment:

- **Today:** Avoid heavy makeup, hot showers, saunas, steam rooms, and vigorous exercise for the rest of the day, or as advised by your practitioner.
- **Sun protection:** Use sunscreen daily and avoid prolonged sun exposure, especially in the first few days after treatment.
- **Skincare:** Use gentle products as advised. Do not start a new exfoliating or strong active product without asking your practitioner first.
- **Hands off:** Avoid touching or picking at the treated area.
- **What is normal:** Mild redness or sensitivity that settles within a day or two is common after many treatments. If you are worried, or if redness, swelling, pain, or a rash gets worse rather than better, contact your practitioner, or see a physician promptly.
- **Your next appointment:** ____________________
- **Products recommended for home use (general guidance only):** ____________________
- **Contact us:** Phone: ____________________ Email: ____________________

*If you have a skin condition or a medical concern, please consult a dermatologist or physician. This sheet is general education, not medical advice.*

---

## Form D — Patch Test Record

| Date | Client | Product tested | Area tested | Result after 24–48 hrs | Practitioner initials |
|---|---|---|---|---|---|
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |

**Patch test guidance:** Where a product or treatment carries a risk of reaction, carry out a patch test in line with the manufacturer's instructions and your state board rules, and record the result before the full treatment. Do not proceed if a reaction occurs — advise the client to seek medical advice if needed.

---

*Keep all completed forms in a secure, private place, and keep them for as long as your insurer and state board require. Never share a client's information with another person without the client's consent.*
