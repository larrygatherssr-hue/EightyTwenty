# Business Plan — [Your Business Name]

*Fill in each section in your own words. Keep it short and honest — a plan you actually use beats a long plan you never open. Review it every quarter.*

---

## 1. Business Summary

- **Business name:** ____________________
- **Owner name:** ____________________
- **Business structure:** Sole proprietor / LLC (circle one; confirm with an accountant or attorney)
- **Business address:** ____________________
- **Phone / email:** ____________________
- **Booking link:** ____________________
- **Opening date:** ____________________
- **What my business does, in one sentence:** ____________________

## 2. My Niche and Ideal Client

- **Who I serve:** ____________________
- **The problem I solve for them:** ____________________
- **The outcome they get:** ____________________
- **Why they choose me instead of a competitor:** ____________________
- **Services I will NOT offer at launch, and why:** ____________________

## 3. Services and Prices

List every launch service with its price and the time it takes. Each price must be built with the pricing formula in Module 6 (product cost + time cost + overheads share + profit margin).

| Service | Time | Price |
|---|---|---|
| | | $ |
| | | $ |
| | | $ |
| | | $ |
| | | $ |
| | | $ |

- **Add-ons offered:** ____________________
- **Retail products stocked:** ____________________
- **Discount policy:** ____________________

## 4. Business Model and Premises

- **Model chosen:** Chair / room rental / salon suite / home-based / mobile (circle one)
- **Why this model, for me, now:** ____________________
- **Monthly rent / cost:** $____________________
- **Lease or agreement length and notice period:** ____________________
- **What is included (utilities, laundry, reception, booking):** ____________________
- **Restrictions I must follow:** ____________________
- **Plan to move to a larger model, if any, and when:** ____________________

## 5. Licensing, Legal, and Insurance

*Licensing requirements vary by state and country. Verify every item with your state board of cosmetology or equivalent authority, your city or county, and your insurer. This section is a checklist, not legal advice.*

- [ ] Professional licence current and covers all menu services — licence number: __________, expiry: __________
- [ ] Salon / establishment licence required? Yes / No — status: __________
- [ ] Business registered — registration number: __________
- [ ] EIN obtained (if required): __________
- [ ] Professional liability insurance — provider: __________, policy number: __________, renewal: __________
- [ ] General liability insurance — provider: __________, renewal: __________
- [ ] Home-based / zoning / landlord rules checked — outcome: __________
- [ ] Sanitation and hygiene routine written — date: __________

## 6. Startup Costs and Funding

- **Total one-off startup costs:** $__________ (see workbook Worksheet 2)
- **Monthly running costs:** $__________
- **Cash needed to open safely (one-off + 3 months of running costs):** $__________
- **How I am funding it:** Savings $__________ | Part-time work $__________ | Other $__________
- **Amount still to save, and date it will be ready:** $__________ by __________

## 7. Financial Targets — First 12 Months

| Month | Appointments target | Revenue target | Notes |
|---|---|---|---|
| Month 1 | | $ | |
| Month 2 | | $ | |
| Month 3 | | $ | |
| Month 6 | | $ | |
| Month 12 | | $ | |

- **Monthly income I need to cover costs and pay myself:** $__________
- **Appointments per month needed to reach that income:** __________
- **Tax savings rule:** I will transfer ____% of each payment to a separate tax savings account.

## 8. Marketing Plan — How I Will Find My First 20 Clients

- **My list of 50 people who know me:** Done / In progress (date: __________)
- **Founding-client offer:** ____________________ — limit: __________ — end date: __________
- **Places where my ideal client already spends time:** ____________________
- **Social media posting rhythm:** ____ posts per week, on: ____________________
- **Referral ask:** I will ask every happy client for a referral, and thank referrers with: ____________________
- **Monthly marketing budget:** $__________

## 9. Client Experience

- **Booking:** Clients book by: ____________________
- **Deposit:** $__________ / ____% — cancellation policy: ____________________
- **What happens when a client arrives:** ____________________
- **How I rebook clients before they leave:** ____________________
- **Aftercare / follow-up message:** ____________________
- **How I handle complaints:** ____________________

## 10. 90-Day Launch Plan

- **Days 1–30 (decide and prepare):** ____________________
- **Days 31–60 (build and tell people):** ____________________
- **Days 61–90 (open and learn):** ____________________
- **Opening date:** __________
- **Day-90 review date:** __________

## 11. Goals for Year One

1. Income goal: ____________________
2. Client goal: ____________________
3. Personal goal (days worked, time off, learning): ____________________
- **Quarterly review dates:** __________ / __________ / __________ / __________

## 12. Risks and What I Will Do About Them

| Risk | What I will do |
|---|---|
| Bookings are slow in month one | |
| A client cancels at the last minute | |
| My costs rise | |
| I feel burned out | |
| A competitor opens nearby | |

---

*Signed:* ____________________ *Date:* __________

*This template is education only and is not legal, tax, or financial advice. Speak to an accountant or attorney in your state before registering a business or signing a lease.*
