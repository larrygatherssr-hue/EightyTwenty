# The Beauty Business Launch Academy — BEA-01

**Price:** $697 (one-time) · **Category:** Beauty & Health · **SKU:** BEA-01

A complete start-to-finish academy for licensed estheticians, hairstylists, and nail technicians ready to open their first salon, suite, or home-based beauty business.

## Files

| File | What it is |
|---|---|
| `content.md` | The full course text — 12 fully written modules, plus a bonus first-month chapter and a mistakes appendix (~12,000 words). |
| `workbook.md` | Companion workbook — niche worksheet, startup budget worksheet, service pricing worksheet, launch checklist, first-20-clients tracker, monthly review. |
| `templates/service-pricing-calculator.csv` | Service pricing calculator — price build-up per service, product cost breakdown, month-one revenue model. |
| `templates/business-plan-template.md` | Fill-in business plan template, covering niche, services, premises, licensing, finances, marketing, and the 90-day launch plan. |
| `templates/client-intake-and-consent-form.md` | Client intake and consent forms pack — intake form, treatment consent form, aftercare sheet, patch test record. |
| `sales-page.md` | Sales page copy — headline, problem, solution, module list, who it is for / not for, price, guarantee, FAQ, disclaimers. |
| `listing.json` | Marketplace listing data (SKU, name, category, price_cents 69700, billing, headline, description, delivery note, SEO keywords, refund policy, support). |
| `cover.md` | Cover design brief — black-and-gold luxury branding, typography, imagery, layout. |
| `cover.png` | Generated premium cover image (black-and-gold, title readable). |
| `onboarding.md` | Buyer onboarding — what to do first, how to use the materials, suggested 8-week schedule, how to get support. |
| `README.md` | This index. |

## Notes

- All content is original and education only. No medical advice, no treatment or disease-cure claims. Skincare content is general education about routines and ingredients, with a note to consult a dermatologist or physician for skin conditions. Licensing requirements vary by state/country — buyers must verify local rules.
- No testimonials, sales figures, certifications, or reviews are fabricated anywhere in this product.
