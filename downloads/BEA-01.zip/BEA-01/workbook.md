# The Beauty Business Launch Academy — Workbook

## Companion Workbook: Exercises, Worksheets, and Checklists

Use this workbook alongside the course text. Print it or copy it into a notebook. The worksheets are meant to be filled in with your real numbers, your real clients, and your real decisions. A workbook filled in honestly is worth more than a course read twice.

---

## Important Disclaimer

This workbook is education only. It does not provide medical advice, and it does not teach you to diagnose, treat, or cure any skin condition, disease, or medical problem. Skincare content here is general education about routines and ingredients. If you or a client has a skin condition or a health concern, consult a dermatologist or physician. Licensing requirements vary by state and country — verify your local rules with your state board of cosmetology or equivalent licensing authority before you open, advertise, or take paying clients.

---

## Worksheet 1 — Niche Worksheet (Module 1)

**My ideal client**

- Name I give her (a label, not a real person): ____________________
- Age range: ____________________
- Job / life situation: ____________________
- Where she spends her time (online and in person): ____________________
- What she worries about when she looks in the mirror: ____________________
- What she has tried before that disappointed her: ____________________
- What a good result looks like to her, in her words: ____________________
- What would stop her booking (price, time, embarrassment, confusion)? ____________________

**My three best services** (the ones I do well and enjoy):

1. ____________________
2. ____________________
3. ____________________

**My niche in one sentence:** "I help [person] who [problem] to [outcome]."

Write it here: ____________________________________________________________

**Test results:** I spoke to five people who fit this profile. What they said, in their exact words:

1. ____________________
2. ____________________
3. ____________________
4. ____________________
5. ____________________

**Decision:** My niche is confirmed / needs adjusting (circle one). What I will change: ____________________

---

## Worksheet 2 — Startup Budget Worksheet (Module 4)

Fill in every line with a real quote for your area. Add lines if you need them.

**One-off startup costs**

| Item | Estimated cost | Actual quote |
|---|---|---|
| Deposit (first month / security) | $ | $ |
| Treatment bed | $ | $ |
| Stool, trolley, storage | $ | $ |
| Lighting / magnifying lamp | $ | $ |
| Linen, towels, blankets | $ | $ |
| Initial product stock | $ | $ |
| Small equipment | $ | $ |
| Branding, logo, printed materials | $ | $ |
| Booking software setup | $ | $ |
| Licences and registrations | $ | $ |
| Insurance (first payment) | $ | $ |
| Other: ____________________ | $ | $ |
| **Total one-off costs** | **$** | **$** |

**Monthly running costs**

| Item | Monthly cost |
|---|---|
| Rent | $ |
| Insurance | $ |
| Booking software | $ |
| Utilities and laundry | $ |
| Product top-ups | $ |
| Phone and internet | $ |
| Marketing | $ |
| Other: ____________________ | $ |
| **Total monthly running costs** | **$** |

**Total cash needed to open safely:** One-off costs + (monthly running costs × 3) = $__________

**My funding plan:** Savings $__________ | Income while building $__________ | Other $__________ | Still needed $__________ | Opening date: __________

---

## Worksheet 3 — Service Pricing Worksheet (Module 6)

Copy this table for each service on your menu. Use the pricing calculator spreadsheet for the full maths, and record the result here.

**Service:** ____________________ **Time (treatment + setup/clean-up):** __________ minutes

| Cost | Amount |
|---|---|
| Product cost per treatment | $ |
| Time cost (hours × my hourly rate of $____) | $ |
| Overheads share (monthly overheads ÷ expected appointments) | $ |
| **Total cost** | **$** |
| Profit margin (20% as a starting point) | $ |
| **My price** | **$** |

**Check:** Does this price feel fair for the result the client receives? Yes / No. If no, what needs to change — my costs, my time, or my offer? ____________________

**My menu at a glance** (list every launch service with its price):

1. ____________________ — $____
2. ____________________ — $____
3. ____________________ — $____
4. ____________________ — $____
5. ____________________ — $____
6. ____________________ — $____

**My discount policy** (write it before you open): I will offer discounts only when: ____________________. The maximum discount is ____%. The offer ends on: ____________________.

---

## Worksheet 4 — Launch Checklist (Modules 2, 3, 8, 12)

Tick each item when it is genuinely done, not when you plan to do it.

**Licence and legal**

- [ ] My professional licence is current and covers every service on my menu
- [ ] I have checked whether a separate salon / establishment licence is needed
- [ ] Business structure decided; registered as required
- [ ] Business bank account opened; personal and business money separated
- [ ] Professional liability and general liability insurance in place
- [ ] Zoning, landlord, and home-based rules checked for my premises

**Premises and room**

- [ ] Premises chosen and agreement read and signed
- [ ] Treatment bed, stool, trolley, and storage in place
- [ ] Lighting tested; room clean, warm, and uncluttered
- [ ] Linen, towels, and cleaning supplies stocked
- [ ] Sanitation routine written down and followed
- [ ] First aid kit in the room

**Menu, pricing, and booking**

- [ ] Service menu written in plain language, with prices published
- [ ] Every service priced with the formula in Module 6
- [ ] Booking system set up with services, prices, and real availability
- [ ] Deposit and cancellation policy written and shown before booking
- [ ] Automatic confirmations and reminders switched on
- [ ] Intake and consent forms ready to send before appointments

**Brand and marketing**

- [ ] Business name, colours, and fonts chosen and used consistently
- [ ] Social media profiles set up with booking link
- [ ] List of 50 people who know me written; personal messages sent
- [ ] Founding-client offer designed, with a clear limit and end date
- [ ] First three useful social media posts published

**Opening week**

- [ ] First five appointments booked before opening day
- [ ] Client notes system ready
- [ ] Aftercare message written
- [ ] Rebooking script practised
- [ ] Tax savings account opened; weekly bookkeeping habit set

---

## Worksheet 5 — First-20-Clients Tracker (Module 9)

Record every one of your first 20 clients. After 20, look at the pattern: where did they come from, and what brought the most?

| # | Client (initials) | How she found me | Service booked | Rebooked? | Referred anyone? |
|---|---|---|---|---|---|
| 1 | | | | | |
| 2 | | | | | |
| 3 | | | | | |
| 4 | | | | | |
| 5 | | | | | |
| 6 | | | | | |
| 7 | | | | | |
| 8 | | | | | |
| 9 | | | | | |
| 10 | | | | | |
| 11 | | | | | |
| 12 | | | | | |
| 13 | | | | | |
| 14 | | | | | |
| 15 | | | | | |
| 16 | | | | | |
| 17 | | | | | |
| 18 | | | | | |
| 19 | | | | | |
| 20 | | | | | |

**After 20 clients — review:**

- My best source of clients was: ____________________
- My most-booked service was: ____________________
- My rebooking rate was: ____%
- What I will do more of: ____________________
- What I will stop doing: ____________________

---

## Exercise — My Opening Week Plan

Write your opening week before it arrives. A week planned on paper is calmer than a week improvised under pressure.

- **Opening date:** __________
- **Working days and hours this week:** ____________________
- **Appointments already booked:** ____
- **Gaps I need to fill, and how I will fill them:** ____________________
- **Three posts I will publish this week:** 1. ____________________ 2. ____________________ 3. ____________________
- **People I will message personally this week:** ____________________
- **One thing I will ask every client:** ____________________

## Monthly Review (use every month after launch)

- Appointments this month: ____
- Income received: $____
- Expenses paid: $____
- Earnings before tax: $____
- Rebooking rate: ____%
- Retail and add-on income: $____
- Best source of new clients: ____________________
- One thing to change next month: ____________________

---

*Keep this workbook with your business records. Review it at day 30, day 60, and day 90 of your launch, and update your numbers as your real costs and bookings become clear.*
