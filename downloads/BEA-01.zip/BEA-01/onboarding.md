# Welcome — The Beauty Business Launch Academy

## What to Do First

Welcome. You have just bought a complete plan for opening your first beauty business. Before you read anything else, do these three things.

**1. Save your files somewhere safe.** You received the full course text, the companion workbook, the service pricing calculator, the business plan template, and the client intake and consent forms pack. Save them in one folder on your computer and back them up. Print the workbook and the templates — you will write in them.

**2. Read the disclaimers at the start of the course.** This course is education only. It teaches business skills, not medical advice, and it does not teach you to diagnose, treat, or cure any skin condition. Skincare content is general education about routines and ingredients. If you or a client has a skin condition or a health concern, consult a dermatologist or physician. Licensing requirements vary by state and country — verify your local rules with your state board of cosmetology or equivalent licensing authority before you open, advertise, or take paying clients.

**3. Set your opening date — even a rough one.** Pick a date about 90 days from now and write it on the first page of your workbook. Everything in this course works backwards from that date. A plan without a date is a wish.

## How to Use the Materials

- **content.md — the course.** Read it in order the first time. Each module ends with action steps. Do them before you move on, because the course builds on itself: Module 1 chooses your niche, Module 6 prices it, Module 9 fills it with clients, and Module 12 puts it on a calendar.
- **workbook.md — your working notebook.** This is where your real numbers live: your niche worksheet, your startup budget, your service pricing, your launch checklist, and your first-20-clients tracker. Fill it in as you go.
- **templates/service-pricing-calculator.csv — your pricing tool.** Open it in any spreadsheet app. Replace the sample values with your own overheads, hourly rate, and product costs, and it will build a price for each service. Use it in Module 6 and every time you add a service.
- **templates/business-plan-template.md — your plan on one document.** Fill it in as you finish each module. By Module 12 it is a complete business plan you can show to an accountant, a landlord, or a lender.
- **templates/client-intake-and-consent-form.md — your client paperwork.** Adapt it to your services and your state board requirements. Print the intake and consent forms, and give every client the aftercare sheet after treatment.

## Suggested 8-Week Schedule

Work at two to three hours per module, including the action steps. One to two modules a week is a steady, sustainable pace.

- **Week 1:** Modules 1–2 — niche and ideal client; licensing and legal setup.
- **Week 2:** Modules 3–4 — business model; startup costs and funding. Complete your startup budget with real quotes.
- **Week 3:** Modules 5–6 — service menu; pricing for profit. Price every service with the calculator.
- **Week 4:** Modules 7–8 — branding and salon identity; booking and scheduling systems.
- **Week 5:** Module 9 — getting your first 20 clients. Contact your list of 50 people.
- **Week 6:** Modules 10–11 — client experience and retention; retail and add-on revenue.
- **Week 7:** Module 12 — your 90-day launch plan. Write it on a calendar with real dates.
- **Week 8:** Bonus chapter and appendix. Review your business plan, check your numbers, and confirm your opening date.

If you can only do one module a week, that is fine — take 12 weeks instead. What matters is doing the action steps, not rushing through the reading.

## How to Get Support

For help with your order or the course files, email the marketplace support address with your order number and a description of the issue, and the support team will respond. Please include the product name (The Beauty Business Launch Academy, SKU BEA-01) and, if the problem is with a file, which file it is and what happens when you try to open it.

For questions about licensing, insurance, tax, or local business rules, speak to the relevant professional in your area — your state board of cosmetology, an accountant, an attorney, or your insurer. Marketplace support cannot give legal, tax, or medical advice.

## Your First Step, Today

Open the workbook, turn to Worksheet 1, and write your ideal client profile. One page, one person, in her words. That single page is the foundation of everything that follows. Good luck — and welcome to your own business.
