# The Beauty Business Launch Academy

## Turn Your Beauty Skills Into Your Own Business — Niche, Pricing, Booking, and First Clients

A complete start-to-finish course for licensed estheticians, hairstylists, and nail technicians who are ready to leave employment and open their first salon, suite, or home-based beauty business.

---

## Important Disclaimers — Please Read First

This course is education only. It teaches business skills: choosing a niche, pricing services, booking clients, marketing, and running a small beauty business. It is not medical advice, and it does not teach you how to diagnose, treat, or cure any skin condition, disease, or medical problem. Nothing in this course claims that a cosmetic product or treatment treats a medical condition.

Skincare content in this course is general education about routines and ingredients. If you or a client has a skin condition, a rash, an infection, scarring, hair loss, or any health concern, consult a dermatologist or physician. Do not offer medical opinions to clients, and do not promise medical results from cosmetic services.

Licensing requirements vary by state and country, and they change over time. The licensing information in this course is general guidance only. You must verify the current rules with your state board of cosmetology or equivalent licensing authority, your city or county, and your landlord or lease, before you open, advertise, or take paying clients. The same applies to home-based business rules, zoning, insurance, and health and safety requirements — check your local rules first.

No income figures in this course are promises. Every worked example uses sample numbers to show you how the maths works. Your real income will depend on your prices, your location, your costs, how many clients you book, and how consistently you work the plan.

---

## How to Use This Course

There are 12 modules. Work through them in order the first time. Each module ends with action steps — do them before you move on, because the course builds on itself. Module 1 chooses your niche. Module 6 prices it. Module 9 fills it with clients. Module 12 puts it all on a 90-day calendar.

You will need the companion files: the business plan template, the service pricing calculator, the launch checklist, and the client intake and consent forms pack. They are in your download. Use them as you go — they are not optional extras, they are the working tools of the course.

Set aside two to three hours per module, including the action steps. The full course takes about eight weeks at a steady pace. The suggested schedule is in the onboarding guide.

---

## Module 1 — Choosing Your Niche and Your Ideal Client

Most beauty professionals who stall before opening do not have a skills problem. They have a focus problem. They try to serve everyone, offer everything, and compete on price with every salon in town. The result is a vague business that no one remembers and no one recommends.

A niche is not a limitation. It is a decision about who you serve best, what problem you solve for them, and why they should choose you over the salon down the road. A clear niche makes every later decision easier: your prices, your service menu, your branding, your marketing, and even your room setup all follow from it.

### What a niche actually is

A niche has three parts: a person, a problem, and a promise.

The person is your ideal client — described in enough detail that you could recognise her when she walks in. The problem is the specific frustration or desire she brings with her. The promise is the outcome she gets from you, stated in her words, not yours.

Consider three estheticians with the same licence and similar training:

- Esthetician A offers "facials, waxing, lashes, brows, and more" to "everyone."
- Esthetician B specialises in facials for women over 40 who want a calm, unhurried treatment and honest guidance on a simple skincare routine.
- Esthetician C specialises in acne-safe facials for teenagers and young adults, with parent-friendly booking and clear aftercare education.

Esthetician A has to compete with every salon in the area. Estheticians B and C can be recommended by name: "Go to her, she is brilliant with mature skin" or "She is the one for teenage skin." That recommendation is the cheapest marketing in the world, and it only happens when people can describe what you do in one sentence.

### Finding your niche: start with evidence, not wishes

Do not pick a niche because it sounds profitable. Pick it from evidence you already have. Work through these four questions honestly.

**1. What do you already do well, and what do clients already ask you for?** Look back over the last three months of your employed work. Which services did clients rebook? Which ones did they ask for by name? Which ones did colleagues send to you? If clients keep asking you for brow work, that is data. If no one ever rebooks your lash service, that is also data.

**2. What do you enjoy enough to do all day, five days a week?** A niche you dislike will not survive the first slow month. You will be doing this work when you are tired, when a client cancels, and when the room needs cleaning. Choose work that still interests you on a bad day.

**3. Who can you reach?** A niche is only useful if you can find those clients. If your ideal client is "busy executives who want lunchtime facials," can you reach them — near offices, through LinkedIn, through a lunchtime offer? If your answer is "I hope they find me," the niche is too hard to reach.

**4. Who can pay?** Passion does not pay rent. Your ideal client must have both the problem and the money to solve it. A niche of students who love luxury facials but cannot afford them will not sustain a business. That does not mean you only serve wealthy clients — it means your prices and your audience must match.

### The ideal client profile

Write a one-page profile of one person. Give her a name, an age range, a job or life situation, and a weekly routine. Then answer: What does she worry about when she looks in the mirror? What has she tried before that disappointed her? What does a good result look like to her? What would stop her booking — price, time, embarrassment, not knowing what to ask for?

Here is a worked example:

> **Ideal client: "Maya, 38, office manager, two children."** Maya works full time and does most of the household organising. She has 45 minutes she can protect for herself, usually on a Saturday morning or a weekday lunch break. She has tried drugstore skincare and a cheap facial deal that left her skin red. She wants to look rested, not "done." She will pay for a treatment that feels calm and unhurried, and for someone who explains what is being used on her skin in plain language. She will not book if she has to phone during work hours, if the price is unclear, or if she feels judged about her skin.

Everything in Maya's business follows from that paragraph. The service menu is short and calm. Booking is online. Prices are published. The room is quiet. The marketing speaks about rest and confidence, not about "anti-ageing miracles."

Write your profile now, in the workbook. If you cannot fill in the details, you do not yet know your client well enough — talk to five real people who fit the profile before you go further.

### Testing your niche before you commit

Before you spend money on a lease or branding, test the niche for two weeks:

- Post three times on your personal or business social media about the specific problem you solve, in plain language. Do not post "I do facials." Post "If your skin feels tight and tired by 3 p.m., here is why, and what helps."
- Offer five discovery conversations — 15 minutes, free, no sales pressure — to people who fit your profile. Ask what they have tried, what frustrated them, and what they would pay for.
- Search local listings. How many competitors serve this exact niche within a 20-minute drive? Zero competitors can mean no demand, so check that people are actually searching for it. Ten direct competitors means you need a sharper angle.

If people respond, ask questions, and book the conversation, the niche has life. If no one responds, the niche is either wrong or your message is unclear. Fix the message first — most niches fail on messaging, not on demand.

### Common niche mistakes

- **Too broad:** "Women aged 18 to 65 who want to look good." That is everyone, which means no one feels spoken to.
- **Too narrow to pay:** A niche so specific that only a handful of people in your town fit it, and they cannot afford you.
- **Copying a competitor:** Choosing a niche because another salon does well in it, without checking whether you enjoy it or can reach those clients.
- **Choosing by treatment, not by person:** "I do lash lifts" is a service, not a niche. "I do lash lifts for brides and wedding parties who want a natural look that lasts through the day" is a niche.

### Action steps — Module 1

1. Write your ideal client profile in the workbook niche worksheet. One person, one page, in her words.
2. List the three services you do best and enjoy most. Cross out any service you would dread doing daily.
3. Write your niche in one sentence: "I help [person] who [problem] to [outcome]."
4. Have five conversations with people who fit your profile. Write down their exact words about their frustrations.
5. Post three times about the problem you solve. Note which post gets the most response.

---

## Module 2 — Licensing and Legal Setup

You can have the best niche in town and still be shut down in week one if your paperwork is wrong. This module is not legal advice — it is a checklist of what to check, in what order, so you do not miss a step. Verify every item against your current local rules.

### Your professional licence

In most US states, you need a current cosmetology, esthetics, or nail technician licence to offer services for payment. The exact licence depends on your state and on the services you offer. A facial may need an esthetics licence. Hair colour may need a cosmetology licence. Nails may need a separate nail technician licence. Some services — such as certain advanced treatments — may need additional certification or may be outside your scope entirely.

Check three things now: that your licence is current, that it covers every service on your planned menu, and whether your state requires a separate salon, suite, or establishment licence for the premises itself. Many states require both a personal licence and a facility licence, and the facility must pass an inspection before it opens.

If you trained or were licensed in another state, check reciprocity rules. Do not assume your licence transfers. If your licence has lapsed, renew it before you spend money on anything else.

### Choosing a business structure

For most solo beauty businesses, the choice is between operating as a sole proprietor and forming a limited liability company (LLC). This is a general explanation, not advice for your situation — speak to an accountant or attorney in your state before you decide.

A sole proprietorship is the simplest setup: you and the business are the same legal person. It is cheap to start, but your personal assets are not separated from the business if something goes wrong.

An LLC creates a separate legal entity. It costs more to form and maintain, and you must keep business and personal money separate, but it provides a layer of separation between your personal assets and the business. Many beauty professionals choose an LLC for that reason, and many landlords and insurers expect it.

Whatever you choose, get an Employer Identification Number (EIN) from the IRS if you form an LLC or plan to hire anyone, open a business bank account in the business name, and never mix business and personal money. Mixing the two is the single most common bookkeeping mistake in small beauty businesses, and it makes tax time miserable.

### Business name, registration, and taxes

Register your business name with your state or county as required. Check that the name is not already in use by another salon in your state, and check that the matching social media handle and domain are available before you print anything.

Register for the taxes your state requires. In many states, services themselves are not subject to sales tax, but retail products are. That distinction matters when you start selling retail in Module 11. Check with your state tax authority or your accountant — do not guess.

Set up a simple system from day one: a business bank account, a business card, and a rule that every business expense goes through the business account. Keep receipts. Photograph them the same day. At tax time, you will be grateful.

### Insurance — do not skip this

You need professional liability insurance (sometimes called malpractice insurance for beauty professionals) and general liability insurance. Professional liability covers claims related to your services — a reaction, an injury, a dissatisfied client claim. General liability covers the premises — a client slips in your suite, for example.

If you work from home, do not assume your homeowner's insurance covers your business. It usually does not. Tell your insurer you run a business from the premises. If you rent a suite, check what the salon or suite landlord covers and what you must carry yourself. Get quotes from at least two insurers who specialise in beauty professionals, and read the policy — check the coverage limits, the excess, and whether your specific services are covered.

### Leases, home-based rules, and zoning

If you rent a salon suite or a chair, read the lease before you sign it. Check the length, the notice period, what is included (utilities, laundry, reception, booking software), what you may and may not do to the room, and what happens if you leave early. Ask whether you can use your own booking system and your own product lines, or whether the landlord restricts them.

If you work from home, check three separate things: your local zoning rules, your lease or homeowner association rules, and your state board rules. Some areas prohibit home-based salons outright. Some allow them with a separate entrance, a separate bathroom, or an inspection. Some landlords forbid business use. Find out before you tell clients your address.

If you go mobile, check whether your state allows mobile services, whether you need a separate mobile licence, and what hygiene and transport rules apply to your kit.

### Health, safety, and hygiene

Your state board will have rules on sanitation, disinfection, single-use items, laundry, and waste. Learn them and follow them visibly. Clients notice clean tools, fresh linen, and a tidy room — and they notice the opposite even more.

Keep a simple written sanitation routine: what is cleaned, with what, and how often. Keep product safety data sheets where you can find them. Keep a first aid kit in the room. None of this is glamorous. All of it protects you and your clients.

### Records you must keep

From day one, keep: client intake and consent forms, patch test records where relevant, notes on products used, receipts and invoices, your booking records, and your income and expenses. Keep client records securely and privately — do not leave intake forms where other clients can see them, and do not discuss one client's treatment with another client.

### Action steps — Module 2

1. Confirm your licence is current and covers every service on your planned menu. Note any additional licence you need.
2. Decide your business structure and speak to an accountant or attorney before you register.
3. Get two insurance quotes and read what is covered.
4. Check zoning, landlord, and state board rules for your chosen premises type.
5. Open a business bank account and set up a receipt system before your first sale.

---

## Module 3 — Business Model Options: Salon, Suite, Home-Based, or Mobile

There is no single best model. There is a best model for your money, your personality, and your stage. This module compares the four main options honestly, with real costs, so you can choose with your eyes open.

### Option 1: Renting a chair or a room in an existing salon

You rent space inside someone else's salon and work under your own name. You usually pay a weekly or monthly rent, and you keep what you earn after rent and your own product costs.

**Typical costs:** Chair or room rent varies widely by city, from a few hundred to over a thousand dollars a month. You supply your own products, tools, and booking system unless the salon provides them. You may also pay a share of laundry or reception costs.

**Best for:** A first step out of employment. You get a professional setting, walk-in traffic, and colleagues, without a lease on a whole building.

**Watch out for:** Restrictions. Some salons control your prices, your hours, your product lines, or whether you can take your clients with you when you leave. Read the agreement. Ask in writing: Who owns the client list? Can I use my own booking system? What happens to my clients if I leave?

### Option 2: Renting a salon suite

A salon suite is a small private room — sometimes in a purpose-built suite building — that you rent and fit out yourself. You control the room, the hours, the prices, and the branding.

**Typical costs:** Suite rent is usually higher than chair rent, and you pay for your own fit-out: furniture, lighting, linen, product storage, decor, and signage. Budget for a deposit, first month's rent, and fit-out before you open. Many suite landlords offer a short introductory rent period — ask about it.

**Best for:** Professionals who want privacy and control, and whose clients value a calm, one-to-one experience. Suites suit estheticians and nail technicians particularly well.

**Watch out for:** Loneliness and invisibility. There is no walk-in traffic and no receptionist. You are responsible for every booking. If you are not comfortable marketing yourself, a suite can feel very quiet.

### Option 3: Home-based

You convert a room in your home into a treatment space. Your commute is a staircase, your rent is low, and your hours are fully yours.

**Typical costs:** The lowest of the four models. Main costs are the room conversion, furniture, insurance, and any local permits. Your biggest cost is not money — it is boundaries.

**Best for:** Professionals with a spare room, a separate entrance if possible, and clients who are comfortable visiting a home. It is also the lowest-risk way to test whether you can fill a diary before you sign a lease.

**Watch out for:** Zoning and landlord rules (see Module 2), privacy, and the feeling that you never leave work. Set strict hours, a separate phone number or booking link, and a rule that clients do not message you at midnight. Keep the treatment room separate from family living space, and keep client records locked away.

### Option 4: Mobile

You travel to clients' homes with a portable kit. You have no rent at all, and you can serve clients who cannot travel — new parents, older clients, people with limited mobility.

**Typical costs:** Travel, a portable bed or kit, fuel, and extra time between appointments. You will fit fewer clients in a day than in a fixed room, because travel eats the gaps.

**Best for:** Hair and nail professionals whose work travels well, and anyone whose ideal client cannot easily come to a salon.

**Watch out for:** Hygiene and safety. You need a reliable kit, a cleaning routine between clients, and clear safety rules about where you will and will not work. Charge a travel fee or build travel into your price — do not absorb it silently.

### Comparing the models

| Factor | Chair / Room | Suite | Home-Based | Mobile |
|---|---|---|---|---|
| Monthly fixed cost | Medium | High | Low | Very low |
| Control over branding | Low | High | High | Medium |
| Walk-in traffic | Some | None | None | None |
| Privacy for clients | Low–Medium | High | High | High |
| Flexibility of hours | Medium | High | High | High |
| Loneliness / isolation | Low | High | High | High |
| Risk if bookings are slow | Medium | High | Low | Low |

### A staged path many professionals take

You do not have to choose your forever model on day one. A common, sensible path is:

1. **Months 1–6:** Home-based or chair rental while you build a client base and prove your prices.
2. **Months 6–18:** Move to a suite once you have steady rebookings and can cover the rent from existing clients.
3. **Later:** Consider a full salon only when you have a waiting list, a team in mind, and the management appetite to run other people — a salon is a different job from being a solo practitioner.

Each move should be funded by the clients you already have, not by hope. The question is never "Which model is best?" It is "Which model can I afford if bookings are slow for two months?"

### Action steps — Module 3

1. Score each model against your money, your personality, and your ideal client. Be honest about whether you enjoy working alone.
2. Visit two suites or salons and ask about rent, inclusions, and restrictions. Write the numbers down.
3. Check home-based or mobile rules for your area before you assume they are allowed.
4. Choose your starting model and write one sentence explaining why. Revisit it after Module 5, when your costs are clear.

---

## Module 4 — Startup Costs and Funding

Most beauty businesses do not fail because the work is bad. They fail because the owner runs out of money before the diary fills. This module helps you count the real cost of opening, so you open with a buffer instead of a prayer.

### The two kinds of cost

**One-off startup costs** are paid once: furniture, equipment, initial product stock, branding, website, booking software setup, deposits, and licences.

**Monthly running costs** repeat every month whether you have clients or not: rent, insurance, product top-ups, laundry, booking software, phone, and marketing.

Your launch budget must cover both: the one-off costs, plus at least three months of running costs with no income. That three-month buffer is not pessimism — it is the time it takes most new businesses to build a steady diary.

### Worked example: startup budget for a solo esthetician in a rented suite

These are sample figures for planning. Your local prices will differ — replace each line with a real quote.

| Item | One-off | Monthly |
|---|---|---|
| Suite deposit (one month) | $1,200 | — |
| Treatment bed | $600 | — |
| Stool, trolley, storage | $350 | — |
| Lighting and magnifying lamp | $250 | — |
| Linen, towels, blankets | $200 | — |
| Initial skincare stock | $800 | — |
| Small equipment (steamer, etc.) | $400 | — |
| Branding, logo, and printed materials | $300 | — |
| Booking software setup | $50 | $30 |
| Insurance (annual, paid monthly) | — | $60 |
| Suite rent | — | $1,200 |
| Utilities and laundry | — | $120 |
| Product top-ups | — | $200 |
| Phone and internet share | — | $50 |
| Marketing | — | $100 |
| **Totals** | **$4,150** | **$1,760** |

Three months of running costs: $1,760 × 3 = $5,280. Total cash needed to open safely: $4,150 + $5,280 = **$9,430**.

That number surprises many people. It is better to be surprised now, on paper, than in month two when the rent is due and the diary is half empty.

### Funding it without debt you regret

In order of preference for most starters:

1. **Save first, then open.** Set a target from your budget above and a date. Every month you save brings the date closer, and you open without repayments hanging over you.
2. **Start smaller.** A home-based or chair-rental start can cut the one-off cost by half or more. You can move to a suite later, funded by clients.
3. **Keep a part-time employed job while you build.** Many professionals open two or three days a week and keep employed days until the diary fills. There is no shame in this — it is sensible risk management.
4. **Borrow carefully, if at all.** If you borrow, borrow the smallest amount that covers a real gap, know the monthly repayment, and check that your month-one revenue model (Module 6) covers it. Never borrow to fund a luxury fit-out. Clients pay for results and a clean, calm room — not for designer furniture.

Avoid funding your launch on a credit card at high interest. If you must use credit, have a written repayment plan with a date, and do not add new spending to the card while you repay it.

### Tracking money from day one

Open a separate business bank account. Use a simple spreadsheet or bookkeeping app. Every week, record: income received, expenses paid, and cash left. Once a month, compare your actual figures with your budget. The habit matters more than the tool — a notebook you actually use beats software you never open.

Set aside tax money as you earn it. A simple rule many solo professionals use is to transfer 25 to 30 percent of each payment into a separate savings account for tax, and to leave it alone. Check the correct percentage with your accountant for your situation.

### Action steps — Module 4

1. Complete the startup budget worksheet in the workbook with real quotes for your area.
2. Calculate your total cash needed: one-off costs plus three months of running costs.
3. Write your funding plan: how much you have saved, how much you still need, and the date you will open.
4. Open a business bank account and a separate tax savings account before your first sale.

---

## Module 5 — Service Menu Design

Your service menu is not a list of everything you can do. It is a sales tool. A good menu helps a new client choose quickly, understand what she is paying for, and book without phoning you with questions. A bad menu confuses her, and a confused client does not book.

### The rule of the short menu

Offer fewer services, done brilliantly, rather than a long list done adequately. A menu of six to ten services is enough for most solo businesses at launch. You can add services later, once the core menu is full.

Every service on your menu should pass three tests:

1. **You do it well.** You are confident, trained, and insured for it.
2. **Your ideal client wants it.** It solves her problem, not a problem you imagine she has.
3. **It makes money.** It covers its costs and your time at a profitable price (see Module 6). A service that fills your diary but loses money is not a success.

If a service fails any test, leave it off the launch menu. You can add it later if the evidence changes.

### Designing the menu around outcomes, not techniques

Clients buy outcomes, not techniques. "60-minute customised facial" tells a client how long it takes, but not what it does for her. "The Calm Skin Facial — 60 minutes, for skin that feels tight, red, or tired" tells her whether it is for her.

For each service, write: the name, who it is for, what happens, how long it takes, and the price. Use plain language. Avoid jargon your client would need to look up. If you use professional terms, explain them in one line.

Example menu entries for a solo esthetician:

- **The Calm Skin Facial — 60 minutes — $95.** For skin that feels tight, reactive, or tired. Gentle cleansing, calming mask, and a simple home routine to take away. Ideal as a first visit.
- **The Deep Clean Facial — 75 minutes — $120.** For congested skin and clogged pores. Includes thorough cleansing, exfoliation, extractions where appropriate, and a mask.
- **The Glow Facial — 45 minutes — $75.** A shorter treatment for a special occasion or a lunchtime refresh. Cleansing, exfoliation, and a hydrating mask.

Notice what is missing: no list of 15 facials with similar names, no unexplained abbreviations, no prices hidden until the client asks. Clarity is a kindness, and it is also good business.

### Packages and series

A series — for example, three facials over six weeks — can help clients commit to a course of treatments and give you predictable income. Only offer a series where the treatment genuinely benefits from repetition, and be clear about expiry dates and refund terms. Do not sell a series as a pressure tactic. A client who feels pushed will not return.

### What to leave out

- Services you are not insured for.
- Services you have not practised enough to deliver confidently.
- "Add-ons" that confuse the booking process. Add-ons belong in Module 11, once the core menu works.
- Prices that say "from $…" with no explanation. If the price varies, explain why in one line — for example, "Price depends on hair length; quoted at consultation."

### Reviewing your menu every quarter

Once a quarter, look at your booking data. Which services are booked most? Which are never booked? Which make the most profit per hour? Remove or reprice the services that never book. Promote the ones that clients love. Your menu is a living document, not a monument.

### Action steps — Module 5

1. Draft a launch menu of six to ten services. For each one, write who it is for and what outcome it delivers.
2. Remove any service that fails the three tests above.
3. Show the menu to three people who fit your ideal client profile. Ask them: "Could you choose a service from this without asking me a question?" If they cannot, rewrite it.
4. Publish prices on your booking page. Do not hide them.

---

## Module 6 — Pricing for Profit (With Formulas)

This is the module that changes everything. Most beauty professionals underprice, because they price by looking at competitors and then charging a little less. That is how you end up busy, exhausted, and broke. This module shows you how to price from your costs and your time, so your business can actually sustain you.

### The pricing formula

For each service, your price must cover four things:

**Price = Product cost + Your time cost + Overheads share + Profit margin**

- **Product cost:** What the products used in the treatment actually cost you. Not the retail price — your cost price.
- **Your time cost:** What your time is worth per hour, multiplied by the time the service takes, including setup and clean-up.
- **Overheads share:** Your share of rent, insurance, laundry, booking software, and other fixed costs, allocated to each appointment.
- **Profit margin:** Money left over after all costs, so the business can grow and you can take time off.

If your price does not cover all four, you are subsidising your clients from your own pocket.

### Worked example: pricing a 60-minute facial

Meet "Ana," a solo esthetician in a rented suite. These are sample figures — replace them with your own.

**Step 1 — Product cost.** Ana uses a cleanser, exfoliant, mask, serum, moisturiser, and SPF in a facial. Her cost per treatment, measured by dividing each product's cost by the number of treatments it provides, is **$9.50**.

**Step 2 — Your time cost.** Ana decides her time is worth $50 per hour. The facial takes 60 minutes of treatment, plus 15 minutes of setup and clean-up. Total time: 75 minutes, or 1.25 hours. Time cost: 1.25 × $50 = **$62.50**.

**Step 3 — Overheads share.** Ana's monthly overheads (rent, insurance, booking software, laundry, utilities) total $1,760. She expects to do 80 appointments a month. Overheads per appointment: $1,760 ÷ 80 = **$22.00**.

**Step 4 — Add them up and add profit.** Product $9.50 + time $62.50 + overheads $22.00 = $94.00. Ana adds a 20 percent profit margin: $94.00 × 1.20 = **$112.80**, which she rounds to **$115**.

Her facial price is $115. If a competitor charges $75 for a similar facial, Ana is not "too expensive" — the competitor is either working for very little, cutting corners on products, or losing money. Ana's price is the price that lets her pay rent, replace products, and still earn a living.

Now test it the other way. If Ana charged $75, her costs are $94. She would lose $19 on every facial before profit. Do 80 facials a month at that price and she loses $1,520 a month. Being busy does not help if every appointment loses money.

### How to find your own numbers

- **Product cost:** For each product, divide its cost by the number of treatments you get from it. A $60 serum that lasts 30 treatments costs $2 per treatment. Do this for every product in the service and add them up.
- **Your time cost:** Decide an hourly rate for your time. A starting point many solo professionals use is the hourly wage they would need to earn their target income. If you want to earn $60,000 a year working 40 hours a week for 48 weeks, that is $60,000 ÷ 1,920 hours = $31.25 per hour before costs — and that is only your time, before products and overheads. Work out your own target, and do not be embarrassed to aim higher than your employed wage. You now pay your own rent, insurance, holidays, and sick days.
- **Overheads share:** Add up your monthly overheads and divide by the number of appointments you realistically expect. If you are just starting and expect 40 appointments a month, your overheads per appointment will be higher than when you do 80. That is normal — price for the reality of your first months, not for a full diary you do not have yet.

### Discounts: the quiet profit killer

A 20 percent discount does not reduce your profit by 20 percent — it can wipe it out entirely. If your facial costs $94 to deliver and you sell it for $115, your profit is $21. Discount it by 20 percent to $92 and you are now losing $2 on every facial. Discounts are fine as a deliberate, limited launch offer, but they must be planned, time-limited, and priced so you still cover costs. Never discount because you feel guilty about your price.

### When and how to raise prices

Raise prices once a year, or when your costs rise significantly. Tell existing clients in advance, in writing, with a date. A short note works: "From 1 September, my facial will be $120. Thank you for your loyalty — I have held my prices for a year and my product and rent costs have risen." Most clients accept a fair, explained increase. The clients who leave over a small increase were often the ones who valued the discount more than the treatment.

### Worked example: month-one revenue model for a solo esthetician

Ana opens with a realistic first month, not a full diary. She works four days a week and offers three services:

| Service | Price | Appointments | Revenue |
|---|---|---|---|
| Calm Skin Facial, 60 min | $115 | 28 | $3,220 |
| Glow Facial, 45 min | $85 | 16 | $1,360 |
| Brow shape and tint, 30 min | $45 | 20 | $900 |
| **Total** | | **64** | **$5,480** |

Her costs for the month: products $610, overheads $1,760, total $2,370. Her gross earnings before tax: $5,480 − $2,370 = **$3,110**. That is her income for the month, before tax and before paying herself a separate wage — and it is based on 64 appointments, not a fantasy of a fully booked diary. If she books fewer, the overheads stay the same and the earnings fall. That is why the three-month buffer in Module 4 matters.

Use the pricing calculator in your download to run your own version of this model with your prices and your expected appointments.

### Action steps — Module 6

1. Calculate the product cost for each service on your menu, product by product.
2. Decide your hourly time rate from your income target, not from a competitor's price.
3. Price every service with the formula above, using the calculator provided.
4. Write your discount policy: when you will discount, by how much, and for how long. Put it in writing before you open.
5. Set a date for your first price review.

---

## Module 7 — Branding and Salon Identity

Branding is not a logo. A logo is one small part of it. Your brand is what clients expect when they book with you, and what they tell their friends afterwards. It is built from your name, your room, your language, your prices, and the way you treat people — consistently, every time.

### Start with the feeling, not the font

Before you choose colours or a logo, decide the feeling you want a client to have when she walks in. Calm? Energised? Luxurious? Friendly and down to earth? Pick two words, no more. Every branding decision should support those two words.

If your words are "calm" and "trusted," your room will be quiet, uncluttered, and warm. Your language will be plain and reassuring. Your colours will be soft and restrained. If your words are "bold" and "glamorous," the room, language, and colours will be different — and that is fine, as long as they match your ideal client.

### Your business name

A good name is easy to say, easy to spell, easy to remember, and available. Check that no other salon in your area uses it, that the social media handle is free, and that the domain name is available. Avoid names that limit you: "Ana's Lash Bar" is a problem if you later want to offer facials. Avoid puns that need explaining. Say the name out loud as if you are answering the phone. If it feels awkward, it is the wrong name.

### Visual identity: keep it simple

You need: a logo (or a clean wordmark in a good font), two or three colours, and one or two fonts. That is enough. Use the same colours and fonts on your booking page, your social media, your price list, and your intake forms. Consistency builds recognition faster than cleverness.

The black-and-gold palette of this academy is an example of a premium look: deep black, warm gold, and clean white space. It works because it is restrained. Whatever palette you choose, keep it restrained too. Three colours, used consistently, look more professional than ten colours used at random.

### Your voice

Write the way you speak to a client in the room: warm, plain, and honest. Do not use language you would never say out loud. Do not promise miracles. Do not use medical language about treatments — remember the education-only rule from the start of this course. Describe what the treatment feels like, how long it takes, and what the client should expect afterwards, in plain words.

### The room as branding

Your room is your strongest branding tool. It should be clean, calm, and uncluttered. Fresh linen, a tidy trolley, soft lighting, and a clear place for the client to put her belongings. A client decides in the first 30 seconds whether she feels safe and cared for. That decision has nothing to do with how expensive your furniture was.

Pay attention to the senses: a clean smell (not overpowering fragrance), a comfortable temperature, a quiet background, and a treatment bed that is actually comfortable. Ask a friend to lie on your bed for 20 minutes and tell you honestly what needs fixing.

### Action steps — Module 7

1. Choose your two brand words. Write them where you can see them.
2. Choose your business name and check availability of the name, handle, and domain.
3. Choose your colours and fonts. Write them down and use them everywhere.
4. Set up your room and ask a friend to test it as a client. Fix what they find.

---

## Module 8 — Booking and Scheduling Systems

A booking system is not admin. It is the difference between a business and a hobby. If clients cannot book easily, they will book with someone else — often at 11 p.m., when you are asleep and your competitor's online booking is awake.

### What a good system does

At minimum, your booking system should: show your real availability, let clients book and pay a deposit online, send automatic confirmations and reminders, let clients reschedule without phoning you, and keep a record of who booked what and when.

It should also protect your time: a cancellation policy, a deposit or full prepayment for new clients, and a gap between appointments for setup and clean-up. Do not let the system book clients back to back with no break. You need time to reset the room, write notes, eat, and breathe.

### Deposits and cancellation policies

Take a deposit from new clients. A deposit of 50 percent, or a fixed amount such as $30, is common. It reduces no-shows dramatically, and it means a last-minute cancellation does not cost you the whole appointment.

Write your policy in plain language and show it before the client books, not after she cancels. For example: "A $30 deposit secures your appointment. If you need to reschedule, please give 48 hours' notice and your deposit will move to your new appointment. Deposits are not refunded for cancellations with less than 48 hours' notice or for missed appointments."

Be firm and kind about enforcing it. If you waive the policy every time, you do not have a policy.

### Your weekly schedule

Design your working week before you open. Decide which days you work, your start and finish times, and your breaks. Then protect that schedule. A solo beauty business can easily expand into every evening and weekend if you let it, and burnout follows.

A realistic starting week for a solo practitioner might be four days: Tuesday to Friday, 9 a.m. to 5 p.m., with one late evening for clients who cannot come during the day. Build in a lunch break, a gap between clients, and one admin hour a week for ordering, bookkeeping, and marketing. You are the business — if you burn out, the business stops.

### Reminders and no-shows

Send an automatic reminder 48 hours before and again on the morning of the appointment. Most no-shows are forgotten appointments, not rudeness. A reminder protects both of you. Keep a simple record of no-shows and late cancellations. If a client does it repeatedly, have a kind, direct conversation — and require full prepayment for future bookings.

### Client records

After every appointment, write a short note: what was done, which products were used, any reactions, and what the client wants next time. This takes two minutes and it transforms retention — a client who hears "Last time you said the mask felt too warm, so I have used a cooler one today" knows she was listened to. Keep these notes securely and privately.

### Action steps — Module 8

1. Choose a booking system and set it up with your services, prices, and availability.
2. Write your deposit and cancellation policy. Show it before booking.
3. Design your working week, including breaks and an admin hour.
4. Set up automatic reminders and a system for client notes.

---

## Module 9 — Getting Your First 20 Clients

Your first 20 clients are the hardest to get and the most important to keep. They will teach you what works, refer their friends, and give you the confidence to keep going. This module is a practical plan for finding them, without spending money you do not have.

### Start with people who already know you

Your first clients are rarely strangers. They are former colleagues' clients, friends, family, neighbours, and people who have watched you train. Make a list of 50 people who know you and your work. Contact them personally — not with a mass message, but with a short, individual note: what you are opening, when, where, and how to book. Offer them a founding-client appointment in your first two weeks.

Do not be embarrassed to ask. People like helping someone they know to start a business. What they do not like is a generic broadcast that feels like spam.

### The founding-client offer

A limited, deliberate opening offer can fill your first diary. For example: your first 20 clients receive a founding-client price, or a free add-on such as a brow shape with a facial, for bookings in your first month only. The offer must have a limit — a number of clients or a date — or it becomes your permanent price.

Be clear that the offer is a launch celebration, not your normal price. When the offer ends, your normal prices apply. Clients who came for the discount and leave when it ends were never your clients — but many will stay, because they now know your work.

### Where your ideal client already spends time

Go where your ideal client already is, instead of shouting into the void. If she is a new mother, she is in parent groups, at baby classes, and on local parent forums. If she is a bride, she is in wedding groups and at wedding fairs. If she works in an office, she is on LinkedIn and in local business networks.

Join those places as a helpful person, not as an advertiser. Answer questions. Share useful, general information. When someone asks for a recommendation, you are there — known, trusted, and easy to book.

### Social media that actually books clients

Post three to four times a week, and make most of it useful, not promotional. Useful posts answer a question your ideal client has: how to choose a moisturiser, what to expect from a first facial, how to care for skin between appointments. Educational content builds trust, and trust books appointments. Promotional posts — your offer, your availability, your opening — should be about one in four posts.

Show your face, your room, and your work. Clients book people, not logos. A short video of your clean, calm room, or of you explaining a treatment in plain language, does more than a polished graphic. Post your booking link in every post. Make it easy — a client should never have to ask how to book.

### Referrals: ask for them

After a client's first visit, if she is happy, ask her directly: "I am building my business and I would love to help people like you. If you know someone who might enjoy this, would you pass on my details?" Most happy clients are glad to help, but they will not think of it unless you ask.

A simple referral thank-you — a small discount on her next visit, or a free add-on — encourages the behaviour without turning it into a sales scheme. Keep it simple and generous.

### Tracking your first 20

Use the first-20-clients tracker in the workbook. For each client, record: how she found you, what she booked, whether she rebooked, and whether she referred anyone. After 20 clients, you will know which of your efforts actually work. Double down on those, and stop doing the ones that brought no one.

### Action steps — Module 9

1. Make your list of 50 people who know you. Contact them personally.
2. Design your founding-client offer, with a clear limit.
3. Join two places where your ideal client already spends time, and be helpful there for two weeks.
4. Post three useful pieces of content this week, each with your booking link.
5. Ask every happy first-time client for a referral.

---

## Module 10 — Client Experience and Retention

Getting a client once is marketing. Getting her back is a business. Retention is cheaper than acquisition, more profitable, and more enjoyable. A client who returns every four to six weeks, and who brings a friend, is worth many times more than a one-off booking.

### The client experience, step by step

**Before the appointment:** Booking is easy, the price is clear, the confirmation arrives, and the reminder arrives. The client knows where to go, where to park, and what to expect. She is asked to complete her intake form in advance, so her appointment time is treatment time, not paperwork time.

**Arrival:** She is welcomed by name. She is offered water or tea. She is shown where to put her things. The room is clean, warm, and ready. She is not kept waiting while you finish with another client or tidy the room.

**Consultation:** Before you begin, you ask — and listen. What brings her in today? What has she tried before? What does she want to feel when she leaves? You explain what you will do, in plain language, and you check that she is comfortable. You do not assume. You do not rush.

**The treatment:** You work calmly and attentively. You explain what you are using and why, without lecturing. You check in on comfort — temperature, pressure, light. You respect silence. Some clients want to chat; some want to rest. Follow their lead.

**After the treatment:** You explain what you did, what she should expect over the next day, and simple aftercare in plain language. You write down what you used, so you can repeat it or adjust it next time. You do not pressure her to buy products. You rebook her before she leaves, while the experience is fresh — "Shall we book your next visit in four weeks, on a Tuesday or a Thursday?"

**After she leaves:** A short thank-you message the next day, and a reminder when her next visit is due. No spam, no daily messages. One thoughtful follow-up is enough.

### Rebooking before she leaves

The single most effective retention habit is rebooking at the appointment. A client who leaves without a next appointment is a client you must win back with marketing. A client who leaves with a date in the diary is already retained.

Make it easy: offer two options, not an open question. "Would Tuesday or Thursday suit you better?" books more appointments than "Would you like to rebook?" Keep a simple rebooking script by your desk until it becomes habit.

### Handling complaints

A complaint is not a disaster — it is a client telling you how to keep her. Listen without interrupting. Apologise for her experience, even if you disagree about the cause. Ask what would make it right. Offer a solution you can actually deliver: a complimentary follow-up, a redo of the service where appropriate, or a refund in line with your policy.

Do not argue, do not blame the client, and do not discuss it with other clients. Handle it privately, promptly, and kindly. A well-handled complaint often creates a more loyal client than a flawless visit.

### Knowing when to let a client go

Not every client is your client. If someone repeatedly arrives late, cancels at the last minute, demands services outside your scope, or treats you disrespectfully, you are allowed to end the relationship politely. "I don't think I am the right practitioner for you, and I would like to recommend a colleague" is a professional, kind way to do it. Protecting your time and your wellbeing is part of running a business.

### Measuring retention

Track two numbers every month: your rebooking rate (what percentage of clients rebook before they leave) and your return rate (what percentage of clients return within eight weeks). If your rebooking rate is below 50 percent, something in the experience needs attention — usually it is that no one is asking clients to rebook.

### Action steps — Module 10

1. Write down your client journey, step by step, from booking to follow-up. Fix any step that is unclear or rushed.
2. Start rebooking every client before she leaves, offering two options.
3. Write a short aftercare message you can send the day after a treatment.
4. Track your rebooking rate for one month.

---

## Module 11 — Retail and Add-On Revenue

Retail and add-ons are not about pushing products on clients. They are about helping a client continue the results of her treatment at home, and about adding income to appointments you are already doing. Done honestly, both help the client. Done pushily, both damage trust.

### Add-ons: small, relevant, easy to choose

An add-on is a short extra service added to a booked treatment — a brow shape with a facial, a hand massage with a manicure, a lip treatment with a facial. It should take 10 to 15 minutes, cost the client a small extra amount, and be genuinely useful for her.

Rules for add-ons: offer at most two at booking, explain the benefit in one sentence, and accept a "no" gracefully. Never add an add-on without the client's agreement, and never make a client feel she is getting a lesser treatment if she declines.

Work out the add-on price with the same formula from Module 6. If a 15-minute add-on uses $3 of product and your time is worth $50 an hour, the time cost is $12.50, product $3, overheads share about $5 — total $20.50, plus profit. A price of $25 is fair and profitable. A price of $10 would lose money.

### Retail: sell what you use, and only what you believe in

Clients ask, "What should I use at home?" That question is a retail opportunity — but only if you recommend products you actually use in treatments, understand well, and can explain in plain language.

Start with a small retail range: three to five products that cover the basics for your niche. For an esthetician, that might be a cleanser, a moisturiser, and a sunscreen. You do not need a shelf of 30 products. A small, confident range sells better than a large, confusing one.

### How retail pricing works

You buy products at a wholesale or professional price and sell them at a recommended retail price. The difference is your margin. Before you stock a product, check: your cost price, the retail price, your margin, how many you need to sell to cover the stock cost, and whether the brand restricts where you can sell it.

Example: a moisturiser costs you $24 wholesale and retails at $48. Your margin is $24 per sale. If you buy six, you have spent $144. You need to sell three to recover your cost, and the other three are profit. Do not buy 20 of a product before you know whether your clients want it.

Keep retail simple: a clean display, prices clearly shown, and a short explanation of each product. Offer a product only when it fits the client's treatment and home routine. A recommendation made in the client's interest is helpful. A recommendation made to hit a sales target is not.

### Skincare education, not medical claims

When you discuss skincare with clients, keep to general education: how to cleanse, moisturise, and protect skin from the sun; what common ingredients do in general terms; and how to build a simple routine. Do not diagnose skin conditions, do not claim a product treats a medical condition, and do not promise specific medical results. If a client has a skin condition, encourage her to see a dermatologist or physician. This protects your client, and it protects you.

### Tracking retail and add-on income

Record retail sales and add-on income separately from service income. Each month, check: which products sell, which add-ons are chosen, and how much extra income they add per appointment. If an add-on adds $15 per appointment on average and you do 80 appointments a month, that is $1,200 a month from work you were already doing.

### Action steps — Module 11

1. Choose two add-ons for your menu. Price them with the Module 6 formula.
2. Choose three to five retail products you use and believe in. Check your cost, retail price, and margin for each.
3. Write a one-sentence explanation for each retail product, in plain language.
4. Add a retail display to your room and track sales separately.

---

## Module 12 — Your 90-Day Launch Plan

You now have a niche, a legal setup, a business model, a budget, a menu, prices, a brand, a booking system, and a plan for your first clients. This module puts it all on a calendar. Ninety days is enough to open properly without rushing, and short enough to stay focused.

### Days 1–30: Decide and prepare

- Finalise your niche and ideal client profile.
- Confirm your licence, insurance, and business structure.
- Choose your business model and premises. Sign the agreement only after reading it.
- Complete your startup budget and funding plan.
- Draft your service menu and price every service with the calculator.
- Choose your business name, colours, and booking system.
- Order your fit-out and initial stock.

By day 30, you should know your numbers, your niche, and your opening date. If you do not yet know them, do not rush to open. A delayed opening is better than a confused one.

### Days 31–60: Build and tell people

- Fit out your room. Test it as a client would.
- Set up your booking page with services, prices, deposit policy, and intake forms.
- Create your social media profiles with consistent branding.
- Contact your list of 50 people personally.
- Post useful content three to four times a week.
- Offer five discovery conversations.
- Set your founding-client offer and your opening week appointments.

By day 60, your room should be ready, your booking page should be live, and your first appointments should be booked.

### Days 61–90: Open and learn

- Open. Welcome your first clients. Deliver the experience you designed in Module 10.
- Rebook every client before she leaves. Ask every happy client for a referral.
- Track your numbers weekly: appointments, income, expenses, rebooking rate, and where clients came from.
- Review your menu and prices after the first month. Remove what does not book. Promote what clients love.
- At day 90, sit down with your numbers and answer three questions: Am I covering my costs? Are clients rebooking? What will I change in the next 90 days?

### Your weekly rhythm after launch

- **Monday:** Admin hour — bookkeeping, ordering, and one marketing post.
- **Tuesday to Friday (or your working days):** Client appointments, with client notes written after each one.
- **Weekly:** Check your diary for next week. Fill gaps with a post or a message to your waiting list.
- **Monthly:** Review income, expenses, rebooking rate, and retail sales. Adjust one thing, not everything.

### When things go slowly

A slow first month is normal. Do not panic and slash your prices — that teaches clients to wait for discounts and leaves you working for nothing. Instead, check the basics: Are people seeing your posts? Is booking easy? Are you asking for referrals? Are you following up with people who enquired but did not book? Fix one thing at a time, and give each fix two weeks to work before you judge it.

### Your first-year goals

Set three goals for your first year, and write them down: a monthly income goal, a client-number goal, and a personal goal (such as working four days a week, or taking a holiday). Review them every quarter. Goals you write down and review are goals you can adjust. Goals you keep in your head are wishes.

### Action steps — Module 12

1. Write your 90-day plan on a calendar, with dates, not just intentions.
2. Set your opening date and work backwards.
3. Book your first five appointments before you open, even if they are founding clients.
4. Set your three first-year goals and a quarterly review date.
5. Open, serve your clients well, and keep going. You have a plan. Work the plan.

---

## Bonus — Your First Month, Week by Week

The 90-day plan in Module 12 tells you what to do. This bonus chapter tells you what a normal first month actually feels like, week by week, so a quiet Tuesday does not feel like failure.

### Week 1: Opening week

Your first week is about learning, not earning. Expect a mix of excitement and nerves, a room that still needs small fixes, and appointments that run slightly over time while you find your rhythm. That is normal.

Each day, arrive 30 minutes early. Check the room: clean linen, fresh water, products in place, booking system open. After each client, write your notes immediately — do not trust your memory at the end of the day. In the evening, note three things: what went well, what took too long, and what you will change tomorrow. Small daily fixes compound quickly.

If you have gaps in the diary, use them well. Do not sit waiting. Post a short video of your room, message two people from your list of 50, or tidy and restock. A gap used for marketing is not a wasted gap.

A realistic opening week for a solo esthetician might be 12 to 16 appointments. If you do fewer, it is not a verdict on your business — it is a starting point. Your job in week 1 is to deliver a good experience to everyone who comes, and to ask each of them to rebook.

### Week 2: Finding your rhythm

By week 2, your timing improves. You know how long setup takes. You know which products you reach for. Your client notes start to pay off — you remember what a returning client liked, and she notices.

This is the week to check your numbers for the first time. Add up your income and your expenses. Compare them with your month-one model from Module 6. Are you on track, ahead, or behind? If you are behind, do not change your prices. Change your activity: more posts, more personal messages, more referral asks. Activity is the lever you control in week 2.

It is also the week to ask for your first honest feedback. Ask three clients, in person: "Is there anything I could do better?" Listen, thank them, and act on anything reasonable. Clients who are asked for feedback feel valued — and they tell their friends.

### Week 3: The first wobble

Week 3 is often the hardest week. The excitement of opening has faded, the diary is not yet full, and a cancellation or two can feel personal. This is the moment many new owners make their biggest mistake: discounting heavily to fill gaps.

Resist it. Instead, do a focused push on the channels that already worked. If your first clients came from personal messages, send more personal messages. If they came from a local parent group, post something useful there. If a particular service booked well, feature it. Do more of what worked, not something entirely new.

Use week 3 to review your menu. Which service is booked most? Which one has never been booked? If a service has had no interest in three weeks, consider removing it or repricing it — but give it a fair chance first, and check whether the problem is the service or the way it is described.

### Week 4: Review and reset

At the end of week 4, sit down with your numbers and your notes. Answer these questions in writing:

- How many appointments did I do? How much income did I receive?
- What were my total costs? Did I cover them? If not, how big is the gap?
- What percentage of clients rebooked before they left?
- Where did my clients come from? Which channel brought the most?
- What did clients praise? What did they ask for that I do not offer?
- What will I do differently next month?

Then set three actions for month two, and only three. For example: post four times a week instead of two; ask every client for a referral; add one add-on to the booking page. Three focused changes beat ten vague intentions.

### A note on slow days and self-doubt

Every beauty business owner has slow days. The difference between those who succeed and those who close is not talent — it is what they do on a slow day. The successful ones use the day: they market, they learn, they tidy, they plan, they rest so they can serve well tomorrow. The ones who struggle sit and worry, and then discount in a panic.

You chose this work because you are good at it. Trust the plan, track the numbers, and give the business the 90 days you promised it. A business is built one client, one rebooking, and one referral at a time.

### A second worked example: pricing a nail service

To reinforce Module 6, here is a second pricing build-up, this time for a nail technician offering a gel manicure.

Sample figures: product cost per manicure, including gel polish, base and top coat, remover, and disposable files, is $4.50. The service takes 45 minutes of treatment plus 10 minutes of setup and clean-up, a total of 55 minutes, or 0.92 hours. At a time rate of $45 per hour, the time cost is $41.40. Monthly overheads are $1,400 and the technician expects 90 appointments a month, so overheads per appointment are $15.56. Total cost: $4.50 + $41.40 + $15.56 = $61.46. Adding a 20 percent profit margin gives $73.75, rounded to $75.

If this technician charged $45 because a nearby salon does, she would lose $16.46 on every manicure. At 90 manicures a month, that is a loss of $1,481 a month. The maths does not care about the competitor's price. Your price must cover your costs, or your business cannot survive — no matter how talented you are.

### A second worked example: a hairstylist's first month

A hairstylist renting a chair works three days a week in her first month. She offers cuts, colour, and blow-dries:

| Service | Price | Appointments | Revenue |
|---|---|---|---|
| Cut and finish | $65 | 24 | $1,560 |
| Full colour and cut | $140 | 12 | $1,680 |
| Blow-dry | $40 | 18 | $720 |
| **Total** | | **54** | **$3,960** |

Her costs: products $480, chair rent $900, insurance and booking $110, total $1,490. Earnings before tax: $3,960 − $1,490 = $2,470. She can see clearly that colour, though fewer in number, brings in the most revenue — and that her diary needs more colour bookings, not more blow-dries, if she wants to grow her income. That insight only comes from tracking services separately, which is why the pricing calculator and the workbook matter.

## Appendix — Ten Mistakes New Beauty Business Owners Make (and How to Avoid Them)

**1. Underpricing to win clients.** You attract clients who value low prices, not your work, and you cannot afford to serve them well. Price from your costs, as in Module 6, and let your work justify the price.

**2. Spending too much before opening.** A beautiful room matters, but clients pay for results and a clean, calm experience, not for designer furniture. Spend on what clients touch and see — the bed, the linen, the lighting — and keep the rest simple until income covers it.

**3. Hiding prices.** Clients who cannot find your price will assume it is expensive, or they will book elsewhere rather than ask. Publish your prices. Clarity builds trust.

**4. Offering everything.** A long menu confuses clients and spreads your stock, training, and marketing too thin. Start with a short menu you can deliver brilliantly, and add services when the evidence supports it.

**5. No deposit, no policy.** Without a deposit, no-shows cost you the whole appointment. Without a written cancellation policy, every cancellation becomes a negotiation. Set both before you open, show them before booking, and enforce them kindly and consistently.

**6. Mixing business and personal money.** It feels harmless at first, and it makes tax time miserable later. A separate business account from day one, and a separate tax savings account, will save you hours and stress.

**7. Not rebooking clients.** The client who leaves without a next appointment is a client you must win back. Rebook before she leaves, every time, offering two options. It is the simplest retention habit in this course, and one of the most powerful.

**8. Marketing only when the diary is empty.** Marketing done in a panic rarely works. A steady rhythm — three to four useful posts a week, personal messages, referral asks — keeps the diary full before it empties. Market when you are busy, not only when you are quiet.

**9. Ignoring the numbers.** If you do not track income, expenses, and rebooking rates, you cannot tell whether your business is working. A weekly 15-minute check of the numbers is enough, but it must happen every week.

**10. Trying to do it all alone, forever.** You are the practitioner, the receptionist, the marketer, and the bookkeeper at the start, and that is normal. As you grow, consider help where it saves you the most time — a bookkeeper, a cleaner, or a virtual assistant for messages. Asking for help is not failure. It is how a small business becomes a sustainable one.

Read this appendix again at day 90. Tick the mistakes you avoided, and be honest about the ones you made. Then fix one, and keep going.

## Conclusion

You do not need to be the best beauty professional in your city to run a successful beauty business. You need a clear niche, prices that cover your costs, a calm and professional experience, and the consistency to keep showing up for your clients.

Before you close this course, take a moment to picture the business you have just planned. A client walks in, is welcomed by name, and settles into a clean, calm room. She knows what she is paying for and why it is worth it. She leaves feeling cared for, with her next appointment already booked, and she tells a friend. That is the business. It is not built in a day, and it is not built by a single clever trick. It is built appointment by appointment, by a professional who knows her niche, charges fairly, keeps her promises, and treats every client as if she will return.

The plan in your hands is complete. You know who you serve, what you charge, how you will find your first clients, and what you will do in your first 90 days. The next step is not another course, another logo, or another month of planning. The next step is to do the action steps in Module 1, then Module 2, and to keep going until the door opens.

Open with a plan. Price with honesty. Treat every client as if she will return — because the way you treat her decides whether she does. Keep your records tidy, your room clean, your prices fair, and your promises small enough to keep every single time.

Your business starts the day you decide it does. Use this course, use the templates, work the 90-day plan, and build it one client at a time.

---

*This course is education only and is not medical, legal, tax, or financial advice. Verify licensing, insurance, tax, and local business requirements with the appropriate professionals and authorities in your area. Consult a dermatologist or physician for skin conditions and medical concerns.*
