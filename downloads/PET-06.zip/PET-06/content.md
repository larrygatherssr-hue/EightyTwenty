
---

## Module 3 — Local SEO: Being Found When Neighbours Search

### What local SEO actually means

Search engine optimisation (SEO) sounds technical, but local SEO for a pet business is simple in principle: when someone nearby searches for the service you offer, your business should appear near the top. Google decides the ranking based on three things — relevance (does your business match what was searched?), distance (how close are you to the searcher?), and prominence (how well known and trusted is your business?). You cannot change your distance from a searcher, but you can improve relevance and prominence a great deal, mostly for free.

This module covers the practical steps. You do not need to understand how search engines work in detail, and you do not need to hire an SEO agency to do the basics well. If an agency contacts you promising a number-one ranking for a monthly fee, treat that promise with scepticism — no one can guarantee a ranking, and the basics in this module cover most of what a small local business needs.

### Step 1: Be consistent everywhere (NAP consistency)

NAP stands for Name, Address, and Phone number. Google checks whether your business details are the same across the internet. If your Google profile says "Paws & Claws Grooming, 12 High Street, 555-0142" but your Facebook page says "Paws and Claws, 12 High St, 555-0143," Google is less sure which details are correct, and that uncertainty can hurt your ranking.

Choose one exact version of your name, address, and phone number, and use it identically everywhere: your Google profile, your website, your Facebook and Instagram bios, any directories you are listed in, and your email signature. This is a small, boring task — and it matters more than most of the clever tactics people sell.

### Step 2: Your website or booking page

You do not need a large website. You need one clear page (or a simple small site) that tells Google and customers who you are, what you do, and where you do it. If you already have a website, make sure it includes:

- **Your town and service area in plain text.** Not just in an image or a footer graphic — in readable text. A page that says "Dog grooming in [Town] for anxious and senior dogs" tells Google exactly what you do and where.
- **One page per main service.** If you offer grooming and sitting, give each its own page with its own heading, description, and starting price. A single page listing everything ranks worse than focused pages.
- **Your full NAP details** on every page, usually in the footer, matching your Google profile exactly.
- **Real photos** of your work, your premises, and your team.
- **A clear way to book or contact you** on every page — a phone number, a booking button, or a simple contact form. Do not make a customer hunt for it.
- **A page that loads quickly on a phone.** Most local searches happen on a phone. If your page is slow or hard to read on a small screen, customers leave — and Google notices.

If you do not have a website, a Google Business Profile plus a booking link and an active Facebook page can be enough to start. But a simple website gives you control that rented platforms do not, and it is worth building once your profile is complete. A basic site built with a common website builder is sufficient; do not pay thousands for a custom build at this stage.

### Step 3: Local directories and citations

A citation is any mention of your business name, address, and phone number on another website — a local business directory, a pet directory, your local chamber of commerce, or a review site. Citations help Google confirm that your business is real and established.

List your business in a handful of reputable, relevant places:

- General directories that are genuinely used in your country (for example, Yelp, Thomson Local or Yell in the UK, or your local equivalents).
- Pet-specific directories and local pet service listings.
- Your local council or chamber of commerce business directory, if one exists.
- Any local community or neighbourhood site that lists businesses.

Use your exact NAP details on each one. Do not pay for listings on directories you have never heard of, and do not sign up for dozens of low-quality directories — a few good ones beat fifty obscure ones. Check once a year that the listings are still accurate.

### Step 4: Content that answers local questions

Google rewards businesses that answer the questions local customers are actually asking. You do not need a blog with fifty articles. Four to six genuinely useful pages or posts are enough to start:

- "What to expect at your dog's first groom" — for nervous first-time owners.
- "How often should a doodle be groomed?" — a question owners search constantly.
- "What to look for in a dog walker in [Town]" — a local, useful guide.
- "How to prepare your puppy for its first training class."
- "Dog walking in [Neighbourhood]: routes, parks, and what to know."

Write these in plain, helpful language. Answer the question properly, mention your town naturally, and end with a gentle invitation to book or call. Do not stuff the town name into every sentence — write for a human reader first, and the search benefit will follow. One good page per month is a realistic pace. A page that answers a real question will keep bringing visitors for years.

### Step 5: Reviews feed your ranking (and your reputation)

Reviews are covered in depth in Module 4, but they belong in this module too, because they are one of the strongest local ranking signals. A business with 40 recent, genuine reviews and a 4.8-star average will usually outrank a business with 6 old reviews, even if the second business has a better website. Quantity, recency, and your replies all count. Keep asking for reviews, keep replying, and the ranking benefit compounds over time.

### Step 6: Measure what matters

You do not need analytics software to know whether local SEO is working. Check these once a month:

- How many people found you through Google Search versus Google Maps? (Your Google Business Profile insights show this.)
- How many calls, direction requests, and website visits came from your profile?
- What search terms brought people to you? (Your profile insights list the most common ones.)
- How many new enquiries mentioned they found you on Google?

If calls and enquiries from Google are rising month by month, your local SEO is working. If they are flat, revisit Modules 2 and 3: is your profile complete, are you posting weekly, are you earning reviews, and does your website clearly state what you do and where?

### Module 3 action steps

1. Fix your NAP details so they match exactly everywhere.
2. Check your website or booking page against the checklist in Step 2.
3. List your business in three to five reputable local or pet directories.
4. Write or plan your first helpful local content page.
5. Record your baseline Google profile numbers so you can measure progress.

---

## Module 4 — Reviews: Earning Them, Asking for Them, and Answering Them Well

### Why reviews decide bookings

A pet owner is handing over a family member to a stranger. That is an act of trust, and trust is hard to build from a website alone. Reviews are how strangers borrow trust from people who have already used you. Studies of consumer behaviour consistently find that most people read reviews before choosing a local business, and that a business with no reviews is often skipped entirely — not because the business is bad, but because there is no evidence it is good.

Reviews also affect whether customers find you at all, as noted in Module 3. And they affect price: a business with strong reviews can charge more than a business with none, because the risk of choosing it feels lower. Reviews are not a vanity metric. They are a business asset, and they are earned one happy customer at a time.

### Step 1: Earn the review before you ask for it

No script can rescue a mediocre experience. The review is decided by what happened during the service, not by what you say afterwards. The moments that produce five-star reviews are usually small and specific:

- The dog is returned calm, clean, and happy — not stressed or rushed.
- The owner is told what happened, in plain language, without being asked.
- A small extra is noticed: a bandana after a groom, a photo mid-walk, a note about how the puppy did at training.
- A problem is handled honestly and quickly, rather than hidden or blamed on the dog.

Build one "review-worthy moment" into every service. For a groomer, it might be a photo of the finished groom sent with a short message. For a walker, a daily photo and a one-line walk report. For a sitter, a morning and evening update. These moments cost minutes and produce the reviews that fill your books.

### Step 2: Ask at the right moment

The best time to ask for a review is when the customer is happiest — usually within an hour of the service, when the dog is home looking and smelling wonderful, or when the owner has just received your photo update and replied with delight. Do not wait a week. Enthusiasm fades, and the review never gets written.

Ask in person first, then follow up with a link. A simple spoken ask works well: "I'm so glad Bella did well today. If you have a moment, a Google review would mean a lot — it really helps other owners find us." Then send a short message with the direct link to your Google review page. Make it as easy as possible: one tap, no searching, no account creation beyond what Google already requires.

Do not ask every customer every time in a way that feels like pressure. Ask your happy customers, ask once, and thank them whether or not they leave a review. Never offer payment, discounts, or free services in exchange for a review — that is against Google's policies and, in many places, against advertising rules. A genuine review is worth more than a bought one, and a bought one can get your profile penalised.

### Step 3: Make it easy — the review request system

Set up a simple, repeatable system so asking becomes a habit, not a chore:

1. Create a short link to your Google review page. Google Business Profile provides this in your dashboard — save it and use it everywhere.
2. Prepare two or three short message templates (see the templates folder). One for text message, one for email, one for after a first visit.
3. Send the request within one hour of the service ending, while the experience is fresh.
4. Track who you asked and who left a review, using the review-request tracker in the workbook. If someone did not review, do not chase them repeatedly — one polite reminder after a few days is enough.

Aim to ask every happy customer. If you serve 40 customers a month and half of them leave a review over time, you will have dozens of reviews within a year. That is the compounding effect that separates busy businesses from struggling ones.

### Step 4: Reply to every review

Reply to every review — positive and negative — within 48 hours. Replies show future customers that you pay attention and that you care. They also show Google that your business is active.

**Replying to a positive review.** Thank the customer by name, mention something specific from their review, and invite them back. Keep it short and genuine.

Worked example:

> "Thank you so much, Sarah — Bella was an absolute delight today, and she looked wonderful after her trim. We're so glad the shorter cut is working well for her coat. See you both in six weeks!"

That reply does three things: it thanks the customer, it proves the review is about a real dog and a real service, and it mentions the rebooking interval — which quietly tells future readers that this customer comes back regularly.

**Replying to a negative review.** This is where reputations are made. A calm, professional reply to a fair complaint impresses future customers more than a page of five-star reviews. Never argue, never blame the customer or the dog, and never reveal private details. Follow this structure:

1. Thank them for the feedback.
2. Apologise that their experience was not what they hoped for — without admitting fault for things you did not do.
3. State briefly what you will do or have done about it.
4. Invite them to contact you directly to resolve it.

Worked example:

> "Thank you for letting us know, James, and I'm sorry Max's groom didn't go as you hoped. We've reviewed what happened and would like to make it right — please call us on [number] or message us directly so we can discuss it. We value your feedback and want every dog to leave happy."

Do not offer a public refund or a free service in the reply — discuss that privately. Do not reply when you are angry. Write the reply, wait an hour, read it again, and then post it. If a review is fake, abusive, or from someone who was never a customer, you can report it to Google — but do not expect every unfair review to be removed. A thoughtful reply usually matters more than removal.

### Step 5: Use reviews in your marketing (with permission)

With the reviewer's permission, your best reviews can be used on your website, your social media, and your booking page. A short quote from a real customer, with their first name and their dog's name, is more persuasive than any claim you make about yourself. Rotate them — a fresh review on your booking page each month keeps it looking current. Never edit a review to make it sound better, and never present a review from one business as if it belongs to another.

### The referral math: why reviews compound

Reviews and referrals work together. A customer who leaves a review is already an advocate; a customer who refers a friend is an advocate who has put their own reputation behind you. Both grow from the same source — a service worth talking about — and both are covered again in Module 6.

### Module 4 action steps

1. Build one review-worthy moment into every service.
2. Create your Google review link and three short request templates.
3. Ask every happy customer within one hour of the service.
4. Reply to every new review within 48 hours.
5. Record reviews in the tracker and rotate the best ones (with permission) into your marketing.

---

## Module 5 — Social Media That Books Appointments, Not Just Likes

### The trap: content that entertains but never converts

Many pet businesses post every day and still have empty appointment books. The problem is rarely effort — it is that the content is designed to get likes, not bookings. A cute dog video can get thousands of views from people who live hundreds of miles away and will never book. A simple post about next week's availability, seen by 80 local followers, can fill three appointments. Reach is not revenue. Local relevance is.

This module is about social media with a job to do: keep your business visible to local pet owners, prove your quality, and make booking easy. It focuses on Instagram and Facebook, because those are where most local pet owners spend time, but the principles apply anywhere.

### Step 1: Choose one primary platform

You do not need to be everywhere. Choose the platform where your local customers already are, and do it well. For most pet businesses, that is Instagram (strong for visual proof — grooming photos, walk videos, before-and-afters) or Facebook (strong for local community groups, older owners, and event sharing). If you are unsure, ask your ten best customers which platform they use most, and go where they are.

Post on your primary platform three to five times a week. If you use a second platform, repost the same content there rather than creating separate content. Consistency on one platform beats sporadic posting on four.

### Step 2: The four types of post that actually work

Every post should fall into one of four categories. If a post does not fit any of them, do not publish it.

**1. Proof posts.** Show your work. Before-and-after grooming photos, a video of a nervous dog relaxing during a groom, a puppy's progress over four training sessions. Proof posts are your portfolio, and they are the posts that convince a stranger you can do the job. Always get the owner's permission before posting their dog, and tag the location (your town) so local people find you.

**2. Education posts.** Answer a question your customers ask. "How to brush a doodle between grooms," "Three signs your dog needs a nail trim," "What to pack for your dog's first daycare day." Education posts build trust, get saved and shared, and position you as the local expert. One education post a week is enough.

**3. Personality posts.** Show the human behind the business. A short video of you talking about why you started, a photo of your own dog, a behind-the-scenes look at your morning routine. Customers choose people, not logos. You do not need to share your private life — a little warmth and honesty is enough.

**4. Booking posts.** Tell people what is available and how to book. "Two grooming slots left next week," "Christmas sitting is now 70% booked," "New puppy training class starts Monday — three places left." Booking posts should be direct, specific, and include a clear next step: a link, a phone number, or "message us to book." Post a booking post at least once a week. Many businesses post proof and personality endlessly and never actually ask for the booking. Ask.

A healthy week might look like this: Monday, a proof post; Wednesday, an education post; Friday, a booking post; and one personality post whenever something genuine happens. That is four posts a week, each with a purpose.

### Step 3: Make every post local

Local visibility is the whole point. Use these habits on every post:

- Tag your location (town or neighbourhood) in every post.
- Mention your town naturally in captions where it fits: "A fresh trim for Milo, one of our regulars here in [Town]."
- Use a small number of local hashtags, not thirty generic ones: #[Town]Dogs, #[Town]Groomer, #[Town]DogWalker — plus a few service tags. Generic tags like #dogsofinstagram bring likes from strangers, not bookings from neighbours.
- Share local content: a post about a nearby dog-friendly park, a local pet event, or a neighbourhood walk route. Local content gets shared locally.

### Step 4: Stories and short video

Short, informal video outperforms polished posts for most pet businesses, because it shows the real experience. You do not need professional equipment — a phone, good light, and a steady hand are enough. Ideas that work:

- A 30-second before-and-after groom, filmed in the same spot with the same light.
- A time-lapse of a walk, with a caption naming the route.
- A quick tip filmed while you work: "This is how I check a doodle coat for matting."
- A "day in the life" story: morning setup, first dog, lunch break, last walk.

Post stories most days, even if they are simple. Stories keep you visible at the top of your followers' feeds between your main posts, and they are where casual followers become familiar enough to book. Save your best stories as highlights on your profile: Services, Prices, Reviews, Before & After, FAQs. A new visitor should be able to understand your business from your highlights in under a minute.

### Step 5: Turn followers into bookings

Social media only pays if it leads somewhere. Make the path from post to booking as short as possible:

- Your bio should state what you do, where you do it, and how to book — in that order. Example: "Calm one-to-one grooming for anxious dogs in [Town]. Book online below."
- Your bio link should go to your booking page, not your homepage. One tap should start a booking.
- Reply to every comment and every direct message the same day. A slow reply loses the booking to a competitor who answered first. If you cannot reply personally all day, set up a short automatic reply that says when you will respond and how to book in the meantime.
- When someone asks a question in a comment, answer it helpfully and invite them to message you to book. Do not argue, and do not post prices for every service in the comments — direct them to your booking page where prices are listed clearly.

### Step 6: Measure honestly

Once a month, look at the numbers that matter and ignore the rest:

- How many enquiries or bookings mentioned Instagram or Facebook?
- How many profile visits and link clicks did you get?
- Which posts got the most saves and shares (not just likes)? Saves and shares predict bookings better than likes.
- Did your follower count grow among local people, or mostly among strangers?

If a type of post consistently produces enquiries, do more of it. If a type produces likes but no enquiries, do less of it, however fun it is to make. The 30 social media post templates in the templates folder give you a full month of starting points — adapt them to your voice and your town, and do not post them word for word without making them yours.

### Module 5 action steps

1. Choose your primary platform and fix your bio (what, where, how to book).
2. Plan next week's four posts: one proof, one education, one personality, one booking.
3. Tag your location on every post and use local hashtags.
4. Set up story highlights: Services, Prices, Reviews, Before & After, FAQs.
5. Reply to every comment and message the same day.
6. Review monthly: enquiries, link clicks, saves, and shares — not just likes.

---

## Module 6 — Referrals and Partnerships: Turning Happy Clients into Your Sales Team

### Why referrals are the cheapest marketing you will ever do

A referred customer arrives already trusting you, because someone they trust recommended you. Referred customers typically book faster, complain less, and stay longer than customers from advertising. And unlike paid ads, a referral system costs very little to run. The reason most pet businesses do not get many referrals is not that customers are unwilling — it is that nobody ever asked them, and nobody gave them a reason or an easy way to do it.

### Step 1: Ask — simply and at the right time

Most happy customers would refer a friend if asked. The right time is the same as for reviews: when they are delighted, just after a good service. A simple spoken ask is enough: "If you know anyone with a dog who needs a groomer, I'd love an introduction — I have two slots open next week." That is not pushy. It is a normal business request, and most customers are flattered to be asked.

Follow up the spoken ask with something they can forward: a short message with your booking link, or a small card they can hand to a friend. Make referring effortless. If a customer has to explain your business from memory, the referral often never happens. If they can forward a message in ten seconds, it does.

### Step 2: Design a referral offer that works for both sides

A referral programme should reward both the referrer and the new customer. That way, the existing customer feels appreciated and the new customer has a reason to try you. Keep it simple — complicated programmes are never used.

Worked example — referral-program math:

Suppose your average groom costs $65 and your average customer books every six weeks, roughly eight times a year. That customer is worth about $520 a year in grooming fees alone, before any extras. If you offer the referrer a $15 credit and the new customer $15 off their first groom, the total cost of acquiring that new customer is $30. If the new customer stays for even one year, you have spent $30 to gain $520 of revenue. If they stay for two years, you have spent $30 to gain over $1,000. That is why a generous referral offer is not expensive — it is one of the best investments a pet business can make. (Your numbers will differ; run the same calculation with your own prices and rebooking frequency using the referral-program planner in the workbook.)

Rules for a referral offer:

- Make the reward meaningful enough to notice — a small discount that feels like a token is often ignored.
- Make it easy to claim — a code, a card, or a simple "mention your friend's name" is enough.
- Put a fair limit on it if you need to, such as one reward per new customer, and state the terms clearly.
- Never pay for referrals in a way that breaks platform rules or local regulations. A credit against your own services is normally straightforward; cash payments for referrals can raise legal and tax questions in some places, so keep it to service credits unless you have checked the rules where you operate.

### Step 3: Build local partnerships

Other local businesses meet your ideal customers every day. A vet, a pet shop, a dog-friendly café, a pet photographer, and a local rescue all talk to pet owners constantly. A partnership is a simple, mutual arrangement: you recommend each other when it genuinely helps the customer.

Approach partnerships as a relationship, not a transaction. Start by visiting the business, introducing yourself, and learning what they do. Offer something useful first — a short talk for their customers, a discount for their staff's dogs, or a leaflet they can keep at the counter. Then ask whether they would be happy to recommend you to customers who ask. Most local businesses say yes, because recommending a good local service makes them look good too.

Practical partnership ideas:

- **Vets:** Offer a calm-groom or puppy-introduction service they can recommend to nervous-dog owners. Leave a small stack of cards at reception (with permission).
- **Pet shops:** Offer a joint promotion — for example, a free nail trim with a first groom for customers they send you, or a discount on their products for your customers.
- **Dog-friendly cafés and pubs:** Offer to feature them in a social media post about local dog-friendly places. They will often return the favour.
- **Rescues and breeders:** Offer a discounted first groom or a free puppy-introduction session for newly rehomed dogs. This builds goodwill and a steady stream of new owners who need a groomer.
- **Other pet professionals:** A trainer who does not groom, a walker who does not sit — refer customers to each other when the service is outside your own scope. Generosity in referrals usually comes back.

Track every partnership: who you partnered with, what you offered, how many customers came from them, and what you sent back. A partnership that produces nothing after three months may need a fresh conversation — or a graceful ending.

### Step 4: Community presence

You do not need to sponsor a football team. Small, visible community involvement builds the kind of local reputation that advertising cannot buy:

- Attend a local pet event or dog show with a small stall or a demonstration.
- Offer a free nail-trim or grooming demonstration at a community fair.
- Donate a groom or a walk as a raffle prize for a local rescue fundraiser.
- Join local Facebook community groups as a helpful member, not as an advertiser. Answer questions, share useful tips, and mention your business only when someone asks for a recommendation. Group members remember the helpful person and forget the person who posts ads every day.

### Module 6 action steps

1. Write your one-sentence referral ask and use it with happy customers this week.
2. Create a forwardable message or card with your booking link.
3. Design your referral offer and run the math with your own prices.
4. Approach two local businesses about a partnership this month.
5. Attend or support one local pet or community event this quarter.

---

## Module 7 — Retention and Rebooking: Filling the Calendar You Already Have

### The cheapest booking is the one you already have

Acquiring a new customer costs time and money. Keeping an existing one costs almost nothing by comparison. Yet many pet businesses spend all their marketing energy chasing new customers while existing customers quietly drift away — not because they were unhappy, but because nobody asked them to come back. A customer who does not rebook is not necessarily a lost customer. Often they simply forgot, got busy, or assumed you were full.

Retention is not a loyalty card gimmick. It is a system: book the next appointment before the customer leaves, remind them at the right time, notice when they go quiet, and give them a reason to stay.

### Step 1: Rebook before they leave

The single most effective retention habit is also the simplest: book the next appointment while the customer is still with you. For a groomer, that means offering the next date before the owner leaves with their dog. For a trainer, it means booking the next session at the end of the current one. For a walker, it means confirming next week's schedule on Friday.

Use a simple script: "Bella did wonderfully today. Her coat will need another trim in about six weeks — shall I book you in for [date]? It's the same time, and I'll send a reminder the day before." Most customers say yes, because you have removed the effort of remembering and booking later. If they cannot commit, agree on a date to check back: "No problem — I'll message you in five weeks to find a time."

Track your rebooking rate: of the customers you served this month, how many left with their next appointment booked? If the answer is under half, this one habit is the biggest opportunity in your business.

### Step 2: Reminders that respect the customer

Reminders prevent no-shows and bring customers back. The best reminder system is simple and timely:

- **Confirmation:** A message the day before the appointment confirming the time and asking the customer to reply if anything has changed.
- **Reminder:** For regular customers, a message a few days before their usual interval is up: "It's been about six weeks since Milo's last groom — would you like his usual slot on Thursday?"
- **Follow-up:** A short message after the service, thanking them and confirming the next date if one was booked.

Use the channel the customer prefers — text message usually gets the fastest response, but some customers prefer email or a messaging app. Keep messages short, warm, and specific to their dog. A message that says "Hi Sarah, Bella's groom is booked for Thursday at 10am — see you then!" is better than a generic "Your appointment is tomorrow."

### Step 3: Notice when customers go quiet

Every business has customers who stop coming without saying why. Some moved away, some found another provider, and some simply got out of the habit. A short, friendly check-in can bring a surprising number of them back:

> "Hi Emma, we haven't seen Rocky for a while and wanted to check in — is everything all right? We'd love to see him again if you'd like to book a groom. No pressure at all, just wanted to say hello."

Send this kind of message once, politely, to customers who have not booked in twice their usual interval. Do not send it repeatedly, and do not offer a discount in the first message — the check-in itself is the gesture. If they reply, you have learned something useful. If they do not, you have spent two minutes and can move on.

Keep a simple list: customer name, dog's name, usual interval, last visit date, and next contact date. Review it weekly. This list is one of the most valuable assets in your business, because every name on it is a customer who already trusts you.

### Step 4: Make staying worthwhile

Customers stay when the experience is consistently good and when they feel recognised. Small touches matter more than grand gestures:

- Remember the dog's name, its preferences, and any quirks — and show that you remember. "Bella likes the blue bandana, doesn't she?" costs nothing and means a great deal.
- Note the details: coat condition, skin sensitivity, favourite treat, nervous habits. A short note after each visit, kept in a notebook or a simple customer record, lets you pick up exactly where you left off.
- Celebrate milestones: a dog's birthday, a first anniversary as a customer, a puppy's first full groom. A short message or a small treat on those days builds a relationship that price alone cannot break.
- Offer a simple loyalty benefit that rewards regulars without complicating your pricing — for example, every tenth groom includes a free nail trim, or regular walkers get priority booking over holiday periods. Keep it simple enough to explain in one sentence.

### Step 5: Handle complaints as retention opportunities

A customer who complains and is handled well often becomes more loyal than a customer who never had a problem. When something goes wrong — a cut shorter than expected, a late arrival, a miscommunication — respond quickly, listen properly, apologise sincerely, and fix what you can. Then follow up a few days later to check that the customer is happy. That follow-up is what turns a complaint into a story the customer tells their friends about how well you handled it.

Do not argue about whose fault it was. Do not blame the dog. Do not ignore the complaint and hope it goes away. A complaint handled badly loses a customer and can cost you several more through word of mouth. A complaint handled well can keep a customer for years.

### The retention worksheet

The workbook includes a retention and rebooking worksheet. Use it to record your rebooking rate, your quiet-customer list, and your reminder schedule. Review it every Monday morning — ten minutes is enough to see who needs a reminder, who needs a check-in, and which slots are still empty this week.

### Module 7 action steps

1. Start rebooking before every customer leaves.
2. Set up confirmation and interval reminders for every service.
3. List your quiet customers and send one friendly check-in to each.
4. Record one personal detail about every dog you serve, and use it next time.
5. Track your rebooking rate monthly and aim to improve it by a few points each quarter.

---

## Module 8 — Pricing and Upsells: Charging What the Work Is Worth

### Why pricing is a marketing decision

Price is not just a number on a list. It is a signal. A price that is far below every competitor tells customers the service may be rushed or inexperienced. A price that is far above, with no explanation, tells them it may not be worth it. A clear, confident price, explained in terms of what the customer gets, tells them the business knows its value — and customers trust businesses that know their value.

Many pet business owners undercharge because they feel guilty charging friends and neighbours, or because they are afraid of losing customers. The result is predictable: long hours, thin margins, no money for marketing, and eventually burnout. This module is about pricing honestly, explaining your prices clearly, and offering extras that genuinely help the customer and the dog.

### Step 1: Know your real costs

Before you set a price, you need to know what a service actually costs you. Many owners know their headline price but have never added up the costs behind it. Work it out for your most common service:

- **Direct costs:** shampoo, products, treats, consumables, and any per-service supplies.
- **Time:** how long the service takes, including setup, the service itself, cleanup, and messaging the customer. Multiply the hours by the hourly rate you need to earn to cover your living costs and your business overhead.
- **Overheads:** a share of rent, utilities, insurance, transport, phone, booking software, and marketing. Divide your monthly overheads by the number of services you do in a month to get a per-service share.
- **Taxes and fees:** set aside a realistic share for tax and any payment processing fees.

Worked example — a groomer:

A full groom takes 2 hours including setup and cleanup. Products cost $6 per groom. Monthly overheads (rent share, insurance, utilities, phone, booking software) total $800, and the groomer completes 80 grooms a month, so the overhead share is $10 per groom. Payment fees average $2. Total direct cost per groom is therefore $18 before the groomer's own time. If the groomer needs to earn $30 an hour to cover living costs, tax, and a modest profit, the labour cost is $60. The true cost of the groom is $78. A price of $65 would lose money on every groom. A price of $85 leaves a small margin. This is an illustrative example — your numbers will differ — but the method is the point: price from your costs, not from a guess or from copying the cheapest competitor.

Do this calculation for each main service, using your own figures. If the result surprises you, that surprise is valuable information. Many businesses discover they have been working for less than minimum wage on some services.

### Step 2: Price by value, not by the hour alone

Once you know your costs, price by the value the customer receives, not only by your time. A calm groom for an anxious dog is worth more than a quick groom for an easy dog, because it requires more skill, patience, and care. A reliable walker who sends a photo report every day is worth more than a walker who simply turns up. Your prices should reflect that difference.

Practical steps:

- Set a starting price ("from $X") for each service, and explain what affects the final price: size, coat condition, temperament, and time needed. Customers accept variable pricing when the reasons are explained upfront.
- Charge more for genuinely harder work: matted coats, reactive dogs, large breeds, and out-of-hours services. State these surcharges clearly before the service, not as a surprise at payment.
- Review your prices at least once a year. Costs rise; if your prices do not, your margin quietly disappears. A small annual increase, explained honestly ("our prices are increasing slightly from next month to reflect rising costs"), is accepted by most regular customers far more easily than a large increase after three years of standing still.

### Step 3: Present prices clearly

Customers fear hidden costs more than high prices. List your starting prices on your Google Business Profile, your website, and your booking page. When a customer enquires, confirm the expected price before the service starts. A customer who knows the price in advance and chooses to book is a customer who will not argue about it afterwards.

If you do not want to publish exact prices, publish starting prices and a clear explanation of what changes them. Do not hide prices entirely — a business with no prices visible forces every customer to ask, and many will simply choose a competitor who told them upfront.

### Step 4: Upsells that genuinely help

An upsell is an additional service or product offered to a customer because it would genuinely benefit them or their dog. It is not a trick, and it is not pressure. The difference is intent and honesty: offer something useful, explain why it would help, and accept "no" gracefully.

Upsells that work well for pet businesses:

- **Grooming:** a de-shedding treatment for a heavy-coated dog, a paw balm in winter, a teeth-brushing add-on, a flea and tick treatment where appropriate and permitted.
- **Walking and daycare:** an extra walk on long days, a longer walk for high-energy dogs, a photo package, or a weekend walk add-on.
- **Sitting:** an extra visit per day for a puppy or a senior dog, a garden tidy or plant watering while the owner is away, a mid-stay photo update package.
- **Training:** a follow-up session, a written training plan, or a short video summary of the session for the owner to practise with.

Offer one relevant extra per visit, at most. Explain it in one sentence: "Bella's coat is quite thick at the moment — a de-shedding treatment today would help with the loose hair at home, and it's $12 extra. Would you like me to add it?" If the customer says no, smile and move on. A customer who feels pressured will not come back, and no upsell is worth losing a regular.

### Step 5: Packages and bundles

Packages encourage regular bookings and give customers a small saving for committing. Keep them simple:

- A block of five walks paid in advance, with a small discount on the total.
- A grooming package: full groom plus a bath-and-tidy between grooms, at a set price.
- A puppy package: first groom, second groom, and a training introduction, bundled for new puppy owners.

Set clear terms: how long the package is valid, whether it can be transferred, and what happens if an appointment is cancelled. Simple terms prevent awkward conversations later. Packages also improve your cash flow, because you are paid in advance for work you will do over the coming weeks.

### Module 8 action steps

1. Calculate the true cost of each main service using your own figures.
2. Set or revise your starting prices, and publish them.
3. Write down one relevant upsell for each service, with a one-sentence explanation.
4. Design one simple package for your most popular service.
5. Review your prices annually, and never apologise for charging fairly for good work.

---

## Module 9 — Paid Ads Basics: Small, Local, Measurable Campaigns

### When paid ads make sense — and when they do not

Paid advertising is not the first step in marketing a pet business. It is a later step, for a business that already has a complete Google profile, good reviews, a clear offer, and a way to take bookings. Advertising a business with no reviews and no booking page is like paying to send people to an empty shop. Fix the foundations first (Modules 1–4), then consider ads.

When the foundations are in place, a small, local paid campaign can work well — particularly when you have a specific goal, such as filling slots in a quiet month, launching a new service, or promoting a seasonal offer. This module covers the basics. It is not a complete course in advertising, and if you scale up spending significantly, consider getting help from someone with local advertising experience. Start small, measure everything, and stop anything that does not produce bookings.

### Step 1: Set a goal and a budget

Every ad campaign needs one goal and one budget. Examples of good goals:

- "Fill four empty grooming slots next week."
- "Get ten enquiries for puppy training classes starting next month."
- "Get twenty new local followers who are pet owners in [Town]."

A vague goal like "get more exposure" cannot be measured and usually wastes money. Pick one goal, write it down, and judge the campaign only against that goal.

Set a budget you can afford to lose. A reasonable starting test budget for a local pet business is a small daily amount — for example, $5 to $10 a day for two weeks — on one platform, for one offer. That is enough to learn whether the ad produces enquiries. Do not spend money you need for rent or supplies, and do not commit to a monthly advertising contract before you have tested a small campaign yourself.

### Step 2: Choose one platform

For most local pet businesses, the two realistic options are Google Ads (showing when someone searches for your service) and Meta ads on Facebook and Instagram (showing to local pet owners based on interests and location). Each suits a different goal:

- **Google Ads** work well when the customer is already searching — "dog groomer near me," "puppy training [Town]." The customer has intent, so the enquiry rate is usually higher, but the cost per click is also usually higher.
- **Meta ads** work well for awareness and for offers — a new puppy class, a seasonal grooming offer, a video of your work shown to dog owners within a few miles. The customer was not searching, so the enquiry rate is lower, but the cost to reach people is usually lower too.

Start with one platform and one campaign. Do not run both at once while you are learning — you will not know which one produced the result.

### Step 3: Target locally and specifically

The most common paid-ads mistake for a local business is targeting too widely. An ad shown to the whole country is money wasted. Target narrowly:

- **Location:** Your town plus a realistic travel radius — usually 5 to 10 miles for grooming and daycare, slightly wider for sitting and training if customers will travel.
- **Audience:** Pet owners, by interest or by behaviour, within that radius. On Meta, that means interests such as dogs, dog grooming, and pet care. On Google, it means the search terms themselves.
- **Offer:** One clear offer, not a list of everything you do. "Puppy's first groom — gentle introduction, $35, this month only" is a better ad than "We offer grooming, walking, sitting, and training."

### Step 4: Write an ad that earns the click

A good local ad has five elements:

1. **A clear headline** naming the service and the place: "Calm Grooming for Anxious Dogs in [Town]."
2. **A photo or short video of your real work** — not a stock photo.
3. **One benefit** the customer cares about: a calm experience, a photo update, a convenient booking.
4. **A specific offer or next step:** a price, a limited availability note, or a booking link.
5. **A single call to action:** "Book online" or "Message us to book."

Do not use clickbait, exaggerated claims, or promises you cannot keep. Do not claim to be the best, the cheapest, or the only option. Follow the advertising policies of the platform — in particular, do not make health claims, do not use before-and-after photos in ways the platform prohibits, and do not target children.

### Step 5: Send clicks somewhere that converts

An ad is only as good as the page it sends people to. Send ad clicks to a page that matches the ad exactly: if the ad is about puppy's first groom, the page should be about puppy's first groom, with its price, what happens, and a booking button at the top. Sending people to a generic homepage is the fastest way to waste an advertising budget.

Make sure the page loads quickly on a phone, the booking button is obvious, and the phone number is visible. If you use a booking system, test the full booking journey yourself from an ad click before you spend any money.

### Step 6: Measure, decide, and stop if it is not working

Track these numbers for every campaign:

- How much did you spend?
- How many clicks did you get, and what did each click cost?
- How many enquiries or bookings came from the campaign? (Ask every new enquirer how they found you, and keep a simple record.)
- What did each enquiry cost? (Total spend divided by number of enquiries.)
- What did each booking cost? (Total spend divided by number of bookings.)

Then compare the cost per booking with the value of a booking. If a campaign cost $100 and produced four bookings, each booking cost $25 to acquire. If the average customer from that campaign is worth $300 over a year, the campaign was worthwhile. If the campaign cost $100 and produced no bookings, stop it, look at what went wrong — was the offer unclear, the targeting too wide, the landing page too slow? — fix one thing, and test again with a small budget. Do not keep spending on a campaign that is not producing bookings in the hope that it will improve on its own. It usually will not.

### Module 9 action steps

1. Confirm your foundations are ready (profile, reviews, booking page) before spending on ads.
2. Choose one goal, one platform, and one offer.
3. Set a small test budget you can afford.
4. Target narrowly — your town and a realistic radius.
5. Track spend, clicks, enquiries, and bookings, and calculate your cost per booking.
6. Keep what works, fix one thing at a time, and stop what does not work.

---

## Module 10 — Your 90-Day Marketing Plan: Putting It All Together

### Why 90 days

A single week of marketing effort produces little. Ninety days of steady, small actions produces a visible change: more reviews, a stronger profile, a fuller book, and a set of habits you can repeat. This module turns the previous nine into a day-by-day and week-by-week plan. The full calendar is in the workbook and in the templates folder (90-day-marketing-calendar.md). This module explains how to use it.

### The rhythm: daily, weekly, monthly

**Daily (10–15 minutes):**
- Reply to any new messages, comments, and reviews.
- Post a story or a short update if something worth sharing happened.
- Check tomorrow's bookings and confirm any that need confirming.

**Weekly (about 2 hours, spread across the week):**
- Publish three to five social media posts (proof, education, personality, booking).
- Publish one Google Business Profile post.
- Ask every happy customer for a review.
- Send rebooking reminders and quiet-customer check-ins.
- Review the week's bookings: what filled, what did not, and why?

**Monthly (about 2 hours):**
- Add new photos to your Google profile and check your hours, services, and prices.
- Review your numbers (see Appendix B): enquiries, bookings, reviews, rebooking rate, and cost per booking if you ran ads.
- Write or update one helpful local content page.
- Approach one new local partner or attend one local event.
- Plan next month's offers and availability posts.

### The 90-day structure

**Days 1–30: Foundations.**
Complete your positioning statement, your Google Business Profile, and your NAP consistency check. Start asking for reviews and rebooking before customers leave. Publish your first four social media posts and your first Google post. Set up your review-request templates and your quiet-customer list. This is the least glamorous month and the most important — everything later depends on it.

**Days 31–60: Visibility.**
Publish helpful local content, list your business in directories, and start your referral programme. Approach two local partners. Increase your social media rhythm to a steady three to five posts a week. Run your first small, careful paid test only if your foundations are solid and you have a specific offer. By the end of this month you should see more Google profile views, more reviews, and more enquiries mentioning Google or a referral.

**Days 61–90: Growth and review.**
Review what worked and what did not. Which posts produced enquiries? Which partnership sent customers? What is your rebooking rate now compared with Day 1? Double down on the two or three activities that produced the most bookings, and drop or fix the ones that produced nothing. Plan the next 90 days using the same calendar, keeping the habits that worked and changing only one or two things at a time.

### What success looks like after 90 days

Be realistic. After 90 days of steady work, a reasonable outcome for a small pet business is: a complete and active Google profile, noticeably more reviews, a steady flow of enquiries from Google and referrals, a higher rebooking rate, and a clearer understanding of which marketing activities actually produce bookings for your business. It is not a promise of a specific number of clients or a specific income. Some businesses will see faster results because they are in a busy area or have few competitors; others will see slower results because the market is crowded or seasonal. What matters is that the system is running, the numbers are improving, and you know what to do next.

### Keeping it going

Marketing is not a project with an end date. It is a habit, like cleaning your premises or ordering supplies. After your first 90 days, repeat the calendar with small changes: new photos, new reviews, new content, new partners. The work gets faster each quarter because the foundations are already built — you are maintaining a system, not building one from scratch. Protect two hours a week for marketing in your diary, the same way you protect time for your customers. A business that markets consistently, even modestly, will over time outperform a business that markets in bursts and then stops.

### Module 10 action steps

1. Print or copy the 90-day marketing calendar from the workbook.
2. Block your daily 15 minutes and your weekly 2 hours in your diary now.
3. Work through Days 1–30 before worrying about Days 31–90.
4. Review your numbers at Day 30, Day 60, and Day 90 — and write down what you learned.
5. Start your next 90 days the following Monday, keeping what worked.

---

## Appendix A — Sample Monthly Marketing Budget

This is an illustrative example for a small pet grooming business, to show how a modest budget can be allocated. Your figures will differ. The point is to plan deliberately and to track what each item produces, not to spend a specific amount.

| Item | Monthly cost (illustrative) | Notes |
|---|---|---|
| Google Business Profile | $0 | Free. Your time: about 1 hour a month. |
| Social media (organic) | $0 | Free. Your time: about 8 hours a month. |
| Review-request messages | $0 | Text and email you already pay for. |
| Referral credits (estimated) | $30 | Based on two successful referrals a month at $15 each. Only spent when a referral actually books. |
| Printed cards / leaflets | $15 | A small batch of referral cards and a few leaflets for partners. |
| Local event or community stall | $25 | Averaged across the year — some months $0, some months more. |
| Paid ads test (optional) | $100 | $5 a day for 20 days, one platform, one offer. Only when foundations are ready. |
| Booking software | $20 | A simple booking system, if you use one. |
| **Total** | **$190** | **Of which $100 is an optional ads test.** |

Without the optional ads test, the cash cost is about $90 a month, plus your time. That is the honest shape of marketing for a small pet business: mostly time and consistency, with a modest cash budget for the things that genuinely need paying for. If your budget is smaller, start with the free items — profile, reviews, rebooking, referrals — and add paid items only when the free ones are working.

## Appendix B — Tracking Sheet: The Five Numbers That Matter

Do not track twenty metrics. Track five, once a month, and write them down:

1. **Enquiries:** How many new people contacted you this month, and where did they say they found you?
2. **Bookings:** How many of those enquiries became bookings?
3. **Reviews:** How many new reviews did you receive, and what is your average rating?
4. **Rebooking rate:** Of the customers you served, what percentage left with their next appointment booked?
5. **Cost per booking (if you ran ads):** Total ad spend divided by bookings from ads.

Record these in the workbook each month. Over three months, the trend tells you more than any single month's numbers. Rising enquiries, a steady rebooking rate, and a growing review count mean the system is working. Flat numbers mean something needs attention — usually the foundations in Modules 1 to 4.

---

## Appendix C — Two Illustrative Walkthroughs

These are fictional, illustrative examples built from the methods in this course. They show how the pieces fit together for different types of pet business. No results are promised — they are planning examples, not predictions.

### Walkthrough 1: A groomer with empty Tuesdays

Maya runs a one-person grooming salon in a suburban town. She is fully booked on Fridays and Saturdays but her Tuesdays and Wednesdays are half empty. She has 12 Google reviews, a profile with six photos, and an Instagram account she posts on when she remembers.

Following this course, Maya starts with positioning. Looking at her last twenty customers, she notices her happiest clients are owners of doodles and spaniels whose coats need regular, skilled care — and that several of them mentioned their previous groomer rushed the job. Her positioning becomes: calm, unhurried grooming for doodle and spaniel coats, one dog at a time, with a photo after every groom.

In week one she completes her Google Business Profile: correct category, full services with starting prices, 24 new photos of her salon and her recent grooms, and five questions with answers. She starts asking every happy customer for a review within an hour of the groom, using a short text template with her review link. She also starts rebooking before customers leave, offering the next slot six weeks ahead.

In weeks two to four she posts three times a week on Instagram: a before-and-after groom on Monday, a short coat-care tip on Wednesday, and a booking post on Friday naming the specific open slots — "Two slots left next Tuesday." She tags her town on every post. She prints simple referral cards offering the referrer and the new customer a $15 credit each, and hands one to every happy customer.

By the end of the first month she has added several reviews, her profile views have risen, and her Tuesday bookings have started to fill — not because of one clever trick, but because the profile, the reviews, the rebooking habit, and the weekly booking posts are all working together. In month two she approaches the local pet shop about leaving cards at the counter, and writes a short page for her website answering "How often should a doodle be groomed?" In month three she reviews her numbers: which posts produced enquiries, what her rebooking rate is now, and whether Tuesdays are still the weak spot. She keeps the activities that produced bookings and drops the ones that did not.

### Walkthrough 2: A dog walker starting from scratch in a new neighbourhood

Tom has just moved to a new town and started a dog-walking business. He has no local reputation, no reviews, and three regular dogs from a friend's referral. His challenge is different from Maya's: he needs to be found and trusted by strangers, quickly, on a small budget.

Tom's positioning is deliberately narrow: reliable midday walks for busy owners in two specific neighbourhoods, same walker every day, with a photo and walk report after every walk. He does not try to serve the whole town at once — he concentrates on the area he can walk to, so his service is genuinely local and his travel time stays low.

He sets up his Google Business Profile as a service-area business, lists his two neighbourhoods, and uploads photos from his actual walks. He creates a simple booking page with his prices and his service area clearly stated. He joins two local community Facebook groups and, instead of advertising, answers questions helpfully — recommending a local park, explaining what to look for in a walker — and only mentions his business when someone asks for a recommendation.

For his first customers, he over-delivers on the review-worthy moment: a photo mid-walk, a one-line report, and a short message when the dog is home and settled. He asks each happy customer for a Google review and for one introduction to a neighbour with a dog. He offers a local vet and a pet shop a simple arrangement: he will recommend them to his customers, and they can recommend him to theirs.

Tom also plans his time carefully. He knows that walking is his income and marketing is what fills the walking slots, so he protects two hours a week for marketing — one hour for social media and one hour for community and partner conversations — and treats that time as non-negotiable. After 90 days he does not expect a full book; he expects a growing base of regulars, a set of genuine reviews, and a clear picture of which neighbourhood and which activities produce his customers. That foundation is what the second 90 days builds on.

### What both walkthroughs share

Different businesses, different starting points — but the same sequence: position clearly, fix the profile, earn reviews, rebook relentlessly, ask for referrals, and measure what happens. Neither walkthrough relies on a large budget or a viral post. Both rely on steady, local, repeatable actions. That is the whole system, and it is the system this course teaches.

---

## Appendix D — Troubleshooting: When Something Is Not Working

**"I am posting on social media but getting no enquiries."** Check three things: Are your posts reaching local people, or mostly strangers? Is there a clear next step — a booking link or a phone number — in your bio and in the post? Are you posting booking posts, or only cute photos? Proof without an ask rarely produces bookings.

**"I ask for reviews but nobody leaves one."** Check the timing and the friction. Are you asking within an hour, while the customer is happy? Are you sending a direct link, or asking them to search for you? Are you asking in person first, so the message does not feel like an automated request? One small change — asking in person, then sending the link by text within the hour — often doubles the response.

**"My Google profile gets views but few calls."** Check the profile the way a customer sees it: Are your hours correct? Is your phone number right? Do your photos look clean and professional? Do you have recent reviews, and have you replied to them? Is your booking link working? Test it yourself on your phone.

**"Customers come once and never return."** This is usually a rebooking problem, not a marketing problem. Are you booking the next appointment before they leave? Are you sending a reminder when their usual interval is up? Are you checking in with quiet customers? Fix the rebooking habit before spending more on acquiring new customers.

**"A competitor is cheaper and busier."** Competing on price is a race to the bottom. Compete on the experience: the calm groom, the photo update, the reliable walker, the remembered details. Customers who choose on price alone are also the quickest to leave for the next cheaper option. Customers who choose on trust stay.

**"I do not have time for marketing."** Start with fifteen minutes a day: reply to messages and reviews, post one story, confirm tomorrow's bookings. Then protect two hours a week for the weekly tasks. If you truly cannot find two hours, do the highest-value items only — rebooking, review requests, and one Google post a week — and add the rest when you can. A small system done consistently beats a large system done once.

---

*End of course content. Use the companion workbook to work through each module, and the templates folder for ready-to-adapt calendars, scripts, and post templates. Results vary with your local market and effort — the system works when you work it, steadily, for 90 days at a time.*
