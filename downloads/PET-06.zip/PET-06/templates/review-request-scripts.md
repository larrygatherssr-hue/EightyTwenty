# Review-Request Scripts — Pet Business Marketing Mastery

Send your review request within an hour of the service, while the customer is happiest. Ask in person first when you can, then follow up with a message containing your direct review link. Ask once, thank them either way, and do not chase repeatedly. Never offer payment, discounts, or free services in exchange for a review — that is against Google's policies and, in many places, against advertising rules.

Replace the brackets with your details. Keep the tone warm, short, and specific to the dog.

---

## 1. Text message — after a groom

Hi [Customer name], thank you for bringing [Dog's name] in today — [he/she] did wonderfully, and [his/her] [coat/trim] looks great. If you have a moment, a Google review would mean a lot to us — it really helps other owners in [Town] find us. Here is the link: [your Google review link]. Thank you so much!

## 2. Text message — after a walk or sitting visit

Hi [Customer name], [Dog's name] had a lovely [walk / day] today — [one detail, e.g. "we did the riverside route and he met his friend Milo"]. [He/She] is home and settled now. If you have a minute, would you mind leaving us a quick Google review? It helps other local owners find us: [your Google review link]. Thank you!

## 3. Email — after a first visit

Subject: Thank you for [Dog's name]'s first visit

Hi [Customer name],

Thank you for trusting us with [Dog's name] today. [One or two sentences about how the visit went.]

If you were happy with the visit, we would be very grateful for a Google review — it helps other pet owners in [Town] find a [groomer / walker / sitter / trainer] they can trust. You can leave one here: [your Google review link].

We would love to see [Dog's name] again — your next appointment is booked for [date], and we will send a reminder the day before.

Thank you,
[Your name], [Business name]
[Phone number]

## 4. In person — the spoken ask

Use this at handover, when the customer is happy and the dog looks wonderful:

"I'm so glad [Dog's name] did well today. If you have a moment later, a Google review would mean a lot — it really helps other owners find us. I'll send you the link by text so it is easy."

Then send the text within the hour, while the experience is fresh.

## 5. One polite reminder (a few days later, only if needed)

Hi [Customer name], just a quick note — if you had a moment to leave us a Google review after [Dog's name]'s visit, we would really appreciate it: [your Google review link]. No worries at all if not — thank you for choosing us!

Do not send a second reminder. If they do not review, thank them for their custom and move on.

## 6. After a training session or a puppy milestone

Hi [Customer name], [Dog's name] did brilliantly today — [one specific detail, e.g. "he walked past three dogs without pulling"]. We are so pleased with [his/her] progress. If you have a minute, a Google review would mean the world to us: [your Google review link]. Thank you!

---

## Replying to Reviews

### Reply to a positive review

Thank the customer by name, mention something specific, and invite them back. Example:

"Thank you so much, Sarah — Bella was an absolute delight today, and she looked wonderful after her trim. We're so glad the shorter cut is working well for her coat. See you both in six weeks!"

### Reply to a negative review

Stay calm, thank them, apologise that the experience was not what they hoped for, state briefly what you will do, and invite them to contact you directly. Do not argue, do not blame the customer or the dog, and do not reveal private details. Example:

"Thank you for letting us know, James, and I'm sorry Max's groom didn't go as you hoped. We've reviewed what happened and would like to make it right — please call us on [number] or message us directly so we can discuss it. We value your feedback and want every dog to leave happy."

Write the reply, wait an hour, read it again, and then post it. If a review is fake, abusive, or from someone who was never a customer, you can report it to Google — but a thoughtful reply usually matters more than removal.

---

## Review-Request Checklist

- [ ] My Google review link is saved and ready to send.
- [ ] I ask in person when I can, then send the link by text or email within an hour.
- [ ] I ask every happy customer, not just my favourites.
- [ ] I track requests in the workbook's review-request tracker.
- [ ] I reply to every review within 48 hours.
- [ ] I never offer payment or discounts for reviews.
