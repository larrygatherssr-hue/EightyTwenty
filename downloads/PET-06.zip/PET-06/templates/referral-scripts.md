# Referral Scripts — Pet Business Marketing Mastery

Most happy customers would refer a friend if asked — and if given an easy way to do it. Ask when they are delighted, just after a good service. Give them something they can forward in ten seconds. Keep the reward simple and meaningful for both sides, and state the terms clearly.

Replace the brackets with your details, and run the referral math in the workbook (Section 6) with your own prices before you set your reward.

---

## 1. The spoken ask (at handover)

"If you know anyone with a dog who needs a [groomer / walker / sitter], I'd love an introduction — I have [number] slots open [next week / this month]. I'll send you a message you can forward, so it is easy."

## 2. Forwardable text message (for the customer to send a friend)

Hi! I take [Dog's name] to [Business name] in [Town] for [service], and [he/she] is wonderful with [him/her]. If you are looking for a [groomer / walker / sitter], I recommend them — and if you mention my name, we both get [referral reward, e.g. "$15 off"]. You can book here: [booking link]. — [Customer's first name]

## 3. Text message from you to a happy customer

Hi [Customer name], thank you for being such a lovely regular — [Dog's name] is always a pleasure. If you know anyone in [Town] whose dog needs a [groomer / walker / sitter], we would love an introduction. If they book and mention your name, you both get [referral reward]. Here is a message you can forward: [forwardable message or booking link]. Thank you!

## 4. Email to regular customers (once a quarter, at most)

Subject: A thank-you for our regulars — and a way to share it

Hi [Customer name],

Thank you for trusting us with [Dog's name]. Regulars like you are the reason our books stay full, and we appreciate you.

If you know another pet owner in [Town] who is looking for a [groomer / walker / sitter / trainer], we would love an introduction. When they book and mention your name, you both receive [referral reward].

Terms: [state them plainly — for example, "One reward per new customer, credited after their first completed booking."]

You can forward this email, or share our booking page: [booking link].

Thank you,
[Your name], [Business name]

## 5. Referral card (print a small batch — wording for the card)

Front:
[Business name] — [Service] in [Town]
[Phone number] · [Booking link or QR code]

Back:
"Recommended by a friend? Mention their name when you book and you both get [referral reward]. Thank you for trusting us with your dog."

## 6. Asking a local partner for referrals

"Hi, I'm [Your name] from [Business name] — we [service] here in [Town]. I often have customers asking about [their service — for example, a good vet, a pet shop, a dog-friendly café], and I'd love to be able to recommend you. If you ever have customers asking about [your service], I'd be grateful if you'd mention us. Here's a card with our details — and if there's anything we can do for your customers, just let me know."

## 7. Thanking a customer who referred someone

Hi [Customer name], thank you so much for recommending us to [Friend's name] — [their dog's name] had [his/her] first [service] with us today and did wonderfully. Your [referral reward] is [applied / on your account]. We really appreciate you spreading the word!

---

## Referral-Programme Rules to Remember

- Reward both sides — the referrer and the new customer.
- Keep it simple enough to explain in one sentence.
- Make claiming easy: a name, a code, or a card.
- State the terms clearly on the card or message.
- Track every referral: who referred whom, whether they booked, and whether the reward was given.
- Never pay cash for referrals unless you have checked the rules where you operate — service credits are normally straightforward.
- Thank every referrer personally, even if the referral does not book.
