# Pricing and Upsell Playbook — Pet Business Marketing Mastery

This playbook helps you price fairly, explain your prices clearly, and offer extras that genuinely help the customer and the dog. It is a planning tool — use your own costs, your own prices, and your own local currency throughout.

**Disclaimer:** This playbook is educational material. It does not guarantee any income or number of bookings. Results vary with your local market and effort.

---

## Part 1: Know Your True Cost

Work this out for each main service before you set or change a price.

**Formula:**
True cost = products and consumables + overhead share + payment fees + labour (hours × the hourly rate you need to earn)

**Worked example — a groomer (illustrative figures, not a prediction):**
- Time taken, including setup and cleanup: 2 hours
- Products per groom: $6
- Overhead share per groom: $10 (monthly overheads of $800 ÷ 80 grooms)
- Payment fees: $2
- Labour: 2 hours × $30/hour = $60
- True cost: $78
- A price of $65 would lose money on every groom. A price of $85 leaves a small margin.

**Your turn — fill in for each service:**

| Service | Hours | Products | Overhead share | Fees | Labour | True cost | Current price | Margin |
|---|---|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |

If any service loses money, that is important information. Adjust the price, the time it takes, or what is included — do not keep working at a loss.

---

## Part 2: Setting Your Prices

**Rules:**
1. Price from your costs, not from a guess or from copying the cheapest competitor.
2. Use a starting price ("from $X") and explain what changes the final price: size, coat condition, temperament, time needed.
3. Charge more for genuinely harder work: matted coats, reactive dogs, large breeds, out-of-hours services. State surcharges clearly before the service, not as a surprise at payment.
4. Publish your starting prices on your Google Business Profile, your website, and your booking page. Customers fear hidden costs more than high prices.
5. Review your prices at least once a year. A small annual increase, explained honestly, is accepted far more easily than a large increase after years of standing still.

**Price list template:**

| Service | Starting price | What changes the price | Notes |
|---|---|---|---|
|  |  |  |  |
|  |  |  |  |
|  |  |  |  |
|  |  |  |  |

**How to announce a price increase (adapt to your voice):**
"From [date], our prices will increase slightly to reflect rising costs. [Service] will be [new price]. Thank you for your understanding — and for trusting us with your dog."

---

## Part 3: Upsells That Genuinely Help

An upsell is an additional service offered because it would genuinely benefit the customer or the dog. Offer one relevant extra per visit, at most. Explain it in one sentence, and accept "no" gracefully. A customer who feels pressured will not come back.

### Grooming upsells

| Upsell | When to offer it | One-sentence script |
|---|---|---|
| De-shedding treatment | Heavy-coated dog, shedding season | "[Dog's name]'s coat is quite thick at the moment — a de-shedding treatment today would help with the loose hair at home, and it's $[X] extra. Would you like me to add it?" |
| Paw balm | Winter, dry or cracked paws | "[Dog's name]'s paws are a little dry — a paw balm today will protect them on cold pavements, for $[X]. Shall I add it?" |
| Teeth brushing | Owner mentions bad breath, or as a regular add-on | "We can add a teeth brushing today for $[X] — it helps between vet dental checks. Would you like that?" |
| Flea and tick treatment | Where appropriate and permitted in your area | "[Dog's name] is due — would you like us to apply [product] today for $[X]?" |

### Walking and daycare upsells

| Upsell | When to offer it | One-sentence script |
|---|---|---|
| Extra walk on long days | Owner working late, high-energy dog | "You're out late on Thursday — would you like an extra afternoon walk for [Dog's name] so [he/she] isn't alone all day? It's $[X]." |
| Longer walk | High-energy breed, puppy with energy to burn | "[Dog's name] has so much energy — a longer walk on [day] would suit [him/her] well. Shall we try it this week for $[X] extra?" |
| Weekend walk add-on | Regular weekday customer | "Would a Saturday walk help too? We have a slot at [time] for $[X]." |

### Sitting upsells

| Upsell | When to offer it | One-sentence script |
|---|---|---|
| Extra visit per day | Puppy, senior dog, or a dog that needs medication | "For [Dog's name]'s age, an extra midday visit would help — it's $[X] per day extra. Would you like me to add it?" |
| Photo update package | Owner travelling, anxious about leaving the dog | "I can send you a morning and evening photo update while you're away, so you can see how [Dog's name] is doing — $[X] for the stay." |

### Training upsells

| Upsell | When to offer it | One-sentence script |
|---|---|---|
| Follow-up session | End of a session, clear next step | "Let's book a follow-up in two weeks to build on today's progress — [day/time] works, and it's $[X]." |
| Written training plan | Owner wants to practise at home | "I can write up today's plan so you can practise at home — $[X], and it includes the exercises we did today." |
| Video summary | Owner wants a reminder of the techniques | "I'll film a short summary of today's session for you to follow at home — $[X]." |

---

## Part 4: Simple Packages

Packages encourage regular bookings and give customers a small saving for committing. Keep them simple, with clear terms.

**Package template:**
- Package name:
- What is included:
- Price (and the saving versus buying separately):
- Valid for: [time period]
- Terms: [cancellations, transfers, expiry]

**Package ideas:**
- Five midday walks paid in advance, with a small discount on the total.
- Full groom plus a bath-and-tidy between grooms, at a set price.
- Puppy package: first groom, second groom, and a training introduction, bundled for new puppy owners.

**Rules for packages:**
- Keep the terms simple enough to explain in one sentence.
- State the validity period and the cancellation policy upfront.
- Do not oversell packages to customers who may not use them — an unused package is a refund request waiting to happen.

---

## Part 5: Pricing Checklist

- [ ] True cost calculated for each main service.
- [ ] Starting prices published (Google profile, website, booking page).
- [ ] Surcharges for harder work stated clearly in advance.
- [ ] One upsell written for each service, with a one-sentence script.
- [ ] One simple package designed for the most popular service.
- [ ] Next annual price review date set: ______
