# 90-Day Marketing Calendar — Pet Business Marketing Mastery

Adapt this calendar to your business, your town, and your services. The pattern repeats every quarter: foundations, visibility, then growth and review. Daily tasks take about 15 minutes; weekly tasks take about 2 hours spread across the week.

**Daily (every working day):** Reply to new messages, comments, and reviews. Post a story if something worth sharing happened. Confirm tomorrow's bookings.

**Weekly:** Publish 3–5 social posts, 1 Google Business Profile post, ask every happy customer for a review, send rebooking reminders and quiet-customer check-ins, review the week's bookings.

---

## Days 1–30: Foundations

### Week 1
- **Day 1:** Complete the Marketing Audit in the workbook. List your last 20 customers and identify your best-fit audience.
- **Day 2:** Write your positioning statement. Rewrite each service as a customer outcome.
- **Day 3:** Claim and verify your Google Business Profile. Check your primary category.
- **Day 4:** Complete every profile field — name, address/service area, phone, hours, services, prices, description.
- **Day 5:** Upload your first 10 photos. Take new ones if needed — clean premises, your work, happy dogs (with permission).
- **Day 6:** Write your review-request templates and save your Google review link. Write your rebooking script.
- **Day 7:** Rest and review. Publish your first Google post and your first social post (a proof post).

### Week 2
- **Day 8:** Upload 10 more photos to your profile (20 total). Add your 5 FAQs with answers.
- **Day 9:** Fix your NAP details so they match exactly everywhere (Google, website, Facebook, Instagram, email signature).
- **Day 10:** Check your website or booking page against the Module 3 checklist. Fix the booking link and test it on your phone.
- **Day 11:** Start rebooking before every customer leaves. Start asking every happy customer for a review within an hour.
- **Day 12:** Social post — education (answer a question customers ask). Google post — a service or availability update.
- **Day 13:** List your business in your first local or pet directory.
- **Day 14:** Review the week: how many reviews did you ask for? How many rebookings? Write the numbers down.

### Week 3
- **Day 15:** Social post — proof (before-and-after or a happy customer, with permission). Story — a behind-the-scenes look at your day.
- **Day 16:** Write your referral offer and run the math with your own prices (workbook Section 6).
- **Day 17:** Create your forwardable referral message and print or save referral cards.
- **Day 18:** List your business in a second directory. Plan your first helpful local content page.
- **Day 19:** Social post — booking post naming specific open slots. Google post — same offer.
- **Day 20:** Send check-ins to quiet customers (those who have not booked in twice their usual interval).
- **Day 21:** Review the week. Record your numbers in the monthly tracker.

### Week 4
- **Day 22:** Social post — personality (why you started, or a day in your life). Update your story highlights.
- **Day 23:** Write your first helpful local content page (for example, "What to expect at your dog's first groom").
- **Day 24:** Approach your first local partner (vet, pet shop, café, or trainer). Keep it friendly and useful first.
- **Day 25:** Calculate the true cost of each main service (workbook Section 8). Check your prices.
- **Day 26:** Social post — education. Google post — a tip or a seasonal reminder.
- **Day 27:** Review your Google profile: hours, photos, questions, reviews — all current?
- **Day 28–30:** **Day 30 review.** Record your baseline numbers: enquiries, bookings, reviews, average rating, rebooking rate. Write down what worked and what did not. Plan Month 2.

---

## Days 31–60: Visibility

### Week 5
- **Day 31:** Publish your local content page. Share it on social media.
- **Day 32:** Launch your referral programme — tell every happy customer about it this week.
- **Day 33:** Social post — proof. Story — a customer success (with permission).
- **Day 34:** Approach a second local partner.
- **Day 35:** Social post — booking post. Google post — availability for the coming weeks.
- **Day 36:** List your business in a third directory.
- **Day 37–38:** Review the week. Check your Google profile insights — views, calls, direction requests.

### Week 6
- **Day 39:** Social post — education (coat care, training tip, or what to pack for daycare).
- **Day 40:** Write your second local content page.
- **Day 41:** Attend or support a local pet or community event, or plan one for this quarter.
- **Day 42:** Social post — personality. Ask a question in your caption to encourage replies.
- **Day 43:** Review your quiet-customer list and send check-ins.
- **Day 44:** Google post — a new photo set or a seasonal offer.
- **Day 45:** Review the week and your numbers.

### Week 7
- **Day 46:** Social post — proof (a transformation or a progress story over several sessions).
- **Day 47:** Design one simple package for your most popular service (workbook Section 8).
- **Day 48:** Write one relevant upsell script for each service and practise saying it naturally.
- **Day 49:** Social post — booking post with a clear call to action.
- **Day 50:** Check your prices against your true costs. Note your next price review date.
- **Day 51:** Google post — a review highlight (with permission) or a service update.
- **Day 52:** Review the week. Which posts produced enquiries? Do more of those.

### Week 8
- **Day 53:** Social post — education. Share a local dog-friendly place or route.
- **Day 54:** Approach a third local partner, or follow up with the first two.
- **Day 55:** Only if your foundations are solid: plan one small paid-ads test — one goal, one platform, one offer, small budget (Module 9).
- **Day 56:** Social post — personality or behind the scenes.
- **Day 57:** Refresh your Google photos — add 5 new ones and remove any that are out of date.
- **Day 58–60:** **Day 60 review.** Record your numbers. Compare with Day 30. What improved? What needs attention? Write your plan for Month 3.

---

## Days 61–90: Growth and Review

### Week 9
- **Day 61:** Double down on the two activities that produced the most bookings so far.
- **Day 62:** Social post — proof. Google post — availability.
- **Day 63:** Write your third local content page, or update your best-performing one.
- **Day 64:** Send referral cards or messages to your happiest customers.
- **Day 65:** Social post — booking post. Mention a specific date or a limited number of slots.
- **Day 66:** Review your rebooking rate. If it is under half, focus on rebooking before customers leave this week.
- **Day 67:** Review the week.

### Week 10
- **Day 68:** Social post — education.
- **Day 69:** Check in with partners — what have they sent you, and what have you sent them?
- **Day 70:** Attend a local event or support a local rescue fundraiser.
- **Day 71:** Social post — personality. Thank your regular customers publicly (without naming anyone who prefers privacy).
- **Day 72:** Google post — a seasonal reminder (holiday bookings, summer coats, winter paw care).
- **Day 73:** Review your quiet-customer list again.
- **Day 74:** Review the week and your numbers.

### Week 11
- **Day 75:** Social post — proof (before-and-after).
- **Day 76:** Review your paid-ads test if you ran one. Keep it, fix one thing, or stop it.
- **Day 77:** Update your website or booking page with your best recent review (with permission).
- **Day 78:** Social post — booking post.
- **Day 79:** Plan next quarter's offers and availability posts.
- **Day 80:** Google post — a service update or a new photo set.
- **Day 81:** Review the week.

### Week 12
- **Day 82:** Social post — education (a seasonal tip).
- **Day 83:** Thank your top referrers personally.
- **Day 84:** Refresh your story highlights and your bio.
- **Day 85:** Social post — proof. Google post — a final availability update for the quarter.
- **Day 86:** Tidy your records: review tracker, referral tracker, monthly numbers.
- **Day 87–89:** **Day 90 review.** Record all five numbers (enquiries, bookings, reviews, rebooking rate, cost per booking). Compare Day 1, Day 30, Day 60, and Day 90. Write down: what worked best, what produced nothing, and what you will change next quarter.
- **Day 90:** Start your next 90 days the following Monday, keeping what worked and changing only one or two things.

---

*Results vary with your local market and effort. The calendar works when you work it steadily — a little every day, for 90 days at a time.*
