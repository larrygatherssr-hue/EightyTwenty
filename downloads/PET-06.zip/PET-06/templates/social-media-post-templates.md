# 30 Social Media Post Templates — Pet Business Marketing Mastery

Adapt every template to your voice, your town, and your real work. Replace the brackets with your details, use your own photos, and never post a template word for word without making it yours. Tag your location on every post. Each template is labelled by type: Proof, Education, Personality, or Booking.

**Disclaimer:** These templates are starting points. Do not make claims you cannot support, and do not promise results you cannot control. Results vary with your local market and effort.

---

## Proof Posts (show your work)

1. **Before and after.** "Before and after for [dog's name] today here in [Town]. [He/She] came in with [coat condition] and left with [result]. [One detail about how the dog did.]" Photo: before and after, same spot, same light.
2. **A calm success.** "[Dog's name] used to be nervous about grooming. Today [he/she] [specific calm behaviour — relaxed on the table, fell asleep, wagged when we arrived]. Slow and patient wins every time."
3. **Progress over time.** "Four sessions in, and look at [dog's name] now. [What changed — walks better on the lead, settles faster, enjoys the groom.] Progress takes patience, and it is worth it."
4. **A happy regular.** "[Dog's name] has been coming to us for [time period]. Today was [service], and [he/she] [a personal detail — favourite treat, favourite spot, funny habit]. We love our regulars."
5. **A puppy milestone.** "[Puppy's name] had [his/her] first [groom / training session / daycare day] today. [How it went, in one or two sentences.] A gentle first experience makes all the difference."
6. **A walk report.** "Today's walk with [dog's name]: [route or park], [distance or time], and [one detail — met a friend, practised recall, found a puddle]. [He/She] is home and settled now."
7. **A transformation with a tip.** "[Dog's name] came in matted under the ears — a common spot owners miss. A quick brush there twice a week prevents it. Today [he/she] left [result]."
8. **A team moment.** "Meet [your name / team member], who [what they do — grooms our doodles, walks our weekday regulars]. [One sentence about their experience or approach.]"

## Education Posts (answer real questions)

9. **Coat care.** "How often should you brush a doodle between grooms? [Your honest answer, in two or three sentences.] If you are unsure, bring [dog] in and we will show you."
10. **Nail trims.** "Three signs your dog needs a nail trim: [sign 1], [sign 2], [sign 3]. We include a nail check with every groom."
11. **First groom prep.** "Bringing your puppy for a first groom? Here is what to expect: [step 1], [step 2], [step 3]. Gentle, short, and positive — that is the goal."
12. **Hot weather.** "Hot day in [Town]? [One or two practical tips — walk early, check the pavement, fresh water.] We adjust walk times on hot days so your dog stays safe."
13. **Winter paws.** "Winter paw care in three steps: [step 1], [step 2], [step 3]. Ask us about paw balm at your next groom."
14. **Choosing a walker.** "Looking for a dog walker in [Town]? Ask these three questions: [question 1], [question 2], [question 3]. The answers tell you a lot."
15. **Separation and settling.** "Does your dog settle when you leave? [One or two signs of a settled dog, and one tip.] A tired dog from a midday walk usually settles better."
16. **Training tip.** "One training tip that works: [a simple, honest tip — short sessions, reward the behaviour you want, practise little and often]. Consistency beats long sessions every time."

## Personality Posts (the human behind the business)

17. **Why you started.** "I started [business name] because [one or two honest sentences]. [What you love about the work.] Thank you to everyone who trusts us with their dogs."
18. **A day in the life.** "A day in our life: [morning setup], [first dog], [lunch break], [last walk]. [One sentence about what makes a good day.]"
19. **Your own dog.** "This is [your dog's name]. [One or two sentences — what they teach you, or a funny habit.] Every dog we look after gets the same care we give [him/her]."
20. **Behind the scenes.** "Behind the scenes: [what you are doing — cleaning the salon, prepping for the week, restocking]. The unglamorous part matters as much as the grooming."
21. **A thank-you.** "Thank you to our regulars — [no names needed, or first names with permission]. You keep our books full and our days happy. We appreciate you."
22. **A local favourite.** "One of our favourite dog-friendly spots in [Town]: [place]. [Why you like it, in one sentence.] Where is your dog's favourite walk?"

## Booking Posts (ask for the booking)

23. **Open slots.** "We have [number] grooming slots left next week: [days/times]. Message us or book online at [link] to grab one."
24. **Seasonal reminder.** "[Season] is coming, and [service] slots are booking up. If your dog needs [service] before [date], now is the time to book: [link]."
25. **New service.** "New: [service name]. [What it is, who it is for, starting price.] [Number] places available this month — message us to book."
26. **Last-minute opening.** "A slot just opened up [day/time] for [service]. First to message gets it: [phone or link]."
27. **Holiday bookings.** "Holiday sitting for [dates] is now [percentage] booked. If you are going away, message us soon — [link]."
28. **Puppy class.** "Our next puppy [training / introduction] starts [date]. [Number] places left. [One sentence about what is included.] Message us to book."
29. **Referral reminder.** "Know someone in [Town] whose dog needs a [groomer / walker / sitter]? If you refer them, you both get [your referral reward]. Just send them our way — [link]."
30. **A simple ask.** "If your dog is due a [groom / walk / training session], we would love to see them. Book online here: [link] — or message us and we will find a time that suits you."

---

## How to use these templates

- **Mix the types.** A healthy week is roughly: 1 proof, 1 education, 1 personality, 1 booking. Do not post booking posts every day, and do not post proof without ever asking for the booking.
- **Use your own photos and videos.** A real photo of a real dog you groomed beats a stock photo every time. Get the owner's permission first.
- **Tag your location and use local hashtags.** Example: #[Town]Dogs, #[Town]Groomer, #[Town]DogWalker — plus a few service tags. Keep hashtags local and relevant.
- **Reply to every comment the same day.** A reply turns a viewer into a conversation, and a conversation into a booking.
- **Track what works.** Note which posts produce enquiries, saves, and shares. Do more of those; do less of the posts that only get likes.
