# PET-06 — Pet Business Marketing Mastery: Fill Your Books with Local Customers

**Price:** $297 (one-time) · **Category:** Pet Products & Pet Business · **SKU:** PET-06

A pet-specific marketing and customer-acquisition system for groomers, sitters, walkers, trainers, and daycare owners — covering positioning, Google Business Profile, local SEO, reviews, social media, referrals, retention, pricing and upsells, paid ads basics, and a 90-day plan.

## Files in This Folder

| File | Description |
|---|---|
| `content.md` | Full course content — 10 modules, appendices, worked examples (10,664 words). |
| `workbook.md` | Companion workbook — marketing audit, checklists, trackers, and worksheets. |
| `templates/90-day-marketing-calendar.md` | Day-by-day 90-day marketing calendar. |
| `templates/social-media-post-templates.md` | 30 social media post templates. |
| `templates/review-request-scripts.md` | Review-request messages and review-reply scripts. |
| `templates/referral-scripts.md` | Referral asks, forwardable messages, and partner scripts. |
| `templates/pricing-upsell-playbook.md` | True-cost calculator, pricing guidance, upsell scripts, package ideas. |
| `sales-page.md` | Full sales page — headline, problem, solution, module list, FAQs, disclaimer. |
| `listing.json` | Marketplace listing data (price 29700 cents, one-time billing). |
| `cover.md` | Cover design brief (black-and-gold luxury branding). |
| `cover.png` | Generated cover image (1120 × 2240 px). |
| `onboarding.md` | Customer onboarding guide — what to do first, schedule, support. |

**Disclaimer:** Results vary with the local market and effort. No client counts or income are guaranteed.
