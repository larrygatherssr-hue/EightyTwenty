# Welcome — Pet Business Marketing Mastery

Thank you for purchasing **Pet Business Marketing Mastery: Fill Your Books with Local Customers**. This guide will help you get started quickly and get the most from the materials.

## What You Received

| File | What it is |
|---|---|
| `content.md` | The full course — 10 modules, plus appendices with a sample marketing budget, a tracking sheet, worked walkthroughs, and troubleshooting. |
| `workbook.md` | The companion workbook — audit, worksheets, checklists, and trackers to fill in as you go. |
| `templates/90-day-marketing-calendar.md` | Your day-by-day plan for the first 90 days. |
| `templates/social-media-post-templates.md` | 30 post templates (proof, education, personality, booking). |
| `templates/review-request-scripts.md` | Review-request messages and reply scripts, including for difficult reviews. |
| `templates/referral-scripts.md` | Referral asks, forwardable messages, and partner outreach scripts. |
| `templates/pricing-upsell-playbook.md` | True-cost calculator, price-setting guidance, upsell scripts, and package ideas. |
| `cover.png` | The product cover image. |
| `sales-page.md` | The full sales page for this product (reference). |
| `listing.json` | The marketplace listing data for this product (reference). |

## What to Do First (Your First Week)

1. **Read the disclaimer and the "How to Use This Course" section** at the top of `content.md`. It explains the pace and the honest limits of the course.
2. **Complete the Marketing Audit** in the workbook (Section 1). It takes about 20 minutes and shows you where to focus first.
3. **Work through Module 1 (Positioning) and Module 2 (Google Business Profile).** These two modules are the foundation for everything else. Do not skip ahead to ads or social media before they are done.
4. **Claim and verify your Google Business Profile** if you have not already. Verification can take days, so start it now.
5. **Save your Google review link** somewhere easy to reach — you will use it every week.

## Suggested Schedule

- **Self-paced, one module per week** is the recommended pace — 10 weeks for the full course.
- **Daily:** about 15 minutes — reply to messages, comments, and reviews; confirm tomorrow's bookings.
- **Weekly:** about 2 hours — publish your social posts and one Google post, ask happy customers for reviews, send rebooking reminders.
- **Monthly:** about 2 hours — review your numbers in the workbook tracker, add new photos, plan next month.
- **The 90-day calendar** in the templates folder turns this into a day-by-day plan. Start on Day 1 and follow it through Day 90, then repeat with what you learned.

## How to Use the Templates

The templates are starting points, not scripts to post word for word. Adapt every one to your voice, your town, and your real work. Replace the bracketed placeholders with your details, use your own photos, and get the owner's permission before posting photos of their pet. Never make claims you cannot support, and never promise results you cannot control.

## How to Get Support

If you have a question about the course materials, your download, or a refund request, contact EightyTwenty marketplace support and include your order number, the product SKU (PET-06), and a description of your question. Please allow up to 2 business days for a reply. Support covers the course materials and delivery; it does not include one-to-one marketing coaching or done-for-you marketing services.

**Refund policy:** 14-day money-back guarantee under the EightyTwenty marketplace refund policy. See the product listing for full terms.

## A Note on Results

This course teaches a system, not a shortcut. Results vary with your local market, competition, service quality, consistency, and effort. No specific number of clients, bookings, or amount of income is promised or guaranteed. The businesses that get the most from this course are the ones that do a little, every week, for 90 days at a time. Start with Module 1, and good luck.
