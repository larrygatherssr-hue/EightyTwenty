# Pet Business Marketing Mastery — Companion Workbook

Use this workbook alongside the course. Print it, or copy it into a notebook or document, and fill it in as you work through each module. The value is in the writing: a completed workbook is a marketing plan, not just a set of notes.

**Disclaimer:** This workbook is educational material. Results vary and depend on your local market, competition, service quality, consistency, and effort. No specific number of clients, bookings, or amount of income is promised or guaranteed. Any figures you write in here are your own planning numbers.

---

## 1. Marketing Audit

Complete this before you change anything. Be honest — the audit is for you, not for anyone else.

**Your business**
- Business name:
- Main service (the one that earns most):
- Other services:
- Town / neighbourhoods served:
- How long have you been operating?
- How many regular customers do you have right now?

**Your current marketing — rate each 1–5 (1 = not done, 5 = done well)**
- Google Business Profile completeness: __ / 5
- Number of Google reviews: ______ Average rating: ______
- Photos on your profile: ______
- Social media activity: __ / 5
- Review requests: __ / 5
- Rebooking before customers leave: __ / 5
- Referral system: __ / 5
- Local partnerships: __ / 5
- Website / booking page clarity: __ / 5
- Pricing clarity: __ / 5

**Where do your customers currently come from?** (Estimate the percentage for each.)
- Word of mouth / referrals: ______%
- Google search / Google Maps: ______%
- Social media: ______%
- Repeat / existing customers: ______%
- Other (write what): ______%

**Your three biggest marketing gaps (from the audit above):**
1.
2.
3.

**Your three best customers — what do they have in common?**
1.
2.
3.

---

## 2. Positioning Worksheet (Module 1)

**My best-fit audience (who I serve best):**

**The outcome they want (in their words):**

**My three pieces of proof:**
1. Experience:
2. Process (what I do differently):
3. Social proof (a genuine client comment, used with permission):

**My positioning statement (under three sentences):**

**Services rewritten as outcomes:**
| Service | Outcome the customer wants | Starting price |
|---|---|---|
|  |  |  |
|  |  |  |
|  |  |  |
|  |  |  |

---

## 3. Google Business Profile Checklist (Module 2)

Tick each item when it is done, and note the date.

- [ ] Profile claimed and verified — Date: ______
- [ ] Primary category correct — Category: ______
- [ ] Secondary categories added — Which: ______
- [ ] Business name exact and consistent — Name: ______
- [ ] Address / service area correct — Details: ______
- [ ] Phone number correct and answered — Number: ______
- [ ] Website / booking link works (tested on a phone) — Link: ______
- [ ] Hours correct, including holidays — Checked: ______
- [ ] Services listed with starting prices — Count: ______
- [ ] Attributes ticked where they honestly apply
- [ ] Description uses my positioning statement
- [ ] At least 20 real photos uploaded — Count: ______
- [ ] First Google post published — Date: ______
- [ ] Five FAQs added with answers
- [ ] Review link saved and ready to send — Link: ______
- [ ] Monthly review reminder set — Date each month: ______

**Photos to add this month:**
1.
2.
3.

**Google posts planned this month:**
1.
2.
3.
4.

---

## 4. Local SEO Checklist (Module 3)

- [ ] NAP details (name, address, phone) written down in one exact version
- [ ] NAP matches on Google profile
- [ ] NAP matches on website / booking page
- [ ] NAP matches on Facebook
- [ ] NAP matches on Instagram
- [ ] NAP matches on email signature
- [ ] Website / booking page states my town and service area in plain text
- [ ] One page per main service exists (or is planned)
- [ ] Booking or contact option visible on every page
- [ ] Website tested on a phone — loads quickly and reads clearly
- [ ] Listed in directory 1: ______ Date: ______
- [ ] Listed in directory 2: ______ Date: ______
- [ ] Listed in directory 3: ______ Date: ______
- [ ] First helpful local content page written — Title: ______
- [ ] Baseline Google profile numbers recorded (see Section 8)

**Content ideas (four to six local questions my customers ask):**
1.
2.
3.
4.

---

## 5. Review-Request Tracker (Module 4)

Record every review request. One polite reminder after a few days is enough — do not chase repeatedly.

| Date | Customer | Dog | Service | Asked? | Review left? | Replied? | Notes |
|---|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |

**Monthly review totals:**
- Reviews requested this month: ______
- Reviews received this month: ______
- Current total reviews: ______ Current average rating: ______

**My review-worthy moment (the small extra built into every service):**

**Best reviews to reuse (with permission) — quote, customer first name, dog's name:**
1.
2.
3.

---

## 6. Referral-Program Planner (Module 6)

**My referral offer:**
- Reward for the referrer:
- Reward for the new customer:
- How it is claimed (code, card, mention a name):
- Any limits or terms:

**Referral math — using my own numbers:**
- My average service price: $______
- How often the average customer books per year: ______ times
- Average yearly value of one customer: $______ (price × times per year)
- Total cost of one referral (both rewards): $______
- If the new customer stays one year, the referral costs $______ to gain $______ of revenue.
- Is the offer worth it? Yes / No — notes:

**Forwardable referral message (write it here, ready to send):**

**Local partners to approach:**
| Business | Contact / who to ask | What I can offer them | Approached? | Result |
|---|---|---|---|---|
|  |  |  |  |  |
|  |  |  |  |  |
|  |  |  |  |  |
|  |  |  |  |  |

**Community events this quarter:**
1.
2.

---

## 7. Retention and Rebooking Worksheet (Module 7)

**My rebooking script (what I say before the customer leaves):**

**My reminder messages:**
- Day-before confirmation:
- Interval reminder (when their usual gap is up):
- Quiet-customer check-in:

**Rebooking rate:**
- Customers served this month: ______
- Customers who left with their next appointment booked: ______
- Rebooking rate: ______%

**Quiet customers — customers who have not booked in twice their usual interval:**
| Customer | Dog | Usual interval | Last visit | Check-in sent? | Result |
|---|---|---|---|---|---|
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |
|  |  |  |  |  |  |

**Personal details I remember about my regular dogs (name, preferences, quirks):**
| Dog | Owner | Likes / needs | Notes |
|---|---|---|---|
|  |  |  |  |
|  |  |  |  |
|  |  |  |  |
|  |  |  |  |

**My loyalty benefit for regulars (one sentence):**

---

## 8. Pricing and Upsell Worksheet (Module 8)

**True cost of my most common service:**
- Service:
- Time taken (including setup and cleanup): ______ hours
- Products / consumables per service: $______
- Overhead share per service: $______
- Payment fees per service: $______
- Labour cost (hours × hourly rate I need): $______
- True cost per service: $______
- Current price: $______
- Margin (price − true cost): $______

Repeat this calculation for each main service. If any service loses money, that is important information — adjust the price, the time, or the offer.

**My prices (starting prices, published):**
| Service | Starting price | What changes the final price |
|---|---|---|
|  |  |  |
|  |  |  |
|  |  |  |
|  |  |  |

**One relevant upsell per service:**
| Service | Upsell | Price | One-sentence explanation |
|---|---|---|---|
|  |  |  |  |
|  |  |  |  |
|  |  |  |  |

**My simple package (one service, bundled):**
- Package name:
- What is included:
- Price:
- Terms (validity, cancellations):

**Next price review date:** ______

---

## 9. 90-Day Marketing Calendar

The full day-by-day calendar is in `templates/90-day-marketing-calendar.md`. Use this page for your monthly summary and review.

**Month 1 (Days 1–30) — Foundations**
- Positioning statement written: [ ]
- Google profile completed: [ ]
- Review requests started: [ ]
- Rebooking habit started: [ ]
- First social posts published: [ ]
- What I learned:

**Month 2 (Days 31–60) — Visibility**
- Local content published: [ ]
- Directories listed: [ ]
- Referral programme launched: [ ]
- Partners approached: [ ]
- What I learned:

**Month 3 (Days 61–90) — Growth and review**
- Numbers reviewed at Day 90: [ ]
- Activities that produced the most bookings:
- Activities that produced nothing (drop or fix):
- Plan for the next 90 days:

**Monthly numbers tracker (complete on the 1st of each month):**

| Month | Enquiries | Bookings | New reviews | Avg rating | Rebooking rate | Ad spend | Cost per booking |
|---|---|---|---|---|---|---|---|
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |

**Where did this month's enquiries come from?**
- Google: ______
- Referrals / word of mouth: ______
- Social media: ______
- Repeat customers: ______
- Other: ______

---

## 10. My 90-Day Commitments

Write down the three habits you will protect, even in a busy week. Keep this page visible.

1. Daily (15 minutes):
2. Weekly (2 hours):
3. Monthly (2 hours):

**My start date:** ______ **My Day 90 review date:** ______

*Results vary with your local market and effort. The workbook works when you work it — a little, every week, for 90 days at a time.*
