# Dog Daycare & Boarding Blueprint — Companion Workbook

Use this workbook alongside the course. Print it or copy it into your own documents. Fill in every worksheet with your own local numbers, quotes, and decisions. A blank worksheet is not a plan.

## Disclaimer

This workbook is education only. It is not legal, veterinary, financial, tax, or insurance advice. Licensing, zoning, and insurance requirements vary by location and must be verified locally. Pet safety content is education only and never replaces veterinary care. No income or outcome is guaranteed.

---

## Worksheet 1 — Startup-Budget Worksheet

Copy the figures from `templates/startup-budget-planner.csv` as you collect quotes. Record the source and date of every quote.

| Category | Budgeted | Quoted / Actual | Variance | Quote source and date |
|---|---|---|---|---|
| Lease deposit | | | | |
| First month's rent | | | | |
| Legal fees (entity + lease review) | | | | |
| Licenses and permits | | | | |
| Insurance — first year | | | | |
| Build-out: flooring and sealing | | | | |
| Build-out: walls, kennels, suites | | | | |
| Build-out: fencing and outdoor yards | | | | |
| Build-out: plumbing and drains | | | | |
| Build-out: HVAC and ventilation | | | | |
| Build-out: electrical | | | | |
| Build-out: soundproofing | | | | |
| Kennel and suite equipment | | | | |
| Play equipment and toys | | | | |
| Commercial washer and dryer | | | | |
| Cleaning equipment and supplies | | | | |
| Office, reception, computers | | | | |
| Booking software setup | | | | |
| Webcams and security cameras | | | | |
| Signage | | | | |
| Branding, website, launch marketing | | | | |
| Initial supplies | | | | |
| **Total one-time costs** | | | | |
| Monthly operating cost (from Module 4) | | | | |
| Months of working capital (target: 6) | | | | |
| **Total startup requirement** | | | | |

**Funding sources**

| Source | Amount | Confirmed? (yes / no) | Notes |
|---|---|---|---|
| Personal savings | | | |
| Loan (lender and status) | | | |
| Partner or investor | | | |
| Equipment financing | | | |
| Other | | | |
| **Total funding available** | | | |
| **Gap (requirement minus funding)** | | | |

If there is a gap, write your decision here: raise more capital / start smaller / phase the opening / delay. Do not proceed with an unfunded gap.

**My decision:** _______________________________________________________________

---

## Worksheet 2 — Facility Checklist

Walk your building with this checklist and a contractor. Check every item or mark it as needing work, with a cost.

- [ ] Zoning confirmed in writing for dog daycare and boarding at this address
- [ ] Conditional-use permit obtained or confirmed not required
- [ ] Kennel or boarding license requirements identified
- [ ] Building size adequate for planned capacity (square feet: ______)
- [ ] Floor drains present or installable in every playroom and kennel area
- [ ] Flooring sealable and non-slip (material chosen: ____________________)
- [ ] HVAC sized for dog load, not just square footage
- [ ] Ventilation and exhaust fans adequate
- [ ] Soundproofing plan in place
- [ ] Outdoor yard space available and fencible (fence height: ______ feet)
- [ ] Double-gated entries possible at every outdoor access point
- [ ] Separate lobby and reception, separated from play areas by a door or gate
- [ ] Two to four separate playrooms possible (sizes: ____________________)
- [ ] Boarding suites area identified (number of suites: ______)
- [ ] Quiet and rest room identified
- [ ] Isolation area identified, away from other dogs
- [ ] Dog wash area with drain identified
- [ ] Kitchen and food-preparation area identified
- [ ] Laundry area identified
- [ ] Locked storage for cleaning chemicals identified
- [ ] Staff break area identified
- [ ] Parking adequate (spaces: ______)
- [ ] Fire exits clear and evacuation route planned
- [ ] Emergency veterinary clinic identified (name, address, phone: ______________)

**Issues found and cost to fix:**

1. ________________________________________________________________________
2. ________________________________________________________________________
3. ________________________________________________________________________

---

## Worksheet 3 — Staffing Planner

**Ratios I will use (write them down and post them):**

- General playgroups: 1 staff per ______ dogs (maximum 15; use 10 for large or high-energy groups)
- Puppy groups: 1 staff per ______ puppies (maximum 10)
- Senior or special-needs groups: 1 staff per ______ dogs (maximum 10)
- Overnight: 1 staff on site per ______ boarding dogs (maximum 25)

**Staffing plan by stage**

| Role | Opening day | At 60% occupancy | At full occupancy |
|---|---|---|---|
| Owner-operator / manager | | | |
| Lead attendant | | | |
| Playroom attendants | | | |
| Overnight caretaker | | | |
| Reception support | | | |

**Payroll model (use the staffing-ratio planner template for the full calculation)**

| Role | Hours per week | Hourly rate | Weekly cost |
|---|---|---|---|
| | | | |
| | | | |
| | | | |
| | | | |
| **Total base payroll per week** | | | |
| **Monthly base payroll (weekly x 4.33)** | | | |
| **Payroll taxes and workers' comp (about 15%)** | | | |
| **Total monthly labor cost** | | | |

**Hiring notes — qualities I will hire for:** calm under pressure, reliable attendance, physically able to lift a 50-pound dog, follows systems, genuinely fond of dogs.

**Training checklist (sign off each topic per hire):**

- [ ] Dog body language and stress signals
- [ ] Safe handling and moving dogs between areas
- [ ] Group management and reading play versus conflict
- [ ] Cleaning and sanitation (dilution and contact time)
- [ ] Feeding and medication logs
- [ ] Emergency procedures (injury, fight, escape, fire, power outage)
- [ ] Customer service and incident reporting

---

## Worksheet 4 — Safety Drill Checklist

Run each drill before opening and on the schedule shown. Record the date, the staff present, and what needs fixing.

| Drill | Frequency | Last run (date) | Staff present | Issues found |
|---|---|---|---|---|
| Fire evacuation (including boarding dogs at night) | Quarterly | | | |
| Dog escape response | Quarterly | | | |
| Dog fight separation (using barriers, never hands) | Before opening, then every 6 months | | | |
| Medical emergency (first aid + vet call) | Before opening, then every 6 months | | | |
| Power outage / severe weather | Annually | | | |

**After every drill, answer:** What worked? What was slow? What do we change?

**Incident log (copy this table for each incident):**

- Date and time: ____________________
- Dogs involved: ____________________
- Staff present: ____________________
- What happened: ____________________
- Care given and veterinary advice: ____________________
- Owners notified (when and by whom): ____________________
- What we will change: ____________________

---

## Worksheet 5 — Pricing Worksheet

**Monthly operating cost (total):** $__________

**Capacity:** Daycare ______ dog-days per month; Boarding ______ dog-nights per month.

**Break-even occupancy:** Daycare ______%; Boarding ______%; Combined ______%.

**My price list**

| Service | Price | Competitor price (lowest / highest) |
|---|---|---|
| Full-day daycare | | |
| Half-day daycare | | |
| 10-day package | | |
| 20-day package | | |
| Boarding — standard suite | | |
| Boarding — premium suite | | |
| Holiday surcharge | | |
| Bath | | |
| Nail trim | | |
| Enrichment session | | |
| Late checkout | | |

**Revenue at occupancy scenarios (use the pricing calculator template):**

| Scenario | Daycare revenue | Boarding revenue | Add-ons | Total revenue | Costs | Profit before loan, draw, tax |
|---|---|---|---|---|---|---|
| 40% occupancy | | | | | | |
| 60% occupancy | | | | | | |
| 80% occupancy | | | | | | |
| 100% occupancy | | | | | | |

**Price-review date (annual):** ____________________

---

## Worksheet 6 — Opening-Week Checklist

**Two weeks before opening**

- [ ] All licenses, permits, and insurance in place and filed
- [ ] Staff hired and training completed, sign-off sheets filed
- [ ] Booking software live with vaccination-expiry reminders set
- [ ] Emergency binder complete (vet clinic, poison control, insurer, owner contacts)
- [ ] Fire evacuation and escape drills run
- [ ] Cleaning schedule posted and supplies stocked
- [ ] Vendor accounts set up (cleaning, pet supplies, laundry, waste)

**Opening week**

- [ ] Trial half-days run for first dogs, assessments recorded
- [ ] Open house held, visitor emails collected
- [ ] Founding-member offer sent to the waitlist
- [ ] Every trial-day owner followed up within 48 hours with a photo
- [ ] Daily closing checklist used every night
- [ ] Overnight handover written every night

**End of week one — review**

- Daycare dogs per day: ______ (target 15–20 by end of month one)
- Boarding nights booked: ______
- Incidents: ______ (describe and review each one)
- Customer feedback themes: ________________________________________________
- What to fix next week: ____________________________________________________

---

## My 8-Week Plan

| Week | Focus | Key tasks | Done? |
|---|---|---|---|
| 1–2 | Decide and budget | Zoning, market research, budget, funding | |
| 3–4 | Secure and build | Lease, build-out, equipment orders | |
| 5–6 | Hire and prepare | Staff, training, protocols, software | |
| 7–8 | Launch | Trial days, open house, opening | |

---

*This workbook is education only and does not replace legal, veterinary, financial, tax, or insurance advice. No income or outcome is guaranteed.*
