# Customer Onboarding Guide — Dog Daycare & Boarding Blueprint

Welcome. This guide tells you what to do first, how to use the materials, and how to work through the course on a suggested 8-week schedule.

## What You Received

- **content.md** — the full 12-module course, written in complete prose. This is the core teaching.
- **workbook.md** — the companion workbook: startup-budget worksheet, facility checklist, staffing planner, safety drill checklist, pricing worksheet, and opening-week checklist.
- **templates/startup-budget-planner.csv** — line-item startup costs, monthly operating costs, working capital, funding, and break-even checks.
- **templates/pricing-packages-calculator.csv** — price list, add-ons, occupancy scenarios, and break-even calculations.
- **templates/facility-layout-checklist.md** — zoning, building, zones, safety, capacity, and parking checklist.
- **templates/staffing-ratio-planner.md** — ratios, staffing by occupancy, payroll model, and new-hire training sign-off.
- **templates/safety-emergency-protocols.md** — emergency contacts, health intake, isolation, fight, escape, fire, medical emergency, severe weather, cleaning, and incident reporting.
- **sales-page.md** — the product's sales page, included for your reference.
- **cover.md** and **cover.png** — the cover design brief and the cover image.
- **listing.json** — the marketplace listing data.
- **README.md** — the index of this folder.

## What to Do First

1. Read the disclaimers at the top of `content.md`. They matter: licensing, zoning, and insurance vary by location, and pet safety content never replaces veterinary care.
2. Read Module 1 and answer its questions honestly: why you want this business, what capital you actually have, and whether you will be the on-site operator in year one.
3. Start the workbook's Worksheet 1 (startup budget) and Worksheet 2 (facility checklist) early — they are working documents, not homework to do at the end.
4. Do not sign a lease, buy a property, or spend money on a build-out until you have written zoning confirmation for your address (Module 3).

## How to Use the Materials

- Work through the modules in order the first time. Each module ends with action steps — do them before moving on.
- Fill in the templates with your own local numbers as you go: your rent, your wage rates, your quotes, your competitor prices. The worked examples in the course use illustrative figures; your decisions must use your numbers.
- Print the safety and emergency protocols and the facility checklist. The protocols belong in the office and in the isolation area, not only on a computer.
- Keep your completed workbook and templates together as your business plan. They are the documents you show a lender, a partner, or your insurance broker.

## Suggested 8-Week Schedule

| Week | Focus | Modules | Key deliverables |
|---|---|---|---|
| 1 | Decide | 1–2 | Decision statement, capital list, trade-area map, competitor table, model and positioning chosen |
| 2 | Budget | 3–4 | Written zoning confirmation, license list, entity formed, insurance quotes, completed startup budget and funding plan |
| 3 | Secure the location | 3, 5 | Lease reviewed by an attorney and signed, floor plan sketched by zones, contractor quotes |
| 4 | Build | 5–6 | Build-out underway, equipment ordered, vendor accounts set up, consumables budget set |
| 5 | Hire and train | 7–8 | Staff hired, training completed with sign-off sheets, ratios posted, intake and assessment procedures written |
| 6 | Safety and systems | 9, 11 | Cleaning schedule posted, emergency binder complete, drills run, booking software live, daily playbook written |
| 7 | Price and launch plan | 10, 12 | Price list set, break-even calculated, waitlist built, veterinarian and groomer visits made, trial days scheduled |
| 8 | Launch | 12 | Trial half-days run, open house held, founding-member offer sent, first bookings taken |

You can move faster if your location and funding are already secured, or slower if you are still raising capital. Do not compress Weeks 1–2: the zoning, budget, and funding decisions protect everything that follows.

## How to Get Support

For questions about your purchase, your download, or a refund within the 14-day guarantee period, email marketplace support with your order number and a description of the issue.

For questions about your business — licensing, zoning, insurance, legal structure, tax, or veterinary matters — contact the appropriate licensed professional in your area. This product is education only and does not replace professional advice.

## A Final Note

Open when you are ready, not a week before. The dogs, and their owners, will be glad you did.
