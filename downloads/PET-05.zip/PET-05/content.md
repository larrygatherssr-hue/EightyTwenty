# Dog Daycare & Boarding Blueprint: Open and Run a Profitable Daycare & Boarding Business

**The complete startup and operations system for a dog daycare and boarding facility — location, licensing, staffing, safety, and pricing.**

---

## Important Disclaimers — Read First

This course is education only. It is not legal, veterinary, financial, tax, or insurance advice, and it does not replace professional advice from a licensed attorney, accountant, insurance broker, veterinarian, or local licensing authority.

- **Licensing, zoning, and permits vary by city, county, and state.** Some jurisdictions require a kennel license, a boarding license, a business license, a conditional-use permit, a fire inspection, and a health or animal-control inspection. Others prohibit boarding in residential zones entirely. Verify every requirement with your local planning department, animal control office, and health department before signing a lease or spending money on a build-out.
- **Pet safety content in this course is safety-focused education, not veterinary care.** Never delay veterinary care for a sick or injured dog. If a dog shows signs of distress, injury, or illness, contact the owner and a veterinarian immediately. This course does not teach you to diagnose or treat animals.
- **Insurance and liability are real risks in this business.** Dogs can be injured, can injure other dogs or people, and can damage property. Work with a licensed commercial insurance broker to obtain appropriate general liability, professional liability (care, custody, and control), property, and workers' compensation coverage before accepting your first dog. Policy terms, exclusions, and limits vary; read them.
- **No income is guaranteed.** The financial examples in this course use illustrative numbers so you can see how the math works. Your actual revenue, costs, and profit will depend on your location, rent, staffing, pricing, occupancy, and local demand. Do not sign a lease or borrow money based on the examples alone.
- **Prices, wages, and costs change over time and vary by market.** Every dollar figure in this course is an illustrative planning figure. Replace it with quotes from your own market before making decisions.
- **Animal welfare laws and local ordinances change.** Confirm current rules with your local authorities and keep your policies updated.

By using this course, you accept responsibility for verifying local rules, obtaining proper insurance, and seeking professional advice where needed.

---

## Table of Contents

- Module 1 — Is This Business Right for You? The Daycare and Boarding Model
- Module 2 — Market Research and Choosing Your Model: Daycare, Boarding, or Pet Hotel
- Module 3 — Location, Zoning, Licensing, and the Lease
- Module 4 — The Startup Budget: Line-by-Line Costs and Funding
- Module 5 — Facility Design and Layout: Safe, Clean, Profitable Space
- Module 6 — Equipment, Supplies, and Vendor Setup
- Module 7 — Staffing Ratios, Hiring, Training, and the Payroll Model
- Module 8 — Safety, Behavior Assessment, and Group Play Management
- Module 9 — Health, Cleaning, and Emergency Protocols
- Module 10 — Pricing, Packages, and the Break-Even Model
- Module 11 — Daily Operations: The Playbook That Runs the Building
- Module 12 — Marketing, Launch, and Growing to Full Occupancy

---

## How to Use This Course

Work through the modules in order the first time. Each module ends with action steps. Do the action steps before moving on — especially Modules 3 and 4, which protect you from the two most expensive mistakes in this business: signing a lease for a space that cannot legally operate as a kennel, and underestimating startup costs.

Use the companion workbook and templates alongside the course. The startup-budget planner, pricing calculator, staffing planner, facility checklist, and safety protocols are the working tools of this system. Fill them in with your own local numbers as you go.

---

# Module 1 — Is This Business Right for You? The Daycare and Boarding Model

## What a daycare and boarding business actually is

A dog daycare takes dogs during the day while owners are at work or away. A boarding facility keeps dogs overnight. A pet hotel combines both and adds premium suites, extra services, and a higher level of comfort. Many successful facilities do all three: daycare fills the daytime, boarding fills the nights and weekends, and add-on services such as baths, enrichment sessions, and training fill the gaps in between.

The business earns money by selling supervised space, time, and care. A customer pays for a day of play, a night of boarding, or a package of days. The facility's job is to keep dogs safe, exercised, clean, and calm, and to return them to their owners in good condition. That sounds simple. In practice it requires constant supervision, careful grouping, strict cleaning, clear communication, and disciplined scheduling. Dogs are living animals with individual temperaments, health needs, and stress responses. A good facility manages all of that every day, without exception.

## The three revenue streams

Daycare is the volume stream. It brings the same dogs back several days a week, which creates predictable recurring revenue. A facility with 40 daycare dogs a day at an average of 35 dollars per dog earns 1,400 dollars per day from daycare alone. Over a 22-day operating month, that is 30,800 dollars. Daycare dogs also tend to book boarding, which makes them your best boarding customers.

Boarding is the high-value stream. A boarding night typically sells for 55 to 85 dollars, depending on the market and the room type, and holiday periods command premium rates. Boarding fills nights, weekends, and holidays — the times when daycare is closed or quiet. A facility with 20 boarding dogs a night at an average of 65 dollars earns 1,300 dollars per night. Over a month with mixed occupancy, boarding can equal or exceed daycare revenue.

Add-on services are the margin stream. Baths, nail trims, enrichment sessions, one-on-one play, training refreshers, and webcam access cost little to deliver and carry high margins. A bath that takes 20 minutes of staff time and 3 dollars of supplies can sell for 25 to 40 dollars. Add-ons also improve the customer experience and give owners reasons to choose your facility over a cheaper competitor.

## What the work is really like

This is a physical, early-morning, seven-day business. Dogs arrive at 7:00 a.m. Boarding dogs need care on weekends and holidays. Cleaning happens every day. Staff call in sick, dogs have bad days, and owners have questions at 9:00 p.m. If you want a business you can run from a laptop on a beach, this is not it. If you love dogs, enjoy building systems, and are willing to be present — especially in the first year — it can be deeply rewarding and genuinely profitable.

You do not need to be a dog trainer to open a daycare, but you do need to understand dog body language, group dynamics, and stress signals, and you need staff who do too. You will hire for temperament and train for skill. Your best employees are calm, observant, physically capable, and genuinely fond of dogs. They are not necessarily the people who love dogs the most loudly; they are the people who stay calm when a play group gets loud.

## The capital question

Daycare and boarding have real startup costs. You need a commercial space, flooring, fencing, kennels or suites, ventilation, drainage, cleaning systems, insurance, licenses, and working capital to cover the first months before occupancy builds. A modest leased facility commonly requires 75,000 to 200,000 dollars in total startup capital, including the first months of operating expenses. A larger or premium facility can require 250,000 dollars or more. Module 4 walks through the full budget line by line so you can build your own number instead of guessing.

If you do not have access to that level of capital, be honest with yourself now. Options include starting smaller — for example, a small daycare-only operation in a smaller space — partnering with someone who brings capital or a suitable property, or phasing the build: open daycare first, add boarding suites in a second phase once cash flow is proven. What you should not do is sign a lease and hope the money appears.

## The risk question

This business carries liability that a retail shop does not. Dogs can fight. A dog can be injured on equipment, can escape, can become ill, or can bite a person. An owner can claim your facility caused an injury or a death. You manage this risk with four layers: careful intake and behavior assessment, trained supervision at safe ratios, a facility designed for safety, and proper insurance. None of these layers is optional. Module 8 and Module 9 cover the operational layers in detail; insurance and legal structure are covered in Module 3.

## Who this business suits — and who it does not

This business suits you if you have access to space or capital, you are willing to work on site, you can manage people, you can follow systems consistently, and you genuinely enjoy the daily reality of caring for dogs. It suits former veterinary technicians, groomers, trainers, pet sitters, and kennel staff who want to own the business instead of working in someone else's.

It does not suit you if you want passive income, if you dislike managing employees, if you cannot handle early mornings and weekends, or if you are uncomfortable with the responsibility of caring for other people's animals. There is nothing wrong with any of those preferences — but this is not the right business for them.

## Action steps — Module 1

1. Write down, in one paragraph, why you want to open this business and what a good week in it looks like to you.
2. List your available capital honestly: savings, a loan you have actually been approved for, a partner's contribution, and a property you already control. Do not list money you hope to raise.
3. Decide whether you will be the on-site operator in year one. If not, name the person who will be, and confirm they are willing.
4. Visit three daycare or boarding facilities in your area as a customer. Note their prices, their hours, their cleanliness, and how the dogs look and sound. This is your first market research.

---

# Module 2 — Market Research and Choosing Your Model: Daycare, Boarding, or Pet Hotel

## Why research comes before the lease

Most failed daycare and boarding businesses do not fail because the owner did not love dogs. They fail because the local market could not support the facility at the price the owner needed to charge, or because a competitor already served the same customers better and cheaper. Research answers three questions: Are there enough dog-owning households nearby who will pay for this service? What are they already paying, and to whom? And what gap can you fill that no one else is filling?

## Step 1: Map your trade area

Draw a 15-minute drive-time circle around the location you are considering. That is your primary trade area for daycare, because owners drop dogs off on the way to work. For boarding, the circle is wider — 30 minutes — because owners plan boarding in advance and will drive further for a facility they trust.

Within that circle, count the households, the average household income, and the number of dogs. You can estimate dog-owning households from local data: roughly one in three to one in two households in many American suburbs owns a dog, and the share is higher in family-oriented neighborhoods. Your city or county planning department, chamber of commerce, and local animal-control office can often supply household counts and licensing data. Pet-store managers and veterinarians in the area can tell you how busy the local dog population is. Do not guess this number. A trade area with 8,000 households and a 40 percent dog-ownership rate holds about 3,200 dog-owning households. If 5 percent of those use daycare regularly, that is 160 potential daycare customers — enough to fill a 40-dog facility with room for competitors. If the trade area holds only 1,500 households, the math is far tighter.

## Step 2: Study every competitor

Visit or call every daycare, boarding kennel, pet hotel, and in-home boarding provider in your trade area. Record the following for each: services offered, daycare price, half-day price, boarding price per night, package discounts, hours, capacity, number of play areas, webcam availability, add-on services, and anything customers praise or complain about in online reviews. Read the reviews carefully. Complaints are your opportunity map. If three competitors are repeatedly criticized for dirty facilities, long wait times at pickup, or dogs coming home stressed, those are gaps you can fill — and advertise.

Pay attention to what competitors do not offer. Common gaps include: early drop-off before 7:00 a.m., weekend daycare, small-dog-only groups, senior-dog care, puppy socialization programs, and transparent webcams. You do not need to fill every gap. Pick one or two that match your strengths and your facility.

## Step 3: Choose your model

There are three basic models, and the choice shapes everything that follows.

**Daycare-only.** Lower startup cost, because you need play space and rest areas but not overnight suites. Simpler staffing, because you close at night. Revenue is concentrated in weekday daytime hours, so weekends and holidays earn little. Best for a first facility in a commuter-heavy area, or for an owner with limited capital.

**Boarding-only (kennel or pet hotel).** Higher revenue per dog per night, and strong holiday peaks. But occupancy is spiky — full at Thanksgiving and Christmas, quiet in February — and you need overnight staffing or a live-in caretaker. Best where there is strong travel demand and limited boarding supply.

**Combined daycare and boarding.** The most common successful model. Daycare provides steady weekday revenue; boarding provides high-value nights, weekends, and holidays; the same dogs use both. Startup cost is highest, because you need both play space and overnight suites. But utilization of staff and space is best, and the combined model is the most resilient to seasonal swings. This is the model the rest of this course assumes, with notes where daycare-only or boarding-only differs.

## Step 4: Choose your positioning

Positioning is the answer to the question: why would an owner choose you instead of the facility down the road? There are three honest positions.

**Value.** Competitive prices, clean and safe care, no frills. You win on price and convenience. This requires high occupancy and tight cost control, because margins are thin.

**Mid-market with excellent service.** Fair prices, great communication, webcams, enrichment, and a facility owners enjoy visiting. This is the largest market and the best fit for most new facilities.

**Premium pet hotel.** Suites instead of kennels, individual play sessions, baths included, luxury finishes, and concierge service. Prices are 50 to 100 percent above mid-market. This requires a higher build-out budget and a trade area with enough affluent households to fill it. It fails fast in a price-sensitive market.

Pick one position and build everything — pricing, facility design, staffing, and marketing — around it. A facility that tries to be premium and cheap at the same time confuses customers and pleases no one.

## Worked example: sizing the market

Consider a suburban trade area with 10,000 households. At a 40 percent dog-ownership rate, that is 4,000 dog-owning households. Suppose 8 percent of those households would consider paid daycare or boarding in a given year — that is 320 households. If your facility captures one quarter of them, you have 80 active customer households. If each active household uses an average of 3 daycare days per month at 35 dollars, that is 8,400 dollars per month from daycare, plus boarding revenue on top. That is a viable start, but not a full facility: a 40-dog daycare at full occupancy needs about 120 to 160 active households, because not every customer comes every day. Use this kind of arithmetic on your own trade area before you commit. If the numbers do not support the facility you want, choose a smaller facility, a different location, or a different model.

## Action steps — Module 2

1. Define your trade area and estimate dog-owning households using local data, not guesses.
2. Build a competitor table with prices, services, hours, and review themes for every competitor in the area.
3. Choose your model — daycare-only, boarding-only, or combined — and write down why.
4. Choose your positioning — value, mid-market, or premium — and write down what it means for pricing and build-out.
5. Run the sizing arithmetic above with your own numbers. If the market cannot support your plan, change the plan now, while it is still free.

# Module 3 — Location, Zoning, Licensing, and the Lease

## The rule that saves the most money in this course

Do not sign a lease, buy a property, or spend money on a build-out until you have written confirmation that a dog daycare and boarding facility is a permitted use at that address. A beautiful space in the wrong zone is worthless to you, and a signed lease does not change the zoning. This is the single most common and most expensive mistake new owners make. Everything in this module exists to prevent it.

## Zoning and land use

Start at your city or county planning department. Ask, in writing: Is a kennel, dog daycare, or animal boarding facility a permitted use at this address? Is a conditional-use permit required? Are there distance requirements from residences, schools, or parks? Are there limits on the number of dogs, on hours of operation, or on outdoor play? Are there noise ordinances that apply to barking, and how are they enforced?

Bring the exact address and a written description of your planned use: number of dogs, indoor and outdoor areas, hours, and staffing. Get the answer in writing or by email. Verbal assurances from a leasing agent or a landlord are not enough — leasing agents are not zoning authorities, and landlords have an interest in signing you.

Common outcomes: the use is permitted outright in light-industrial or certain commercial zones; it requires a conditional-use permit, which involves a public hearing, a fee, and a waiting period of one to six months; or it is prohibited in that zone and you must look elsewhere. A conditional-use permit is workable if you plan for the time and cost, but do not count on approval. Neighbors can object, and hearings can go against you. Have a backup location in mind.

Also check deed restrictions, homeowners' association rules, and any covenants on the property. These can prohibit kennels even where zoning allows them.

## Licenses and permits

The exact list varies by jurisdiction, but expect some combination of the following. Verify each one locally.

- **Business license.** Required almost everywhere. Usually inexpensive and quick.
- **Kennel or boarding license.** Issued by animal control or the health department in many jurisdictions. May require an inspection of the facility before opening and annually thereafter.
- **Conditional-use permit.** See above. Can cost 500 to 5,000 dollars in fees and take months.
- **Building permit.** Required for most build-outs: walls, plumbing, drainage, electrical work, and fencing. Your contractor usually handles this, but you pay for it and you wait for it.
- **Fire inspection and certificate of occupancy.** Required before opening. Fire officials check exits, alarms, extinguishers, and occupancy limits.
- **Health department approval.** Some jurisdictions inspect boarding facilities for sanitation, drainage, and waste handling.
- **Sign permit.** Required for exterior signage in many cities.
- **Sales tax registration.** If your state charges sales tax on pet services or retail products, register and collect it correctly. Rules vary by state; confirm with your state revenue department or an accountant.

Keep a compliance file: a folder, physical or digital, with every license, permit, inspection report, and approval, plus renewal dates. Set calendar reminders 60 days before each renewal.

## Business structure and insurance

Most owners form a limited liability company (LLC) or corporation rather than operating as a sole proprietor, because the business carries real liability. An LLC does not eliminate the need for insurance, and it does not protect you if you personally act negligently, but it is the standard starting structure. Form the entity with a licensed attorney or a reputable formation service, obtain an employer identification number (EIN) from the tax authority, and open a separate business bank account. Never mix personal and business funds.

Insurance is non-negotiable. Work with a commercial insurance broker who understands animal businesses — not a generalist who has never insured a kennel. Ask for quotes on:

- **General liability** — injuries to visitors and damage to others' property.
- **Professional liability / care, custody, and control** — injury, illness, or death of a dog in your care. This is the coverage that matters most, and it is the one general policies often exclude or limit. Read the exclusions.
- **Property insurance** — the building contents, equipment, and improvements you own.
- **Workers' compensation** — required in most states once you have employees.
- **Commercial auto** — if you offer pickup and delivery.
- **Business interruption** — income lost if the facility must close after a covered event.

Expect to pay 3,000 to 8,000 dollars per year for a small facility's core coverage, more for a larger one. Get quotes before you sign the lease, so the cost is in your budget rather than a surprise. Ask your broker, in writing, what is excluded: common exclusions include certain breeds, off-leash play, dogs over a weight limit, and injuries during transport. If an exclusion conflicts with how you plan to operate, change the operation or change the policy — do not operate uncovered and hope nothing happens.

## Choosing the building

A good daycare and boarding building has: at least 3,000 to 5,000 square feet for a modest facility (more for a premium or large one); high ceilings for ventilation and sound; concrete or sealed floors that can be hosed and disinfected; floor drains; good natural light; a fenced outdoor area or room to build one; separate entrances for drop-off and pickup to avoid congestion; parking for at least 10 to 15 cars; and neighbors who will tolerate barking. Light-industrial buildings, former warehouses, and former veterinary or grooming spaces often work well. Retail storefronts with glass fronts and no drainage often do not.

Walk the building with a contractor before you sign anything. Ask: Where will the drains go? Can the floor be sealed or replaced? Is the electrical service enough for commercial washers, dryers, and HVAC? Is there adequate ventilation, or will you need to install it? Can you build outdoor runs, and is there room for waste storage away from play areas? Get a written estimate for the build-out. That estimate belongs in your startup budget in Module 4.

Check the neighborhood at different times of day. Visit at 7:00 a.m. and at 6:00 p.m. Is there traffic congestion? Is parking adequate? Are there residences directly next door whose occupants will complain about barking? A facility next to a quiet residential street will face more complaints than one in a light-industrial park.

## The lease

Have a commercial real estate attorney review the lease before you sign it. A commercial lease is not a residential lease; terms are negotiable and the stakes are high. Key points:

- **Use clause.** The lease must expressly permit dog daycare and boarding. If it says "general commercial use" without naming your use, ask for the specific use to be added.
- **Term and renewal.** A three- to five-year initial term with renewal options is common. A one-year term is risky: you will spend heavily on a build-out and may not recover it in a year.
- **Rent and increases.** Know the base rent, the annual increase, and what is included — common-area maintenance, taxes, insurance, and utilities are often charged separately in commercial leases. Get the total monthly cost, not just the base rent.
- **Tenant improvements.** Negotiate a tenant-improvement allowance or a rent-free build-out period. Landlords of vacant industrial space often contribute. Ask.
- **Exit and assignment.** Can you assign the lease or sublet if the business does not work? What happens to your improvements when you leave? Get this in writing.
- **Personal guarantee.** Landlords often ask the owner to personally guarantee the lease. Understand what this means: if the business fails, you are personally liable for the remaining rent. Negotiate limits where you can, and never sign a guarantee you do not understand.

Budget for a lease deposit (commonly one to three months' rent), the first month's rent, and legal review fees of 1,000 to 3,000 dollars.

## Action steps — Module 3

1. Get written zoning confirmation for your top two location choices before spending money on either.
2. List every license and permit your jurisdiction requires, with fees and timelines.
3. Form your business entity, get an EIN, and open a business bank account.
4. Get insurance quotes from a broker experienced with animal businesses, and confirm care, custody, and control coverage in writing.
5. Have a commercial attorney review the lease before signing. Do not sign a lease that lacks an express permitted-use clause for dog daycare and boarding.

---

# Module 4 — The Startup Budget: Line-by-Line Costs and Funding

## Why a line-item budget matters

A lump-sum guess — "I think it will cost about 100,000 dollars" — is how owners run out of money halfway through a build-out. A line-item budget forces you to price every category, compare quotes, and see exactly where the money goes. It also becomes the document you show a lender or partner, and the baseline you measure actual spending against.

The template that accompanies this course, `templates/startup-budget-planner.csv`, mirrors the budget in this module. Fill it in with your own quotes as you collect them.

## Worked example: a mid-market combined facility

The example below describes a leased 4,000-square-foot facility in a suburban light-industrial area, designed for 40 daycare dogs per day and 24 boarding dogs per night. Every figure is illustrative. Your market will differ. The point is the structure and the order of magnitude — and the discipline of counting working capital as a startup cost, not an afterthought.

### One-time startup costs

| Category | Illustrative cost |
|---|---|
| Lease deposit (2 months at 4,500 dollars per month) | 9,000 |
| First month's rent | 4,500 |
| Legal fees (entity formation and lease review) | 2,500 |
| Licenses and permits (business, kennel, conditional-use, sign, fire) | 3,500 |
| Insurance — first-year premium, paid up front or in installments | 5,000 |
| Build-out: flooring and sealing | 12,000 |
| Build-out: interior walls, kennels, and suites | 18,000 |
| Build-out: fencing and outdoor play yards | 9,000 |
| Build-out: plumbing, drains, and dog-wash stations | 8,000 |
| Build-out: HVAC and ventilation upgrades | 7,000 |
| Build-out: electrical upgrades | 4,000 |
| Build-out: soundproofing and acoustic panels | 3,500 |
| Kennel and suite equipment (runs, beds, bowls, gates) | 8,000 |
| Play equipment, enrichment, and toys | 2,500 |
| Commercial washer and dryer | 4,500 |
| Cleaning equipment and initial supplies | 2,000 |
| Office furniture, reception, and computers | 3,500 |
| Booking and management software setup | 1,200 |
| Webcams and security cameras | 2,500 |
| Signage (exterior and interior) | 3,000 |
| Branding, website, and launch marketing | 4,000 |
| Initial supplies (food bowls, leashes, first aid, waste bags) | 1,500 |
| **Total one-time costs** | **118,700** |

### Monthly operating costs at opening (before full occupancy)

| Category | Illustrative monthly cost |
|---|---|
| Rent (including common-area charges) | 4,500 |
| Payroll (owner-operator plus 3 part-time staff at opening) | 9,000 |
| Payroll taxes and workers' compensation | 1,350 |
| Insurance (monthly share) | 420 |
| Utilities (electric, water, sewer, gas) | 1,100 |
| Cleaning and sanitation supplies | 450 |
| Waste removal | 250 |
| Software (booking, phones, internet) | 350 |
| Marketing | 500 |
| Miscellaneous and repairs reserve | 500 |
| **Total monthly operating cost** | **18,420** |

### Working capital

Working capital is the cash you hold to pay operating costs while revenue builds. A new facility rarely fills in the first month. Plan for at least four to six months of operating costs in reserve. At 18,420 dollars per month, six months is 110,520 dollars. That sounds like a lot — and it is the reason many facilities fail in month four, when the build-out money is gone, occupancy is at 40 percent, and payroll is still due every two weeks.

A realistic total startup requirement for this example is therefore about 118,700 dollars in one-time costs plus 110,520 dollars in working capital — roughly 229,000 dollars. If that number shocks you, that is the budget doing its job. You have three honest responses: raise more capital, start smaller, or phase the build. What you must not do is start with half the money and hope revenue arrives faster than it usually does.

### A smaller start: daycare-only example

For comparison, a daycare-only facility in 2,500 square feet, with no overnight suites and a simpler build-out, might total 55,000 to 85,000 dollars in one-time costs and 8,000 to 12,000 dollars per month in operating costs. Working capital for six months would be 48,000 to 72,000 dollars. The total startup requirement would be roughly 103,000 to 157,000 dollars. Smaller, but still serious money — and still requiring working capital.

## Funding options

- **Personal savings.** The simplest and most common source for a first facility. Do not empty your emergency fund to open a business.
- **Small business loan.** Banks and credit unions lend to pet businesses with a solid business plan, good credit, and collateral or a personal guarantee. The Small Business Administration (SBA) loan programs are the usual route for first-time owners. Expect a detailed application, a business plan, and financial projections. Approval takes weeks to months.
- **Partner or investor.** A partner who contributes capital or a suitable property can make the difference. Put the arrangement in writing with an attorney: ownership percentages, decision rights, profit distribution, and what happens if one partner wants out.
- **Equipment financing or leasing.** Kennels, washers, and HVAC can sometimes be financed separately, spreading the cost over time. Compare the total cost of financing against paying cash.
- **Phased opening.** Open daycare first in a smaller footprint, build cash flow and a customer base, then add boarding suites in phase two from operating cash flow or a second, smaller loan. This is the lowest-risk path for owners with limited capital.

Avoid funding a startup with high-interest credit cards or a home equity loan you cannot afford to lose. If the business fails, that debt remains.

## Tracking actual spending

Once the budget is built, track actual spending against it weekly during the build-out. Create three columns: budgeted, actual, and variance. When a category runs over — and one always does — decide immediately what you will cut or defer to stay within the total. The budget is a management tool, not a document you write once and forget.

## Action steps — Module 4

1. Collect three quotes for each major build-out category: flooring, kennels, fencing, plumbing, and HVAC.
2. Complete the startup-budget planner with your own quotes, your actual rent, and your local wage rates.
3. Calculate your total startup requirement: one-time costs plus six months of operating costs.
4. Identify your funding sources and the gap, if any. If there is a gap, decide now whether to raise more, start smaller, or phase the opening.
5. Set up a separate business bank account and a simple weekly budget-tracking routine before spending begins.

# Module 5 — Facility Design and Layout: Safe, Clean, Profitable Space

## Design principles

A daycare and boarding facility has three design jobs at once: keep dogs safe, keep the building clean and healthy, and move dogs and people efficiently. Every layout decision should serve at least one of those jobs. A pretty lobby that forces boarding dogs to walk through the daycare playroom to reach their suites fails the safety job. A playroom with no floor drain fails the cleaning job. A building with one narrow hallway for 40 arriving dogs fails the efficiency job.

Design in zones. Dogs and people should flow through the building in a predictable order, and zones should be separated by doors and gates so that a problem in one zone stays in one zone.

## The zones

**Reception and lobby (300–400 square feet).** The first thing owners see. It should be clean, calm, well lit, and free of loose dogs. Include a reception desk, seating for two or three people, a retail display if you sell food or supplies, and a secure check-in area where dogs are leashed and handed over. Keep the lobby separate from play areas by a door or gate. Dogs waiting in the lobby should not be able to see or reach dogs playing — visual stimulation raises arousal and barking before the day has even started.

**Daycare playrooms (the largest area).** Plan for two to four playrooms so you can separate dogs by size, age, energy level, and temperament. A 4,000-square-foot facility might have a large-dog room of 800 square feet, a small-dog room of 500 square feet, and a rest or quiet room of 300 square feet. Each playroom needs: sealed, non-slip flooring with a drain; walls that can be washed; a gate system that lets staff enter and exit without dogs escaping; water stations; resting platforms or benches; and good ventilation. Avoid blind corners where a dog can be cornered. Staff should be able to see the whole room from any position.

**Boarding suites and kennels (800–1,200 square feet).** Overnight dogs need individual, secure, comfortable spaces. Suites can be glass-fronted rooms of 4 by 6 feet or larger for premium facilities, or standard kennel runs of 4 by 4 feet for mid-market facilities. Every suite needs a raised bed or platform, a water bowl that cannot be tipped, adequate ventilation, and a door that a dog cannot open. Place suites away from the noisiest playrooms, and include a quiet area for senior dogs and dogs that need rest. Cats are not part of this course's model; if you board cats, they need a completely separate area with separate ventilation.

**Outdoor play yards (as large as your site allows).** Outdoor space is valuable but must be secure: fencing at least 6 feet high, with no gaps at the bottom, no climbable structures near the fence, and double-gated entry points so a dog cannot escape when a gate opens. Provide shade, water, and a surface that drains and can be cleaned — sealed concrete, artificial turf designed for dogs, or pea gravel in limited areas. Natural grass turns to mud quickly under 40 dogs. Never leave dogs outdoors unsupervised, and bring them in during extreme heat, cold, or storms.

**Dog wash and grooming area (150–250 square feet).** A raised tub or walk-in shower, non-slip flooring, a drain, storage for shampoos and towels, and a commercial dryer. Even if you do not offer grooming as a standalone service, you need to wash dirty dogs before they go home.

**Kitchen and food preparation (100–150 square feet).** A commercial sink, refrigerator, storage for client-provided food, and a labeling system. Every dog's food must be labeled with the dog's name and feeding instructions. Never feed dogs from unlabeled containers.

**Laundry (100 square feet).** A commercial washer and dryer, folding space, and storage for clean bedding and towels. You will do laundry every day. Plan for it.

**Staff areas and storage.** A small break area, lockers, a first-aid station, and locked storage for cleaning chemicals — locked, because cleaning chemicals and dogs must never mix. Cleaning supplies should be stored away from food preparation.

**Isolation area.** A separate room or kennel, away from other dogs, for a dog that becomes ill or shows signs of contagious disease during the day. This is not optional. A dog that vomits or develops diarrhea in a playroom can expose every dog in the building. The isolation area needs its own cleaning supplies and a protocol for veterinary contact, which Module 9 covers.

## Flooring, drainage, and ventilation

Flooring is the most important build-out decision you will make. Dogs urinate, vomit, spill water, and track in mud. The floor must be sealed, non-slip when wet, and able to withstand daily disinfection. Sealed concrete with a non-slip coating, commercial vinyl with heat-welded seams, or epoxy flooring are the standard choices. Carpet is unacceptable in play and kennel areas. Bare wood is unacceptable. Budget for professional installation; a failed floor coating that peels under daily washing will cost more to fix than to do correctly the first time.

Drainage matters as much as flooring. Every playroom, kennel area, wash area, and outdoor yard should drain to a floor drain or a graded outdoor drain. Without drainage, cleaning means pushing dirty water around with a squeegee instead of hosing it away, and standing water becomes a health risk.

Ventilation matters for health and for neighbor relations. Dogs produce odor and moisture. A facility needs fresh-air exchange, exhaust fans, and, in most climates, commercial HVAC sized for the building and the dog load — not residential HVAC. Ask your HVAC contractor to size the system for the number of dogs, not just the square footage. Poor ventilation causes respiratory illness, odor complaints, and a building that smells like a kennel within a month. Soundproofing matters too: acoustic panels, solid-core doors, and insulation reduce barking noise for neighbors and stress for dogs.

## Capacity planning

Capacity is set by your smallest constraint: space, staffing, or licensing. A common planning figure is 50 to 75 square feet of indoor play space per dog in a play group, plus separate rest and kennel space. A 800-square-foot playroom therefore holds about 12 to 16 dogs at a time, depending on the dogs' size and energy. Do not plan capacity by cramming dogs into every square foot. Overcrowding causes fights, stress, and injuries — and it is the fastest way to lose customers and staff.

Your license may also cap the number of dogs. Check the cap before you design, and design to the lower of the licensed cap and the safe capacity your space allows.

## Example layout: 4,000-square-foot combined facility

- Lobby and reception: 350 square feet
- Large-dog playroom: 800 square feet
- Small-dog playroom: 500 square feet
- Quiet and rest room: 300 square feet
- Boarding suites (24 suites): 1,000 square feet
- Outdoor yards: 2,000 square feet (outside the building footprint)
- Wash area: 200 square feet
- Kitchen and food prep: 120 square feet
- Laundry: 100 square feet
- Staff, storage, and isolation: 330 square feet
- Hallways and circulation: 300 square feet

Total: 4,000 square feet indoors, plus outdoor yards. This layout supports 40 daycare dogs per day and 24 boarding dogs per night with safe staffing ratios, which Module 7 covers.

## Action steps — Module 5

1. Sketch your floor plan by zones before talking to a contractor. Mark entrances, gates, drains, and the isolation area.
2. Get flooring, drainage, and HVAC quotes from contractors experienced with animal facilities, not just general commercial work.
3. Complete the facility layout checklist in the templates folder for your specific building.
4. Confirm your licensed dog capacity and design to the lower of the licensed cap and safe space capacity.

---

# Module 6 — Equipment, Supplies, and Vendor Setup

## Buy once, buy right

Equipment failures during operating hours are expensive: a broken washer means dirty bedding piles up, a failed gate latch means a safety incident, a dead camera means owners cannot see their dogs. Buy commercial-grade equipment where it matters — washers, dryers, kennels, gates, and flooring — and keep spare parts for the items that fail most often: gate latches, bowl holders, leashes, and cleaning sprayers.

## Core equipment list

- **Kennels and suites.** Stainless steel or heavy-duty coated runs with secure latches. Budget 250 to 600 dollars per kennel run, depending on size and materials, or 800 to 2,000 dollars per premium suite.
- **Gates and barriers.** Commercial-grade, wall-mounted or free-standing gates for playroom separation. Budget 150 to 400 dollars per gate.
- **Beds and platforms.** Raised, washable beds or Kuranda-style platforms. Budget 40 to 90 dollars per bed.
- **Bowls.** Stainless steel, non-tip, in two sizes. Budget 8 to 15 dollars each; buy twice as many as you think you need.
- **Play equipment.** Ramps, tunnels, platforms, and climbing structures designed for dogs — no sharp edges, no small parts, and no equipment a dog can fall from at height. Budget 1,500 to 3,000 dollars for a full set.
- **Toys.** Durable rubber toys, ropes, and puzzle feeders. Inspect daily and discard damaged toys. Budget 300 to 600 dollars for an opening stock, plus a monthly replacement budget.
- **Leashes, collars, and slip leads.** For moving dogs safely between areas. Budget 200 to 400 dollars.
- **Commercial washer and dryer.** Budget 3,500 to 6,000 dollars for the pair. Residential machines will not survive the volume.
- **Dog wash tub.** A raised stainless tub with a handheld sprayer. Budget 800 to 2,000 dollars.
- **Cleaning equipment.** A floor scrubber or pressure washer, mops, buckets, sprayers, and a wet vacuum. Budget 800 to 1,500 dollars.
- **Webcams and security cameras.** One camera per playroom plus lobby and exterior coverage. Budget 1,500 to 3,000 dollars for a system with remote viewing.
- **Office and booking system.** A computer, a phone system, and booking software. Budget 1,500 to 3,000 dollars for setup.
- **First-aid kits.** One per play area plus a main kit. Include bandages, gauze, saline, a thermometer, tweezers, styptic powder, and a muzzle. Budget 150 to 300 dollars. Restock monthly.

## Supplies and consumables

Plan a monthly consumables budget. Typical monthly figures for a mid-size facility: cleaning and disinfectant chemicals 200 to 350 dollars; laundry detergent and supplies 100 to 150 dollars; waste bags and trash liners 80 to 120 dollars; paper towels and hand soap 60 to 100 dollars; toys and enrichment replacement 100 to 200 dollars; office supplies 50 to 100 dollars. Total: roughly 600 to 1,000 dollars per month. Track actual usage for the first three months and adjust the budget to reality.

## Choosing cleaning products

Use veterinary-grade, kennel-safe disinfectants, and follow the manufacturer's dilution and contact-time instructions exactly. A disinfectant that needs ten minutes of wet contact time does not work if you spray and wipe in thirty seconds. Keep safety data sheets for every chemical on site. Never mix bleach with other cleaners. Store chemicals in a locked area, away from dogs and food. Train every staff member on correct dilution and use before their first shift.

## Vendor setup

Set up accounts before opening with: a pet-supply wholesaler for beds, bowls, toys, and leashes; a janitorial supplier for cleaning chemicals and paper goods; a laundry supplier; a local veterinarian or emergency veterinary clinic for referrals and emergencies; a waste-removal company; and an HVAC and plumbing contractor on call. Negotiate payment terms and delivery schedules. Keep a vendor list with names, phone numbers, account numbers, and order lead times in the office where any manager can find it.

## Action steps — Module 6

1. Build your equipment list from this module and get quotes for the five most expensive items.
2. Set up vendor accounts for cleaning supplies, pet supplies, laundry, and waste removal before opening.
3. Create a monthly consumables budget and a restocking checklist.
4. Confirm your emergency veterinary clinic's address, phone number, and hours, and post them in the office and the isolation area.

# Module 7 — Staffing Ratios, Hiring, Training, and the Payroll Model

## Staffing is your largest cost and your largest risk

Payroll is typically 40 to 55 percent of revenue in a daycare and boarding facility. It is also the difference between a safe facility and a dangerous one. Understaffed playrooms cause injuries. Overtired staff miss warning signs. High turnover destroys consistency, and dogs notice inconsistency before owners do. Staffing well is not a luxury; it is the core operating discipline of this business.

## Staffing ratios

There is no single national legal ratio for dog daycare in the United States — requirements vary by jurisdiction, and some set none at all. That does not mean any ratio is acceptable. The ratios below are widely used planning standards in the industry, and you should treat them as maximums, not targets. Fewer dogs per staff member is always safer.

- **General daycare playgroups:** 1 staff member per 10 to 15 dogs, depending on the dogs' size, age, and energy. Use 1 to 10 for large, high-energy, or mixed groups, and 1 to 15 only for calm, well-known, small-dog groups.
- **Puppy groups:** 1 staff member per 8 to 10 puppies.
- **Senior or special-needs groups:** 1 staff member per 8 to 10 dogs.
- **Boarding overnight:** at least 1 staff member on site overnight for every 20 to 25 boarding dogs, awake and checking dogs on a schedule — not asleep in another building. Some jurisdictions require overnight staff; even where they do not, leaving boarding dogs unattended overnight is a serious liability and welfare risk.
- **Intake, feeding, and cleaning shifts:** schedule extra hands for the morning intake rush (7:00–9:00 a.m.), the midday feeding and cleaning window, and the evening pickup rush (4:00–6:30 p.m.). These are the hours when incidents happen, because dogs are moving between areas and staff are busy.

Never run a playroom with a single staff member if you can avoid it. A lone staff member cannot break up a fight safely, cannot leave the room to get help, and cannot manage an emergency while supervising the remaining dogs. Schedule in pairs wherever possible.

## Roles

A facility with 40 daycare dogs and 24 boarding dogs typically needs:

- **Owner-operator or general manager (1, full-time).** Oversees everything: intake, staff, customers, finances, and compliance. Works on site.
- **Lead playroom attendant (1–2, full-time).** Experienced staff who run playrooms, assess behavior, and train newer staff.
- **Playroom attendants (3–5, full- and part-time).** Supervise playgroups, clean, feed, and handle dogs.
- **Overnight caretaker (1, part-time or live-in).** Overnight checks, late arrivals, early departures, and emergency response.
- **Reception and customer service (1, part-time or combined with a lead role).** Check-in, check-out, phone, bookings, and billing. In a small facility this role is combined with the manager's role.

At opening, with lower occupancy, you will run leaner — the owner plus two or three attendants. Staff up as occupancy grows, and never let occupancy outrun staffing.

## Hiring

Hire for calm temperament, reliability, and physical capability, then train for skill. A candidate who is calm under pressure, shows up on time, follows instructions, and can lift a 50-pound dog is worth more than a candidate with strong opinions about dog training and poor attendance. During interviews, ask candidates to spend time in a playroom and watch how they move, how they read dogs, and whether they stay calm when the room gets loud. Check references, and run background checks where your insurer or local rules require them.

Pay competitively for your market. In many markets, playroom attendants earn 15 to 20 dollars per hour, leads earn 18 to 24 dollars, and managers earn 45,000 to 65,000 dollars per year. Paying below market saves money for a month and costs you staff, safety, and reputation for a year. Include paid training time — staff who are paid to learn stay longer and learn better.

## Training program

Every new hire completes training before working unsupervised in a playroom. A minimum program covers:

1. Dog body language and stress signals — ears, tail, posture, whale eye, freezing, lip licking, yawning, and avoidance.
2. Safe handling — leashing, moving dogs between areas, breaking up scuffles safely, and never putting hands between fighting dogs.
3. Group management — introductions, reading play versus conflict, arousal levels, and when to separate a dog.
4. Cleaning and sanitation — correct disinfectant dilution, contact time, and waste handling.
5. Feeding and medication — reading feeding instructions, labeling, and medication logs.
6. Emergency procedures — injury, escape, fire, power outage, and veterinary emergency steps, from Module 9.
7. Customer service — check-in and check-out scripts, incident reporting, and communication standards.

Document training with a sign-off sheet for each topic. Keep the sheets on file. If an incident ever leads to an insurance claim or a legal question, documented training is evidence that you operated responsibly.

## Worked example: the payroll model

The example below models a facility at 70 percent occupancy: 28 daycare dogs per day and 17 boarding dogs per night, with the staffing shown. All figures are illustrative; replace wages with your local market rates.

| Role | Hours per week | Hourly rate or salary | Weekly cost |
|---|---|---|---|
| Owner-operator / manager | 45 (salaried) | 1,050 dollars per week | 1,050 |
| Lead attendant | 40 | 20 dollars per hour | 800 |
| Attendant 1 | 40 | 17 dollars per hour | 680 |
| Attendant 2 | 32 | 17 dollars per hour | 544 |
| Attendant 3 (part-time) | 20 | 16 dollars per hour | 320 |
| Overnight caretaker | 28 | 18 dollars per hour | 504 |
| Reception support (part-time) | 16 | 16 dollars per hour | 256 |
| **Total base payroll** | | | **4,154 per week** |

Monthly base payroll is about 18,000 dollars (4,154 dollars times 4.33 weeks). Add payroll taxes and workers' compensation at roughly 15 percent, or about 2,700 dollars per month, for a total monthly labor cost of about 20,700 dollars.

Compare that to revenue at 70 percent occupancy. Daycare: 28 dogs times 35 dollars times 22 days equals 21,560 dollars per month. Boarding: 17 dogs times 65 dollars times 30 nights equals 33,150 dollars per month. Add-ons at a modest 2,000 dollars per month bring total revenue to about 56,710 dollars. Labor at 20,700 dollars is about 36 percent of revenue — within the healthy range. At 40 percent occupancy, the same payroll would be over 60 percent of revenue, which is why new facilities lose money in the early months and why working capital matters. The payroll model in the templates lets you test these numbers at 40, 60, 80, and 100 percent occupancy.

## Scheduling and burnout

Build the schedule two weeks ahead, post it where staff can see it, and protect rest. Staff who work six long days in a row make mistakes. Rotate playroom assignments so no one spends an entire shift in the loudest room. Give staff a real break away from dogs. Track overtime and keep it low — overtime is expensive, and tired staff are a safety risk. Cross-train every attendant on feeding, cleaning, and reception so one absence does not shut down a function.

## Action steps — Module 7

1. Write your staffing plan for opening day, at 60 percent occupancy, and at full occupancy.
2. Set your ratios in writing and post them in the office: maximum dogs per staff member by group type.
3. Build a two-week training checklist for every new hire and a sign-off sheet.
4. Complete the staffing-ratio planner with your local wage rates and your occupancy scenarios.

---

# Module 8 — Safety, Behavior Assessment, and Group Play Management

## Safety is a system, not a hope

Every dog that enters your building is assessed, grouped, supervised, and monitored according to a written system. The system exists so that safety does not depend on one person's judgment on one busy morning. It has five parts: intake and assessment, grouping, supervision, separation, and incident response.

## Intake and behavior assessment

No dog enters group play without an assessment. The process:

1. **Application and records.** Before the first visit, the owner completes an application covering age, breed, weight, spay or neuter status, vaccination history, health conditions, medications, allergies, feeding instructions, bite history, and behavior with other dogs, children, and strangers. Require proof of vaccinations — at minimum rabies, distemper and parvovirus, and Bordetella — from a veterinarian. Check the dates; expired vaccinations are not vaccinations. Keep copies on file.
2. **Meet-and-greet.** A short, controlled introduction with one calm, well-socialized dog of similar size, in a neutral area, supervised by an experienced staff member. Watch for the dog's greeting style, arousal level, and recovery after excitement. A dog that cannot calm down after a greeting, that fixates, that resource-guards, or that shows sustained fear or aggression is not a group-play candidate.
3. **Trial half-day.** The dog's first visit is a short trial in a small, calm group. Staff observe and record behavior: play style, social skills, rest behavior, response to staff direction, and any concerning incidents. The owner is told honestly how the trial went.
4. **Ongoing assessment.** Assessment never ends. A dog's behavior can change with age, health, or stress. Staff log notes after every visit, and any change — increased reactivity, new fear, pain, or lethargy — triggers a review and, if needed, a change in grouping or a conversation with the owner.

Dogs that do not suit group play are not bad dogs. Some are fearful, some are reactive, some are elderly, and some simply prefer people to dogs. Offer them individual care — private play sessions, one-on-one walks, and a quiet suite — rather than forcing them into a group. Forcing an unsuitable dog into group play endangers that dog, the other dogs, and your staff.

## Grouping rules

Group dogs by size, age, energy, and play style. The standard groups are: small dogs (under 25 pounds), medium dogs (25 to 50 pounds), large dogs (over 50 pounds), puppies under six months, and seniors or low-energy dogs. Within each size group, separate high-energy rough players from calm dogs. Never mix a 70-pound adolescent with a 10-pound senior because both happen to be available. Intact adult dogs require special consideration: many facilities require spaying or neutering for dogs over six to twelve months in group play, because intact dogs increase conflict. Set your policy in writing, apply it consistently, and confirm it complies with local rules and your insurer's requirements.

Cap group sizes by room and by staff ratio, whichever is lower. A room that fits 15 dogs with one staff member holds 10 if your ratio is 1 to 10. Do not exceed either limit.

## Reading play and reading trouble

Healthy play is loose, bouncy, and reciprocal: dogs take turns chasing, pause, shake off, and re-engage. Trouble looks different: stiff bodies, hard stares, raised hackles, freezing, pinning, relentless chasing without pauses, and one dog repeatedly trying to escape while the other pursues. Staff must intervene early, before a scuffle becomes a fight. Intervention means calmly redirecting with a voice cue, a barrier, or a leash — separating the dogs into different areas and letting arousal drop. It never means reaching between two fighting dogs with bare hands. Staff carry air horns or citronella spray as a last-resort interruption tool where your policy and local rules allow, and they are trained to use a physical barrier such as a board or a gate panel.

## Separation and rest

Dogs need rest. A full day of nonstop play exhausts dogs, raises arousal, and causes incidents. Schedule rest periods: a midday rest of one to two hours in individual suites or quiet rooms, with water available and lights low. Puppies and seniors need more rest. After rest, dogs return to play calmer and safer. Owners should know that rest is part of the program, not a failure to provide play. A dog that comes home tired and content is the goal; a dog that comes home wired and stressed is a warning sign.

## Incident response

When an incident happens — a scuffle, a bite, an injury, or an escape — the response follows a written procedure, every time:

1. Separate the dogs safely and secure the area.
2. Check every dog and person involved for injuries. Apply first aid. Call a veterinarian if there is any doubt.
3. Move uninjured dogs to a calm area.
4. Document the incident in writing the same day: date, time, dogs involved, staff present, what happened, what was done, and veterinary advice received. Keep the report on file.
5. Notify the owners of every dog involved, honestly and promptly. Do not minimize, and do not blame. State the facts, the care given, and the next steps.
6. Review the incident with the team within 48 hours. Was the grouping wrong? Was the ratio exceeded? Was a warning sign missed? Change the system, not just the apology.

Owners will forgive an honest incident handled well. They will not forgive a hidden one.

## Bite and aggression policy

Set a written policy before opening: what happens after a bite to a dog or a person, and what happens after repeated aggression. A common policy is that a dog that bites a person is suspended pending review and may be permanently dismissed; a dog involved in a serious fight is suspended and reassessed; a dog with three recorded aggressive incidents is dismissed from group play. Apply the policy consistently, document every decision, and communicate it to owners at intake so no one is surprised.

## Action steps — Module 8

1. Write your intake application, vaccination requirements, and assessment procedure.
2. Define your grouping rules and maximum group sizes by room.
3. Write your incident-response procedure and post it in every playroom.
4. Train every staff member on reading play versus conflict, and practice separation drills before opening.

# Module 9 — Health, Cleaning, and Emergency Protocols

## Health starts at the door

A boarding and daycare facility is a shared environment, and contagious disease spreads fast in one. Your health system has three layers: prevention at intake, daily observation, and rapid isolation and response.

**Prevention at intake.** Require current vaccinations as described in Module 8, and require a veterinarian's clearance for any dog with a known contagious condition. Do not accept a dog that is actively coughing, vomiting, or has diarrhea, even if the owner insists the dog is fine. A polite refusal protects every other dog in the building and protects your reputation. Record the refusal and the reason.

**Daily observation.** Staff check every dog at arrival and throughout the day: appetite, energy, stool, coughing, sneezing, skin, eyes, and gait. Any change is logged and reported to the manager the same day. A dog that is lethargic, refuses food, or develops diarrhea is moved to the isolation area, the owner is contacted, and a veterinarian is consulted. Do not wait until the end of the day to act on a sick dog.

**Common conditions to know.** Kennel cough (a contagious respiratory infection), canine influenza, parvovirus, and intestinal parasites are the conditions most likely to affect a facility. Staff should know the basic signs — coughing, nasal discharge, vomiting, diarrhea, lethargy, loss of appetite — and the response: isolate, contact the owner, consult a veterinarian, and clean and disinfect the affected area. This course does not teach diagnosis or treatment. Any medical decision belongs to a veterinarian. Your job is recognition, isolation, communication, and documentation.

**Medication.** Administer medication only with written owner instructions and a signed authorization. Log every dose: dog, medication, dose, time, and staff initials. Store medication as labeled — some require refrigeration. Never give a dog medication that was not prescribed for that dog, and never adjust a dose.

## Cleaning and sanitation

Cleaning is a daily, scheduled, non-negotiable operation — not something that happens when there is time. The schedule:

- **Continuously during the day:** pick up waste immediately, wipe water spills, and spot-clean accidents as they happen.
- **Midday:** clean and disinfect food and water bowls, wipe playroom surfaces, and launder soiled bedding.
- **End of day:** remove all dogs from each playroom in turn, pick up waste and debris, hose or mop floors, apply disinfectant at the correct dilution with the required contact time, rinse where the product requires it, and allow floors to dry before dogs return. Clean and disinfect kennels and suites, change bedding, and wash bowls.
- **Weekly:** deep-clean walls, gates, play equipment, and drains; clean ventilation grilles; inspect and replace worn toys and bedding.
- **Monthly:** deep-clean the laundry, kitchen, and storage areas; inspect flooring for damage; service the floor scrubber and washer.

Use only kennel-safe disinfectants, follow dilution and contact-time instructions, and keep safety data sheets on site. A disinfectant used incorrectly is worse than useless — it creates a false sense of safety. Train every staff member, and spot-check their work.

## Waste handling

Pick up solid waste immediately, bag it, and store it in sealed outdoor containers away from play areas and food preparation. Dispose of it according to local rules. Wash hands after handling waste, and provide hand-washing stations and gloves for staff. Drainage from play areas and wash stations must go to an approved drain, not to a storm drain or a neighbor's property.

## Emergency protocols

Emergencies in this business fall into five categories. Plan for all five before opening, and drill them.

**1. Dog injury or medical emergency.** Stop the activity, secure the dog, apply first aid, and call the veterinarian and the owner. If the dog needs emergency care, transport it to the emergency clinic named in your protocol, with the owner's emergency contact and the dog's medical records. Document everything: time, symptoms, care given, veterinary advice, and owner notification. Never delay veterinary care to wait for an owner to call back if a dog is in distress.

**2. Dog fight.** Interrupt safely with a barrier or an approved interruption tool, separate the dogs, check for injuries, isolate the dogs involved, and follow the incident procedure in Module 8. Staff must never put their hands between fighting dogs.

**3. Escape.** If a dog escapes the building or a yard, staff follow a written plan: who calls the owner, who searches in which direction, who stays with the remaining dogs, and who contacts animal control if the dog is not found quickly. Prevention matters more: double-gated entries, latch checks twice daily, and fence inspections weekly.

**4. Fire.** Know your evacuation plan: how dogs are moved out, in what order, to what assembly point, and with what equipment (leashes, carriers, and a headcount list). Post the plan, drill it quarterly, and keep exits clear at all times. Boarding dogs must be evacuable at night by the overnight caretaker alone — if the plan requires four people, it is not a real plan.

**5. Power outage, flood, or severe weather.** Know how you will keep dogs safe, warm or cool, and watered if power fails; where dogs go if part of the building floods; and when you will close early or cancel daycare for severe weather. Keep emergency lighting, a battery-powered radio, and the emergency contact list accessible. Notify owners promptly if hours change.

Keep a printed emergency binder in the office and a copy in the isolation area with: the emergency veterinary clinic's address and phone number, the nearest 24-hour emergency clinic, the poison-control number for animals, the owner's emergency contacts for every dog on site that day, your insurer's claim-reporting number, and the fire and police non-emergency numbers. A binder that only exists on a computer is useless when the power is out.

## Insurance claims and records

If an incident may lead to a claim, notify your insurer promptly and follow their instructions. Do not admit fault in writing to an owner before speaking with your insurer. Keep incident reports, veterinary records, vaccination records, and training sign-off sheets for at least three years, or longer if your insurer or local rules require it.

## Action steps — Module 9

1. Write your vaccination and health-intake requirements and post them for customers.
2. Build the daily, weekly, and monthly cleaning schedule and assign it by name, not by "whoever is free."
3. Complete the safety and emergency protocols template, including the emergency binder contents and the fire evacuation plan.
4. Drill the fire evacuation and the dog-escape procedures before opening, and schedule quarterly drills thereafter.

---

# Module 10 — Pricing, Packages, and the Break-Even Model

## Pricing is a math problem before it is a marketing decision

Your price must cover your costs, pay your staff, and leave a profit — at the occupancy you can realistically achieve. A price that feels competitive but loses money at 70 percent occupancy is not a good price. Start with the math, then check the result against the market. If the math says you need 45 dollars a day and the market pays 30, you have a cost problem, a location problem, or a positioning problem — and you need to fix one of those before opening, not after.

## Step 1: Know your monthly costs

Use the operating budget from Module 4. For the worked example in this module, monthly operating costs are 20,000 dollars, including rent, payroll, payroll taxes, insurance, utilities, supplies, software, and marketing. Your number will differ. Build it from your own quotes.

## Step 2: Know your capacity

Capacity is the maximum number of dog-days and dog-nights you can sell in a month. For the example facility: 40 daycare dogs per day times 22 operating days equals 880 daycare dog-days per month. Boarding: 24 suites times 30 nights equals 720 boarding dog-nights per month. Add-ons are priced separately and are not counted here.

## Step 3: Calculate break-even

Break-even occupancy is the occupancy at which revenue equals costs. Work it separately for daycare and boarding, then together.

**Daycare break-even (daycare alone).** Suppose daycare carries 55 percent of monthly costs, or 11,000 dollars. At 35 dollars per daycare day, break-even is 11,000 divided by 35, which is 314 dog-days per month — about 36 percent of the 880 capacity, or about 14 dogs per day. That is the daycare-only break-even.

**Boarding break-even (boarding alone).** Suppose boarding carries 45 percent of monthly costs, or 9,000 dollars. At 65 dollars per night, break-even is 9,000 divided by 65, which is 138 dog-nights per month — about 19 percent of the 720 capacity, or about 5 dogs per night.

**Combined break-even.** In practice the streams share costs, so the combined picture matters most. At 60 percent occupancy — 24 daycare dogs per day and 14 boarding dogs per night — monthly revenue is: daycare 24 times 35 times 22 equals 18,480 dollars; boarding 14 times 65 times 30 equals 27,300 dollars; add-ons 1,500 dollars. Total: 47,280 dollars against 20,000 dollars in operating costs, leaving 27,280 dollars before loan payments, owner draw, taxes, and reserves. That is a healthy margin on paper — and it is why occupancy is the single most important number in the business. At 30 percent occupancy, the same facility earns about 23,000 dollars and barely covers costs. The difference between 30 percent and 60 percent occupancy is the difference between struggling and thriving.

Run your own numbers in the pricing calculator template at 40, 60, 80, and 100 percent occupancy. If break-even requires more than 70 percent occupancy, your costs are too high or your prices are too low. Fix that before opening.

## Building the price list

**Daycare.** Common structures: a full day (more than 5 hours) at 30 to 45 dollars, a half day (up to 5 hours) at 20 to 30 dollars, and packages of 10 or 20 days at a 10 to 15 percent discount. Packages improve cash flow — the customer pays up front — and improve retention, because a customer with 10 prepaid days is likely to use them with you. Set package expiry (commonly 60 to 90 days for a 10-pack) and state it clearly.

**Boarding.** A standard suite at 55 to 75 dollars per night, a premium suite at 85 to 120 dollars per night, and a holiday rate 10 to 25 percent higher. Include a daycare session in the boarding price or charge it separately — either is fine, but state it clearly so owners are not surprised. Charge for the day of arrival and the day of departure according to a written policy, and state the checkout time (commonly 11:00 a.m. or noon, with a late-checkout fee after that).

**Add-ons.** A bath at 25 to 40 dollars, a nail trim at 15 to 20 dollars, a one-on-one enrichment session at 10 to 15 dollars, a training refresher at 20 to 30 dollars, and a photo or report-card package at 5 to 10 dollars. Price add-ons to be profitable on their own, not as loss leaders.

**Example price list (mid-market, illustrative).**

| Service | Price |
|---|---|
| Full-day daycare | 38 dollars |
| Half-day daycare | 25 dollars |
| 10-day daycare package | 342 dollars (10 percent off) |
| 20-day daycare package | 646 dollars (15 percent off) |
| Boarding — standard suite | 68 dollars per night |
| Boarding — premium suite | 95 dollars per night |
| Holiday boarding surcharge | 15 dollars per night |
| Bath (add-on) | 30 dollars |
| Nail trim (add-on) | 15 dollars |
| Enrichment session (add-on) | 12 dollars |
| Late checkout (after noon) | 15 dollars |

## Discounts: use them carefully

Discounts that fill empty space are good. Discounts that train customers to wait for a sale are bad. Offer an opening promotion — for example, 20 percent off the first package — with a clear end date. Offer a referral credit, such as 25 dollars off for the referrer and the new customer, because a referred customer is your cheapest acquisition. Avoid permanent discounts, deep daily-deal coupons, and pricing that depends on a platform taking a large commission. A customer acquired at a 50 percent discount rarely converts to full price.

## Raising prices

Plan to review prices annually. Costs rise every year — wages, rent, insurance, supplies — and prices must rise with them. A 3 to 5 percent annual increase, announced 30 days in advance with a clear explanation, is normal and expected. Customers leave over a surprise 20 percent increase, not over a planned 4 percent one. Grandfather loyal customers for one cycle if you wish, but do not freeze prices forever.

## Action steps — Module 10

1. Build your monthly operating budget from real quotes.
2. Calculate break-even occupancy for daycare, boarding, and the combined business.
3. Set your price list and package structure, and check it against three local competitors.
4. Complete the pricing-packages calculator with your own numbers at 40, 60, 80, and 100 percent occupancy.

# Module 11 — Daily Operations: The Playbook That Runs the Building

## Why a written playbook matters

A facility that depends on the owner remembering everything fails the first time the owner is sick. A written daily playbook lets any trained staff member run the building safely. It also makes training faster, reduces mistakes, and gives you a document to improve over time. This module is the outline of that playbook. Write your own version for your building, post it in the office, and update it whenever a procedure changes.

## The daily schedule

**6:30 a.m. — Opening.** The opening staff member arrives, checks the building, reviews the overnight log, checks every boarding dog, and prepares the playrooms. Doors, gates, and fences are checked. Food for the day is reviewed against feeding instructions.

**7:00–9:00 a.m. — Morning intake.** Dogs arrive, are checked in, and move to their play groups. Staff verify the dog's identity, check for signs of illness, confirm feeding and medication instructions, and note any owner messages. This is the busiest and highest-risk window of the day. Schedule your most experienced staff for it.

**9:00 a.m.–12:00 p.m. — Morning play.** Structured play in groups, with staff supervising at the posted ratios. Water is refreshed, and staff log notes on any dog that seems off.

**12:00–2:00 p.m. — Midday rest, feeding, and cleaning.** Dogs rest in suites or quiet rooms. Staff feed boarding dogs according to instructions, administer medications, clean playrooms, and do laundry. This is also when baths and add-on services are delivered.

**2:00–4:30 p.m. — Afternoon play.** A second play session, often calmer than the morning. Staff rotate so no one spends the whole day in the loudest room.

**4:00–6:30 p.m. — Evening pickup.** Dogs are checked out, owners are given a short report on their dog's day, and any incidents or observations are communicated honestly. Staff confirm the next booking.

**6:30–7:30 p.m. — Evening care.** Boarding dogs are fed, exercised, and settled for the night. Suites are cleaned, bedding is changed, and the overnight caretaker takes over with a written handover: which dogs are on site, which need medication, which had incidents, and which owners to contact in an emergency.

**Overnight.** The caretaker checks dogs on a schedule — at least every two to three hours — and logs each check. Any dog showing distress is assessed immediately and a veterinarian is called if needed.

## The booking and records system

Use booking software designed for pet care, not a paper diary or a generic calendar. The system should record: the dog's profile and vaccination dates, the owner's contact and emergency information, feeding and medication instructions, bookings, payments, and incident notes. Set automatic reminders for vaccination expiry — a dog whose vaccinations lapse should not be booked until records are updated. Keep payment records clean and reconcile them weekly. A booking system that cannot tell you how many dogs are on site tomorrow is not doing its job.

## Customer communication

Owners trust facilities that communicate clearly and honestly. Send a short report after a dog's first visit, with a photo and a note on how the dog settled in. Report incidents the same day, by phone for anything serious and by message for minor observations. Answer the phone during business hours, and return messages within one business day. Publish your hours, prices, policies, and vaccination requirements on your website so owners arrive informed rather than surprised.

Handle complaints the same way you handle incidents: listen, state the facts, explain what you will do, and follow up. A complaint handled well often creates a more loyal customer than a visit with no complaint at all.

## Cleaning, laundry, and maintenance routines

Assign cleaning and laundry by name and by shift, not by goodwill. The closing checklist each night includes: all dogs accounted for, all suites cleaned and bedded, all bowls washed, laundry running or folded, floors cleaned, gates and doors locked, alarms set, and the overnight handover written. A weekly maintenance check covers fencing, gate latches, flooring, drains, HVAC filters, and play equipment. Fix small problems immediately; a loose gate latch is a five-minute repair today and an escaped dog tomorrow.

## Monthly management routine

Once a month, the owner or manager reviews: occupancy by service, revenue by service, payroll as a percentage of revenue, customer numbers (new, returning, and lost), incident count and themes, staff attendance and turnover, and the budget versus actual spending. One page of numbers, reviewed monthly, catches problems while they are small. A facility that only looks at its bank balance discovers problems when the balance is already low.

## Action steps — Module 11

1. Write your daily schedule for your building, with named roles for each window.
2. Choose your booking software and set up vaccination-expiry reminders before opening.
3. Write your closing checklist and your overnight handover form.
4. Create a one-page monthly review template with occupancy, revenue, payroll percentage, and incident count.

---

# Module 12 — Marketing, Launch, and Growing to Full Occupancy

## Marketing a service people trust with their dog

Owners do not choose a daycare the way they choose a coffee shop. They choose based on trust, and trust is built by seeing the facility, meeting the staff, and hearing from other owners. Your marketing should therefore show the facility, introduce the people, and make it easy for a new owner to visit. A polished advertisement for a facility no one can visit is worthless. A clean, welcoming open house is worth more than a month of social media posts.

## Before opening: the pre-launch list

Start marketing 60 to 90 days before opening. Build an email list of interested owners through a simple landing page: the facility name, the location, the opening date, the services, and a form to join the waitlist. Offer waitlist members a founding-member benefit, such as a free trial day or 20 percent off the first package, in exchange for their email address. Visit local veterinarians, groomers, pet stores, and dog trainers, introduce yourself, and leave information about the facility. These businesses refer customers every week, and a personal introduction is worth more than a flyer. Join local dog-owner groups online and answer questions helpfully, without spamming. Post construction progress photos — owners enjoy watching a facility come together, and it builds anticipation.

## Launch week

Plan a launch week, not a launch day. Offer free trial half-days by appointment so new dogs can be assessed and owners can see the facility in operation. Host an open house on a Saturday, with staff present, playrooms visible, and information available. Invite the veterinarians, groomers, and trainers you met during pre-launch. Collect email addresses from every visitor. Follow up with every trial-day owner within 48 hours with a photo of their dog and an invitation to book a package.

Set a realistic launch target: 15 to 20 daycare dogs per day by the end of the first month, growing to 30 by month three and 40 by month six. Boarding builds more slowly and spikes at holidays. Plan your staffing and your cash flow around that ramp, not around full occupancy on day one.

## Ongoing marketing that works

- **Referrals.** Your best marketing is a happy owner telling another owner. Run a permanent referral credit: 25 dollars off for the referrer and 25 dollars off for the new customer. Track referrals and thank referrers personally.
- **Local partnerships.** Maintain relationships with veterinarians, groomers, trainers, and pet stores. Offer their clients a first-visit discount and thank the referrer. A monthly visit or a short update keeps the relationship alive.
- **Reviews.** Ask satisfied owners for a review after a good first month, and make it easy with a direct link. Respond to every review, including negative ones, politely and factually. Never pay for reviews or write fake ones.
- **Social media.** Post photos and short videos of dogs playing, with owner permission. Show the facility, the staff, and the daily routine. Post consistently — three to five times a week — rather than in bursts. Do not post photos of dogs without the owner's permission, and never post a photo of a dog that had an incident that day.
- **Webcams.** If you offer webcams, promote them. Owners who can check on their dog during the day are more likely to book and more likely to stay.
- **Community presence.** Sponsor a local rescue event, host a puppy socialization class, or offer a free nail-trim day once a quarter. Community presence builds the trust that advertising cannot buy.

## Measuring growth

Track these numbers monthly: number of active customers, number of new customers, number of customers who did not return and why, average daycare days per customer per month, boarding nights per month, occupancy by service, revenue per customer, and review rating. If new customers are arriving but not returning, the problem is the experience, not the marketing. Fix the experience first.

## Growing beyond full occupancy

When you reach consistent full occupancy, you have three options: raise prices modestly, extend hours or add weekend daycare, or expand the facility. Expanding — more space, more suites, more staff — is a second startup decision and deserves the same discipline as the first: check zoning, rebuild the budget, and confirm the market supports the larger facility. Do not expand on the strength of one busy holiday season. Expand on the strength of six months of sustained demand and a waiting list.

## Your first 8 weeks — a summary

- **Weeks 1–2:** Complete Modules 1–4. Confirm zoning, build the budget, and secure funding.
- **Weeks 3–4:** Secure the location, begin the build-out, and order equipment.
- **Weeks 5–6:** Hire and train staff, complete safety and emergency protocols, and set up booking software.
- **Weeks 7–8:** Run trial days, host the open house, and open with a founding-member offer.

The onboarding guide in this product gives a fuller week-by-week schedule.

---

## Closing Note

Opening a dog daycare and boarding facility is a serious undertaking. It requires capital, a suitable location, trained staff, and daily discipline. It also gives you something few businesses offer: a building full of dogs that owners trust you with, a service that genuinely improves their lives, and a business that can grow steadily for years. Do the work in this course in order, verify every local rule, insure the business properly, and open when you are ready — not a week before. The dogs, and their owners, will be glad you did.

---

*This course is education only and does not replace legal, veterinary, financial, tax, or insurance advice. Licensing, zoning, and insurance requirements vary by location and must be verified locally. No income or outcome is guaranteed.*
