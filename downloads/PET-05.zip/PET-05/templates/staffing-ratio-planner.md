# Staffing-Ratio Planner — Dog Daycare & Boarding Blueprint

## Ratios I Will Use

These are maximums, not targets. Fewer dogs per staff member is always safer. Never run a playroom with a single staff member if you can avoid it.

| Group type | Maximum dogs per staff member | My ratio |
|---|---|---|
| General daycare playgroups (large or high-energy) | 1 per 10 | |
| General daycare playgroups (calm, small dogs) | 1 per 15 | |
| Puppy groups (under 6 months) | 1 per 8–10 | |
| Senior or special-needs groups | 1 per 8–10 | |
| Boarding overnight (awake, on scheduled checks) | 1 per 20–25 | |

## Staff Required by Occupancy

Work out how many playroom staff you need at each occupancy level. Staff needed = dogs on site divided by your ratio, rounded up, with a minimum of two staff per playroom in use.

| Occupancy | Daycare dogs per day | Playroom staff needed (1:10) | Boarding dogs per night | Overnight staff needed |
|---|---|---|---|---|
| 40% | 16 | 2 | 10 | 1 |
| 60% | 24 | 3 | 14 | 1 |
| 80% | 32 | 4 | 19 | 1 |
| 100% | 40 | 4 | 24 | 1 |

Adjust the table above to your own capacity and ratios. Add reception, cleaning, feeding, and management time on top of playroom supervision — those hours are real work and must be scheduled and paid for.

## Worked Example: Payroll Model at 70% Occupancy

Illustrative figures. Replace every wage with your local market rate.

| Role | Hours per week | Hourly rate or salary | Weekly cost |
|---|---|---|---|
| Owner-operator / manager | 45 (salaried) | $1,050 per week | $1,050 |
| Lead attendant | 40 | $20 per hour | $800 |
| Attendant 1 | 40 | $17 per hour | $680 |
| Attendant 2 | 32 | $17 per hour | $544 |
| Attendant 3 (part-time) | 20 | $16 per hour | $320 |
| Overnight caretaker | 28 | $18 per hour | $504 |
| Reception support (part-time) | 16 | $16 per hour | $256 |
| **Total base payroll** | | | **$4,154 per week** |

Monthly base payroll: $4,154 × 4.33 = about $18,000.
Payroll taxes and workers' compensation (about 15%): about $2,700 per month.
**Total monthly labor cost: about $20,700.**

At 70% occupancy, illustrative monthly revenue is about $56,710 (daycare $21,560 + boarding $33,150 + add-ons $2,000). Labor at $20,700 is about 36% of revenue — within the healthy 40–55% range for this business. At 40% occupancy the same payroll would exceed 60% of revenue, which is why new facilities lose money in the early months and why working capital matters.

## My Payroll Model

Fill in with your own roles, hours, and local wages.

| Role | Hours per week | Hourly rate or salary | Weekly cost |
|---|---|---|---|
| | | | |
| | | | |
| | | | |
| | | | |
| | | | |
| | | | |
| **Total base payroll per week** | | | **$** |
| **Monthly base payroll (weekly × 4.33)** | | | **$** |
| **Payroll taxes and workers' comp (about 15%)** | | | **$** |
| **Total monthly labor cost** | | | **$** |

## Labor Cost as a Percentage of Revenue

| Occupancy | Monthly revenue | Monthly labor cost | Labor as % of revenue | Healthy? (target 40–55%) |
|---|---|---|---|---|
| 40% | | | | |
| 60% | | | | |
| 80% | | | | |
| 100% | | | | |

If labor exceeds 55% of revenue at your realistic occupancy, you need higher prices, higher occupancy, or lower costs — decide which before opening, not after.

## Scheduling Rules

- Build the schedule two weeks ahead and post it where staff can see it.
- Schedule extra hands for the morning intake rush (7:00–9:00 a.m.), the midday feeding and cleaning window, and the evening pickup rush (4:00–6:30 p.m.).
- Rotate playroom assignments so no one spends an entire shift in the loudest room.
- Give staff a real break away from dogs.
- Track overtime and keep it low — tired staff are a safety risk.
- Cross-train every attendant on feeding, cleaning, and reception so one absence does not shut down a function.

## New-Hire Training Sign-Off

Every new hire completes training before working unsupervised in a playroom. The hiring manager signs off each topic.

| Training topic | Trainee initials | Trainer initials | Date |
|---|---|---|---|
| Dog body language and stress signals | | | |
| Safe handling and moving dogs between areas | | | |
| Group management; reading play versus conflict | | | |
| Cleaning and sanitation (dilution and contact time) | | | |
| Feeding and medication logs | | | |
| Emergency procedures (injury, fight, escape, fire, power outage) | | | |
| Customer service and incident reporting | | | |
