# Safety & Emergency Protocols — Dog Daycare & Boarding Blueprint

Keep a printed copy of this document in the office and a copy in the isolation area. Review it with every new hire before their first unsupervised shift, and review it with all staff after any incident.

## Disclaimer

This document is safety-focused education only. It never replaces veterinary care. If a dog shows signs of distress, injury, or illness, contact the owner and a veterinarian immediately. Never delay veterinary care to wait for an owner to call back if a dog is in distress.

---

## 1. Emergency Contacts (fill in before opening)

| Contact | Name | Phone | Address / notes |
|---|---|---|---|
| Primary veterinarian | | | |
| 24-hour emergency veterinary clinic | | | |
| Animal poison control | | | |
| Animal control | | | |
| Fire department (non-emergency) | | | |
| Police (non-emergency) | | | |
| Insurance broker / claims line | | | |
| Facility owner / manager | | | |
| Building maintenance / plumber / electrician | | | |

Emergency number: 911 (or your local emergency number).

## 2. Vaccination and Health Intake Requirements

- Proof of current rabies, distemper/parvovirus, and Bordetella vaccinations from a veterinarian, checked before the first visit and at every renewal.
- Dogs that are actively coughing, vomiting, or have diarrhea are not accepted that day, even if the owner insists the dog is fine. Record the refusal and the reason.
- A veterinarian's clearance is required for any dog with a known contagious condition.
- Medication is administered only with written owner instructions and a signed authorization. Log every dose: dog, medication, dose, time, staff initials.
- Never give a dog medication that was not prescribed for that dog, and never adjust a dose.

## 3. Daily Health Observation

Staff check every dog at arrival and throughout the day: appetite, energy, stool, coughing, sneezing, skin, eyes, and gait. Any change is logged and reported to the manager the same day.

Signs that trigger immediate action (move the dog to isolation, contact the owner, consult a veterinarian): lethargy, refusal of food, vomiting, diarrhea, coughing, difficulty breathing, bleeding, limping or inability to stand, seizures, or any sudden change in behavior.

Common conditions staff should recognize (recognition only — diagnosis and treatment belong to a veterinarian): kennel cough (coughing, nasal discharge), canine influenza, parvovirus (vomiting, diarrhea, lethargy), and intestinal parasites.

## 4. Isolation Procedure

1. Move the dog calmly to the isolation area, away from other dogs.
2. Use separate cleaning supplies for the isolation area.
3. Contact the owner and a veterinarian. Follow the veterinarian's advice.
4. Clean and disinfect the area the dog was in, and any surfaces or bowls the dog used.
5. Log the incident: date, time, dog, symptoms, actions taken, veterinary advice, owner notification.
6. Do not return the dog to group play until a veterinarian clears it or the owner collects it.

## 5. Dog Fight — Response Procedure

1. Do NOT put your hands between fighting dogs.
2. Interrupt safely with a physical barrier (board or gate panel), a loud noise, or an approved interruption tool where your policy and local rules allow.
3. Separate the dogs into different areas and let arousal drop.
4. Check every dog and person involved for injuries. Apply first aid. Call a veterinarian if there is any doubt.
5. Move uninjured dogs to a calm area.
6. Document the incident in writing the same day: date, time, dogs involved, staff present, what happened, what was done, veterinary advice received.
7. Notify the owners of every dog involved, honestly and promptly. State the facts, the care given, and the next steps.
8. Review the incident with the team within 48 hours and change the system if needed.

## 6. Dog Bite or Serious Aggression Policy

Write your policy here and apply it consistently. A common policy: a dog that bites a person is suspended pending review and may be permanently dismissed; a dog involved in a serious fight is suspended and reassessed; a dog with three recorded aggressive incidents is dismissed from group play. Document every decision and communicate the policy to owners at intake.

**My policy:** ________________________________________________________________

## 7. Escape — Response Procedure

1. The staff member who notices the escape alerts the manager immediately.
2. One person stays with the remaining dogs; the others search in the directions the dog was last seen heading.
3. The manager (or designated staff member) calls the owner with the dog's description, last known location, and direction of travel.
4. If the dog is not found within 15 minutes, contact animal control and nearby veterinary clinics.
5. Log the escape: time, dog, how it happened, search actions, outcome.
6. Fix the cause before the next operating day — a loose latch, a fence gap, or a gate procedure.

**Prevention:** double-gated entries, latch checks twice daily, fence inspections weekly.

## 8. Fire Evacuation Plan

- Assembly point: ________________________________________________________
- Evacuation order (which dogs first, which route, who carries what): _______________
- Equipment kept ready: leashes, slip leads, carriers, headcount list of dogs on site.
- Boarding dogs must be evacuable at night by the overnight caretaker alone. If the plan requires four people, it is not a real plan.
- Exits are kept clear at all times. The plan is posted in the office and every playroom.
- Fire drills: quarterly, including at least one overnight drill per year.

## 9. Medical Emergency — Dog

1. Stop the activity and secure the dog.
2. Apply first aid from the stocked first-aid kit.
3. Call the veterinarian and the owner. If the dog needs emergency care, transport it to the emergency clinic named in Section 1, with the owner's emergency contact and the dog's medical records.
4. Document everything: time, symptoms, care given, veterinary advice, owner notification.
5. Never delay veterinary care to wait for an owner to call back if a dog is in distress.

## 10. Power Outage, Flood, or Severe Weather

- Emergency lighting and a battery-powered radio are kept accessible.
- Plan for keeping dogs safe, warm or cool, and watered if power fails: _______________
- Plan if part of the building floods: __________________________________________
- Criteria for closing early or canceling daycare for severe weather: _______________
- Owners are notified promptly if hours change.

## 11. Cleaning and Sanitation Schedule

- **Continuously:** pick up waste immediately; wipe spills; spot-clean accidents.
- **Midday:** clean and disinfect food and water bowls; wipe playroom surfaces; launder soiled bedding.
- **End of day:** remove dogs from each playroom in turn; pick up waste; hose or mop floors; apply disinfectant at the correct dilution with the required contact time; rinse where required; allow floors to dry; clean and disinfect kennels and suites; change bedding; wash bowls.
- **Weekly:** deep-clean walls, gates, play equipment, and drains; clean ventilation grilles; inspect and replace worn toys and bedding.
- **Monthly:** deep-clean laundry, kitchen, and storage; inspect flooring; service floor scrubber and washer.

Use only kennel-safe disinfectants. Follow dilution and contact-time instructions exactly. Never mix bleach with other cleaners. Store chemicals locked away from dogs and food. Keep safety data sheets for every chemical on site.

## 12. Incident Report Form

Copy this form for each incident.

- Date and time: ____________________
- Dogs involved: ____________________
- Staff present: ____________________
- What happened: ____________________
- Injuries (dogs and people): ____________________
- Care given and veterinary advice: ____________________
- Owners notified (when, by whom, how): ____________________
- Insurer notified (if applicable): ____________________
- What we will change: ____________________
- Report completed by: ____________________ Date: __________

Keep incident reports, veterinary records, vaccination records, and training sign-off sheets for at least three years, or longer if your insurer or local rules require it. If an incident may lead to a claim, notify your insurer promptly and follow their instructions. Do not admit fault in writing to an owner before speaking with your insurer.

## 13. Drill Log

| Drill | Date | Staff present | What worked | What to fix |
|---|---|---|---|---|
| Fire evacuation | | | | |
| Dog escape | | | | |
| Dog fight separation | | | | |
| Medical emergency | | | | |
| Power outage / severe weather | | | | |

Drill frequency: fire evacuation quarterly; escape quarterly; fight separation before opening and every 6 months; medical emergency before opening and every 6 months; power outage and severe weather annually.
