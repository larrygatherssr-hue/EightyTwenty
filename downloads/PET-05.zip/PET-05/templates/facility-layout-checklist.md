# Facility Layout Checklist — Dog Daycare & Boarding Blueprint

Use this checklist when evaluating a building and again before opening. Check every item, note the cost of anything that needs work, and do not open until safety and licensing items are complete.

## 1. Zoning, Licensing, and Legal

- [ ] Zoning confirmed in writing: dog daycare and boarding is a permitted use at this address
- [ ] Conditional-use permit obtained, or confirmed in writing that none is required
- [ ] Kennel or boarding license requirements identified; application submitted
- [ ] Business license obtained
- [ ] Building permit obtained for the build-out
- [ ] Fire inspection passed and certificate of occupancy obtained
- [ ] Health department approval obtained (if required locally)
- [ ] Sign permit obtained
- [ ] Sales tax registration completed (if required in your state)
- [ ] Lease signed with an express permitted-use clause for dog daycare and boarding
- [ ] Insurance in place, including care, custody, and control coverage, confirmed in writing

## 2. Building and Structure

- [ ] Total indoor area: ______ square feet (target 3,000–5,000 for a modest combined facility)
- [ ] Ceiling height adequate for ventilation and sound (note: ______ feet)
- [ ] Floor drains present or installable in every playroom, kennel area, and wash area
- [ ] Flooring chosen and installed: sealed concrete, epoxy, or commercial vinyl with heat-welded seams (no carpet, no bare wood in dog areas)
- [ ] Flooring is non-slip when wet
- [ ] HVAC sized for the dog load, not just the square footage
- [ ] Fresh-air exchange and exhaust fans installed
- [ ] Soundproofing installed: acoustic panels, solid-core doors, insulation
- [ ] Electrical service adequate for commercial washer, dryer, and HVAC
- [ ] Lighting adequate in every dog area, with natural light where possible
- [ ] No blind corners in playrooms where a dog can be cornered
- [ ] Staff can see the whole playroom from any position in it

## 3. Zones

- [ ] Lobby and reception (300–400 sq ft), separated from play areas by a door or gate
- [ ] Reception desk, seating, and a secure check-in area where dogs are leashed on handover
- [ ] Large-dog playroom: ______ sq ft (target 800)
- [ ] Small-dog playroom: ______ sq ft (target 500)
- [ ] Quiet and rest room: ______ sq ft (target 300)
- [ ] Boarding suites area: ______ sq ft, ______ suites (target 24 for the example facility)
- [ ] Every suite has a raised bed or platform, a non-tip water bowl, ventilation, and a secure latch
- [ ] Senior and low-energy dogs have a quiet area away from the noisiest playrooms
- [ ] Outdoor play yard(s): ______ sq ft, fencing at least 6 feet high, no gaps at the bottom
- [ ] Double-gated entry at every outdoor access point
- [ ] Shade and water available in every outdoor yard
- [ ] Dog wash area (150–250 sq ft) with drain, raised tub, and non-slip floor
- [ ] Kitchen and food-preparation area (100–150 sq ft) with sink, refrigerator, and labeled food storage
- [ ] Laundry area (about 100 sq ft) with commercial washer and dryer
- [ ] Isolation area, separate from other dogs, with its own cleaning supplies
- [ ] Locked storage for cleaning chemicals, away from dogs and food
- [ ] Staff break area and lockers
- [ ] First-aid station stocked and accessible

## 4. Safety and Security

- [ ] All gates latch securely; latches checked twice daily (add to the daily checklist)
- [ ] Fencing inspected weekly; no climbable structures near the fence
- [ ] No sharp edges, small parts, or fall hazards on play equipment
- [ ] Cleaning chemicals locked away; safety data sheets on site for every chemical
- [ ] Webcams in every playroom; security cameras covering lobby and exterior
- [ ] Fire exits clear, marked, and known to all staff
- [ ] Fire evacuation plan posted, including how boarding dogs are moved at night
- [ ] Emergency binder in the office and a copy in the isolation area

## 5. Capacity

- [ ] Licensed maximum number of dogs confirmed: ______
- [ ] Safe capacity by space (50–75 sq ft of indoor play space per dog in a group): ______ dogs
- [ ] Planned daycare capacity: ______ dogs per day
- [ ] Planned boarding capacity: ______ dogs per night
- [ ] Planned capacity is at or below the lower of the licensed cap and the safe space capacity

## 6. Parking and Neighborhood

- [ ] Parking for at least 10–15 cars
- [ ] Separate drop-off and pickup flow, or a plan to avoid congestion at peak times
- [ ] Building visited at 7:00 a.m. and 6:00 p.m. to check traffic and noise conditions
- [ ] Neighbors and nearby residences noted; noise plan in place

## Issues Found

| Issue | Location | Cost to fix | Fixed? |
|---|---|---|---|
| | | | |
| | | | |
| | | | |

## Sign-Off

- Building evaluated by: ____________________ Date: __________
- Contractor walk-through completed by: ____________________ Date: __________
- All safety and licensing items complete before opening: Yes / No
