# Debt-Free in 24 — Companion Workbook

**Use this workbook alongside the course manual. Fill in your own numbers. The Rivera household's figures are shown in each exercise as a worked example — replace them with yours.**

> **Disclaimer:** This workbook is general financial education only. It is not individualized financial, tax, or legal advice, and it does not guarantee any result. Your payoff timeline depends on your income, debts, and interest rates. Negotiation scripts are general education, not legal advice. If you are behind on payments or considering bankruptcy, speak with a nonprofit credit counselor or a licensed attorney before acting.

---

## Exercise 1 — Debt Inventory (Module 1)

List every non-mortgage debt. Do not include your mortgage here, but do include every card, loan, and buy-now-pay-later balance.

| # | Creditor | Type | Balance | APR | Minimum payment | Monthly interest (balance × APR ÷ 12) |
|---|---|---|---|---|---|---|
| 1 | | | $ | % | $ | $ |
| 2 | | | $ | % | $ | $ |
| 3 | | | $ | % | $ | $ |
| 4 | | | $ | % | $ | $ |
| 5 | | | $ | % | $ | $ |
| 6 | | | $ | % | $ | $ |
| **Total** | | | **$** | — | **$** | **$** |

**Worked example — the Rivera household:** Store Card $850 at 26.99% ($35 min, $19.12/mo interest); Credit Card A $2,400 at 19.99% ($72 min, $39.98); Credit Card B $4,600 at 24.99% ($115 min, $95.80); Personal Loan $7,800 at 11.50% ($245 min, $74.75); Auto Loan $11,200 at 7.90% ($310 min, $73.73). Totals: $26,850 balance, $777 minimums, $303.38 monthly interest.

**Reflection:** What surprised you about your total? Write one sentence.

___________________________________________________________________________

**Credit report check:** I pulled my reports from AnnualCreditReport.com on ___________. Debts found on the reports but missing from my inventory: _______________________________. Accounts I do not recognize: _______________________________.

---

## Exercise 2 — Payoff-Method Comparison (Module 2)

### A. Snowball order (smallest balance first)

| Order | Debt | Balance | APR |
|---|---|---|---|
| 1 | | $ | % |
| 2 | | $ | % |
| 3 | | $ | % |
| 4 | | $ | % |
| 5 | | $ | % |

### B. Avalanche order (highest APR first)

| Order | Debt | Balance | APR |
|---|---|---|---|
| 1 | | $ | % |
| 2 | | $ | % |
| 3 | | $ | % |
| 4 | | $ | % |
| 5 | | $ | % |

### C. Your decision

My chosen method: ☐ Snowball ☐ Avalanche

My reason, in one sentence: _______________________________________________

My first target debt (every extra dollar goes here): __________________________

**Worked example — the Riveras:** Snowball order: Store Card → Credit Card A → Credit Card B → Personal Loan → Auto Loan. Avalanche order: Store Card → Credit Card B → Credit Card A → Personal Loan → Auto Loan. At $1,100/month, the snowball costs $4,107.15 in interest and finishes in month 29 (May 2029); the avalanche costs $4,002.11 and also finishes in month 29. The difference is $105.04. The Riveras chose the snowball for the early wins.

### D. Decision questions

1. Have I started and stopped a debt plan before? ☐ Yes ☐ No — If yes, I am leaning snowball.
2. Is my highest-rate debt also a large balance? ☐ Yes ☐ No — If yes, I am leaning avalanche.
3. Which method will I actually keep doing for two years? ______________________

---

## Exercise 3 — Your Dated Plan (Module 3)

Monthly payoff budget: $___________ (total minimums $___________ + extra $___________)

My debt-free date: ___________________________

| Order | Debt | Balance | Payoff month | Payoff date |
|---|---|---|---|---|
| 1 | | $ | Month ___ | |
| 2 | | $ | Month ___ | |
| 3 | | $ | Month ___ | |
| 4 | | $ | Month ___ | |
| 5 | | $ | Month ___ | |

Total interest I expect to pay: $___________ (from the calculator)

**My commitment:** I, ____________________, will be debt-free on ____________________.

**Worked example — the Riveras (snowball, $1,100/month):** Store Card — month 3 (March 2027); Credit Card A — month 9 (September 2027); Credit Card B — month 18 (June 2028); Personal Loan — month 24 (December 2028); Auto Loan — month 29 (May 2029). Total interest $4,107.15.

### What moves my date?

- If I pay $100 more a month, my date moves to approximately: _______________
- If I pay $100 less a month, my date moves to approximately: _______________
- The one event most likely to knock my plan off course: ______________________
- My plan for that event: __________________________________________________

---

## Exercise 4 — The Minimum-Payment Trap (Module 4)

Fill in your own numbers using the calculator templates, or the paper method in the manual.

| | Minimums only | My dated plan |
|---|---|---|
| Monthly payment | $ | $ |
| Months to debt-free | | |
| Total interest | $ | $ |
| Total paid | $ | $ |

**Interest saved by my plan:** $___________ **Months saved:** ___________

**Worked example — the Riveras:** Minimums only ($777/mo): about 87 months, $10,093.26 interest, $36,943.26 total. Dated plan ($1,100/mo, snowball): 29 months, $4,107.15 interest, $30,957.15 total. Saved: $5,986.11 and 58 months.

**One card, two ways:** Pick your most expensive card. Balance $___________ at ______% APR.

- Fixed minimum payment of $___________/month: paid off in ______ months, $___________ interest.
- Declining minimum (about 2% of balance, $25 floor): roughly ______ months, $___________ interest.

What did the statement disclosure box say about your card? ______________________

---

## Exercise 5 — Budget to Payoff (Module 5)

### A. One-month spending record

Track every dollar for one month, then total each category.

| Category | Amount |
|---|---|
| Rent / mortgage | $ |
| Utilities | $ |
| Groceries | $ |
| Dining out / takeout | $ |
| Transport (insurance, fuel, transit) | $ |
| Phones | $ |
| Childcare / school | $ |
| Minimum debt payments | $ |
| Subscriptions | $ |
| Clothing / household | $ |
| Entertainment / miscellaneous | $ |
| Personal care | $ |
| Other: _______________ | $ |
| **Total spending** | **$** |
| Take-home pay | $ |
| Left over | $ |

### B. Find the money

| Change I will make | Monthly savings |
|---|---|
| | $ |
| | $ |
| | $ |
| | $ |
| | $ |
| **Total freed for the plan** | **$** |

**Worked example — the Riveras ($323/month):** Cancelled 3 unused subscriptions $55.98; dining out $385 → $220, saving $165; phone plan change $22; groceries $720 → $680, saving $40; miscellaneous $210 → $170, saving $40.

### C. Pay-first setup

- Payday(s): ______________________
- Automatic extra payment date: ______________________
- Amount: $___________ to (target debt): ______________________
- My budget line name for the payoff money: "Debt-Free ___________"

### D. Leaks list

Subscriptions and services I pay for but do not use: ____________________________

___________________________________________________________________________

---

## Exercise 6 — Emergency Fund (Module 6)

Starter fund target: $___________ ($1,000 recommended; $500 first if needed)

Current savings set aside for emergencies: $___________

Monthly contribution to the fund: $___________

Date I expect the fund to be complete: ___________________________

Where the fund lives (separate account): ______________________________________

**My definition of an emergency** (unexpected, necessary, urgent):

___________________________________________________________________________

**Replenishment rule:** If I use the fund, I pause the extra debt payment until the fund is back to $___________.

**Worked example — the Riveras:** $1,000 starter fund built over three months at $323/month before the full $1,100 plan began. In August 2027 they used $340 for a car repair, rebuilt the fund over two months, and returned to full speed in October 2027.

---

## Exercise 7 — Negotiation Script Practice (Module 7)

Prepare one call at a time. Fill this in before you dial.

**Debt I am calling about:** ______________________ **Creditor:** ______________________

**Account number:** ______________________ **Current APR:** ______% **Balance:** $___________

**What I am asking for:** ☐ Lower rate ☐ Fee waiver ☐ Hardship program ☐ Other: ___________

**The number I will ask for:** Lower the rate to ______% for ______ months / Waive the $______ fee / Reduce my payment to $______ for ______ months.

**My opening line (write it in your own words):**

___________________________________________________________________________

___________________________________________________________________________

**If they say no, I will ask:** "Is there a supervisor or a retention department I could speak with?"

**If they say no again, I will ask about:** ☐ A hardship program ☐ Trying again in 3–6 months

**Call log:**

| Date | Time | Who I spoke with | Confirmation # | What was agreed |
|---|---|---|---|---|
| | | | | |
| | | | | |
| | | | | |
| | | | | |

**Follow-up:** I checked my next statement on ___________ and the change ☐ was applied ☐ was NOT applied. If not applied, I called back on ___________.

**Rules I will follow on every call:**
- I will not give any collector electronic access to my bank account.
- I will not agree to a payment I cannot make.
- I will not agree to settlement terms until I have them in writing.
- I will get confirmation numbers and written confirmation of any agreed change.

---

## Exercise 8 — Monthly Payoff Tracker (Module 3, ongoing)

Photocopy or print this page once a month. One row per month.

**Plan month:** ______ **Date:** ___________ **Monthly payoff budget:** $___________

| Debt | Balance last month | Payment made | Balance this month | Target? |
|---|---|---|---|---|
| | $ | $ | $ | ☐ |
| | $ | $ | $ | ☐ |
| | $ | $ | $ | ☐ |
| | $ | $ | $ | ☐ |
| | $ | $ | $ | ☐ |
| **Total** | **$** | **$** | **$** | |

Expected total balance this month (from the plan): $___________

Actual total balance: $___________ — I am ☐ ahead ☐ on track ☐ behind by $___________

Why (if behind): ☐ Missed/partial payment ☐ New charge ☐ Fee ☐ Rate change ☐ Other: ___________

Next debt payoff: ______________________ in ______ months.

**A machine-readable version of this tracker is included as `monthly-payoff-tracker.csv` in the templates folder.**

---

## Exercise 9 — Milestone Tracker

Celebrate each payoff. Check it off, write the date, and roll the payment forward.

| Milestone | Date achieved | Payment freed | Rolled to |
|---|---|---|---|
| ☐ Debt 1 paid off: ______________ | | $ /mo | |
| ☐ Debt 2 paid off: ______________ | | $ /mo | |
| ☐ Debt 3 paid off: ______________ | | $ /mo | |
| ☐ Debt 4 paid off: ______________ | | $ /mo | |
| ☐ Debt 5 paid off: ______________ | | $ /mo | |
| ☐ Halfway: total balance below 50% | | — | |
| ☐ Emergency fund reached $1,000 | | — | |
| ☐ 12 months on the plan | | — | |
| ☐ DEBT-FREE | | $ /mo freed | |

**Worked example — the Riveras' milestones:** Store Card March 2027; Credit Card A September 2027; balance below 50% around March 2028; Credit Card B June 2028; Personal Loan December 2028; debt-free May 2029.

---

## Exercise 10 — Your 24-Month Plan

Use this page to lay out the next 24 months at a glance. Fill in the month, the target debt, the expected balance, and one note.

| Month | Date | Target debt | Expected total balance | Notes |
|---|---|---|---|---|
| 1 | | | $ | |
| 2 | | | $ | |
| 3 | | | $ | |
| 4 | | | $ | |
| 5 | | | $ | |
| 6 | | | $ | |
| 7 | | | $ | |
| 8 | | | $ | |
| 9 | | | $ | |
| 10 | | | $ | |
| 11 | | | $ | |
| 12 | | | $ | |
| 13 | | | $ | |
| 14 | | | $ | |
| 15 | | | $ | |
| 16 | | | $ | |
| 17 | | | $ | |
| 18 | | | $ | |
| 19 | | | $ | |
| 20 | | | $ | |
| 21 | | | $ | |
| 22 | | | $ | |
| 23 | | | $ | |
| 24 | | | $ | |

**After month 24, my remaining plan is:** ________________________________________

**My debt-free date:** ___________________________

---

## Staying Debt-Free — My Rules (Module 8)

Write your own version of the five rules, in your words:

1. Credit card rule: _________________________________________________________
2. 72-hour rule (purchases over $______ wait ______ hours): ____________________
3. Next car rule: ___________________________________________________________
4. New-debt test (three questions I will answer in writing first): _________________
5. Annual review date: ______________________ every year.

**First 90 days after debt-free:** I will direct my freed $___________/month to:

- Emergency fund: $___________/month
- Savings / investing: $___________/month

---

## Disclaimer

This workbook is general financial education only. It is not individualized financial, tax, or legal advice, and it does not guarantee any result. Payoff timelines depend on income, debts, and interest rates. Negotiation scripts are general education, not legal advice. Before making financial decisions, consider speaking with a qualified financial professional, a nonprofit credit counselor, or a licensed attorney in your state.
