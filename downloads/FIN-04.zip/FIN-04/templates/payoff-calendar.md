# Payoff Calendar — The Rivera Household (Worked Example)

Snowball method at $1,100 per month, starting January 2027. Total debt $26,850. Total interest $4,107.15. Debt-free May 2029 (month 29).

How to read this calendar: each row shows the balances at the end of that month, after that month's payments. When a balance reaches $0.00, that debt is paid off and its payment rolls to the next debt in the snowball order (Store Card → Credit Card A → Credit Card B → Personal Loan → Auto Loan).

Replace the Rivera numbers with your own using the snowball or avalanche calculator, and this calendar becomes yours.

| Month | Date | Store Card | Credit Card A | Credit Card B | Personal Loan | Auto Loan | Total Balance | Interest Paid So Far | Milestone |
|---|---|---|---|---|---|---|---|---|---|
| 0 | Start (Jan 2027) | $850.00 | $2400.00 | $4600.00 | $7800.00 | $11200.00 | **$26850.00** | $0.00 |  |
| 1 | Jan 2027 | $511.12 | $2367.98 | $4580.80 | $7629.75 | $10963.73 | **$26053.38** | $303.38 |  |
| 2 | Feb 2027 | $164.61 | $2335.43 | $4561.19 | $7457.87 | $10725.91 | **$25245.01** | $595.01 |  |
| 3 | Mar 2027 | $0.00 | $2112.65 | $4541.18 | $7284.34 | $10486.52 | **$24424.69** | $874.69 | Store Card paid off |
| 4 | Apr 2027 | $0.00 | $1717.84 | $4520.75 | $7109.15 | $10245.56 | **$23593.29** | $1143.29 |  |
| 5 | May 2027 | $0.00 | $1316.46 | $4499.89 | $6932.28 | $10003.01 | **$22751.64** | $1401.64 |  |
| 6 | Jun 2027 | $0.00 | $908.39 | $4478.60 | $6753.71 | $9758.86 | **$21899.56** | $1649.56 |  |
| 7 | Jul 2027 | $0.00 | $493.52 | $4456.87 | $6573.43 | $9513.11 | **$21036.93** | $1886.93 |  |
| 8 | Aug 2027 | $0.00 | $71.74 | $4434.68 | $6391.43 | $9265.74 | **$20163.59** | $2113.59 |  |
| 9 | Sep 2027 | $0.00 | $0.00 | $4054.97 | $6207.68 | $9016.74 | **$19279.39** | $2329.39 | Credit Card A paid off |
| 10 | Oct 2027 | $0.00 | $0.00 | $3594.41 | $6022.17 | $8766.10 | **$18382.68** | $2532.68 |  |
| 11 | Nov 2027 | $0.00 | $0.00 | $3124.27 | $5834.88 | $8513.81 | **$17472.96** | $2722.96 |  |
| 12 | Dec 2027 | $0.00 | $0.00 | $2644.33 | $5645.80 | $8259.86 | **$16549.99** | $2899.99 |  |
| 13 | Jan 2028 | $0.00 | $0.00 | $2154.40 | $5454.91 | $8004.23 | **$15613.54** | $3063.54 |  |
| 14 | Feb 2028 | $0.00 | $0.00 | $1654.27 | $5262.18 | $7746.93 | **$14663.38** | $3213.38 |  |
| 15 | Mar 2028 | $0.00 | $0.00 | $1143.72 | $5067.61 | $7487.93 | **$13699.26** | $3349.26 |  |
| 16 | Apr 2028 | $0.00 | $0.00 | $622.53 | $4871.18 | $7227.22 | **$12720.93** | $3470.93 |  |
| 17 | May 2028 | $0.00 | $0.00 | $90.50 | $4672.86 | $6964.80 | **$11728.16** | $3578.16 |  |
| 18 | Jun 2028 | $0.00 | $0.00 | $0.00 | $4020.02 | $6700.65 | **$10720.68** | $3670.68 | Credit Card B paid off |
| 19 | Jul 2028 | $0.00 | $0.00 | $0.00 | $3268.55 | $6434.77 | **$9703.32** | $3753.32 |  |
| 20 | Aug 2028 | $0.00 | $0.00 | $0.00 | $2509.87 | $6167.13 | **$8677.00** | $3827.00 |  |
| 21 | Sep 2028 | $0.00 | $0.00 | $0.00 | $1743.92 | $5897.73 | **$7641.65** | $3891.65 |  |
| 22 | Oct 2028 | $0.00 | $0.00 | $0.00 | $970.64 | $5626.56 | **$6597.19** | $3947.19 |  |
| 23 | Nov 2028 | $0.00 | $0.00 | $0.00 | $189.94 | $5353.60 | **$5543.54** | $3993.54 |  |
| 24 | Dec 2028 | $0.00 | $0.00 | $0.00 | $0.00 | $4480.60 | **$4480.60** | $4030.60 | Personal Loan paid off |
| 25 | Jan 2029 | $0.00 | $0.00 | $0.00 | $0.00 | $3410.10 | **$3410.10** | $4060.10 |  |
| 26 | Feb 2029 | $0.00 | $0.00 | $0.00 | $0.00 | $2332.55 | **$2332.55** | $4082.55 |  |
| 27 | Mar 2029 | $0.00 | $0.00 | $0.00 | $0.00 | $1247.90 | **$1247.90** | $4097.90 |  |
| 28 | Apr 2029 | $0.00 | $0.00 | $0.00 | $0.00 | $156.12 | **$156.12** | $4106.12 |  |
| 29 | May 2029 | $0.00 | $0.00 | $0.00 | $0.00 | $0.00 | **$0.00** | $4107.15 | DEBT-FREE — Auto Loan paid off |

## Summary

- **Start:** January 2027 — $26,850 owed, $777/month in minimums, $303.38/month in interest.
- **Month 3 (March 2027):** Store Card paid off. First win.
- **Month 9 (September 2027):** Credit Card A paid off. Two debts gone.
- **Month 12 (December 2027):** Total balance $16,549.99 — under $17,000 after one year.
- **Month 18 (June 2028):** Credit Card B paid off. Balance $10,720.68.
- **Month 24 (December 2028):** Personal Loan paid off. Only the auto loan remains: $4,480.60.
- **Month 29 (May 2029):** Auto Loan paid off. Total paid $30,957.15 ($26,850 debt + $4,107.15 interest). Debt-free.

## Build Your Own Calendar

1. Complete the debt inventory (Workbook Exercise 1).
2. Choose snowball or avalanche (Workbook Exercise 2).
3. Enter your debts into the matching calculator CSV and note each debt's payoff month.
4. Copy the table above, replace the Rivera rows with your payoff months and dates, and keep it where you will see it each month.

*This calendar is a worked example based on stated assumptions (fixed APRs, fixed minimums, no new charges, no fees, no missed payments). Your actual results will differ. This is general education, not individualized financial advice.*
