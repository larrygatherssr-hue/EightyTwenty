# Creditor Negotiation Scripts

**General education only — not legal advice.** Adapt these scripts to your own words and facts. Never agree to terms you do not understand, never give a collector electronic access to your bank account, and never agree to a payment you cannot make. Get any agreed change in writing and check your next statement to confirm it happened.

---

## Before Every Call

- Account number, current balance, APR, and minimum payment in front of you.
- Know what you are asking for, with a specific number in mind.
- Pen ready: date, time, representative's name, confirmation or reference number, and exactly what was agreed.
- Call from a quiet place when you are not rushed. Allow 15–30 minutes.

---

## Script 1 — Asking for a Lower Interest Rate

Use for any card charging more than about 15% APR. Call once, and if the answer is no, try again in three to six months.

> "Hello, my name is [your name], and my account number is [number]. I have been a customer for [number] years, and I have a balance of [amount] at [rate] percent. I am working on a plan to pay this balance off in full, and I am paying [amount] a month toward it. I would like to ask whether you can lower my interest rate. I have received offers from other cards at lower rates, and I would prefer to stay with you and pay this balance off here. Is there a lower rate you can offer me, even for twelve months?"

**If they say no:** "Is there a supervisor or a retention department I could speak with about this?"

**If the answer is still no:** "Do you have a hardship program I might qualify for?" Then thank them, write down what happened, and try again in three to six months.

**Worked example — what a rate cut is worth:** If the Rivera household got Credit Card B cut from 24.99% to 14.99% for the life of their plan, they would save roughly $700 in interest and finish about one month sooner. A twelve-month cut would save roughly $450. One phone call can be worth more than a month of budgeting.

---

## Script 2 — Asking for a Fee to Be Waived

Use for a late fee or an annual fee on any account.

> "Hello, my name is [your name], account number [number]. I see a [late fee / annual fee] of [amount] on my statement dated [date]. I have been a customer for [number] years and I pay on time. Could you waive this fee as a courtesy? I am working to pay this account off, and the fee makes that harder."

**If they say no:** Ask whether the annual fee can be removed by switching to a no-annual-fee card with the same issuer — but only if the switch does not close the account in a way that harms your credit history, which you should consider first.

---

## Script 3 — Asking About a Hardship Program

Call **before** you miss a payment, if your income has fallen or you cannot make the minimum.

> "Hello, my name is [your name], account number [number]. My income has changed because [brief, honest reason — reduced hours, job loss, medical costs], and I am concerned I will not be able to make my minimum payment of [amount] next month. I want to keep paying. Do you have a hardship program, or a temporary reduced-payment arrangement? I can pay [amount you can pay] a month right now."

**Ask specifically, and write down the answers:**
- What interest rate will apply, and for how long?
- Will the account be closed to new purchases while the program runs?
- What happens when the program ends?
- Will the account be reported as current?

Get the terms in writing before you agree.

---

## Script 4 — Talking to a Debt Collector

Use when a debt is with a collector. Do not agree to a payment on the first call.

> "Hello, my name is [your name]. I am calling about account [number]. Before I discuss payment, I would like you to send me written validation of this debt, including the original creditor, the amount, and the date of the last payment. Please send it to [your mailing address]. I will review it and contact you after I receive it."

**Rules for collector calls:**
- Do not give electronic access to your bank account.
- Do not agree to a settlement amount until you have the offer in writing, including whether the remaining balance will be forgiven and how the account will be reported.
- If a collector is abusive or threatens action they cannot legally take, end the call, write down what was said, and consider reporting the conduct to your state attorney general's consumer protection office or the Consumer Financial Protection Bureau.
- This is general information, not legal advice about your rights.

---

## Script 5 — Responding to a Settlement Offer

Sometimes a creditor or collector offers to settle a debt for less than the full balance — for example, $2,000 to settle a $4,600 balance. Before you agree:

> "Thank you for the offer. Before I agree to anything, please send me the settlement terms in writing, including the total amount I would pay, the payment date, confirmation that the remaining balance will be forgiven, and how the account will be reported to the credit bureaus. I will review it and get back to you."

**Understand before you sign:** the forgiven amount may be reported as income for tax purposes, and the account will usually be reported as settled rather than paid in full. This course does not recommend settlement for or against any particular debt. If you are considering it, speak with a nonprofit credit counselor or a tax professional first.

---

## Call Log

| Date | Time | Creditor | Who I spoke with | Confirmation # | What was agreed | Confirmed on next statement? |
|---|---|---|---|---|---|---|
| | | | | | | ☐ Yes ☐ No |
| | | | | | | ☐ Yes ☐ No |
| | | | | | | ☐ Yes ☐ No |
| | | | | | | ☐ Yes ☐ No |
| | | | | | | ☐ Yes ☐ No |

---

*These scripts are general education, not legal advice. If you believe a rate was raised improperly, a fee was charged in error, or a collector is violating the law, keep your statements, write down the dates and names of everyone you speak with, and consider speaking with a licensed attorney or your state attorney general's consumer protection office.*
