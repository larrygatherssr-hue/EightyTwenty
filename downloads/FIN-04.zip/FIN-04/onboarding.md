# Customer Onboarding Guide — Debt-Free in 24

Welcome. You now own the complete Debt-Free in 24 system: a written course manual, a companion workbook, calculators, a payoff calendar, and creditor negotiation scripts. This guide tells you exactly what to do first.

> **A note on format:** This is a complete **written** course manual. No video lessons are included in this edition. Everything the course teaches is in the manual, in writing, in full.

> **Disclaimer:** This product is general financial education only — not individualized financial, tax, or legal advice, and it does not guarantee any result. Your payoff timeline depends on your income, debts, and interest rates. If you are behind on payments or considering bankruptcy, speak with a nonprofit credit counselor or a licensed attorney before acting.

---

## What You Received

| File | What it is |
|---|---|
| `content.md` | The complete written course manual — 8 modules |
| `workbook.md` | Companion workbook — exercises for every module |
| `templates/debt-snowball-calculator.csv` | Snowball calculator with a worked example |
| `templates/debt-avalanche-calculator.csv` | Avalanche calculator with a worked example |
| `templates/payoff-calendar.md` | Month-by-month worked payoff calendar |
| `templates/creditor-negotiation-scripts.md` | 5 negotiation scripts + call log |
| `templates/monthly-payoff-tracker.csv` | Monthly tracker you fill in as you go |
| `sales-page.md` | The product sales page (reference copy) |
| `cover.png` | The product cover image |
| `listing.json` | Marketplace listing data |
| `cover.md` | Cover design brief |
| `onboarding.md` | This guide |
| `README.md` | File index |

---

## What to Do First (Day 1)

1. **Read the "Note Before You Begin"** at the top of `content.md`. It explains what this course is and is not.
2. **Gather your statements.** Every credit card, store card, personal loan, and auto loan. Do not include your mortgage in the payoff plan.
3. **Do Workbook Exercise 1** — the debt inventory. Write down every creditor, balance, APR, and minimum payment, then add up the totals. This is the hardest step, and it takes about 30 minutes.

## Suggested 4-Week Schedule

**Week 1 — See it clearly (Modules 1–2)**
- Read Module 1 and complete Workbook Exercises 1 and 2.
- Pull your free credit reports at AnnualCreditReport.com and check them against your inventory.
- Read Module 2, compare snowball vs. avalanche, and choose your method. Name your first target debt.

**Week 2 — Build the plan (Modules 3–4)**
- Read Module 3 and complete Workbook Exercise 3: your dated plan and debt-free date.
- Open the calculator that matches your method and replace the example rows with your own debts.
- Read Module 4 and complete Workbook Exercise 4: the minimum-only comparison. Write down what your plan saves you.

**Week 3 — Fund it and protect it (Modules 5–6)**
- Read Module 5 and complete Workbook Exercise 5: track one month of spending, find your extra payment, and set the automatic payment for payday.
- Read Module 6 and complete Workbook Exercise 6: set up your $1,000 starter emergency fund (or confirm the one you already have).

**Week 4 — Talk to your creditors (Module 7)**
- Read Module 7 and complete Workbook Exercise 7: prepare one call at a time.
- Start with the rate-reduction script for your highest-APR card. Log every call.
- Check your next statements to confirm any agreed changes took effect.

**Ongoing — Module 8**
- Read Module 8 before your first payoff, so you know what happens after the last payment.
- Use the monthly payoff tracker every month, on the same day. Ten minutes.
- Use the milestone tracker to mark each debt paid off.

## How to Use the Calculators

1. Open `debt-snowball-calculator.csv` or `debt-avalanche-calculator.csv` in Excel, Google Sheets, or any spreadsheet app.
2. The files contain the Rivera household's worked example. Replace each row with one of your debts: balance, APR, and minimum payment.
3. Order the rows by your chosen method — smallest balance first (snowball) or highest APR first (avalanche).
4. The payoff month for each debt, your total interest, and your debt-free date come from the plan you build in Module 3. Re-run the numbers whenever a rate changes, a payment is missed, or a new debt appears.

## How to Use the Monthly Tracker

- Print or copy `monthly-payoff-tracker.csv` (or Workbook Exercise 8) once a month.
- Record each balance, what you paid, and the total. Compare it with the expected balance from your plan.
- If you are behind, find out why: a missed payment, a new charge, a fee, or a rate change — then fix the cause, not just the number.

## Getting Support

- **Problems with your download or files:** contact EightyTwenty marketplace support.
- **Questions about your own debts, credit, or legal situation:** this product cannot answer those. Speak with a nonprofit credit counselor (look for an NFCC member agency) or a licensed attorney in your state.
- **If you are behind on payments:** contact your creditors and a nonprofit credit counselor before building your plan.

## Your First Milestone

Your first win is not a debt paid off. It is a finished inventory and a written debt-free date. Do that this week, and the rest of the system has something to work with.

**My debt-free date: ___________________________**
