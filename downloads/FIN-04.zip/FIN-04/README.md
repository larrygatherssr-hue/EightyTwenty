# FIN-04 — Debt-Free in 24: The Debt Elimination Workbook & System

**Category:** Finance & Wealth Building · **Price:** $149 one-time · **SKU:** FIN-04

A complete written debt payoff system for households carrying $5,000–$50,000 in non-mortgage debt. Compares snowball vs. avalanche with real worked numbers, builds a dated month-by-month payoff plan, and includes a companion workbook, calculators, a payoff calendar, and creditor negotiation scripts.

**Format note:** This edition is a complete written course manual. No video lessons are included.

## Files

| File | Description |
|---|---|
| `content.md` | The full written course — table of contents, 8 modules, appendices (10,444 words) |
| `workbook.md` | Companion workbook — 10 exercises/worksheets for every module |
| `templates/debt-snowball-calculator.csv` | Snowball calculator with worked example (Rivera household) |
| `templates/debt-avalanche-calculator.csv` | Avalanche calculator with worked example |
| `templates/payoff-calendar.md` | Month-by-month payoff calendar, Jan 2027 – May 2029 |
| `templates/creditor-negotiation-scripts.md` | 5 negotiation scripts + call log |
| `templates/monthly-payoff-tracker.csv` | Fillable monthly tracker (24 months) |
| `sales-page.md` | Full sales page — headline, problem/solution, module list, FAQ (12 questions), disclaimers |
| `listing.json` | Marketplace listing data (price_cents 14900, one-time) |
| `cover.png` | Product cover image — black-and-gold luxury design (1120 × 2240) |
| `cover.md` | Cover design brief |
| `onboarding.md` | Customer onboarding guide — first steps + 4-week schedule |
| `README.md` | This file |

## The Worked Example

All calculations use one consistent fictional household (Maya and Jordan Rivera): $26,850 across 5 debts, $777/month minimums, $1,100/month payoff budget. Snowball: 29 months, $4,107.15 interest, debt-free May 2029. Avalanche: 29 months, $4,002.11 interest. Minimums only: ~87 months, $10,093.26 interest. Every figure was computed month-by-month from the stated APRs.

## Disclaimers

Education only — not individualized financial, tax, or legal advice. No guaranteed results; payoff timelines depend on income, debts, and interest rates. Negotiation scripts are general education, not legal advice.
