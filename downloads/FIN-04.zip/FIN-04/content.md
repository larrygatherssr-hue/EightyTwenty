# Debt-Free in 24: The Debt Elimination Workbook & System

**The complete written course manual — 8 modules, a companion workbook, calculators, a payoff calendar, and creditor negotiation scripts.**

---

## A Note Before You Begin

This course is education, not individualized financial advice, legal advice, or tax advice. It teaches general principles, worked examples, and tools you can use to build your own debt payoff plan. It does not tell you what you personally should do with your money, and it cannot guarantee any result. Your payoff timeline depends on your income, your debts, your interest rates, and whether you can keep paying the plan amount every month. Nothing in this course creates a financial advisor–client relationship.

The example household used throughout this course — Maya and Jordan Rivera — is fictional. Their numbers are realistic and the payoff calculations are real arithmetic, but they are an illustration, not a promise. Your numbers will differ, and so will your results.

If you are behind on payments, facing collection lawsuits, considering bankruptcy, or unable to cover basic living costs, please speak with a nonprofit credit counselor (for example, a member agency of the National Foundation for Credit Counseling) or a licensed attorney in your state before acting on any strategy in this course. You can also contact your creditors directly — many have hardship programs — and you never have to pay a company to do that for you.

**Format note:** This is a complete written course manual. The catalog description for this product originally described a video course; no video has been recorded for this edition. Everything the course promises to teach is taught here, in writing, in full. If you were expecting video lessons, please do not buy this product — the written manual is the course.

---

## Table of Contents

- Module 1 — The Truth About Your Debt: Seeing the Whole Picture
- Module 2 — Snowball vs. Avalanche: Picking Your Payoff Method
- Module 3 — Your Payoff Date: Building the Dated Plan
- Module 4 — The Minimum-Payment Trap: What Interest Really Costs
- Module 5 — Finding Your Payoff Money: The Budget That Funds the Plan
- Module 6 — Your Safety Net: The Emergency Fund That Protects the Plan
- Module 7 — Talking to Creditors: Negotiation Scripts That Work
- Module 8 — Staying Debt-Free: Life After the Last Payment

---

## Meet the Example Household

Every worked example in this course uses one consistent household so you can follow the same numbers from the first module to the last.

**Maya and Jordan Rivera** are both 38. They live in a rented two-bedroom apartment with their two children. Their combined take-home pay is **$5,400 per month**. They are not reckless spenders. Like millions of households, they built their debt a few hundred dollars at a time — a car repair on a card, a furniture purchase on store credit, a personal loan to consolidate two older cards — and then discovered that the minimum payments never seemed to move the balances.

Here is their full debt inventory, exactly as it stands on the first day of their plan, January 1, 2027:

| Debt | Balance | APR | Minimum payment |
|---|---|---|---|
| Store Card | $850.00 | 26.99% | $35 |
| Credit Card A | $2,400.00 | 19.99% | $72 |
| Credit Card B | $4,600.00 | 24.99% | $115 |
| Personal Loan | $7,800.00 | 11.50% | $245 |
| Auto Loan | $11,200.00 | 7.90% | $310 |
| **Total** | **$26,850.00** | — | **$777** |

Five debts. Total balance $26,850. Total minimum payments $777 a month. The Riveras' debts are all non-mortgage debt — credit cards, a personal loan, and an auto loan. That is the debt this course is built for: household debt in the $5,000 to $50,000 range, carried by people earning a regular income, who want a dated plan to zero.

After working through Module 5, the Riveras free up an additional **$323 per month** from their budget. Their total monthly payoff budget becomes **$1,100** — the $777 in minimums plus $323 extra. Every payoff calculation in this course uses that $1,100 figure, and every comparison holds it constant, so the differences you see between methods are differences in method, not differences in effort.

Keep this household in mind as you read. When you reach the workbook, you will build the same tables with your own numbers.

---

## Module 1 — The Truth About Your Debt: Seeing the Whole Picture

### Why debt feels endless

Ask someone in debt how much they owe and you will usually get one of three answers: a guess, a single number that leaves something out, or silence. That is not a character flaw. Debt is designed to be hard to see all at once. Each account lives in its own app, its own statement, its own due date. The minimum payment on each one is small enough to feel manageable. Nothing in the system ever shows you the whole picture — the total balance, the total interest, the total time — in one place. So the debt feels endless, because from where you are standing, it has no edge and no end date.

The first job of this course is to give debt an edge and an end date. That starts with a complete inventory.

### Step 1: Gather every statement

Collect the most recent statement for every debt you owe, except your mortgage if you have one. This course is about non-mortgage debt. Include:

- Every credit card, including store cards and cards you have not used in months. A card with a zero balance is not a debt; a card with any balance is, even if you never use it.
- Personal loans, including loans from a bank, a credit union, or an online lender.
- Auto loans, including any loan on a vehicle you still owe money on.
- Buy-now-pay-later balances, medical payment plans, and any other installment debt.
- Any debt in collections. If a debt has been charged off or sent to a collector, it still counts. Note the collector's name and the amount they claim, and do not agree to anything about it until you have read Module 7.

Do not include your mortgage in the payoff plan, but do include the mortgage payment in your budget in Module 5, because it is part of your monthly spending.

For each debt, write down four things: the creditor's name, the current balance, the annual percentage rate (APR), and the minimum monthly payment. The APR is on your statement. If you cannot find it, call the number on the back of the card and ask. You need the real APR, not a guess, because the APR decides how much interest each debt costs you every month.

### Step 2: Add it up — and sit with the number

Add all the balances together. Add all the minimum payments together. Write both totals down.

The Riveras' totals are $26,850 in balances and $777 in minimum payments. If your total is higher than you expected, you are in normal company. Most people underestimate their total debt by a wide margin before they do this exercise, because they have never added it up. The number is not a verdict on you. It is a starting line. You cannot build a plan to zero from a number you have not looked at.

### Step 3: Work out what interest costs you each month

Here is the formula that runs this entire course:

**Monthly interest = current balance × (APR ÷ 12)**

Apply it to each debt. For the Riveras, in their first month:

- Store Card: $850 × (26.99% ÷ 12) = $850 × 0.022492 = **$19.12**
- Credit Card A: $2,400 × (19.99% ÷ 12) = $2,400 × 0.016658 = **$39.98**
- Credit Card B: $4,600 × (24.99% ÷ 12) = $4,600 × 0.020825 = **$95.80**
- Personal Loan: $7,800 × (11.50% ÷ 12) = $7,800 × 0.009583 = **$74.75**
- Auto Loan: $11,200 × (7.90% ÷ 12) = $11,200 × 0.006583 = **$73.73**

Total interest in month one: **$303.38**. That means of the Riveras' $777 in minimum payments, $303.38 — nearly forty cents of every dollar — goes to interest in the first month alone. Only $473.62 reduces what they owe. And that is the best month it will ever be on minimums alone, because every month the balance falls more slowly than the interest compounds.

Notice something important: Credit Card B, at $4,600 and 24.99%, costs $95.80 a month in interest — more than the auto loan costs on an $11,200 balance, because the auto loan's rate is a third of the card's. The size of a balance is not the same as the cost of a balance. Rate matters as much as size, and that fact is the whole argument of Module 2.

### Step 4: List your debts in two orders

You will need two orderings of your debts, and the workbook has a worksheet for both:

1. **Smallest balance first.** For the Riveras: Store Card ($850), Credit Card A ($2,400), Credit Card B ($4,600), Personal Loan ($7,800), Auto Loan ($11,200).
2. **Highest APR first.** For the Riveras: Store Card (26.99%), Credit Card B (24.99%), Credit Card A (19.99%), Personal Loan (11.50%), Auto Loan (7.90%).

These are the two payoff methods. You will choose one in Module 2, and the rest of the course builds the plan around it.

### Step 5: Check for errors and surprises

Before you plan, verify. Pull your free credit reports at AnnualCreditReport.com — the official site — and check that every debt on your reports matches your inventory. Look for:

- Debts you forgot about, including old store cards and medical accounts.
- Balances that are higher than your statements show, which can mean interest or fees have been added.
- Accounts listed as delinquent that you believed were current.
- Any account you do not recognize, which may be an error or identity theft. Dispute errors with the credit bureau in writing; do not ignore an account you do not recognize.

Also check each statement for fees: late fees, annual fees, over-limit fees. A card with a $95 annual fee is $95 a year of payoff money going nowhere. Note the fees in your inventory. Module 7 covers asking for fees to be waived.

### The honest conversation

Debt carries shame, and shame is the enemy of a plan. People hide statements, avoid opening mail, and pay minimums on autopilot because looking at the total feels like an accusation. It is not. Debt is a math problem with an emotional wrapper. The math is solvable — this course will prove that with real numbers in Modules 2 through 4. The emotional wrapper is handled by giving the plan a date: once you know the month you will be debt-free, the debt stops being endless and starts being a countdown. That is the shift Module 1 is for. You have now done the hardest part of the course, which is looking.

**Module 1 action checklist:**
- [ ] Every non-mortgage debt listed with creditor, balance, APR, and minimum payment
- [ ] Total balance and total minimums calculated
- [ ] Monthly interest calculated for each debt
- [ ] Debts listed smallest-balance-first and highest-APR-first
- [ ] Credit reports pulled and checked against the inventory
- [ ] Fees noted

---

## Module 2 — Snowball vs. Avalanche: Picking Your Payoff Method

### The two methods, plainly stated

There are two proven ways to order a debt payoff. Everything else is a variation of one of these.

**The debt snowball.** Pay minimums on everything. Put every extra dollar toward the debt with the *smallest balance*, regardless of its interest rate. When that debt is gone, roll its payment — its minimum plus the extra — onto the next-smallest balance. The payment grows like a snowball rolling downhill, which is where the name comes from.

**The debt avalanche.** Pay minimums on everything. Put every extra dollar toward the debt with the *highest interest rate*, regardless of its balance. When that debt is gone, roll the payment onto the next-highest rate. The avalanche attacks the most expensive debt first, so it always costs the least interest on paper.

Both methods work. Both have been studied, and both get people out of debt. The difference between them is smaller than most people expect, and the reason to choose one over the other has more to do with how you behave than how the math works. This module gives you the math first, then the behavior, then a decision rule.

### The Riveras, both ways

The Riveras have $1,100 a month to pay toward debt. Here is what happens under each method, calculated month by month with interest charged at each debt's APR before payments are applied.

**Snowball order** (smallest balance first): Store Card → Credit Card A → Credit Card B → Personal Loan → Auto Loan.

**Avalanche order** (highest APR first): Store Card → Credit Card B → Credit Card A → Personal Loan → Auto Loan.

Notice that the two orders differ only in the middle: the snowball attacks the $2,400 card at 19.99% before the $4,600 card at 24.99%; the avalanche reverses them. The Store Card comes first in both, because it is both the smallest balance and the highest rate — a common coincidence, and a lucky one for the Riveras.

**Results, $1,100 per month, both methods:**

| | Snowball | Avalanche |
|---|---|---|
| Debt-free month | Month 29 — May 2029 | Month 29 — May 2029 |
| Total interest paid | $4,107.15 | $4,002.11 |
| Total paid (debt + interest) | $30,957.15 | $30,852.11 |
| Difference | — | Saves $105.04 |

Both methods finish in the same month. The avalanche saves $105.04 in interest over 29 months — about $3.62 a month. That is the entire mathematical difference for the Riveras. It is real money, and it is small money. Keep that scale in mind when you read anyone claiming one method is dramatically better than the other. For most households in the $5,000 to $50,000 range, the difference between the methods is measured in weeks and low hundreds of dollars, not years and thousands.

**When each debt is paid off:**

| Debt | Snowball payoff month | Avalanche payoff month |
|---|---|---|
| Store Card ($850) | Month 3 — March 2027 | Month 3 — March 2027 |
| Credit Card A ($2,400) | Month 9 — September 2027 | Month 17 — May 2028 |
| Credit Card B ($4,600) | Month 18 — June 2028 | Month 14 — February 2028 |
| Personal Loan ($7,800) | Month 24 — December 2028 | Month 24 — December 2028 |
| Auto Loan ($11,200) | Month 29 — May 2029 | Month 29 — May 2029 |

This table is the real difference between the methods, and it is psychological, not mathematical. Under the snowball, the Riveras pay off a debt in month 3, another in month 9, and a third in month 18 — three wins in the first year and a half. Under the avalanche, they pay off a debt in month 3, and then nothing is fully paid off until month 14. For eleven months, every account is still open, and the plan can feel like it is not working, even though it is working slightly better on interest.

**Total balance remaining at checkpoints:**

| Month | Snowball balance | Avalanche balance |
|---|---|---|
| Month 1 | $26,053.38 | $26,053.38 |
| Month 6 | $21,899.56 | $21,892.57 |
| Month 12 | $16,549.99 | $16,493.21 |
| Month 18 | $10,720.68 | $10,624.69 |
| Month 24 | $4,480.60 | $4,378.96 |
| Month 29 | $0 | $0 |

The avalanche is ahead at every checkpoint after month 1, but never by more than about $100. The two lines are nearly on top of each other. The choice is not between a good method and a bad method. It is between a method that gives you early wins and a method that saves a small amount of interest.

### When the difference is bigger

The gap between snowball and avalanche grows when the highest-rate debt is also a large balance. Suppose a household owes $18,000 on a card at 27.99% and $900 on a store card at 22%. The snowball spends months clearing small debts while the $18,000 card accrues roughly $420 a month in interest. The avalanche attacks the big expensive card immediately and can save thousands. As a rule of thumb: if your highest-rate debt is also your largest balance, or if the rate gap between your debts is very wide (say, 8% versus 29%), lean avalanche. If your debts are close in size and rate, as the Riveras' are, the methods are nearly equivalent and behavior decides.

### The behavior argument

Research on debt payoff consistently finds that people who get an early win — a debt fully paid off — are more likely to keep going. A paid-off account is visible proof the plan works, and it frees up a payment, which makes the next win come faster. The snowball is engineered to produce that win as early as possible. Its critics call it irrational, because it does not minimize interest. Its defenders point out that a mathematically perfect plan you abandon in month five costs far more than a slightly imperfect plan you finish in month 29. A plan you quit has no payoff date at all.

The avalanche's behavioral case is different: it appeals to people who are motivated by efficiency and who find it satisfying to watch the total interest fall. If you are the kind of person who checks the numbers, who likes knowing you are paying the least possible interest, and who will not be discouraged by a long stretch without a payoff, the avalanche fits you.

### The decision rule

Answer these two questions honestly:

1. **Have you started and stopped a debt plan before?** If yes, choose the snowball. You need wins early, and the extra interest is the price of a plan you will actually finish.
2. **Do your debts differ wildly in rate — a 25%+ card alongside a 7% loan — with the expensive debt also being large?** If yes, choose the avalanche. The interest savings are big enough to matter.

If neither applies, choose the one you like more. The Riveras choose the snowball, because Maya has tried to pay down cards twice before and stalled both times when months passed without a debt disappearing. The $105.04 is, in her words, "the price of finishing." That is a reasonable trade, and it is hers to make.

Whichever you choose, write it down, write down why, and do not switch methods mid-plan without a real reason. Switching resets your momentum. The workbook has a decision worksheet for this module.

**A note on balance transfers and consolidation:** You may be tempted to move card balances to a 0% introductory card or take a consolidation loan. Those tools can help, and they can also hurt: transfer fees (typically 3% to 5% of the amount moved), a rate that jumps to 25% or more when the introductory period ends, and the risk of running the old cards back up. This course does not recommend for or against them; it treats them as a separate decision to make only after you have a working plan, with the full fee and post-intro rate written down first. If you do transfer a balance, the transferred debt keeps its place in your payoff order at its new rate.

**Module 2 action checklist:**
- [ ] Snowball order written down
- [ ] Avalanche order written down
- [ ] Method chosen, with the reason written in one sentence
- [ ] First target debt named — the debt every extra dollar goes to

---

## Module 3 — Your Payoff Date: Building the Dated Plan

### Why a date changes everything

A plan without a date is a wish. "I will pay off my debt someday" has no deadline, no test, and no moment when you can say it is working. A dated plan — "I will be debt-free in May 2029" — gives you a finish line, a monthly check, and a number you can defend. This module builds that plan for the Riveras, month by month, and then shows you how to build yours.

### The five numbers the plan needs

1. **Total debt** — the sum of every balance. Riveras: $26,850.
2. **Total minimum payments** — the sum of every minimum. Riveras: $777.
3. **Extra payment** — the money freed up in Module 5. Riveras: $323.
4. **Monthly payoff budget** — minimums plus extra. Riveras: $1,100.
5. **Payoff method** — snowball or avalanche, chosen in Module 2. Riveras: snowball.

The plan's rule is simple and never changes: **every month, pay every minimum, and put every remaining dollar of the $1,100 toward the target debt.** When the target debt is paid off, its minimum payment is not spent — it rolls into the next target debt. The payment grows as debts fall away. That is the snowball in motion.

### The Riveras' plan, month by month

Here is the snowball plan at $1,100 a month. The table shows the total balance remaining and the total interest paid so far at each checkpoint, with the debts paid off along the way. The full month-by-month calendar is in the templates folder as `payoff-calendar.md`, and the calculators that generate it are in the templates folder as spreadsheets.

| Month | Date | Total balance remaining | Interest paid so far | Debt paid off |
|---|---|---|---|---|
| 0 | January 2027 (start) | $26,850.00 | $0 | — |
| 1 | February 2027 | $26,053.38 | $303.38 | — |
| 3 | March 2027 | $24,424.69 | $874.69 | Store Card |
| 6 | June 2027 | $21,899.56 | $1,649.56 | — |
| 9 | September 2027 | $19,279.39 | $2,329.39 | Credit Card A |
| 12 | December 2027 | $16,549.99 | $2,899.99 | — |
| 18 | June 2028 | $10,720.68 | $3,670.68 | Credit Card B |
| 24 | December 2028 | $4,480.60 | $4,030.60 | Personal Loan |
| 29 | May 2029 | $0 | $4,107.15 | Auto Loan — debt-free |

Read the shape of that table. In the first year, the balance falls by about $10,300 — but $2,900 of the year's payments went to interest. By month 18 the balance is under $11,000, and the plan accelerates, because the same $1,100 is now spread across fewer debts and the interest charge shrinks every month. The last $4,480 takes five months. The first $4,480 took less than four. Debt payoff is slow at the start and fast at the end, which is exactly why people quit early: the early months are the hardest and the least visibly rewarding. Knowing that in advance is part of the plan.

**The payoff date: May 2029.** Twenty-nine months from the January 2027 start. The Riveras will pay $30,957.15 in total — their $26,850 of debt plus $4,107.15 of interest — and then the $1,100 a month is theirs again. Over the following year, that is $13,200 they can save, invest, or spend without a creditor involved. The plan does not just end debt; it starts the next phase of their finances, which is Module 8.

### How the payment grows

Watch what happens to the payment on the target debt as debts are eliminated. In month 1, the target is the Store Card. The Riveras pay its $35 minimum plus the $323 extra: $358 toward an $850 balance, and it is gone in month 3. In month 4, the target becomes Credit Card A. Its $72 minimum plus the $35 freed from the Store Card plus the $323 extra is $430 a month — and it is gone in month 9. By month 10 the target is Credit Card B, receiving its $115 minimum plus $72 plus $35 plus $323: $545 a month. By the final stretch, the entire $1,100 lands on the auto loan. The payment never increases out of the Riveras' pocket. It grows because finished debts hand their payments forward. That is the whole mechanism, and it is why you must not spend a freed-up minimum payment. The moment a paid-off card's $35 a month becomes takeout instead of payoff money, the snowball stops rolling.

### What changes the date

Your payoff date is not fixed in stone; it moves with four variables. Understand them now so that no surprise later feels like failure.

- **The monthly amount.** This is the big lever. At $900 a month, the Riveras would finish in 37 months and pay $5,828.36 in interest. At $1,300 a month, they finish in 24 months and pay $3,245.44. At $1,500 a month, they finish in 20 months and pay $2,708.69. Every additional $100 a month saves roughly two months and several hundred dollars of interest at this debt level. Module 5 is about finding that money.
- **The interest rates.** Rates can rise, especially on variable-rate cards. If a rate rises, the plan still works — it just costs more interest and may take longer. If a rate falls, or a balance is transferred, the date moves closer. Re-run the calculator whenever a rate changes.
- **New debt.** A single new $2,000 balance at 25% adds roughly two months and about $400 of interest to the plan at $1,100 a month. The plan survives new debt; it does not survive repeated new debt. Module 8 covers how to stop adding balances.
- **Missed or partial months.** Life happens — a car repair, a medical bill, a lost shift. If you pay less than the plan amount in a month, the date moves back by about a month for every month you fall short, and interest accrues on the higher balance. That is why Module 6 builds an emergency fund first: it is the thing that keeps one bad month from becoming a broken plan.

### Building your plan with the calculator

Open the template that matches your method — `debt-snowball-calculator.csv` or `debt-avalanche-calculator.csv` — and replace the Riveras' rows with your own debts. The spreadsheet's worked example shows the structure: one row per debt, with balance, APR, and minimum payment, and a payoff month calculated for each. If you do not use spreadsheets, the workbook has a paper version of the same calculation, and the payoff calendar template walks you through it by hand. Either way, the output is the same: a list of your debts in payoff order, a payoff month for each, a total interest figure, and a debt-free date. Write the date somewhere you will see it. Put it on the fridge, in your phone, on the first page of the workbook. A date you can see is a date you defend.

### The monthly check-in

On the same day each month — the day your first payment goes out is a good choice — spend ten minutes on the check-in:

1. Record each balance from the statements.
2. Record what you paid.
3. Compare the total balance to the plan's expected balance for that month. If you are ahead, say so out loud. If you are behind, find out why: a missed payment, a new charge, a fee, a rate change.
4. Note the next debt payoff date and how many months away it is.

The monthly payoff tracker template is built for exactly this. Ten minutes a month is the entire administrative cost of the plan. Everything else is just making the payments.

**Module 3 action checklist:**
- [ ] Monthly payoff budget written down (minimums + extra)
- [ ] Payoff order confirmed for your chosen method
- [ ] Payoff month and debt-free date calculated for every debt
- [ ] Debt-free date written somewhere visible
- [ ] Monthly check-in day chosen

---

## Module 4 — The Minimum-Payment Trap: What Interest Really Costs

### The trap, in one sentence

Minimum payments are set low enough to keep you paying for years and high enough to look responsible — and that combination is the most expensive way to repay debt that exists.

### The Riveras on minimums only

If the Riveras paid only the $777 in minimums each month and never a dollar more, here is what would happen to their $26,850 of debt, calculated with the same month-by-month arithmetic as Module 3:

- **Time to debt-free: about 87 months — 7 years and 3 months.**
- **Total interest paid: $10,093.26.**
- **Total paid: $36,943.26.**

Compare that with the plan: 29 months, $4,107.15 of interest, $30,957.15 total. Paying only minimums costs the Riveras **$5,986.11 more in interest** and **58 extra months** — nearly five more years — for the same debts. The extra $323 a month does not cost them $323 a month. It saves them almost $6,000 and five years. That is the single most important comparison in this course, and it is worth reading twice.

Why does the minimum-only path take so long? Because a minimum payment is mostly interest. In month one, $303.38 of the $777 is interest. As balances fall slowly, the interest falls slowly too, and the principal shrinks at a crawl. The system is not broken. It is working exactly as designed: a minimum payment keeps an account current and profitable for the lender at the same time. Your job is not to be angry about that. Your job is to stop being the person it is designed for.

### One card, two ways

The trap is easiest to see on a single card. Take Credit Card B on its own: $4,600 at 24.99% APR.

- **Paying a fixed $115 a month:** the card is paid off in **67 months** (5 years 7 months), with **$3,040.49** in interest. Total paid: $7,640.49 for a $4,600 balance.
- **Paying only the typical declining minimum** — the kind most card agreements use, roughly 2% of the balance with a $25 floor: the card takes about **462 months — more than 38 years** — with about **$16,637.85** in interest. Total paid: over $21,000 for a $4,600 balance.

That second figure is not a typo. A declining minimum shrinks as the balance shrinks, so the payment falls toward the floor, and the balance falls toward the floor with it, for decades. The card company discloses this on your statement — by law, statements must show how long a balance takes to repay on minimums and what it costs — but almost nobody reads that box. Read it on your next statement. It is the most honest paragraph your creditor will ever send you.

### The three numbers that matter

Whenever you look at a debt, three numbers tell you the truth about it:

1. **The monthly interest** — balance × (APR ÷ 12). This is what the debt costs you every month for the privilege of still owing it.
2. **The total interest to payoff** — what you will pay above the balance by the time it is gone, at your current payment. The calculator gives you this.
3. **The payoff date** — the month it reaches zero. A debt with no date is a debt you are renting, not repaying.

If you only remember one idea from this module, remember this: **interest is a monthly bill you pay for past spending, and the only ways to reduce it are to pay more each month, to pay at a lower rate, or to owe less.** There is no fourth way. Every strategy in this course is one of those three.

### What this module does not recommend

This course does not recommend borrowing to pay off borrowing as a general strategy, and it does not recommend any specific balance transfer, loan, or credit product. Consolidation can lower a rate, and a lower rate is one of the three ways to reduce interest — but it only helps if the new rate is genuinely lower after fees, if the old cards are not run back up, and if the new payment is no smaller than the old total payment. A consolidation loan that cuts your monthly payment in half and stretches the term to five years can cost more interest than the cards it replaced, even at a lower rate. Run the numbers before you sign anything, and never pay an upfront fee to a company that promises to settle your debts for you. If a debt is unmanageable, a nonprofit credit counselor can review your options, including a debt management plan, without charging the fees that for-profit settlement companies do.

### A note on interest and the law

Interest rates on your existing debts are governed by your cardholder agreements and by applicable law, which varies by state and by creditor. This course explains how interest is calculated; it does not interpret your agreements or advise you on your legal rights. If you believe a rate was raised improperly, a fee was charged in error, or a collector is violating the law, keep your statements, write down the dates and names of everyone you speak with, and consider speaking with a licensed attorney or your state attorney general's consumer protection office.

**Module 4 action checklist:**
- [ ] Minimum-only cost calculated for your total debt (time and interest)
- [ ] Plan cost calculated for comparison (from Module 3)
- [ ] Difference written down — months saved and interest saved
- [ ] The minimum-payment disclosure box read on your next statement
- [ ] Any debt with a declining minimum identified and noted

---

## Module 5 — Finding Your Payoff Money: The Budget That Funds the Plan

### The budget is not the punishment. The debt is.

Most budgeting advice fails because it starts with restriction and ends with guilt. This module starts somewhere else: with the fact that the Riveras need $323 a month above their minimums, and that money already exists in their spending. It is not hidden. It is sitting in subscriptions they forgot, food they throw away, and habits they would not miss. The job is to find it, name it, and move it to the plan before it gets spent anywhere else.

### Step 1: Write down the real month

For one month, track everything. Not a budget — a record. Every dollar out, written down the day it leaves. Use your bank's app, a notebook, or the workbook's spending tracker. Do not judge anything yet. The Riveras' first tracking month looked like this (take-home pay $5,400):

| Category | Amount |
|---|---|
| Rent | $1,450 |
| Utilities (electric, water, internet) | $310 |
| Groceries | $720 |
| Dining out and takeout | $385 |
| Car insurance and fuel | $340 |
| Phones (two lines) | $130 |
| Childcare and school costs | $480 |
| Minimum debt payments | $777 |
| Subscriptions (streaming, apps, gym, boxes) | $148 |
| Clothing and household | $165 |
| Entertainment and miscellaneous | $210 |
| Personal care | $95 |
| **Total** | **$5,210** |

Two things jump out. First, the total is $5,210 against $5,400 of income — only $190 unaccounted for, which means the Riveras are not wildly overspending. They are leaking. Second, the leaks are visible: $385 on dining out, $148 on subscriptions, $210 on miscellaneous. Nobody needs a lecture about those categories. They need a decision about them.

### Step 2: Sort spending into three buckets

- **Fixed and necessary:** rent, utilities, insurance, childcare, groceries, minimum debt payments, phones. These are hard to change quickly and mostly should not be changed while you are paying off debt — stability is part of the plan.
- **Flexible and negotiable:** dining out, entertainment, clothing, subscriptions, personal care. These can be reduced without hardship, and they are where payoff money comes from.
- **Leaks:** money spent without a decision — subscriptions nobody uses, food delivery fees, impulse purchases, duplicate services. Leaks are the easiest money to find because nobody will miss it.

The Riveras' audit found $148 a month in subscriptions, and when they listed them, three were unwatched or unused: a second streaming service ($15.99), a music app nobody had opened in months ($10.99), and a subscription box ($29.00). Cancelling those three freed **$55.98 a month** — money that was leaving their account for nothing.

### Step 3: The Riveras' $323

Here is exactly how the Riveras found their extra $323 a month. Your list will be different, and that is fine — the method is the same.

| Change | Monthly savings |
|---|---|
| Cancelled 3 unused subscriptions | $55.98 |
| Dining out cut from $385 to $220 (two takeout nights a month instead of six, plus one cooked "takeout night" at home) | $165.00 |
| Switched one phone line to a lower-cost plan at renewal | $22.00 |
| Groceries: meal plan and one fewer impulse trip a week ($720 → $680) | $40.00 |
| Miscellaneous cap: $210 → $170, with a $40 "anything" envelope | $40.00 |
| **Total freed** | **$322.98 → $323** |

None of these changes is dramatic. The family still eats takeout twice a month. Nobody cancelled anything they used. The children still have their activities. What changed is that $323 a month now has a job — it goes to the debt plan — instead of evaporating.

Three rules make the freed money actually arrive:

1. **Move it on payday.** Set an automatic transfer or an automatic extra payment for the day your pay lands. Money that sits in checking gets spent. Money that moves on payday does not.
2. **Pay the target debt first, not last.** The extra $323 goes to the target debt in the same week the pay lands. The minimums go out on their due dates. If the extra payment waits until the end of the month, it will be whatever is left, and whatever is left is usually nothing.
3. **Name it.** In the Riveras' budget, the line is not "extra." It is "Debt-Free May 2029." A line with a name and a date is harder to raid than a line called "miscellaneous."

### Step 4: If you cannot find the full amount

If your audit finds $120 and you need $323, do not abandon the plan. Start with the $120. A plan at $897 a month (the Riveras' minimums plus $120) still finishes years ahead of minimums alone, and you can raise the amount as you find more. Then look at the bigger levers, in this order:

- **One-time money:** a tax refund, a work bonus, a sold item, a rebate. Put windfalls toward the target debt the week they arrive, before they become spending. A $1,200 tax refund applied to the target debt saves roughly a month and about $200 of interest at the Riveras' rates.
- **Income:** an extra shift, overtime, a weekend job for a season, selling unused items. Even $150 a month of extra income, sustained for a year, moves a payoff date by about two months at this debt level. This is not a recommendation to overwork yourself; it is an option to weigh honestly.
- **Bigger fixed costs:** refinancing or re-shopping insurance, negotiating a bill, or — the hardest one — considering whether a car payment fits the plan at all. Do not make a big fixed-cost change in the first month. Let the plan run for three months first, so you are deciding from stability, not panic.

### Step 5: The budget that protects the plan

A payoff budget is not a normal budget. It has one extra rule: **the payoff amount is paid before discretionary spending, not after it.** In the Riveras' monthly order, the sequence is: rent and utilities, groceries, minimum debt payments, the $323 extra payment to the target debt, childcare, insurance, phones — and then everything else with what remains. When the plan is paid first, the rest of the month is honest: what is left is what you can spend, not what you hope to have left.

Build your budget with the workbook's budget-to-payoff worksheet. Revisit it every three months, or whenever income changes. A budget is a living document, and a payoff budget that never changes is a budget nobody is reading.

**A note on food and dignity:** A debt plan that cuts a family's food budget to the bone will fail, and it should. Groceries are not a leak. The Riveras cut $40 from groceries by planning meals, not by eating less. If your food spending is already tight, leave it alone and find the money elsewhere. A plan that keeps a household fed and stable is a plan that lasts 29 months. A plan that does not is a plan that lasts three weeks.

**Module 5 action checklist:**
- [ ] One full month of spending tracked
- [ ] Spending sorted into fixed, flexible, and leaks
- [ ] Extra monthly payment amount found and written down
- [ ] Automatic payment or transfer set for payday
- [ ] Budget-to-payoff worksheet completed
- [ ] "Debt-Free [your date]" named as a budget line

---

## Module 6 — Your Safety Net: The Emergency Fund That Protects the Plan

### The plan's single point of failure

Every debt plan has the same weakness, and it is not willpower. It is the unexpected $800 car repair, the emergency dental bill, the week of lost shifts. Without savings, an emergency goes on a credit card — the very card you are paying off — and the plan goes backwards. The emergency fund exists so that the plan survives real life. It is not a luxury to build after the debt is gone. It is part of the debt plan.

### The starter fund: $1,000

Before the Riveras put their full $323 extra toward debt, they built a **$1,000 starter emergency fund**. It took them three months: $323 a month for three months, with the debt plan running on minimums plus whatever was left, then the full $1,100 payoff budget began in month four of the plan year — which is why the payoff calendar in Module 3 starts in January 2027 with the fund already in place, funded in the last quarter of 2026.

If $1,000 sounds like a lot, start smaller. The first goal is $500, then $1,000. Even $500 covers the most common emergencies — a tire, a copay, a broken appliance part — that otherwise land on a card. The fund lives in a separate savings account, not in checking, and not in cash at home. It is for emergencies only, and "emergency" has a definition: something unexpected, necessary, and urgent. A sale is not an emergency. A holiday is not an emergency. A car repair that keeps you from getting to work is.

### Fund first, then full speed — the honest trade

Building the fund first delays the debt plan by the months the fund takes to build. For the Riveras, three months of building the fund meant three months of minimum-only payments, during which they paid roughly $910 in interest and reduced their balances by about $1,420. That is real money. But consider the alternative: starting the full plan with no savings, then putting a $900 transmission repair on Credit Card B at 24.99% in month five, adding a new balance to the debt they were paying off, and losing the psychological win of the Store Card payoff. The fund is insurance for the plan, and like all insurance, it costs something and pays for itself the first time it is needed.

If you already have $1,000 in savings, skip this step and start the full plan immediately. If you have less than $1,000, build the starter fund first. If you are behind on payments right now, talk to your creditors and a nonprofit credit counselor before building savings — catching up on past-due accounts comes first, because a past-due account can add fees and damage your credit while you save.

### Replenishing and growing

When the fund is used, the plan pauses the extra payment until the fund is rebuilt to $1,000. The minimums continue. This is not failure; it is the fund doing its job. The Riveras used $340 of their fund in August 2027 for a car repair, rebuilt it over the next two months by pausing part of the extra payment, and were back to full speed by October. Their debt-free date moved by about one month, and the plan survived intact.

After the last debt is paid, the fund grows. Module 8 covers building it from $1,000 to a full emergency fund of three to six months of essential expenses — the Riveras' target is $10,800, or three months of their $3,600 in essential monthly spending — using the same $1,100 a month that used to go to debt.

### Where the fund lives

- A separate savings account at your bank, or a high-yield savings account if you have one. The interest rate matters less than the separation.
- Not invested. Emergency money is not investment money; it must be available this week, in full, without a market to check.
- Not on a card, not in a line of credit, not borrowed. Credit is the thing the fund replaces.

**Module 6 action checklist:**
- [ ] Starter emergency fund target set ($1,000, or $500 first)
- [ ] Separate savings account opened or designated
- [ ] Monthly fund contribution set (or fund confirmed already in place)
- [ ] Written definition of "emergency" agreed for your household
- [ ] Replenishment rule written down: extra payment pauses until the fund is whole

---

## Module 7 — Talking to Creditors: Negotiation Scripts That Work

### The call you are allowed to make

Most people never call their creditors, because the idea feels like begging. It is not. Creditors would rather be paid something on agreed terms than be paid nothing after a charge-off, and every large creditor has departments, programs, and scripts of its own for exactly this conversation. You are not asking for a favor outside the system. You are using the system.

This module is general education about how these conversations work. It is not legal advice, and it does not tell you what to say about your specific situation. The scripts in the templates folder are starting points — adapt them to your words, your facts, and your comfort. Never agree to terms you do not understand, never give a collector access to your bank account, and never agree to a payment you cannot make.

### Before you call

- Have the account number, the current balance, the APR, and the minimum payment in front of you.
- Know what you are asking for, and have a number in mind. "Can you lower my rate?" is weaker than "Can you lower my rate from 24.99% to 12.99% for twelve months while I pay $545 a month toward this balance?"
- Have a pen ready. Write down the date, the time, the name of the person you speak with, any reference or confirmation number, and exactly what was agreed.
- Call from a quiet place, when you are not rushed. These calls take fifteen to thirty minutes.
- If you are behind on payments, know that you have the right to ask a debt collector to validate the debt in writing, and that you can ask them to stop calling your workplace. This course does not advise you on the law in your state; a nonprofit credit counselor or a licensed attorney can.

### Script 1: Asking for a lower interest rate

This is the highest-value call in the course. A rate cut on a large balance saves real money every month, and it costs nothing to ask.

> "Hello, my name is [your name], and my account number is [number]. I have been a customer for [number] years, and I have a balance of [amount] at [rate] percent. I am working on a plan to pay this balance off in full, and I am paying [amount] a month toward it. I would like to ask whether you can lower my interest rate. I have received offers from other cards at lower rates, and I would prefer to stay with you and pay this balance off here. Is there a lower rate you can offer me, even for twelve months?"

If they say no, ask: "Is there a supervisor or a retention department I could speak with about this?" If the answer is still no, ask about a hardship program. Then thank them, write down what happened, and try again in three to six months. Persistence is part of the strategy — rates are often lowered on the second or third ask, or after several months of on-time payments at the higher payment amount.

**What a rate cut is worth:** if the Riveras got Credit Card B cut from 24.99% to 14.99% for the life of the plan, they would save roughly $700 in interest and finish about one month sooner. If they got it cut for twelve months only, they would save roughly $450. Either way, one phone call is worth more than a month of couponing.

### Script 2: Asking for a fee to be waived

> "Hello, my name is [your name], account number [number]. I see a [late fee / annual fee] of [amount] on my statement dated [date]. I have been a customer for [number] years and I pay on time. Could you waive this fee as a courtesy? I am working to pay this account off, and the fee makes that harder."

Fees are waived often, especially a first late fee and annual fees for long-standing customers. If the fee is not waived, ask whether the annual fee can be removed by switching to a no-annual-fee card with the same issuer — but only if the switch does not close the account and hurt your credit history in a way you have considered.

### Script 3: Asking about a hardship program

If your income has fallen, or you cannot make the minimum payment, call before you miss it.

> "Hello, my name is [your name], account number [number]. My income has changed because [brief, honest reason — reduced hours, job loss, medical costs], and I am concerned I will not be able to make my minimum payment of [amount] next month. I want to keep paying. Do you have a hardship program, or a temporary reduced-payment arrangement? I can pay [amount you can pay] a month right now."

Hardship programs can reduce your rate, waive fees, or lower the payment for a set period, usually three to twelve months. They may also close the card to new purchases while the program runs. That is often a fair trade. Get the terms in writing before you agree, and ask specifically: what rate applies, for how long, what happens when the program ends, and whether the account will be reported as current.

### Script 4: Talking to a debt collector

If a debt is with a collector, the rules of the conversation are different, and this script is deliberately narrower.

> "Hello, my name is [your name]. I am calling about account [number]. Before I discuss payment, I would like you to send me written validation of this debt, including the original creditor, the amount, and the date of the last payment. Please send it to [your mailing address]. I will review it and contact you after I receive it."

Do not agree to a payment on the first call. Do not give electronic access to your bank account. Do not agree to a settlement amount until you have the offer in writing, including whether the remaining balance will be forgiven and how the account will be reported. If a collector is abusive or threatens action they cannot legally take, end the call, write down what was said, and consider reporting the conduct to your state attorney general or the Consumer Financial Protection Bureau. This paragraph is general information, not legal advice about your rights.

### Script 5: The settlement question

Sometimes a collector or creditor offers to settle a debt for less than the full balance — for example, $2,000 to settle a $4,600 balance. Settlement can be a legitimate option for a debt you cannot pay in full, but it has consequences you should understand before you agree: the forgiven amount may be reported as income for tax purposes, the account will usually be reported as settled rather than paid in full, and you need the settlement terms in writing before you pay anything. This course does not recommend settlement for or against any particular debt. If you are considering it, speak with a nonprofit credit counselor or a tax professional first, because the tax and credit consequences depend on your situation.

### After every call

Write down the date, the representative's name, the confirmation number, and the terms agreed. If terms were promised, ask for written confirmation. Check your next statement to make sure the change actually happened. If it did not, call back with your notes and the confirmation number. Your notes are your leverage.

**Module 7 action checklist:**
- [ ] Rate-reduction calls made for every card above 15% APR
- [ ] Fee waivers requested where fees appear
- [ ] Hardship program asked about if income has fallen
- [ ] Every call documented with date, name, and confirmation number
- [ ] Next statements checked to confirm agreed changes
- [ ] No bank-account access given to any collector

---

## Module 8 — Staying Debt-Free: Life After the Last Payment

### May 2029

In May 2029, the Riveras make their last debt payment: the final amount on the auto loan. The total paid over 29 months is $30,957.15. The $1,100 a month that went to debt is now free. This module is about what happens the day after, because getting out of debt and staying out of debt are two different skills, and the second one is the one that decides whether the first one mattered.

### The first 90 days after debt-free

Do not spend the $1,100. For the first three months after the last payment, keep living as if the payment still exists — because for 29 months, you did. Direct the $1,100 like this:

- **Months 1–3 after debt-free: $1,100 a month to the emergency fund.** The Riveras' fund grows from $1,000 to $4,300 in three months.
- **Then: split it.** The Riveras' standing split is $600 a month to the emergency fund until it reaches three months of essential expenses ($10,800), and $500 a month to retirement savings. Once the emergency fund is full, the whole $1,100 goes to long-term savings and investing, in line with their goals.

The point of the 90-day rule is not the money. It is the habit. If the $1,100 is spent the month the debt ends, the lifestyle expands to fill the freed income, and the household is one emergency away from a new card balance. If the $1,100 is redirected for three months, the household learns that it can live well on the income it has, and the money starts working for them instead of for a lender.

### The rules that keep you debt-free

1. **The credit card rule.** If you keep credit cards, use them only for spending you already budgeted, and pay the statement balance in full every month. A card paid in full every month costs nothing in interest. A card that carries a balance is a loan at 20% or more, whatever you call it.
2. **The 72-hour rule.** Any non-essential purchase over $100 waits 72 hours. Most of them do not survive the wait, and the ones that do are purchases you actually wanted.
3. **The car rule.** The Riveras' auto loan is gone. Their next car will be bought with money saved in advance, or with a loan they have planned for in the same way they planned this payoff — with a date, a monthly amount, and a total cost written down before they sign.
4. **The new-debt test.** Before taking on any new debt, answer three questions in writing: What is the total cost including interest? What is the payoff date? What will I not be able to do while I am paying this? If you cannot answer all three, you are not ready to borrow.
5. **The annual review.** Once a year, on the anniversary of your debt-free date, do a one-page review: total savings, emergency fund level, any new debt, and the plan for the next year. Debt does not usually return in one big decision. It returns in a year of small ones nobody reviewed.

### What to do with the skills

You now know how to inventory debt, compare payoff methods, build a dated plan, calculate the true cost of interest, find payoff money in a budget, build a safety net, and negotiate with creditors. Those skills do not expire. Use them for the next big financial decision — a car, a home, a child's education — the same way: get the numbers, compare the options, pick a date, and check in monthly.

### If you fall back

If new debt appears after you are debt-free, it is not a moral failure and it is not the end of the story. You have a system now, and systems can be re-run. Inventory the new debt, pick a method, build a dated plan, and start again. The second time is faster, because you already know how it ends: with a date, a zero balance, and a household that keeps its $1,100 a month.

### Your debt-free date

Write it here, in your workbook, and on the first page of your plan:

**I, ____________________, will be debt-free on ____________________.**

That sentence is the whole course. Everything before it was how to make it true.

---

## Disclaimer

This course provides general financial education only. It is not individualized financial advice, investment advice, tax advice, or legal advice, and it does not consider your personal circumstances. The example household, payoff calculations, and timelines are illustrations based on stated assumptions; your results will differ depending on your income, debts, interest rates, fees, and payment behavior. No result is guaranteed. Payoff timelines depend on income, debts, and interest rates, and can change if rates rise, payments are missed, or new debt is added. Negotiation scripts are general education, not legal advice. Before making financial decisions, consider speaking with a qualified financial professional, a nonprofit credit counselor, or a licensed attorney in your state. The author and publisher are not responsible for decisions you make based on this material.

---

*Debt-Free in 24: The Debt Elimination Workbook & System — complete written course manual. EightyTwenty marketplace, Finance & Wealth Building.*

---

## Appendix A — How the Numbers in This Course Were Calculated

Every payoff figure in this course was calculated the same way, month by month:

1. Interest is charged first, on the balance at the start of the month: balance × (APR ÷ 12).
2. Minimum payments are applied to each debt.
3. The remaining payoff budget is applied to the target debt.
4. When a debt reaches zero, its payment rolls to the next debt in the order.

The calculations assume fixed APRs, fixed minimum payments, no new charges, no fees, and no missed payments. Real life will differ — rates change, minimums on credit cards usually decline as balances fall, and fees can appear — so treat the figures as a planning estimate, not a bank statement. Re-run the calculator with your real numbers whenever anything changes.

## Appendix B — Glossary

- **APR (Annual Percentage Rate):** The yearly cost of borrowing, expressed as a percentage of the balance. Monthly interest is roughly the balance times the APR divided by 12.
- **Avalanche method:** Paying minimums on all debts and putting every extra dollar toward the debt with the highest interest rate.
- **Charge-off:** When a creditor writes off a debt as uncollectible, usually after about six months of non-payment. The debt is still owed and may be sold to a collector.
- **Debt snowball:** Paying minimums on all debts and putting every extra dollar toward the debt with the smallest balance.
- **Hardship program:** A temporary arrangement offered by a creditor — often a lower rate, waived fees, or a reduced payment — for borrowers whose income has fallen.
- **Minimum payment:** The smallest amount a creditor accepts each month to keep an account current. Paying only the minimum maximizes the time and interest required to repay a debt.
- **Payoff date:** The month in which the last debt in the plan reaches zero.
- **Principal:** The amount actually borrowed or owed, not counting interest.
- **Rolling the payment:** When a debt is paid off, adding its monthly payment to the payment on the next debt in the order, so the amount applied to the target debt grows as debts are eliminated.
- **Validation of debt:** A collector's obligation, on request, to provide written proof that a debt is yours, including the original creditor and the amount.

## Appendix C — A Second Worked Example: One Card, One Loan

Not every household has five debts. Consider Dana, 31, who has two: a credit card with $6,200 at 22.99% (minimum $155) and a personal loan with $3,400 at 9.99% (minimum $120). Her minimums total $275. She finds $175 a month in her budget, giving her a $450 monthly payoff budget.

- **Snowball:** smallest balance first — the $3,400 personal loan, then the card. Debt-free in about 24 months, total interest about $1,180.
- **Avalanche:** highest rate first — the card, then the loan. Debt-free in about 24 months, total interest about $1,090.
- **Minimums only:** about 71 months and roughly $3,400 in interest.

The lesson is the same at any debt level: the method matters less than the extra payment, and the extra payment matters enormously. Dana's $175 a month saves her about $2,200 in interest and more than three years. The system scales down as well as it scales up.

## Appendix D — Where to Get Help

- **Nonprofit credit counseling:** Look for an agency that is a member of the National Foundation for Credit Counseling (NFCC) or accredited by the Council on Accreditation. A reputable agency offers a free or low-cost review, and will not charge large upfront fees.
- **Your creditors' hardship departments:** Call the number on your statement and ask for the hardship or account assistance department.
- **AnnualCreditReport.com:** The official site for free weekly credit reports from the three major bureaus.
- **Consumer Financial Protection Bureau (consumerfinance.gov):** General information on debt collection, credit reporting, and how to submit a complaint.
- **Your state attorney general's consumer protection office:** For questions about debt collection practices in your state.

None of these resources is affiliated with this course, and this list is general information, not a referral or an endorsement.
