# Money Foundations Workbook

**Companion workbook to Money Foundations: The Personal Financial Literacy Masterclass**

---

## Disclaimer

This workbook is general financial education only. It is not individualized financial, investment, tax, legal, or insurance advice. The worksheets are tools for organizing your own information and plans. Before making a significant financial decision, consider speaking with a qualified, licensed professional who understands your full situation. No result is guaranteed.

## How to Use This Workbook

Work through one section per course module, in order. Fill in your real numbers — estimates are fine to start, but replace them with actual figures from your statements as soon as you can. Revisit the Net-Worth Tracker and the 90-Day Action Plan monthly. Print the pages you use most, or copy the tables into a notebook or spreadsheet.

---

## 1. Money Mindset Worksheet (Module 1)

Complete these sentences honestly, then challenge one belief in writing.

**"Money is…"**

1. ________________________________________
2. ________________________________________
3. ________________________________________
4. ________________________________________
5. ________________________________________

**"People with money are…"**

1. ________________________________________
2. ________________________________________
3. ________________________________________
4. ________________________________________
5. ________________________________________

**Belief I want to challenge:** ________________________________________

**Where did I learn it?** ________________________________________

**What would I do differently if I believed the opposite?** ________________________________________

**My top emotional spending trigger:** ________________________________________

**My alternative response when it hits:** ________________________________________

**My 72-hour wish list** (non-essential purchases over $50 — date them, buy only if you still want them after 3 days):

| Item | Price | Date listed | Still want it after 72 hours? | Bought? |
|---|---|---|---|---|
| | | | | |
| | | | | |
| | | | | |
| | | | | |

---

## 2. Monthly Budget Worksheet (Modules 2 and 3)

**Month:** ______________ **Take-home income:** $______________

### Income

| Source | Amount |
|---|---|
| Job / salary (after tax) | $ |
| Freelance / side income | $ |
| Other income | $ |
| **Total income** | **$** |

### Needs

| Category | Budgeted | Actual | Difference |
|---|---|---|---|
| Rent / mortgage | $ | $ | $ |
| Utilities (electric, gas, water) | $ | $ | $ |
| Phone and internet | $ | $ | $ |
| Groceries | $ | $ | $ |
| Transport | $ | $ | $ |
| Insurance | $ | $ | $ |
| Minimum debt payments | $ | $ | $ |
| Other needs | $ | $ | $ |
| **Needs subtotal** | **$** | **$** | **$** |

### Wants

| Category | Budgeted | Actual | Difference |
|---|---|---|---|
| Dining out and coffee | $ | $ | $ |
| Streaming and subscriptions | $ | $ | $ |
| Entertainment and hobbies | $ | $ | $ |
| Clothes and personal care | $ | $ | $ |
| Travel | $ | $ | $ |
| Fun money | $ | $ | $ |
| Other wants | $ | $ | $ |
| **Wants subtotal** | **$** | **$** | **$** |

### Savings and Debt Payoff

| Category | Budgeted | Actual | Difference |
|---|---|---|---|
| Emergency fund | $ | $ | $ |
| Retirement (IRA / 401(k)) | $ | $ | $ |
| Extra debt payments | $ | $ | $ |
| Sinking funds | $ | $ | $ |
| Goal savings | $ | $ | $ |
| **Savings subtotal** | **$** | **$** | **$** |

### Summary

| | Amount | % of income |
|---|---|---|
| Needs | $ | % |
| Wants | $ | % |
| Savings and debt payoff | $ | % |
| Buffer / miscellaneous | $ | % |
| **Total** | **$** | **100%** |

**Income minus total spending (cash-flow gap):** $________

**One change I will make next month:** ________________________________________

---

## 3. Savings-Goal Planner (Module 4)

### Emergency Fund

| | Amount |
|---|---|
| Monthly essential expenses | $ |
| 1-month target | $ |
| 3-month target | $ |
| 6-month target | $ |
| Current balance | $ |
| Monthly contribution | $ |
| Months to 3-month target | |

### Sinking Funds

| Future cost | Total needed | Due date | Monthly amount |
|---|---|---|---|
| | $ | | $ |
| | $ | | $ |
| | $ | | $ |
| | $ | | $ |

### Goal Savings

| Goal | Target amount | Deadline | Months left | Monthly amount needed | Current balance |
|---|---|---|---|---|---|
| | $ | | | $ | $ |
| | $ | | | $ | $ |
| | $ | | | $ | $ |

---

## 4. Credit Review Checklist (Module 5)

- [ ] I have obtained my free credit reports from AnnualCreditReport.com (all three bureaus).
- [ ] I have checked every account listed and confirmed I recognize it.
- [ ] I have checked every balance and payment history entry for errors.
- [ ] I have disputed any errors found, in writing, and kept a copy.
- [ ] I know my current credit score and the date I checked it: ______ (score: ______).
- [ ] I have calculated my credit utilization: total balances $______ ÷ total limits $______ = ______%.
- [ ] My utilization is below 30% (goal: below 10%).
- [ ] Autopay for at least the minimum is set up on every account.
- [ ] My oldest card is still open (or I understand the effect of closing it).
- [ ] I have reviewed my credit card interest rates and noted the highest: ______% on ______ card.
- [ ] I have set a calendar reminder to check my reports again in ______ months.

**Notes / disputes filed:** ________________________________________

---

## 5. Debt Payoff Planner (Module 6)

### My Debts

| Debt | Balance | Interest rate (APR) | Minimum payment | Payoff order |
|---|---|---|---|---|
| | $ | % | $ | |
| | $ | % | $ | |
| | $ | % | $ | |
| | $ | % | $ | |
| | $ | % | $ | |
| **Totals** | **$** | | **$** | |

**My chosen method:** Avalanche (highest rate first) / Snowball (smallest balance first) — circle one.

**Total monthly debt payment (minimums + extra):** $________

**Target debt-free date:** ______________

### Monthly Progress Log

| Month | Total debt at start | Payment made | Total debt at end | Debt paid off so far |
|---|---|---|---|---|
| | $ | $ | $ | $ |
| | $ | $ | $ | $ |
| | $ | $ | $ | $ |
| | $ | $ | $ | $ |
| | $ | $ | $ | $ |
| | $ | $ | $ | $ |

**Commitment:** I will not add new charges to these accounts while the plan runs. I will remove saved cards from shopping apps this week. Signed: ____________________ Date: __________

---

## 6. Insurance Checklist (Module 8)

| Policy | Provider | Coverage amount | Deductible | Monthly / annual premium | Renewal date | Beneficiary current? |
|---|---|---|---|---|---|---|
| Health | | | $ | $ | | — |
| Auto | | | $ | $ | | — |
| Renter's / homeowner's | | | $ | $ | | — |
| Life | | $ | — | $ | | Yes / No |
| Disability | | | — | $ | | — |
| Other | | | $ | $ | | |

**Gaps I found:** ________________________________________

**Quotes I will get:** ________________________________________

**Beneficiaries updated on (date):** ______________

---

## 7. Net-Worth Tracker (Module 2)

Update this table on the first of every month. The direction of the number matters more than any single value.

| Date | Cash & savings | Retirement accounts | Investments | Vehicle / property value | **Total assets** | Credit cards | Loans | Other debts | **Total liabilities** | **Net worth** |
|---|---|---|---|---|---|---|---|---|---|---|
| | $ | $ | $ | $ | $ | $ | $ | $ | $ | $ |
| | $ | $ | $ | $ | $ | $ | $ | $ | $ | $ |
| | $ | $ | $ | $ | $ | $ | $ | $ | $ | $ |
| | $ | $ | $ | $ | $ | $ | $ | $ | $ | $ |
| | $ | $ | $ | $ | $ | $ | $ | $ | $ | $ |
| | $ | $ | $ | $ | $ | $ | $ | $ | $ | $ |

**Net-worth change this quarter:** $________ **Direction:** Up / Down

---

## 8. Tax Snapshot (Module 9)

| Item | Amount / answer |
|---|---|
| Last year's total income | $ |
| Last year's total tax paid | $ |
| Effective tax rate (tax ÷ income) | % |
| Marginal tax rate | % |
| Withholding checked this year? | Yes / No |
| Tax-advantaged accounts I use | |
| Self-employed tax set-aside account opened? | Yes / No |
| Estimated quarterly payments due dates noted? | Yes / No |

---

## 9. Investing and Retirement Planner (Modules 10 and 11)

| Item | Answer |
|---|---|
| Money needed within 5 years (stays in savings) | $ |
| Investing time horizon | ______ years |
| Target mix (stocks / bonds) | ______% / ______% |
| Employer 401(k) match formula | |
| Am I contributing enough for the full match? | Yes / No |
| IRA type (Roth / Traditional) | |
| Annual IRA contribution | $ |
| Current retirement savings rate (incl. match) | % |
| Target retirement savings rate | 15% |
| Old employer accounts to roll over | |
| Monthly automatic investment amount | $ |
| Annual rebalance date | |

---

## 10. Goal-Setting Worksheets (Module 12)

### My Three Financial Goals

**Goal 1 (next 90 days):** ________________________________________

- Target: $________ by (date) ________
- Monthly action: ________________________________________
- Weekly action: ________________________________________

**Goal 2 (this year):** ________________________________________

- Target: $________ by (date) ________
- Monthly action: ________________________________________
- Weekly action: ________________________________________

**Goal 3 (next 3–5 years):** ________________________________________

- Target: $________ by (date) ________
- Monthly action: ________________________________________
- What needs to be true first: ________________________________________

### Goal-Setting Rules

- Make each goal specific, measurable, and dated — "save $3,000 for an emergency fund by June 30" beats "save more."
- Give every goal a monthly number. A goal without a monthly amount is a wish.
- Sequence goals by deadline and importance; fund the nearest deadline first.
- Review goals monthly and adjust the numbers when life changes — adjusting is not failing.

---

## 11. 90-Day Action Plan (Module 12)

### Days 1–30: Measure and Stabilize

| Action | Done? | Date |
|---|---|---|
| Wrote my money beliefs and challenged one | [ ] | |
| Tracked spending for 7 days | [ ] | |
| Calculated income, expenses, and net worth | [ ] | |
| Opened a high-yield savings account | [ ] | |
| Set up a $1,000 starter emergency cushion (or first $500) | [ ] | |
| Obtained free credit reports and checked for errors | [ ] | |
| Set up autopay (minimum) on every debt and bill | [ ] | |

### Days 31–60: Build the System

| Action | Done? | Date |
|---|---|---|
| Built my budget from real numbers | [ ] | |
| Set up payday automatic transfers | [ ] | |
| Chose avalanche or snowball and made first extra payment | [ ] | |
| Created sinking funds for three predictable costs | [ ] | |
| Confirmed employer retirement match; enrolled or increased | [ ] | |
| Reviewed insurance and got quotes for gaps | [ ] | |

### Days 61–90: Automate and Look Ahead

| Action | Done? | Date |
|---|---|---|
| Opened an IRA or increased retirement contribution | [ ] | |
| Set up automatic monthly investment | [ ] | |
| Checked tax withholding / set up quarterly payments | [ ] | |
| Scheduled a monthly 30-minute money review for the next year | [ ] | |
| Re-calculated net worth and compared it with day one | [ ] | |

### Monthly Money Review (copy this page each month)

**Month:** ______________

- What went well: ________________________________________
- What surprised me: ________________________________________
- Net worth this month: $________ (last month: $________)
- One thing I will change next month: ________________________________________

---

*End of workbook. Education only — not individualized financial advice.*
