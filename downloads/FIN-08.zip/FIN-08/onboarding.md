# Customer Onboarding Guide — Money Foundations

Welcome, and congratulations on taking the step most people never take: learning how money works, properly, in order. This guide tells you exactly what to do first, how to use the materials, and how to keep going.

## What You Received

| File | What it is |
|---|---|
| `content.md` | The full course text — 12 modules, a bonus chapter, glossary, and appendices (about 12 hours of study). |
| `workbook.md` | The 100-page companion workbook — one worksheet set per module, plus the 90-day action plan. |
| `templates/monthly-budget.csv` | Monthly budget spreadsheet, pre-filled with a realistic sample budget. |
| `templates/savings-goal-tracker.csv` | Savings-goal tracker with targets, deadlines, and monthly amounts. |
| `templates/net-worth-tracker.csv` | Net-worth tracker with a full year of monthly rows. |
| `templates/goal-setting-template.md` | Goal-setting template — one goal per copy, with milestones and check-ins. |
| `cover.png` | The course cover image. |

## What to Do First (Day 1)

1. **Read the disclaimer** at the start of the course. This is general financial education, not individualized advice.
2. **Read the Introduction and Module 1.** They explain how the course is ordered and why.
3. **Open the workbook** and complete the Money Mindset Worksheet (Section 1). It takes about 20 minutes.
4. **Start tracking your spending** for seven days. No categories, no judgment — just a list of every dollar. This is the raw material for Module 2.

## How to Use the Materials

- **Work in order the first time.** The modules build on each other — budgeting comes before investing for a reason.
- **Keep the workbook open beside the course.** Each module ends with action steps, and the workbook has a matching worksheet for each one. Do the exercise before moving on.
- **Use the spreadsheets for your real numbers.** The CSV files are pre-filled with a worked example (Maya, the sample student in the course). Replace her numbers with yours; the structure and formulas stay the same.
- **Print what you use most.** The monthly budget worksheet, the net-worth tracker, and the 90-day action plan are the pages you will return to every month.

## Suggested Schedule

| Week | What to do |
|---|---|
| Week 1 | Modules 1–2 + workbook Sections 1–2. Track spending, calculate income, expenses, and net worth. |
| Week 2 | Modules 3–4 + workbook Sections 2–3. Build your budget, open a high-yield savings account, start your emergency fund. |
| Week 3 | Modules 5–6 + workbook Sections 4–5. Check credit reports, list debts, choose a payoff method, make the first extra payment. |
| Week 4 | Modules 7–9 + workbook Sections 6 and 8. Set up the payday routine, review insurance, check withholding. |
| Week 5 | Modules 10–11 + workbook Section 9. Set your investment mix, capture the employer match, open or fund an IRA. |
| Week 6 | Module 12 + workbook Sections 10–11. Complete the 90-day action plan and schedule your monthly money reviews. |

After week 6, the course is done — and the system runs itself with a 15-minute weekly check and a 30-minute monthly review. Re-read a module whenever life changes: a raise, a move, a new job, a new child.

## How to Get Support

- **Download or access problems:** email the marketplace support address with your order number and a description of the issue. Support can help with downloads and access to the course files.
- **Questions about the material:** re-read the relevant module and its workbook section — most questions are answered by the worked examples.
- **Personalized financial, investment, or tax advice:** support cannot provide this. For decisions specific to your situation, consult a qualified, licensed financial planner, tax professional, or attorney.

## A Note on Results

No course can guarantee financial results, and this one does not try. What it guarantees is a complete system, worked examples with real numbers, and a plan you can follow. Your results depend on your income, your expenses, and — most of all — on doing the exercises and keeping the habits. Start on Monday. Start with one transfer, one worksheet, one automatic payment. Then do it again next week.
