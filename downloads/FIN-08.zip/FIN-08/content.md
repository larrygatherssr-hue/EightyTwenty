# Money Foundations: The Personal Financial Literacy Masterclass

**One complete money foundation — budgeting through investing, in a single ordered system.**

---

## Important Disclaimer — Please Read First

This course is general financial education only. It is not individualized financial, investment, tax, legal, or insurance advice, and it does not create an advisor-client relationship. The examples in this course use simplified, hypothetical numbers to illustrate concepts; they are not predictions, promises, or guarantees of any outcome. Investment values can fall as well as rise, and past performance does not guarantee future results. Tax rules, contribution limits, and program details change over time and vary by location — verify current rules with the relevant government agency or a licensed professional before acting. Before making a significant financial decision, consider speaking with a qualified, licensed financial planner, tax professional, or attorney who understands your full situation. You are responsible for your own decisions and results.

---

## Table of Contents

- Introduction: Why a Foundation, Not a Pile of Tips
- Module 1: Your Money Mindset — Beliefs, Habits, and the Psychology of Spending
- Module 2: Know Where You Stand — Income, Expenses, and Your Starting Net Worth
- Module 3: Budgeting That Actually Works — Building a Plan You Can Keep
- Module 4: Saving on Purpose — Emergency Funds, Sinking Funds, and Goals
- Module 5: Credit — How Scores Work and How to Build Yours
- Module 6: Debt — The True Cost and a Plan to Eliminate It
- Module 7: Banking, Cash Flow, and Protecting Your Money
- Module 8: Insurance — Protecting What You Build
- Module 9: Taxes — The Basics Every Earner Should Understand
- Module 10: Investing Foundations — Compound Growth, Risk, and Diversification
- Module 11: Retirement Accounts — 401(k)s, IRAs, and the Power of Starting Early
- Module 12: Your 90-Day Money Plan and Your Financial Life for the Next Decade
- Appendix A: Glossary of Key Terms
- Appendix B: Your Numbers at a Glance

---

## Introduction: Why a Foundation, Not a Pile of Tips

Most people who feel bad about money do not have a knowledge problem in the ordinary sense. They have read articles. They have watched videos. They have downloaded budgeting apps and deleted them. The problem is that the knowledge arrived in fragments — a tip about credit cards here, a video about index funds there, a podcast about side income somewhere else — with no order, no sequence, and no way to tell what matters now versus what matters later.

A foundation is different from a pile of tips. A foundation is built in order: first you understand your own behavior, then you measure where you stand, then you control the flow of money month to month, then you build safety, then you clean up debt, then you protect what you have, then you understand what the government takes, and only then do you invest for the long term. Each layer rests on the one before it. Skip a layer and the whole structure wobbles — that is why so many people who "know" they should invest still carry credit card balances at 24 percent interest, and why so many people who earn good salaries still live one emergency away from a crisis.

This course is that ordered system. It has twelve modules and roughly twelve hours of material. Work through them in order the first time. Do the exercises as you go, because financial literacy is a skill, not a spectator sport — reading about a budget is not the same as building one with your own numbers. By the end you will have a working budget, a savings plan, a debt payoff plan, a credit-building routine, an insurance checklist, a tax picture, an investment plan, and a 90-day action plan that turns all of it into weekly habits.

A note on numbers: every worked example in this course uses round, simplified figures so the arithmetic is easy to follow. Your numbers will differ. The method is what matters — plug in your own figures using the workbook and spreadsheets that come with this course, and the same logic will hold. Keep the workbook nearby as you read: each module ends with action steps, and the workbook has a matching worksheet for every one of them, so the course and the workbook work as a single system rather than two separate documents.

---

## Module 1: Your Money Mindset — Beliefs, Habits, and the Psychology of Spending

### What this module covers

Money behavior is mostly psychology. Two people with the same salary can end up in completely different financial positions, and the difference is rarely intelligence or luck. It is the set of beliefs they carry about money, the habits they repeat without thinking, and the environment they have built around themselves. This module helps you see your own patterns clearly, without judgment, so you can change the ones that are costing you.

### The beliefs you inherited

Almost everyone absorbed money beliefs before the age of ten, usually without noticing. If you grew up hearing that money is scarce and stressful, you may feel anxious even when your bank balance is healthy. If you grew up watching adults spend to signal success, you may feel pressure to keep up appearances. If money was never discussed at all, you may have entered adulthood with no mental model for it — which is how capable, intelligent people end up confused about a credit card statement.

None of these beliefs is your fault, but all of them are now your responsibility to examine. A useful exercise is to write down five sentences that complete the phrase "Money is…" and five that complete "People with money are…" Do not edit yourself. Then, for each sentence, ask: Is this true? Is it always true? Where did I learn it? What would I do differently if I believed the opposite? You do not need to replace every belief at once. You need to notice which ones are running your decisions.

### How spending actually works

Spending is rarely a rational calculation. Research in behavioral economics has repeatedly shown that people spend more when payment is frictionless — a saved card, a one-click checkout, a tap-to-pay phone — because the "pain of paying" is lower when you do not handle cash or type in a number. Subscriptions are powerful for the same reason: the money leaves quietly, month after month, and you only notice it when you look.

Three patterns account for most unplanned spending:

1. **Emotional spending.** Stress, boredom, celebration, and loneliness all trigger purchases that feel like relief in the moment and regret later. The purchase is not the problem; it is the coping mechanism. Naming the emotion before you buy — "I am stressed, and I want comfort" — breaks the automatic link more reliably than willpower.
2. **Social spending.** Keeping up with friends, colleagues, or influencers is expensive, and it is often invisible: the restaurant you did not want, the gift exchange you could not afford, the lifestyle that social media makes look normal. A simple question helps: "Would I buy this if nobody ever saw it?"
3. **Convenience spending.** Delivery fees, ride-shares, takeout, and impulse add-ons are individually small and collectively large. A $12 lunch five days a week is $3,120 a year. That is not a moral judgment — convenience has real value — but it should be a conscious choice, not a default.

### The 72-hour rule and other friction tools

You cannot eliminate impulses, but you can slow them down. The most effective single habit in this course is the 72-hour rule: any non-essential purchase over $50 waits 72 hours before you buy it. Put it on a list. If you still want it three days later, buy it with a clear conscience. In practice, most items never get bought — the desire was a moment, not a need.

Other friction tools that work: remove saved payment methods from shopping apps; unsubscribe from marketing emails (they exist to create urgency); keep a "fun money" amount in your budget so spending is planned rather than forbidden; and use a weekly cash allowance for discretionary spending if digital money feels too abstract.

### Identity beats willpower

Willpower is a poor long-term strategy because it depletes. Identity is stronger: people who see themselves as "someone who saves" make different choices automatically than people who see themselves as "someone trying to save." Start small and let the identity follow the evidence. Save $25 a week for a month and you have proof — "I am a person who saves $100 a month" — and that proof makes the next month easier. Financial confidence is built the same way physical fitness is: small, repeated actions, not heroic efforts.

### Module 1 action steps

1. Write your five "Money is…" and five "People with money are…" sentences, and challenge one of them in writing.
2. Track every dollar you spend for seven days — no categories, no judgment, just a list.
3. Start a 72-hour wish list for non-essential purchases over $50.
4. Identify your top emotional spending trigger and write one alternative response (a walk, a call, a workout, a cup of tea).

---

## Module 2: Know Where You Stand — Income, Expenses, and Your Starting Net Worth

### What this module covers

You cannot navigate without knowing your starting point. This module is a financial snapshot: what comes in, what goes out, what you own, and what you owe. It takes about an hour, and it is the single most clarifying exercise in the course. Most people who do it discover either that they earn more than they thought and the money is leaking somewhere, or that a fixed cost they assumed was small is actually the largest line in their budget. Either way, the picture replaces anxiety with information.

### Step 1: Your real income

List every source of income you receive in a typical month, using your after-tax (take-home) amounts — the money that actually lands in your account. Include your salary or wages, freelance or side income, tips, benefits, and any other regular payments. If your income varies, use the average of the last three months, or the lowest of the three if you want a conservative plan. Do not count hoped-for income, bonuses that have not arrived, or money you might earn.

**Worked example — Maya, 28, marketing associate.** Maya earns $4,200 per month after tax from her job, and about $300 per month from weekend freelance design work (averaged over three months). Her total monthly take-home income is $4,500.

### Step 2: Your real expenses

Gather the last three months of bank and credit card statements. Go through them line by line and sort every transaction into one of three buckets: **needs** (housing, utilities, groceries, transport to work, insurance, minimum debt payments), **wants** (dining out, streaming, hobbies, travel, new clothes beyond replacement), and **savings and debt payoff beyond minimums** (extra debt payments, retirement contributions, emergency fund). The 50/30/20 guideline — roughly 50 percent needs, 30 percent wants, 20 percent savings and debt payoff — is a useful reference point, not a law. In expensive cities, needs may run to 60 percent, and that is fine; the point is to see your actual split, not to force a ratio.

**Worked example — Maya's spending.** Over three months, Maya's average monthly spending is: rent $1,500; utilities and phone $220; groceries $380; transport $180; insurance $140; minimum student loan payment $210 — needs total $2,630, or about 58 percent of her income. Dining out and coffee $320; streaming and apps $55; gym $45; clothes and personal care $120; travel savings $100 — wants total $640, or 14 percent. Extra student loan payment $200; Roth IRA $250; emergency fund $150 — savings and extra debt payoff total $600, or 13 percent. That leaves $630 unaccounted for — the "mystery money" that disappears into small, unrecorded purchases. Finding that $630 is the entire point of this exercise.

### Step 3: Your net worth

Net worth is simply what you own minus what you owe. List your assets: cash in checking and savings, retirement accounts, investment accounts, the current value of a car or other property you could sell. Then list your liabilities: credit card balances, student loans, auto loans, personal loans, any other debts. Subtract liabilities from assets. The result may be negative, especially early in your working life, and that is normal — a negative net worth is a starting point, not a verdict. What matters is the direction it moves each month.

**Worked example — Maya's net worth.** Assets: checking $800; savings $2,400; Roth IRA $3,100; car worth about $8,000. Total assets: $14,300. Liabilities: student loan $11,500; credit card $900; auto loan $6,200. Total liabilities: $18,600. Net worth: $14,300 − $18,600 = **−$4,300**. Maya now knows exactly where she stands, and she can watch that number climb as she pays down debt and builds savings.

### Step 4: Your cash-flow gap

Subtract total monthly spending from total monthly income. A positive gap is money you can direct on purpose — toward savings, debt, or goals. A negative gap means you are spending more than you earn, which is unsustainable and must be addressed before anything else in this course will work. If your gap is negative, the fix is either to raise income or cut spending, and Module 3 gives you the tools for both.

### Module 2 action steps

1. Calculate your monthly take-home income from all sources.
2. Categorize three months of statements into needs, wants, and savings/debt payoff.
3. Calculate your net worth and write it down with today's date.
4. Find your "mystery money" — the gap between income and recorded spending — and name where it is going.

---

## Module 3: Budgeting That Actually Works — Building a Plan You Can Keep

### What this module covers

A budget is not a punishment. It is a plan for your money before the month begins, so that your money does not make its own plans while you are not looking. Most budgets fail for three reasons: they are too restrictive to sustain, they are built from guesses instead of real spending data, or they are never reviewed. This module fixes all three.

### Start with your real numbers

Because you completed Module 2, you already have three months of real spending data. Build your first budget from those averages, not from an ideal version of yourself. If you actually spend $380 a month on groceries, do not budget $200 and then feel like a failure on the 18th of the month. Budget $380, watch it for a month, and then decide whether you want to change it. A budget that reflects reality is one you can keep; a budget that reflects a fantasy is one you will abandon.

### Choose a method

There is no single best budgeting method — there is the method you will actually use. Three proven approaches:

**The 50/30/20 budget.** Allocate roughly 50 percent of take-home pay to needs, 30 percent to wants, and 20 percent to savings and extra debt payoff. It is simple and flexible, which is why it is the most popular starting point. Use it as a diagnostic: if your needs are 65 percent, your first project is reducing a fixed cost, not cutting coffee.

**Zero-based budgeting.** Give every dollar a job before the month starts, so income minus planned spending equals zero. This is the most precise method and the most work; it suits people who like detail and control. The "zero" does not mean you spend everything — savings and debt payoff are jobs too.

**Pay-yourself-first (reverse budgeting).** Set up automatic transfers on payday — savings, extra debt payment, retirement — and spend the rest freely without tracking every category. This works well for people who hate tracking but are disciplined about the automatic transfers. Its weakness is that without categories, lifestyle creep can quietly absorb the "rest."

You may combine them: pay yourself first for savings, then run a loose 50/30/20 check on what remains. The right answer is the one you still use in month six.

### A complete sample monthly budget

Here is a full monthly budget for a single adult earning $4,500 per month after tax — Maya from Module 2, revised after she found her mystery money and made deliberate choices.

| Category | Amount | Notes |
|---|---|---|
| Rent | $1,500 | 33% of income — high, but her lease runs 8 more months |
| Utilities and phone | $220 | Includes electricity, internet, mobile |
| Groceries | $380 | Meal-planned, one weekly shop |
| Transport | $180 | Transit pass plus occasional rides |
| Insurance | $140 | Renter's and auto |
| Minimum loan payments | $210 | Student loan minimum |
| **Needs subtotal** | **$2,630** | 58% |
| Dining out and coffee | $220 | Down from $320 — two takeout meals a week |
| Streaming and apps | $40 | Cancelled two unused subscriptions |
| Gym | $45 | |
| Clothes and personal care | $100 | |
| Fun money | $100 | Guilt-free, no tracking |
| **Wants subtotal** | **$505** | 11% |
| Emergency fund | $300 | Automatic transfer on payday |
| Roth IRA | $250 | Automatic transfer on payday |
| Extra student loan payment | $400 | Up from $200 |
| Travel fund | $100 | Sinking fund (see Module 4) |
| **Savings and debt subtotal** | **$1,050** | 23% |
| Buffer / miscellaneous | $315 | 7% — absorbs surprises without breaking the plan |
| **Total** | **$4,500** | 100% |

Notice the buffer line. A budget without a buffer is a budget that breaks the first time a tire goes flat. The buffer is not failure; it is engineering.

### Automate the important parts

Willpower should not be involved in your savings. Set up automatic transfers for the day your paycheck lands: emergency fund, retirement contribution, extra debt payment. What you never see, you never miss. Then set a single weekly 15-minute "money date" with yourself — same day, same time — to check balances, categorize spending, and adjust the coming week. Fifteen minutes a week prevents the three-hour panic at the end of the month.

### When income is irregular

If you freelance, work gigs, or earn commissions, budget from your lowest recent month, not your average. In good months, the surplus goes to a "holding" account that smooths the lean months. Pay yourself a fixed "salary" from that holding account each month, and your budget becomes as stable as a salaried worker's.

### Adjusting your budget when life changes

A budget is a living document, not a contract carved in stone. A raise, a new baby, a move, a job loss, or a paid-off loan all change the numbers, and the budget should change with them. The rule for windfalls is simple: decide the split before the money arrives — a common split is 50 percent to a goal (debt or savings), 30 percent to something you enjoy, and 20 percent to the buffer. The rule for income drops is equally simple: protect housing, food, transport to work, insurance, and minimum payments first; pause investing and extra debt payments; and revisit the budget weekly until income stabilizes. A budget that bends is a budget that survives.

### Module 3 action steps

1. Choose your budgeting method and build next month's budget from your real Module 2 numbers.
2. Add a buffer line of at least 5 percent of income.
3. Set up at least one automatic transfer for payday.
4. Schedule a weekly 15-minute money date and put it on your calendar.

---

## Module 4: Saving on Purpose — Emergency Funds, Sinking Funds, and Goals

### What this module covers

Saving fails when it is vague. "I should save more" is not a plan. A plan names an amount, a date, and a reason — and separates savings into distinct buckets so that one goal cannot quietly eat another. This module covers the three kinds of saving every adult needs: the emergency fund, sinking funds for predictable costs, and goal savings for the things you want.

### The emergency fund: your financial airbag

An emergency fund is money set aside for true emergencies — a job loss, a major car repair, an unexpected medical bill — and nothing else. It is the single most important savings goal, because without it, every emergency becomes debt, and debt at high interest is how small problems become long crises.

How much? The standard guidance is three to six months of essential expenses. If your essential monthly expenses are $2,600, that means $7,800 to $15,600. That number sounds large, and it is — which is why you build it in stages. Stage one is a $1,000 starter cushion, which covers most minor emergencies (a tire, a copay, a broken appliance). Stage two is one month of essential expenses. Stage three is three months. Stage four is six months. Each stage is a genuine achievement, and each one makes the next easier because emergencies stop becoming debt.

Where to keep it: a high-yield savings account, separate from your everyday checking account, where you can reach it within a day or two but not in a single impulsive tap. It should not be invested in the stock market — the point is stability and access, not growth. If your bank pays little interest, a high-yield savings account from a reputable bank or credit union is worth opening; the difference between 0.01 percent and 4 percent on $10,000 is about $400 a year, which is real money.

**Worked example — building an emergency fund.** Maya's essential expenses are $2,630 a month. Her three-month target is $7,890. She starts with the $2,400 already in her savings account, leaving $5,490 to build. At $300 a month — the amount in her budget — she reaches three months in about 18 months. That feels slow, so she adds two accelerators: she directs her $650 annual tax refund to the fund, and she adds $100 a month from the dining-out savings in her new budget. At $400 a month plus the refund, she reaches her target in about 12 months. Then the $400 a month gets redirected to her next goal. The fund is not a permanent drain on her budget; it is a project with a finish line.

### Sinking funds: making predictable costs boring

Some "emergencies" are not emergencies at all — they are predictable costs you forgot to plan for. Car insurance due every six months, holiday gifts every December, a car repair every year or two, a new phone every few years. A sinking fund is a small monthly amount saved for a known future cost, so that when the cost arrives it is an ordinary transaction, not a crisis.

Set up one sinking fund per predictable cost. Car insurance of $840 every six months is $140 a month. Holiday spending of $600 a year is $50 a month. A $1,200 annual car-maintenance estimate is $100 a month. These amounts are small individually; together they replace the annual panic with a calm transfer.

### Goal savings: what you actually want

Once the emergency fund is underway, save for specific goals with names and dates: a vacation in eight months, a house deposit in five years, a new laptop in six months. A named goal with a deadline is far more motivating than a generic savings account, and it protects you from raiding the emergency fund for a holiday. Use the savings-goal tracker in the workbook to record each goal's target amount, deadline, and required monthly contribution: target divided by months remaining.

**Worked example — goal math.** A $1,800 vacation in 9 months requires $200 a month. A $5,000 house-deposit starter fund in 24 months requires about $208 a month. If you cannot afford both at once, sequence them: fund the vacation first because its deadline is nearer, then roll that $200 a month into the deposit fund.

### The order of saving

If you have high-interest debt, the order matters. Keep a $1,000 starter emergency cushion first, then attack the high-interest debt aggressively (Module 6 explains why), then return to finish the full three-to-six-month emergency fund. This order prevents the most common trap: paying off a card, then having no cushion when the car breaks, then putting the repair back on the card.

### Module 4 action steps

1. Open or designate a separate high-yield savings account for your emergency fund.
2. Calculate your three-month essential-expenses target and your current progress.
3. List three predictable annual costs and create a sinking fund for each.
4. Name one savings goal with a target amount and a deadline, and set up the monthly transfer.

---

## Module 5: Credit — How Scores Work and How to Build Yours

### What this module covers

Credit is a tool, and like any tool it can build or damage. A good credit history can save you tens of thousands of dollars over a lifetime through lower interest rates on car loans and mortgages, and it affects rental applications, insurance pricing in some places, and sometimes employment checks. A damaged one does the opposite. This module explains, in plain English, what a credit score is, what moves it, and how to build and protect yours.

### What a credit score actually is

A credit score is a three-digit number, usually between 300 and 850, that summarizes your history of borrowing and repaying. Lenders use it to estimate the risk of lending to you. The most widely used scoring models are FICO and VantageScore; they weigh similar factors but not identically. You do not have one single score — you have several, and they change as your reported information changes. Checking your own score never hurts it.

### The five factors that matter most

For the FICO model, the factors are generally weighted as follows:

1. **Payment history (about 35 percent).** Whether you pay on time. A single payment more than 30 days late can lower a score significantly, and the mark can remain on your report for up to seven years. This is the single most important factor, and the simplest to control: pay at least the minimum on time, every time.
2. **Amounts owed / credit utilization (about 30 percent).** How much of your available credit you are using. If you have a $5,000 limit and a $4,500 balance, your utilization is 90 percent, which signals risk. Keeping utilization below 30 percent is a common guideline; below 10 percent is better. Note that utilization has no memory in most scoring models — pay a balance down and the score typically recovers quickly.
3. **Length of credit history (about 15 percent).** How long your accounts have been open, on average. This is why closing your oldest card can hurt: it shortens your average account age. If you no longer use an old card, keeping it open with an occasional small purchase is usually better than closing it.
4. **Credit mix (about 10 percent).** Having different types of credit — a credit card and an installment loan, for example — can help slightly, but it is not worth opening accounts you do not need just to improve your mix.
5. **New credit (about 10 percent).** Opening several new accounts in a short period can lower your score temporarily. Each application can create a "hard inquiry," which typically has a small, short-lived effect. Rate-shopping for a mortgage or auto loan within a short window is usually treated as a single inquiry by the scoring models.

### Your credit report: the source of the score

Your score is calculated from your credit reports, held by the major credit bureaus. In the United States, you are entitled to free weekly reports from each bureau through AnnualCreditReport.com, the only federally authorized source. Check all three reports at least once a year and look for errors: accounts you do not recognize, incorrect balances, late payments you actually made on time. If you find an error, dispute it with the bureau in writing — the workbook includes a dispute checklist. Errors are common enough that checking is worth the hour it takes.

### Building credit from scratch

If you have little or no credit history, start with one of these paths: a secured credit card (you deposit, say, $300, and that becomes your limit; use it for one small recurring bill and pay it in full each month); becoming an authorized user on a trusted family member's long-standing, well-managed card; or a credit-builder loan from a credit union, where your payments are held in savings and released to you when the loan is complete. The pattern is always the same: borrow a little, pay it back on time, repeat.

### Credit cards: the rules that keep them safe

- Pay the statement balance in full whenever possible. Paying only the minimum on a high-interest card is how balances grow for years.
- Never use a credit card to pay for something you cannot afford to pay off — that is a loan, not a purchase.
- Keep utilization low by paying mid-cycle if needed, not just on the due date.
- Set up autopay for at least the minimum so a forgotten date never becomes a late mark.
- Ignore the siren call of rewards unless you pay in full every month; the interest on a carried balance always outweighs the cash back.

**Worked example — the cost of minimum payments.** A $3,000 balance at 24 percent annual interest, paying only a $75 minimum each month, takes roughly 6 years to clear and costs about $2,700 in interest — nearly doubling the cost of the original purchases. Paying $150 a month instead clears it in about 2 years and costs about $800 in interest. The difference between those two plans is about $1,900, and the only change is the monthly payment amount. This is why Module 6 matters so much.

### Module 5 action steps

1. Get your free credit reports from AnnualCreditReport.com and check all three for errors.
2. Find your current credit utilization across all cards and bring it below 30 percent.
3. Set up autopay for at least the minimum on every account.
4. If you have no credit history, open one secured card or credit-builder product and use it for a single recurring bill.

---

## Module 6: Debt — The True Cost and a Plan to Eliminate It

### What this module covers

Debt is not a moral failure; it is a financial condition with a mathematical solution. This module teaches you to see the true cost of each debt, choose a payoff strategy that fits your personality, and stay with it until the balances are gone. If you have no debt, this module is still worth reading — it is the best inoculation against taking on bad debt later.

### Good debt, bad debt, and the gray area

Not all debt is equal. Debt that buys something that grows in value or earning power — a reasonable mortgage, a student loan for a degree that raises your income — can be a sound investment. Debt that funds consumption at high interest — credit cards, payday loans, buy-now-pay-later balances that roll into fees — is expensive and rarely justified. In between are car loans (a depreciating asset, so keep the term short and the payment modest) and personal loans (useful for consolidation if the rate is genuinely lower and the spending that created the debt is fixed).

The dividing line is the interest rate and the purpose. A useful rule: any debt above roughly 8 percent annual interest is expensive and should be a priority to eliminate. Below that, the urgency is lower, and investing may compete for the same dollars (Modules 10 and 11 explain the trade-off).

### The two payoff strategies

There are two widely used methods, and both work — the best one is the one you will stick with.

**The avalanche method.** List your debts by interest rate, highest first. Pay minimums on all of them, and put every spare dollar toward the highest-rate debt. When it is gone, roll that payment into the next highest. The avalanche saves the most money in interest, mathematically. It is the right choice if you are motivated by logic and efficiency.

**The snowball method.** List your debts by balance, smallest first. Pay minimums on all, and put every spare dollar toward the smallest balance. When it is gone, roll that payment into the next smallest. The snowball costs slightly more in interest but delivers quick wins — a zero balance in a few months — and that momentum keeps many people going when the avalanche feels endless. It is the right choice if you are motivated by visible progress.

Neither method works without one precondition: stop adding new debt. A payoff plan while still charging new purchases is like bailing a boat with a hole in it. Freeze the cards, remove them from online accounts, and live on your budget while the plan runs.

### Worked example — avalanche versus snowball

Maya has three debts and $600 a month available for debt payoff beyond minimums is not realistic — so let us use her real numbers: she has $600 a month total for extra payoff and minimums combined, and her minimums total $210. The honest version of this example uses the debts from Module 2 plus one store card:

| Debt | Balance | Interest rate | Minimum payment |
|---|---|---|---|
| Store card | $900 | 26% | $35 |
| Credit card | $1,200 | 22% | $40 |
| Student loan | $11,500 | 5.5% | $210 |
| **Total** | **$13,600** | | **$285** |

Maya can put $700 a month toward debt in total ($285 minimums + $415 extra). Under the **avalanche**, she attacks the store card first (26 percent), then the credit card (22 percent), then the student loan. The two cards are gone in about 6 months, and she has saved roughly $350 in interest compared with paying minimums only. Under the **snowball**, she attacks the store card first anyway — it is both the smallest balance and the highest rate, which happens often — then the credit card, then the loan. In Maya's case the two methods converge, which is a useful reminder: the debate matters less than starting. Once the cards are gone in month 6, the full $700 a month goes to the student loan, and at 5.5 percent it is cleared in roughly 17 more months. Total time to debt-free: about 23 months. Total interest paid along the way: roughly $1,100, versus roughly $2,900 if she had paid minimums only. The plan saves her about $1,800 and more than a decade of payments.

### Negotiating and consolidating

If you are struggling, call your creditors before you miss a payment — many will offer a hardship plan, a lower rate, or a temporary reduction, because they would rather be paid slowly than not at all. A balance-transfer card with a 0 percent introductory rate can help if you can pay the balance off within the introductory period and you do not run the old card back up; otherwise the deferred interest and transfer fees make it worse. A personal loan for consolidation only helps if the new rate is genuinely lower, the term is not stretched so long that total interest rises, and the spending behavior that created the debt has changed. Debt settlement companies that promise to make debt disappear for a fee deserve extreme skepticism — many charge large fees and damage your credit while they "negotiate."

### When debt is an emergency

If you cannot make minimum payments, or you are using one card to pay another, get help early rather than late. Nonprofit credit counselors — in the United States, look for agencies affiliated with the National Foundation for Credit Counseling (NFCC) — offer low-cost or free debt management plans and budgeting help. This is a practical step, not a failure. The earlier you act, the more options you have.

### Module 6 action steps

1. List every debt with its balance, interest rate, and minimum payment.
2. Choose avalanche or snowball and write down your order.
3. Calculate your total monthly debt payment and set it to autopay.
4. Remove saved cards from shopping apps and commit to no new charges while the plan runs.

---

## Module 7: Banking, Cash Flow, and Protecting Your Money

### What this module covers

Banking is unglamorous, and that is exactly why it is worth a module: the wrong accounts quietly cost you hundreds of dollars a year in fees and lost interest, while the right setup runs itself. This module covers choosing accounts, organizing cash flow, and protecting yourself from fraud and identity theft.

### Choosing your accounts

You need, at most, four accounts: a checking account for daily spending and bills; a high-yield savings account for the emergency fund; a second savings account (or sub-savings buckets, if your bank offers them) for sinking funds and goals; and, if you invest, a brokerage or retirement account. More accounts than that create confusion without benefit.

When choosing a bank or credit union, compare: monthly fees and how to avoid them; overdraft fees and whether overdraft protection can be switched off; ATM access; interest rates on savings; and whether the institution is insured — in the United States, the FDIC covers bank deposits up to $250,000 per depositor per bank, and the NCUA provides the same protection for credit unions. Credit unions often offer lower fees and better rates than large banks, and online banks often pay higher savings interest because they have no branches to maintain.

### Cash-flow design: the payday routine

Money should move on a schedule, not on impulse. A simple payday routine:

1. Payday arrives in checking.
2. Automatic transfers move savings, retirement, and extra debt payments out the same day.
3. Fixed bills are paid by autopay from checking.
4. What remains is your variable spending for the period — groceries, transport, fun money.

If you are paid biweekly, build your budget on two paychecks a month and treat the two months a year with a third paycheck as bonus months: direct the extra paycheck entirely to savings or debt. That single habit can add $2,000 to $4,000 a year to your goals without any change to your lifestyle.

### Fees are a leak — plug them

Review a full year of bank statements for fees: monthly maintenance, overdraft, ATM, late payment, and foreign transaction fees. A $12 monthly maintenance fee is $144 a year; a single $35 overdraft fee a month is $420 a year. Most maintenance fees are waivable with a direct deposit or minimum balance, and many banks will refund a first overdraft fee if you ask. Overdraft "protection" that automatically covers shortfalls at $35 a time is usually better switched off, so a declined card costs you embarrassment instead of money.

### Protecting your money: fraud and identity theft

Three habits protect most people most of the time:

- **Unique passwords and two-factor authentication** on every financial account. Use a password manager rather than reusing one password everywhere.
- **Freezing your credit** with the three major bureaus when you are not actively applying for credit. A freeze blocks new accounts from being opened in your name and can be temporarily lifted in minutes when you need it. It does not affect your score.
- **Reading statements monthly.** Fraud is usually small at first — a $9.99 charge you do not recognize — because thieves test whether you are watching. Report unfamiliar charges immediately; under most consumer protection rules, your liability for unauthorized charges is limited if you report promptly.

Be skeptical of urgency: a call, text, or email claiming your account is locked, a package is held, or a loved one is in trouble — and demanding immediate payment by gift card, wire, or cryptocurrency — is almost always a scam. Legitimate institutions do not demand payment that way. When in doubt, hang up and call the organization on a number you find yourself.

### Module 7 action steps

1. List every account you hold and every fee you paid in the last year; close or renegotiate the expensive ones.
2. Confirm your deposits are with an FDIC- or NCUA-insured institution.
3. Set up the payday routine: automatic transfers on the day income lands.
4. Place a credit freeze with the three major bureaus and enable two-factor authentication on all financial accounts.

---

## Module 8: Insurance — Protecting What You Build

### What this module covers

Insurance is the least exciting purchase you will ever make, and one of the most important. Its purpose is simple: to transfer a risk you cannot afford to bear onto an insurer that can. Without it, a single event — a car crash, a house fire, a serious illness — can erase years of careful saving. This module explains the coverage every adult should understand, how to choose it, and the mistakes that leave people exposed.

### Health insurance

In the United States, health insurance is usually obtained through an employer, a government marketplace, or a public program. When choosing a plan, look past the monthly premium and compare the deductible (what you pay before coverage begins), the out-of-pocket maximum (the most you will pay in a year), the copays, and whether your doctors and prescriptions are covered. A low-premium plan with a $7,000 deductible is not cheaper than a higher-premium plan if you expect to use care — do the math on your likely total cost, not just the monthly bill. If you are offered a high-deductible plan with a Health Savings Account (HSA), the HSA is worth understanding: contributions are tax-deductible, growth is tax-free, and withdrawals for medical expenses are tax-free — the only account with all three tax benefits. Keep your insurance card and policy documents somewhere you can find them in an emergency.

### Auto insurance

If you drive, you need liability coverage at least at the level your state requires — and usually more, because state minimums are often far below the cost of a serious accident. Beyond liability, consider collision and comprehensive coverage if your car is worth enough that replacing it would be a hardship; as a car ages and its value falls, dropping collision coverage can make sense. A higher deductible (say, $1,000 instead of $250) lowers your premium, and it is a reasonable choice once your emergency fund can cover the deductible. Shop for quotes every year or two — loyalty to one insurer rarely pays, and rates vary widely for identical coverage.

### Renter's and homeowner's insurance

If you rent, renter's insurance is one of the best bargains in personal finance: typically $15 to $30 a month for coverage of your belongings against theft, fire, and water damage, plus liability protection if someone is injured in your home. Many landlords require it. If you own a home, homeowner's insurance is usually required by your mortgage lender; check that your coverage would rebuild the house at today's construction costs, not the price you paid years ago, and understand whether flood or earthquake coverage — usually separate policies — applies to your area.

### Life insurance

Life insurance exists to replace income for people who depend on you. If no one depends on your income, you probably do not need it yet. If a partner, child, or parent does, term life insurance — coverage for a set period, such as 20 years — is usually the right choice: it is far cheaper than whole life insurance, and the coverage amount is what matters. A common starting estimate is 10 to 12 times your annual income, adjusted for debts, children's education, and a spouse's earning capacity. Buy it when you are young and healthy, when it is cheapest, and revisit the amount after major life changes.

### Disability insurance

Your ability to earn is your largest financial asset, and disability insurance protects it. Many employers offer short-term and long-term disability coverage — check what yours provides and what it would actually pay (often 60 percent of salary, with caps). If your employer offers little or nothing and you depend on your income, an individual long-term disability policy is worth a quote. This is the coverage most people skip and most often regret skipping.

### The annual insurance review

Once a year, review all your policies together: coverage amounts, deductibles, premiums, and beneficiaries. Update beneficiaries after marriage, divorce, or the birth of a child — a beneficiary designation on a policy overrides a will. Photograph or video your belongings for a home inventory, and store it outside your home. And remember the golden rule: insure against losses you cannot afford, and self-insure the small stuff with your emergency fund.

### Module 8 action steps

1. List every insurance policy you hold, with its coverage, deductible, premium, and renewal date.
2. Identify your gaps: renter's insurance, disability coverage, and life insurance if anyone depends on your income.
3. Get two competing quotes for your largest premium (usually auto or home).
4. Check and update the beneficiaries on every policy.

---

## Module 9: Taxes — The Basics Every Earner Should Understand

### What this module covers

Taxes are the largest single expense most people will ever pay, and the least understood. You do not need to become a tax preparer, but you do need to understand how your income is taxed, which accounts and choices reduce your bill legally, and how to avoid the common mistakes that cost ordinary earners hundreds or thousands of dollars. Tax rules change frequently and vary by country and state — the principles here are general, and the specific rates, brackets, and limits should always be verified against current official sources.

### How income tax works: brackets, not cliffs

Most income tax systems are progressive: your income is taxed in slices, or brackets, with higher rates applying only to the income in each higher slice. A common misunderstanding is that moving into a higher bracket means all of your income is taxed at the higher rate. It does not. Only the income above each threshold is taxed at that bracket's rate. Your marginal rate is the rate on your next dollar of income; your effective rate is the total tax divided by total income, and it is always lower than your marginal rate.

**Worked example — simplified brackets.** Suppose the tax system taxes the first $10,000 of income at 10 percent, the next $30,000 at 12 percent, and income above $40,000 at 22 percent. A person earning $50,000 pays: 10 percent of $10,000 = $1,000; 12 percent of $30,000 = $3,600; 22 percent of the remaining $10,000 = $2,200. Total tax: $6,800. Their marginal rate is 22 percent, but their effective rate is $6,800 ÷ $50,000 = 13.6 percent. A raise that pushes $2,000 of income into the 22 percent bracket costs $440 of tax on that $2,000 — the raise is still worth taking.

### Deductions and credits: two different things

A deduction reduces the income that is taxed. A $1,000 deduction saves you $1,000 multiplied by your marginal rate — at 22 percent, that is $220. A credit reduces the tax itself, dollar for dollar: a $1,000 credit saves you $1,000. Credits are therefore more valuable than deductions of the same size. The standard deduction — a fixed amount everyone can claim without itemizing — is the right choice for most people; itemizing only helps if your deductible expenses exceed it. Common deductions and credits vary by country and change often, so check the current list rather than relying on memory.

### Paycheck withholding: getting it right

If you are an employee, tax is withheld from each paycheck based on the information you provided on your withholding form. Too little withheld means a bill (and possibly a penalty) at tax time; too much means you gave the government an interest-free loan and wait months for a refund. A large refund is not a windfall — it is your own money returned late. Review your withholding after a raise, a marriage, a new child, or a second job, and use your tax authority's official withholding calculator to check it. If you are self-employed, you generally need to pay estimated tax quarterly — set aside 25 to 30 percent of each payment you receive in a separate account so the quarterly bill never catches you short.

### Tax-advantaged accounts: the legal way to pay less

Retirement accounts (covered in detail in Module 11) are the most powerful tax tool available to ordinary earners: traditional contributions reduce your taxable income now, Roth contributions are taxed now but grow and withdraw tax-free later, and employer matches are effectively free money. Health Savings Accounts, where available, offer the rare triple tax benefit described in Module 8. The common thread: the government rewards long-term saving with tax advantages, and using them is not a loophole — it is the system working as designed.

### Filing and records

Keep tax returns and supporting documents for at least three years (longer in some jurisdictions), and keep records of major asset purchases indefinitely. File on time even if you cannot pay in full — the penalty for not filing is usually worse than the penalty for paying late, and most tax authorities offer payment plans. If your situation is simple, reputable tax software is usually sufficient; if you have self-employment income, rental property, or a major life change, a few hundred dollars for a professional can save more than it costs.

### Common mistakes to avoid

- Treating a refund as free money instead of correcting your withholding.
- Forgetting to report side income — tax authorities receive copies of the same payment records you do.
- Missing employer retirement matches while chasing investment returns elsewhere.
- Ignoring estimated quarterly payments when self-employed, then facing a lump-sum bill plus penalties.
- Making financial decisions purely for tax reasons. A deduction that saves you 22 cents per dollar still costs you 78 cents. Never spend a dollar to save a quarter in tax.

### Module 9 action steps

1. Calculate your effective tax rate from last year's return (total tax divided by total income).
2. Check your current paycheck withholding against the official calculator.
3. If self-employed, open a separate tax savings account and set aside 25 to 30 percent of each payment.
4. List every tax-advantaged account available to you (retirement, HSA) and confirm you are using the ones that fit.

---

## Module 10: Investing Foundations — Compound Growth, Risk, and Diversification

### What this module covers

Investing is how money you have already earned goes to work and earns more. It is also the topic most surrounded by hype, jargon, and fear. This module strips it back to the fundamentals: what compound growth really is, what risk really means, why diversification matters, and how an ordinary person builds a sensible long-term portfolio without picking stocks or timing the market. This is education, not a recommendation to buy any specific investment.

### Compound growth: the engine

Compound growth means your returns earn returns. Money invested grows, and the growth itself grows. The formula is simple — future value equals the amount invested multiplied by (1 + the annual return) raised to the number of years — but the results surprise people, because growth accelerates with time. That is why starting early matters more than starting big.

**Worked examples — with stated assumptions.** Assume a steady 7 percent average annual return, before inflation, fees, and taxes, with no withdrawals. These are illustrative assumptions, not predictions: actual returns vary widely year to year and can be negative.

- $200 a month invested for 30 years at 7 percent grows to roughly $243,000, of which about $72,000 is your contributions and about $171,000 is growth.
- $200 a month for 20 years at the same assumed return grows to roughly $98,000 — less than half, despite two-thirds of the time, because the last decade does most of the compounding.
- A single $10,000 investment left untouched for 30 years at 7 percent grows to roughly $76,000; for 20 years, roughly $39,000. Ten extra years nearly doubles the outcome.

The lesson is not the specific numbers — they change with the assumed return — it is the shape of the curve: time is the most powerful ingredient, and it cannot be bought back later. A 25-year-old investing $200 a month will very likely end up ahead of a 35-year-old investing $400 a month, because the earlier start has ten extra years of compounding. Start small if you must. Start now.

### Risk: what it really means

Risk in investing does not mean "you might lose money." It means the outcome is uncertain — returns vary from year to year, and in some years they are negative. The stock market has historically fallen 10 percent or more in many years and risen 20 percent or more in others; the long-run average smooths out those swings, but only for investors who stay invested through them. The investors who lose the most are usually not the ones who picked the wrong investment — they are the ones who sold during a downturn and locked in the loss, then waited too long to return.

Two rules follow. First, money you will need within five years does not belong in the stock market; keep it in savings, because a downturn in year three of a five-year plan is a real problem, while a downturn in year three of a thirty-year plan is a footnote. Second, your tolerance for risk should be set by your time horizon and your temperament, not by what the market did last month.

### Diversification: the only free lunch

Diversification means spreading your money across many different investments so that no single failure can sink you. A single company's stock can fall to zero; a fund holding hundreds of companies across many industries and countries cannot, short of a catastrophe that would make the distinction irrelevant. The classic vehicle for ordinary investors is the low-cost index fund: a fund that tracks a broad market index, such as the total US stock market or a global index, holding hundreds or thousands of companies, charging a very low annual fee.

Fees deserve more attention than most beginners give them. An annual fee (expense ratio) of 0.03 percent costs $3 a year per $10,000 invested; a fee of 1 percent costs $100 a year per $10,000 — and the gap compounds. Over 30 years, the difference between a 0.03 percent and a 1 percent fee on a growing portfolio can amount to tens of thousands of dollars. Low fees are one of the few things in investing you can control completely.

### What to invest in: a simple framework

A sensible long-term portfolio for a beginner can be built from three ingredients:

1. **A broad stock index fund** — the growth engine, for money you will not need for many years.
2. **A broad bond index fund** — steadier, lower-returning, and useful for damping the portfolio's swings, especially as you approach the goal the money is for.
3. **Cash or a money-market fund** — for money needed soon.

The proportions depend on your time horizon and temperament. A common starting point for a young investor with a 30-year horizon is a high share of stocks; someone ten years from retirement holds more bonds. Target-date funds automate this: they start aggressive and gradually shift toward bonds as the target year approaches. They are a reasonable one-fund choice for people who want to set it and forget it.

What this framework deliberately leaves out: individual stock picking, day trading, options, leveraged products, and cryptocurrencies as a core holding. None of these is inherently evil, but none of them is necessary for building wealth, and each of them adds risk and complexity that a beginner does not need. If you want to explore them later, do so with money you can afford to lose, after your foundation is built.

### Inflation: the quiet tax on idle money

Inflation is the gradual rise in prices over time, and it is the reason money sitting in a checking account loses purchasing power. If inflation averages 3 percent a year, $10,000 today buys what roughly $7,400 buys in ten years. That is why the emergency fund belongs in a high-yield savings account rather than a drawer, and why long-term money belongs in investments rather than cash: over long periods, diversified investments have historically grown faster than inflation, while cash has not. Inflation does not mean you should invest money you need soon — it means you should be deliberate about which bucket each dollar belongs in. Short-term money prioritizes safety; long-term money must outgrow inflation, or it quietly shrinks.

### Behavior beats brilliance

The most important investing skill is not analysis — it is behavior. Automate a monthly contribution. Increase it when your income rises. Rebalance once a year (selling a little of what grew and buying a little of what lagged, to restore your target proportions). Do not check your balance daily. Do not sell in a panic. Do not chase whatever performed best last year. The investor who contributes steadily to a diversified, low-cost portfolio for thirty years will beat the clever investor who trades constantly, because fees, taxes, and emotional mistakes compound just as surely as returns do — in the wrong direction.

### Module 10 action steps

1. Decide your investing time horizon: money needed within five years stays in savings.
2. Write down your target mix of stocks and bonds and why you chose it.
3. Compare the expense ratios of any funds you hold or are considering; prefer low-cost broad index funds.
4. Set up an automatic monthly investment, even if it is small, and a date to increase it.

---

## Module 11: Retirement Accounts — 401(k)s, IRAs, and the Power of Starting Early

### What this module covers

Retirement accounts are where tax advantages and compound growth meet. They are also confusing, because the names, limits, and rules differ by country and change over time. This module explains the main account types in the United States — the system most readers of this course will use — the order in which to fund them, and the math that makes starting early so powerful. If you live elsewhere, the names will differ, but the principles — tax advantages for long-term saving, employer contributions where available, and the power of starting early — are universal. Verify current contribution limits with the official source for your country.

### The 401(k) and the employer match

A 401(k) is a retirement account offered by an employer. Contributions come out of your paycheck before tax (traditional) or after tax (Roth), and the money grows tax-deferred or tax-free depending on the type. The most important feature is the employer match: many employers match a portion of your contributions — a common formula is 50 percent of the first 6 percent of salary you contribute, or 100 percent of the first 3 percent plus 50 percent of the next 2 percent. A match is an immediate, guaranteed return on your money. Not contributing enough to get the full match is turning down part of your pay. If you contribute 6 percent of a $60,000 salary and your employer matches 50 percent of it, that is $1,800 a year from your employer — $54,000 over 30 years before any growth, and far more with it.

### IRAs: your own retirement account

An Individual Retirement Account (IRA) is one you open yourself, independent of any employer. The two main types:

- **Traditional IRA.** Contributions may be tax-deductible, growth is tax-deferred, and withdrawals in retirement are taxed as income.
- **Roth IRA.** Contributions are made with after-tax money, growth is tax-free, and qualified withdrawals in retirement are tax-free. Roth IRAs also have income limits on who can contribute directly, and annual contribution limits that change over time — check the current figures before contributing.

For most young earners in a relatively low tax bracket, a Roth IRA is attractive: you pay a low tax rate now in exchange for tax-free growth for decades. For higher earners, the immediate deduction of a traditional account may be worth more. There is no universally right answer; the right answer depends on your current tax rate versus your expected rate in retirement.

### The funding order

A widely used order of operations for retirement saving:

1. **Contribute enough to your 401(k) to get the full employer match.** Never leave the match on the table.
2. **Build your emergency fund** to at least one month of expenses (Module 4) — retirement accounts are hard to access early without penalties, so they are not an emergency fund.
3. **Pay off high-interest debt** (Module 6) — a guaranteed 24 percent return from eliminating a credit card balance beats any investment.
4. **Max out an IRA** (Roth or traditional, whichever fits), up to the annual limit.
5. **Return to the 401(k) and increase contributions** toward the annual limit.
6. **Taxable investing** for goals beyond retirement, once the tax-advantaged accounts are full.

This order is a guideline, not a law. Your situation may shuffle steps two and three. The principle is what matters: capture free money first, secure your safety net, eliminate expensive debt, then fill the tax-advantaged accounts before taxable ones.

### How much do you need?

A common rule of thumb is to save 15 percent of your gross income for retirement, including any employer match, starting in your twenties. If you start at 35, the figure rises; if you start at 45, it rises sharply. Another rule of thumb: aim to have roughly one year's salary saved by age 30, three times by 40, six times by 50, and eight to ten times by 60. These are rough guides, not guarantees, and your actual needs depend on your spending, your pension or Social Security expectations, and your retirement plans.

**Worked example — the cost of waiting.** Assume a 7 percent average annual return, before inflation, fees, and taxes, and a monthly contribution of $300. Starting at age 25 and contributing until 65 (40 years), the account grows to roughly $787,000. Starting at age 35 (30 years), the same $300 a month grows to roughly $365,000. Starting at 45 (20 years), roughly $157,000. The 25-year-old contributes $144,000 in total; the 35-year-old contributes $108,000; the 45-year-old contributes $72,000. The earliest starter contributes the most in total dollars, but ends up with more than twice the final balance of the 35-year-old — because time, not money, did the heavy lifting. Again, these figures depend on the assumed return and are illustrative, not predictions.

### Avoiding the traps

- **Cashing out when you change jobs.** Rolling an old 401(k) into an IRA or your new employer's plan preserves the tax advantages; cashing it out triggers taxes and usually a 10 percent early-withdrawal penalty, and it destroys decades of compounding.
- **Borrowing from your 401(k).** It feels like borrowing from yourself, but the money stops growing, repayments come from after-tax pay, and if you leave the job the loan often becomes due immediately.
- **Forgetting old accounts.** Track down every 401(k) from every former employer and consolidate them; a forgotten account is an account that is not being managed.

### Module 11 action steps

1. Find out your employer's 401(k) match formula and confirm you are contributing enough to get all of it.
2. Open an IRA if you do not have one, and choose Roth or traditional based on your tax situation.
3. Calculate your current retirement savings rate, including the match, and compare it with the 15 percent guideline.
4. Locate any old employer retirement accounts and plan to roll them over.

---

## Module 12: Your 90-Day Money Plan and Your Financial Life for the Next Decade

### What this module covers

Knowledge without action is entertainment. This final module turns everything in the course into a concrete 90-day plan, then zooms out to the decade ahead, so you know what to do on Monday morning and what "done" looks like over the long term.

### Your 90-day plan

**Days 1–30: Measure and stabilize.**

- Complete Modules 1 and 2: write your money beliefs, track spending for a week, calculate your income, expenses, and net worth.
- Open a high-yield savings account and set up a $1,000 starter emergency cushion (or your first $500 if $1,000 is out of reach this month).
- Get your free credit reports and dispute any errors.
- Set up autopay for at least the minimum on every debt and bill.

**Days 31–60: Build the system.**

- Build your budget from real numbers (Module 3) and set up payday automatic transfers.
- Choose your debt payoff method and make your first extra payment (Module 6).
- Create sinking funds for your three most predictable annual costs (Module 4).
- Confirm your employer retirement match and enroll or increase contributions to capture it fully (Module 11).
- Review your insurance coverage and get quotes for any gaps (Module 8).

**Days 61–90: Automate and look ahead.**

- Open an IRA or increase your retirement contribution, even by a small amount.
- Set up an automatic monthly investment (Module 10) — even $50 a month counts.
- Check your withholding and, if self-employed, set up quarterly estimated payments (Module 9).
- Schedule a monthly 30-minute money review on your calendar, recurring, for the next year.
- Celebrate the first 90 days properly: review your net worth again and compare it with day one. It will have moved.

### The decade view: what "done" looks like

- **Year 1:** A working budget, a starter emergency fund, no new high-interest debt, a credit score moving upward, retirement contributions capturing the full match.
- **Year 2–3:** Full three-to-six-month emergency fund, high-interest debt eliminated, an IRA open and funded, sinking funds covering every predictable cost.
- **Year 4–5:** Net worth positive and growing steadily, retirement savings rate at or near 15 percent, insurance coverage reviewed annually, investing automated and rebalanced yearly.
- **Year 6–10:** Compound growth becoming visible in your accounts, major goals (home deposit, education, business) funded from named savings rather than debt, and the habit of the monthly money review so ingrained that it takes fifteen minutes.

### Staying on track when life happens

Life will interrupt your plan: a job loss, a move, a child, an illness, a market crash. The plan is designed for that. When income drops, the first things to protect are the emergency fund and the minimum payments; investing can pause and resume. When a windfall arrives — a refund, a bonus, a gift — give it a job before it disappears: half to a goal, half to something you enjoy. And when you make a mistake, which you will, treat it as data, not as failure. One overspent month does not erase eleven good ones. Return to the budget, adjust, and continue.

### A final word

You now have the complete system: mindset, measurement, budgeting, saving, credit, debt, banking, insurance, taxes, investing, and retirement — in order, with numbers, and with a plan for the next 90 days. The system works if you work it, slowly and steadily, month after month. The richest version of your future self is not the one who found a secret trick. It is the one who built a foundation and stood on it for a decade. Start on Monday. Start with one transfer, one page of the workbook, one automatic payment. Then do it again next week.

---

## Bonus Chapter: Talking About Money — With Partners, Family, and Yourself

### What this chapter covers

Money is the most common source of conflict in relationships and one of the least discussed topics in families. This bonus chapter covers the conversations that make the rest of the system work: talking with a partner, setting boundaries with family, and being honest with yourself when the plan slips.

### With a partner: one team, one picture

Financial conflict in a relationship is rarely about the numbers — it is about different unspoken assumptions. One partner may see saving as safety; the other may see spending as freedom. The fix is a regular, low-stakes conversation, not a crisis meeting after an overdraft.

Start with a monthly money date: thirty minutes, same day each month, no blame allowed. Review the budget together, celebrate what worked, and agree on one change for next month. Many couples use a "yours, mine, ours" structure: a joint account for shared bills and goals, plus a personal allowance for each partner that requires no justification. The allowance is the key — it removes the feeling of being monitored and the resentment that comes with it.

Before merging finances, discuss four things explicitly: existing debts and credit scores, attitudes toward saving and spending, financial obligations to parents or children, and what "enough" looks like. Couples who discuss money before a crisis are the ones who survive one.

### With family: boundaries without guilt

Adult children are often caught between their own goals and family expectations — lending money to relatives, funding celebrations, or supporting parents. Generosity is a value, not a budget line to be raided. If you help family financially, decide in advance how much you can give each year, put it in the budget as its own line, and say no — kindly and firmly — when the request exceeds it. A useful phrase: "I have set aside this amount for family help this year, and I have already committed it." You cannot rescue others from a sinking boat, and a boundary stated early is kinder than resentment built over years.

### With yourself: the monthly review

The most important money conversation is the one you have with yourself. Once a month, sit with your numbers for thirty minutes and ask three questions: What went well? What surprised me? What is one thing I will change next month? Write the answers down. Over a year, those twelve notes become a record of your progress and a reminder that setbacks are normal. People who review monthly are far more likely to stay on plan than people who check only when something goes wrong — because by then, the problem has been growing for months.

---

## Appendix A: Glossary of Key Terms

- **APR (Annual Percentage Rate):** The yearly cost of borrowing, including interest and certain fees, expressed as a percentage.
- **Asset:** Anything you own that has value — cash, investments, property.
- **Compound growth:** Growth on both the original amount and the growth already earned.
- **Credit utilization:** The percentage of your available credit that you are currently using.
- **Deductible:** The amount you pay out of pocket before insurance coverage begins.
- **Diversification:** Spreading investments across many different assets to reduce risk.
- **Emergency fund:** Cash savings reserved for unexpected, essential expenses.
- **Expense ratio:** The annual fee charged by a fund, expressed as a percentage of assets.
- **Index fund:** A fund that tracks a broad market index, holding many securities at low cost.
- **Interest:** The cost of borrowing money, or the return earned on savings and investments.
- **IRA (Individual Retirement Account):** A personal, tax-advantaged retirement account.
- **Liability:** Anything you owe — a debt or obligation.
- **Marginal tax rate:** The tax rate applied to your next dollar of income.
- **Net worth:** Total assets minus total liabilities.
- **Premium:** The amount you pay for an insurance policy.
- **Roth IRA:** An IRA funded with after-tax money, with tax-free growth and qualified withdrawals.
- **Sinking fund:** Money saved in small regular amounts for a known future expense.
- **401(k):** An employer-sponsored, tax-advantaged retirement account.

## Appendix B: Your Numbers at a Glance

Fill this in as you complete the course, and update it every quarter. It is the one page that tells you whether your financial life is improving.

- Monthly take-home income: $________
- Monthly essential expenses: $________
- Monthly savings and debt payoff: $________
- Emergency fund target (3 months): $________
- Emergency fund current balance: $________
- Total debt: $________
- Total assets: $________
- Net worth: $________
- Credit score (and date checked): ________
- Retirement savings rate (including match): ________%

---

*End of course. Education only — not individualized financial advice. See the disclaimer at the beginning of this course.*
