# FIN-08 — Money Foundations: The Personal Financial Literacy Masterclass

**Price:** $297 (one-time) · **Category:** Finance & Wealth Building

## Files in This Folder

| File | Description |
|---|---|
| `content.md` | Full course text — 12 modules, bonus chapter, glossary, appendices (~12,000 words). |
| `workbook.md` | 100-page companion workbook — budgeting, savings, credit, debt, insurance, net-worth, tax, investing, goal-setting, and 90-day action plan worksheets. |
| `templates/monthly-budget.csv` | Monthly budget spreadsheet (sample budget pre-filled). |
| `templates/savings-goal-tracker.csv` | Savings-goal tracker spreadsheet. |
| `templates/net-worth-tracker.csv` | Net-worth tracker spreadsheet (12 monthly rows). |
| `templates/goal-setting-template.md` | Goal-setting template — one goal per copy. |
| `sales-page.md` | Full sales page — headline, problem, solution, module list, who it is/is not for, price, guarantee, 10 FAQs, disclaimers. |
| `listing.json` | Marketplace listing data (SKU FIN-08, $297.00, one-time). |
| `cover.md` | Cover design brief (black-and-gold luxury). |
| `cover.png` | Generated cover image (1280 × 1920 px, portrait). |
| `onboarding.md` | Customer onboarding guide — first steps, how to use the materials, 6-week schedule, support. |
