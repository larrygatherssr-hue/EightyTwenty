# Goal-Setting Template

Use this template for every financial goal. One goal per copy. A goal without a monthly number is a wish — this template forces the number.

## Goal

**What I want:** ________________________________________

**Why it matters to me:** ________________________________________

## The Numbers

| Field | Value |
|---|---|
| Target amount | $ |
| Amount already saved | $ |
| Amount still needed | $ |
| Deadline | |
| Months remaining | |
| Monthly amount needed (still needed ÷ months) | $ |
| Current monthly contribution | $ |
| Gap (monthly needed − current contribution) | $ |

## The Plan

**Where the money comes from each month:**

- Automatic transfer on payday: $________ to (account) ________________
- Extra income or windfalls: ________________________________________
- Spending I will reduce to fund this: ________________________________________

**What could get in the way, and my response:**

- Obstacle: ________________________________________ Response: ________________________________________
- Obstacle: ________________________________________ Response: ________________________________________

## Milestones

| Milestone | Target date | Amount | Reached? |
|---|---|---|---|
| 25% funded | | $ | [ ] |
| 50% funded | | $ | [ ] |
| 75% funded | | $ | [ ] |
| 100% funded | | $ | [ ] |

## Monthly Check-In

| Month | Contributed | Balance | On track? | Adjustment |
|---|---|---|---|---|
| | $ | $ | Yes / No | |
| | $ | $ | Yes / No | |
| | $ | $ | Yes / No | |
| | $ | $ | Yes / No | |
| | $ | $ | Yes / No | |
| | $ | $ | Yes / No | |

## Completion

**Date completed:** ______________

**What I did with the money:** ________________________________________

**Next goal:** ________________________________________
