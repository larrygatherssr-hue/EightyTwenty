# GRN-10 — Recycling Business Starter: Find Your Niche and Launch Profitably

**Price:** $147 (one-time) · **Category:** Green Living & Sustainability · **SKU:** GRN-10
**Format:** Complete written course manual (not a video course) + workbook + templates.

A business-opportunity guide to entering the recycling trade — niche selection, sourcing material, buyers, pricing, and compliance basics — for aspiring entrepreneurs who need to pick a profitable niche before investing.

## Files in This Product

| File | What it is |
|---|---|
| `content.md` | The full written course: introduction, table of contents, all 7 modules fully written in prose with actionable steps and worked examples with real numbers, plus glossary, pre-investment checklist, and sources appendix (13,040 words) |
| `workbook.md` | Companion workbook: exercises and worksheets for each module — niche scoring, weekly stress test, deal-breaker test, source list, buyer outreach tracker, permit checklist summary, break-even analysis, 90-day launch plan, risk assessment |
| `templates/niche-profitability-comparison.csv` | Niche profitability comparison tool with factor scoring, weekly money math, worked example rows, and deal-breaker test |
| `templates/startup-cost-estimator.csv` | Startup cost estimator with one-time and monthly costs, quote tracking, and a worked break-even example |
| `templates/buyer-broker-outreach-scripts.md` | 5 outreach scripts: local buyer, broker, source business, contractor, and post-sale follow-up |
| `templates/permits-compliance-checklist.md` | US-focused permits and compliance checklist (12 sections) |
| `sales-page.md` | Full sales page: headline, problem, solution, module list, who it is for / not for, price + 14-day guarantee, 12-question FAQ, disclaimers |
| `listing.json` | Marketplace listing data (valid JSON; price_cents 14700) |
| `cover.md` | Cover design brief (black-and-gold luxury palette) |
| `cover.png` | Generated cover image (1280 × 1920) |
| `onboarding.md` | Customer onboarding guide: what to do first, how to use the materials, suggested 4-week schedule, support |
| `README.md` | This file — index of the product's files |

## Notes

- All numbers in the course are illustrative teaching examples, clearly labeled as such — buyers must replace them with real local quotes.
- Permits/compliance content is US-focused general education; buyers must verify local rules.
- The sales page states plainly that this is a complete written course manual, not a video course.
- No fabricated testimonials, sales figures, reviews, or invented market data.
