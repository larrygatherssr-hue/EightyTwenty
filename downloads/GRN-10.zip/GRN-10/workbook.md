# Recycling Business Starter — Companion Workbook

Use this workbook alongside the course manual (content.md). Print it or copy it into your own notes. Every exercise asks you to write down real, local numbers — not guesses. A blank answer is honest; a guessed price is a trap.

**Disclaimer:** This workbook is general education, not legal, tax, financial, or investment advice. All example figures in the course are illustrative. Verify prices, permits, and rules locally before investing. Results depend on your market, location, capital, and effort.

---

## Module 1 — How the Business Works

### Exercise 1.1: Rank the four entry models

Rate each model 1–5 for fit with your capital, vehicle, space, and time. Write one sentence explaining each rating.

| Entry model | Fit (1–5) | Why |
|---|---|---|
| A — Collection and resale | | |
| B — Sort and bale | | |
| C — Dismantle and grade | | |
| D — Brokerage and aggregation | | |

My starting model: _______________
Why this one first: _______________

### Exercise 1.2: Estimate your five cost buckets for a typical week

| Cost bucket | My estimate per week | How I estimated it / who I will ask |
|---|---|---|
| 1. Acquisition cost | $ | |
| 2. Transport cost | $ | |
| 3. Processing cost | $ | |
| 4. Storage and handling | $ | |
| 5. Compliance cost | $ | |
| **Total weekly cost** | **$** | |

### Exercise 1.3: The loss-making load test

Take a load you are considering (material, pounds, buyer price). Work the five costs. Does it profit? Show the math:

- Material and pounds: _______________
- Revenue (pounds × price per pound): $ _______________
- Total cost (all five buckets): $ _______________
- Profit or loss: $ _______________
- What would have to change for this load to profit? _______________

---

## Module 2 — The Four Material Streams

### Exercise 2.1: Where the money is made — and lost

Write one paragraph per stream, in your own words.

**Plastics — where the money is made / lost:**


**E-waste — where the money is made / lost:**


**Scrap metal — where the money is made / lost:**


**Textiles — where the money is made / lost:**


### Exercise 2.2: Rank the four streams for you

| Stream | Fit (1–5) | Biggest strength for me | Biggest weakness for me |
|---|---|---|---|
| Plastics | | | |
| E-waste | | | |
| Scrap metal | | | |
| Textiles | | | |

My top-ranked stream: _______________
What I still need to verify before choosing it: _______________

### Exercise 2.3: Value-density check

For your top stream, list the grades you would handle and the illustrative price range for each (from the course), then the real local quote once you have it.

| Grade | Illustrative price/lb (course) | My local buyer quote | Buyer name and date |
|---|---|---|---|
| | | | |
| | | | |
| | | | |

---

## Module 3 — Picking Your Niche

### Exercise 3.1: Niche scoring worksheet

Score each stream 1–5 on each factor (1 = poor, 5 = excellent). Use the CSV template (templates/niche-profitability-comparison.csv) for the full scored comparison; record totals here.

| Factor | Plastics | E-waste | Scrap metal | Textiles |
|---|---|---|---|---|
| Supply availability near me | | | | |
| Buyer access and payment reliability | | | | |
| Revenue per pound (value density) | | | | |
| Transport cost per pound (low cost = high score) | | | | |
| Processing labor per pound (low labor = high score) | | | | |
| Permit and compliance burden (low burden = high score) | | | | |
| My knowledge and interest | | | | |
| **Total (out of 35)** | | | | |

### Exercise 3.2: Weekly stress test

For each stream, estimate a realistic week at the LOW end of the local price range.

| | Plastics | E-waste | Scrap metal | Textiles |
|---|---|---|---|---|
| Pounds (or jobs) per week | | | | |
| Revenue per pound (low price) | $ | $ | $ | $ |
| Weekly revenue | $ | $ | $ | $ |
| Weekly total cost | $ | $ | $ | $ |
| **Weekly profit at low price** | **$** | **$** | **$** | **$** |

### Exercise 3.3: Deal-breaker test

Answer yes or no for your top stream:

- [ ] I can legally handle and store this material in my location. (Yes / No — evidence: _______________)
- [ ] There is a buyer within a transport distance that leaves a margin. (Yes / No — buyer: _______________, distance: _____ miles)
- [ ] I can get a reliable supply. (Yes / No — source: _______________)

Any "No" means the niche is not ready. What would fix it? _______________

### Exercise 3.4: The decision

1. Which stream scored highest, and by how much? _______________
2. What is your stress-test weekly profit at the low price? $ _______________
3. What is the single weakest element of your chosen niche? _______________
4. What will you do about it in the first 30 days? _______________
5. My stop rule (the specific day-90 result that would make me change niches or stop): _______________

My chosen niche: _______________
Date chosen: _______________

---

## Module 4 — Sourcing Material

### Exercise 4.1: Ten potential sources near you

| # | Source (business / contractor / institution) | Material | Likely volume | Distance | Contacted? |
|---|---|---|---|---|---|
| 1 | | | | | |
| 2 | | | | | |
| 3 | | | | | |
| 4 | | | | | |
| 5 | | | | | |
| 6 | | | | | |
| 7 | | | | | |
| 8 | | | | | |
| 9 | | | | | |
| 10 | | | | | |

### Exercise 4.2: My collection service note (draft)

Write the essentials you will put in writing with each source: material collected, material NOT collected, pickup day/time/frequency, containers, price or fee, contamination responsibility, how the arrangement ends, and (for e-waste) data handling.

Material I will collect: _______________
Material I will NOT collect: _______________
Pickup schedule: _______________
Fee or price: _______________
Data handling (e-waste): _______________

### Exercise 4.3: My "we do not take" list

1. _______________
2. _______________
3. _______________
4. _______________
5. _______________

### Exercise 4.4: Route density check

Map your first route. List stops in order, miles between them, and pounds per stop.

| Stop | Miles from last stop | Pounds expected | Notes |
|---|---|---|---|
| | | | |
| | | | |
| | | | |
| | | | |
| **Route totals** | **_____ miles** | **_____ lbs** | **Cost per pound: $_____** |

---

## Module 5 — Buyers, Pricing, and Getting Paid

### Exercise 5.1: Buyer outreach tracker

Contact at least three buyers for your niche. Record real quotes.

| Buyer | Contact / phone / email | Material and grades bought | Price per pound (dated) | Payment terms | Distance | Requirements / paperwork | Date quoted |
|---|---|---|---|---|---|---|---|
| | | | | | | | |
| | | | | | | | |
| | | | | | | | |

My first buyer: _______________ — Why: _______________

### Exercise 5.2: The second-quote test

Take one real load. Compare your two best buyers, net of transport.

| | Buyer A | Buyer B |
|---|---|---|
| Price per pound | $ | $ |
| Pounds | | |
| Gross revenue | $ | $ |
| Extra transport cost vs. the other | $ | $ |
| Extra time cost | $ | $ |
| **Net revenue** | **$** | **$** |

Winner: _______________

### Exercise 5.3: Sale record (copy this page for every sale)

- Date: _______________
- Buyer: _______________
- Material and grade: _______________
- Gross weight / net weight: _______________ lbs / _______________ lbs
- Price per pound: $ _______________
- Deductions (contamination, moisture, fees): $ _______________
- Total paid: $ _______________
- Payment method and date received: _______________
- Scale ticket photographed? Yes / No

---

## Module 6 — Permits and Compliance

### Exercise 6.1: Permit checklist (summary)

Work through templates/permits-compliance-checklist.md in full. Summarize here:

| Requirement | Applies to me? | Agency to contact | Contacted (date) | Status |
|---|---|---|---|---|
| Business registration | | | | |
| EIN | | | | |
| Zoning / land use | | | | |
| Local business license | | | | |
| State recycling facility permit/registration | | | | |
| Stormwater permit / plan | | | | |
| Hazardous / universal waste rules | | | | |
| Fire code / storage limits | | | | |
| Scrap-dealer rules (ID, records, holding) | | | | |
| Insurance (liability, vehicle, property) | | | | |
| Sales tax / seller's permit | | | | |

My zoning call is scheduled for: _______________ (make this call before spending money on a lease or equipment).

### Exercise 6.2: Insurance quotes

| Insurer | Coverage quoted | Annual premium | Notes |
|---|---|---|---|
| | | $ | |
| | | $ | |

---

## Module 7 — Launch Plan, Break-Even, and Staying in Business

### Exercise 7.1: Break-even analysis

**Fixed monthly costs:**

| Fixed cost | $ per month |
|---|---|
| Rent / storage | $ |
| Insurance | $ |
| Phone | $ |
| Loan payments | $ |
| Subscriptions / software | $ |
| Other fixed: _______________ | $ |
| **Total fixed costs** | **$** |

**Variable cost per pound (or per job):**

| Variable cost | $ per pound (or per job) |
|---|---|
| Transport | $ |
| Processing (incl. your time, valued honestly) | $ |
| Acquisition | $ |
| Storage share | $ |
| Compliance share | $ |
| **Total variable cost** | **$** |

**Break-even math (run at low, middle, and high price):**

| | Low price | Middle price | High price |
|---|---|---|---|
| Selling price per pound | $ | $ | $ |
| Contribution margin per pound (price − variable cost) | $ | $ | $ |
| Break-even pounds per month (fixed ÷ margin) | | | |
| Can I realistically move that many pounds? | | | |

### Exercise 7.2: Startup cost estimator (summary)

Fill in templates/startup-cost-estimator.csv with real quotes. Record totals here:

- One-time startup costs: $ _______________
- Monthly fixed costs: $ _______________
- Cash reserve (2 months of fixed costs): $ _______________
- Total cash needed before first sale: $ _______________

### Exercise 7.3: 90-day launch plan

**Days 1–30 — Verify, do not buy.**
- [ ] Niche comparison complete with real quotes
- [ ] Zoning call made
- [ ] Permit checklist started
- [ ] Top 3 sources contacted
- [ ] Top 3 buyers contacted
- [ ] Startup estimator filled in with real quotes
- [ ] Break-even run at low, middle, and high price
- Day-30 decision: _______________

**Days 31–60 — Start small, prove the route.**
- [ ] First source agreement signed
- [ ] First buyer confirmed in writing
- [ ] Fixed pickup schedule running
- [ ] First loads sold; actuals compared with estimates
- Where were my estimates wrong, and by how much? _______________
- Day-60 decision: _______________

**Days 61–90 — Decide.**
- Total revenue (90 days): $ _______________
- Total costs (90 days): $ _______________
- Profit or loss: $ _______________
- Hours worked: _______________
- Effective hourly rate: $ _______________
- Decision: [ ] Continue [ ] Adjust — how: _______________ [ ] Stop
- Next 90-day targets: _______________

### Exercise 7.4: Risk assessment

| Risk | Likelihood (Low / Med / High) | Impact (Low / Med / High) | What I will do about it |
|---|---|---|---|
| Buyer price falls sharply | | | |
| Main source dries up | | | |
| Permit delayed or denied | | | |
| Transport cost rises (fuel) | | | |
| Load rejected for contamination | | | |
| Injury or equipment breakdown | | | |
| Slow payment from a buyer | | | |
| Data breach (e-waste) / battery fire | | | |
| Storage problem (wet, pests, theft) | | | |
| Other: _______________ | | | |

### Exercise 7.5: Pre-investment checklist (from Appendix B)

Confirm every box before spending on equipment, a lease, or a vehicle:

- [ ] Niche chosen with the comparison tool and real local quotes
- [ ] At least one confirmed source and one confirmed buyer, both in writing
- [ ] Zoning checked with the planning department
- [ ] Permit checklist started; I know which permits apply
- [ ] Break-even run at low, middle, and high price; the business survives at the low price
- [ ] Cash reserve covering at least two months of fixed costs
- [ ] Insurance quotes obtained
- [ ] Separate business bank account (or plan to open one before the first sale)
- [ ] "We do not take" list written; data-handling plan in place (e-waste)
- [ ] Stop rule written and day-90 decision date set: _______________

---

## Disclaimer

This workbook is general education, not legal, tax, financial, or investment advice. Verify all prices, permits, zoning, and rules locally before investing. Consult a local attorney and accountant before forming a business, signing a lease, or taking on debt. Results depend on your market, location, capital, and effort. Never invest money you cannot afford to lose.
