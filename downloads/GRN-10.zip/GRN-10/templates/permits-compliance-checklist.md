# Permits and Compliance Checklist (US-Focused)

**Purpose:** A working checklist to help you identify the permits, licenses, and rules that may apply to your recycling business. This is general education, not legal advice. Rules vary by state, county, and city, and they change. Verify every item with the agency that enforces it in your location.

**How to use it:** Work through the list before you spend money on a lease or equipment. Mark each item: Not applicable / To check / In progress / Done. Record the agency, the person you spoke to, the date, and what they told you. Keep this checklist with your business records.

---

## 1. Business Formation and Registration

- [ ] Business structure chosen (sole proprietorship / LLC / partnership / corporation) — decided after advice from a local attorney or accountant
- [ ] Business name registered with the state (and county/city, if required)
- [ ] EIN obtained from the IRS (if required for your structure or if you will have employees)
- [ ] Separate business bank account opened
- [ ] Business insurance quoted and in place (see Section 6)

**Agency to contact:** Your state's Secretary of State / business registration office; IRS (irs.gov) for an EIN.
**Notes:** _______________

## 2. Zoning and Land Use — DO THIS BEFORE SIGNING A LEASE

- [ ] Called the city/county planning department about my exact address and material
- [ ] Confirmed the zoning allows collecting, sorting, and storing my material at that location
- [ ] Asked whether a conditional use permit, special use permit, or site plan approval is required
- [ ] Asked about limits on outdoor storage, truck traffic, hours of operation, and signage
- [ ] Checked home-occupation rules (if operating from home) and any homeowners' association rules
- [ ] Received the answer in writing (email or letter) where possible

**Agency to contact:** City or county planning / zoning department.
**Question to ask:** "I want to collect, sort, and store [your material] at [address]. Is that allowed in this zone, and what permits do I need?"
**Notes:** _______________

## 3. Local Business License

- [ ] Checked whether my city and/or county requires a business license
- [ ] Applied for and received the license (if required)
- [ ] Noted the renewal date: _______________

**Agency to contact:** City clerk or county business licensing office.
**Notes:** _______________

## 4. State Environmental Permits and Registrations

- [ ] Contacted my state environmental agency about recycling facility registration or permits
- [ ] Determined whether my operation is below an exemption threshold — and confirmed the threshold in writing
- [ ] Applied for any required facility permit or registration
- [ ] Checked stormwater requirements for outdoor storage (permit or pollution prevention plan)
- [ ] Checked whether any air permit applies to my processing (shredding, melting, burning — check before doing any of these)
- [ ] Noted permit numbers and renewal dates: _______________

**Agency to contact:** Your state environmental / natural resources agency.
**Notes:** _______________

## 5. Hazardous and Universal Waste

- [ ] Identified every hazardous or universal-waste item I will handle (batteries, fluorescent lamps, CRTs, items containing lead or mercury, refrigerants)
- [ ] Checked my state's rules for handling, labeling, and storing each one
- [ ] Registered as a handler if required
- [ ] Identified a permitted downstream facility for each hazardous item — I will not mix hazardous waste into a general load
- [ ] Lithium batteries: separate storage, approved containers, away from other material
- [ ] Refrigerants: confirmed that only certified recovery will be used, and which yards accept appliances with refrigerants (and their fees)

**Agency to contact:** Your state environmental agency; your local household hazardous waste program.
**Notes:** _______________

## 6. Insurance

- [ ] General liability insurance — quoted and in place
- [ ] Commercial vehicle insurance — quoted and in place
- [ ] Property / storage insurance — quoted and in place (if I have a yard or unit)
- [ ] Pollution liability — considered, especially for e-waste
- [ ] Workers' compensation — in place if I have employees (required in most states)
- [ ] Renewal dates noted: _______________

**Notes:** _______________

## 7. Scrap-Dealer Rules (Especially for Scrap Metal)

- [ ] Checked my state and local scrap-dealer rules: seller identification, record-keeping, holding periods, and restricted materials
- [ ] Confirmed which materials require proof of ownership (for example, copper wire, catalytic converters, manhole covers, utility materials)
- [ ] Set up a record system for every purchase: date, seller name and ID, material, weight, price paid
- [ ] Confirmed how my buyers handle payment (cash, check, holding period) and what ID they require from me

**Agency to contact:** Your state attorney general's office or department of licensing; your local police non-emergency line can often point you to the right local rule.
**Notes:** _______________

## 8. E-Waste Rules

- [ ] Checked my state's e-waste law: registration, reporting, or certification requirements for collectors/recyclers
- [ ] Confirmed whether my state bans certain electronics from landfills
- [ ] Data-wiping/destruction process in place, with certificates of destruction issued to clients
- [ ] Understand the rules on exporting used electronics — I will not export e-waste without a compliant downstream partner
- [ ] Considered R2 or e-Stewards certification as a future growth goal (not a starting requirement)

**Agency to contact:** Your state environmental agency; your state e-waste program office.
**Notes:** _______________

## 9. Sales Tax and Resale

- [ ] Checked with my state tax agency whether I need a seller's permit or resale certificate
- [ ] Confirmed whether sales tax applies to items I resell (refurbished electronics, resold clothing, etc.)
- [ ] Set up a system to collect and remit sales tax if required

**Agency to contact:** Your state department of revenue / taxation.
**Notes:** _______________

## 10. Fire Code and Storage Safety

- [ ] Checked fire code limits on pile height, pile density, aisle clearance, and indoor storage
- [ ] Confirmed fire department access requirements for my site
- [ ] Prepared a basic fire prevention plan for indoor storage (if required)
- [ ] Lithium batteries stored separately in approved containers

**Agency to contact:** Your local fire department / fire marshal.
**Notes:** _______________

## 11. Record-Keeping System (Set Up Before the First Load)

- [ ] Load-in log: date, source, material, grade, weight, price paid, supplier name
- [ ] Load-out log: date, buyer, material, grade, weight, price received, payment method, scale ticket copy
- [ ] Permit, license, and insurance documents filed with renewal dates
- [ ] Data-wiping / destruction certificates filed (e-waste)
- [ ] Disposal receipts filed for unsellable material

**Notes:** _______________

## 12. Before the First Sale — Final Confirmation

- [ ] Zoning confirmed in writing
- [ ] All required permits applied for (or confirmed not required, in writing)
- [ ] Insurance in place
- [ ] At least one source agreement signed
- [ ] At least one buyer confirmed in writing (grades, prices, terms)
- [ ] "We do not take" list written and posted
- [ ] Break-even analysis done at the low price

**Date I completed this checklist:** _______________

---

## Disclaimer

This checklist is general education, not legal advice. It is not a complete inventory of the rules that may apply to your location and material. Verify every item with the agency that enforces it, and consult a local attorney before forming a business, signing a lease, or taking on debt.
