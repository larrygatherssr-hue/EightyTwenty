# Buyer and Broker Outreach Templates

Use these scripts when you contact buyers for the first time. Adapt the bracketed parts to your niche, material, and volume. The goal of a first contact is information — grades, prices, terms, and requirements — not a hard sell.

**General rule:** get prices and terms in writing (email or text) before you load the truck. A verbal price that changes when you arrive is a price you cannot plan on.

---

## Script 1 — First Call or Visit to a Local Buyer (Scrap Yard / Processor)

> Hello, my name is [Your Name] from [Your Business Name]. I am starting a small recycling collection business in [Town/Area], and I am looking for a buyer for [material — for example, baled LDPE film / sorted copper and aluminum / graded used clothing / tested business laptops].
>
> I expect to bring in about [volume] per [week/month], sorted and graded to [grade/specification]. Could you tell me:
>
> 1. Which grades of [material] do you buy?
> 2. What are your current prices for those grades?
> 3. How do you grade on arrival, and what deductions apply for contamination or moisture?
> 4. What are your delivery hours, and do I need to schedule a delivery?
> 5. How and when do you pay — cash, check, or bank transfer, and how long after delivery?
> 6. What paperwork do you need from a new supplier — identification, business license, source records?
>
> Would it be all right if I bring a small, clean sample load by first, so we can agree on the grade together? And could you send me your current price list by email so I have it in writing?
>
> Thank you — my email is [email] and my phone is [phone].

**After the call, send this follow-up email the same day:**

> Subject: [Material] supply — confirming grades, prices, and terms
>
> Hello [Name],
>
> Thank you for speaking with me today. To confirm what we discussed: you buy [grades] at [prices] as of [date], with delivery [hours/arrangement], payment by [method] within [timeframe], and you need [paperwork] from me.
>
> Please let me know if I have any of that wrong. I plan to bring my first load on [date]. Thank you for your time.
>
> [Your Name], [Business Name], [Phone], [Email]

---

## Script 2 — Approaching a Broker

> Hello, my name is [Your Name] from [Your Business Name] in [Town/Area]. I collect and [sort/bale/dismantle] [material], and I am looking for a broker who can place [volume] per [week/month] with mills or export buyers.
>
> Before we talk volume, I would like to understand how you work: which grades you handle, how pricing is set, what your payment terms are, and what you need from a supplier in terms of grading, packaging, and paperwork.
>
> I can send photos of a typical load and a sample of how I grade and pack it. Would you be open to a short call this week?

**Questions to ask a broker before you commit to one:**

- How is my price set — a fixed quote, a percentage of the mill price, or a market index? Which one, and can I see it?
- When do I get paid, and what happens if your end buyer pays late or rejects a load?
- Who pays for transport, and who is responsible if a load is damaged or lost in transit?
- What grading standard do you use, and can I see it in writing before I ship?
- Can you give me two references — small suppliers you already work with?

**Red flags:** a broker who will not put prices or terms in writing; a broker who asks you to deliver now and be paid "when they sell it on"; a broker who cannot name their end buyer or their grading standard. Walk away from all three.

---

## Script 3 — Approaching a Source Business (Collection Pitch)

Use this when you want a business to give you its recyclable material — a warehouse, office, retailer, or school.

> Hello, my name is [Your Name] from [Your Business Name]. I run a local recycling collection service, and I noticed your business generates [material — for example, cardboard and shrink wrap / retired computers / used fixtures].
>
> I can collect it on a fixed schedule — [day and time] every week — leave the area clean, and provide [a collection record / a data-destruction certificate for electronics]. There is [no charge / a small collection fee of $___ — explain why, for example, to cover items that cost money to handle safely].
>
> A few questions, if I may: what do you currently do with this material, how much do you generate in a typical week, and is there anything you need me to handle differently — for example, data wiping, or keeping certain items separate?
>
> If it helps, I can start with a trial month and a simple one-page written agreement so we both know exactly what is included.

**If the business asks why they should switch from their current hauler or collector:**

> I understand — reliability matters more than anything here. What I offer is a fixed schedule, a clean pickup, and a single point of contact: me. I am happy to start small, prove the service for a month, and let you judge on results. What matters most to you — timing, cleanliness, paperwork, or price?

---

## Script 4 — Approaching a Contractor (Plumber, Electrician, HVAC, Demolition)

> Hello, my name is [Your Name] from [Your Business Name]. I buy [copper, brass, aluminum, wire — as applicable] from local trades, and I am looking for contractors who want a reliable buyer who shows up when called, weighs honestly, and pays [on the spot / within ___ days].
>
> I pay based on grade — clean #1 copper, #2 copper, insulated wire, brass, aluminum — and I will show you how I grade each load so there are no surprises. If you have a job coming up that will generate scrap, I would be glad to quote it before you start, so you know what it is worth.
>
> What kind of material do your jobs usually generate, and would it help if I gave you my number to call when a load is ready?

---

## Script 5 — Follow-Up After a First Sale

> Hello [Name], thank you for taking my first load of [material] on [date] — [weight] at [grade and price], paid [method/date]. I would like to keep supplying you on a regular basis, about [volume] per [week/month].
>
> Two quick questions: was the grading and packaging what you expected, and is there anything I should do differently on the next load to get the best grade? I would also like to confirm whether the price we used will hold for next week, or whether I should check with you before each delivery.
>
> Thank you — [Your Name], [Phone], [Email]

---

## Notes

- Never rely on a single buyer. Keep at least three buyer relationships warm, even when you are selling to one of them.
- Keep a record of every quote: buyer, date, grade, price, terms. The buyer outreach tracker in the workbook is built for this.
- Do not extend credit to buyers. You should be paid on delivery or on short, agreed terms.
