# Customer Onboarding Guide — Recycling Business Starter

Welcome — and thank you for purchasing **Recycling Business Starter: Find Your Niche and Launch Profitably**. This guide tells you what to do first, how to use the materials, and how to get support.

**What you bought:** A complete written course manual (not a video course), a companion workbook, and four templates. There is no video to watch — you work through the written course at your own pace and fill in the tools with your own local numbers.

---

## What You Received

| File | What it is |
|---|---|
| `content.md` | The complete written course manual — 7 modules, over 13,000 words |
| `workbook.md` | Companion workbook with exercises and worksheets for every module |
| `templates/niche-profitability-comparison.csv` | Niche comparison tool with worked example rows |
| `templates/startup-cost-estimator.csv` | Startup cost estimator — fill in with real quotes |
| `templates/buyer-broker-outreach-scripts.md` | 5 outreach scripts for buyers, brokers, sources, and contractors |
| `templates/permits-compliance-checklist.md` | US-focused permits and compliance checklist (12 sections) |
| `sales-page.md` | The full sales page for this product (reference) |
| `cover.png` | The product cover image |
| `cover.md` | The cover design brief |
| `listing.json` | The marketplace listing data |
| `README.md` | Index of the product files |

---

## What To Do First (Day 1)

1. **Read the disclaimers** at the start of the course manual. They matter: every price in the course is an illustrative teaching example, not a market quote, and the permits content is US-focused general education.
2. **Read the Introduction and Module 1.** They give you the language of the business — the value chain, the five costs, the four entry models.
3. **Print the workbook** (or copy it into your notes app). You will use it in every module.
4. **Do not buy anything yet.** No equipment, no lease, no vehicle. The first 30 days are for verifying, not buying.

## Suggested Schedule

**Week 1 — Learn the landscape (Modules 1–2, about 3–4 hours of reading plus exercises).**
Read Modules 1 and 2 and complete the Module 1 and 2 workbook exercises. Rank the four entry models and the four material streams for your situation. Write down what you still need to verify.

**Week 2 — Compare niches (Module 3, about 2–3 hours plus calls).**
Fill in the niche profitability comparison tool. Score all four streams, run the weekly stress test at the low price, and apply the deal-breaker test. Start calling local buyers for real quotes — the numbers in the tool are only useful once they are real.

**Week 3 — Sources and buyers (Modules 4–5, about 3–4 hours plus calls and visits).**
List ten potential sources near you and contact your top three. Contact at least three buyers, record their quotes in the buyer outreach tracker, and use the outreach scripts for your first conversations.

**Week 4 — Permits and the money math (Modules 6–7, about 3–4 hours plus calls).**
Make the zoning call to your planning department before anything else. Work through the permits checklist, fill in the startup cost estimator with real quotes, and run your break-even analysis at the low, middle, and high price. Complete the pre-investment checklist in Appendix B.

**Days 31–90 — Launch in stages (Module 7).**
Follow the 90-day plan: start small, prove the route, sell your first loads, compare actuals against your estimates, and make your continue / adjust / stop decision at day 90 with real numbers in front of you.

## How To Use the Templates

- **Niche comparison (CSV):** Open in any spreadsheet app. Score each stream 1–5, then fill in the money section with real local quotes. Blank cells mean "not verified yet" — do not guess.
- **Startup cost estimator (CSV):** One row per cost. Get a real quote for every line that applies to you. The totals at the bottom tell you the cash you need before your first sale, including a two-month cash reserve.
- **Outreach scripts:** Adapt the bracketed parts to your niche and volume. Use them for calls, visits, and follow-up emails. Always confirm prices and terms in writing afterward.
- **Permits checklist:** Work through it section by section and record the agency, the person you spoke to, and the date for every item. Keep it with your business records.

## Tips for Getting the Most From the Course

- Value your own time honestly in every calculation. A business that only profits when your time is worth $0 is not a business.
- Run every calculation at the low price, not the middle or high price. If it only works at the high price, it does not work.
- Keep every record from day one — every load in, every load out, every quote, every permit. Good records protect you and tell you the truth about profit.
- If the math says a niche does not work for you, that is a successful outcome. You found out before spending, not after.

## Getting Support

- **Order or file problems:** Contact marketplace support with your order number and a description of the issue, and the support team will respond.
- **Refunds:** 14-day money-back guarantee. If you are not satisfied within 14 days of purchase, contact support with your order number for a full refund, no questions asked.
- **Business advice:** This course is general education, not legal, tax, financial, or investment advice. For questions about permits, zoning, business structure, or taxes in your area, contact your local planning department, state environmental agency, state tax agency, and a local attorney or accountant.

## Important Reminders

- Recycling is a capital- and permit-heavy business with thin margins and volatile commodity prices. Verify all prices, permits, and rules locally before investing.
- Permits and compliance content is US-focused general education; verify local rules for your exact location and material stream.
- Results depend on your market, location, capital, and effort. Never invest money you cannot afford to lose.
