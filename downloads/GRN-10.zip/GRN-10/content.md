# Recycling Business Starter: Find Your Niche and Launch Profitably

## The Complete Written Course Manual

**Author:** EightyTwenty Marketplace — Green Living & Sustainability
**Format:** Complete written course manual (this is a written course, not a video course). Work through it with the companion workbook and templates.
**Price:** $147 — one-time purchase. 14-day money-back guarantee.

---

## Important Disclaimers — Read First

This course is general education about starting a recycling business in the United States. It is not legal, tax, financial, or investment advice, and it is not a guarantee of income, profit, or business success. Recycling is a capital-intensive, permit-heavy, commodity-priced business. Prices for recovered materials rise and fall with global commodity markets, fuel costs, and local demand, and they can change sharply in weeks. Every price, margin, cost, and revenue figure in this course is an **illustrative example** built to teach you how to do the math yourself — not a promise of what you will earn, and not a report of current market prices. Before you spend money, verify current prices with real buyers in your area, confirm permit and zoning requirements with your city, county, and state agencies, and talk to a local attorney and accountant about business structure, licensing, and taxes.

Results depend on your market, your location, your available capital, your access to material and buyers, and the effort you put in. Many recycling businesses fail because the owner underestimated transport costs, overestimated the price buyers would pay, or discovered a required permit too late. This course exists to help you avoid exactly those mistakes — but it cannot remove the risk. Never invest money you cannot afford to lose, and never sign a lease, buy equipment, or take on debt based on a single course, article, or conversation.

**Permits and compliance:** The permits section (Module 6) is a US-focused overview of the kinds of requirements that commonly apply. Rules vary by state, county, and city, and they change. You must verify the rules that apply to your exact location and material stream with the agencies that enforce them.

---

## Table of Contents

- Introduction: Why Recycling Rewards the Careful — and Punishes the Hasty
- Module 1: How the Recycling Business Actually Works
- Module 2: The Four Main Material Streams — Plastics, E-Waste, Scrap Metal, Textiles
- Module 3: Picking Your Niche — The Profitability Comparison
- Module 4: Sourcing Material — Where Supply Really Comes From
- Module 5: Buyers, Pricing, and Getting Paid
- Module 6: Permits, Compliance, and the Rules That Can Stop You
- Module 7: Your 90-Day Launch Plan, Break-Even Math, and Staying in Business
- Appendix A: Glossary of Recycling Terms
- Appendix B: Your Pre-Investment Checklist
- Appendix C: Sources and How to Verify Current Prices

---

## Introduction: Why Recycling Rewards the Careful — and Punishes the Hasty

Every week, truckloads of cardboard, plastic bottles, old phones, worn-out appliances, and bags of used clothing move through American towns. To an outsider, it looks like money lying on the curb. To someone inside the business, it is a logistics operation with thin margins, heavy equipment, strict rules, and buyers who pay commodity prices — prices that can drop 30 percent in a month for reasons that have nothing to do with you.

That gap between how the business looks and how it works is where most beginners lose money. They see a pile of scrap metal and think about the price per pound. They do not think about the truck, the fuel, the forklift, the rent on the yard, the insurance, the scale ticket, the buyer who deducts for contamination, or the permit the county requires before the first load arrives.

This course is built around one idea: **pick the right niche before you invest.** A niche is not just a material. It is a material, plus a reliable source of supply, plus a buyer who pays fairly and on time, plus a cost structure you can actually cover, plus permits you can actually obtain in your location. Get all five right and a small recycling business can be a steady, honest living. Get one wrong and you can burn through your savings before your first profitable month.

You will not find income promises in this course. You will find math. Worked examples with real numbers, labeled clearly as illustrations. Cost estimators you can fill in with your own local figures. A method for comparing niches side by side so you can see which one fits your capital, your space, your truck, and your town — before you spend a dollar.

### Who this course is for

- Aspiring entrepreneurs who want to enter the recycling trade and need to choose a niche before investing.
- People considering plastics, e-waste, scrap metal, or textiles, and unsure which stream fits them.
- Side-hustlers and small operators who want to start lean — a pickup truck and a storage space, not a full processing plant.
- Anyone who has been told recycling is "easy money" and wants the honest version before committing.

### Who this course is not for

- Anyone looking for a get-rich-quick scheme. Recycling margins are thin and the work is physical.
- Anyone unwilling to deal with permits, inspections, and record-keeping. This business is regulated.
- Anyone who wants to run a large-scale materials recovery facility (MRF). This course covers entry-level and small-operator models, not industrial plant design.

### How to use this course

1. Read Modules 1 and 2 first. They give you the language and the landscape.
2. Do the exercises in the companion workbook as you go — especially the niche scoring worksheet in Module 3.
3. Fill in the startup cost estimator (templates/startup-cost-estimator.csv) with real quotes from your area before you spend anything.
4. Do not skip Module 6. Permits are the most common reason a new recycling business stalls.
5. Use Module 7's 90-day plan to launch in stages, with a clear break-even target and a decision point at day 90: continue, adjust, or stop.

### A note on the numbers in this course

Every dollar figure is an illustrative example unless it is explicitly described as a step in a calculation method. Commodity prices change constantly. When this course says "for example, a buyer might pay $0.08 per pound for baled PET," that is a teaching example to show you how the math works — not a quote you can rely on. Your job is to replace every illustrative number with a real, current, written quote from a buyer in your area. The templates are built for exactly that.

---

## Module 1: How the Recycling Business Actually Works

### 1.1 The value chain in plain language

A recycling business sits in the middle of a chain. On one side are the people and businesses that produce used material — households, offices, factories, demolition crews, retailers, schools. On the other side are the buyers — processors, mills, smelters, exporters, and manufacturers who turn recovered material back into products.

Your job, in almost every entry-level model, is one or more of these four functions:

1. **Collect.** Gather material from its source — curbside, drop-off, business pickups, cleanouts, demolition sites.
2. **Sort.** Separate material by type and grade, because mixed material is worth far less than sorted material.
3. **Process.** Do the minimum work that raises value: bale cardboard and plastic, strip wire, drain and dismantle appliances, grade and bale textiles, test and wipe electronics.
4. **Sell.** Deliver sorted, graded material to a buyer who pays by weight or by unit, and get paid on terms you can live with.

The money is made in the gap between what it costs you to collect, sort, process, transport, and store a load — and what the buyer pays for it. That gap is usually narrow. A beginner who focuses only on the buyer's price and forgets the transport cost is the most common failure in this business.

### 1.2 The five costs that decide whether you profit

Every niche, every model, and every load comes down to five cost buckets. Learn them now; you will use them in every calculation in this course.

**1. Acquisition cost.** What you pay (or are paid) to get the material. Sometimes you pay for it — buying scrap by the pound, or paying a hauling fee to take e-waste. Sometimes it is free — a business glad to have you haul away cardboard. Sometimes you are paid to take it — a company paying a disposal fee you undercut. Know which one applies to each source, and get it in writing.

**2. Transport cost.** Fuel, vehicle wear, your time, and any hired hauling. This is the silent killer. A load that looks profitable at the buyer's yard can be a loss by the time you drive it there. Transport cost is driven by distance, weight, and how full your truck is. A half-empty truck doubles your per-pound transport cost. Always calculate cost per pound or per ton delivered, not per trip.

**3. Processing cost.** Labor (including your own time, valued honestly), rent, utilities, equipment wear, baler wire, bags, pallets, and consumables. Sorting by hand is slow. A baler is fast but costs money to buy, power, and maintain. Every processing step must pay for itself in a higher selling price — if it does not, skip it or charge for it.

**4. Storage and handling cost.** Rent on your yard or unit, insurance, security, and the cost of material sitting unsold. Material that sits loses value in two ways: prices can fall while you hold it, and some materials degrade (wet cardboard, rusting metal, mildewed textiles). Storage is not free just because you own the space — that space has an opportunity cost.

**5. Compliance cost.** Permits, licenses, inspections, record-keeping, insurance, and any required reporting. Beginners routinely budget zero for this. Budget for it. A single fine, a forced shutdown, or a rejected load at the buyer's gate because your paperwork is wrong can cost more than a month of profit.

**Worked example — the five costs on one load:**
Imagine you collect 2,000 pounds of mixed cardboard from three small businesses in a week. You are paid nothing for the material itself (free pickup, a service the businesses value). Your costs: fuel and truck wear for three pickup runs, $45; your time, 6 hours at a modest $20/hour value, $120; baler wire and electricity, $12; a share of your storage unit rent for the week, $35; insurance and record-keeping share, $10. Total cost: $222. You sell the baled cardboard at an illustrative $60 per ton — 2,000 pounds is one ton, so revenue is $60. You lost $162 on that load.

That example is deliberately harsh, and it is the point. At $60 a ton, cardboard only works at volume, with dense routes, efficient baling, and a buyer close by. The same 2,000 pounds at a $110-per-ton illustrative price, collected on one dense route in 3 hours, with costs of $140, earns a small profit. The material did not change. The route, the volume, and the buyer price changed everything. That is why this course insists on math before money.

### 1.3 The four entry models

Most beginners enter through one of four models. Each has a different capital requirement, a different risk profile, and a different ceiling.

**Model A — Collection and resale (lowest capital).** You collect material, sort it lightly, and sell it to a larger processor or broker. You own a truck or trailer and basic hand tools. Startup cost is typically the lowest — often a few thousand dollars if you already own a suitable vehicle. Margins are the thinnest because you are doing the least processing, but you also carry the least risk and the least overhead. This is the right starting point for most people.

**Model B — Sort and bale.** You add a baler (or access to one) and sell denser, cleaner bales at a better price. Capital rises — a used vertical baler can cost several thousand dollars, a horizontal baler far more — but your per-pound revenue rises too, and transport cost per pound falls because bales pack tighter. This model suits cardboard, plastic film, and textiles.

**Model C — Dismantle and grade.** You take things apart: e-waste, appliances, wire, and mixed scrap. The value is in separating high-value components (copper, circuit boards, motors) from low-value bulk (steel shells, plastic housings). Capital is moderate — tools, workbenches, testing equipment, storage bins — but labor is high and you need to know what each component is worth and who buys it. This model rewards knowledge more than equipment.

**Model D — Brokerage and aggregation.** You do not handle material yourself. You connect sources with buyers and take a margin or a fee. Capital is the lowest of all — a phone, a scale ticket relationship, and credibility — but it is also the hardest to start, because both sides need to trust you before they will deal through you, and because buyers and sellers can cut you out once they meet. Brokerage works best as a second step, after you have handled material yourself and built relationships.

**Which model should you start with?** For most beginners, Model A, with a clear plan to grow into B or C in the niche you choose. Start by handling material, learning your local buyers, and proving you can move volume at a profit before you buy equipment. Equipment bought before you have supply and buyers is the most expensive mistake in this business.

### 1.4 The commodity trap

Recovered material is a commodity. That means three things you must accept:

- **You do not set the price.** The buyer does, based on markets you do not control. Your job is to know the price, track it, and decide whether to sell or hold.
- **Prices move.** A material that pays well in spring can pay half as much in autumn. Never build a business plan on a single week's price. Use a range — a low, a middle, and a high price — and make sure the business survives at the low end.
- **Quality is price.** Contamination is the fastest way to lose money. A bale of plastic with food waste in it, a load of e-waste with batteries mixed in, a gaylord of textiles with wet or soiled items — buyers deduct, reject, or downgrade. Clean, sorted, dry material earns the quoted price. Dirty material earns a deduction or a rejection.

### 1.5 Your first decision: local before everything

Recycling is a local business. The same niche can be profitable in one county and a money pit in the next, because the buyer is 20 miles away in one place and 200 miles away in the other, because one city requires a special use permit and the next does not, because one town has three competing scrap yards and the next has a monopoly buyer who sets the price.

Before you fall in love with any material, answer these five local questions:

1. Who buys this material within a reasonable drive of me, and what do they pay today?
2. Where does this material come from near me, in what volume, and how reliably?
3. What permits, zoning, and licenses does my city and county require for handling and storing it?
4. What does transport really cost me per pound, at the volumes I can realistically move?
5. Who else is already doing this near me, and what are they doing better or worse?

If you cannot answer those five questions for a niche, you are not ready to invest in it. Modules 2 through 6 exist to help you answer them.

### Module 1 exercise

In your workbook, write down the four entry models and rank them by how well each fits your current capital, vehicle, space, and time. Then list the five cost buckets and estimate, honestly, what each would cost you in a typical week. If you cannot estimate a bucket, write down who you will ask and by when.

---

## Module 2: The Four Main Material Streams — Plastics, E-Waste, Scrap Metal, Textiles

This module walks through the four streams the catalog targets. For each one: what it is, how it is graded, how beginners typically enter, what the money looks like in illustrative terms, and what the traps are. Read all four before you choose. The stream that sounds most exciting is rarely the one that fits your situation best.

A note on grades: every stream has grades, and grade is everything. Two loads that look identical to a beginner can be worth very different amounts because one is a clean single grade and the other is mixed or contaminated. Learn the grades for your chosen stream before you buy or collect a single load.

### 2.1 Plastics

**What it is.** The plastics stream covers the resins used in packaging and products: PET (beverage bottles, #1), HDPE (milk jugs, detergent bottles, #2), PP (food containers, caps, #5), LDPE film (bags, shrink wrap, #4), and others. The most commonly traded by small operators are PET bottles, HDPE containers, and LDPE film from commercial sources.

**How beginners enter.** The two realistic entry points are (a) collecting PET and HDPE bottles from businesses, events, schools, and deposit-return activity where applicable, and (b) collecting commercial LDPE film — shrink wrap and pallet wrap from warehouses, retailers, and distribution centers. Film is attractive because a single warehouse can generate a steady, clean supply, and because film bales are a standard traded product. Bottle collection is attractive because the material is visible and easy to understand, but it is bulky, light, and low-value per load until baled.

**Illustrative pricing (teaching examples only — verify locally).** Baled PET bottles might fetch in the range of $0.06–$0.15 per pound depending on grade, color (clear pays better than mixed color), and market conditions. Baled natural HDPE might fetch $0.15–$0.40 per pound. Baled clean LDPE film might fetch $0.05–$0.20 per pound. Loose, unbaled material fetches far less — sometimes nothing — because the buyer must pay to bale it. These ranges are deliberately wide because real prices swing with oil prices, virgin resin prices, and export demand. Your local buyer quote is the only number that matters.

**Worked example — film from one warehouse:** A small warehouse generates about 800 pounds of clean LDPE shrink wrap per month. You collect it weekly, bale it with a shared or rented baler, and sell 800 pounds at an illustrative $0.10 per pound: $80 of revenue for the month. Your costs: four pickup trips at $12 in fuel and wear each ($48), baler time and wire ($10), your time (4 hours at $20/hour = $80), and a share of storage ($15). Total cost: $153. You lost $73. Now change one variable: the same warehouse plus two more like it, 2,400 pounds a month, same four trips because the stops are on one route, baling in one session. Revenue at $0.10 per pound: $240. Costs: fuel $48, baler $20, your time 6 hours ($120), storage $15 — total $203. Profit: $37 for the month. Still thin. Now change the price: at $0.15 per pound, revenue is $360 and profit is $157. The lesson is not that film is good or bad. The lesson is that film only works at density (multiple stops per route), at volume (enough pounds to justify the baler and the trip), and at a price you have confirmed in writing. If any of those three is missing, the niche does not work for you — yet.

**Traps in plastics:**
- **Contamination.** Food residue, labels, mixed resins, and non-recyclable plastics in a bale trigger deductions or rejection. A bale that is 10 percent contamination can lose far more than 10 percent of its value.
- **Volume and weight.** Plastics are light. You need a lot of cubic feet to make a pound, which means transport cost per pound is high until you bale. Never buy a truckload of loose bottles expecting to profit on the resale alone.
- **Color and grade mixing.** Clear PET and colored PET are different products with different prices. Mixed-color bales pay the mixed price. Sorting by color takes time — price that time.
- **Market swings.** Plastic prices track oil and virgin resin. When virgin plastic is cheap, recycled plastic struggles. Build your plan on the low end of the range.

### 2.2 E-Waste (Electronics Waste)

**What it is.** Discarded electronics: computers, laptops, phones, tablets, monitors, printers, servers, networking gear, and small appliances. E-waste contains valuable materials — copper, aluminum, gold-bearing circuit boards, steel — and hazardous ones — lead, mercury, lithium batteries, refrigerants. That combination is what makes it both profitable and heavily regulated.

**How beginners enter.** The realistic entry points are (a) collecting business IT retirements — offices replacing computers, schools and clinics upgrading equipment — and reselling working units or parts, and (b) dismantling non-working equipment into sorted commodities (boards, copper wire, aluminum, steel, plastic) for sale to specialized buyers. A third path, refurbishing and reselling working laptops and phones, can pay better than scrap value but requires testing skills, data-wiping capability, and a sales channel.

**Illustrative pricing (teaching examples only).** These vary enormously by item and condition, which is the point: a working business laptop might resell for $80–$250, while the same laptop as scrap might yield $3–$8 in separated commodities. High-grade circuit boards might fetch $2–$8 per pound from a specialized buyer; low-grade boards far less. Copper-bearing wire, stripped, is priced near copper scrap rates; insulated wire pays much less. CRT monitors and old TVs are often a cost, not a revenue — many recyclers charge to take them because of the leaded glass and the disposal cost. Never assume every electronic item has positive scrap value. Some items cost you money to handle correctly.

**Worked example — a small office cleanout:** An office retires 20 desktop computers, 20 monitors (flat-panel), and assorted keyboards and cables — about 600 pounds total. You collect for free and spend a day testing, wiping data, and dismantling. You find 6 desktops that work and resell at an illustrative $60 each ($360), 4 more that yield usable parts worth $15 each ($60), and the rest dismantled into boards, wire, aluminum, and steel worth an illustrative $90 in commodity value. Total revenue: $510. Your costs: truck and fuel $40, your time 10 hours at $20/hour ($200), data-wiping software and supplies $15, storage share $20, and a disposal fee for 2 damaged flat-panel monitors that a buyer will not take ($30). Total cost: $305. Profit: $205 for the job. That is a good day — and it depended on resale, not scrap. If none of the machines had been resalable and the commodity value had been the whole revenue ($90), the same job would have lost $215. The lesson: in e-waste, your profit is usually in reuse and in knowing what to test, not in shredding everything.

**Traps in e-waste:**
- **Data liability.** A hard drive with a previous owner's data is a legal and reputational risk. You must wipe or destroy data properly, keep records, and — for business clients — sign a clear agreement about data handling. Never resell a drive you have not wiped.
- **Hazardous materials.** Lithium batteries can catch fire. CRTs contain lead. Refrigerants require certified handling. Mishandling is dangerous and can be illegal. Know what you are taking before you take it, and know what you will not take.
- **Regulation.** Many states have e-waste laws, and some require registration, reporting, or certification to handle certain items. The federal rules on exporting e-waste are strict. Module 6 covers the basics; verify your state's rules before you start.
- **The "free" trap.** Businesses will offer you truckloads of old electronics for free. Some of it is valuable. Some of it is a disposal bill in disguise. Learn to say no to loads that cost more to process than they return.

### 2.3 Scrap Metal

**What it is.** Ferrous metal (iron and steel — appliances, structural steel, cars, machinery) and non-ferrous metal (copper, aluminum, brass, stainless steel, lead, zinc). Non-ferrous metals are worth far more per pound than ferrous, and they are where most of the margin lives for a small operator. Copper is the classic example: heavy, valuable, and heavily targeted by thieves, which means buyers check identification and keep records.

**How beginners enter.** The realistic entry points are (a) collecting appliances, light iron, and mixed scrap from cleanouts, contractors, and small businesses, and selling to a local scrap yard; (b) specializing in non-ferrous — copper wire and pipe, aluminum, brass fixtures — from plumbers, electricians, HVAC contractors, and demolition crews; and (c) buying and reselling appliances or equipment that still work. Scrap metal is the most established of the four streams: the buyers are easy to find, the prices are posted, and the infrastructure (scales, yards, shredders) already exists.

**Illustrative pricing (teaching examples only).** Light iron and steel might fetch $0.03–$0.10 per pound. Prepared steel and heavy iron pay more. Aluminum (cans, extrusions, cast) might fetch $0.30–$0.70 per pound depending on grade. Copper — the highest-value common scrap — might fetch $2.50–$4.50 per pound for clean #1 copper, less for #2, and much less for insulated wire. Brass might fetch $1.00–$2.00 per pound. These are wide ranges because grades, contamination, and daily market prices move them constantly. Your local yard's posted prices, checked the day you sell, are the only numbers that count.

**Worked example — a week of light iron vs. a day of copper:** Option one: you collect 4,000 pounds of light iron (old appliances, scrap steel) over a week. At an illustrative $0.06 per pound, revenue is $240. Your costs: fuel and truck wear for five pickups ($75), your time 12 hours ($240), disposal fees for non-metal parts and refrigerants in two appliances ($60), and a share of storage and insurance ($25). Total cost: $400. You lost $160. Option two: you spend a day with a plumber who is replacing copper pipe in a renovation. You buy 150 pounds of clean copper pipe at an illustrative $2.00 per pound ($300) and sell it the same day at $3.50 per pound ($525). Your costs: fuel $20, your time 4 hours ($80). Profit: $125. The iron job moved twenty-six times the weight and lost money. The copper job moved a small, dense, high-value load and made money. Weight is not profit. Value density — dollars per pound, minus cost per pound to move it — is profit.

**Traps in scrap metal:**
- **Theft and title.** Scrap yards are required in many states to record seller identification and, for some materials, to hold payment or verify ownership. Never buy or accept material you cannot show a legitimate source for. Stolen copper can mean criminal liability, not just a lost load.
- **Contamination and attachments.** A load of steel with wood, rubber, or concrete attached pays less or gets rejected. Copper wire with insulation pays the insulated price, not the bare bright price. Budget time for cleaning and separating — or accept the lower grade.
- **Refrigerants and hazardous components.** Appliances with refrigerants (fridges, freezers, air conditioners) require certified refrigerant recovery before scrapping in the US. Some yards will not take them at all; others charge a fee. Know the rule and the fee before you accept the appliance.
- **Price volatility and yard terms.** Prices change daily. Some yards pay cash, some pay by check after a hold period, some deduct for scale fees or contamination. Know the terms before you unload.

### 2.4 Textiles

**What it is.** Used clothing, shoes, household textiles (towels, bedding, curtains), and industrial textiles (rags, wiping cloths). The stream splits into three value tiers: wearable clothing that can be resold (the highest value), clothing that can be reused as wiping rags or industrial material (mid value), and worn-out material that can only be recycled into fiber, insulation, or stuffing (lowest value, sometimes a cost).

**How beginners enter.** The realistic entry points are (a) collecting used clothing through drop-off bins, community drives, or partnerships with thrift stores and charities that have overflow; (b) sorting and grading wearable clothing for resale through vintage shops, online resale, or export buyers; and (c) supplying graded rags and wiping cloths to industrial buyers. Textiles are attractive because the material is abundant and the entry cost is low — bags, a sorting table, a scale, and a storage space. They are difficult because sorting is slow, grading is subjective, and a large share of what you collect is low-value or unsellable.

**Illustrative pricing (teaching examples only).** Mixed used clothing sold in bulk to a grader or exporter might fetch $0.10–$0.30 per pound. Sorted wearable clothing sold in bales by category can fetch more — sometimes $0.50–$1.50 per pound for good grades — while rag-grade material might fetch $0.05–$0.15 per pound. True vintage or branded pieces sold individually online can fetch far more, but that is a resale business, not a recycling business, and it depends on your eye for brands and condition. These ranges are illustrative; local buyers and export demand move them.

**Worked example — a community clothing drive:** You run a weekend drive and collect 1,500 pounds of bagged clothing. You sort it over two days. About 40 percent (600 pounds) is wearable and in good condition; 35 percent (525 pounds) is rag-grade; 25 percent (375 pounds) is stained, wet, torn beyond use, or non-textile trash mixed in. You sell the wearable grade at an illustrative $0.60 per pound ($360) and the rag grade at $0.10 per pound ($52.50). Total revenue: $412.50. Your costs: collection bins and bags $30, fuel $25, your time — 16 hours of sorting at $20/hour ($320), storage share $20, and disposal of the 375 pounds of unsellable material at a local tip fee (illustrative $40 per ton, so about $7.50, plus your time to haul it). Total cost: about $402.50. Profit: about $10. That is the honest math of an unsorted drive: the sorting labor eats the margin. Now change one variable: a partnership with a thrift store that pre-sorts and gives you only their overflow wearable grade — 600 pounds at the same $0.60 price, with 3 hours of your time instead of 16. Revenue $360, costs about $125, profit about $235. The lesson: in textiles, your profit is in the quality of the incoming sort, not in the volume of bags you collect.

**Traps in textiles:**
- **Sorting labor.** Sorting is the whole business, and it is slow. If you value your time honestly, most unsorted textile loads do not pay.
- **Wet and soiled material.** Wet clothing mildews fast, weighs more (you pay to haul water), and can ruin a whole bale. Never store bagged textiles where they can get wet, and never bale wet material.
- **The charity confusion.** Collecting "for charity" and then selling the material is a regulated area in many states, and it can damage your reputation fast if donors believe their clothes go directly to people in need. Be transparent about what you do with collected clothing, and get any charity partnership in writing.
- **Export dependence.** A large share of graded used clothing is exported. Export demand, shipping costs, and import rules in destination countries can change quickly and affect the price your local buyer will pay.

### Module 2 exercise

In your workbook, write one paragraph for each stream explaining, in your own words, where the money is made and where it is lost. Then rank the four streams by how well each fits your capital, your vehicle, your space, and your local market — and write down what you still need to verify for your top-ranked stream before you choose it.

---


## Module 3: Picking Your Niche — The Profitability Comparison

This is the module the whole course is built around. Do not rush it. A niche chosen well saves you a year of expensive learning. A niche chosen badly costs you that year anyway, plus your capital.

### 3.1 What a niche actually is

A niche is not a material. It is a complete, working combination of five things:

1. **A material stream** you understand and can grade.
2. **A reliable source** of that material, in volume, near you.
3. **A buyer** who pays fairly, pays on time, and will take your volume.
4. **A cost structure** you can cover at realistic prices — not best-case prices.
5. **Permits you can obtain** in your location, at a cost you can afford.

If any one of the five is missing or weak, the niche is not ready. You can fix a weak element — find a second buyer, negotiate a better source, get the permit — but you cannot skip it and hope. Hope is not a business plan.

### 3.2 The comparison method

Use the niche profitability comparison tool (templates/niche-profitability-comparison.csv) to score each stream side by side. The method has three steps:

**Step 1 — Score each stream on seven factors, 1 to 5.** The factors are: supply availability near you; buyer access and payment reliability; revenue per pound (value density); transport cost per pound; processing labor per pound; permit and compliance burden; and your own knowledge and interest. Score honestly. A 5 in "supply availability" means you already have a source lined up, not that you hope one exists.

**Step 2 — Run the money math for a typical week.** For each stream, estimate: pounds you can realistically collect in a week, revenue per pound at the low end of your local price range, and total weekly cost (all five cost buckets from Module 1). Weekly profit at the low price is your stress-test number. If a niche only profits at the high price, it is not a niche — it is a gamble.

**Step 3 — Apply the deal-breaker test.** Three deal-breakers override any score: (a) you cannot legally handle or store the material in your location; (b) there is no buyer within a transport distance that leaves a margin; (c) you cannot get a reliable supply. A niche that fails any deal-breaker is out, no matter how attractive the headline price looks.

### 3.3 The four streams compared — an illustrative side-by-side

The table below is an illustrative comparison using the example price ranges from Module 2. It is a teaching example, not market data. Your filled-in comparison tool, with your local quotes, is the real version.

| Factor | Plastics | E-Waste | Scrap Metal | Textiles |
|---|---|---|---|---|
| Typical entry capital | Low–medium (truck + baler access) | Low–medium (tools, testing, storage) | Low (truck + hand tools) | Low (bags, sorting space, scale) |
| Value density (revenue/lb, illustrative) | Low ($0.05–$0.40) | Very high per item, variable | Medium–high ($0.03–$4.50 by grade) | Low ($0.10–$0.60 bulk) |
| Volume needed to profit | High | Low–medium | Medium (low for copper) | High |
| Processing labor | Medium (sort + bale) | High (test, wipe, dismantle) | Low–medium (sort + clean) | High (sort + grade) |
| Transport sensitivity | High (light, bulky) | Medium | Low for non-ferrous; high for iron | High (bulky, light) |
| Permit burden | Medium | High | Medium–high | Low–medium |
| Price volatility | High | Medium (resale steadier than scrap) | High (daily prices) | Medium |
| Best for | Operators with route density + baler access | Operators with technical skill + resale channels | Operators near good yards + contractor contacts | Operators with sorting space + pre-sorted supply |

Read the table as a set of trade-offs, not a ranking. Plastics reward route density and volume. E-waste rewards knowledge and resale skill. Scrap rewards relationships with contractors and a good local yard. Textiles reward sorting discipline and a pre-sorted supply. Your situation — your truck, your space, your contacts, your skills — decides which trade-off fits you.

### 3.4 Worked comparison — three beginners, three different answers

**Beginner A — Maya, warehouse district, owns a pickup and a small storage unit.** Maya has three warehouses within five miles that generate clean LDPE film, and a buyer 25 miles away who takes baled film. She has no baler but can rent time on one at a nearby facility for a flat fee. Her comparison shows plastics scoring highest: supply is confirmed, transport is short, and the baler rental keeps capital low. Her stress test at the low price still shows a small profit at 2,400 pounds a month. She chooses plastics, film-first, and plans to add PET bottles from the same warehouses in month three.

**Beginner B — Dev, former IT technician, garage workspace, no truck.** Dev has no truck and limited space, but he can test, wipe, and repair laptops, and he has contacts at two small businesses replacing equipment. Transport is his weakness, so he chooses e-waste with a resale focus: he collects small loads in a borrowed van or has the business deliver, tests and wipes on a bench, and sells working units online. His stress test shows that even if commodity prices fall, the resale revenue carries the job. He chooses e-waste and explicitly avoids CRTs, printers, and anything with a disposal cost.

**Beginner C — Rosa, rural area, owns a flatbed trailer, knows local contractors.** Rosa's nearest plastics buyer is 120 miles away, which kills plastics on transport cost. But she has a scrap yard 15 miles away with posted prices, and she knows three contractors who generate copper, aluminum, and brass. Her comparison shows scrap metal — non-ferrous first — scoring highest by a wide margin. Her stress test at the low copper price still profits because her transport is short and her acquisition cost is a fair purchase price, not a gamble. She chooses scrap metal, non-ferrous, and plans to add light iron only when she has a full trailer and a route that makes the trip pay.

Three people, three correct answers, all different. That is the point of the comparison. There is no best niche. There is a best niche for you, in your place, with your resources.

### 3.5 The niche you should not pick (yet)

Be honest about the niches that do not fit you yet, and write them down. Common mismatches:

- **Plastics without a baler or baler access, and without route density.** Loose plastic is mostly air. You will spend more on transport than the material is worth.
- **E-waste without data-wiping capability or a hazardous-materials plan.** One data breach or one battery fire can end the business.
- **Scrap metal without a legitimate source trail.** If you cannot document where material came from, you should not handle it.
- **Textiles without a sorting plan and a disposal route for the unsellable share.** A quarter of a typical unsorted load is waste. If you have no legal, affordable way to dispose of it, you have a storage problem, not a business.
- **Any niche where the only buyer is far away, pays slowly, or will not put a price in writing.** Distance, slow payment, and verbal prices are three separate ways to lose money.

"Not yet" is a useful answer. It means: build the missing piece first — the baler access, the testing bench, the contractor relationships, the permit — and then re-run the comparison.

### 3.6 Choosing your first niche: the decision worksheet

In the workbook, complete the niche scoring worksheet for all four streams. Then answer these five questions in writing:

1. Which stream scored highest, and by how much? If the top two are close, what would tip the balance?
2. What is your stress-test weekly profit at the low price? Is it positive? By how much?
3. Which deal-breaker test did you run, and what did it show?
4. What is the single weakest element of your chosen niche (supply, buyer, cost, permit, or knowledge), and what will you do about it in the first 30 days?
5. What is your stop rule — the specific result at day 90 that would make you change niches or stop?

Write the answers down. A decision you can re-read in 90 days is worth ten times a decision you only thought about.

### Module 3 exercise

Fill in templates/niche-profitability-comparison.csv with your own local numbers — real buyer quotes, real distances, real fuel costs. If you do not have a real quote yet, the cell stays blank and the niche stays unchosen. A blank is honest. A guessed price is a trap.

---

## Module 4: Sourcing Material — Where Supply Really Comes From

A recycling business without supply is a truck with nowhere to go. This module covers where material actually comes from, how to secure it, and how to keep it coming.

### 4.1 The four source types

**Businesses and institutions.** Offices, warehouses, retailers, restaurants, schools, clinics, factories. They generate steady, predictable, often clean material — cardboard and film from warehouses, IT equipment from offices, offcuts from factories, fixtures from renovations. Business supply is the best supply for a beginner: it is regular, it is often pre-sorted, and the business usually wants a reliable pickup more than it wants a high price. Your pitch is reliability: same day, same time, every week, no mess left behind.

**Contractors and trades.** Plumbers, electricians, HVAC installers, demolition crews, roofers. They generate non-ferrous metal, wire, and mixed scrap in bursts — a lot at once, then nothing for weeks. Contractor supply pays well per pound but is lumpy. Your pitch is speed and fairness: you show up when they call, you weigh honestly, you pay fairly and fast.

**Households and community.** Curbside material, cleanouts, estate clearances, community drives, drop-off points. Household supply is abundant but mixed, unpredictable, and labor-heavy to sort. It works best when you have a specific, narrow ask — "we collect working laptops" or "we collect clean, dry clothing" — rather than a general "we take everything."

**Other recyclers and overflow.** Larger processors, thrift stores, and charities sometimes have overflow they will pass on — material they cannot process or do not want. This can be excellent supply (pre-sorted, in volume) but it depends on relationships, and it can disappear when the larger operator's own capacity changes. Treat it as a bonus, not a foundation.

### 4.2 Securing supply: the agreement that matters

Verbal agreements are how beginners lose their best source to a competitor. Get the essentials in writing — a simple one-page service note is enough at this stage:

- What material you will collect, and what you will not take.
- Pickup day, time, and frequency.
- Who provides containers, bags, or bins, and who owns them.
- What you pay (if anything) or what you charge (if anything), and when.
- Who is responsible for contamination, and what happens if a load is contaminated.
- How either side ends the arrangement, and with how much notice.
- For e-waste: how data will be handled, wiped, or destroyed, and what records you will keep.

You do not need a lawyer to write the first version, but you do need it in writing, signed by both sides, with a copy each. For business clients, ask a local attorney to review your standard form once you have one — it is a small cost that prevents large disputes.

### 4.3 Pricing your collection service

Sometimes you pay for material. Sometimes it is free. Sometimes you charge a collection fee. The right answer depends on the material's value to you and the cost of the alternative to the source:

- **High-value material (copper, working electronics, good-grade textiles):** you usually pay the source, or you collect free and the source is glad to be rid of it. Paying a fair price keeps the source loyal.
- **Low-value, high-volume material (cardboard, film):** you usually collect free, as a service. The business saves on waste-hauling fees, and you get the material. That trade is the deal.
- **Negative-value material (CRTs, wet textiles, contaminated loads, items with disposal fees):** you must charge a fee that covers your handling and disposal cost, or you must decline. Taking negative-value material for free is how beginners fill a storage unit with a disposal bill.

**Worked example — charging for a cleanout:** A small business asks you to clear a storage room: 12 old computers (8 working, 4 not), 2 printers, and a pile of cables — about 400 pounds. You quote a $75 collection fee, explaining that the fee covers the non-working units and the printers, which cost you money to handle. The client agrees because a commercial hauler quoted $200. You resell 6 working desktops at an illustrative $50 each ($300), sell parts from 2 more ($30), and recover $40 in commodity value from the rest. Revenue: $370 plus the $75 fee, $445 total. Costs: fuel $25, your time 6 hours ($120), data wiping $10, disposal of the 2 printers at $15 each ($30). Total cost: $185. Profit: $260. The fee did not scare the client away — it was less than the alternative, and it made the job profitable for you. Price the service on the value to the client and the cost to you, not on guilt about charging.

### 4.4 Building a route: density is profit

A route is a set of pickups you can complete in one trip, in a sensible order, with a full truck at the end. Density — pounds per mile and pounds per hour — is what makes collection profitable. Three rules:

1. **Cluster your stops.** Five stops within ten miles beat ten stops spread across fifty miles. Say no to a far-away stop until you have others near it.
2. **Fix the schedule.** Same day, same time, every week. Businesses plan around you, and you plan your week around the route. Ad-hoc pickups are expensive.
3. **Fill the truck.** A half-empty truck costs nearly as much to run as a full one. If your route does not fill the truck, add stops or combine collection days until it does.

**Worked example — route density:** Route A: four stops, 40 miles total, 1,200 pounds collected, fuel and wear $28, your time 3 hours ($60). Cost per pound for transport and time: $0.073. Route B: four stops, 110 miles total, 1,200 pounds collected, fuel and wear $77, your time 5.5 hours ($110). Cost per pound: $0.156 — more than double. Same material, same weight, same buyer price. Route A profits; Route B loses. The difference is geography, not effort.

### 4.5 Keeping supply: reliability beats price

Sources leave for two reasons: you are unreliable, or someone else pays more. You can control the first completely and the second partly. Be on time, every time. Leave the area clean. Communicate before you miss a pickup, not after. Pay what you promised, when you promised. Keep simple records of what you collected and what you paid, and share a summary with business clients who ask — transparency builds trust faster than any sales pitch.

When a competitor offers your source more money, do not panic and do not match a price you cannot afford. Ask what matters to the source besides price: reliability, cleanliness, frequency, paperwork, data handling. Often the answer is not money at all. And if it is money, and you cannot match it profitably, let the source go gracefully. A source that loses you money is not a source — it is a liability.

### 4.6 What not to collect

Every beginner should have a written "we do not take" list, posted where they will see it before every pickup. A starter list:

- Material you cannot legally store or transport in your location.
- Items with hazardous components you are not equipped to handle (leaking batteries, CRTs unless you have a certified downstream, refrigerants unless you have certified recovery).
- Loads you cannot verify the source of.
- Material that is wet, soiled, or contaminated beyond what your buyer will accept.
- Anything that would require a permit you do not have.

Saying no is a business skill. Every load you decline is a disposal bill, a fine, or a rejected bale you avoided.

### Module 4 exercise

In your workbook, list ten potential sources near you — businesses, contractors, institutions — with the material each generates, the likely volume, and how far away they are. Then draft your one-page collection service note and your "we do not take" list. Contact your top three sources this week and ask, in person or by phone, what they currently do with the material you want.

---


## Module 5: Buyers, Pricing, and Getting Paid

You can collect the best material in the world and still lose money if you sell it to the wrong buyer, at the wrong time, on the wrong terms. This module is about the other side of the trade.

### 5.1 Types of buyers

**Local scrap yards and processors.** The most common buyer for scrap metal and, in some areas, for plastics and e-waste commodities. They buy by weight, grade material on arrival, and pay posted prices that change daily or weekly. Advantages: easy to find, fast payment, no minimum volume. Disadvantages: prices are set by the yard, grading is their call, and you have little negotiating power as a small seller.

**Brokers.** Middlemen who buy from small operators and sell to mills, smelters, and exporters. A good broker can get you a better price than a local yard, handle logistics, and take larger volumes. A bad broker can delay payment, dispute grades, or disappear. Advantages: better prices for sorted, baled material; access to distant markets. Disadvantages: payment terms are slower, trust matters more, and you must verify everything.

**Mills, smelters, and manufacturers.** The end users of recovered material. They usually buy in large volumes with strict specifications, and they rarely deal directly with small operators. Your path to them is usually through a broker or a larger processor — or by growing to a volume they will deal with directly.

**Resale buyers.** For e-waste and textiles, the resale market — online marketplaces, vintage shops, refurbishers, export graders — often pays far more than the scrap or bulk price. Resale takes more time per item but earns more per pound. Know which items in your stream have resale value and which do not, and separate them early.

**Export buyers.** Graded textiles and some plastics and metals move through export channels. Export prices can be attractive, but they depend on shipping costs, container availability, and import rules in the destination country — all of which can change quickly. As a beginner, sell to a local buyer or broker who handles export; do not try to export directly.

### 5.2 How buyers price your material

Buyers pay on three things: **grade, weight, and market price on the day of sale.** Grade is the quality and purity of the material. Weight is what the scale says — and the buyer's scale is the one that counts, so understand how they weigh (gross weight minus container weight, moisture deductions, contamination deductions). Market price is the commodity price that day, which you do not control.

Before you sell, know:
- The buyer's price list for each grade, and how often it changes.
- How the buyer grades — what counts as #1 copper versus #2, what counts as clean film versus contaminated film.
- What deductions apply — moisture, contamination, container weight, scale fees.
- Payment terms — cash, check, bank transfer, and how long after delivery.
- Minimum volumes, delivery windows, and whether they accept drop-off or require scheduled delivery.
- What paperwork they require — identification, source records, and, for some materials, proof of ownership or a business license.

Get the price in writing — an email, a text, or a printed price sheet with a date — before you load the truck. A verbal price that changes when you arrive is a price you cannot plan on.

### 5.3 Negotiating as a small seller

You will not out-negotiate a scrap yard on the commodity price. You can negotiate on the things around the price:

- **Grade.** Learn to grade your own material accurately, present it cleanly sorted, and ask the buyer to show you how they graded a load you disagree with. Clean, well-presented material gets the grade it deserves more often than a mixed, dirty load.
- **Volume commitments.** A buyer who knows you will deliver 2,000 pounds every week is more willing to hold a price or offer a better tier than a buyer who sees you once. Reliability is negotiating power.
- **Payment terms.** Faster payment is worth a slightly lower price when your cash is tight. Ask what the options are.
- **Multiple buyers.** Never rely on a single buyer. Get quotes from at least three buyers for your main material, and keep the relationships warm even when you are selling to one of them. A second quote is your only real leverage, and your only protection if your main buyer closes, changes terms, or stops taking your grade.

**Worked example — the second quote:** You have 500 pounds of stripped copper wire. Buyer A quotes $3.00 per pound: $1,500. Buyer B quotes $3.25 per pound: $1,625 — a $125 difference on one load. Buyer B is 30 miles farther away, costing an extra $18 in fuel and an extra hour of your time ($20). Net gain from choosing Buyer B: $87. Worth it. Now imagine Buyer B's quote was $3.05: a $25 gross gain, minus $38 in extra cost — a net loss of $13. Not worth it. Always calculate the net, after transport, before you chase a higher price.

### 5.4 When to sell and when to hold

Commodity prices move. Sometimes holding material for a better price pays. Sometimes it costs you. Three rules:

1. **Never hold what you cannot store properly.** Wet cardboard, rusting steel, mildewing textiles, and lithium batteries lose value or become hazards in storage. If you cannot store it dry, safe, and secure, sell it.
2. **Never hold on a guess.** Hold only when you have a reason — a known seasonal pattern you have tracked, a buyer who has told you a price will rise, a contract that sets a future price. "I feel like it will go up" is not a reason.
3. **Never hold what you need the cash from.** If holding a load means you cannot pay for fuel, rent, or the next collection run, sell it. Cash flow keeps the business alive; a speculative hold does not.

A practical approach for beginners: sell regularly, in steady volumes, and track the prices you received. After six months you will have your own price history — the most valuable pricing data you can own, because it is your market, your grades, your buyers.

### 5.5 Getting paid — and protecting yourself

- **Keep a paper trail for every sale.** Date, buyer, material, grade, weight (gross and net), price per pound, total paid, payment method, and any deductions. Photograph the scale ticket. This protects you in disputes, helps your taxes, and shows you which buyers and grades actually profit.
- **Understand payment timing.** Some buyers pay on the spot. Some pay in 7, 14, or 30 days. A buyer who pays in 30 days is effectively lending you nothing and borrowing from you — price that into your decision, and never depend on a slow-paying buyer for money you need this week.
- **Watch for grading disputes.** If a buyer downgrades a load you believe was correctly graded, ask to see the material, ask for the reason in writing, and compare with your next load at a second buyer. One dispute is a disagreement. A pattern of downgrades is a buyer to leave.
- **Do not extend credit to buyers.** As a small seller, you should be paid on delivery or on short, agreed terms. If a buyer asks you to deliver now and be paid "when they sell it on," decline. That is their cash-flow problem, not yours.

### 5.6 Buyer outreach: how to approach a buyer

Use the outreach templates (templates/buyer-broker-outreach-scripts.md) for exact scripts. The principles:

- **Introduce yourself briefly:** who you are, what material you handle, what volume you can supply, and how it is graded and packaged.
- **Ask, do not pitch:** ask what grades they buy, what their current prices are, what their delivery and payment terms are, and what they require from a new supplier.
- **Bring a sample:** for your first delivery, bring a small, clean, well-sorted sample load. Let the material speak.
- **Follow up in writing:** after the conversation, send a short email confirming the grades, prices, and terms you discussed. If the buyer will not confirm in writing, treat the prices as unconfirmed.

### Module 5 exercise

In your workbook, list at least three buyers for your chosen niche, with their prices, terms, distances, and requirements. Call or visit each one this week. Record the quotes in the buyer outreach tracker, and note which buyer you will sell to first and why.

---

## Module 6: Permits, Compliance, and the Rules That Can Stop You

This is the module beginners most want to skip, and the one that most often decides whether a new recycling business survives its first year. Read it fully. Then verify everything in it against your local rules.

**Scope reminder:** This module is a US-focused general overview. It is not legal advice. Rules vary by state, county, and city, and they change. Your city or county planning department, your state environmental agency, and a local attorney are the authorities for your situation.

### 6.1 Why recycling is regulated

Recycling handles waste, hazardous materials, and large volumes of stored material. Governments regulate it because of fire risk (piles of material, lithium batteries), water and soil contamination (leaking fluids, lead, oils), pests and odour, traffic and noise, and the theft and fencing of stolen metal. The rules are not there to stop honest operators — but they will stop an operator who does not know they exist.

### 6.2 Business basics: structure, registration, and tax

Before you handle a single load as a business, you need the business itself in order:

- **Business structure.** Sole proprietorship, LLC, partnership, or corporation — each has different liability, tax, and paperwork implications. Many small recyclers choose an LLC for liability protection, but the right choice depends on your state and your situation. Talk to a local attorney or accountant before you choose, and before you sign anything.
- **Business registration.** Register your business name with your state and, where required, your county or city. Get an Employer Identification Number (EIN) from the IRS if you need one — most businesses with employees, and many LLCs, do.
- **Sales tax and resale.** Rules on whether you collect sales tax on resold items (such as refurbished electronics or resold clothing) vary by state. Your state tax agency can tell you whether you need a seller's permit or a resale certificate.
- **Insurance.** At a minimum, general liability insurance and commercial vehicle insurance. If you have a yard or storage, property insurance. If you handle e-waste, consider pollution liability and coverage for data-related claims. If you have employees, workers' compensation is required in most states. Get quotes before you start — insurance is a real cost, and it belongs in your startup estimator.
- **Banking and records.** Open a separate business bank account. Keep business money and personal money separate from day one. Keep records of every purchase, sale, and expense — you will need them for taxes, for disputes, and for your own understanding of whether the business profits.

### 6.3 Zoning and land use: where you can operate

Zoning is the most common surprise for new recyclers. You cannot assume you can store and sort material wherever you live or wherever rent is cheap.

- **Check zoning before you sign a lease.** Call your city or county planning department and ask, in plain language: "I want to collect, sort, and store [your material] at [the address]. Is that allowed in this zone, and what permits do I need?" Get the answer in writing if you can.
- **Residential areas are usually off-limits** for anything beyond small-scale, indoor work. Outdoor storage, truck traffic, and noise in a residential zone will draw complaints and enforcement.
- **Industrial and commercial zones** are the usual home for recycling operations, but even there, a specific use permit, a conditional use permit, or a site plan approval may be required.
- **Home-based operations** are possible for some models — e-waste testing and resale from a garage, for example — but check your local home-occupation rules, any homeowners' association rules, and fire code limits on storage.

**Worked example — the lease signed too soon:** A beginner signs a one-year lease on a cheap warehouse unit, pays a deposit and first month's rent ($1,800), buys a baler ($4,500 used), and then learns the unit's zoning does not allow outdoor storage or the truck traffic the business needs. The landlord will not release the lease. The beginner must either operate in violation (risking fines and shutdown), find a new location and pay double rent, or walk away from the deposit and the lease. Total loss before the first sale: over $6,000. One phone call to the planning department, made before signing, would have prevented it. Make that call.

### 6.4 Environmental permits and registrations

Depending on your state and your material, you may need one or more of the following. This list is an overview, not a complete inventory for your location:

- **Solid waste facility or recycling facility permit or registration.** Many states require facilities that receive, sort, process, or store recyclable material to register with, or be permitted by, the state environmental agency. Some small operations are exempt below a volume threshold; some are not. Ask your state agency where the threshold is.
- **Stormwater permits.** If you store material outdoors, rain can carry contaminants into storm drains. Many states and cities require a stormwater permit or a pollution prevention plan for outdoor storage and processing areas.
- **Air permits.** Some processing — shredding, melting, burning — can require air permits. Small sorting and baling operations usually do not, but check if you plan any processing beyond sorting and baling.
- **Hazardous waste rules.** E-waste, batteries, fluorescent lamps, and materials containing lead, mercury, or refrigerants are regulated as hazardous or universal waste in many states. You may need to register as a handler, follow specific storage and labeling rules, and use only permitted downstream facilities. Never mix hazardous waste into a general recycling load.
- **Fire code and storage limits.** Fire departments set limits on how high and how densely material can be piled, require clear aisles and access for fire equipment, and may require a fire prevention plan for indoor storage. Lithium batteries deserve special attention — store them separately, in approved containers, away from other material.
- **Local business licenses and scrap-specific rules.** Many cities and counties require a business license, and some have specific rules for scrap dealers — including seller identification, record-keeping, holding periods before resale, and restrictions on buying certain materials (such as copper wire, catalytic converters, and manhole covers) without proof of ownership. Know your local scrap-dealer rules before you buy your first load.

### 6.5 E-waste rules in more detail

E-waste deserves its own subsection because the rules are layered and the penalties are real:

- **State e-waste laws.** Many states have laws covering the collection and recycling of electronics, with registration, reporting, and sometimes certification requirements for collectors and recyclers. Some states ban certain electronics from landfills entirely.
- **Data destruction.** If you handle business electronics, your clients will expect — and may contractually require — certified data wiping or physical destruction, with a certificate of destruction. Keep records of every drive you wipe or destroy.
- **Export rules.** Exporting used electronics, especially non-working units, is regulated under US law and under the laws of destination countries. Do not export e-waste without understanding the rules and using a compliant downstream partner.
- **Certifications.** Industry certifications such as R2 and e-Stewards exist for electronics recyclers. They are not required for every small operator, but large business clients increasingly ask for them, and they can be a competitive advantage as you grow. They also cost time and money to obtain — treat them as a growth goal, not a starting requirement.

### 6.6 Record-keeping: the habit that protects you

Keep records from day one, even when the business is small. At minimum:

- Every load in: date, source, material, grade, weight, price paid (if any), and the name of the person who supplied it.
- Every load out: date, buyer, material, grade, weight, price received, payment method, and a copy of the scale ticket.
- Every permit, license, and insurance document, with renewal dates.
- Every data-wiping or destruction certificate.
- Every disposal receipt for material you could not sell.

Good records do three things: they keep you compliant, they settle disputes, and they tell you the truth about whether you are making money. A business without records is a hobby with expenses.

### 6.7 The permits and compliance checklist

Use templates/permits-compliance-checklist.md as your working checklist. Do not start collecting material for sale until you have checked every item that applies to your location and material — or at least know which items are pending and when they will be resolved. If a required permit will take 60 days, that is your launch timeline, not an inconvenience to work around.

### Module 6 exercise

In your workbook, complete the permit checklist for your location and material. List every agency you need to contact, the question you will ask each one, and the date you will contact them. Make the first call this week — the zoning call — before you spend money on anything else.

---

## Module 7: Your 90-Day Launch Plan, Break-Even Math, and Staying in Business

You have the knowledge. This module turns it into a launch — in stages, with numbers, and with a decision point at the end.

### 7.1 Break-even analysis: the number that matters most

Break-even is the point where your revenue covers your costs. Before you launch, you must know two break-even numbers:

**Monthly break-even revenue.** Add up your fixed monthly costs — rent, insurance, phone, loan payments, subscriptions — the costs you pay whether you sell anything or not. Then add your variable cost per pound (transport, processing, acquisition) multiplied by the pounds you expect to move. Your break-even revenue is the revenue you need each month to cover both.

**Break-even pounds.** Divide your monthly fixed costs by your contribution margin per pound — that is, your selling price per pound minus your variable cost per pound. The result is the number of pounds you must sell each month to break even.

**Worked example — break-even for a small plastics operation:**
Fixed monthly costs: storage unit $250, insurance $80, phone $40, baler rental share $60. Total fixed: $430 per month.
Variable cost per pound: transport $0.04, processing (baler wire, electricity, your time valued at $20/hour spread across pounds) $0.06, acquisition $0.00 (free collection). Total variable: $0.10 per pound.
Selling price: $0.18 per pound (illustrative, baled film).
Contribution margin per pound: $0.18 − $0.10 = $0.08.
Break-even pounds: $430 ÷ $0.08 = 5,375 pounds per month.
That is the number to stare at. Can you realistically collect, bale, and sell 5,375 pounds of film a month — about 1,344 pounds a week — from your sources? If your three warehouses generate 2,400 pounds a month combined, you are less than halfway to break-even, and the business loses money every month until you add sources or raise the price. If you can add two more warehouses and reach 5,500 pounds, you break even — barely. If the price drops to $0.14, your margin becomes $0.04 and break-even jumps to 10,750 pounds a month, which you cannot reach. That is why the stress test matters: run break-even at the low price, not the middle price. If the business only works at the high price, it does not work.

**Worked example — break-even for a small e-waste resale operation:**
Fixed monthly costs: garage workspace share $0 (already owned), insurance $60, phone $40, software $15. Total fixed: $115 per month.
Average job: collect 20 desktops, resell 6 at $60 ($360), parts $60, commodities $90 — revenue $510. Variable cost per job: fuel $40, your time 10 hours ($200), supplies $15, disposal $30 — total $285. Contribution per job: $510 − $285 = $225.
Break-even jobs per month: $115 ÷ $225 = 0.51 jobs — one job a month covers fixed costs, and every job after that is profit (before tax). That is a much healthier break-even than the plastics example, because the margin per job is large and the fixed costs are low. It is also more fragile in a different way: it depends on a steady flow of business cleanouts and on your ability to resell. If the cleanouts stop for a month, revenue stops too. Every model has a fragility. Know yours.

### 7.2 The 90-day launch plan

**Days 1–30: Verify, do not buy.**
- Complete the niche comparison with real local quotes (Module 3).
- Make the zoning call and start the permit checklist (Module 6).
- Contact your top three sources and your top three buyers (Modules 4 and 5).
- Fill in the startup cost estimator with real quotes (templates/startup-cost-estimator.csv).
- Run your break-even analysis at the low, middle, and high price.
- Decision point at day 30: if the numbers do not work at the low price, change the niche, change the model, or delay the launch. Do not buy equipment to fix a bad niche.

**Days 31–60: Start small, prove the route.**
- Secure your first source agreement in writing.
- Confirm your first buyer, prices, and terms in writing.
- Start collecting on a fixed schedule. Keep every record.
- Sell your first loads. Compare actual revenue and costs against your estimates — where were you wrong, and by how much?
- Do not buy major equipment yet. Rent, borrow, or share where you can.
- Decision point at day 60: is the route working? Are you hitting the pounds and the prices you projected? If not, what specifically is off — supply, price, transport, or time?

**Days 61–90: Decide — continue, adjust, or stop.**
- Review the full 90 days: total revenue, total costs, profit or loss, hours worked, and your effective hourly rate.
- Compare against your day-30 projections. Be honest about the gap.
- Decide: (a) continue and invest in the next step (a baler, a second route, a certification); (b) adjust — change the niche, the source mix, or the buyer; or (c) stop, having spent little and learned a lot. Stopping a business that does not work is a success, not a failure. The failure is continuing to fund a loss.
- Set your next 90-day targets if you continue: pounds per month, revenue per month, and the date of your next review.

### 7.3 Cash flow: the rule that kills more small recyclers than low prices

Profit and cash are different things. You can be profitable on paper and broke in practice if your money is tied up in stored material, in a slow-paying buyer, or in equipment you bought too soon. Three cash-flow rules:

1. **Keep a cash reserve.** Before you launch, set aside enough cash to cover at least two months of fixed costs with no revenue. If you cannot do that, you are launching too big — shrink the launch until you can.
2. **Sell regularly.** Do not let material pile up waiting for a better price while your bills come due. Regular sales mean regular cash.
3. **Do not finance the launch with high-interest debt.** A credit card or a high-interest loan turns a thin-margin business into a loss-making one before you start. If you need financing, talk to a local small-business lender or a community development financial institution, and get the terms in writing.

### 7.4 Growing — slowly, and only on proof

Growth in recycling usually means one of four things: more volume from the same sources, more sources, more processing (a baler, a dismantling bench), or a second material stream. Each step should be funded by profit from the step before, not by new debt. Before each growth step, re-run the break-even analysis with the new costs and the new volumes. If the growth step does not improve your margin or your break-even, do not take it yet.

Common growth mistakes: buying a baler before you have the volume to feed it; taking on a second material before the first one profits; signing a bigger lease before the route fills the space you already have; hiring help before you can pay yourself. Grow on proof, not on optimism.

### 7.5 Staying in business: the habits

- **Track prices weekly.** A simple log of what each buyer paid, for each grade, each week. After six months you will see patterns no article can give you.
- **Review your numbers monthly.** Revenue, costs, profit, pounds moved, hours worked, effective hourly rate. If your hourly rate is below what you could earn elsewhere, the business needs to change — higher prices, better sources, lower costs, or a different niche.
- **Keep learning the grades.** The operators who earn the most in recycling are the ones who can look at a load and know, accurately, what it is worth and who will pay the most for it. That knowledge compounds.
- **Keep your relationships.** Sources, buyers, and other recyclers are your business. Treat them well, pay fairly, and be honest when something goes wrong. Reputation in a local trade travels fast.
- **Know your stop rule.** Decide in advance what result would make you stop or change direction, and write it down. A stop rule made calmly, before you are emotionally invested, is worth more than any amount of optimism later.

### 7.6 A final word

Recycling is honest work. It takes material the world has thrown away and puts it back to use. It rewards people who are careful, reliable, and good at arithmetic — and it punishes people who skip the arithmetic. You now have the method: compare niches honestly, verify prices locally, count all five costs, check the permits first, start small, and decide at day 90 with real numbers in front of you.

Do the work in the workbook. Fill in the templates with real quotes. Make the calls. Then decide — with your eyes open — whether this business is right for you, in your place, right now. Whatever you decide, you will have decided on evidence, not on a headline. That is the whole point of this course.

---

## Appendix A: Glossary of Recycling Terms

- **Bale:** Material compressed into a dense, tied bundle for transport and sale. Baled material pays more than loose material.
- **Broker:** A middleman who buys recovered material from small operators and sells it to mills, smelters, or exporters.
- **Commodity price:** The market price for a recovered material, which changes with supply, demand, and global markets.
- **Contamination:** Unwanted material mixed into a load — food waste in plastic, batteries in e-waste, wet material in textiles. Contamination reduces value or causes rejection.
- **Ferrous metal:** Iron and steel. Magnetic, lower value per pound than non-ferrous.
- **Gaylord:** A large cardboard box on a pallet, used for storing and shipping loose or sorted material.
- **Grade:** A classification of material by type, purity, and quality. Higher grades pay more.
- **MRF (Materials Recovery Facility):** A large facility that receives, sorts, and processes mixed recyclables.
- **Non-ferrous metal:** Metals other than iron and steel — copper, aluminum, brass, stainless steel. Higher value per pound.
- **R2 / e-Stewards:** Industry certifications for electronics recyclers covering environmental, health, safety, and data-security practices.
- **Scale ticket:** The receipt from a weighbridge showing the weight of a load, used to calculate payment.
- **Tipping fee:** A fee charged to dispose of material at a landfill or transfer station.
- **Universal waste:** A category of hazardous waste — including batteries, lamps, and some electronics — subject to streamlined handling rules in many states.

## Appendix B: Your Pre-Investment Checklist

Before you spend money on equipment, a lease, or a vehicle for this business, confirm every item:

- [ ] I have chosen a niche using the comparison tool with real local quotes.
- [ ] I have at least one confirmed source and at least one confirmed buyer, both in writing.
- [ ] I have checked zoning for my operating location with the planning department.
- [ ] I have started the permit checklist and know which permits apply to me.
- [ ] I have run break-even at the low, middle, and high price, and the business survives at the low price.
- [ ] I have a cash reserve covering at least two months of fixed costs.
- [ ] I have insurance quotes and understand the cost.
- [ ] I have a separate business bank account (or a plan to open one before the first sale).
- [ ] I have a "we do not take" list and a data-handling plan (for e-waste).
- [ ] I have a written stop rule and a day-90 decision date.

If any box is unchecked, that is your next task — not a reason to buy equipment.

## Appendix C: Sources and How to Verify Current Prices

This course does not cite live market prices, because they change daily and any printed price would be out of date before you read it. To verify current prices:

- Call or visit at least three local buyers and ask for their current price list, in writing, for your grades.
- Check published commodity price reports (such as industry recycling price indexes) for the general direction of the market — but treat them as background, not as a quote.
- Track your own sale prices in the buyer outreach tracker, week by week. Your own history is your most reliable source.
- For permits and rules, contact your city or county planning department, your state environmental agency, and your state tax agency directly. Their websites list the current requirements and contact points.

---

## Disclaimers (repeated for clarity)

This course is general education, not legal, tax, financial, or investment advice. All prices, margins, costs, and revenue figures are illustrative examples for teaching the calculation methods, not promises of income or reports of current market prices. Recycling is a capital- and permit-heavy business with thin margins and volatile commodity prices. Verify all prices, permits, zoning, and rules locally before investing. Consult a local attorney and accountant before forming a business, signing a lease, or taking on debt. Results depend on your market, location, capital, and effort. Never invest money you cannot afford to lose.

*End of course manual.*
