# Customer Onboarding Guide — Pet Business Launchpad (PET-02)

**Welcome — and congratulations on deciding to build a real pet business.**

## What you have just bought

- **content.md** — the full 14-module course in written form (the complete course text).
- **workbook.md** — the companion workbook with exercises, worksheets, and trackers.
- **templates/** — four ready-to-use tools: the business-model comparison matrix, the business plan template, the startup budget planner (CSV spreadsheet), and the legal and insurance checklist.
- **sales-page.md** — a summary of the course for your reference.
- **cover.png** — the course cover image.

No physical product is shipped. All files are standard formats (Markdown and CSV) readable on any computer, tablet, or phone.

## What to do first (Day 1)

1. **Read the disclaimers** at the top of `content.md`. This course is education only — not legal, tax, financial, or veterinary advice. You will verify licensing, insurance, and regulations locally.
2. **Read the Introduction and Module 1.** Then do the Module 1 action step: write your one-paragraph picture of a good week in your business one year from now.
3. **Open the workbook** and start Section 1 (Know Yourself). Do not skip it — choosing the wrong model is the most expensive mistake in this course, and Section 1 prevents it.
4. **Set your launch date.** Pick a date eight weeks from today and write it in your calendar. The schedule below works backwards from that date.

## How to use the materials

- **Read one module, then do its workbook section, then move on.** The course only works if you do the exercises between lessons. Reading all 14 modules in a weekend without doing the work will not launch a business.
- **Use the templates as working documents.** Fill them in with your real numbers and real local research — not guesses. The comparison matrix (Module 4), the budget planner (Module 9), and the pricing build-up (Module 10) are the three documents that decide whether your business works.
- **Keep a notebook beside you.** Write down questions, ideas, and the names of people to contact. Bring the notebook to every customer interview and every supplier call.
- **Keep your files together.** Save your completed workbook and templates in one folder with the course files, and back them up.

## Suggested 8-week schedule

| Week | Modules | Work to complete |
|---|---|---|
| 1 | Modules 1–2 | Self-assessment (workbook Section 1); guardrail sentence; picture of a good week. |
| 2 | Modules 3–4 | Score all five models; complete the comparison matrix; choose your model; run a tie-breaker test if scores are close. |
| 3 | Module 5 | Competitor audit (5 competitors); interview 10 pet owners; write your market gap in one sentence. |
| 4 | Module 6 | Write your one-page business plan; show it to one honest person; fix the weakest line. |
| 5 | Modules 7–8 | Complete the legal and insurance checklist; get two insurance quotes; check licences with your local authority in writing. |
| 6 | Modules 9–10 | Complete the startup budget planner with real quotes; calculate runway; price every service with the build-up method. |
| 7 | Modules 11–12 | Set up booking and payment; write your first-ten plan; create your Google Business Profile; prepare your launch offer. |
| 8 | Module 13 | Launch week: confirm bookings, test systems, serve your first customers, ask for reviews and referrals. Start the first-30-days tracker. |

After launch, work through Module 14 and set your 90-day review date.

## How to get support

- **Questions about your download, file access, or course materials:** contact EightyTwenty support through the marketplace help page. Include your order number and the product SKU **PET-02**.
- **Questions about the course content:** re-read the relevant module and workbook section first — most questions are answered by doing the exercise. If you are stuck on a decision (which model, what price), work through the matrix or the pricing build-up with your real numbers before deciding.
- **Business, legal, tax, or insurance questions specific to your situation:** consult a licensed attorney, accountant, or insurance broker in your area. This course is education only and cannot advise on your individual circumstances.
- **Animal health questions:** contact a licensed veterinarian. Never diagnose or treat an animal yourself.

## A final note

You do not need to be perfect to launch. You need a chosen model, a written plan, a budget that works, prices that pay, insurance in force, and ten people to serve. If you follow the eight-week schedule and do the exercises, you will have all of those. Good luck — and go and get your first customer.

---

*Pet Business Launchpad — onboarding.md — SKU PET-02.*
