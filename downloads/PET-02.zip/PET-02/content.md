# Pet Business Launchpad: From Idea to Profitable Pet Business

**A 14-Module Course — Full Written Course Scripts**

---

## Important Disclaimers — Please Read First

This course is education only. It is not legal advice, tax advice, financial advice, or veterinary advice. Business licensing, insurance requirements, zoning rules, animal-care regulations, and tax obligations vary by city, county, state, and country, and they change over time. You must verify every legal, insurance, and regulatory requirement with the relevant local authority, a licensed attorney, a licensed insurance broker, and a qualified accountant before you start trading.

Nothing in this course guarantees income, profit, clients, or business success. The financial figures in this course are worked examples built from stated assumptions so you can learn the arithmetic of pricing, budgeting, and break-even analysis. They are not forecasts, promises, or reports of actual results. Your real costs, prices, and demand will differ. Do your own research and test your assumptions with small, low-cost steps before committing significant money.

Animal health and safety: this course covers business operations, not animal medicine. Never diagnose, treat, or advise on an animal's health condition. If an animal in your care shows signs of illness, injury, distress, or unusual behaviour, contact the owner and a licensed veterinarian promptly. Follow your local animal-welfare laws at all times. Pet care businesses must put animal safety ahead of profit in every decision.

No testimonials, reviews, certifications, or sales figures are claimed in this course. Any business names used in examples are fictional and illustrative.

---

## How to Use This Course

This document is the complete written course manual for the 14-module course. Each module is a full lesson in prose: read it, work through the exercises in the companion workbook, and complete the templates before moving on. The suggested pace is one to two modules per week over eight weeks (see `onboarding.md` for the full schedule). Keep a notebook beside you. Every module ends with an action step — do it before starting the next module. The course only works if you do the work between the lessons.

You will need: the companion workbook (`workbook.md`), the four templates in the `templates/` folder, a spreadsheet application, and access to your local council or city licensing website, your state's business registration portal, and at least three local competitors' websites or price lists.

---

## Table of Contents

- Module 1 — The Pet Industry and Your Place in It
- Module 2 — Know Yourself: Skills, Time, Money, and Risk
- Module 3 — The Five Models Compared: Grooming, Sitting, Training, Retail, and Products
- Module 4 — Choosing Your Model: The Decision Matrix in Action
- Module 5 — Your Local Market: Research That Takes One Weekend
- Module 6 — The Business Plan: One Page That Makes Real Decisions
- Module 7 — Legal Setup: Structure, Registration, Licences, and Names
- Module 8 — Insurance, Safety, and Protecting Animals in Your Care
- Module 9 — Startup Budget and Runway: What It Really Costs
- Module 10 — Pricing That Pays: Building Prices from Costs, Not Guesses
- Module 11 — Branding, Booking, and the Systems That Run the Business
- Module 12 — Getting Your First Ten Customers
- Module 13 — Launch Week and the First 90 Days
- Module 14 — Growing, Hiring, and Knowing When to Expand

---

## Introduction: Why Most Pet Businesses Stall Before They Start

People love pets, and that love makes the pet industry look easy from the outside. The customer seems obvious — every dog owner needs grooming, sitting, or training — and the work seems joyful. So aspiring owners do what feels productive: they compare business ideas for months, read forums late at night, price a few competitors, and design a logo. Then nothing launches, because the three questions that actually matter never got answered in order: which model fits my life, what will it really cost, and who exactly will pay me first?

This course answers those three questions in order, with numbers. You will not be asked to believe in a dream. You will be asked to score five business models against your skills, budget, and local market; to price your service from your real costs upward; to build a startup budget with a runway you can survive; and to go and get ten paying customers using a specific, repeatable plan. By the end you will have a chosen model, a written one-page plan, a budget, a price list, the legal and insurance checklists completed, and a launch date.

A note on honesty: a pet business is a service business first and a passion second. The parts that make it profitable — showing up on time, answering messages quickly, keeping records, charging enough, saying no to the wrong client — are unglamorous. If you can do the unglamorous parts consistently, the joyful parts take care of themselves. If you cannot, no amount of love for animals will save the business. This course is built for people willing to do both.

---

## Module 1 — The Pet Industry and Your Place in It

### What the industry actually looks like

The pet industry is large, resilient, and fragmented. Pet owners spend money in good years and bad, because spending on a pet feels like spending on family. That resilience is real, but it does not mean every pet business succeeds. The industry is also crowded at the entry level: dog walking, pet sitting, and home grooming have low barriers to entry, so a new business competes with neighbours, hobbyists, and established local operators from day one. The opportunity is not "pets are popular." The opportunity is to be the operator in your neighbourhood who is reliable, clearly priced, properly insured, and easy to book — because most competitors fail at one of those four things.

There are five broad ways to earn money from pets, and this course covers all five: grooming (hands-on care of an animal's coat, nails, and hygiene), sitting and walking (care in the owner's home or yours, plus exercise), training (teaching dogs — and their owners — behaviour and obedience), retail (selling pet products from a shop or online), and products (making and selling your own pet products, such as treats, toys, or accessories). Each model has a different cost structure, a different kind of customer, and a different daily life. Confusing them is the most common first mistake. A person who loves training dogs but opens a retail shop because a lease looked cheap has chosen the wrong daily life, and the business will feel like a burden within months.

### The four truths that govern every model

First, trust is the product. A pet owner hands you a family member. Price matters, but trust decides. Trust is built by being insured, by having clear policies, by communicating during the service, and by handling the first problem well. One handled problem — a late arrival you owned and fixed — builds more trust than ten perfect visits.

Second, local beats large. You are not competing with national chains on price or advertising. You are competing on being five minutes away, knowing the local park, remembering the dog's name, and answering the phone. Your market is a radius, not a country. Act accordingly: your marketing budget belongs in your neighbourhood, not on the internet at large.

Third, recurring revenue beats one-off sales. A grooming client who books every six weeks is worth far more than a one-time buyer. A walking client who books five days a week is a foundation. Design your business so the first sale naturally leads to the second: rebooking prompts, packages, subscriptions, and reminders are not extras — they are the business model.

Fourth, your time is the scarcest input. In service models, you cannot sell more hours than you have. That is why pricing matters so much, and why Module 10 exists. A business that charges too little does not fail dramatically; it fails quietly, by exhausting its owner. Price for the business you want in year two, not the hobby you can afford in month one.

### The pet owner as a customer

Pet owners buy in three modes. The first is routine: the regular groom, the daily walk, the weekly training class. Routine buyers want reliability and convenience above all. The second is problem-driven: the dog that barks, the cat that needs care during a holiday, the puppy that needs socialising. Problem buyers want competence and reassurance, and they will pay more for it. The third is emotional: the special treat, the birthday gift, the premium product. Emotional buyers want delight and are the least price-sensitive. Most pet businesses serve at least two of these modes. Know which ones yours serves, because each mode needs different marketing and different pricing.

### Action step — Module 1

Write one paragraph answering this question: "In one year, what does a good week in my pet business look like — how many hours am I working, what am I doing each day, and how much money comes in?" Keep it under 150 words and be specific. If you cannot picture the week, you are not ready to choose a model yet — Module 2 will fix that.

---

## Module 2 — Know Yourself: Skills, Time, Money, and Risk

### The honest inventory

Before you compare business models, compare yourself to the job. Every model demands a different mix of four things: hands-on animal skill, people skill, physical stamina, and administrative tolerance. Grooming demands stamina, patience with animals, and tolerance for repetitive physical work. Sitting demands reliability, comfort in strangers' homes, and the ability to follow instructions exactly. Training demands people skills more than dog skills — you are mostly training the owner. Retail demands buying, merchandising, and managing stock. Products demand making, packaging, and selling at scale. Score yourself honestly on each, from 1 (weak or unwilling) to 5 (strong and enthusiastic). A model that needs a 5 in an area where you score a 2 is a bad fit, however profitable it looks on paper.

Now the harder inventory: time and money. Write down the real numbers. How many hours per week can you give this business for the next six months, after your job, family, and rest? How much money can you invest without borrowing, and how much could you lose without harming your household? How many months can you go without the business paying you? These are not motivational questions; they are design constraints. A model that needs forty hours a week and $8,000 of equipment is not available to someone with ten hours and $800 — and that is fine, because a model that fits ten hours and $800 exists. The failure is choosing a model that does not fit and then blaming yourself when it does not work.

### Risk tolerance and the shape of your life

Risk is personal. Some people can tolerate an irregular income and a lease; others need the security of starting part-time alongside a job. There is no correct answer, but there is a correct match: start part-time and service-based if you need security; consider retail or a leased space only when you have proof of demand and a cash cushion. A useful rule: do not sign a lease, buy a van, or quit a job on the basis of a hope. Sign them on the basis of a waiting list, a full booking diary, or three months of revenue that already covers the cost.

Consider also the physical and emotional shape of the work. Grooming is hard on hands, back, and knees. Sitting means early mornings, late nights, and holidays when everyone else is off. Training means difficult conversations with owners who are frustrated with their dog. Retail means weekends and quiet weekdays. Products mean long stretches alone making and packing. Choose the daily life you can sustain for years, not the one that sounds best in a sentence.

### Your unfair advantage

Every successful small pet business has one: a skill, a connection, or a situation that competitors do not have. Maybe you are a veterinary nurse, a former groomer, or a dog trainer with a qualification. Maybe you live next to a park, own a suitable property, or know fifty dog owners through a club. Maybe you are simply the most reliable person in your neighbourhood. Name your advantage in one sentence and write it down. If you cannot name one, your first job is to build one — a short course, a certification, a volunteer role, or a visible track record — before you spend money on anything else. Advantages are built, not found.

### Action step — Module 2

Complete the self-assessment in the workbook (Section 1): score your skills, write down your real hours and money, and name your unfair advantage. Then write the sentence: "I will not choose a model that requires more than ___ hours a week or more than $___ to start." Fill in the blanks. That sentence is your guardrail for the rest of the course.

---

## Module 3 — The Five Models Compared: Grooming, Sitting, Training, Retail, and Products

This is the heart of the course. Below is a realistic comparison of the five models for a solo operator in a typical suburban or small-city market. The figures are worked examples using stated assumptions — mid-range prices, a solo operator, no employees — so you can see how the arithmetic differs between models. Your local prices and costs will vary; the method is what matters, and you will rebuild these numbers for your own area in Module 5.

### The comparison at a glance

| Factor | Grooming | Sitting / Walking | Training | Retail (shop / online) | Products (make & sell) |
|---|---|---|---|---|---|
| Typical startup cost (solo, lean) | $3,000–$8,000 | $300–$1,500 | $500–$3,000 | $5,000–$25,000+ | $500–$3,000 |
| Typical price per sale | $45–$90 per groom | $15–$25 per walk; $40–$75 per night sitting | $60–$120 per session; $200–$600 per course | $8–$40 average basket | $8–$30 per item |
| Gross margin (after direct costs) | 70–85% | 85–95% | 80–95% | 40–55% | 50–70% |
| Time per sale | 1.5–3 hours | 0.5–1 hour / 24 hrs | 1 hour | Minutes (but stocking hours) | Making + packing time |
| Repeat frequency | Every 4–8 weeks | Daily / weekly | Course, then top-ups | Weekly / monthly | Monthly |
| Hardest part | Physical stamina, skill | Reliability, holidays | Selling to owners | Stock & rent | Standing out |
| Ceiling (solo) | ~$60k–$90k revenue/yr | ~$40k–$70k revenue/yr | ~$50k–$90k revenue/yr | Highly variable | Highly variable |
| Best for | Hands-on, patient people | Reliable, flexible people | Confident communicators | Commercial, organised people | Creative makers |

### Model 1 — Grooming

Grooming is the highest-skill service model and the hardest to enter without training, but it has the strongest repeat pattern: a dog that needs grooming in January needs it again in March. A full groom for a medium dog at $65, taking two hours including bathing, drying, clipping, and nails, is typical. A solo groomer doing five grooms a day, five days a week, at an average of $60, grosses $1,500 a week — but five grooms a day is a heavy physical load, and most solo groomers sustain three to four a day. At four grooms a day, five days a week, 48 working weeks a year, revenue is $57,600. Direct costs (shampoo, blades, electricity, laundry) run roughly 10–15%, leaving strong gross profit — but the costs that matter are the hidden ones: equipment replacement (clippers, blades, tables), training, insurance, and the physical toll.

Startup costs, lean home-based setup: a professional table ($200–$400), clippers and blades ($300–$600), dryer ($200–$500), bath and plumbing if needed ($500–$2,000), scissors and tools ($200–$400), shampoos and consumables ($150–$300), insurance ($400–$800/year), and a basic booking system ($0–$300/year). Total: roughly $3,000–$8,000. A mobile grooming van is a different business: $30,000–$80,000 for the vehicle and fit-out. Do not buy a van until a home or salon base is full.

The real question for grooming is not money but body and skill. Can you stand for six hours, lift a 30 kg dog, and stay patient with a nervous animal at 4 p.m. on a Friday? Can you invest in proper training first — a recognised grooming qualification is the single best investment in this model, because it raises both your prices and your safety. Grooming rewards the skilled and punishes the rushed: a bad cut or a nicked dog travels fast by word of mouth.

### Model 2 — Sitting and Walking

Sitting and walking has the lowest startup cost and the fastest path to first revenue, which is why it is the most popular entry point. You need insurance, a phone, reliable transport, and a way to take bookings. Startup: insurance ($300–$600/year), a booking and payment tool ($0–$300/year), keys and lockbox system ($50–$150), basic supplies ($100–$200), and local marketing ($100–$300). Total: roughly $300–$1,500.

The arithmetic is volume arithmetic. A 30-minute group walk at $18, with four dogs, earns $72 an hour — good money. A solo walk at $20 earns $20 an hour before travel. The difference between a profitable walking business and an exhausting one is route density: four dogs in one neighbourhood beats eight dogs spread across a town. Sitting is different again: house sitting at $55 a night for one household, or boarding in your own home at $40–$60 per dog per night, can be lucrative, but you are on call 24 hours and your home becomes the workplace.

Worked example: a walker doing three group walks a day (four dogs each at $18), five days a week, 48 weeks a year, grosses $51,840. That is a full, physical working day with travel, messages, and admin on top. A sitter boarding two dogs a night at $50, five nights a week, 48 weeks, grosses $24,000 — but it can combine with walking in the daytime. The honest ceiling for a solo sitter/walker is set by hours and by trust: owners book the person, not the brand, so growth means hiring, and hiring means managing other people's reliability. That is Module 14.

### Model 3 — Training

Training has the highest hourly rate of the service models and the lowest direct costs — your knowledge is the product. A one-to-one session at $80–$100 for an hour, or a six-week group course at $180–$250 per dog with eight dogs in a class, are typical structures. A group class of eight dogs at $200 each is $1,600 for six hours of teaching plus preparation — strong economics, but only if you can fill the class, hold the room, and teach owners who learn at different speeds.

Startup: training or behaviour qualifications ($500–$2,500 depending on route), insurance ($300–$600/year), venue hire for classes ($30–$60 per hour, often only paid when classes run), treats and equipment ($100–$300), and marketing ($100–$300). Total: roughly $500–$3,000. The real investment is time spent learning: dogs are the easy part; the job is changing human behaviour, handling frustrated owners with kindness, and setting expectations honestly. Never promise a "fixed" dog. Ethical trainers sell progress, management, and skills — not guarantees.

Worked example: a trainer running two group courses a week (eight dogs at $200, six-week courses, running 40 weeks a year) plus four one-to-one sessions a week at $90. Course revenue: two courses running in rotation is roughly $3,200 per six-week cycle; over 40 weeks that is about $21,000. One-to-one: 4 × $90 × 48 weeks = $17,280. Combined revenue is around $38,000–$45,000 for roughly 20–25 teaching hours a week plus preparation, marketing, and admin. Trainers who add online courses, puppy classes, and follow-up packages earn more — but the core lesson is that training income is lumpy: courses fill and empty in cycles, so you need a pipeline, not just a diary.

### Model 4 — Retail

Retail looks simple — buy products, sell them for more — and is the hardest model to make profitable as a small operator. The margin math is unforgiving. If you buy a bag of food for $30 and sell it for $45, your gross margin is 33%. Rent, utilities, staff, and shrinkage come out of that margin. A shop needs high turnover to survive, and high turnover needs footfall, which needs a good location, which costs rent. Online retail removes rent but adds shipping, platform fees, and advertising costs, and you compete with large retailers on price.

Startup, small shop: first stock order ($3,000–$10,000), shop fit-out and shelving ($1,000–$5,000), deposit and first rent (varies enormously — $1,000–$5,000+ a month in many areas), till and payment system ($300–$800), insurance ($500–$1,000/year), and licences. Total: $5,000–$25,000 and up, before you have sold anything. Online-only retail is cheaper to start ($1,000–$3,000 for stock, a website, and packaging) but harder to get noticed: you are one listing among millions.

Worked example: a small shop with $12,000 of monthly sales at a 45% gross margin makes $5,400 gross profit a month. Rent $1,800, utilities $300, insurance $80, payment fees $300, and miscellaneous $200 leave $2,720 before the owner's pay and tax. That is a viable business — but it needs $12,000 of sales every month, which needs either a strong location or a loyal local following. Retail suits people who love buying, merchandising, and community-building, and who understand that the shop is the marketing: events, tastings, and local partnerships drive the footfall that pays the rent.

### Model 5 — Products (make and sell your own)

Making your own products — treats, toys, accessories, grooming products — is the most creative model and the hardest to scale profitably. The unit economics can look attractive: a bag of dog treats that costs $2.50 in ingredients and packaging and sells for $9 has a 72% gross margin. But that margin must pay for your making time, your selling time, market stalls, shipping, platform fees, and the cost of finding each customer. A maker who spends three hours baking, packing, and selling 40 bags earns $260 gross profit for three hours plus the selling time — good as a side income, poor as a full-time wage unless volume grows.

Startup: ingredients and packaging ($200–$600 for a first run), food-hygiene or product-safety compliance (varies — treats may need a licensed kitchen or registration; check local rules), labelling and branding ($100–$400), a selling channel (market stall fees $30–$100 per market, or an online shop), and insurance ($300–$600/year). Total: roughly $500–$3,000. The critical questions are regulatory — pet food and treats are regulated in most jurisdictions, and cosmetics for animals have their own rules — and commercial: who buys repeatedly, and how do you reach them without spending all your margin on advertising?

Worked example: a treat maker selling 300 bags a month at $9 ($2,700 revenue), with ingredient and packaging costs of $750, platform and payment fees of $270, and market stall fees of $200, keeps $1,480 gross profit before their own time. If making and selling takes 60 hours a month, that is about $24 an hour — respectable, but only if the 300 bags actually sell every month. Products become a real business when they reach wholesale (selling to shops at $5 a bag, in volume) or subscriptions, not when they sell one bag at a time at a market.

### Action step — Module 3

In the workbook, score each of the five models 1–5 on: fit with your skills, fit with your hours, fit with your money, how much you would enjoy the daily work, and local demand as you currently understand it. Do not decide yet. Module 4 turns those scores into a decision.

---

## Module 4 — Choosing Your Model: The Decision Matrix in Action

### How the matrix works

The business-model comparison matrix (in `templates/`) turns gut feeling into a score. You rate each model from 1 to 5 on eight criteria, then multiply by a weight that reflects what matters most to you. The weights must add up to 100. A suggested starting set: skill fit (20), enjoyment of daily work (20), startup cost fit (15), income potential (15), time fit (10), local demand (10), speed to first income (5), and growth potential (5). If money is your binding constraint, raise the weight on startup cost fit. If you hate admin, raise the weight on enjoyment. The weights are yours — but write them down before you score, so you cannot quietly change them to favour the model you already like.

Score honestly. A 5 in skill fit means you could do the work well tomorrow. A 3 means you could learn it in a few months. A 1 means you would be starting from zero and do not enjoy learning it. Enjoyment is not a soft criterion: a business you dislike doing will be abandoned, and abandonment is the most expensive outcome of all.

### Worked example: Maya chooses sitting

Maya is 34, works part-time, has $1,200 to invest, 20 hours a week, no grooming or training qualifications, but ten years of looking after friends' dogs and a reputation as the reliable neighbour. Her weights: skill fit 20, enjoyment 20, startup cost 15, income 15, time 10, demand 10, speed 5, growth 5.

Her scores: grooming — skill 1, enjoyment 3, cost 1, income 4, time 2, demand 4, speed 2, growth 3. Weighted total: (1×20)+(3×20)+(1×15)+(4×15)+(2×10)+(4×10)+(2×5)+(3×5) = 20+60+15+60+20+40+10+15 = 240 out of 500. Sitting — skill 5, enjoyment 4, cost 5, income 3, time 4, demand 5, speed 5, growth 3. Total: 100+80+75+45+40+50+25+15 = 430. Training — skill 2, enjoyment 3, cost 4, income 4, time 3, demand 3, speed 2, growth 4. Total: 40+60+60+60+30+30+10+20 = 310. Retail — skill 2, enjoyment 2, cost 1, income 3, time 2, demand 3, speed 1, growth 3. Total: 40+40+15+45+20+30+5+15 = 210. Products — skill 3, enjoyment 4, cost 4, income 2, time 3, demand 2, speed 2, growth 3. Total: 60+80+60+30+30+20+10+15 = 305.

Maya's winner is sitting, by a wide margin, and the matrix tells her why: it fits her skills, money, and time today. She can start sitting now, build a client base and a cash cushion, and add training qualifications later if she wants. The matrix also tells her what not to do: grooming, which she likes the idea of but cannot do yet, and retail, which her budget cannot carry.

### Worked example: Daniel chooses grooming

Daniel is 28, single, has $7,000 saved, 45 hours a week, and has just completed a grooming qualification. He enjoys hands-on work and dislikes selling. His weights favour skill fit and income. His scores put grooming at 445, training at 320, sitting at 330, retail at 250, and products at 280. Grooming wins clearly — and the matrix confirms that his qualification is worth money: without it, grooming would have scored near the bottom. The lesson is that the matrix rewards the model you are already prepared for. If your winner is a model you are not prepared for, the correct response is usually to get prepared — take the course, get the qualification, save the money — rather than to launch unprepared.

### When the scores are close

If two models are within 30 points, you have a genuine choice. Break the tie with a test, not a debate. Spend two weeks doing the work in miniature: walk a neighbour's dog for money, assist a groomer for a day, run a free training taster, or sell twenty bags of treats at a market. The model that leaves you energised at the end of the test is the one to choose. If both leave you flat, neither is right — revisit Module 2.

A final warning: do not choose two models at once. "Grooming and training and a little shop" is three businesses, not one, and each needs its own marketing, pricing, and diary. Choose one, launch it, fill it, and only then add a second service to the same customers. The second service is far easier to sell to people who already trust you.

### Action step — Module 4

Complete the matrix in `templates/business-model-comparison-matrix.md` with your own weights and scores. Write your chosen model in one sentence: "I am launching a ___ business because ___." If you cannot write that sentence confidently, repeat the tie-breaker test before continuing.

---

## Module 5 — Your Local Market: Research That Takes One Weekend

### Your market is a radius

Your market is not "the pet industry." It is the pet owners within a distance you can serve profitably — usually a 15–30 minute drive, or a walkable neighbourhood for walking services. Draw that radius on a map. Inside it, count roughly how many households own pets. You do not need exact census data: local veterinary practices, pet shops, parks, and dog-walking groups give you a sense of density. A suburb with three vets, two pet shops, and a busy dog park is a strong market. A rural area with one vet and long distances between homes is a thin market — and thin markets favour mobile or home-based services, not shops.

### The competitor audit

Find five direct competitors inside your radius. For each, record: services offered, prices, opening hours, how to book, whether they are insured (do they say so?), reviews and ratings, and what customers praise or complain about. You can gather almost all of this from websites, Google listings, and social media in a few hours. Then find the gap. Common gaps: no evening or weekend availability, slow replies, no online booking, no prices shown, no insurance mentioned, no service for large or nervous dogs, no cat sitting, or no service in a particular neighbourhood. Your gap is your opening. Do not copy the market leader; serve the customers they are ignoring.

Worked example: in one town, three groomers all close at 5 p.m. and none take bookings online. A new groomer offering online booking and one late evening a week until 8 p.m. captures the commuters the others cannot serve — without competing on price at all. In another area, every dog walker takes group walks, and nobody offers solo walks for reactive dogs. A solo-walk specialist charging $30 instead of $18 serves a smaller market at a higher price with less competition. Gaps like these are worth more than a clever logo.

### Talking to real customers

Numbers from the internet are not enough. Talk to ten pet owners in your radius — at the park, at the vet waiting room, in a local Facebook group (with the group's permission), or among friends. Ask four questions: What pet service do you use now? What frustrates you about it? What would you pay for a better version? Would you try a new local provider, and what would convince you? Write the answers down verbatim. If seven of ten say they cannot find a sitter over Christmas, you have found a seasonal opportunity. If five say they would pay more for someone who sends photo updates, you have found a service feature worth building in from day one.

### Demand test before you spend

Before spending serious money, run a demand test. Create a simple booking page or social media page with your service, prices, and area, and see whether anyone enquires. Post in local groups, put up a notice at the vet or pet shop (with permission), and tell everyone you know. Ten genuine enquiries in two weeks is a strong signal. Zero enquiries after two weeks of real effort is also a signal — either the offer, the price, or the area is wrong, and it is far cheaper to learn that now than after a lease is signed. Adjust one thing at a time: price, area, or message. Never adjust all three at once, or you will not know what fixed it.

### Action step — Module 5

Complete the competitor audit table in the workbook (Section 3) for five competitors, interview ten pet owners, and write down your gap in one sentence: "The gap in my area is ___." That sentence goes into your business plan in Module 6.

---

## Module 6 — The Business Plan: One Page That Makes Real Decisions

### Why one page

Most business plans fail because they are written to impress a bank and never read again. Your plan has a different job: to make decisions when you are tired, busy, or tempted by a distraction. One page is enough if it answers the questions that matter: who you serve, what you sell, what you charge, what it costs, how customers find you, and what success looks like in 90 days. If a plan cannot fit on one page, it contains decoration. Use the full template in `templates/business-plan-template.md` — it expands each section — but keep the one-page summary on your wall.

### The eight sections

1. **The business in one sentence.** "I run a home-based dog grooming business for medium and large dogs in [area], open Tuesday to Saturday."
2. **The customer.** Who exactly? "Busy professionals within 20 minutes who own medium or large dogs and want a reliable six-weekly groom with online booking."
3. **The offer.** What services, at what prices, in what packages? List them.
4. **The gap.** The unmet need from Module 5, in one sentence.
5. **The money.** Monthly revenue target, monthly costs, and the break-even point (Module 9 and 10 build these numbers).
6. **How customers find you.** Your three main channels (Module 12), with a weekly action for each.
7. **The first 90 days.** Three milestones with dates: launch date, first ten customers, first month of target revenue.
8. **What you will not do.** The distractions you are saying no to for the first six months — the second service, the shop, the product line. Write them down so you can recognise them when they appear.

### Worked example: a one-page plan

Business: "Paws & Clippers — home-based grooming for medium and large dogs in Northfield, Tuesday to Saturday." Customer: "Owners within 20 minutes who work full-time and want a reliable groom every six weeks, booked online." Offer: "Full groom $65 (medium), $80 (large); bath and tidy $40; nails $15. Rebook at checkout for six weeks ahead." Gap: "No local groomer offers online booking or evenings; commuters cannot book." Money: "Target $3,200 a month revenue by month four; costs $850 a month; break-even at 14 grooms a month." Customers: "Google Business Profile, local Facebook group, vet noticeboard; one post a week, one referral ask a week." First 90 days: "Launch 1 June; ten regular clients by 30 June; $3,200 month by 30 August." Will not do: "No mobile van, no training classes, no retail shelf until grooming is full."

That plan fits on one page, and every line is a decision. When someone offers a cheap van in month two, the plan says no. When a customer asks for cat grooming, the plan says no for now. That is the plan working.

### Action step — Module 6

Write your one-page plan using the template. Show it to one honest person — a friend, a fellow pet professional, or a small-business adviser — and ask them to point out the weakest line. Fix that line before continuing.

---

## Module 7 — Legal Setup: Structure, Registration, Licences, and Names

*Education only — this module explains the kinds of steps that commonly apply. It is not legal advice. Requirements vary by location and change over time. Verify everything with your local authority and a licensed professional.*

### Choose a structure

In most places you will trade as one of three things: a sole trader (you are the business), a partnership (you and one or more others), or a limited company / LLC (a separate legal entity). A sole trader setup is the simplest and cheapest to start, but you are personally responsible for the business's debts. A limited company or LLC separates your personal assets from the business, but it costs more to set up and brings filing and accounting duties. There is no universally right answer; there is a right answer for your risk, your income, and your location. Many pet businesses start as sole traders and incorporate later when revenue and risk grow. Talk to an accountant before you decide — a 30-minute consultation is cheaper than fixing the wrong structure later.

### Registration, tax, and record-keeping

Register your business with the relevant authority, register for tax, and — if your turnover reaches the threshold in your jurisdiction — for sales tax or VAT. Keep records from day one: every invoice, every receipt, every expense, every client payment. Use a separate bank account for the business, even if the law does not require it: mixing personal and business money is the single most common bookkeeping disaster for new owners, and it makes tax time miserable. Use simple accounting software or a well-kept spreadsheet, and set aside a percentage of every payment for tax (a common starting habit is 20–30%, adjusted on your accountant's advice). If you hire anyone, even casually, you take on employer duties — payroll, tax withholding, and workplace rules. Get advice before your first hire, not after.

### Licences, zoning, and animal-care rules

This is the part most new owners skip, and it is the part that can close a business. Check, in writing, with your local council or city authority: Do you need a licence to board animals in your home? To run a grooming business from home? To operate a kennel or daycare? Are there limits on the number of animals you can keep? Does your home's zoning allow business visitors? Does your lease or mortgage allow it? Do you need planning permission for signage or a converted outbuilding? Animal boarding and daycare are licensed activities in many areas, with inspections covering space, ventilation, hygiene, exercise, and record-keeping. Grooming from home may need no licence in one area and a business licence in another. Never assume. A five-minute phone call or a page on the council website is the difference between a legal business and a fine.

If you make and sell pet food or treats, check food-safety and labelling rules: you may need to register as a food business, follow hygiene rules, label ingredients and allergens, and keep traceability records. If you sell grooming products or cosmetics, check product-safety and labelling rules. These rules exist to protect animals and customers — treat compliance as part of the product, not as red tape.

### Names, brands, and insurance of the name

Choose a business name that is easy to spell, easy to say on the phone, and available as a domain and on social media. Check that no other business in your area or sector already uses it, and check trademark registers if you plan to grow beyond your town. Register the name where required. Avoid names that promise what you cannot deliver ("Best", "Guaranteed", "Vet-approved" unless a vet has actually approved it) and names that limit you ("Northfield Dog Walking" is a problem if you later add grooming or move). Your name should work on a van, a website, and a spoken recommendation.

### Contracts and policies

Every service business needs written terms: what is included, what it costs, when payment is due, what happens if the owner cancels, what happens if you cancel, what happens if an animal is ill, and who is responsible for what. Keep them short, plain, and fair. A one-page service agreement and a booking confirmation that links to your terms is enough to start. Never work without the owner's written consent for the service, and keep vaccination and veterinary contact details on file for every animal in your care. If you use photos of clients' pets on social media, get written permission first.

### Action step — Module 7

Complete the legal checklist in `templates/legal-insurance-checklist.md`: structure chosen, registration done, tax registered, licences checked with the council in writing, name checked, terms written. Do not take paying customers until the boxes that apply to you are ticked or you have professional advice saying they do not apply.

---

## Module 8 — Insurance, Safety, and Protecting Animals in Your Care

### Why insurance is not optional

Insurance is the cost of being trusted with someone's pet. A single accident — a dog that escapes, a clipper cut that needs a vet, a client's house key lost, a customer who slips on your premises — can cost thousands. Without insurance, that cost comes from your pocket and can end the business. With insurance, it is a claim. Customers increasingly ask whether you are insured before they book; being able to say yes, and to show proof, is a selling point, not just a cost.

### The cover to ask a broker about

Talk to a licensed insurance broker who understands pet businesses; do not buy a generic policy and assume it covers you. Ask about: public liability (injury or damage to third parties), professional indemnity (claims that your advice or service caused loss), care, custody, and control cover (injury to, or loss of, animals in your care — this is the cover that matters most and is often excluded from standard policies), property and equipment cover, business interruption, and, if you drive for work, the right motor cover. If you employ anyone, employers' liability is usually a legal requirement. If you board animals in your home, check whether your home insurance still applies — many home policies exclude business use, and you may need a separate or amended policy.

Worked example of why it matters: a dog in your care slips its lead and is hit by a car. Veterinary treatment costs $2,400. With care, custody, and control cover, the insurer handles the claim (subject to your excess and policy terms). Without it, you pay $2,400, lose the client, and face a difficult conversation about who is responsible. Insurance does not remove the emotional weight of an accident — but it removes the financial catastrophe, which is its job.

### Safety systems that prevent claims

Insurance pays for accidents; systems prevent them. Build these habits from day one: meet every animal before the first booking and record temperament, health, and handling notes. Keep vaccination records on file and require them where your policy or local rules do. Use secure leads, harnesses, and enclosures; check gates and fences before every session. Never leave animals unsupervised with unfamiliar animals. Keep a first-aid kit, know basic pet first aid (take a recognised course — it is a genuine selling point), and keep the owner's vet details and an emergency vet number in your phone and on paper. Record every incident, however small, in writing, with the date, what happened, and what you did. If something goes wrong, tell the owner promptly and honestly, in person or by phone, not by text — honesty after an accident preserves more trust than silence ever will.

### Health, hygiene, and welfare

Clean equipment between animals. Wash bedding and towels regularly. Store food, treats, and medicines as the owner instructs, and never give medication without written instruction. Watch for signs of stress, overheating, or illness — excessive panting, lethargy, vomiting, diarrhoea, limping, or unusual behaviour — and act on them: stop the activity, move the animal to a safe, cool place, contact the owner, and seek veterinary advice. Know your limits: if an animal is aggressive, severely anxious, or medically complex, refer the owner to a specialist or a vet rather than taking the booking. Turning away the wrong client is a professional decision, not a failure.

### Safeguarding and the owner's home

Sitters and walkers enter people's homes. Treat that trust as sacred: never share alarm codes or key locations, never bring unapproved people into a client's home, lock up exactly as instructed, and report anything unusual (a leak, a broken window, an alarm) immediately. Keep keys labelled by code, not by address, and store them securely. If you use staff, the same rules apply to them, and you are responsible for enforcing them.

### Action step — Module 8

Get at least two insurance quotes from brokers who cover pet businesses, compare what is actually covered (not just the price), and buy the cover before your first paying customer. Complete the insurance section of the legal checklist and file your policy documents where you can find them in under a minute.

---

## Module 9 — Startup Budget and Runway: What It Really Costs

### The three buckets

Every startup budget has three buckets: one-off setup costs (equipment, training, branding, licences), monthly running costs (insurance, phone, booking software, marketing, consumables), and your living costs while the business grows (rent, food, bills — the money you need to live). Most new owners budget the first bucket, guess the second, and forget the third. The third is the one that kills businesses: a business can be profitable on paper and still fail because its owner cannot afford to wait for the money to arrive.

### Worked example: a lean grooming startup budget

One-off costs: grooming table $300, clippers and blades $450, dryer $350, bath and plumbing $1,200, scissors and tools $300, initial consumables $200, qualification course $1,200, branding and website $400, licences and registration $150. One-off total: $4,550. Monthly running costs: insurance $60, booking software $25, phone $40, consumables $120, marketing $100, utilities share $80, accounting $50. Monthly total: $475. If the owner needs $2,200 a month to live and has no other income, the business must cover $2,675 a month before it pays its owner at all. At $65 per groom, that is 42 grooms a month — about 11 a week — just to break even on living costs plus running costs. That number tells you the truth: this groomer needs roughly three months of building to reach break-even, and needs savings to survive those three months.

### Worked example: a lean sitting startup budget

One-off costs: insurance (first year) $450, booking software $150, keys and lockbox $100, supplies $150, branding and website $250, first-aid course $120, marketing $200. One-off total: $1,420. Monthly running costs: insurance share $38, software $20, phone $40, fuel $150, marketing $60. Monthly total: $308. Living costs $2,200. Total monthly need: $2,508. At $20 per walk, that is 126 walks a month — about 32 a week, or six to seven a day. At $50 a night for boarding two dogs, it is 51 nights a month — impossible alone. The lesson is not that sitting cannot pay; it is that a sitter needs a mix — group walks (four dogs at $18 is $72 an hour) plus boarding plus holiday sitting — and needs to build density before the numbers work. The budget forces that realisation before the launch, when it can still change the plan.

### Runway: how long you can survive

Runway is your savings divided by your monthly shortfall. If you have $6,000 saved, your monthly living and business costs are $2,700, and the business brings in $1,200 a month in the early months, your shortfall is $1,500 a month and your runway is four months. If the business does not reach $2,700 a month by month four, you run out of money. That is not a motivational statement; it is arithmetic, and it is the most important number in your plan. Build your launch around extending runway: start part-time while keeping other income, keep monthly costs low, and take deposits or prepayments where appropriate.

### The budget planner

Use `templates/startup-budget-planner.csv` to build your own version of these examples. Enter your real one-off costs, your real monthly costs, your real living costs, and your prices. The sheet calculates your monthly break-even in sales and your runway in months. Change one number at a time and watch what moves. If the break-even number frightens you, that is the sheet doing its job: lower your costs, raise your prices, or choose a model with better economics — before you spend the money.

### Action step — Module 9

Complete the startup budget planner with real quotes (not guesses) for your five largest costs. Write down your runway in months. If it is under three months, change something — lower costs, keep other income longer, or start smaller — until it is at least three.

---

## Module 10 — Pricing That Pays: Building Prices from Costs, Not Guesses

### The mistake almost everyone makes

Most new pet businesses set prices by copying a competitor and knocking off a few dollars. That is how you inherit someone else's cost structure, someone else's mistakes, and a price that may not cover your costs at all. Your competitor might own their premises outright, have no insurance, or be subsidising the business from a partner's income. Their price tells you nothing about your costs. Build your price from your costs upward, then check it against the market — not the other way around.

### The pricing build-up, step by step

Start with your direct cost per service: the consumables, travel, and time used by one sale. Then add your share of monthly running costs: divide your monthly running costs by the number of sales you expect to make in a month. Then add your pay: the hourly rate you need to earn, multiplied by the hours the service takes (including travel, messages, and admin — not just the face-to-face hour). Then add tax provision and a profit margin for reinvestment. The total is your minimum viable price. Charge less than that and you are paying the customer to use your business.

### Worked example: pricing a groom

A full groom for a medium dog. Direct costs: shampoo, conditioner, and consumables $4, blade wear and laundry $2, total $6. Monthly running costs $475, expected 60 grooms a month: $7.92 per groom. Time: 2 hours of grooming plus 30 minutes of messages, booking, and clean-up — 2.5 hours. Target pay: $30 an hour (a professional rate that allows for tax, holidays, and sick days — not a minimum wage). Labour: 2.5 × $30 = $75. Subtotal: $6 + $7.92 + $75 = $88.92. Add a 10% provision for tax and a small reinvestment margin, and the price needs to be around $95–$100. But the local market charges $55–$70. What do you do? You have three honest options, and only three: reduce the time the groom takes (better equipment, better systems), reduce your running costs, or accept a lower hourly rate for a period while you build — and name the date when the rate rises. What you must not do is charge $55, work 2.5 hours, and wonder why you are exhausted and broke. The arithmetic does not care about your good intentions.

Now the same groom, done well: an experienced groomer takes 1.5 hours including admin, uses $5 of consumables, and does 80 grooms a month, so the running-cost share falls to $5.94. Labour: 1.5 hours × $30 = $45 (plus 30 minutes admin at $30 = $15, total $60). Total: $5 + $5.94 + $60 = $70.94. At $75, the groom is viable. The difference between the two examples is not luck — it is speed, volume, and systems. Pricing reveals what you need to improve.

### Worked example: pricing a walk

A 30-minute group walk with four dogs at $18 each earns $72 for the hour including travel and admin. Direct costs: treats and bags $1, fuel share $3, total $4. Running-cost share: monthly costs $308, expected 120 walks a month, $2.57 per walk. Labour: one hour at $30 = $30. Cost per walk (the group of four): $4 + $2.57 + $30 = $36.57. Revenue $72. Gross profit $35.43 per walk — a healthy margin, because the group model multiplies revenue per hour. Now the solo walk: one dog at $22, same hour, same costs. Revenue $22, costs $36.57 — a loss of $14.57 per walk. That is why solo walks must be priced far higher ($35–$45) or offered only as a premium service for dogs that cannot walk in groups. The numbers make the decision for you.

### Pricing structures that work

Use these structures, not flat discounts: tiered pricing (small/medium/large; 30/60-minute walks), packages (buy five walks, get the sixth at a discount — paid upfront, which improves cash flow), subscriptions (a monthly plan for regular clients, which smooths income), and add-ons (nail trim, teeth, de-shedding, photo updates) that raise the average sale without raising the headline price. Raise prices once a year, in a planned way, with notice to existing clients — a 5% annual rise is normal business, not greed, and clients who value you will stay. Never compete on being cheapest: the cheapest provider attracts the most price-sensitive customers and has the least money to serve them well.

### Action step — Module 10

Price every service you plan to offer using the build-up method in the workbook (Section 6). Compare each price to three competitors. For any price below your minimum viable price, write down which of the three honest options you are choosing — and the date your price rises.

---

## Module 11 — Branding, Booking, and the Systems That Run the Business

### Branding is a promise, not a logo

Your brand is what a customer expects before they book and what they remember after. A good pet-business brand promises three things: safe, reliable, and easy. Everything else — colours, fonts, a logo — is decoration in service of that promise. Choose a name and a look that a customer can remember after hearing it once, that reads clearly on a phone screen, and that looks professional on a van, a card, and an invoice. Then be consistent: the same name, colours, and tone everywhere. Inconsistency reads as unreliability, and unreliability is the one thing a pet owner cannot tolerate.

Your tone matters more than your design. Write like a calm, competent professional who loves animals: clear, warm, specific. "Your dog will be walked at 10 a.m., with two other friendly dogs, in the riverside park, and you will receive a photo when we are home" is branding. "We love pets!!!" is not.

### Booking and payment systems

Customers book the business that is easiest to book. From day one, offer: a way to enquire and book without phoning (an online form or booking tool), clear prices, clear availability, and a way to pay by card or bank transfer. Take a deposit or full prepayment for first bookings — it reduces no-shows and proves the customer is serious. Send a confirmation with the date, time, address, price, and what to bring. Send a reminder the day before. After the service, send a short update with a photo and a rebooking prompt. This sequence — confirm, remind, update, rebook — is the system that turns one booking into a regular client.

Choose tools you will actually use: a simple booking tool, a payment link or invoicing tool, a calendar, and a messaging channel. Do not buy expensive software before you have customers. A spreadsheet, a calendar, and a payment link serve the first fifty clients perfectly well. Upgrade when the admin takes more than an hour a day — that is the signal the system, not your effort, needs to change.

### Records that protect you

Keep a record for every animal: owner details, vet details, vaccination status, health notes, temperament, feeding and medication instructions, and consent. Keep a record for every booking: date, service, price, payment, and any incident. Keep a record for every expense: date, supplier, amount, receipt. These records are your memory, your legal protection, and your tax return. Spend ten minutes at the end of every working day updating them. The businesses that fail at admin do not fail in a dramatic moment; they fail in a slow accumulation of lost messages, forgotten bookings, and missing receipts.

### The weekly rhythm

A service business runs on a weekly rhythm. A suggested one: Monday — admin, messages, and the week's bookings confirmed. Tuesday to Friday — service delivery, with photos and updates sent the same day. Saturday — service delivery plus one marketing action (a post, a referral ask, a noticeboard check). Sunday — rest, plus 30 minutes planning the next week. Protect the rhythm. A business without a rhythm becomes a business that reacts to whatever is loudest, and the loudest thing is rarely the most important.

### Action step — Module 11

Write your booking sequence (enquiry to rebooking) in six steps, choose your booking and payment tools, and set up your client record sheet. Test the whole sequence on a friend as a pretend customer before you launch.

---

## Module 12 — Getting Your First Ten Customers

### The principle: ten people who trust you

Your first ten customers are not a marketing campaign; they are ten relationships. Each one needs to be won individually, served excellently, and asked to help you find the next one. Ten happy customers who each refer one person give you twenty. A hundred strangers who saw an advert give you nothing if none of them books. Start with people, not platforms.

### The five channels, in order

1. **Your existing network.** Tell everyone you know — friends, family, neighbours, colleagues, the dog park regulars — that you are launching, what you do, and who it is for. Be specific: "I am launching a dog grooming business in Northfield for medium and large dogs, from 1 June, $65 a groom, online booking" is a message people can pass on. "I am starting a pet business" is not.
2. **Local groups and noticeboards.** Post in local community groups (with permission and within the rules), and put a clear, professional notice at vets, pet shops, cafés, and community boards. Offer something useful, not just an advert: a free nail trim with a first groom, a free meet-and-greet walk, a short guide to choosing a groomer.
3. **Google Business Profile.** Create a free profile with your services, area, hours, photos, and prices. Ask every happy customer for a review. Reviews are the single most powerful local marketing asset you will ever have — five genuine five-star reviews do more than any advert.
4. **Referrals.** After every good service, ask: "If you know anyone who needs this, I would love an introduction — and here is a card you can pass on." Offer a small thank-you (a discount on their next booking) for a referral who books. Make it easy: give them the words and the link.
5. **Partnerships.** Vets, pet shops, trainers, and groomers who do not offer your service are not competitors — they are referrers. Visit them, introduce yourself, leave cards, and offer to refer your customers to them. A vet who trusts you will send you more customers than any advert.

### The launch offer

A launch offer should attract your ideal customer, not bargain hunters. Good offers: a founding-client rate for the first ten customers who book a regular slot (locked for three months, then standard price); a free meet-and-greet or consultation; a package of three sessions at a modest saving, paid upfront. Bad offers: a deep discount with no commitment, a free service with no follow-up, or a price so low it attracts customers who will leave when the price rises. The purpose of the offer is to fill the diary with the right people, not to fill it with anyone.

### Worked example: ten customers in four weeks

Week 1: tell your network (aim for 50 people told, 10 conversations, 3 bookings). Post in two local groups and put up three notices (aim for 5 enquiries, 2 bookings). Week 2: Google Business Profile live, first three customers served and asked for reviews and referrals (aim for 2 referrals, 2 bookings). Week 3: visit two vets and one pet shop, leave cards, offer a referral arrangement (aim for 3 enquiries, 2 bookings). Week 4: follow up every enquiry that did not book, post a photo story of a happy client (with permission), and ask all ten customers to rebook (aim for 10 regulars). Total: 3 + 2 + 2 + 2 + 1 = 10. It is not magic; it is arithmetic plus follow-up. Most new businesses fail at the follow-up, not at the first contact.

### Action step — Module 12

Write your first-ten plan: list 50 people you will tell, two groups you will post in, three places for notices, two partners you will visit, and the launch offer you will make. Put dates on each one. Then start with the first five people on the list today.

---

## Module 13 — Launch Week and the First 90 Days

### Launch week checklist

Launch week is not a party; it is a test of your systems. The day before launch, confirm every booking, check your equipment, confirm your insurance is in force, and make sure your phone, payment link, and booking page all work. On launch day, do the work, send the updates, and ask every customer for feedback and a review. At the end of each day, write down three things: what went well, what went wrong, and what you will change tomorrow. Small daily fixes in week one prevent large problems in month three.

Use the launch checklist in the workbook (Section 8) and tick every item. If an item is not done, either do it or consciously postpone it with a date — do not silently skip it. The items most often skipped are the boring ones: confirming insurance, testing the payment link, and having the vet's number saved. They are also the ones that matter most when something goes wrong.

### The first 30 days: learn, don't scale

In the first month, your job is to learn: which services take longer than expected, which customers are easy and which are hard, what your real costs are, and where your enquiries actually come from. Track everything: enquiries, bookings, no-shows, revenue, costs, hours worked, and customer feedback. At the end of the month, compare your real numbers to the budget from Module 9. If revenue is lower than planned, is it because of too few enquiries, too few bookings from enquiries, or prices too low? Each cause has a different fix, and the numbers tell you which one. Do not change everything at once. Change one thing, measure it for two weeks, and then decide.

### The first 90 days: fill the diary

By day 90, a service business should have a pattern: a core of regular clients, a steady flow of enquiries, and a diary that is filling two to three weeks ahead. If the diary is empty, the problem is almost always one of three things: not enough people know you exist (marketing), people know but do not trust you enough to book (proof — reviews, insurance, professional presentation), or people enquire but do not book (price, availability, or a slow reply). Diagnose honestly before spending money on a fix. A slow reply is the most common and cheapest cause: if you take 24 hours to answer an enquiry, the customer has already booked someone who answered in an hour.

Set three 90-day milestones and review them weekly: number of regular clients, monthly revenue, and average rating. Write them on the wall. When you hit them, celebrate briefly and set the next three. When you miss them, ask what the numbers are telling you — and act on the answer within a week, not a month.

### Looking after yourself

The first 90 days are the hardest. You will work long hours, doubt yourself, and compare your beginning to someone else's year five. Protect your energy: keep one day a week free, eat and sleep properly, and keep a list of what is working — the happy customers, the good reviews, the money coming in — to read on the hard days. If you are exhausted, the business is not failing; it is telling you the price, the diary, or the systems need adjusting. Listen to it early.

### Action step — Module 13

Set your launch date. Work backwards: eight weeks of preparation (see `onboarding.md`), then launch week, then the 90-day review date. Write all three dates in your calendar now, and tell one person who will hold you to them.

---

## Module 14 — Growing, Hiring, and Knowing When to Expand

### Growth is a decision, not an accident

Growth happens in three ways: more customers for the same service, more services for the same customers, and more people delivering the service. The order matters. First, fill your own diary — a full diary is proof of demand and the cheapest growth you will ever get. Second, add a service your existing customers already ask for: a groomer adds nail trims and de-shedding; a walker adds holiday sitting; a trainer adds puppy classes. Third, and only third, hire someone to deliver the service. Hiring before your diary is full means paying someone to wait for customers who do not exist yet.

### Adding services the right way

Add one service at a time, to the customers you already have. Test it with five existing clients at an introductory price, ask for feedback, fix the problems, and only then promote it widely. Price it using the build-up method from Module 10, not by guessing. And check the knock-on effects: a new service may need new insurance, new training, new equipment, or a new licence. Check before you launch it, not after a customer asks for it.

### Hiring your first person

Hiring changes the business completely: you become a manager as well as a practitioner. Before you hire, be able to answer: what exactly will they do, how will they be trained, how will you check their work, what will you pay them (including tax, insurance, and the employer's costs — which add roughly 20–30% on top of wages in many places), and what happens if they are ill or leave? Start with a contractor or a part-time helper for a defined task, with a written agreement, before committing to a full employee. Check references, check their right to work, and make sure your insurance covers them. The cheapest hire is rarely the best one: in a trust business, the person you send into a customer's home is your reputation.

### Knowing when to expand — and when not to

Expand when three things are true at the same time: your diary is full two to three weeks ahead, you are turning away good customers, and you have three months of cash to fund the expansion. Do not expand because you are bored, because a competitor opened nearby, or because a cheap lease appeared. A second location, a van, or a shop is a new business with new costs, not a bigger version of the one you have. Run the numbers from Module 9 and 10 again for the expansion as if it were a new business — because it is.

Equally, know when not to expand. A solo business earning a good living, with regular clients, reasonable hours, and low stress, is a success — not a failure to grow. Not every business needs to become an empire. Decide what "enough" looks like for you, write it down, and measure yourself against it rather than against someone else's version of success.

### The five-year view

In five years, the businesses that survive are the ones that kept three habits: they answered quickly, they charged enough, and they looked after their customers and their animals. Everything else — marketing trends, platforms, fashions — changes. Those three do not. If you keep them, and you keep learning, you have a business that can support you for years. That is the real launchpad: not a single launch, but a business built to last.

### Action step — Module 14

Write your "enough" statement: the monthly income, weekly hours, and number of regular clients that would make this business a success for you. Then write the one thing you will do in the next 30 days to move toward it. Start there.

---

## Appendix A — Worked Example: Full First-Year Numbers for a Home-Based Groomer

Assumptions: solo groomer, home-based, 48 working weeks, average groom price $68, four grooms a day, five days a week, 80% diary fill in year one (the diary is not full from day one).

Gross revenue: 4 grooms × 5 days × 48 weeks × $68 × 80% fill = $52,224. Direct costs (consumables, laundry, blade wear) at 12%: $6,267. Gross profit: $45,957. Monthly running costs $475 × 12 = $5,700. Profit before owner pay and tax: $40,257. That is the money available to pay the owner and tax. If the owner takes $2,800 a month ($33,600 a year), $6,657 remains for tax provision and reinvestment. The business works — but only at 80% fill and four grooms a day, sustained. At 50% fill, revenue is $32,640 and profit before owner pay is $21,000 — the owner cannot take $2,800 a month. The diary fill rate is the number that decides everything, which is why Modules 12 and 13 matter as much as the pricing.

## Appendix B — Worked Example: Full First-Year Numbers for a Dog Walker

Assumptions: solo walker, 48 weeks, three group walks a day, four dogs per walk at $18, five days a week, 75% fill in year one, plus two boarding nights a week at $50.

Walking revenue: 3 walks × 4 dogs × $18 × 5 days × 48 weeks × 75% = $38,880. Boarding revenue: 2 nights × $50 × 48 weeks × 75% = $3,600. Total revenue: $42,480. Direct costs (fuel, treats, bags) at 10%: $4,248. Gross profit: $38,232. Monthly running costs $308 × 12 = $3,696. Profit before owner pay and tax: $34,536. Owner pay at $2,400 a month ($28,800) leaves $5,736 for tax and reinvestment. Again, the business works — at 75% fill and with boarding added. Without boarding, profit before owner pay falls to $30,936, and the owner's pay must fall with it. Mix matters: the walker who only walks, and only solo walks, earns far less for the same hours.

## Appendix C — Glossary

- **Break-even point:** the level of sales at which revenue covers all costs, with no profit and no loss.
- **Care, custody, and control:** insurance cover for animals in your care.
- **Diary fill rate:** the percentage of your available booking slots that are actually booked.
- **Gross margin:** revenue minus direct costs, expressed as a percentage of revenue.
- **Runway:** how many months you can operate before your money runs out, at your current rate of spending and income.
- **Sole trader:** a business structure in which one person owns and runs the business and is personally responsible for it.
- **LLC / limited company:** a business structure that is a separate legal entity from its owners.

---

*End of course. Now complete the workbook, the templates, and your launch plan — the course is only finished when the business is launched.*

**Disclaimer (repeated for clarity):** This course is education only and is not legal, tax, financial, or veterinary advice. Verify all licensing, insurance, and regulatory requirements locally, consult qualified professionals for your situation, and never make animal-health decisions without a licensed veterinarian. No income or outcome is guaranteed.

## Appendix D — Pricing Quick Reference and Pre-Launch Decision Checklist

### Pricing quick reference

Use this table as a starting point only — rebuild every figure for your own costs using the method in Module 10, and check all prices against your local competitors before you publish them.

| Service | Typical range (worked examples) | What drives the price |
|---|---|---|
| Full groom, small dog | $45–$60 | Coat type, temperament, time |
| Full groom, medium dog | $60–$75 | Coat type, temperament, time |
| Full groom, large dog | $75–$95 | Size, coat, handling time |
| Bath and tidy | $35–$50 | Time and coat condition |
| Nail trim (standalone) | $12–$20 | Time and handling |
| Group dog walk, 30 minutes | $15–$20 per dog | Group size, area, travel |
| Solo dog walk, 30 minutes | $30–$45 | One-to-one attention, travel |
| Solo dog walk, 60 minutes | $45–$65 | Duration and travel |
| House sitting, per night | $45–$75 | Duties, animals, location |
| Boarding in your home, per night | $40–$60 per dog | Space, care level, duration |
| One-to-one training session | $60–$120 | Experience, specialism, travel |
| Group training course (6 weeks) | $180–$250 per dog | Class size, venue, content |
| Puppy class (4–6 weeks) | $120–$200 per puppy | Class size, venue, content |

### Pre-launch decision checklist

Answer each question before you take your first paying customer. If the answer is no, write the date by which it will become yes.

1. Have I chosen one model, and can I explain why in one sentence?
2. Have I completed the competitor audit and interviewed ten pet owners?
3. Is my one-page business plan written and shown to one honest person?
4. Is my business registered and my tax registration in place?
5. Have I checked licences, zoning, and animal-care rules with my local authority in writing?
6. Is my insurance in force, including care, custody, and control cover where relevant?
7. Is my startup budget complete with real quotes, and is my runway at least three months?
8. Is every service priced using the build-up method, and is the price above my minimum viable price?
9. Is my booking, payment, and confirmation sequence tested end to end?
10. Do I have client records, consent forms, and vet details ready for every animal?
11. Is my Google Business Profile live with services, hours, and prices?
12. Do I have a launch date, a first-ten plan, and a 90-day review date in my calendar?

If you can answer yes to all twelve, you are ready to launch. If you cannot, you now know exactly what to do next — and that, more than any single lesson in this course, is the point of it.

---

*Pet Business Launchpad — content.md — end.*
