# PET-02 — Pet Business Launchpad: From Idea to Profitable Pet Business

**Price:** $497 (one-time) · **Category:** Pet Products & Pet Business · **SKU:** PET-02

A flagship, all-in-one course for choosing, legally setting up, pricing, and launching any pet business — grooming, sitting, training, retail, or products.

## Files in this folder

| File | What it is |
|---|---|
| `content.md` | The full 14-module course in written form (video course scripts, complete) — model comparison with startup costs and margins, pricing build-up, startup budget with real figures, first-customers plan, and worked first-year examples. |
| `workbook.md` | Companion workbook — model-selection worksheet, business-plan exercises, startup-budget worksheet, legal/insurance checklist, launch checklist, first-30-days tracker. |
| `templates/business-model-comparison-matrix.md` | Weighted scoring matrix for the five business models, with reference figures. |
| `templates/business-plan-template.md` | Full business plan template (12 sections, including risks and 90-day milestones). |
| `templates/startup-budget-planner.csv` | Spreadsheet planner — one-off costs, monthly costs, runway, and break-even, calculated automatically. |
| `templates/legal-insurance-checklist.md` | Legal and insurance checklist — structure, registration, licences, contracts, cover, and safety. |
| `sales-page.md` | Full sales page — headline, problem, solution, module list, who it is for / not for, $497 price + 14-day guarantee, FAQ, disclaimers. |
| `listing.json` | Marketplace listing data for EightyTwenty (SKU, name, category, price in cents, billing, headline, description, SEO keywords, refund policy, support). |
| `cover.md` | Cover design brief (black-and-gold luxury palette, typography, imagery, layout). |
| `cover.png` | The generated cover image (premium black-and-gold luxury branding). |
| `onboarding.md` | Customer onboarding guide — what to do first, how to use the materials, suggested 8-week schedule, how to get support. |

## Key facts

- **Headline:** Pick the right pet business and launch it — model, plan, pricing, and first customers.
- **Format:** Video course (14 modules) + comparison matrix + business plan template + startup budget planner + legal and insurance checklists + launch checklist.
- **Guarantee:** 14-day money-back guarantee.
- **Disclaimers:** Education only — not legal, tax, financial, or veterinary advice. No guaranteed income claims. No fabricated testimonials, sales figures, certifications, or reviews.
