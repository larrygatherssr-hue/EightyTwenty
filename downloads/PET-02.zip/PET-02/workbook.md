# Pet Business Launchpad — Companion Workbook

**SKU PET-02 — Work through each section as you complete the matching course module. Write your answers in this file or print it and write by hand.**

---

## Disclaimer

This workbook is education only. It is not legal, tax, financial, or veterinary advice. Business licensing, insurance, and regulatory requirements vary by location — verify them with your local authority and qualified professionals. No income or outcome is guaranteed. Never make animal-health decisions without a licensed veterinarian.

---

## Section 1 — Know Yourself (Module 2)

### 1A. Skills inventory

Score yourself 1 (weak / unwilling) to 5 (strong / enthusiastic) for each skill. Be honest — this is for you, not for anyone else.

| Skill | Score (1–5) | Notes |
|---|---|---|
| Hands-on animal handling | | |
| Grooming technique | | |
| Dog training knowledge | | |
| Patience with nervous animals | | |
| Talking with customers | | |
| Selling and promoting | | |
| Written communication | | |
| Admin and record-keeping | | |
| Physical stamina | | |
| Comfort in strangers' homes | | |
| Making / crafting products | | |
| Buying and merchandising | | |

My three strongest skills: _______________________________________________
My three weakest skills: ________________________________________________

### 1B. Time and money — the real numbers

- Hours per week I can give this business for the next 6 months: ______
- Hours per week I can give after 6 months: ______
- Money I can invest without borrowing: $______
- Money I could lose without harming my household: $______
- Months I can go without the business paying me: ______
- Monthly living costs I must cover: $______
- Other income I will keep while launching: $______ per month

My guardrail sentence: "I will not choose a model that requires more than ______ hours a week or more than $______ to start."

### 1C. My unfair advantage

My unfair advantage in one sentence: _____________________________________

If I cannot name one, the advantage I will build first is: ____________________, by (date) __________.

---

## Section 2 — Model Selection (Modules 3–4)

Score each model 1–5 on each criterion. Use the weights from the comparison matrix template; record your weighted totals here.

| Criterion | Weight | Grooming | Sitting / Walking | Training | Retail | Products |
|---|---|---|---|---|---|---|
| Skill fit | | | | | | |
| Enjoyment of daily work | | | | | | |
| Startup cost fit | | | | | | |
| Income potential | | | | | | |
| Time fit | | | | | | |
| Local demand | | | | | | |
| Speed to first income | | | | | | |
| Growth potential | | | | | | |
| **Weighted total** | | | | | | |

My chosen model: ________________________________________________________
Why, in one sentence: "I am launching a ______ business because _______."

The model I am NOT choosing, and why: ___________________________________

Tie-breaker test (if two models were close): what I did, what I learned:
_______________________________________________________________________

---

## Section 3 — Local Market Research (Module 5)

### 3A. My market radius

My service radius: __________________ (area / drive time). Why this radius: __________________

Local signs of demand (vets, pet shops, parks, groups): ____________________

### 3B. Competitor audit — complete for five competitors

| | Competitor 1 | Competitor 2 | Competitor 3 | Competitor 4 | Competitor 5 |
|---|---|---|---|---|---|
| Name | | | | | |
| Services | | | | | |
| Prices | | | | | |
| Hours | | | | | |
| How to book | | | | | |
| Insured? (stated?) | | | | | |
| Reviews / rating | | | | | |
| Praised for | | | | | |
| Complained about | | | | | |

The gap in my area, in one sentence: "The gap in my area is _______________."

### 3C. Customer interviews — ten pet owners

Record each conversation briefly: who, what service they use now, frustrations, what they would pay for better, what would convince them to try you.

1. _____________________________________________________________________
2. _____________________________________________________________________
3. _____________________________________________________________________
4. _____________________________________________________________________
5. _____________________________________________________________________
6. _____________________________________________________________________
7. _____________________________________________________________________
8. _____________________________________________________________________
9. _____________________________________________________________________
10. ____________________________________________________________________

Patterns I noticed (mentioned by 3+ people): _______________________________

---

## Section 4 — Business Plan Exercises (Module 6)

### 4A. One-page plan draft

1. The business in one sentence: ________________________________________
2. The customer (who exactly): __________________________________________
3. The offer (services and prices): ______________________________________
4. The gap: ____________________________________________________________
5. The money (monthly revenue target / costs / break-even): ________________
6. How customers find me (3 channels): __________________________________
7. First 90 days (3 milestones with dates): _______________________________
8. What I will NOT do for the first 6 months: ____________________________

### 4B. Honest review

Who reviewed my plan: __________________ Date: __________
Weakest line they identified: ____________________________________________
How I fixed it: _________________________________________________________

---

## Section 5 — Legal and Insurance Checklist (Modules 7–8)

*Tick each item when done, or note the date and the professional you consulted. Do not take paying customers until the items that apply to you are complete.*

- [ ] Business structure chosen (sole trader / partnership / LLC / limited company)
- [ ] Business registered with the relevant authority — date: __________
- [ ] Tax registration complete — date: __________
- [ ] Sales tax / VAT status checked — notes: _______________________________
- [ ] Separate business bank account opened
- [ ] Business name checked (local use, domain, social media, trademark)
- [ ] Council / city licencing checked in writing — reference: ________________
- [ ] Zoning / home-business permission checked
- [ ] Lease / mortgage permission checked (if applicable)
- [ ] Animal boarding / daycare licence checked (if applicable)
- [ ] Food / treat regulations checked (if making pet food or treats)
- [ ] Service agreement and terms written
- [ ] Booking confirmation and consent form ready
- [ ] Vaccination and vet-details form ready
- [ ] Photo-permission form ready
- [ ] Insurance quotes obtained (at least 2 brokers) — broker names: __________
- [ ] Insurance policy in force — insurer: __________ policy no.: __________ renewal date: __________
- [ ] Care, custody, and control cover confirmed in writing: yes / no
- [ ] Home insurance checked for business use: yes / no
- [ ] Pet first-aid course booked / completed — date: __________

---

## Section 6 — Pricing Build-Up (Module 10)

Complete one table per service. Formula: direct costs + (monthly running costs ÷ expected monthly sales) + (hours × target hourly rate) = minimum viable price.

### Service 1: ________________________

| Item | Amount |
|---|---|
| Direct costs per sale (consumables, travel) | $ |
| Monthly running costs ÷ expected sales per month | $ |
| Hours per sale (incl. admin/travel) × $_____/hour | $ |
| **Minimum viable price** | **$** |
| Price I will charge | $ |
| Competitor prices (3) | $ / $ / $ |
| If my price is below minimum viable: my honest option, and the date the price rises | |

### Service 2: ________________________

| Item | Amount |
|---|---|
| Direct costs per sale | $ |
| Running-cost share | $ |
| Labour (hours × rate) | $ |
| **Minimum viable price** | **$** |
| Price I will charge | $ |
| Competitor prices (3) | $ / $ / $ |

### Service 3: ________________________

| Item | Amount |
|---|---|
| Direct costs per sale | $ |
| Running-cost share | $ |
| Labour (hours × rate) | $ |
| **Minimum viable price** | **$** |
| Price I will charge | $ |
| Competitor prices (3) | $ / $ / $ |

My target hourly rate: $______ per hour. Why this rate: ____________________

---

## Section 7 — First Ten Customers Plan (Module 12)

- 50 people I will tell (list names; start with the first 5 today):
  _______________________________________________________________________
- 2 local groups I will post in: __________________________________________
- 3 noticeboard locations: _______________________________________________
- 2 partners I will visit (vet / pet shop / trainer): ________________________
- My launch offer: _______________________________________________________
- Google Business Profile created: yes / no — date: __________

Tracker:

| # | Customer name | Service | Date | Paid? | Review asked? | Referred someone? |
|---|---|---|---|---|---|---|
| 1 | | | | | | |
| 2 | | | | | | |
| 3 | | | | | | |
| 4 | | | | | | |
| 5 | | | | | | |
| 6 | | | | | | |
| 7 | | | | | | |
| 8 | | | | | | |
| 9 | | | | | | |
| 10 | | | | | | |

---

## Section 8 — Launch Checklist (Module 13)

*Tick each item in launch week. If an item is not done, write the date it will be done — do not silently skip it.*

- [ ] Insurance in force and documents filed
- [ ] All bookings confirmed with customers
- [ ] Equipment checked and working
- [ ] Payment link tested end to end
- [ ] Booking page tested as a pretend customer
- [ ] Vet's number and emergency vet number saved in phone and on paper
- [ ] First-aid kit stocked
- [ ] Client record forms printed / ready
- [ ] Prices published and consistent everywhere
- [ ] Google Business Profile live
- [ ] Launch offer published
- [ ] Daily log started (what went well / wrong / will change tomorrow)

Launch date: __________ 90-day review date: __________

---

## Section 9 — First-30-Days Tracker

Fill in weekly. Compare real numbers to your budget each week.

| Week | Enquiries | Bookings | No-shows | Revenue | Costs | Hours worked | What I learned |
|---|---|---|---|---|---|---|---|
| 1 | | | | $ | $ | | |
| 2 | | | | $ | $ | | |
| 3 | | | | $ | $ | | |
| 4 | | | | $ | $ | | |

End-of-month review:
- Revenue vs. plan: __________________
- Biggest surprise: __________________
- One thing I will change next month: __________________
- Diary fill rate: ______%

---

## Section 10 — My "Enough" Statement (Module 14)

Monthly income that makes this business a success for me: $______
Weekly hours I am willing to work: ______
Number of regular clients that means success: ______
The one thing I will do in the next 30 days: ________________________________
Date: __________

---

*Workbook end. Keep this workbook with your business plan — review it monthly in year one.*
