# Legal and Insurance Checklist

**Pet Business Launchpad — SKU PET-02**

*Education only — this checklist explains the kinds of steps that commonly apply. It is not legal advice. Requirements vary by city, county, state, and country, and they change over time. Verify every item with the relevant local authority, a licensed attorney, a licensed insurance broker, and a qualified accountant.*

## A. Business Structure and Registration

- [ ] Chosen structure: sole trader / partnership / LLC / limited company (circle one)
- [ ] Accountant consulted before choosing — date: ______ adviser: ______
- [ ] Business registered with the relevant authority — date: ______ reference: ______
- [ ] Tax registration complete — date: ______
- [ ] Sales tax / VAT status checked and recorded — notes: ______
- [ ] Separate business bank account opened — bank: ______
- [ ] Bookkeeping system set up (software / spreadsheet) — system: ______

## B. Name and Brand

- [ ] Business name checked for local use by another business
- [ ] Domain name checked and registered (if applicable)
- [ ] Social media handles checked and secured
- [ ] Trademark register checked (if planning to grow beyond your town)
- [ ] Name does not promise what you cannot deliver (no "guaranteed", "vet-approved", "best" unless true)

## C. Licences, Zoning, and Animal-Care Rules

- [ ] Local council / city authority contacted in writing — date: ______ reference: ______
- [ ] Home-business / zoning permission checked — result: ______
- [ ] Lease or mortgage permission checked (if applicable) — result: ______
- [ ] Animal boarding licence required? yes / no — status: ______
- [ ] Daycare / kennel licence required? yes / no — status: ______
- [ ] Grooming licence required? yes / no — status: ______
- [ ] Maximum number of animals allowed on premises checked — limit: ______
- [ ] Food / treat business registration checked (if making pet food or treats)
- [ ] Product labelling and safety rules checked (if selling products)
- [ ] Signage / planning permission checked (if applicable)

## D. Contracts, Consent, and Records

- [ ] Written service agreement and terms prepared
- [ ] Booking confirmation template ready (date, time, address, price, what's included)
- [ ] Owner consent form ready
- [ ] Vaccination record request process in place
- [ ] Vet contact details form ready for every animal
- [ ] Photo / social media permission form ready
- [ ] Key-handling procedure written (sitting / walking)
- [ ] Cancellation policy written and published
- [ ] Complaints process written (how a customer raises a problem, how fast you respond)

## E. Insurance — Ask a Licensed Broker

- [ ] Broker 1 consulted — name: ______ date: ______
- [ ] Broker 2 consulted — name: ______ date: ______
- [ ] Public liability cover — limit: ______ insurer: ______
- [ ] Professional indemnity cover — limit: ______
- [ ] Care, custody, and control cover (animals in your care) — confirmed in writing: yes / no
- [ ] Property and equipment cover — limit: ______
- [ ] Business interruption cover — yes / no
- [ ] Motor cover correct for business use (if driving for work) — yes / no
- [ ] Employers' liability (if hiring anyone) — yes / no / not applicable
- [ ] Home insurance checked for business use — result: ______
- [ ] Policy documents filed where they can be found in under a minute
- [ ] Renewal date in calendar: ______

## F. Safety and Animal Welfare

- [ ] Pet first-aid course completed or booked — date: ______
- [ ] First-aid kit stocked and accessible
- [ ] Emergency vet number saved in phone and on paper
- [ ] Incident log template ready (date, what happened, action taken)
- [ ] Cleaning / hygiene routine written (equipment, bedding, towels)
- [ ] Medication procedure written (written instruction only, stored as directed)
- [ ] List of animals / situations I will not take on, written down

## G. Before the First Paying Customer

- [ ] All items above that apply to my business are complete, or I have professional advice in writing that they do not apply
- [ ] I have read the disclaimers in the course and understand this checklist is education, not legal advice
- [ ] Launch date confirmed: ______

---

*Keep this checklist with your business records. Review it at renewal time and whenever you add a service, hire someone, or move premises.*
