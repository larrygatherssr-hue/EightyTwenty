# Business Plan Template

**Pet Business Launchpad — SKU PET-02**

*Education only — this template helps you organise your thinking. It is not legal, tax, or financial advice. Verify all licensing, insurance, and regulatory requirements locally.*

## 1. Business Summary

- Business name:
- Owner name:
- Chosen model (grooming / sitting & walking / training / retail / products):
- Location and service area:
- Launch date:
- Business in one sentence:

## 2. The Customer

- Who exactly is my customer (age, lifestyle, pet, location)?
- What problem do they have that I solve?
- How many such customers are in my service area (best estimate, and how I estimated it)?
- What do they currently do instead of using me?

## 3. The Offer

List every service or product, with price and time required:

| Service / product | Price | Time required | Notes |
|---|---|---|---|
| | $ | | |
| | $ | | |
| | $ | | |
| | $ | | |
| | $ | | |

- Packages or subscriptions offered:
- Add-ons offered:
- What is NOT included (to avoid misunderstandings):

## 4. The Market Gap

- The gap I found (from Module 5 research):
- My three closest competitors and what they do well:
- What I will do differently:

## 5. The Money

- Monthly revenue target (month 3): $
- Monthly revenue target (month 6): $
- Monthly running costs: $
- Monthly living costs the business must cover: $
- Break-even sales per month: ______ sales at an average of $______ each
- Startup costs (one-off total): $
- Runway: ______ months (savings ÷ monthly shortfall)
- Funding source (savings / other income / loan — note: borrowing carries risk; get independent advice):

## 6. Marketing — How Customers Find Me

| Channel | Weekly action | Target (per month) |
|---|---|---|
| My network / word of mouth | | |
| Local groups & noticeboards | | |
| Google Business Profile & reviews | | |
| Referrals | | |
| Partnerships (vets, shops, trainers) | | |
| Other: | | |

- Launch offer:
- How I will ask for reviews:

## 7. Operations

- Days and hours of operation:
- Booking and payment system:
- How customers contact me:
- Client record system:
- Insurance (insurer, policy number, renewal date):
- Licences held / applied for:
- Suppliers:

## 8. Safety and Animal Welfare

- Pet first-aid training (completed / booked — date):
- Vaccination records required: yes / no
- Meet-and-greet before first booking: yes / no
- Emergency vet details on file: yes / no
- Incident recording process:
- Animals or situations I will not take on:

## 9. First 90 Days — Milestones

| Milestone | Target | Date |
|---|---|---|
| Launch | | |
| First 10 regular customers | | |
| First month at target revenue | | |
| 90-day review | | |

## 10. What I Will NOT Do (First 6 Months)

List the distractions you are saying no to (second service, shop, van, product line, etc.):

1.
2.
3.

## 11. Risks and How I Will Handle Them

| Risk | Likelihood | What I will do about it |
|---|---|---|
| Slow start / few enquiries | | |
| Losing a key customer | | |
| Animal illness or accident | | |
| Running out of money | | |
| Illness / inability to work | | |
| Other: | | |

## 12. Review Schedule

- I will review this plan on (dates):
- Reviewer (honest friend / adviser / mentor):

---

*Keep the one-page summary of this plan on your wall. Review the full plan monthly in year one.*
