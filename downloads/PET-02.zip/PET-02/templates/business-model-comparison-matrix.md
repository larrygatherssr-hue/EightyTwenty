# Business-Model Comparison Matrix

**Pet Business Launchpad — SKU PET-02**

## How to use this matrix

1. Set your weights first. The eight criteria weights must add up to 100. The suggested weights below are a starting point — change them to reflect what matters most to you, but write them down before you score anything.
2. Score each model 1–5 on each criterion: 1 = poor fit, 3 = workable, 5 = excellent fit.
3. Multiply each score by the weight and add up the weighted total for each model. The highest total is your leading model — but read the notes in Module 4 before deciding, especially if two models are within 30 points.

*Education only. Scores are your judgement, not a prediction of income or success. No income is guaranteed.*

## Weights

| Criterion | Your weight (must total 100) |
|---|---|
| Skill fit — can I do this work well, or learn it willingly? | 20 |
| Enjoyment of the daily work — will I still like this in year two? | 20 |
| Startup cost fit — can I afford to start this properly? | 15 |
| Income potential — can this pay what I need? | 15 |
| Time fit — does it fit the hours I actually have? | 10 |
| Local demand — is there a real gap in my area? | 10 |
| Speed to first income — how fast can I earn? | 5 |
| Growth potential — can it grow without breaking? | 5 |
| **Total** | **100** |

## Scoring table

| Criterion (weight) | Grooming | Sitting / Walking | Training | Retail | Products |
|---|---|---|---|---|---|
| Skill fit ( ) | | | | | |
| Enjoyment ( ) | | | | | |
| Startup cost fit ( ) | | | | | |
| Income potential ( ) | | | | | |
| Time fit ( ) | | | | | |
| Local demand ( ) | | | | | |
| Speed to first income ( ) | | | | | |
| Growth potential ( ) | | | | | |
| **Weighted total (max 500)** | | | | | |

## Reference figures (worked examples — rebuild for your area)

| Factor | Grooming | Sitting / Walking | Training | Retail | Products |
|---|---|---|---|---|---|
| Typical lean startup cost | $3,000–$8,000 | $300–$1,500 | $500–$3,000 | $5,000–$25,000+ | $500–$3,000 |
| Typical price per sale | $45–$90 per groom | $15–$25 per walk; $40–$75 per night | $60–$120 per session; $200–$600 per course | $8–$40 average basket | $8–$30 per item |
| Gross margin | 70–85% | 85–95% | 80–95% | 40–55% | 50–70% |
| Repeat frequency | Every 4–8 weeks | Daily / weekly | Course, then top-ups | Weekly / monthly | Monthly |
| Hardest part | Physical stamina, skill | Reliability, holidays | Selling to owners | Stock and rent | Standing out |

## Decision

My chosen model: ________________________________________________________
Why, in one sentence: ___________________________________________________
The closest alternative, and why I did not choose it: ______________________
Tie-breaker test I will run (if scores were close): _________________________
Date I will decide by: __________
