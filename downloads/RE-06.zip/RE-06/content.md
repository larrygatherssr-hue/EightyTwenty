# The Commercial Real Estate Investor Masterclass

## Step up to multifamily and commercial — underwrite, syndicate, and raise capital with confidence

**A complete 20-module masterclass for experienced residential investors and high-income professionals ready to move into multifamily and commercial real estate.**

---

## Important Notice — Please Read First

This masterclass is education only. It is not individualized investment advice, legal advice, tax advice, financial advice, or securities advice, and it does not create an advisor, broker, attorney, or accountant relationship with you. Commercial real estate involves larger amounts of capital, longer timelines, more complex financing, and different risks than residential investing. A single bad commercial deal can risk far more capital than a single-family rental.

Nothing in this course guarantees a return, a cap rate, a loan approval, an occupancy level, or any investment outcome. All numbers in this course are illustrative teaching examples based on stated assumptions. They are not forecasts, appraisals, or promises about any real property or market. Markets change. Rents, expenses, interest rates, insurance costs, taxes, and regulations change. Before you buy, sell, syndicate, raise capital, or sign any document, work with qualified professional advisors — a commercial real estate attorney, a CPA experienced in real estate, a licensed commercial broker, and a commercial lender — and have them review your specific deal, your entity structure, and your offering documents.

If you intend to raise money from other people, you must understand securities law. Pooling investor capital is generally a securities offering and is regulated. Do not raise capital, advertise an investment, or accept investor funds without advice from a securities attorney. This course explains concepts so you can have an informed conversation with that attorney. It does not replace that attorney.

Use the models, checklists, and templates in this course as learning tools. Verify every assumption against real rent rolls, tax returns, leases, inspection reports, and lender quotes for the specific property you are considering.

---

## How to Use This Course

This is the complete written course manual. Each module is written to be read on its own and in order. Work through the modules in sequence the first time. Then return to individual modules as reference when you are underwriting a live deal.

You will need:

- The Commercial Underwriting Model (the CSV template in the templates folder) — open it alongside Modules 4 through 9.
- The Syndication Deal-Review Checklist — use it from Module 12 onward.
- The Capital-Raising Template — use it from Module 14 onward.
- A notebook or the companion workbook — complete the exercise at the end of each module before moving on.

A suggested pace is one to two modules per week over 12 weeks. That schedule is in the onboarding guide. If you are already underwriting a live deal, work through Modules 4 to 9 first, then return to the beginning.

The flagship teaching property used throughout this course is a fictional 48-unit apartment community, "Maple Court," used only to demonstrate the math. It is not a real property, not an offering, and not an invitation to invest.

---

## Table of Contents

- Module 1 — From Houses to Commercial: What Actually Changes
- Module 2 — The Commercial Landscape: Multifamily, Office, Retail, Industrial, and Mixed-Use
- Module 3 — Building Your Commercial Buy Box and Investment Thesis
- Module 4 — The Language of Commercial Value: NOI, Cap Rate, and Price
- Module 5 — Reading a Rent Roll, T-12, and Offering Memorandum Like an Underwriter
- Module 6 — Building a Full Operating Pro Forma, Line by Line
- Module 7 — Commercial Loans: DSCR, Loan Sizing, and Terms That Matter
- Module 8 — The Full Multifamily Underwriting Walkthrough: Maple Court, 48 Units
- Module 9 — Returns That Matter: Cash-on-Cash, IRR, Equity Multiple, and Yield on Cost
- Module 10 — Value-Add Strategy: Renovation, Repositioning, and Rent Growth
- Module 11 — Due Diligence: Physical, Financial, Legal, and Market Verification
- Module 12 — Syndication Structures: Entities, Splits, and Waterfalls
- Module 13 — The Syndication Waterfall, Worked in Full
- Module 14 — Capital Raising: Finding, Qualifying, and Communicating with Investors
- Module 15 — The Investor Presentation and the Data Room
- Module 16 — Asset Management After Closing: Operations, Reporting, and the Business Plan
- Module 17 — Exit Strategies: Refinance, Sale, and the Hold Decision
- Module 18 — Risk Management: What Can Go Wrong and How to Prepare
- Module 19 — Building Your Commercial Team and Your First Deal Pipeline
- Module 20 — Your 12-Month Commercial Action Plan
- Case Study 1 — Maple Court: 48-Unit Value-Add
- Case Study 2 — Cedar Lane: 24-Unit Stabilized Acquisition
- Case Study 3 — Harbor View: 120-Unit Syndication
- Case Study 4 — Birchwood: 36-Unit Turnaround and the Deal That Was Passed On
- Appendix A — Commercial Glossary
- Appendix B — Underwriting Rules of Thumb and Sanity Checks
- Appendix C — Documents and Advisor Checklist

---

## Module 1 — From Houses to Commercial: What Actually Changes

If you have bought single-family rentals, you already know more than you think. You know how to read a lease, how to judge a neighborhood, how to handle a vacancy, and how to compare a rent to a mortgage payment. Commercial investing builds on those instincts, but it changes the rules in five ways that catch residential investors off guard.

First, value is driven by income, not by comparable sales. A house is worth roughly what similar houses nearby sold for. A commercial building is worth roughly what its net operating income divided by a market cap rate says it is worth. That single difference changes everything. It means you can create value by raising income or cutting wasteful expense, even if nothing else in the market changes. It also means a seller can present a flattering income number and, in doing so, present a flattering price. Your job as an underwriter is to test that income number until you trust it.

Second, the numbers are bigger and the mistakes are bigger. A 10 percent error on a $250,000 house is $25,000. A 10 percent error on a $4,800,000 apartment community is $480,000. That does not mean you should be afraid. It means you should be systematic. Commercial underwriting is a discipline: same steps, same checks, every deal, even when you are excited about a property.

Third, financing is underwritten on the property, not mainly on you. A residential lender asks mostly about your income, your credit, and your debt-to-income ratio. A commercial lender asks mostly about the property's net operating income, its debt-service coverage ratio, its occupancy, and its condition — and then about you as a guarantor and operator. A strong property with a weak operator can be declined. A weak property with a strong operator can also be declined. You need both.

Fourth, you are buying a business, not just a building. A 48-unit community has employees or contractors, vendors, leases that expire on different dates, utility contracts, insurance renewals, a marketing funnel, and a reputation with tenants. When you close, you inherit all of it. Your first 90 days of ownership matter as much as your underwriting. Many value-add plans fail not because the math was wrong but because the transition was sloppy.

Fifth, the legal and tax structure matters more. Entities, operating agreements, securities rules for raising capital, cost segregation, depreciation, and 1031 exchanges are not side topics in commercial investing. They are central. You will not become an attorney or a CPA from this course, and you should not try. You will learn enough to ask the right questions, to recognize when you need advice, and to avoid the most common expensive errors — like raising money informally from friends without understanding that you may have conducted a securities offering.

### What stays the same

Good investing habits transfer directly. Buy below replacement cost when you can. Know your market block by block. Verify rent claims against real leases. Keep reserves. Do not fall in love with a property before the numbers clear. Talk to property managers before you buy, not after. These habits made you successful in residential investing. They will serve you here too.

### The two paths into commercial

There are two legitimate paths, and this course covers both. The active path: you buy, operate, or co-sponsor a deal. You make decisions and you carry responsibility. The passive path: you invest as a limited partner in someone else's syndication. You provide capital, you receive reporting, and you do not manage the property. Many experienced residential investors do both — they invest passively first to learn how a good operator reports and communicates, and then they sponsor their own deal.

Neither path is a shortcut. A passive investment still requires you to evaluate the sponsor, the market, the business plan, and the fee structure. If you cannot underwrite the deal yourself, you cannot tell a good sponsor from a poor one. That is why this course teaches underwriting before syndication and capital raising. The math comes first. The structure follows the math.

### Your mindset shift

Residential investors often ask, "What is the monthly cash flow?" Commercial investors ask, "What is the net operating income, how stable is it, what does it cost to grow it, and what is the property worth at a market cap rate?" Learn to think in annual NOI, not monthly rent minus mortgage. Learn to think in cap rates, debt-service coverage, and equity multiples. By Module 9, those terms will feel as natural as cash flow does now.

**Action steps for Module 1:**

1. Write down your residential experience in one paragraph: how many properties, what types, what you learned about tenants and maintenance.
2. Write down why you want to move into commercial, in one sentence. Keep it visible while you work through the course.
3. Decide which path you want to explore first — active, passive, or both — and write down what would need to be true for you to proceed.
4. List the professional advisors you already have (attorney, CPA, broker, lender) and the gaps you need to fill.

**Exercise:** Complete Exercise 1 in the workbook before moving to Module 2.

---

## Module 2 — The Commercial Landscape: Multifamily, Office, Retail, Industrial, and Mixed-Use

Commercial real estate is not one market. It is several markets that behave differently, and the differences matter more than the similarities. This module gives you a working map. You do not need to master every sector. You need to understand them well enough to choose one — and to understand why this course focuses on multifamily.

### Multifamily: apartments

Multifamily means residential buildings with five or more units. It is the focus of this course for three reasons. First, people always need housing, which makes demand more durable across economic cycles than demand for office or retail space. Second, leases are short — usually 12 months — so rents can adjust to market conditions relatively quickly. Third, financing is deep: agency lenders, banks, credit unions, and private lenders all compete for multifamily loans.

Within multifamily, properties are grouped by class. Class A is newer, well-located, amenity-rich, and expensive, with lower cap rates and lower cash flow yields. Class B is older but well-maintained, often the sweet spot for value-add investors: solid bones, dated interiors, rents below newer competitors. Class C is older, in weaker locations, with more deferred maintenance and more management intensity. None of these classes is inherently good or bad. Each has a different risk and return profile, and each demands a different operating skill set. Most first-time commercial investors who succeed start in Class B.

Unit count matters too. A 5-to-20-unit property is often financed and managed more like a large residential deal. A 20-to-100-unit property is the classic first syndication size: large enough to support professional management and meaningful economies of scale, small enough for a first-time sponsor team to manage. Above 100 units, operations, staffing, and capital requirements scale up significantly. This course uses 24-unit, 36-unit, 48-unit, and 120-unit examples so you can see how the math and the management change with size.

### Office

Office buildings earn rent from businesses that need workspace. Lease terms are longer — often three to ten years — which can mean stable income when leases are in place, and long, expensive vacancies when they are not. Office demand is sensitive to employment trends, remote-work patterns, and the health of local employers. Tenant improvement costs and leasing commissions are high. For a first commercial deal, office is generally harder to underwrite and harder to lease than multifamily, and this course does not recommend it as a starting point. You should still understand it, because office distress in a market can affect nearby multifamily demand and pricing.

### Retail

Retail properties range from single-tenant shops to neighborhood shopping centers anchored by a grocery store. Retail leases are often triple-net, meaning the tenant pays taxes, insurance, and maintenance in addition to rent. That can mean lower landlord expenses and more predictable net income — when the tenant is strong and stays. The risk is tenant concentration: lose an anchor tenant and the center can struggle. Retail success depends heavily on location, traffic counts, demographics, and the tenant mix. Co-tenancy clauses, lease guarantees, and the credit quality of the tenant matter enormously.

### Industrial

Industrial includes warehouses, distribution centers, flex space, and light manufacturing. It has grown strongly with e-commerce, but it is a specialized sector. Clear heights, dock doors, truck access, power capacity, and proximity to highways matter more than curb appeal. Leases are often longer and tenants invest heavily in their space, which can mean stability — and can also mean expensive re-tenanting when a specialized user leaves. Industrial is a strong sector to learn later. It is not the focus of this course.

### Mixed-use

Mixed-use buildings combine residential units with ground-floor retail or office. They can diversify income, but they combine the management challenges of both uses. Financing and insurance can be more complex, and the residential and commercial portions may be valued differently. If you consider a mixed-use deal, underwrite each component separately and then together.

### Choosing your lane

The most common mistake new commercial investors make is trying to evaluate every sector at once. Choose one. For most readers of this course, that lane is multifamily, and within multifamily, Class B value-add in a market you know. Learn its rent levels, its expense ratios, its cap rates, its lenders, and its property managers. When you can underwrite ten multifamily deals in that lane quickly and accurately, you will know more than most buyers in your market. Depth beats breadth.

**Action steps for Module 2:**

1. Choose your primary sector and write down why in three sentences.
2. Identify three submarkets you know well enough to name the major employers, the best streets, and the rent range for a two-bedroom apartment.
3. Write down the property classes you will consider and the ones you will exclude for your first deal, with a reason for each exclusion.

**Exercise:** Complete Exercise 2 in the workbook.

---

## Module 3 — Building Your Commercial Buy Box and Investment Thesis

A buy box is a written set of criteria that describes the deals you will pursue and the deals you will ignore. Without one, you will waste time on properties that do not fit your capital, your skills, or your goals — and you will be tempted by every "great deal" a broker sends you. With one, you can evaluate a deal in minutes and say no quickly, which is the most valuable skill in commercial investing.

### What goes in a buy box

A complete commercial buy box includes: property type, unit count range, location and submarkets, vintage and class, price range, minimum and target cap rate, minimum cash-on-cash return, minimum debt-service coverage ratio, value-add scope you are willing to take on, hold period, and equity you can commit. It also includes your exclusions: property types, locations, or conditions you will not consider.

Here is an example buy box for a first-time active multifamily investor, using illustrative numbers. Your numbers will differ, and they should reflect your capital and your market.

- Property type: Multifamily, Class B, 20 to 60 units.
- Location: Two named submarkets within one metro area you know.
- Vintage: Built 1970 to 2000, brick or well-maintained frame, no major structural issues.
- Price: $1,500,000 to $5,000,000.
- Going-in cap rate: At least 6.5 percent on verified trailing NOI.
- Stabilized cash-on-cash: At least 8 percent in the underwriting, after reserves.
- DSCR: At least 1.25x on the proposed loan.
- Value-add: Interior renovation up to $10,000 per unit, exterior and common-area work, no ground-up development, no major structural work.
- Hold period: Five to seven years.
- Equity: Up to $1,500,000 of your own capital, or a syndication with a named co-sponsor.

Notice how specific that is. A broker who reads it knows exactly what to send you and what not to send. A seller who does not fit knows not to waste your time. And you know, before you open a model, whether a deal deserves an hour of your attention.

### Your investment thesis

A thesis is one paragraph that explains why you believe your strategy will work in your market. It is not a prediction that prices will rise. It is a reasoned argument based on supply, demand, income, and your operating advantage. For example: "In this submarket, Class B rents are $250 below Class A rents, occupancy has stayed above 94 percent for five years, new supply is limited by zoning, and many Class B owners have deferred interior updates. A disciplined renovation and professional management program can close part of that rent gap while keeping occupancy stable."

Write your thesis down. Then test it. Ask a property manager whether the rent gap is real. Ask a broker whether occupancy has really stayed high. Check permit data for new supply. If the thesis does not survive those conversations, revise it before you buy.

### Capital, time, and skill — the honest inventory

Before you choose a strategy, take an honest inventory. How much equity can you commit without endangering your personal finances? How many hours per week can you give to asset management? What operating skills do you have, and what will you hire? A value-add deal that needs weekly site visits is a poor fit for an investor who can give four hours a month. A stabilized deal with professional management may fit better. A passive limited-partner investment may fit best of all while you learn.

There is no shame in starting passive. Many successful sponsors invested passively first. The goal is not to do the most ambitious deal. The goal is to do a deal you can operate well and hold through a difficult period.

### Sourcing: where deals come from

Commercial deals come from brokers, from direct outreach to owners, from wholesalers, from other investors, and from your own network. Broker relationships matter. A broker who trusts you will call you before a property goes to market. Earn that trust by being specific about your buy box, by responding quickly, by giving honest feedback on deals you pass on, and by closing when you say you will close. Do not ask a broker to send you everything. Ask them to send you what fits.

Direct outreach — letters, calls, and visits to owners of properties that fit your buy box — can work, but it is slow and it requires consistency. It is a marketing program, not a one-time effort. If you pursue it, track your outreach, follow up, and be respectful of owners' time.

**Action steps for Module 3:**

1. Draft your buy box using the headings above. Keep it to one page.
2. Write your one-paragraph investment thesis.
3. Complete an honest capital, time, and skill inventory.
4. List five brokers and five property managers in your target market to contact.

**Exercise:** Complete Exercise 3 in the workbook — the buy-box worksheet.

---

## Module 4 — The Language of Commercial Value: NOI, Cap Rate, and Price

This module teaches the three numbers that govern commercial value. Master them and you can read any offering memorandum with understanding. Skip them and every deal will look either wonderful or terrifying, depending on who is presenting it.

### Net operating income (NOI)

Net operating income is the income a property produces after operating expenses, but before debt service, income taxes, depreciation, and capital expenditures that are not part of normal operations. In formula form:

**NOI = Effective Gross Income − Operating Expenses**

Effective gross income (EGI) is gross potential income minus vacancy and credit loss. Gross potential income includes rent at full occupancy plus other income: laundry, parking, pet fees, application fees, storage, and similar items. Operating expenses include property taxes, insurance, repairs and maintenance, utilities paid by the owner, property management, payroll, marketing, administration, legal, and reserves for replacement.

What NOI excludes matters as much as what it includes. NOI excludes mortgage payments. That is deliberate: NOI measures the property, not the financing. Two buyers who pay different prices and use different loans can look at the same NOI. NOI also excludes income tax and depreciation, because those depend on the owner, not the property. And NOI excludes large, one-time capital items — a new roof, for example — which are handled separately in the capital budget, though a reserve for future replacements is normally included in operating expenses.

A common seller trick is to present a "pro forma NOI" based on future rents that have not been achieved, or to understate expenses by omitting management fees, reserves, or realistic maintenance. Your job is to rebuild NOI from verified sources: the trailing 12 months of actual income and expense (the T-12), the rent roll, bank statements, and tax returns. That process is covered in Module 5.

### Cap rate

The capitalization rate, or cap rate, is the ratio of NOI to price:

**Cap Rate = NOI ÷ Price**

**Price = NOI ÷ Cap Rate**

If a property produces $390,618 of NOI and sells for $4,800,000, its cap rate is $390,618 ÷ $4,800,000 = 8.14 percent. If the market cap rate for similar properties is 7.5 percent and the NOI is $390,618, the indicated value is $390,618 ÷ 0.075 = $5,208,240. If the market cap rate rises to 8.5 percent, the indicated value falls to $390,618 ÷ 0.085 = $4,595,506 — even though the property itself has not changed. That sensitivity is why interest rates and cap rates matter so much. A small move in the cap rate is a large move in value.

Cap rates vary by market, property class, age, location, and condition. Newer, well-located, stabilized properties trade at lower cap rates. Older, weaker, or more management-intensive properties trade at higher cap rates. Do not use a national average cap rate to value a local deal. Use comparable sales in your submarket, and ask brokers and appraisers what cap rates they are actually seeing close — not what they are seeing listed.

### The worked example: cap rate and price

Use the Maple Court figures introduced in the course overview. They are illustrative.

- Gross potential rent: 48 units × $1,150 per month × 12 = $662,400 per year.
- Other income: $24,000 per year.
- Gross potential income: $686,400.
- Vacancy and credit loss at 5 percent of gross potential rent: $33,120.
- Effective gross income: $653,280.
- Operating expenses: $262,662 (detailed in Module 6).
- NOI: $653,280 − $262,662 = $390,618.
- Asking price: $4,800,000.
- Going-in cap rate: $390,618 ÷ $4,800,000 = 8.14 percent.

If you believed the market cap rate was 7.5 percent, you would value the property at $5,208,240 and the asking price would look like a discount. If you believed the market cap rate was 8.5 percent, you would value it at $4,595,506 and the asking price would look expensive. Your valuation is only as good as your NOI and your cap rate. Both must be verified.

A second check: what happens if NOI is overstated by $40,000 — for example, if the seller understated expenses by that amount? True NOI would be $350,618. At a 7.5 percent cap rate, true value would be $4,674,907, not $5,208,240. That $533,333 difference is why you rebuild NOI yourself.

### Price per unit and price per square foot

Cap rate is the primary valuation tool, but two secondary metrics help you sanity-check a price. Price per unit is the price divided by the number of units. For Maple Court, $4,800,000 ÷ 48 = $100,000 per unit. Price per square foot is the price divided by rentable square footage. If Maple Court has 38,400 rentable square feet (48 units averaging 800 square feet), the price per square foot is $4,800,000 ÷ 38,400 = $125.00. Compare both metrics to recent sales. If a property is far above comparable prices per unit and per square foot, ask why — and demand evidence.

### Going-in, stabilized, and exit cap rates

Three cap rates appear in most underwriting. The going-in cap rate uses current NOI and current price. The stabilized cap rate uses the NOI you expect after your business plan is complete — after renovation, lease-up, and expense control. The exit cap rate is the cap rate you assume when you sell. Prudent underwriting usually assumes an exit cap rate equal to or higher than the going-in cap rate, to reflect the risk that cap rates rise or the property ages. Assuming an exit cap rate lower than today's — that is, assuming the market will pay more for the same income in the future — is optimistic and should be justified with specific evidence, not hope.

**Action steps for Module 4:**

1. Calculate the cap rate for three listed multifamily properties in your market using their stated NOI and asking price.
2. Recalculate each one assuming NOI is 10 percent lower. Note how much the indicated value changes.
3. Write down the cap rate range you are seeing for your target class and submarket, and the source for each data point.

**Exercise:** Complete Exercise 4 in the workbook.

---

## Module 5 — Reading a Rent Roll, T-12, and Offering Memorandum Like an Underwriter

An offering memorandum (OM) is a marketing document. It is designed to sell you a property. A rent roll and a trailing 12-month profit and loss statement (T-12) are operating documents. They are designed to record what actually happened. Learn to read the operating documents first and the marketing document second.

### The rent roll

A rent roll lists every unit, its tenant, its lease start and end dates, its current rent, its market rent, its deposit, and its balance owed. Read it line by line and ask:

- How many units are vacant, and how long have they been vacant?
- How many leases expire in the next 90 days? In the next 12 months? A property where 60 percent of leases expire in one quarter carries rollover risk.
- Are current rents below market rents? By how much, and for how many units? A large gap can be an opportunity — or a sign that the units need work to achieve market rent.
- Are any tenants month-to-month? Are any tenants delinquent, and by how much?
- Are there concessions — free rent, reduced deposits — that make the stated rent look higher than the cash actually collected?
- Do the unit mix and the rent roll match the OM's description? If the OM says 24 two-bedroom units and the rent roll shows 20, stop and ask why.

Reconcile the rent roll to the bank statements. If the rent roll says $55,200 per month in contract rent and the bank statements show $48,000 per month in deposits, find out why. The difference may be vacancy, delinquency, concessions, or something worse. Do not accept an explanation without documentation.

### The T-12

The T-12 shows 12 months of actual income and expense, usually by month and in total. Compare it to the OM's pro forma. Common differences to investigate:

- The OM shows higher other income than the T-12 supports. Ask for the source of each other-income line.
- The OM shows lower expenses than the T-12. Ask which expenses were excluded and why. Management fees, reserves, and one-time items are often treated inconsistently.
- The T-12 shows lumpy expenses — a large repair in one month, no repairs in others. That may be normal, or it may hide deferred maintenance. Ask for a three-year history if you can get it.
- The T-12 shows declining occupancy or rising delinquency. That is a warning sign, not a detail to overlook.

Always ask for the seller's tax returns for the property if they are available. Tax returns are not perfect — owners have incentives to minimize reported income — but they are a useful cross-check. If the tax return shows far less income than the T-12, ask why.

### The offering memorandum

Read the OM for what it tells you about the seller's story: why they are selling, what they have done to the property, what they believe the opportunity is, and what comparable sales and rents they cite. Then verify each claim. Check the comparable sales yourself. Call the property manager of a comparable property. Drive the neighborhood. An OM that cites rents from a newer, better-located property as "comparable" to a 1985 Class B building is not lying in a legal sense, but it is not helping you underwrite accurately either.

Pay attention to what the OM does not say. No mention of deferred maintenance, no discussion of lease expirations, no acknowledgment of a major employer leaving the area — those omissions are information too.

### Red flags in documents

Treat any of the following as a reason to slow down and investigate further: a rent roll that does not reconcile to bank deposits; a T-12 that ends more than 60 days ago with no year-to-date update; expenses that are far below market norms with no explanation; a large share of tenants on month-to-month leases; a single tenant or a single employer that dominates the rent roll; and a seller who will not provide a T-12, a rent roll, or leases before you make an offer. A legitimate seller who wants a fair price will provide documents. A seller who will not is telling you something.

**Action steps for Module 5:**

1. Obtain a sample OM, rent roll, and T-12 — from a broker, a course peer, or a public listing — and read them in that order: rent roll, T-12, then OM.
2. List every number in the OM that you cannot verify from the rent roll or T-12.
3. Write down five questions you would ask the seller or broker before making an offer.

**Exercise:** Complete Exercise 5 in the workbook.

---

## Module 6 — Building a Full Operating Pro Forma, Line by Line

A pro forma is a forward-looking projection of income and expense. It is where underwriting becomes a business plan. A good pro forma is built line by line from verifiable inputs, not copied from the seller's OM. This module builds the Maple Court Year 1 pro forma in full, so you can see every line and test every assumption.

### Income lines

**Gross potential rent (GPR).** Start with the rent roll. For Maple Court: 48 units at an average of $1,150 per month. GPR = 48 × $1,150 × 12 = $662,400. If rents vary by unit type, calculate each type separately. For example, 24 one-bedroom units at $950 and 24 two-bedroom units at $1,350 gives (24 × $950 × 12) + (24 × $1,350 × 12) = $273,600 + $388,800 = $662,400 — the same total, but the mix tells you more about your tenant base and your renovation plan.

**Other income.** Include only income you can document or reasonably support: laundry $6,000, pet fees $7,200, parking $4,800, application and late fees $3,600, storage $2,400 — total $24,000. Do not invent a new income stream in your pro forma unless you have a specific plan and a comparable property that achieves it. Rubs (ratio utility billing systems), for example, can add income, but they also require installation, tenant communication, and compliance with local rules. Model the cost as well as the income.

**Vacancy and credit loss.** Use a market-supported rate, not an optimistic one. This course uses 5 percent of gross potential rent for Maple Court: 0.05 × $662,400 = $33,120. In a market with 95 percent occupancy, 5 percent is reasonable. In a weaker market, 7 to 8 percent may be more honest. Add a separate line for concessions if the property is offering free rent to lease units, and a line for bad debt if delinquency is a known problem.

**Effective gross income (EGI).** EGI = $686,400 − $33,120 = $653,280.

### Expense lines

Use the Maple Court Year 1 expense build below. Each line is stated as an annual amount and, where helpful, as a per-unit amount.

| Expense line | Annual amount | Per unit |
|---|---:|---:|
| Real estate taxes | $52,000 | $1,083 |
| Insurance | $28,800 | $600 |
| Repairs and maintenance | $38,400 | $800 |
| Utilities (owner-paid) | $36,000 | $750 |
| Property management (8% of EGI) | $52,262 | $1,089 |
| Payroll / onsite staff | $24,000 | $500 |
| Marketing and leasing | $9,600 | $200 |
| General and administrative / legal | $7,200 | $150 |
| Reserves for replacement | $14,400 | $300 |
| **Total operating expenses** | **$262,662** | **$5,472** |

Total operating expenses are 40.2 percent of EGI ($262,662 ÷ $653,280). That ratio is within a normal range for Class B multifamily, though it varies by market, age, and utility structure. If your pro forma shows an expense ratio of 25 percent for a 1985 building with owner-paid water, be skeptical. If it shows 60 percent, ask whether expenses are inflated or whether the property has a structural problem.

Check each line against reality:

- **Taxes.** Verify the current tax bill. Check whether a sale will trigger a reassessment. In many jurisdictions, a sale at a higher price can lead to higher taxes. Ask the assessor's office or your attorney how reassessment works in your market, and model the higher tax if it applies.
- **Insurance.** Get a real quote. Insurance costs have risen sharply in many markets. A quote from three years ago is not a quote. If the property is in a flood zone or a high-risk area, the cost can change the deal.
- **Repairs and maintenance.** Older properties cost more. Budget by age, condition, and the inspection report, not by a national average.
- **Management.** Even if you plan to self-manage, include a management fee in your underwriting. If you later hire a manager, the deal still works. If you self-manage, the fee is your compensation for the work. A deal that only works if you work for free is not a good deal.
- **Reserves.** Reserves are not optional. Roofs, boilers, parking lots, and appliances wear out. Budgeting $250 to $350 per unit per year is a common starting range for Class B multifamily. Your lender may require a specific reserve.

### NOI and the sanity check

NOI = $653,280 − $262,662 = $390,618. Before you trust that number, run three sanity checks. First, compare the expense ratio to comparable properties. Second, compare each expense line to the T-12. Third, ask a property manager in the market whether the numbers are realistic. If the manager laughs at your maintenance budget, listen.

### Building Years 2 to 5

A Year 1 pro forma is not enough. Build five years. Grow rents by a supportable rate — for example, 3 percent per year — and grow expenses by a similar or slightly higher rate, since taxes, insurance, and labor often rise faster than rents. Model your renovation plan explicitly: which units, when, at what cost, and what rent increase you expect after each renovation. Model lease-up: renovated units do not lease instantly. Allow for vacancy during renovation and for a lease-up period after.

A simple Year 2 illustration for Maple Court, assuming 3 percent rent growth and 3 percent expense growth and no renovation yet: GPR rises to $682,272, other income to $24,720, vacancy to $34,114, EGI to $672,878, expenses to $270,542, NOI to $402,336. That is a modest increase. The large NOI gains in a value-add plan come from renovation and repositioning, not from assuming high rent growth. That distinction is covered in Module 10.

**Action steps for Module 6:**

1. Build a Year 1 pro forma for a property in your market using the line items above.
2. Compare each expense line to the T-12 and to a property manager's estimate. Note every line where your number differs by more than 15 percent.
3. Build Years 2 through 5 with explicit rent and expense growth rates, and write down the source for each growth rate.

**Exercise:** Complete Exercise 6 in the workbook using the underwriting model template.

---

## Module 7 — Commercial Loans: DSCR, Loan Sizing, and Terms That Matter

Commercial financing rewards borrowers who understand the lender's perspective. A lender is not your partner. A lender is a creditor who wants to be repaid, with interest, on time, even if rents fall or expenses rise. Every term in a commercial loan reflects that priority. Learn to read a loan quote the way a lender reads your deal.

### Debt-service coverage ratio (DSCR)

The debt-service coverage ratio is the lender's central test:

**DSCR = NOI ÷ Annual Debt Service**

Annual debt service is the total of principal and interest payments for the year. A DSCR of 1.25x means NOI is 25 percent higher than the debt payments. A DSCR of 1.00x means NOI exactly covers the debt payments, with nothing left over. Most multifamily lenders require a minimum DSCR of 1.20x to 1.30x on the loan they approve. Some require higher coverage for older properties, weaker markets, or shorter loan terms.

Maple Court, worked in full: NOI is $390,618. The proposed loan is $3,360,000 — 70 percent of the $4,800,000 purchase price — at 6.25 percent interest with a 30-year amortization. The monthly payment is approximately $20,691, calculated from the standard amortization formula. Annual debt service is $20,691 × 12 = $248,292. DSCR = $390,618 ÷ $248,292 = 1.57x. That comfortably exceeds a 1.25x minimum. It tells the lender that even if NOI fell by 20 percent, to $312,494, the DSCR would still be 1.26x. That cushion matters.

Now test the other direction. Suppose a buyer tried to borrow 80 percent, or $3,840,000, on the same terms. The monthly payment would be approximately $23,647, annual debt service $283,764, and DSCR would be $390,618 ÷ $283,764 = 1.38x — still above 1.25x, but with less cushion. Suppose instead the interest rate were 7.50 percent on the $3,360,000 loan. The monthly payment would be approximately $23,494, annual debt service $281,928, and DSCR would be 1.39x. Interest rates change DSCR quickly. Always test your DSCR at a higher rate than the quoted rate, to see how much room you have.

### How lenders size a loan

Lenders size a loan using the lower of two constraints: the loan-to-value (LTV) limit and the DSCR limit. The LTV limit is a percentage of the price or appraised value — commonly 65 to 75 percent for multifamily. The DSCR limit is the largest loan whose debt service still meets the minimum DSCR at the lender's test rate, which is often higher than the quoted rate.

Worked example: NOI $390,618, minimum DSCR 1.25x. Maximum annual debt service allowed = $390,618 ÷ 1.25 = $312,494, or $26,041 per month. At 6.25 percent and 30-year amortization, the loan that produces a $26,041 monthly payment is approximately $4,225,000. That is the DSCR-constrained maximum. The LTV-constrained maximum at 70 percent of $4,800,000 is $3,360,000. The lender will offer the lower of the two — $3,360,000 in this case. The DSCR constraint binds when rates are high or NOI is low. The LTV constraint binds when the price is high relative to NOI. Know which one binds on your deal, because it tells you what would have to change to borrow more: higher NOI, a lower price, or a lower rate.

### Loan terms that matter

- **Interest rate and type.** Fixed rates give certainty. Floating rates can be lower at first and higher later. Understand which you have and what happens if rates rise.
- **Amortization period.** A 30-year amortization gives lower payments than a 25-year amortization, but builds equity more slowly. A 20-year amortization gives higher payments and a higher DSCR requirement. Some loans have an interest-only period, which lowers payments at first and defers principal repayment. Do not mistake lower payments for a better deal without understanding the trade-off.
- **Term and maturity.** The term is how long until the loan must be repaid or refinanced — commonly 5, 7, or 10 years for commercial loans, even when the amortization is 30 years. That mismatch creates refinance risk: you must refinance or sell at maturity. Plan for it from day one.
- **Prepayment penalties.** Yield maintenance and defeasance can make early repayment very expensive. Step-down prepayment penalties decline over time. Know your penalty before you sign, and model your exit around it.
- **Recourse and guarantees.** Many commercial loans require a personal guarantee from the sponsor. Some agency loans are non-recourse with standard carve-outs for fraud and misrepresentation. Understand exactly what you are guaranteeing.
- **Reserves and escrows.** Lenders often require monthly deposits for taxes, insurance, and replacement reserves. Those deposits are real cash outflows. Include them in your cash-flow projection.
- **Covenants and reporting.** Lenders require quarterly or annual financial statements, rent rolls, and sometimes occupancy reporting. Missing a reporting deadline can be a default. Build reporting into your asset-management calendar.

### Agency, bank, and bridge loans

Agency loans — from Fannie Mae and Freddie Mac multifamily programs — are a common choice for stabilized multifamily. They often offer competitive rates and longer terms, but they have strict underwriting, property condition, and borrower requirements, and the process takes longer. Bank and credit-union loans can be faster and more flexible, especially for smaller properties, but they may have shorter terms and floating rates. Bridge loans are short-term, higher-cost loans used for value-add deals that do not yet qualify for permanent financing. They can be the right tool for a heavy renovation, but they carry refinance risk: if the renovation or lease-up takes longer than planned, you may need an extension or a new loan on worse terms. Never use a bridge loan without a realistic plan and a backup plan for permanent financing.

### The loan application package

Prepare a package before you approach lenders: the property's T-12, rent roll, leases, your pro forma, your business plan, your personal financial statement, your real estate experience, and your entity documents. Lenders respond faster and quote better terms to borrowers who are organized. Get quotes from at least three lenders and compare them on rate, fees, term, amortization, prepayment, and reserve requirements — not on rate alone.

**Action steps for Module 7:**

1. For a property you are underwriting, calculate DSCR at the quoted rate and at a rate 1 percent higher.
2. Calculate the DSCR-constrained maximum loan and the LTV-constrained maximum loan. Identify which one binds.
3. List the loan terms you will accept and the terms you will not accept, before you speak to a lender.

**Exercise:** Complete Exercise 7 in the workbook.

---

## Module 8 — The Full Multifamily Underwriting Walkthrough: Maple Court, 48 Units

This module puts Modules 4 through 7 together in a single, complete underwriting. Follow each step in order. When you underwrite your own deal, use the same steps and the underwriting model template.

### Step 1 — The property and the asking price

Maple Court is a fictional 48-unit apartment community, built in 1985, brick construction, 38,400 rentable square feet, averaging 800 square feet per unit. The mix is 24 one-bedroom units and 24 two-bedroom units. The asking price is $4,800,000, or $100,000 per unit and $125.00 per square foot. The seller describes it as a Class B value-add opportunity with rents below market.

### Step 2 — Verify income

The rent roll shows 46 of 48 units occupied, a 95.8 percent occupancy rate. Contract rents average $1,150 per month. Two units are vacant, one for 30 days and one for 60 days. No tenant is more than 30 days delinquent. Four leases expire in the next 90 days. Market rent for comparable renovated two-bedroom units nearby is $1,300 to $1,350. Unrenovated two-bedroom units nearby rent for $1,150 to $1,200. That tells you the seller's claim of below-market rents is partly true: renovated units command more, but unrenovated units do not command much more than current rents. Your value-add plan must include the renovation cost to achieve the higher rent.

Gross potential rent: 48 × $1,150 × 12 = $662,400. Other income, verified from the T-12: $24,000. Gross potential income: $686,400. Vacancy and credit loss at 5 percent of GPR: $33,120. Effective gross income: $653,280.

### Step 3 — Verify expenses

The seller's OM shows operating expenses of $225,000, an expense ratio of 34.5 percent. Your rebuild, using the T-12, tax bills, insurance quotes, and a property manager's estimate, shows $262,662, an expense ratio of 40.2 percent. The difference is $37,662. The seller omitted a management fee on the theory that a buyer would self-manage, understated insurance by $8,000, and included no reserves. You use your number, not the seller's. Your NOI is $390,618. The seller's stated NOI, using their expenses, would have been $428,280 — a difference that, at a 7.5 percent cap rate, is worth more than $500,000 in value. This is why you rebuild NOI.

### Step 4 — Value the property

Going-in cap rate at the asking price: $390,618 ÷ $4,800,000 = 8.14 percent. If the market cap rate for comparable Class B properties is 7.5 percent, the indicated value is $390,618 ÷ 0.075 = $5,208,240. If the market cap rate is 8.0 percent, the indicated value is $4,882,725. If it is 8.5 percent, the indicated value is $4,595,506. Your offer should reflect your verified NOI, your cap-rate research, the condition of the property, and the cost of your business plan — not the seller's asking price alone.

### Step 5 — Size the loan and test DSCR

Loan: $3,360,000, 70 percent LTV, 6.25 percent, 30-year amortization. Monthly payment approximately $20,691. Annual debt service $248,292. DSCR 1.57x. That passes a 1.25x minimum comfortably. At a 7.25 percent test rate, the monthly payment would be approximately $22,895, annual debt service $274,740, DSCR 1.42x — still passing. The loan is not the constraint on this deal. The price and the renovation budget are.

### Step 6 — Cash flow and cash-on-cash

Cash flow after debt service: $390,618 − $248,292 = $142,326 per year, or $11,861 per month. Total cash invested: $1,440,000 down payment plus approximately $120,000 in closing costs, for $1,560,000. Cash-on-cash return in Year 1: $142,326 ÷ $1,560,000 = 9.12 percent. That is before renovation costs, which are modeled separately in Module 10. A buyer who ignores renovation costs will overstate Year 1 cash flow. A buyer who models them will see a lower Year 1 return and a higher stabilized return — which is the honest picture.

### Step 7 — Sensitivity: what if you are wrong?

Test three downside cases.

- **Rents 5 percent lower than expected.** GPR falls to $629,280. EGI falls to approximately $621,984 (holding other income and vacancy constant on the lower rent base). NOI falls to approximately $359,322, assuming expenses are unchanged. DSCR falls to 1.45x. Cash flow falls to $111,030. Cash-on-cash falls to 7.12 percent. The deal still works, but the margin is thinner.
- **Expenses 10 percent higher.** Expenses rise to $288,928. NOI falls to $364,352. DSCR falls to 1.47x. Cash flow falls to $116,060. Cash-on-cash falls to 7.44 percent.
- **Occupancy falls to 90 percent.** Vacancy rises to 10 percent of GPR, or $66,240. EGI falls to $620,160. NOI falls to $357,498. DSCR falls to 1.44x. Cash flow falls to $109,206. Cash-on-cash falls to 7.00 percent.

None of these cases breaks the deal at the asking price, which is a good sign. A deal that only works in the best case is not a deal. A deal that still works in a plausible downside case deserves a closer look. Run the same sensitivity on every deal you underwrite, and write down the assumptions that would have to be true for the deal to fail. If those assumptions are plausible, walk away or renegotiate.

### Step 8 — The decision

On these numbers, Maple Court deserves an offer — at a price that reflects your verified NOI, the renovation cost, and your required return. Whether that offer is $4,800,000, $4,600,000, or $4,400,000 depends on the renovation budget, the inspection findings, and your cap-rate research. The underwriting does not tell you the price. It tells you the range of prices at which the deal meets your criteria, and it gives you the evidence to negotiate within that range.

**Action steps for Module 8:**

1. Rebuild this walkthrough in the underwriting model template, changing one assumption at a time to see which assumption matters most.
2. Write a one-page underwriting summary for Maple Court: price, NOI, cap rate, DSCR, cash-on-cash, and the three downside cases.
3. List the five pieces of information you would still need before making an offer.

**Exercise:** Complete Exercise 8 in the workbook.

---

## Module 9 — Returns That Matter: Cash-on-Cash, IRR, Equity Multiple, and Yield on Cost

Cash-on-cash return tells you what a property pays you in a single year relative to the cash you invested. It does not tell you what happens over five years, what happens when you sell, or what happens when you refinance. For that, you need internal rate of return (IRR), equity multiple, and yield on cost. This module teaches all four, using Maple Court numbers so you can compare them directly.

### Cash-on-cash return

**Cash-on-Cash = Annual Cash Flow After Debt Service ÷ Total Cash Invested**

For Maple Court in Year 1, before renovation: $142,326 ÷ $1,560,000 = 9.12 percent. Cash-on-cash is simple and useful for comparing Year 1 performance across deals. Its limits are that it ignores appreciation, loan paydown, tax benefits, and what happens in later years. A property with a 9 percent cash-on-cash return and no growth is different from a property with a 6 percent Year 1 return that grows to 12 percent by Year 5. You need the multi-year measures to see that difference.

### Equity multiple

**Equity Multiple = Total Cash Returned (Distributions + Sale Proceeds) ÷ Total Cash Invested**

If you invest $1,560,000, receive $750,000 in cash distributions over five years, and receive $1,950,000 at sale after paying off the loan and sale costs, your total cash returned is $2,700,000 and your equity multiple is $2,700,000 ÷ $1,560,000 = 1.73x. That means you received your capital back plus 73 percent profit. Equity multiple is easy to understand and easy to compare. Its limit is that it ignores timing: a 1.73x return in three years is better than a 1.73x return in ten years, but the multiple alone does not show that.

### Internal rate of return (IRR)

IRR is the annualized rate of return that accounts for the timing of every cash flow — the initial investment, the annual distributions, and the sale proceeds. It is the standard measure for comparing investments with different timing. A deal with a higher IRR is not automatically better — IRR is sensitive to assumptions, especially the sale price and the sale year — but it is the measure most sponsors and investors use to compare opportunities.

A simplified Maple Court IRR illustration, using stated assumptions only: invest $1,560,000 at closing plus $480,000 in renovation costs spread over Year 1, receive annual cash flow that grows from approximately $90,000 in Year 1 (after renovation disruption) to $210,000 by Year 5, and sell at the end of Year 5 for a price based on stabilized NOI of approximately $455,000 at a 7.5 percent exit cap rate, or $6,066,667, less sale costs and the remaining loan balance. Under those assumptions, the modeled IRR is in the mid-teens. The exact figure depends on the timing of renovation spending, the lease-up pace, and the sale costs — which is why you should always ask a sponsor for the full cash-flow table behind an IRR, not just the headline number. If a sponsor will not show you the cash flows, do not trust the IRR.

### Yield on cost

**Yield on Cost = Stabilized NOI ÷ Total Cost (Purchase Price + Renovation + Closing Costs)**

For Maple Court after renovation: stabilized NOI of approximately $455,000 divided by total cost of $4,800,000 + $480,000 + $120,000 = $5,400,000 gives a yield on cost of 8.43 percent. Compare that to the market cap rate. If yield on cost is higher than the market cap rate, your renovation created value. If it is lower, you spent more than the income justifies. Yield on cost is one of the clearest tests of a value-add plan.

### How to compare deals honestly

Use all four measures together. Cash-on-cash tells you Year 1. Equity multiple tells you total profit. IRR tells you timing-adjusted return. Yield on cost tells you whether the business plan creates value. A deal that looks good on one measure and poor on the others deserves scrutiny. And always ask: what assumptions drive the return? If the return depends on 5 percent annual rent growth for five years, that is a different deal from one that works at 2 percent rent growth. Write down the assumptions and test them.

**Action steps for Module 9:**

1. Calculate cash-on-cash, equity multiple, and yield on cost for Maple Court using the numbers in this module.
2. For a deal you are considering, build a five-year cash-flow table and calculate the IRR using a spreadsheet. Change the exit cap rate by 0.5 percent and note how much the IRR moves.
3. Write down the minimum cash-on-cash, equity multiple, and IRR you will accept, and the conditions under which you would accept less.

**Exercise:** Complete Exercise 9 in the workbook.

---

## Module 10 — Value-Add Strategy: Renovation, Repositioning, and Rent Growth

Value-add investing means buying a property below its potential, improving it, and earning higher income as a result. It is the most common strategy for first-time commercial sponsors, and it is also the strategy most often done badly — because the renovation budget, the rent increase, and the lease-up timeline are all estimated optimistically at the same time.

### What value-add actually means

Value-add can include interior renovation (flooring, kitchens, bathrooms, fixtures, paint), exterior and common-area work (landscaping, signage, lighting, laundry room, fitness area, dog park), operational improvements (better management, online payments, utility billing, expense control), and repositioning (changing the tenant mix, the marketing, or the property's identity). It does not include ground-up development or major structural work. If the property needs a new foundation, a full re-plumbing, or a zoning change, that is a different strategy with different risks.

### The Maple Court value-add plan, in numbers

The plan: renovate all 48 units over 18 months at $10,000 per unit, for $480,000, plus $60,000 in common-area work, for a total renovation budget of $540,000. Renovate six units at a time, so that no more than six units are vacant for renovation at once. Raise renovated rents from $1,150 to $1,300 per month, an increase of $150. Leave unrenovated rents at $1,150 until their turn.

At full stabilization, after all 48 units are renovated: GPR = 48 × $1,300 × 12 = $748,800. Other income rises to $28,800 with added pet and parking income. Gross potential income = $777,600. Vacancy at 5 percent of GPR = $37,440. EGI = $740,160. Operating expenses rise modestly — management at 8 percent of EGI is $59,213, taxes and insurance rise slightly — to approximately $285,000. Stabilized NOI is approximately $455,000. At a 7.5 percent cap rate, the stabilized value is $455,000 ÷ 0.075 = $6,066,667. Total cost is $4,800,000 purchase + $540,000 renovation + $120,000 closing = $5,460,000. The value created, on these assumptions, is approximately $606,667 before sale costs and before the time and risk involved. Yield on cost is $455,000 ÷ $5,460,000 = 8.33 percent, above the 7.5 percent market cap rate, which is the test that the plan creates value.

Those numbers are illustrative. Your job is to test each one. Is $10,000 per unit enough for the scope you have in mind? Get contractor bids. Is $150 of rent increase supported by comparable renovated properties? Tour them. Can you renovate six units at a time without disrupting occupied tenants? Ask your contractor and your property manager. Will it really take 18 months? Ask for a schedule with milestones, and add a contingency.

### The three value-add mistakes

The first mistake is under-budgeting renovation. Add a contingency of 10 to 15 percent to the contractor's estimate, and a separate budget for items the inspection reveals. The second mistake is overestimating the rent increase. Test it against real comparable properties, not against the nicest property in the submarket. The third mistake is underestimating lease-up time. Renovated units do not lease the day the paint dries. Budget for 30 to 60 days of vacancy per renovated unit, and for marketing costs to fill them.

### Operational value-add

Not all value is created with a hammer. Better management can raise income and cut waste: collecting delinquent rent, enforcing late fees, reducing vacancy through faster turnovers, renegotiating vendor contracts, installing water-saving fixtures, and billing back utilities where the law allows. These improvements are less visible than a new kitchen, but they are often more reliable. Include them in your business plan, but do not double-count them: if you assume both a large rent increase and a large expense reduction, you may be assuming the same improvement twice.

### When value-add is the wrong strategy

Value-add is wrong when the property is already renovated and rents are already at market, when the renovation cost exceeds the value it creates, when the submarket cannot support higher rents, or when you do not have the team to execute the renovation. In those cases, a stabilized purchase or a passive investment may be a better fit. The discipline is to let the numbers decide, not your enthusiasm for a renovation.

**Action steps for Module 10:**

1. For a target property, list every renovation item, its cost, and the rent increase you expect it to support — item by item, not as a single lump sum.
2. Tour three comparable renovated properties and record their rents, their finishes, and their occupancy.
3. Build a month-by-month renovation and lease-up schedule, and identify the month when the property reaches stabilization.

**Exercise:** Complete Exercise 10 in the workbook.

---

## Module 11 — Due Diligence: Physical, Financial, Legal, and Market Verification

Due diligence is the period after you sign a purchase agreement and before you close, when you verify everything the seller told you. It is your last chance to find problems before your money is committed. Treat it as a discipline, not a formality. A thorough due diligence process has four parts: physical, financial, legal, and market.

### Physical due diligence

Hire a licensed inspector experienced in commercial properties, and be present for the inspection. The inspection should cover the roof, the structure, the electrical and plumbing systems, the HVAC, the water heaters, the parking lot, the drainage, and the common areas. It should also cover environmental issues: an environmental site assessment (Phase I) is standard for commercial purchases and is often required by the lender. If the Phase I identifies a concern, a Phase II investigation may be needed.

Walk every unit, or as many as access allows. Look for water damage, mold, deferred maintenance, and signs of pest problems. Check the age and condition of major systems and ask for their service records. A roof with five years of life left is a different purchase from a roof that needs replacement next year. Price the difference into your offer or your renovation budget.

### Financial due diligence

Reconcile the rent roll to the leases and to the bank statements. Verify every lease: the tenant, the rent, the term, the deposit, and any concessions. Review the T-12 and the year-to-date financials. Review the tax returns if available. Check the property tax bill and whether a reassessment is likely. Obtain insurance quotes. Review every service contract: landscaping, pest control, trash, laundry, elevator, and any other vendor agreement. Some contracts can be cancelled. Some cannot, and some have automatic renewal clauses. Know which is which before you close.

Review the security deposit accounting. Deposits are tenant funds, not seller income. Confirm that deposits will be credited to you at closing and that the amounts match the leases. Review any outstanding tenant balances and any pending evictions. Review the utility bills for 12 months to understand owner-paid costs.

### Legal due diligence

Your attorney should review the title report, the survey, the zoning, the leases, the entity documents, and any easements or restrictions. Confirm that the property's current use conforms to zoning and that there are no outstanding code violations. Review any pending litigation involving the property or the seller. If you are assuming any contracts or leases, understand exactly what you are assuming.

If the property has rent control, rent stabilization, or other local regulations that limit rent increases, understand them fully before you underwrite a rent increase. A value-add plan that assumes a $150 rent increase is worthless if the law caps increases at a lower amount. Your attorney and your property manager should both confirm the rules for your jurisdiction.

### Market due diligence

Drive the submarket at different times of day. Talk to property managers, brokers, and tenants. Check occupancy and rents at comparable properties. Check permit data for new supply. Check major employers: are they hiring, stable, or leaving? Check schools, crime, and infrastructure projects. A property can be well-underwritten and still be a poor investment if the submarket is declining.

### The due diligence calendar

Build a calendar with deadlines for each item: inspection, environmental report, appraisal, loan commitment, title review, and lease audit. Assign each item to a person and a date. If an item is late, find out why. Do not let the closing date force you to skip a check. It is better to extend the due diligence period — if the contract allows it — than to close with an unanswered question that costs you later.

### Walking away

Due diligence sometimes reveals a reason to walk away: a structural problem, an environmental issue, a rent roll that does not reconcile, or a market that is weaker than you believed. Walking away during due diligence is not failure. It is the system working. The cost of walking away is the cost of the inspection and the reports. The cost of closing on a bad deal is far larger.

**Action steps for Module 11:**

1. Build a due diligence checklist for your next deal using the four categories in this module.
2. Identify the inspector, environmental firm, appraiser, and attorney you will use, and confirm their availability and fees before you make an offer.
3. Write down the conditions under which you would walk away from a deal during due diligence.

**Exercise:** Complete Exercise 11 in the workbook.

---

## Module 12 — Syndication Structures: Entities, Splits, and Waterfalls

Syndication means pooling capital from multiple investors to buy a property that is too large for one buyer. The sponsor — also called the general partner, or GP — finds the deal, structures it, raises the capital, and manages the asset. The investors — the limited partners, or LPs — provide most of the capital and receive reporting, but do not manage the property. This module explains the structure. Module 13 works the waterfall math in full. Module 14 covers capital raising.

### The entity

Most syndications use a limited liability company (LLC) or a limited partnership (LP) as the owning entity. The sponsor controls the managing entity. The investors hold interests in the owning entity. The operating agreement — or partnership agreement — is the governing document. It sets out who can make decisions, how cash is distributed, what fees the sponsor receives, what happens if the business plan changes, and how the entity is dissolved. Have a securities attorney and a real estate attorney draft or review it. Do not use a template you found online as your final document.

### The capital stack

A typical capital stack has debt and equity. The debt is the commercial loan. The equity is the cash invested by the sponsor and the limited partners. In some deals there is also preferred equity or mezzanine debt, which sits between the senior loan and the common equity. Each layer has a different risk and a different return. The senior lender is paid first and takes the least risk. The common equity is paid last and takes the most risk — and expects the highest return for it.

A sponsor co-investment is standard and important. Investors want to see the sponsor invest their own money alongside them. A sponsor who invests 5 to 10 percent of the equity is showing alignment: they share the downside as well as the upside. Ask any sponsor you consider investing with how much of their own capital is in the deal.

### Fees

Sponsors are compensated through fees and through a share of the profits. Common fees include an acquisition fee (often 1 to 3 percent of the purchase price), an asset management fee (often 1 to 2 percent of effective gross income or of collected revenue per year), and sometimes a disposition fee on sale. Some sponsors also charge a construction or renovation management fee. Fees are not inherently good or bad. They compensate the sponsor for work. But they must be disclosed clearly, they must be reasonable for the work performed, and they must be stated in the offering documents. A deal with high fees and a low sponsor co-investment deserves extra scrutiny.

### The preferred return and the split

The preferred return — often called the "pref" — is a target return paid to the limited partners before the sponsor shares in the profits. A common pref is 7 or 8 percent per year on invested capital, paid from operating cash flow when available. The pref is a preference, not a guarantee. If the property does not earn enough to pay the pref in a given year, the unpaid amount may accrue and be paid later from a sale or refinance, or it may not, depending on the agreement. Read the agreement to understand whether the pref is cumulative.

After the pref is paid, remaining cash flow is split between the LPs and the GP according to the agreed split — commonly 70 percent to the LPs and 30 percent to the GP, or 80/20. Above a higher return threshold, the split may shift further in the sponsor's favor — for example, 50/50 above a 15 percent IRR. That shift is called a promote, and it is the sponsor's incentive to outperform. The full waterfall is worked in Module 13.

### Securities law: the essential warning

Pooling investor capital is generally a securities offering under U.S. law, and it is regulated by the Securities and Exchange Commission and by state regulators. There are exemptions — most commonly Regulation D, Rules 506(b) and 506(c) — that allow private offerings under specific conditions, including limits on advertising, limits on who can invest, and requirements for disclosure and filings. The differences between those rules matter, and getting them wrong can have serious consequences. This course does not provide securities advice and does not tell you which exemption to use. Before you raise capital from anyone, engage a securities attorney, follow their advice, and do not advertise an investment or accept funds until they have reviewed your structure and documents.

### Evaluating a syndication as a limited partner

If you invest passively, evaluate four things: the sponsor (their track record, their communication, their co-investment, and their references), the market (supply, demand, employment, and rent growth), the business plan (is it realistic, and what has to go right?), and the terms (fees, pref, split, hold period, and reporting). Ask for the sponsor's prior deals, including the ones that did not go well, and how they handled them. A sponsor who will not discuss a difficult deal is a sponsor who has not learned from one — or who does not want you to know.

**Action steps for Module 12:**

1. Read a sample syndication operating agreement summary or offering memorandum and identify the fees, the pref, and the split.
2. Write down the questions you would ask a sponsor before investing as a limited partner.
3. If you plan to sponsor, list the attorneys and CPAs you will engage before you speak to any investor.

**Exercise:** Complete Exercise 12 in the workbook.

---

## Module 13 — The Syndication Waterfall, Worked in Full

A waterfall is the set of rules that determines how cash is distributed among investors and the sponsor. It is called a waterfall because cash flows down through a series of tiers: each tier must be filled before cash flows to the next. This module works a complete example using the Maple Court numbers adapted for a syndication. The numbers are illustrative. Your deal's numbers will differ, and your attorney must review your waterfall.

### The deal setup

A sponsor forms an LLC to acquire Maple Court for $4,800,000. Total project cost is $5,460,000: $4,800,000 purchase, $540,000 renovation, $120,000 closing costs. The capital stack is: a commercial loan of $3,360,000 (70 percent of the purchase price) and total equity of $2,100,000. Of that equity, the limited partners contribute $1,995,000 (95 percent) and the sponsor co-invests $105,000 (5 percent). The sponsor also receives an acquisition fee of 2 percent of the purchase price, or $96,000, paid at closing from the capital raised, and an asset management fee of 1.5 percent of effective gross income per year.

The distribution waterfall is:

- **Tier 1 — Return of capital and preferred return.** Operating cash flow is distributed to the LPs until they have received an 8 percent preferred return on their invested capital.
- **Tier 2 — 70/30 split.** After the pref is paid, remaining operating cash flow is split 70 percent to the LPs and 30 percent to the GP, until the LPs have achieved a 12 percent IRR.
- **Tier 3 — 50/50 split.** After the LPs have achieved a 12 percent IRR, remaining cash flow is split 50 percent to the LPs and 50 percent to the GP.

Sale proceeds follow the same waterfall after the loan is repaid and sale costs are paid: return of unreturned capital first, then unpaid pref, then the splits above.

### Year 1 operating cash flow

Assume Year 1 stabilized operating cash flow after renovation disruption is $120,000 available for distribution (NOI of approximately $368,000 less debt service of $248,292, rounded for this illustration). The 8 percent pref on LP capital of $1,995,000 is $159,600 per year. Year 1 cash flow of $120,000 is less than the pref, so all $120,000 goes to the LPs and $39,600 of pref is unpaid and accrues. The GP receives no distribution from Tier 2 or Tier 3 in Year 1, though the GP does receive the asset management fee for managing the property, which is an operating expense, not a distribution.

### A stabilized year

Assume a stabilized year with $200,000 available for distribution. The pref for that year is $159,600, plus the $39,600 accrued from Year 1, for a total pref obligation of $199,200. The first $199,200 goes to the LPs. The remaining $800 is split 70/30: $560 to the LPs and $240 to the GP. In that year, the LPs receive $199,760 and the GP receives $240 in distributions, plus the asset management fee. The GP's distribution is small because the pref and the catch-up consumed almost all of the cash flow. That is how a pref protects LPs in the early years.

### A strong year

Assume a strong year with $300,000 available for distribution and no accrued pref outstanding. The pref of $159,600 goes to the LPs. The remaining $140,400 is split 70/30 until the LPs reach a 12 percent IRR. For this illustration, assume the full $140,400 falls in Tier 2: $98,280 to the LPs and $42,120 to the GP. Total for the year: LPs receive $257,880 and the GP receives $42,120 in distributions. If the LPs had already passed the 12 percent IRR threshold, the amount above that threshold would be split 50/50 instead.

### The sale

Assume the property is sold at the end of Year 5 for $6,066,667, based on stabilized NOI of $455,000 at a 7.5 percent exit cap rate. Sale costs are 3 percent, or $182,000. The remaining loan balance after five years of amortization at 6.25 percent on a 30-year schedule is approximately $3,130,000. Net sale proceeds are $6,066,667 − $182,000 − $3,130,000 = $2,754,667. That amount is distributed through the waterfall: first, return of unreturned capital — the LPs' $1,995,000 and the sponsor's $105,000, for $2,100,000. That leaves $654,667. Next, any unpaid pref is paid. Then the remaining amount is split according to the tiers. On these assumptions, the LPs receive the majority of the sale proceeds and the GP receives a promote for the performance above the thresholds.

The exact split depends on the cumulative cash flows and the IRR calculation at sale, which is why the waterfall must be modeled in a spreadsheet with the actual annual cash flows, not estimated from a single year. Build the model, test it, and have your attorney and CPA review it before you present it to investors.

### What to check in any waterfall

When you review a sponsor's waterfall, check: whether the pref is cumulative or non-cumulative; whether the GP receives a distribution before the pref is paid; whether the asset management fee is charged on gross income, collected income, or NOI, and whether it is paid even in a year when the pref is not met; whether the acquisition fee is included in the capital raised or paid separately; and how the promote is calculated — on IRR, on equity multiple, or on both. Each of those details changes who gets paid, when, and how much. If you cannot explain the waterfall to another person in plain language, you do not understand it well enough to invest in it or to offer it.

**Action steps for Module 13:**

1. Build the Maple Court waterfall in a spreadsheet using the tiers in this module.
2. Change the stabilized cash flow by 20 percent in each direction and note how the LP and GP distributions change.
3. Write a one-paragraph plain-language explanation of the waterfall that you could give to a prospective investor.

**Exercise:** Complete Exercise 13 in the workbook.

---

## Module 14 — Capital Raising: Finding, Qualifying, and Communicating with Investors

Capital raising is relationship work before it is transaction work. Investors invest in people they trust, in deals they understand, and in sponsors who communicate clearly. No script or template replaces that trust. This module teaches the process, the communication, and the boundaries. It does not teach you how to evade securities law. The legal boundaries in Module 12 apply here in full: engage a securities attorney before you raise capital, and follow their advice on who you may speak to, what you may say, and what you may show them.

### Who your investors are

For a first syndication, investors are often people you already know: colleagues, fellow investors, friends, and family who are accredited or otherwise eligible under the exemption your attorney advises you to use, and who understand real estate risk. They are not strangers from the internet. They are people who have seen you operate, who know your track record in residential investing, and who have the capital and the risk tolerance to invest in an illiquid, multi-year deal.

Before you speak to anyone about a specific deal, understand the investor categories that matter under securities law. An accredited investor generally meets income or net-worth thresholds set by regulation. A sophisticated investor may not meet those thresholds but has sufficient knowledge and experience to evaluate the investment. The exemption you use determines who may invest and what you must disclose. Your attorney will advise you on the definitions that apply to your offering. Do not assume someone qualifies because they are wealthy, experienced, or enthusiastic. Verify eligibility through the process your attorney prescribes.

### The capital-raising conversation

A good capital-raising conversation is not a sales pitch. It is a structured discussion with four parts. First, listen: what is the investor's experience with real estate, what is their time horizon, what return are they seeking, and what risks concern them? Second, explain the deal in plain language: the property, the market, the business plan, the capital stack, the fees, the waterfall, and the risks. Third, provide the documents: the offering memorandum, the operating agreement, the subscription documents, and the financial model — all reviewed by your attorney. Fourth, give them time. A legitimate investment does not require a decision today. Pressure is a warning sign, whether you are the one applying it or the one feeling it.

Be honest about what you do not know. If an investor asks a question you cannot answer, say so, find the answer, and follow up in writing. Investors remember honesty more than they remember polish.

### What to communicate, and how often

Investors expect regular, honest reporting. A common standard is a monthly or quarterly update with occupancy, collections, renovation progress, financial statements, and a candid assessment of how the business plan is tracking against the original underwriting. When something goes wrong — and something will go wrong — report it early, explain what you are doing about it, and update the forecast. Investors can tolerate bad news. They cannot tolerate surprise.

Keep a record of every investor communication. Keep your investor list organized, with contact information, eligibility notes from your attorney's process, and a record of what each investor received and when. That discipline protects you and your investors.

### Common capital-raising mistakes

The most common mistakes are: speaking to investors before engaging a securities attorney; advertising a specific return as if it were guaranteed; raising money from people who cannot afford to lose it or who do not understand the illiquidity; under-disclosing fees; and over-promising on timeline. Each of those mistakes can damage your reputation, your deal, or your legal position. Avoid them by moving slowly, documenting everything, and letting your attorney set the boundaries.

### Building an investor pipeline before you need it

Start building relationships before you have a deal. Attend local real estate meetings. Share what you are learning. Publish a short monthly update on your market research — not a deal, not an offering, just education. Over time, people who are interested in commercial real estate will find you. When you do have a deal, you will not be starting from zero. That pipeline is built over months and years, not in a weekend.

**Action steps for Module 14:**

1. List 20 people in your network who invest in real estate or who have expressed interest in it. Note what you know about each person's experience and interests.
2. Write a one-page summary of your background and your investment approach that you could share in a general conversation, without mentioning a specific deal or return.
3. Schedule a consultation with a securities attorney to discuss the capital-raising process before you speak to any investor about a deal.

**Exercise:** Complete Exercise 14 in the workbook — the capital-raising worksheet.

---

## Module 15 — The Investor Presentation and the Data Room

An investor presentation is not a brochure. It is a decision document. Its job is to give a prospective investor everything they need to evaluate the deal, the sponsor, and the risks — in a form they can read, question, and discuss with their own advisors. A data room is the organized collection of documents that supports the presentation. Together, they are how a professional sponsor shows their work.

### The presentation structure

A complete investor presentation, using the template in this course, includes:

1. **Cover and summary.** The property, the location, the purchase price, the total capital required, the hold period, and the investment highlights — in one page.
2. **The sponsor.** Who you are, your track record, your team, your co-investment, and your references. Be specific. "Ten years of residential investing, 12 units owned and managed, two value-add renovations completed" is more useful than "experienced investor."
3. **The market.** The submarket, the employers, the demographics, the occupancy, the rent trends, and the new supply. Use data with sources and dates.
4. **The property.** The unit mix, the condition, the photos, the rent roll summary, and the deferred maintenance. Show the property honestly, including its flaws.
5. **The business plan.** What you will do, when, at what cost, and what income you expect as a result. Show the renovation schedule and the lease-up plan.
6. **The financials.** The Year 1 pro forma, the five-year projection, the sources and uses of funds, the loan terms, the DSCR, the cash-on-cash, the equity multiple, and the IRR — with the assumptions stated and the downside cases shown.
7. **The structure and the waterfall.** The entity, the fees, the pref, the split, and the promote, explained in plain language with a worked example.
8. **The risks.** The specific risks of this deal: market risk, renovation risk, lease-up risk, interest-rate risk, and the risk of loss. Do not hide the risks in fine print. State them clearly.
9. **The timeline and the next steps.** The closing date, the funding date, and what you need from the investor and by when.
10. **Disclaimers and advisor notes.** A clear statement that the presentation is education and information, not investment advice, and that the investor should consult their own attorney, CPA, and financial advisor.

### The data room

A data room is a secure folder — physical or digital — that contains the documents behind the presentation: the OM, the rent roll, the T-12, the leases, the inspection report, the environmental report, the appraisal, the loan term sheet, the operating agreement, the subscription documents, and the financial model. Organize it with a table of contents. Do not send the full data room to every person who expresses interest. Provide it to qualified prospective investors under the process your attorney advises, and track who received what.

### Presenting with honesty

The best presentations are honest about uncertainty. Show the base case, the downside case, and the upside case. Show what has to go right for the base case to happen. If an investor asks a question you cannot answer, say so and follow up. If the numbers do not support the story you want to tell, change the story or change the deal — not the numbers.

**Action steps for Module 15:**

1. Draft an investor presentation outline for Maple Court using the ten sections above.
2. Build a data-room table of contents for a deal you are considering.
3. Practice presenting the deal in 15 minutes, with five minutes for questions, to a colleague or advisor who will challenge your assumptions.

**Exercise:** Complete Exercise 15 in the workbook — the investor-presentation outline.

---

## Module 16 — Asset Management After Closing: Operations, Reporting, and the Business Plan

Closing is the beginning, not the end. Asset management is the work of executing the business plan, overseeing the property manager, monitoring the finances, and reporting to investors. It is where value is created or lost. Many sponsors underwrite well and manage poorly. This module teaches you to manage well.

### The first 90 days

The first 90 days set the tone for the entire hold. In that period: meet the property manager and the onsite team in person; walk every unit and the common areas; review every lease and every vendor contract; confirm that insurance, taxes, and the loan are in order; establish the reporting calendar; and communicate with tenants about who owns the property now, how to pay rent, and how to request maintenance. If you are renovating, confirm the contractor schedule, the material orders, and the unit-turn process. If you are syndicating, send your first investor update within 30 days of closing, even if there is little to report. Early communication builds trust.

### Overseeing the property manager

A property manager is your operating partner. Manage them actively. Set clear expectations: occupancy targets, collection targets, turnover time, maintenance response time, and reporting deadlines. Review the monthly financial statements line by line. Compare actual income and expense to the pro forma. Ask about variances. Visit the property regularly — monthly in the first year, quarterly after stabilization. A sponsor who never visits the property is a sponsor who does not know what is happening there.

Hold the manager accountable, but also support them. A manager who is under-resourced, underpaid, or ignored will not perform. If the manager is not performing after clear feedback and a fair chance to improve, change the manager. Do not let a poor manager destroy a good property.

### The monthly review

Each month, review: occupancy and collections, the rent roll and lease expirations, the profit and loss statement against the budget, the capital expenditure spending against the renovation budget, the maintenance backlog, and the lender reporting requirements. Each quarter, review the business plan: are rents, occupancy, and expenses tracking to the plan? If not, why, and what will you change? Each year, review the insurance, the tax assessment, the vendor contracts, and the market. Annual reviews catch drift before it becomes a problem.

### Reporting to investors

Investors in a syndication expect regular reporting — monthly or quarterly, as stated in the operating agreement. A good report includes: a one-page summary, occupancy and collections, financial statements, renovation progress with photos, a comparison to the business plan, and a candid assessment of challenges and next steps. Do not hide bad news. Report it early, with a plan. Investors who hear bad news from you first will trust you. Investors who hear it from someone else will not.

### When the plan changes

Business plans change. A renovation costs more. A major employer leaves. Interest rates rise. When the plan changes, update the forecast, communicate the change to investors, and explain the revised plan. Do not pretend the original plan is still intact when it is not. The discipline is not to follow the original plan blindly. The discipline is to manage to the best available plan, honestly.

**Action steps for Module 16:**

1. Build a 90-day post-closing checklist for your next acquisition.
2. Draft a monthly asset-management review template using the headings in this module.
3. Draft a quarterly investor update template.

**Exercise:** Complete Exercise 16 in the workbook.

---

## Module 17 — Exit Strategies: Refinance, Sale, and the Hold Decision

Every commercial investment needs an exit plan — not because you will sell soon, but because the exit determines whether the business plan created value. There are three main exits: refinance, sale, and hold. Each has a different purpose, a different tax treatment, and a different set of risks. Your CPA and attorney should advise you on the tax and legal consequences of each option for your situation.

### Refinance

A refinance replaces the existing loan with a new loan, often at a higher amount if the property's value has increased. The borrower may receive cash out — the difference between the new loan and the old loan balance, less costs — while keeping the property. A refinance can return some or all of the original equity, which improves the equity multiple and frees capital for the next deal. It also resets the loan term and may change the interest rate, the payment, and the prepayment terms.

Worked example: Maple Court is stabilized with NOI of $455,000. At a 7.5 percent cap rate, the value is $6,066,667. A new loan at 70 percent LTV is $4,246,667. The remaining balance on the original loan after three years is approximately $3,210,000. After refinance costs of approximately $85,000, the cash-out is $4,246,667 − $3,210,000 − $85,000 = $951,667. That cash can be distributed to investors or held as reserves. The new loan's debt service must still be covered by NOI at an acceptable DSCR. At 6.50 percent and 30-year amortization, the new monthly payment is approximately $26,841, annual debt service $322,092, DSCR $455,000 ÷ $322,092 = 1.41x. That passes a 1.25x minimum. If rates were higher, the DSCR would be lower and the refinance might not be possible at that loan amount. That is refinance risk, and it is why you should not assume a refinance will be available at a specific amount or rate.

### Sale

A sale converts the property to cash, pays off the loan, pays sale costs, and distributes the remainder through the waterfall. The sale price depends on NOI at sale and the exit cap rate. A small change in either number is a large change in price. For Maple Court, stabilized NOI of $455,000 at a 7.5 percent exit cap rate gives a price of $6,066,667. At an 8.0 percent exit cap rate, the price is $5,687,500 — a difference of $379,167. At an 8.5 percent exit cap rate, the price is $5,352,941. Model the sale at a higher exit cap rate than the going-in cap rate, and show investors the sensitivity.

Sale costs include broker commissions, closing costs, and any prepayment penalty on the loan. Taxes depend on the owner's situation, the holding period, depreciation recapture, and whether a 1031 exchange is used. Do not model taxes yourself. Have your CPA model them.

### Hold

Holding means keeping the property and operating it for income. Holding is the right choice when the property is cash-flowing well, the market is stable, and there is no compelling reason to sell or refinance. Holding is also the right choice when the sale market is weak and selling would mean accepting a price below the property's long-term value. The decision to hold is not a failure to exit. It is an exit decision in itself: you are choosing income over a sale.

### The 1031 exchange

A 1031 exchange, under Section 1031 of the Internal Revenue Code, allows a taxpayer to defer capital gains tax by exchanging one investment property for another of like kind, subject to strict timelines and rules. It is a powerful tool and a complex one. The timelines are short, the rules are strict, and a mistake can disqualify the exchange. If you are considering a 1031 exchange, engage a qualified intermediary and a CPA experienced in exchanges before you sell. Do not attempt it without advice.

### Making the exit decision

Each year, ask: what is the property worth today, what is it earning, what would a refinance return, what would a sale return after costs and taxes, and what is the best use of the capital if you sell? Compare the answers honestly. The right exit is the one that best serves the business plan and the investors, not the one that produces the highest headline number in a single year.

**Action steps for Module 17:**

1. For Maple Court, model a Year 5 refinance and a Year 5 sale side by side, and compare the cash returned to investors under each option.
2. List the prepayment terms on your loan and the sale costs you would incur, and include them in your exit model.
3. Consult your CPA about the tax treatment of a sale, a refinance, and a 1031 exchange for your situation.

**Exercise:** Complete Exercise 17 in the workbook.

---

## Module 18 — Risk Management: What Can Go Wrong and How to Prepare

Commercial real estate rewards investors who think about risk before they buy, not after something goes wrong. This module lists the main risks, how each one shows up in a deal, and how a prudent investor prepares for it. None of these risks can be eliminated. All of them can be understood, priced, and managed.

### Market risk

Rents, occupancy, and cap rates move with the economy and with local supply and demand. A new apartment community with 300 units can change the rent and occupancy of every nearby property. A major employer leaving can do the same. Prepare by choosing submarkets with diverse employers, by checking permit data for new supply, by underwriting at conservative rent growth, and by maintaining reserves. Do not assume that today's occupancy and rent will persist for five years.

### Renovation and execution risk

Renovations cost more and take longer than planned. Contractors become unavailable. Materials are delayed. Hidden conditions are discovered. Prepare by getting multiple bids, by adding a 10 to 15 percent contingency, by phasing the work so that a delay in one phase does not stop the whole project, and by having a contractor and a property manager who have done this work before.

### Financing and interest-rate risk

Interest rates rise, lenders tighten, and refinancing becomes harder or more expensive. A bridge loan that must be refinanced in 24 months is a bet that financing will be available on acceptable terms in 24 months. Prepare by testing your DSCR at higher rates, by understanding your loan's maturity and prepayment terms, by maintaining a strong relationship with multiple lenders, and by keeping enough reserves to handle a higher payment if you must refinance at a higher rate.

### Operational risk

Vacancy, delinquency, maintenance emergencies, and management turnover can reduce income and increase expense. A single large repair — a roof, a boiler, a sewer line — can consume a year's cash flow. Prepare by budgeting reserves, by maintaining the property proactively, by collecting rent diligently, and by having a property manager who responds quickly to maintenance issues.

### Legal and regulatory risk

Zoning changes, rent regulation, tax reassessment, and environmental liability can change a deal's economics. Prepare by having your attorney review zoning, leases, and local regulations before you buy, by modeling a tax reassessment, and by obtaining an environmental assessment. Do not assume that the rules that applied when the seller bought the property will apply when you own it.

### Liquidity risk

Commercial real estate is illiquid. You cannot sell a 48-unit property in a day. A syndication interest is even less liquid — there is generally no public market for it, and transfers are restricted by the operating agreement. Prepare by investing only capital you can commit for the full hold period, by maintaining personal reserves outside the deal, and by telling investors plainly that their capital is illiquid.

### Concentration risk

A single property, a single market, or a single tenant can dominate your portfolio. Prepare by diversifying over time, by understanding your exposure, and by not investing more in a single deal than you can afford to lose. Diversification does not eliminate risk, but it reduces the impact of a single bad outcome.

### The risk register

Build a risk register for every deal: list each risk, estimate its likelihood and its impact, describe how you will mitigate it, and identify the warning sign that would tell you the risk is materializing. Review the register quarterly. A risk you have named and planned for is a risk you can manage. A risk you have ignored is a surprise.

**Action steps for Module 18:**

1. Build a risk register for Maple Court with at least ten risks, using the categories in this module.
2. For each risk, write down the mitigation and the warning sign.
3. Identify the three risks that would cause you to walk away from a deal if they materialized during due diligence.

**Exercise:** Complete Exercise 18 in the workbook.

---

## Module 19 — Building Your Commercial Team and Your First Deal Pipeline

No one buys, renovates, and manages a commercial property alone. The sponsor's job is to assemble and lead a team, not to do every task personally. This module teaches you who you need, how to find them, and how to build a pipeline of deals so that you are choosing among opportunities, not chasing the only deal you have seen.

### The core team

- **Commercial broker.** Finds deals, provides market data, and advises on pricing. Choose a broker who specializes in your property type and submarket, not a generalist.
- **Property manager.** Operates the property, collects rent, handles maintenance, and reports to you. Interview at least three managers. Ask for references from owners of similar properties.
- **Commercial lender and mortgage broker.** Provides financing options and advises on loan structure. Build relationships before you need a loan.
- **Real estate attorney.** Reviews purchase agreements, leases, title, and entity documents. Choose an attorney experienced in commercial transactions in your state.
- **Securities attorney.** Advises on any capital raising. Engage them before you speak to investors about a deal.
- **CPA.** Advises on tax, depreciation, cost segregation, and entity structure. Choose a CPA experienced in real estate.
- **Inspector and environmental firm.** Verifies physical and environmental condition.
- **Appraiser.** Provides an independent valuation for the lender and for your own underwriting.
- **Contractor.** Provides renovation bids and executes the work. Choose a contractor with multifamily experience and check references.
- **Insurance broker.** Provides quotes and advises on coverage. Get quotes early — insurance can change a deal.

### Finding and vetting team members

Ask other investors, brokers, and property managers for referrals. Interview each candidate. Ask for references and call them. Ask about their experience with properties like yours, their fees, their availability, and how they communicate. A team member who does not return calls during the interview process will not return calls during a crisis.

Pay for good advice. A cheap attorney or a cheap inspector can be the most expensive choice you make. Budget for professional fees in every deal. They are part of the cost of investing, not an optional extra.

### Building a deal pipeline

A pipeline is a list of deals you are tracking, underwriting, or pursuing, with a status for each one. Build it by: telling brokers your buy box and asking them to send you deals that fit; reviewing listings weekly; driving your target submarkets; and following up with owners. Underwrite quickly and say no quickly. Most deals will not fit. That is normal. A pipeline with ten deals underwritten and nine rejected is a healthy pipeline. A pipeline with one deal is a gamble.

Track each deal in a simple log: property, price, NOI, cap rate, DSCR, cash-on-cash, status, and the reason you passed or proceeded. Review the log monthly. Over time, you will see patterns in pricing and in your own judgment. That log is how you get better at underwriting.

### Your reputation

In commercial real estate, your reputation is your most valuable asset. Brokers, lenders, and investors talk to each other. A sponsor who underwrites honestly, who closes when they say they will close, who reports honestly, and who treats investors fairly will get more deals and more capital. A sponsor who over-promises, who hides bad news, or who walks away from a signed agreement without cause will find doors closing. Protect your reputation as carefully as you protect your capital.

**Action steps for Module 19:**

1. List the ten team roles above and write down who you will use for each one, or how you will find them.
2. Interview two brokers and two property managers in your target market this month.
3. Start a deal pipeline log and add five properties to it this week.

**Exercise:** Complete Exercise 19 in the workbook.

---

## Module 20 — Your 12-Month Commercial Action Plan

This final module turns the course into a plan. It is divided into four quarters. Adapt the timeline to your capital and your schedule, but keep the sequence: learn, build the team, underwrite, and then — only then — pursue a deal.

### Months 1 to 3 — Learn and prepare

Complete this course and the workbook. Draft your buy box and your investment thesis. Build your underwriting model and practice on ten properties. Interview brokers, property managers, lenders, attorneys, and CPAs. Open or confirm your entity structure with your attorney and CPA. Establish your personal reserves and your investment capital — separately. If you plan to invest passively first, research sponsors and attend investor meetings.

### Months 4 to 6 — Build the pipeline

Tell brokers your buy box. Start your deal pipeline log. Underwrite at least one deal per week. Tour properties. Talk to property managers about rents, expenses, and occupancy. Refine your buy box based on what you learn. If you plan to sponsor, consult your securities attorney about the capital-raising process and begin building investor relationships through education, not through a specific offering.

### Months 7 to 9 — Pursue a deal

Make offers on deals that meet your criteria. Conduct due diligence thoroughly. Walk away from deals that do not meet your criteria, even if you have spent time on them. If you are investing passively, evaluate sponsors and deals using the framework in Modules 12 and 13, and make your first passive investment only after you have reviewed the offering documents with your own advisors.

### Months 10 to 12 — Close or continue

Close on a deal that meets your criteria, or continue underwriting. Closing is not the goal. Closing on the right deal is the goal. If you close, execute your 90-day plan, establish reporting, and manage the asset actively. If you do not close, review your pipeline, your buy box, and your underwriting, and keep going. Many successful investors underwrite for a year before they close on their first commercial deal. That patience is a strength, not a delay.

### The commitment

Write down your 12-month plan, with dates, and share it with a colleague, a mentor, or an advisor who will hold you accountable. Review it monthly. Update it when your circumstances change. The plan is not a promise that you will close a deal in 12 months. It is a promise that you will do the work, in order, and that you will not skip the steps that protect you.

You now have the language, the math, and the process to evaluate multifamily and commercial deals with confidence. Use them. Underwrite carefully. Build your team. Protect your investors and your capital. And when you find a deal that meets your criteria — and only then — act decisively.

**Action steps for Module 20:**

1. Write your 12-month plan with specific dates for each milestone.
2. Identify one person who will hold you accountable for the plan.
3. Schedule a monthly review of the plan, starting this month.

**Exercise:** Complete Exercise 20 in the workbook.

---

## Case Study 1 — Maple Court: 48-Unit Value-Add

**Property:** Maple Court, a fictional 48-unit apartment community built in 1985, brick construction, 38,400 rentable square feet. Mix: 24 one-bedroom units at an average of $950 per month and 24 two-bedroom units at an average of $1,350 per month, for a blended average of $1,150. Occupancy at purchase: 46 of 48 units, 95.8 percent.

**Purchase:** $4,800,000, or $100,000 per unit and $125.00 per square foot. Closing costs $120,000. Total cash at closing before renovation: $1,560,000 (down payment $1,440,000 plus closing $120,000).

**Year 1 income and expense (pre-renovation, verified):**

| Line | Annual amount |
|---|---:|
| Gross potential rent (48 × $1,150 × 12) | $662,400 |
| Other income (laundry, pet, parking, fees) | $24,000 |
| Gross potential income | $686,400 |
| Vacancy and credit loss (5% of GPR) | ($33,120) |
| Effective gross income | $653,280 |
| Real estate taxes | ($52,000) |
| Insurance | ($28,800) |
| Repairs and maintenance | ($38,400) |
| Utilities (owner-paid) | ($36,000) |
| Property management (8% of EGI) | ($52,262) |
| Payroll / onsite | ($24,000) |
| Marketing and leasing | ($9,600) |
| General and administrative / legal | ($7,200) |
| Reserves for replacement | ($14,400) |
| Total operating expenses | ($262,662) |
| **Net operating income** | **$390,618** |

**Valuation and financing:** Going-in cap rate 8.14 percent. Market cap rate 7.5 percent, indicated value $5,208,240. Loan $3,360,000 at 6.25 percent, 30-year amortization, monthly payment approximately $20,691, annual debt service $248,292, DSCR 1.57x. Cash flow after debt service $142,326. Cash-on-cash 9.12 percent.

**Business plan:** Renovate all 48 units over 18 months at $10,000 per unit ($480,000) plus $60,000 in common-area work, total $540,000. Raise renovated rents to $1,300 per month. Stabilized GPR $748,800, other income $28,800, gross potential income $777,600, vacancy $37,440, EGI $740,160, operating expenses approximately $285,000, stabilized NOI approximately $455,000. Stabilized value at a 7.5 percent cap rate: $6,066,667. Total cost $5,460,000. Yield on cost 8.33 percent.

**Outcome, on the stated assumptions:** The plan creates value because yield on cost exceeds the market cap rate, the DSCR remains above 1.25x in the downside cases tested in Module 8, and the renovation is phased so that no more than six units are vacant for renovation at once. The risks are renovation cost overruns, slower lease-up, and a rise in the exit cap rate. Each risk is addressed in the risk register in Module 18.

**Lessons:** Verify NOI yourself — the seller's NOI was $37,662 higher because it omitted management, reserves, and realistic insurance. Test the rent increase against comparable renovated properties. Phase the renovation. Keep a contingency in the budget.

---

## Case Study 2 — Cedar Lane: 24-Unit Stabilized Acquisition

**Property:** Cedar Lane, a fictional 24-unit apartment community built in 1992, 19,200 rentable square feet, averaging 800 square feet per unit. Mix: 12 one-bedroom units at $1,050 per month and 12 two-bedroom units at $1,400 per month, for a blended average of $1,225. Occupancy at purchase: 23 of 24 units, 95.8 percent. The property was renovated by the prior owner in 2021 and requires no major interior work.

**Purchase:** $2,150,000, or $89,583 per unit and $111.98 per square foot. Closing costs $65,000. Down payment at 70 percent LTV: loan $1,505,000, down payment $645,000, total cash at closing $710,000.

**Year 1 income and expense:**

| Line | Annual amount |
|---|---:|
| Gross potential rent (24 × $1,225 × 12) | $352,800 |
| Other income (laundry, pet, parking) | $12,000 |
| Gross potential income | $364,800 |
| Vacancy and credit loss (5% of GPR) | ($17,640) |
| Effective gross income | $347,160 |
| Real estate taxes | ($26,000) |
| Insurance | ($14,400) |
| Repairs and maintenance | ($19,200) |
| Utilities (owner-paid) | ($16,800) |
| Property management (8% of EGI) | ($27,773) |
| Payroll / onsite (part-time) | ($12,000) |
| Marketing and leasing | ($4,800) |
| General and administrative / legal | ($3,600) |
| Reserves for replacement | ($7,200) |
| Total operating expenses | ($131,773) |
| **Net operating income** | **$215,387** |

The expense ratio is 38.0 percent of EGI. NOI of $215,387 at a price of $2,150,000 is a going-in cap rate of 10.02 percent — high for a stabilized property, which would prompt a careful check: is the NOI overstated, is the price below market for a reason, or is the submarket weaker than it appears? In this teaching example, the figures are stated as given; in a real deal, a cap rate well above market would be a reason to investigate the property, the market, and the seller's motivation before proceeding.

For the purpose of the return calculation, use the stated NOI. Loan $1,505,000 at 6.50 percent, 30-year amortization: monthly payment approximately $9,513, annual debt service $114,156, DSCR $215,387 ÷ $114,156 = 1.89x. Cash flow after debt service: $101,231. Cash-on-cash: $101,231 ÷ $710,000 = 14.26 percent. That return is high because the stated cap rate is high; a buyer should not assume it will persist without verifying the income, the expenses, and the market.

**Business plan:** No major renovation. Focus on operations: reduce vacancy from 4.2 percent to 3 percent, improve collections, and grow rents by 3 percent per year. Year 2 GPR at 3 percent growth: $363,384. Year 2 EGI, holding other income and vacancy constant in proportion: approximately $357,575. Year 2 expenses at 3 percent growth: $135,726. Year 2 NOI: approximately $221,849.

**Lessons:** A stabilized deal can be attractive when the price reflects the income and no renovation is needed, but a cap rate far above market is a signal to investigate, not a reason to celebrate. Verify every line. A small property still requires professional management, reserves, and reporting. The lower purchase price makes this size accessible to an investor who is moving from residential to commercial for the first time.

---

## Case Study 3 — Harbor View: 120-Unit Syndication

**Property:** Harbor View, a fictional 120-unit apartment community built in 1988, 96,000 rentable square feet, averaging 800 square feet per unit. Mix: 48 one-bedroom units at $1,100 per month, 48 two-bedroom units at $1,450 per month, and 24 three-bedroom units at $1,700 per month. Blended average rent: (48 × $1,100 + 48 × $1,450 + 24 × $1,700) ÷ 120 = ($52,800 + $69,600 + $40,800) ÷ 120 = $163,200 ÷ 120 = $1,360 per month. Occupancy at purchase: 114 of 120 units, 95.0 percent.

**Purchase and capital stack:** Purchase price $14,500,000, or $120,833 per unit and $151.04 per square foot. Closing costs $290,000. Renovation budget $1,200,000 ($10,000 per unit). Total project cost $15,990,000. Loan $10,150,000 (70 percent of purchase price) at 6.50 percent, 30-year amortization. Total equity $5,840,000: limited partners $5,548,000 (95 percent) and sponsor co-investment $292,000 (5 percent). Acquisition fee 2 percent of purchase price, $290,000, paid at closing from capital raised and disclosed in the offering documents.

**Year 1 income and expense (pre-renovation, verified):**

| Line | Annual amount |
|---|---:|
| Gross potential rent (120 × $1,360 × 12) | $1,958,400 |
| Other income | $72,000 |
| Gross potential income | $2,030,400 |
| Vacancy and credit loss (5% of GPR) | ($97,920) |
| Effective gross income | $1,932,480 |
| Real estate taxes | ($145,000) |
| Insurance | ($72,000) |
| Repairs and maintenance | ($96,000) |
| Utilities (owner-paid) | ($84,000) |
| Property management (7% of EGI) | ($135,274) |
| Payroll / onsite | ($96,000) |
| Marketing and leasing | ($24,000) |
| General and administrative / legal | ($18,000) |
| Reserves for replacement | ($36,000) |
| Total operating expenses | ($706,274) |
| **Net operating income** | **$1,226,206** |

Expense ratio 36.5 percent of EGI. Going-in cap rate: $1,226,206 ÷ $14,500,000 = 8.46 percent. Loan $10,150,000 at 6.50 percent, 30-year amortization: monthly payment approximately $64,158, annual debt service $769,896, DSCR 1.59x. Cash flow after debt service: $456,310. Cash-on-cash on total equity, before renovation timing: $456,310 ÷ $5,840,000 = 7.81 percent.

**Business plan:** Renovate all 120 units over 24 months at $10,000 per unit, plus common-area work included in the $1,200,000 budget. Raise renovated rents by an average of $175 per month, to a blended average of $1,535. Stabilized GPR: 120 × $1,535 × 12 = $2,210,400. Other income $84,000. Gross potential income $2,294,400. Vacancy $110,520. EGI $2,183,880. Operating expenses at stabilization, approximately $770,000. Stabilized NOI approximately $1,413,880. Stabilized value at a 7.5 percent cap rate: $18,851,733. Total cost $15,990,000. Yield on cost 8.84 percent.

**Waterfall (as structured in Module 13):** 8 percent preferred return on LP capital of $5,548,000, or $443,840 per year. After the pref, a 70/30 split until the LPs reach a 12 percent IRR, then a 50/50 split. In a stabilized year with $650,000 available for distribution, the pref of $443,840 is paid to the LPs, and the remaining $206,160 is split 70/30 (or 50/50 above the IRR hurdle, as modeled in the spreadsheet). The sponsor also receives an asset management fee of 1.5 percent of EGI per year, disclosed in the offering documents.

**Lessons:** Scale changes operations: a 120-unit property needs full-time onsite staff, a larger marketing budget, and a more formal reporting process. The equity raise is larger and requires a longer capital-raising period and a securities attorney's guidance from the start. The math is the same as for a 48-unit property — NOI, cap rate, DSCR, cash-on-cash — but the consequences of an error are larger. Do not sponsor a 120-unit deal as your first commercial transaction unless you have an experienced co-sponsor and a team that has done it before.

---

## Case Study 4 — Birchwood: 36-Unit Turnaround and the Deal That Was Passed On

**Property:** Birchwood, a fictional 36-unit apartment community built in 1978, 28,800 rentable square feet, averaging 800 square feet per unit. Mix: 18 one-bedroom units at $950 per month and 18 two-bedroom units at $1,250 per month, blended average $1,100. Occupancy at purchase in the teaching scenario: 29 of 36 units, 80.6 percent — well below market. Delinquency is high, deferred maintenance is visible, and the prior management was ineffective.

**Purchase (teaching scenario):** $2,700,000, or $75,000 per unit and $93.75 per square foot. Closing costs $80,000. Renovation and lease-up budget $540,000 ($15,000 per unit, higher than Maple Court because of deferred maintenance). Total project cost $3,320,000. Loan $1,890,000 (70 percent of purchase price) at 6.75 percent, 30-year amortization, monthly payment approximately $12,260, annual debt service $147,120.

**Year 1 income and expense (as purchased, with low occupancy):**

| Line | Annual amount |
|---|---:|
| Gross potential rent (36 × $1,100 × 12) | $475,200 |
| Other income | $14,400 |
| Gross potential income | $489,600 |
| Vacancy and credit loss (19.4% of GPR, reflecting 80.6% occupancy plus delinquency) | ($92,200) |
| Effective gross income | $397,400 |
| Real estate taxes | ($38,000) |
| Insurance | ($21,600) |
| Repairs and maintenance | ($36,000) |
| Utilities (owner-paid) | ($28,800) |
| Property management (8% of EGI) | ($31,792) |
| Payroll / onsite | ($18,000) |
| Marketing and leasing | ($14,400) |
| General and administrative / legal | ($7,200) |
| Reserves for replacement | ($10,800) |
| Total operating expenses | ($206,592) |
| **Net operating income** | **$190,808** |

Going-in cap rate: $190,808 ÷ $2,700,000 = 7.07 percent. DSCR: $190,808 ÷ $147,120 = 1.30x — just above a 1.25x minimum, with little cushion. Cash flow after debt service: $43,688. Total cash invested: down payment $810,000 plus closing $80,000, or $890,000 before renovation. Cash-on-cash in Year 1, before renovation spending: 4.91 percent.

**The turnaround plan:** Replace management, renovate vacant units first, address deferred maintenance, improve collections, and lease to 95 percent occupancy over 18 months. Renovated rents rise to $1,250 per month blended. Stabilized GPR: 36 × $1,250 × 12 = $540,000. Other income $18,000. Gross potential income $558,000. Vacancy at 5 percent of GPR $27,000. EGI $531,000. Operating expenses at stabilization, approximately $215,000. Stabilized NOI approximately $316,000. Stabilized value at a 7.5 percent cap rate: $4,213,333. Total cost $3,320,000. Yield on cost 9.52 percent. On paper, the turnaround creates value.

**Why this deal was passed on — the lesson:** In this case study, the buyer passed on Birchwood after due diligence, and the reasons are the lesson. The inspection found a roof that needed replacement within two years ($180,000, not in the renovation budget), a sewer line that needed replacement ($65,000), and evidence of water damage in six units. The environmental report required further investigation. The rent roll did not reconcile to bank deposits: contract rent was $39,600 per month, but deposits averaged $31,000 per month, a gap the seller could not explain with documentation. The submarket had two new apartment communities under construction, adding 420 units within two miles. The buyer's revised underwriting, adding the roof and sewer costs and using a higher vacancy assumption, showed a DSCR below 1.20x and a cash-on-cash return below the buyer's minimum. The buyer walked away during due diligence.

The point is not that turnaround deals never work. They do, for sponsors with the team, the capital, and the risk tolerance to execute them. The point is that a deal can look attractive on the OM and fail on verification. The discipline in this course — rebuild NOI, verify the rent roll, inspect the property, check the market, test the downside — is what protects you. Walking away from Birchwood cost the buyer the inspection and report fees. Closing on it without that diligence could have cost far more.

**Lessons:** Low occupancy is not automatically an opportunity. It can be a symptom of management, condition, or market problems. Reconcile the rent roll to the bank statements. Price major capital items into the budget before you offer. Check new supply. And remember: the best deal you ever do may be the one you walk away from.

---

## Appendix A — Commercial Glossary

- **Cap rate:** NOI divided by price. A measure of return based on income, independent of financing.
- **Cash-on-cash return:** Annual cash flow after debt service divided by total cash invested.
- **Debt-service coverage ratio (DSCR):** NOI divided by annual debt service.
- **Effective gross income (EGI):** Gross potential income minus vacancy and credit loss.
- **Equity multiple:** Total cash returned divided by total cash invested.
- **Gross potential income (GPI):** Rent at full occupancy plus other income.
- **Internal rate of return (IRR):** The annualized return that accounts for the timing of all cash flows.
- **Loan-to-value (LTV):** Loan amount divided by price or appraised value.
- **Net operating income (NOI):** Effective gross income minus operating expenses, before debt service, income taxes, and depreciation.
- **Preferred return (pref):** A target return paid to limited partners before the sponsor shares in profits, as defined in the operating agreement. It is a preference, not a guarantee.
- **Syndication:** Pooling capital from multiple investors to acquire a property.
- **Value-add:** A strategy of improving a property to increase its income and value.
- **Waterfall:** The rules that determine how cash is distributed among investors and the sponsor.
- **Yield on cost:** Stabilized NOI divided by total cost, including purchase price, renovation, and closing costs.

## Appendix B — Underwriting Rules of Thumb and Sanity Checks

- Always include a management fee and reserves in your underwriting, even if you plan to self-manage.
- Compare your expense ratio to comparable properties. For Class B multifamily, an expense ratio well below 30 percent or well above 50 percent deserves investigation.
- Test DSCR at a rate 1 percent above the quoted rate.
- Test the deal at 5 percent lower rents, 10 percent higher expenses, and 5 percent lower occupancy. If the deal fails all three tests, it is fragile.
- Assume an exit cap rate equal to or higher than the going-in cap rate unless you have specific evidence for a lower rate.
- Get a real insurance quote. Do not use the seller's insurance cost without verification.
- Check whether a sale will trigger a tax reassessment, and model the higher tax if it will.
- Verify the rent roll against bank deposits. A gap you cannot explain is a reason to slow down.

## Appendix C — Documents and Advisor Checklist

Before you make an offer, confirm you have or can obtain: the rent roll, the T-12 and year-to-date financials, the leases, the tax returns or tax bills, the insurance information, the inspection and environmental reports, the appraisal, the loan term sheet, and the title report. Before you close, confirm you have engaged: a commercial real estate attorney, a CPA experienced in real estate, a licensed commercial broker, a commercial lender, a property manager, and — if you are raising capital — a securities attorney. Keep a record of every advisor's advice and every document you relied on.

---

## A Final Note

Commercial real estate can build lasting wealth, and it can also destroy capital quickly when it is done without discipline. The difference is rarely luck. It is underwriting, verification, team, and patience. Use this course as a working reference. Return to it when you are underwriting a live deal. And before you sign anything — a purchase agreement, a loan, an operating agreement, or a subscription document — have your own advisors review it for your situation.

*This course is education only. It is not individualized investment, legal, tax, or financial advice, and it does not provide securities advice. Commercial real estate involves larger capital, longer timelines, and different risks than residential investing. Consult a commercial real estate attorney, a CPA, and a licensed broker before making any investment decision, and consult a securities attorney before raising capital from others. No return is guaranteed.*

---
*The Commercial Real Estate Investor Masterclass — RE-06 — EightyTwenty*
