# Capital-Raising Template

## RE-06 | The Commercial Real Estate Investor Masterclass

This template gives you the structure for an investor presentation and the email scripts for investor communication. Adapt every section to your specific deal, and have a securities attorney review your structure, your documents, and your communications before you speak to any investor about a deal.

> This template is education only. It is not investment, legal, tax, or financial advice, and it does not provide securities advice. Pooling investor capital is generally a securities offering. Do not advertise an investment, promise a return, or accept investor funds without advice from a securities attorney. Never state a return as guaranteed.

---

## Part 1 — Investor Presentation Outline

### 1. Cover and Summary

- Property name, location, unit count, and property type
- Purchase price and total project cost
- Total equity to be raised and minimum investment
- Hold period
- Three to five investment highlights, stated factually

### 2. The Sponsor

- Who you are and your real estate background, with specific numbers (properties owned, units managed, renovations completed)
- Your team: property manager, attorney, CPA, lender, contractor
- Your co-investment amount and percentage
- References available on request

### 3. The Market

- Submarket, major employers, and demographics, with sources and dates
- Occupancy and rent trends for comparable properties
- New supply: permits and projects under construction
- Why this submarket fits your investment thesis

### 4. The Property

- Unit mix, vintage, construction, and rentable square footage
- Current occupancy, rents, and lease expirations
- Condition, with honest photos including deferred maintenance
- What the prior owner did and did not do

### 5. The Business Plan

- Renovation scope, item by item, with costs and schedule
- Rent increase expected after renovation, with comparable properties cited
- Operational improvements: management, collections, expenses
- Month-by-month lease-up plan and stabilization date

### 6. The Financials

- Year 1 pro forma: income, expenses, NOI
- Five-year projection with assumptions stated
- Sources and uses of funds
- Loan terms, DSCR, cash-on-cash, equity multiple, IRR, yield on cost
- Base case, downside case, and upside case — all three shown

### 7. The Structure and the Waterfall

- Entity type
- Fees: acquisition, asset management, disposition — each disclosed with amount and basis
- Preferred return: rate, and whether it is cumulative
- Split after the pref, and the promote above the IRR hurdle
- Worked example using the deal's own numbers
- Return of capital order on sale

### 8. The Risks

State the specific risks of this deal in plain language, including market risk, renovation risk, lease-up risk, financing and interest-rate risk, operational risk, legal and regulatory risk, liquidity risk, and the risk of loss of capital. Do not hide risks in fine print.

### 9. Timeline and Next Steps

- Closing date, funding date, and deadlines
- Documents the investor will receive and how to review them
- Who to contact with questions, and how long the investor has to decide

### 10. Disclaimers

State clearly that the presentation is information and education, not investment advice, that no return is guaranteed, that the investment is illiquid, and that the investor should consult their own attorney, CPA, and financial advisor before investing.

---

## Part 2 — Email Scripts

Use these scripts as starting points. Adapt the wording to your voice and your deal, and have your securities attorney review any communication that discusses a specific offering before you send it. Do not send offering details to anyone your attorney has not cleared to receive them.

### Script A — General introduction (no specific deal mentioned)

Subject: Staying in touch — commercial multifamily investing

Hello [Name],

Thank you for speaking with me about commercial real estate. As I mentioned, I invest in multifamily properties and I am building my knowledge and network in [submarket].

I would like to stay in touch and share what I am learning about the market from time to time. There is no specific investment to discuss at the moment. If you are open to it, I would welcome a brief conversation about your experience with real estate and what you look for in an investment.

Would you be available for a 20-minute call next week?

Thank you,
[Your name]
[Your phone number]

### Script B — Sharing educational market research (no offering)

Subject: What I am seeing in [submarket] multifamily

Hello [Name],

I have been researching [submarket] multifamily properties over the past few months, and I wanted to share a brief summary of what I am seeing: occupancy trends, rent levels for Class B properties, and new supply in the pipeline.

This is general market information, not an investment offer. I am sharing it because you expressed interest in this market, and I value your perspective.

If you would like to discuss what I am seeing, I would welcome a call. I am also happy to hear what you are seeing in your own research.

Thank you,
[Your name]

### Script C — Invitation to review offering documents (only after attorney clearance)

Subject: Offering documents available for review — [Property name]

Hello [Name],

As discussed, the offering documents for [Property name] are now available for your review. They include the offering memorandum, the operating agreement, the subscription documents, and the financial model.

Please take the time you need to review them, and please consult your own attorney, CPA, and financial advisor before making any decision. I am available to answer questions about the property, the market, and the business plan, and I will follow up in writing on any question I cannot answer immediately.

There is no deadline pressure from my side beyond the funding date stated in the documents: [date]. If you decide not to proceed, please let me know so I can plan accordingly. There will be no hard feelings.

Thank you for considering this opportunity.

[Your name]
[Your phone number]

### Script D — Quarterly investor update

Subject: Quarterly update — [Property name] — [Quarter and year]

Hello,

Here is the quarterly update for [Property name].

**Summary:** [Two or three sentences on how the quarter went against the business plan.]

**Occupancy and collections:** Occupancy is [percentage]. Collections are [percentage]. [Note any change and why.]

**Financials:** [Attach or summarize the profit and loss statement, with actual results compared to the budget.]

**Renovation progress:** [Units completed, units in progress, costs to date against budget, with photos.]

**Challenges and next steps:** [State any challenge honestly, what you are doing about it, and the revised forecast if the plan has changed.]

**Questions:** Please reply with any questions. I will respond within [timeframe].

Thank you for your trust.

[Your name]

### Script E — Reporting bad news early

Subject: Update on [Property name] — [specific issue]

Hello,

I am writing to let you know about [specific issue] at [Property name], what it means for the business plan, and what we are doing about it.

**What happened:** [Facts, plainly stated.]

**Financial impact:** [Best current estimate, with the assumptions behind it.]

**What we are doing:** [Specific steps, owners, and dates.]

**Revised outlook:** [How the forecast changes, if it does.]

I will update you again on [date], or sooner if there is a material change. Please contact me with any questions.

Thank you,
[Your name]

---

## Part 3 — Capital-Raising Checklist

- [ ] Securities attorney engaged; offering structure and exemption confirmed by the attorney
- [ ] Investor eligibility process confirmed by the attorney
- [ ] Offering memorandum, operating agreement, and subscription documents reviewed by the attorney
- [ ] Financial model reviewed by your CPA
- [ ] Fees, pref, split, and promote stated consistently in every document
- [ ] No guaranteed returns stated anywhere
- [ ] Investor list organized: contact information, eligibility notes, documents sent, dates
- [ ] Reporting calendar set: monthly or quarterly updates, as stated in the operating agreement
- [ ] Record kept of every investor communication

---

*Education only. Not investment, legal, tax, or financial advice. Not securities advice. Consult a securities attorney before raising capital from others.*
