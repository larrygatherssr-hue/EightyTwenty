# Syndication Deal-Review Checklist

## RE-06 | The Commercial Real Estate Investor Masterclass

Use this checklist before you invest as a limited partner, and before you present a deal as a sponsor. Check each item, note the evidence, and record any open questions. Do not invest — and do not ask others to invest — until every material item is answered in writing.

> This checklist is education only. It is not investment, legal, tax, or financial advice, and it does not provide securities advice. Pooling investor capital is generally a securities offering. Consult a securities attorney before raising capital, and consult your own attorney, CPA, and financial advisor before investing.

---

## 1. The Sponsor

- [ ] Sponsor name, background, and real estate track record documented
- [ ] Prior deals listed, including deals that did not perform as planned and how they were handled
- [ ] References from prior investors and from lenders contacted
- [ ] Sponsor co-investment amount and percentage confirmed in writing
- [ ] Sponsor team identified: property manager, attorney, CPA, lender, contractor
- [ ] Sponsor's other active deals and time commitments disclosed
- [ ] Any litigation, bankruptcy, or regulatory history disclosed and reviewed with your attorney

Notes / evidence: ____________________________________________________________

## 2. The Market

- [ ] Submarket, employers, and demographics documented with sources and dates
- [ ] Occupancy and rent trends for comparable properties verified (not only from the OM)
- [ ] New supply checked: permits and projects under construction within the submarket
- [ ] Major employers: hiring, stable, or leaving — confirmed from a source other than the sponsor
- [ ] Rent regulation, zoning, and tax reassessment rules checked with your attorney

Notes / evidence: ____________________________________________________________

## 3. The Property and the Business Plan

- [ ] Property inspected; inspection report reviewed
- [ ] Environmental report (Phase I) reviewed; Phase II ordered if required
- [ ] Unit mix, condition, and deferred maintenance documented with photos
- [ ] Renovation scope listed item by item with contractor bids
- [ ] Renovation contingency of 10 to 15 percent included in the budget
- [ ] Rent increase tested against comparable renovated properties toured in person
- [ ] Lease-up timeline modeled month by month, with vacancy during renovation
- [ ] Property management plan and manager identified

Notes / evidence: ____________________________________________________________

## 4. The Financials

- [ ] Rent roll read line by line; vacancies, expirations, and delinquency noted
- [ ] Rent roll reconciled to bank deposits
- [ ] T-12 and year-to-date financials reviewed and compared to the OM
- [ ] NOI rebuilt from verified sources, not copied from the OM
- [ ] Each expense line checked against the T-12, tax bills, insurance quotes, and a property manager's estimate
- [ ] Management fee and reserves included in the underwriting
- [ ] Cap rate verified against comparable sales in the submarket
- [ ] Loan terms confirmed: rate, amortization, term, prepayment, recourse, reserves, covenants
- [ ] DSCR calculated at the quoted rate and at a rate 1 percent higher; minimum 1.25x confirmed
- [ ] Cash-on-cash, equity multiple, IRR, and yield on cost calculated and compared
- [ ] Three downside cases tested: rents 5 percent lower, expenses 10 percent higher, occupancy at 90 percent
- [ ] Exit modeled at an exit cap rate equal to or higher than the going-in cap rate
- [ ] Sources and uses of funds reconciled to the total project cost

Notes / evidence: ____________________________________________________________

## 5. The Structure, Fees, and Waterfall

- [ ] Entity type and operating agreement reviewed by your attorney
- [ ] Acquisition fee: rate, amount, and how it is paid — disclosed in writing
- [ ] Asset management fee: basis (gross income, collected income, or NOI) and rate — disclosed
- [ ] Disposition fee, if any, disclosed
- [ ] Preferred return: rate, and whether it is cumulative or non-cumulative
- [ ] Split after the pref, and the promote above the IRR hurdle — stated in plain language
- [ ] Waterfall modeled in a spreadsheet with actual annual cash flows, not estimated from a single year
- [ ] Return of capital order on sale confirmed
- [ ] Transfer restrictions, hold period, and reporting frequency confirmed
- [ ] Tax treatment discussed with your CPA (do not rely on the sponsor's tax summary alone)

Notes / evidence: ____________________________________________________________

## 6. Capital Raising and Securities Compliance (Sponsors)

- [ ] Securities attorney engaged before speaking to investors about the deal
- [ ] Offering exemption identified by your attorney and followed
- [ ] Investor eligibility verified through the process your attorney prescribed
- [ ] Offering memorandum, operating agreement, and subscription documents reviewed by your attorney
- [ ] No guaranteed returns stated in any communication
- [ ] Investor communications and documents tracked: who received what, and when

Notes / evidence: ____________________________________________________________

## 7. Risks and Disclosures

- [ ] Specific risks listed: market, renovation, lease-up, financing, operational, legal, regulatory, liquidity, concentration
- [ ] Risk register completed with mitigation and warning sign for each risk
- [ ] Downside cases shown to investors, not only the base case
- [ ] Illiquidity disclosed in plain language
- [ ] Possibility of loss of capital disclosed in plain language

Notes / evidence: ____________________________________________________________

## 8. Decision

- [ ] My advisors (attorney, CPA) have reviewed the offering documents for my situation
- [ ] I can explain the waterfall, the fees, and the business plan in plain language
- [ ] I understand what has to go right for the base case to happen
- [ ] I can commit this capital for the full hold period
- [ ] Decision: Proceed / Proceed with conditions / Pass
- [ ] Conditions, if any: ____________________________________________________________
- [ ] Date and signature: ____________________________________________________________

---

*Education only. Not investment, legal, tax, or financial advice. Not securities advice. Consult your own professional advisors before investing or raising capital.*
