# The Commercial Real Estate Investor Masterclass — Companion Workbook

## RE-06 | EightyTwenty

Use this workbook alongside `content.md` and the templates folder. Complete each exercise before moving to the next module. Write your answers in this file or in a printed copy. Keep your completed workbook with your deal files — it becomes your underwriting record.

> **Important notice:** This workbook is education only. It is not individualized investment, legal, tax, or financial advice, and it does not provide securities advice. Commercial real estate involves larger capital, longer timelines, and different risks than residential investing. No return is guaranteed. Before you buy, sell, syndicate, raise capital, or sign any document, consult a commercial real estate attorney, a CPA experienced in real estate, a licensed commercial broker, and a commercial lender. Consult a securities attorney before raising capital from others.

---

## Exercise 1 — Your Residential Foundation (Module 1)

1. How many residential properties have you owned or managed, and what types?
2. What did you learn about tenants, maintenance, and vacancy that will transfer to commercial investing?
3. In one sentence, why do you want to move into commercial real estate?
4. Which path will you explore first — active, passive, or both — and what would need to be true for you to proceed?
5. List the professional advisors you already have and the gaps you need to fill.

## Exercise 2 — Choosing Your Lane (Module 2)

1. Choose your primary sector (multifamily, office, retail, industrial, or mixed-use) and explain your choice in three sentences.
2. Name three submarkets you know well. For each, write down the major employers, the best streets, and the rent range for a two-bedroom apartment.
3. Which property classes will you consider for your first deal, and which will you exclude? Give a reason for each exclusion.

## Exercise 3 — Your Buy Box (Module 3)

Complete your one-page buy box:

- Property type and class: ____________________
- Unit count range: ____________________
- Submarkets: ____________________
- Vintage range: ____________________
- Price range: ____________________
- Minimum going-in cap rate: ____________________
- Minimum stabilized cash-on-cash return: ____________________
- Minimum DSCR: ____________________
- Value-add scope you will accept: ____________________
- Value-add scope you will NOT accept: ____________________
- Hold period: ____________________
- Equity you can commit: ____________________
- Exclusions: ____________________

Then write your one-paragraph investment thesis, and complete a capital / time / skill inventory: how much equity can you commit without endangering your personal finances, how many hours per week can you give to asset management, and what will you hire out?

## Exercise 4 — Cap Rate Practice (Module 4)

Find three listed multifamily properties in your market. For each, record the asking price, the stated NOI, and the stated cap rate. Then recalculate the cap rate assuming NOI is 10 percent lower, and calculate the indicated value at your market cap rate.

| Property | Asking price | Stated NOI | Stated cap rate | NOI 10% lower | Value at market cap rate |
|---|---|---:|---:|---:|---:|
| 1 | | | | | |
| 2 | | | | | |
| 3 | | | | | |

Write down the cap-rate range you are seeing for your target class and submarket, and the source for each data point.

## Exercise 5 — Reading Documents (Module 5)

Obtain a sample offering memorandum, rent roll, and T-12. Read the rent roll first, then the T-12, then the OM.

1. How many units are vacant, and how long have they been vacant?
2. How many leases expire in the next 90 days? In the next 12 months?
3. How far below market are current rents, and for how many units?
4. Does the rent roll reconcile to the bank statements? What is the gap, if any?
5. List every number in the OM that you cannot verify from the rent roll or the T-12.
6. Write five questions you would ask the seller or broker before making an offer.

## Exercise 6 — Build a Pro Forma (Module 6)

Using the commercial underwriting model template, build a Year 1 pro forma for a property in your market. Fill in every line: gross potential rent by unit type, other income, vacancy and credit loss, each expense line, and NOI.

1. What is your expense ratio (total operating expenses divided by EGI)? How does it compare to comparable properties?
2. Which expense line differs most from the T-12? Why?
3. Build Years 2 through 5. What rent growth rate and expense growth rate did you use, and what is your source for each?
4. What is your NOI in Year 5, and what would the property be worth at your market cap rate?

## Exercise 7 — Loan Sizing and DSCR (Module 7)

For a property you are underwriting:

1. Proposed loan amount and LTV: ____________________
2. Interest rate, amortization, and term: ____________________
3. Monthly payment and annual debt service: ____________________
4. DSCR at the quoted rate: ____________________
5. DSCR at a rate 1 percent higher: ____________________
6. DSCR-constrained maximum loan: ____________________
7. LTV-constrained maximum loan: ____________________
8. Which constraint binds, and what would have to change to borrow more?
9. List the loan terms you will accept and the terms you will not accept.

## Exercise 8 — Full Underwriting Summary (Module 8)

Rebuild the Maple Court walkthrough in the underwriting model. Then write a one-page summary:

- Purchase price, price per unit, price per square foot
- Verified NOI and going-in cap rate
- Loan, DSCR, cash flow after debt service, cash-on-cash return
- Downside case 1 (rents 5 percent lower): NOI, DSCR, cash-on-cash
- Downside case 2 (expenses 10 percent higher): NOI, DSCR, cash-on-cash
- Downside case 3 (occupancy 90 percent): NOI, DSCR, cash-on-cash
- The five pieces of information you still need before making an offer

## Exercise 9 — Returns (Module 9)

Using the Maple Court numbers:

1. Cash-on-cash return in Year 1: ____________________
2. Yield on cost after renovation: ____________________
3. Equity multiple under your own five-year assumptions (show the cash-flow table): ____________________
4. IRR under your own five-year assumptions: ____________________
5. Change the exit cap rate by 0.5 percent. How much does the IRR move?
6. What minimum cash-on-cash, equity multiple, and IRR will you accept, and when would you accept less?

## Exercise 10 — Value-Add Plan (Module 10)

For a target property, list every renovation item, its cost, and the rent increase you expect it to support — item by item.

| Renovation item | Cost | Expected rent increase | Comparable property that supports it |
|---|---|---:|---:|
| | | | |

1. What is your total renovation budget, including a 10 to 15 percent contingency?
2. What is your month-by-month renovation and lease-up schedule?
3. In which month does the property reach stabilization?
4. What is your stabilized NOI, your yield on cost, and your stabilized value at the market cap rate?

## Exercise 11 — Due Diligence Checklist (Module 11)

Build your due diligence checklist under the four headings — physical, financial, legal, market — with a person and a deadline for each item. Then answer:

1. Who is your inspector, environmental firm, appraiser, and attorney? Confirm their availability and fees.
2. What conditions would cause you to walk away from a deal during due diligence?
3. What is the largest capital item the inspection found, and how does it change your offer or your budget?

## Exercise 12 — Syndication Terms (Module 12)

Read a sample syndication offering memorandum or operating-agreement summary and record:

- Entity type: ____________________
- Sponsor co-investment (amount and percentage): ____________________
- Acquisition fee: ____________________
- Asset management fee (basis and rate): ____________________
- Preferred return (rate and cumulative or non-cumulative): ____________________
- Split after the pref: ____________________
- Promote / split above the IRR hurdle: ____________________
- Hold period and reporting frequency: ____________________

Write five questions you would ask the sponsor before investing as a limited partner.

## Exercise 13 — Waterfall Practice (Module 13)

Build the Maple Court waterfall in a spreadsheet using the tiers in Module 13.

1. In Year 1, with $120,000 available for distribution, how much goes to the LPs and how much to the GP?
2. In a stabilized year with $300,000 available and no accrued pref, how much goes to each side?
3. Change the stabilized cash flow by 20 percent in each direction. How do the LP and GP distributions change?
4. Write a one-paragraph plain-language explanation of the waterfall that you could give to a prospective investor.

## Exercise 14 — Capital-Raising Worksheet (Module 14)

1. List 20 people in your network who invest in real estate or have expressed interest in it. For each, note what you know about their experience and interests.
2. Write a one-page summary of your background and investment approach that you could share in a general conversation, without mentioning a specific deal or return.
3. Have you scheduled a consultation with a securities attorney? Date: ____________________
4. What will you say when an investor asks a question you cannot answer?
5. How often will you report to investors, and what will each report contain?

## Exercise 15 — Investor Presentation Outline (Module 15)

Draft an investor presentation outline for Maple Court using the ten sections in Module 15. For each section, write two or three bullet points of what you would include. Then build a data-room table of contents listing every document you would provide to a qualified prospective investor.

Practice presenting the deal in 15 minutes, with five minutes for questions, to a colleague or advisor who will challenge your assumptions. Record the three hardest questions you were asked and your answers.

## Exercise 16 — Asset-Management Plan (Module 16)

1. Build a 90-day post-closing checklist for your next acquisition.
2. Draft a monthly asset-management review template: occupancy, collections, profit and loss against budget, capital spending against budget, maintenance backlog, lender reporting.
3. Draft a quarterly investor update template.
4. What occupancy, collection, turnover-time, and maintenance-response targets will you set for your property manager?

## Exercise 17 — Exit Comparison (Module 17)

For Maple Court, model a Year 5 refinance and a Year 5 sale side by side:

| | Refinance | Sale |
|---|---|---|
| Property value / sale price | | |
| New loan / loan payoff | | |
| Costs | | |
| Cash returned to investors | | |
| DSCR after refinance / net proceeds | | |

List the prepayment terms on your loan and the sale costs you would incur. Note the questions you will ask your CPA about the tax treatment of each option.

## Exercise 18 — Risk Register (Module 18)

Build a risk register with at least ten risks:

| Risk | Likelihood | Impact | Mitigation | Warning sign |
|---|---|---|---|---|
| | | | | |

Which three risks would cause you to walk away from a deal if they materialized during due diligence?

## Exercise 19 — Team and Pipeline (Module 19)

1. For each of the ten team roles in Module 19, write down who you will use or how you will find them.
2. Interview two brokers and two property managers this month. Record what you learned from each.
3. Start a deal pipeline log. Add five properties this week, with price, NOI, cap rate, DSCR, cash-on-cash, status, and the reason you passed or proceeded.

## Exercise 20 — Your 12-Month Plan (Module 20)

Write your 12-month plan with specific dates:

- Months 1–3 (learn and prepare): ____________________
- Months 4–6 (build the pipeline): ____________________
- Months 7–9 (pursue a deal): ____________________
- Months 10–12 (close or continue): ____________________

Who will hold you accountable for this plan? ____________________

When is your monthly review? ____________________

---

## Deal-Review Checklist

Use this checklist on every deal you underwrite. Do not skip a step because a deal looks attractive.

- [ ] Buy box fit confirmed in writing
- [ ] Rent roll read line by line; vacancies, expirations, delinquency noted
- [ ] Rent roll reconciled to bank deposits
- [ ] T-12 reviewed and compared to the OM; differences investigated
- [ ] NOI rebuilt from verified sources, not copied from the OM
- [ ] Each expense line checked against the T-12, tax bills, insurance quotes, and a property manager's estimate
- [ ] Cap rate verified against comparable sales in the submarket
- [ ] Loan sized; DSCR tested at the quoted rate and at a rate 1 percent higher
- [ ] Cash-on-cash, equity multiple, IRR, and yield on cost calculated
- [ ] Three downside cases tested (lower rents, higher expenses, lower occupancy)
- [ ] Renovation budget built item by item with a 10 to 15 percent contingency
- [ ] Rent increase tested against comparable renovated properties
- [ ] Inspection, environmental report, appraisal, and title review ordered
- [ ] Zoning, rent regulation, and tax reassessment checked with your attorney
- [ ] Risk register completed
- [ ] Advisors (attorney, CPA, broker, lender) have reviewed the deal for your situation
- [ ] If raising capital: securities attorney engaged and offering process followed

---

## Capital-Raising Worksheet

Complete this worksheet only under the guidance of your securities attorney. Do not use it to solicit investors or to advertise an investment.

- Sponsor background and track record: ____________________
- Sponsor co-investment: ____________________
- Total equity to be raised: ____________________
- Minimum investment: ____________________
- Target investor profile (per your attorney's advice): ____________________
- Preferred return, split, and promote: ____________________
- Fees (acquisition, asset management, disposition): ____________________
- Hold period and reporting frequency: ____________________
- Key risks to disclose: ____________________
- Documents to provide: offering memorandum, operating agreement, subscription documents, financial model
- Attorney review date: ____________________

## Investor-Presentation Outline

1. Cover and summary
2. The sponsor
3. The market
4. The property
5. The business plan
6. The financials (with assumptions and downside cases)
7. The structure and the waterfall
8. The risks
9. The timeline and next steps
10. Disclaimers and advisor notes

## Case-Study Analysis Exercises

**Case Study 1 — Maple Court.** What was the dollar difference between the seller's NOI and the verified NOI, and what did that difference mean for value at a 7.5 percent cap rate? What would you have offered, and why?

**Case Study 2 — Cedar Lane.** The going-in cap rate is well above market. List three explanations for that gap and how you would test each one before proceeding.

**Case Study 3 — Harbor View.** How does scale change the operating plan compared to Maple Court? What additional team and reporting would a 120-unit syndication require?

**Case Study 4 — Birchwood.** List the five findings that led the buyer to walk away. Which finding mattered most to you, and why? What would have to change for you to reconsider a deal like Birchwood?

---

*This workbook is education only. It is not individualized investment, legal, tax, or financial advice, and it does not provide securities advice. No return is guaranteed. Consult your own professional advisors before making any investment decision.*
