# Customer Onboarding Guide — The Commercial Real Estate Investor Masterclass

## RE-06 | EightyTwenty | $1,997

Welcome. This guide tells you what to do first, how to use the materials, and how to work through the course in 12 weeks. Read this guide before you start Module 1.

> This course is education only. It is not individualized investment, legal, tax, or financial advice, and it does not provide securities advice. Commercial real estate involves larger capital, longer timelines, and different risks than residential investing. No return is guaranteed. Before you buy, sell, syndicate, raise capital, or sign any document, consult a commercial real estate attorney, a CPA experienced in real estate, a licensed commercial broker, and a commercial lender. Consult a securities attorney before raising capital from others.

---

## What You Received

After purchase, you received these files as an instant download:

- `content.md` — the full 20-module masterclass, fully written, with four complete multifamily case studies
- `workbook.md` — the companion workbook with 20 module exercises, a deal-review checklist, a capital-raising worksheet, an investor-presentation outline, and case-study analysis exercises
- `templates/commercial-underwriting-model.csv` — the underwriting model (NOI, cap rate, DSCR, cash-on-cash, sensitivity cases, value-add math, exit modeling)
- `templates/syndication-deal-review-checklist.md` — the deal-review checklist for sponsors and limited partners
- `templates/capital-raising-template.md` — the investor-presentation outline and five email scripts
- `cover.png` — the black-and-gold cover image
- `sales-page.md`, `listing.json`, `cover.md`, `README.md` — listing and reference files

If any file is missing, contact marketplace support with your order number.

## What to Do First

1. **Read the Important Notice at the top of `content.md`.** It explains the limits of this course and why you need professional advisors. Do not skip it.
2. **Open the underwriting model.** Open `templates/commercial-underwriting-model.csv` in Excel or Google Sheets. Enter the formulas shown in the Formula column as live formulas, and save your own copy. You will use this model from Module 4 onward.
3. **Print or save the workbook.** Keep `workbook.md` open alongside the course. Complete each exercise before moving to the next module.
4. **Set up a deal folder.** Create a folder for your first live deal, with subfolders for the rent roll, T-12, leases, inspection reports, and your underwriting model. Good record-keeping starts before you have a deal.
5. **List your advisors.** Write down your commercial real estate attorney, CPA, broker, and lender — or, if you do not have them yet, the names you will contact in Week 1. If you plan to raise capital, add a securities attorney to that list before you speak to any investor.

## How to Use the Materials

- **Read the modules in order the first time.** Each module builds on the last. Modules 4 through 9 are the mathematical core: NOI, cap rate, pro forma, loans, underwriting, and returns. Do not skip them.
- **If you are underwriting a live deal right now,** work through Modules 4 through 9 first, then return to Module 1 and read the course in order.
- **Complete the workbook exercise at the end of each module** before moving on. The exercises are where the learning becomes skill.
- **Use the templates on real deals.** The underwriting model, the deal-review checklist, and the capital-raising template are designed to be used, not just read. Copy them into your deal folder and fill them in with verified numbers.
- **Return to the course as a reference.** After you finish, keep the course on hand. When you are underwriting a live deal, re-read Modules 5, 6, 8, and 11. When you are evaluating a syndication, re-read Modules 12, 13, and 15. When you are deciding on an exit, re-read Module 17.

## Suggested 12-Week Schedule

Work at a pace of one to two modules per week. Each week includes reading, a workbook exercise, and a practical task.

| Week | Modules | Practical task |
|---|---|---|
| 1 | 1–2: From Houses to Commercial; The Commercial Landscape | Write your one-sentence reason for moving into commercial. Choose your primary sector. |
| 2 | 3: Buy Box and Investment Thesis | Draft your one-page buy box and your investment thesis. List five brokers and five property managers to contact. |
| 3 | 4–5: NOI, Cap Rate, and Price; Reading a Rent Roll, T-12, and OM | Calculate cap rates for three listed properties. Read a sample OM, rent roll, and T-12. |
| 4 | 6: Building a Full Operating Pro Forma | Build a Year 1 pro forma in the underwriting model. Compare each expense line to the T-12. |
| 5 | 7: Commercial Loans | Calculate DSCR at the quoted rate and at a rate 1 percent higher. Identify which loan constraint binds. |
| 6 | 8–9: Full Underwriting Walkthrough; Returns | Rebuild the Maple Court walkthrough. Calculate cash-on-cash, equity multiple, IRR, and yield on cost. |
| 7 | 10–11: Value-Add Strategy; Due Diligence | Build a renovation budget item by item. Build your due diligence checklist and identify your inspector, appraiser, and attorney. |
| 8 | 12–13: Syndication Structures; The Waterfall | Read a sample offering memorandum. Build the Maple Court waterfall in a spreadsheet. |
| 9 | 14–15: Capital Raising; Investor Presentation | Complete the capital-raising worksheet. Draft an investor presentation outline for Maple Court. |
| 10 | 16–17: Asset Management; Exit Strategies | Build a 90-day post-closing checklist. Model a Year 5 refinance and a Year 5 sale side by side. |
| 11 | 18–19: Risk Management; Team and Pipeline | Build a risk register with at least ten risks. Interview two brokers and two property managers. Start your deal pipeline log. |
| 12 | 20: Your 12-Month Action Plan; Case Studies 1–4 | Write your 12-month plan with dates. Complete the case-study analysis exercises. Identify your accountability partner. |

After Week 12, continue underwriting at least one deal per week, keep your pipeline log current, and review your buy box monthly.

## How to Get Support

- **Order or file problems:** Email the marketplace support address with your order number and a description of the issue. The support team will respond and help you access your files.
- **Course content questions:** This is a self-paced digital course. There is no live coaching, office hours, or deal-review service included with this purchase. For questions about a specific deal, consult your own attorney, CPA, broker, and lender.
- **Refunds:** This product includes a 14-day money-back guarantee. If you are not satisfied within 14 days of purchase, contact support with your order number for a full refund.

## A Final Reminder

Do not buy a commercial property because you finished a course. Buy one because you underwrote it carefully, verified the numbers, built the team, and found a deal that meets your criteria — and only then. Patience is part of the strategy.

*Education only. Not investment, legal, tax, or financial advice. Not securities advice. No return is guaranteed.*
