# RE-06 — The Commercial Real Estate Investor Masterclass

- **SKU:** RE-06
- **Category:** Real Estate
- **Price:** $1,997 (one-time, 199700 cents) — Elite tier
- **Headline:** Step up to multifamily and commercial — underwrite, syndicate, and raise capital with confidence.
- **Audience:** Experienced residential investors and high-income professionals with $50,000+ to invest who want to move into multifamily or commercial deals, actively or as limited partners.

## Files in This Folder

- `content.md` — the full 20-module masterclass, fully written (20,019 words), with a table of contents, worked examples with real numbers (NOI / cap rate, DSCR and loan sizing, full 48-unit underwriting walkthrough, syndication waterfall), and 4 full multifamily case studies with complete line-item numbers.
- `workbook.md` — companion workbook: 20 module exercises, deal-review checklist, capital-raising worksheet, investor-presentation outline, and case-study analysis exercises.
- `templates/commercial-underwriting-model.csv` — underwriting model with NOI, cap rate, DSCR, cash-on-cash, IRR inputs, sensitivity cases, value-add math, and exit modeling, with formulas shown.
- `templates/syndication-deal-review-checklist.md` — deal-review checklist covering the sponsor, market, property, financials, fees and waterfall, securities compliance, and risks.
- `templates/capital-raising-template.md` — investor-presentation outline plus five email scripts (introduction, market research, offering documents, quarterly update, reporting bad news).
- `sales-page.md` — full sales page: headline, problem, solution, module list, who it is for / not for, price $1,997 with 14-day guarantee, 8 FAQs, and disclaimers.
- `listing.json` — marketplace listing data (sku RE-06, price_cents 199700, billing one_time, headline, description, delivery note, 12 SEO keywords, refund policy, support instructions).
- `cover.md` — cover design brief (black-and-gold luxury palette, typography, imagery direction, layout).
- `cover.png` — the generated premium black-and-gold cover image (1280 × 1920 PNG).
- `onboarding.md` — customer onboarding guide: what to do first, how to use the materials, suggested 12-week schedule, how to get support.

## Notes

- Education only — not individualized investment, legal, tax, or financial advice, and not securities advice. No guaranteed returns. Disclaimers are included in `content.md`, `workbook.md`, and `sales-page.md`.
- All content is original. No testimonials, sales figures, certifications, or reviews are fabricated. All property examples are fictional and illustrative.
- For upload to the existing live EightyTwenty marketplace. Do not build a new marketplace for this product.
