# Workbook — Holistic Wellness Coach Foundations (BEA-06)

Your companion to the course. Work through these exercises in order. Write your answers here or in a notebook. The point is practice, not perfection — a coach who has done the exercises understands the client who is doing them.

---

## Exercise 1 — The Coach You Want to Be (Module 1)

Write a one-paragraph description of the coach you want to be: who you help, what you help them with, and how a session with you feels. Keep it under 100 words.

My description:

___________________________________________________________________________
___________________________________________________________________________
___________________________________________________________________________
___________________________________________________________________________

Now underline the three most important words in your paragraph. Those words are the start of your practice identity.

---

## Exercise 2 — Scope of Practice (Module 2)

For each situation below, write **Coach** (inside your scope) or **Refer** (outside your scope — refer to a qualified professional), and name the professional you would refer to.

| Situation | Coach or Refer? | Refer to |
|---|---|---|
| Client wants help building a regular wind-down routine | | |
| Client asks you to diagnose their constant tiredness | | |
| Client wants a personalised meal plan for diabetes | | |
| Client wants help setting a goal to walk after lunch | | |
| Client reports thoughts of harming themselves | | |
| Client asks whether to stop a prescribed medication | | |
| Client wants help tracking a new stretching habit | | |
| Client reports chest pain during activity | | |
| Client wants general education about balanced meals | | |
| Client asks you to interpret their blood test results | | |

Answers: Coach — wind-down routine, walking goal, stretching habit, general education about balanced meals. Refer — everything else. If you got any wrong, re-read Module 2 and Appendix A before continuing.

Now write the referral sentence in your own words, the way you would actually say it:

___________________________________________________________________________

Practise saying it out loud three times.

---

## Exercise 3 — Listening Without Advice (Module 3)

Find a volunteer. Have a ten-minute conversation about a habit they would like to change. Use only open questions and reflections — no advice, no "you should," no stories about yourself.

Afterwards, answer these questions:

1. What was the hardest part of holding back advice?
___________________________________________________________________________
2. What did your volunteer say that surprised you?
___________________________________________________________________________
3. What open question worked best, and why?
___________________________________________________________________________
4. What will you do differently next time?
___________________________________________________________________________

---

## Exercise 4 — Your Own Client Snapshot (Module 4)

Complete a blank intake form (templates/client-intake-form.md) as if you were your own first client. Then write your client snapshot below.

**Sleep:** bedtime ______ wake time ______ how rested I feel (1–5) ______

What I would like to change: _______________________________________________

**Stress:** what a stressful week looks like for me: ___________________________

What helps me recover: ____________________________________________________

**Movement:** what a normal day involves: ____________________________________

Movement I enjoy: _________________________________________________________

**Nutrition:** a typical day of eating: ________________________________________

Where my meals happen: ____________________________________________________

**Routines:** what a good day looks like for me: ______________________________

**My first focus area (one only):** ___________________________________________

**Why this one:** ___________________________________________________________

---

## Exercise 5 — Sleep Log (Module 5)

Keep this log for seven days. Rate how rested you feel from 1 (exhausted) to 5 (fully rested).

| Day | Bedtime | Wake time | Rested (1–5) | What helped / got in the way |
|---|---|---|---|---|
| 1 | | | | |
| 2 | | | | |
| 3 | | | | |
| 4 | | | | |
| 5 | | | | |
| 6 | | | | |
| 7 | | | | |

After seven days, answer: what pattern do you notice? ________________________

One change I will test next week: ___________________________________________

---

## Exercise 6 — Stress Signals and Resets (Module 6)

1. My earliest stress signal (what I notice first in my body or mood):
___________________________________________________________________________
2. My most common triggers this week:
___________________________________________________________________________
3. What already helps me feel calmer, even a little:
___________________________________________________________________________
4. My two-minute reset (describe it exactly — what I do, where, for how long):
___________________________________________________________________________
5. One boundary I will set this week:
___________________________________________________________________________
6. One person who leaves me feeling better after I spend time with them:
___________________________________________________________________________

Track your stress signals for one week. At the end of the week, write one sentence about what you learned: _______________________________________________

---

## Exercise 7 — Movement Menu (Module 7)

List ten everyday activities you could offer a client. For each, note who it might suit and what barrier it avoids.

| # | Activity | Suits | Barrier it avoids |
|---|---|---|---|
| 1 | Ten-minute walk after lunch | Desk workers | No gym, no special clothes |
| 2 | | | |
| 3 | | | |
| 4 | | | |
| 5 | | | |
| 6 | | | |
| 7 | | | |
| 8 | | | |
| 9 | | | |
| 10 | | | |

Now design a movement goal for a fictional client who "hates exercise" and works at a desk. Use the five-question goal method from Module 9.

Goal: _____________________________________________________________________
When and where: ____________________________________________________________
Evidence it is done: ________________________________________________________
Confidence (1–10): ______ If below 7, how would you make it smaller? _________
Obstacle and backup plan: ___________________________________________________

---

## Exercise 8 — Food and Feelings Log (Module 8)

Keep this log for three days. Do not count calories. Do not judge. Notice timing, setting, and how you feel afterwards.

| Day / meal | What I ate | When | Where | Energy afterwards (1–5) | How I felt |
|---|---|---|---|---|---|
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |

Patterns I notice (timing and setting, not "good" or "bad" foods):
___________________________________________________________________________
___________________________________________________________________________

One routine change I will test (not a diet change): ___________________________
___________________________________________________________________________

---

## Exercise 9 — Goal-Setting Practice (Module 9)

Take each vague goal below and rewrite it using the five-question method.

**Vague goal 1:** "Get healthy."
Specific version: ___________________________________________________________
When and where: ____________________________________________________________
Evidence: __________________________________________________________________
Confidence (1–10): ______ Obstacle and backup plan: __________________________

**Vague goal 2:** "Sleep better."
Specific version: ___________________________________________________________
When and where: ____________________________________________________________
Evidence: __________________________________________________________________
Confidence (1–10): ______ Obstacle and backup plan: __________________________

**Vague goal 3:** "Eat better."
Specific version: ___________________________________________________________
When and where: ____________________________________________________________
Evidence: __________________________________________________________________
Confidence (1–10): ______ Obstacle and backup plan: __________________________

Now write one real goal for yourself, using the full method, and track it for one week. Use the goal-setting worksheet in the templates folder.

---

## Exercise 10 — Habit Tracker (Module 9)

Use this tracker for one client habit over four weeks — or for your own habit first. Tick each day the habit is done. Review the pattern at the end of each week, not the end of each day.

Habit: _____________________________________________________________________
Anchor (what it follows): ___________________________________________________

| Week | Mon | Tue | Wed | Thu | Fri | Sat | Sun | Total /7 |
|---|---|---|---|---|---|---|---|---|
| 1 | | | | | | | | |
| 2 | | | | | | | | |
| 3 | | | | | | | | |
| 4 | | | | | | | | |

Week 1 review — what worked, what got in the way: ___________________________
Week 2 review: _____________________________________________________________
Week 3 review: _____________________________________________________________
Week 4 review: _____________________________________________________________

What I will keep, change, or stop: ___________________________________________

---

## Exercise 11 — The 12-Week Programme Plan (Module 9)

Using the 12-week habit programme template, sketch a programme for a fictional client. Choose the client, the starting focus, and the habit for each phase.

Client (invented): __________________________________________________________
Starting focus: ____________________________________________________________
Weeks 1–2 habit: ___________________________________________________________
Weeks 3–4 addition: _________________________________________________________
Weeks 5–6 deepening: ________________________________________________________
Mid-point review (weeks 7–8) — what would you ask? __________________________
Weeks 9–10 expansion: _______________________________________________________
Weeks 11–12 consolidation — what does the client's maintenance routine look like?
___________________________________________________________________________

---

## Exercise 12 — Practice-Launch Checklist (Module 10)

Tick each item as you complete it. Do not take paying clients until the starred items are done.

### Offer and materials
- [ ] * Offer paragraph written (who it is for, what it includes, how long it lasts)
- [ ] * Intake form ready (templates/client-intake-form.md)
- [ ] * Session script ready (templates/coaching-session-script.md)
- [ ] * 12-week programme template ready (templates/12-week-habit-programme.md)
- [ ] * Goal-setting worksheet ready (templates/goal-setting-worksheet.md)
- [ ] * Red-flag referral list printed and kept with session notes (content.md, Appendix A)
- [ ] * Client agreement written (scope, sessions, payment, cancellation, refund terms)

### Business basics
- [ ] * Professional liability insurance checked for your area
- [ ] * Local rules checked (business registration, use of the title "coach")
- [ ] * Payment method set up
- [ ] * Booking method set up (calendar, message, or booking tool)
- [ ] * Client notes storage decided (private, secure, not shared)
- [ ] * Support contact details decided for client questions

### Launch
- [ ] * Launch date chosen: ____ / ____ / ____ (four weeks from today)
- [ ] Five people to tell in week 2 (real names):
  1. ________________________ 2. ________________________ 3. ________________________
  4. ________________________ 5. ________________________
- [ ] Five free introductory conversations offered
- [ ] First two or three programme clients enrolled
- [ ] First sessions delivered and notes written within 24 hours
- [ ] Feedback requested from each early client

### Weekly rhythm (once running)
- [ ] Sessions booked with preparation time before each one
- [ ] Notes written within 24 hours of each session
- [ ] Payments tracked
- [ ] One hour a week of learning protected
- [ ] Your own sleep, movement, and recovery protected

---

## My First 30 Days

Write your plan here, using the closing section of the course.

Days 1–7: __________________________________________________________________
Days 8–14: _________________________________________________________________
Days 15–21: ________________________________________________________________
Days 22–30: ________________________________________________________________

---

*Holistic Wellness Coach Foundations — BEA-06. Education only. This workbook does not provide medical advice, diagnosis, or treatment.*
