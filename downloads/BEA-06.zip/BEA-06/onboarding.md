# Onboarding Guide — Holistic Wellness Coach Foundations (BEA-06)

Welcome. This guide tells you what to do first, how to use the materials, and how to work through the programme in a sensible order.

---

## What you have received

| File | What it is |
|---|---|
| `content.md` | The full 10-module course. Read this first. |
| `workbook.md` | The companion workbook — 12 exercises matched to the modules. |
| `templates/coaching-session-script.md` | Your session script for a 45–60 minute coaching session, with session notes. |
| `templates/client-intake-form.md` | The form a client completes before the first session, including consent. |
| `templates/12-week-habit-programme.md` | The week-by-week structure for a client's 12-week programme. |
| `templates/goal-setting-worksheet.md` | The five-question goal method on one page, with a weekly review. |
| `sales-page.md` | The full sales page for this programme (for your reference). |
| `cover.png` | The product cover image. |
| `listing.json` | The marketplace listing data for this product. |
| `README.md` | An index of all the files in this product. |

All files are plain text (Markdown) except the cover image (PNG). They open on any computer, tablet, or phone. You can print the workbook and templates, or fill them in on screen.

---

## What to do first (Day 1)

1. **Read the note at the start of content.md.** It explains the scope of practice for this programme. This is the most important page in the whole product. Coaching is education and support for everyday habits — not medical advice, diagnosis, or treatment.
2. **Skim the table of contents** so you know where everything is.
3. **Read Modules 1 and 2 in full.** Module 1 tells you what a coach does. Module 2 tells you what a coach does not do, and when to refer a client to a qualified health professional. Do not skip Module 2.
4. **Print or save the red-flag referral list** (content.md, Appendix A) and keep it with your session script.

---

## Suggested schedule

Work through the modules in order, one or two a week, completing the action step at the end of each module before moving on.

| Week | Do this |
|---|---|
| 1 | Modules 1–2. Workbook Exercises 1–2. Read the red-flag list until the referral sentence feels natural. |
| 2 | Modules 3–4. Workbook Exercises 3–4. Practise a ten-minute coaching conversation with a friend, using only open questions. Complete an intake form as your own first client. |
| 3 | Modules 5–6. Workbook Exercises 5–6. Keep a sleep log for seven days and track your own stress signals for one week. |
| 4 | Modules 7–8. Workbook Exercises 7–8. Build your movement menu. Keep a food-and-feelings log for three days. |
| 5 | Module 9. Workbook Exercises 9–11. Run your own goal through the five-question method and track it for a week. Sketch a 12-week programme for a fictional client. |
| 6 | Module 10. Workbook Exercise 12 (practice-launch checklist). Choose a launch date four weeks ahead. |
| 7–10 | Follow the closing 30-day plan: rehearse the three sample sessions in Appendix C, hold free introductory conversations, enrol your first clients, and deliver your first sessions. |

There is no time limit. If a module takes longer, take longer — especially Modules 2, 3, and 9, which carry the core skills.

---

## How to use the templates

- **Session script:** Use it for every session until the shape becomes second nature. Read it before the session, keep it beside you during the session, and use the session-notes section afterwards.
- **Intake form:** Send it to a new client before the first session. Read it before you meet them. Note anything that needs a referral conversation.
- **12-week programme:** Start a fresh copy for each client. Fill in the client name, dates, and starting focus. Review the habit tracker together at every session.
- **Goal-setting worksheet:** Use one per goal, per client. If a client's confidence rating is below 7, make the goal smaller until it reaches 7 or above.

---

## How to use the workbook

Do the exercises yourself first. A coach who has kept a sleep log, tracked a habit, and set a goal through the five-question method understands the client who is doing the same. Exercises 5, 6, 8, and 9 ask you to track your own habits for a week — do them honestly, and bring what you learn into your coaching.

---

## Important reminders

- **Stay in scope.** Do not diagnose, treat, prescribe, or give personalised diet or exercise plans. Refer medical concerns to qualified health professionals. When in doubt, refer.
- **Practise before you charge.** Rehearse the sample sessions in Appendix C with a volunteer. Offer free introductory conversations before taking paying clients.
- **Check local rules.** Before taking paying clients, look into professional liability insurance for wellness coaches in your area and check whether your local area requires a business registration or a particular qualification to use the title "coach."
- **Keep client information private.** Store intake forms and session notes securely. Do not share them or discuss clients by name.

---

## How to get support

For help with your order or the course files, email the marketplace support address with your order number and a description of the issue, and the support team will respond. For questions about coaching practice, scope of practice, or local rules, speak to a qualified professional or your local regulator — the marketplace support team cannot give medical or legal advice.

---

*Holistic Wellness Coach Foundations — BEA-06. Education only.*
