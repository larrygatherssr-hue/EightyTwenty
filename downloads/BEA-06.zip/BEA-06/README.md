# Holistic Wellness Coach Foundations — BEA-06

A foundations programme in holistic wellness coaching — sleep, stress, movement, nutrition basics, and habit coaching — for building a coaching practice. Education only; no medical advice, diagnosis, or treatment claims.

- **Price:** $397 (one-time)
- **Category:** Beauty & Health
- **Headline:** Coach wellness with structure — sessions, habits, and goals that turn knowledge into paid work.

## Files

| File | What it is |
|---|---|
| `content.md` | The full 10-module course (10,392 words): coaching skills, scope of practice and referrals, the five foundations, goal-setting, the 12-week programme, practice launch, plus a red-flag list, glossary, and three sample sessions. |
| `workbook.md` | Companion workbook: 12 exercises including scope-of-practice scenarios, listening practice, sleep and stress logs, a food-and-feelings log, goal-setting practice, a habit tracker, and the practice-launch checklist. |
| `templates/coaching-session-script.md` | Full 45–60 minute session script with referral language and session notes. |
| `templates/client-intake-form.md` | Pre-session intake form with health information and signed scope-of-practice consent. |
| `templates/12-week-habit-programme.md` | Week-by-week 12-week client programme with a 12-week habit tracker. |
| `templates/goal-setting-worksheet.md` | Five-question goal-setting worksheet with weekly review. |
| `sales-page.md` | Full sales page: headline, problem, solution, module list, who it is for / not for, $397 price with 14-day guarantee, 8 FAQs, and disclaimers. |
| `listing.json` | Marketplace listing data (SKU BEA-06, $397.00, one-time). |
| `cover.md` | Cover design brief (black-and-gold luxury branding). |
| `cover.png` | The generated product cover image. |
| `onboarding.md` | Customer onboarding guide: what to do first, suggested 6-week schedule, how to use the templates, and how to get support. |
| `README.md` | This file. |
