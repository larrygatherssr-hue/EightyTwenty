# Coaching Session Script — Holistic Wellness Coach Foundations (BEA-06)

Use this script for a standard 45–60 minute coaching session. The wording is a guide, not a rigid script — use your own voice, but keep the structure and the order. Keep the red-flag referral list (content.md, Appendix A) with this script at all times.

**Education only.** This script is for coaching everyday habits. It is not medical advice, diagnosis, or treatment. If a client raises a medical concern, use the referral language in the "If a client raises a medical concern" box below and refer them to a qualified health professional.

---

## Before the session

- [ ] Read the client's intake form and last session's notes.
- [ ] Note the goal or habit from last time and the client's tracker, if shared.
- [ ] Have blank notes, this script, and the red-flag list ready.
- [ ] Start on time.

---

## 1. Opening and check-in (5–10 minutes)

Welcome the client warmly.

> "Welcome back. How has your week been?"

Listen. Do not interrupt. Then ask:

> "What stood out for you this week — anything that went well, or anything that got in the way?"

Reflect back the heart of what you hear:

> "It sounds like… [reflect in your own words]."

If the client shares something emotional, acknowledge it before moving on:

> "That sounds really hard. Thank you for telling me."

---

## 2. Review last week's goal (5 minutes)

> "Last time we agreed [goal in the client's words]. How did that go?"

- If the client did it: celebrate specifically. "You did it three nights out of four — that is real progress. What helped?"
- If the client did not do it: respond with curiosity, not disappointment. "Thank you for telling me. Let us look at what got in the way together."
- Ask: "What did you learn from the week — about the habit, or about what your week is really like?"

Record: goal from last time ______ Done? ______ What helped / got in the way: ______

---

## 3. Focus conversation (15–20 minutes)

Choose one focus for this session — the foundation you agreed, or the topic the client brings today.

Use open questions. Examples:

- "What does a good day look like for you with this?"
- "What is getting in the way right now?"
- "What have you already tried, and what happened?"
- "What would a small step look like this week?"
- "On a scale of 1 to 10, how important is this change to you — and why that number and not a lower one?"

Reflect, do not lecture. If you share general education, frame it as one option and ask what the client thinks:

> "One idea other clients have found useful is… What do you think of that — would it fit your week?"

**Do not:** give advice with "you should," judge food or lifestyle choices, comment on weight or appearance, promise results, or offer medical, nutritional, or psychological advice.

---

## 4. Choose the week's action (10 minutes)

Guide the client through the five goal questions. Write the answers down together.

1. What exactly will you do? _______________________________________________
2. When and where? (day, time, place) ________________________________________
3. How will you know it is done? (the evidence) _______________________________
4. Confidence, 1–10: ______ If below 7, make the goal smaller until it is 7 or above.
   Revised goal: ____________________________________________________________
5. What might get in the way, and what will you do then? _______________________

Read the final goal back to the client in their own words and confirm it.

> "So this week you will [goal]. Is that right?"

Agree how the client will track it and how you will check in:

Tracking method: ______________________ Check-in: ___________________________

---

## 5. Close (5 minutes)

Summarise the session in two or three sentences, in the client's words:

> "Today we talked about [focus]. You chose [goal]. We will check in on [day/method]."

Confirm the next session: date ______ time ______ location/format ______

End with encouragement:

> "Thank you for your honesty today. I am looking forward to hearing how the week goes."

---

## After the session (within 24 hours)

- [ ] Write session notes: date, focus, goal agreed, confidence rating, obstacle plan, next session date.
- [ ] Send the client a short written summary of the goal they chose.
- [ ] File notes privately and securely. Do not share them.
- [ ] Note anything that needs follow-up (for example, a referral you suggested).

---

## If a client raises a medical concern

If a client reports a symptom, a diagnosis, a medication question, an eating disorder, persistent low mood, or anything that sounds like a health problem:

1. Listen with care. Do not assess, diagnose, or reassure medically.
2. Say, warmly and clearly:

> "That sounds important, and it is outside what I coach. I would like you to speak to your doctor about it, and I can keep supporting you with the everyday habits alongside that care."

3. If the concern is urgent (chest pain, breathlessness, fainting, thoughts of harming themselves), encourage urgent professional help immediately.
4. Note the referral in your session notes.
5. Do not continue coaching the medical topic. Return to everyday habits only where appropriate.

---

## Session notes (copy per session)

Client: ______________________ Date: __________ Session number: ______

Focus today: ____________________________________________________________

Last week's goal — outcome: _______________________________________________

This week's goal: _________________________________________________________

Confidence (1–10): ______ Obstacle and backup plan: __________________________

Referral made? Yes / No — details: _________________________________________

Next session: ______________________ Notes sent to client? Yes / No
