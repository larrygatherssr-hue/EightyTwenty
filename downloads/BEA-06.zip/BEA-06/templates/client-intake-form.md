# Client Intake Form — Holistic Wellness Coach Foundations (BEA-06)

**Please complete this form before your first session and return it to your coach.**

Coaching is education and support for everyday wellness habits. It is not medical care. It does not diagnose, treat, or cure any condition, and it is not a substitute for advice from a qualified health professional. Your coach will refer you to the right professional for any medical concern.

---

## About you

Full name: ________________________________________________________________

Date of birth: ____ / ____ / ________

Phone: ________________________________ Email: ________________________________

Emergency contact (name and phone): _________________________________________

How did you hear about this coaching? ________________________________________

---

## What brings you to coaching

What would you like to change, and why now?

___________________________________________________________________________
___________________________________________________________________________

What does a good day look like for you?

___________________________________________________________________________

What have you tried before, and what happened?

___________________________________________________________________________
___________________________________________________________________________

On a scale of 1 to 10, how important is this change to you? ______

What would you like to be different in three months?

___________________________________________________________________________

---

## Your days at the moment

**Sleep:** What time do you usually go to bed and get up? ______________________

How rested do you usually feel in the morning (1–5)? ______

**Stress:** What does a stressful week look like for you? ______________________

What helps you feel calmer? _________________________________________________

**Movement:** What does movement look like in a normal day? ____________________

What kind of movement do you enjoy? _________________________________________

**Eating:** Walk through a typical day of eating, from morning to night.

___________________________________________________________________________
___________________________________________________________________________

Where do your meals usually happen? _________________________________________

**Routines:** Describe your mornings and evenings in a few lines.

___________________________________________________________________________

---

## Health information relevant to coaching safety

Please answer honestly. This information helps your coach keep you safe and know when to refer you to a qualified professional. It is kept private.

Do you have any current health conditions? Yes / No — details: ________________

Are you taking any medication? Yes / No — details: ___________________________

Are you pregnant, or have you had surgery recently? Yes / No — details: ________

Do you have any injury or pain that affects your movement? Yes / No — details:

___________________________________________________________________________

Have you been diagnosed with any sleep condition, eating disorder, or mental health condition? Yes / No — details (only what you are comfortable sharing):

___________________________________________________________________________

Your doctor's name and practice (optional, but helpful if a referral is needed):

___________________________________________________________________________

Do you have any food allergies? Yes / No — details: ___________________________

Is there anything else your coach should know to keep sessions safe for you?

___________________________________________________________________________

---

## Consent and scope of practice

Please read and sign.

- I understand that wellness coaching is education and support for everyday habits (sleep, stress, movement, general nutrition education, and habit-building). It is not medical advice, diagnosis, treatment, or therapy.
- I understand that my coach will not create personalised diet plans, prescribe exercise or supplements, interpret medical results, or advise on medication.
- I understand that I should speak to my doctor or another qualified health professional about any medical concern, and that my coach may suggest I do so.
- I understand that my session notes and personal information will be kept private and will not be shared without my consent.
- I agree to tell my coach about any change in my health that could affect coaching.

Client signature: ________________________________ Date: ____ / ____ / ________

Coach signature: ________________________________ Date: ____ / ____ / ________

---

*Keep the completed form private and secure. Do not share it. Review it before the first session and note anything that needs a referral conversation.*
