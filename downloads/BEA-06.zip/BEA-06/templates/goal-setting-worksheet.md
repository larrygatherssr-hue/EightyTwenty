# Goal-Setting Worksheet — Holistic Wellness Coach Foundations (BEA-06)

Use one worksheet per goal. A goal that passes all five questions is a goal the client is likely to complete.

Client: ______________________ Date: ____ / ____ / ________ Coach: ______________

---

## 1. What exactly will you do?

Name the action in plain words. Be specific — "walk for ten minutes after lunch" rather than "exercise more."

___________________________________________________________________________
___________________________________________________________________________

## 2. When and where?

Name the day, time, and place.

Day(s): ______________________ Time: ______________________ Place: ______________

## 3. How will you know it is done?

Name the evidence — a ticked box, a logged walk, a phone on charge by 10:30 p.m.

___________________________________________________________________________

## 4. How confident are you that you can do it this week?

Circle a number from 1 (not confident at all) to 10 (completely confident).

1 — 2 — 3 — 4 — 5 — 6 — 7 — 8 — 9 — 10

**If your number is below 7, the goal is too big.** Make it smaller until you reach 7 or above. For example: fewer days, a shorter time, an easier version.

Revised goal (if needed): ___________________________________________________
___________________________________________________________________________

Revised confidence (1–10): ______

## 5. What might get in the way, and what will you do then?

Name the obstacle and a backup plan in advance.

Obstacle: __________________________________________________________________

Backup plan: _______________________________________________________________

---

## My goal, in my own words

Read it back and confirm it.

___________________________________________________________________________
___________________________________________________________________________

## How I will track it

Tracking method (tick box, phone note, tracker, message to coach): ______________

Check-in with coach: ________________________________________________________

---

## Weekly review

Week of: ____ / ____ / ________

Did I do it? Days completed: ______ / ______

What helped: _______________________________________________________________

What got in the way: ________________________________________________________

What I learned: ____________________________________________________________

Keep, change, or stop? ______________________________________________________

Next week's goal: ___________________________________________________________

---

## Worked example (for the coach's reference — do not hand this to the client as their goal)

**Vague goal:** "Sleep better."

**After the five questions:** "Phone on silent at 10:30 p.m., read for 20 minutes, lights out by 11 p.m., on Monday, Wednesday, and Friday. I will tick it in my habit tracker each night and send the tracker to my coach on Sunday. Confidence: 8. Obstacle: late work emails. Backup plan: if work runs late, the routine still happens, just 30 minutes later, and the phone still goes on silent."

---

*Education only. This worksheet is for coaching everyday habits. It is not medical advice, diagnosis, or treatment.*
