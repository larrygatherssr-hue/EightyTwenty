# 12-Week Client Habit Programme — Holistic Wellness Coach Foundations (BEA-06)

A week-by-week structure for one client's 12-week coaching programme. Adapt it to the individual client — the template is a structure, not a rigid script. One focus at a time. One small habit at a time.

**Education only.** This programme coaches everyday habits. It is not medical advice, diagnosis, or treatment. Refer the client to a qualified health professional for any medical concern.

---

## Client programme overview

Client name: ______________________ Coach: ______________________

Start date: ____ / ____ / ________ End date: ____ / ____ / ________

Starting focus (one foundation): ____________________________________________

Session rhythm: weekly / fortnightly (circle one). Session length: ______ minutes.

Check-in between sessions: _________________________________________________ (for example, short message once a week, tracker shared before each session)

---

## How to use this template

- **Weeks 1–2:** Foundation. Intake, snapshot, one focus, first small goal.
- **Weeks 3–4:** Build. Add a second small habit in the same foundation.
- **Weeks 5–6:** Deepen. Strengthen the routine. Add a second foundation only if the client is ready.
- **Weeks 7–8:** Mid-point review. Full review, reset goals for the second half.
- **Weeks 9–10:** Expand. Add a third element or deepen existing habits.
- **Weeks 11–12:** Consolidate. Review the whole programme, celebrate progress, design the client's maintenance routine.

Each week: one theme, one session focus, one habit to practise, one check-in. Review the habit tracker together at every session. Celebrate what happened. Investigate what did not, without blame.

---

## Weeks 1–2: Foundation

**Week 1 — First session: intake and snapshot**
- Session focus: Welcome, scope of practice, confidentiality. Walk through the five foundations. Build the client snapshot.
- Habit to practise: Complete the intake form before the session; start a simple daily log (sleep times and one line about the day).
- Check-in: Send the written session summary within 24 hours.
- Session notes: ___________________________________________________________

**Week 2 — Choose the focus**
- Session focus: Choose one foundation. Set the first small goal using the five-question method.
- Habit to practise: The first small goal, tracked daily.
- Goal agreed: ____________________________________________________________
- Confidence (1–10): ______ Obstacle and backup plan: ________________________

---

## Weeks 3–4: Build

**Week 3 — Review and adjust**
- Session focus: Review the first goal. What worked? What got in the way? Adjust the design, not the client.
- Habit to practise: Continue the first habit; refine the anchor or timing if needed.
- Adjustment made: ________________________________________________________

**Week 4 — Add a second small habit**
- Session focus: Add a second small habit in the same foundation (for example, a morning daylight walk alongside the wind-down routine).
- Habit to practise: ________________________________________________________
- Goal agreed: ____________________________________________________________
- Confidence (1–10): ______

---

## Weeks 5–6: Deepen

**Week 5 — Strengthen the routine**
- Session focus: Make the routine easier to repeat — better anchors, fewer decisions, a simpler tracker.
- Habit to practise: ________________________________________________________
- What is making the routine easier or harder? ________________________________

**Week 6 — Second foundation (only if the client is ready)**
- Session focus: If the first foundation is steady, choose a second (for example, a short walk alongside the sleep routine). If it is not steady, deepen the first instead.
- Habit to practise: ________________________________________________________
- Decision (add second foundation / deepen first): ____________________________

---

## Weeks 7–8: Mid-point review

**Week 7 — Full review session**
- Session focus: What has changed? What has the client learned about themselves? What should stay, change, or stop?
- Questions to ask: "What are you most pleased with?" "What surprised you?" "What would you like the second half to focus on?"
- Review notes: ___________________________________________________________
- ___________________________________________________________________________

**Week 8 — Reset goals for the second half**
- Session focus: Set fresh goals for weeks 9–12 using the five-question method.
- Goal agreed: ____________________________________________________________
- Confidence (1–10): ______ Obstacle and backup plan: ________________________

---

## Weeks 9–10: Expand

**Week 9 — Expand**
- Session focus: Add a third element or deepen the existing habits. The client begins to run the routine with less prompting.
- Habit to practise: ________________________________________________________

**Week 10 — Independence check**
- Session focus: Ask the client to plan their own week — goals, anchors, tracking — with the coach reviewing rather than leading.
- Client's self-planned week: _______________________________________________
- What the client did well on their own: _____________________________________

---

## Weeks 11–12: Consolidate and plan ahead

**Week 11 — Review the whole programme**
- Session focus: Walk through all 12 weeks. Celebrate progress honestly and specifically. Name what changed.
- Progress summary: ________________________________________________________
- ___________________________________________________________________________

**Week 12 — Maintenance routine and next steps**
- Session focus: Design the client's own maintenance routine for after the programme ends. Agree what ongoing support looks like: monthly check-in, a second programme, or a confident goodbye.
- Client's maintenance routine: _____________________________________________
- ___________________________________________________________________________
- Ongoing support agreed: ___________________________________________________

---

## Habit tracker (copy per habit)

Habit: ______________________ Anchor: ______________________ Start date: ________

| Week | Mon | Tue | Wed | Thu | Fri | Sat | Sun | Total /7 |
|---|---|---|---|---|---|---|---|---|
| 1 | | | | | | | | |
| 2 | | | | | | | | |
| 3 | | | | | | | | |
| 4 | | | | | | | | |
| 5 | | | | | | | | |
| 6 | | | | | | | | |
| 7 | | | | | | | | |
| 8 | | | | | | | | |
| 9 | | | | | | | | |
| 10 | | | | | | | | |
| 11 | | | | | | | | |
| 12 | | | | | | | | |

---

## Programme completion summary (complete at week 12)

Client: ______________________ Programme dates: __________ to __________

Starting focus: ______________________ Ending focus: ________________________

Habits established: ________________________________________________________

What the client is most pleased with: ________________________________________

Maintenance routine agreed: ________________________________________________

Coach notes: ______________________________________________________________
