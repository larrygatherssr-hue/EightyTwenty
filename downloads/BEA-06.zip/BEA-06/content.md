# Holistic Wellness Coach Foundations

## Coach wellness with structure — sessions, habits, and goals that turn knowledge into paid work

---

## A Note Before You Begin

This programme is education for aspiring wellness coaches. It teaches you how to run structured coaching sessions, help clients set goals, build habits, and organise a coaching practice. It is not medical training. It does not qualify you to diagnose illness, treat disease, prescribe diets or supplements, interpret medical tests, or provide therapy or counselling for mental health conditions.

Throughout this course you will see the same rule repeated, because it is the most important rule in wellness coaching: **stay inside your scope of practice.** When a client raises a medical concern — a symptom, a diagnosis, a medication question, an eating disorder, persistent low mood, or anything that sounds like a health problem — your job is to listen with care, avoid giving medical advice, and refer them to a qualified health professional. Knowing when to refer is not a weakness. It is what makes you a trustworthy coach.

Nutrition content in this programme is general education about balanced eating patterns. It is not a personalised diet plan, and it is never a treatment for a medical condition. Movement content is general education about everyday activity. It is not rehabilitation, physiotherapy, or a personal training prescription. Sleep and stress content is general education about daily habits. It is not treatment for insomnia, anxiety, depression, or any sleep or mental health disorder.

If you follow the referral guidance in Module 2 and the scope-of-practice checklist in every session template, you will be able to coach with confidence and keep your clients safe.

---

## Table of Contents

- Introduction: Why Structure Beats Knowledge
- Module 1 — What a Holistic Wellness Coach Actually Does
- Module 2 — Scope of Practice, Ethics, and When to Refer
- Module 3 — The Coaching Conversation: Listening, Questions, and Trust
- Module 4 — The First Session: Intake, Assessment, and the Client Snapshot
- Module 5 — Sleep Foundations: Coaching Rest Without Medical Claims
- Module 6 — Stress and Calm: Coaching Everyday Stress and Recovery
- Module 7 — Movement Foundations: Coaching Everyday Activity
- Module 8 — Nutrition Basics: General Education, Not Diet Plans
- Module 9 — Goals, Habits, and Accountability: The 12-Week Client Programme
- Module 10 — Launching Your Practice: Packages, Pricing, and First Clients
- Closing: Your First 30 Days as a Coach
- Appendix A — Red-Flag Referral List
- Appendix B — Glossary

---

## Introduction: Why Structure Beats Knowledge

Most aspiring wellness coaches do not lack knowledge. They have read the books, taken the yoga training, completed the nutrition short course, or spent years in a beauty or fitness role hearing clients talk about sleep, stress, food, and energy. What they lack is structure: a way to turn that knowledge into a session a client will pay for, a goal a client will actually follow, and a programme a client can finish.

This course exists to give you that structure. By the end of it you will be able to:

1. Run a complete coaching session, from opening question to closing commitment, in 45 to 60 minutes.
2. Take a new client through intake, set a baseline, and agree on one clear focus area.
3. Coach the five foundations — sleep, stress, movement, nutrition, and habits — with practical, everyday strategies.
4. Build a 12-week client habit programme with weekly themes, check-ins, and accountability.
5. Set goals with a client that are specific, measurable, and small enough to succeed.
6. Price, package, and launch a coaching practice, and enrol your first paying clients.

### How to use this course

Work through the modules in order. Each module ends with an action step — something to do, write, or practise before moving on. The companion workbook gives you the exercises. The templates folder gives you the documents you will use with real clients: a session script, an intake form, a 12-week habit programme, and a goal-setting worksheet. Do not skip the practice steps. Coaching is a practical skill, and reading about a session is not the same as running one. Practise each session format with a friend, a family member, or a fellow student before you charge for it.

### What "holistic" means here

Holistic means looking at the whole person and the whole day, not treating one habit in isolation. A client who sleeps badly often eats differently the next day. A client under stress often moves less. A client who moves more often sleeps better. Your job is not to fix one thing. It is to help the client see how their days connect, choose one small change that supports several areas at once, and build from there.

It does not mean you treat every problem. It means you see the whole picture, work on the part that is yours to coach, and refer the rest.

---

## Module 1 — What a Holistic Wellness Coach Actually Does

### 1.1 The job in one sentence

A holistic wellness coach helps a client look at their everyday habits — sleep, stress, movement, eating, and daily routines — choose small changes that fit their real life, and follow through on them with support and accountability.

Notice what is not in that sentence. You do not diagnose. You do not prescribe. You do not hand a client a rigid plan and tell them to obey it. You guide, you ask, you listen, and you help the client design their own change.

### 1.2 What a session looks like

A typical coaching session lasts 45 to 60 minutes and follows a simple shape:

1. **Check-in (5–10 minutes).** How has the week been? What worked? What got in the way?
2. **Review (5 minutes).** Look at the habit or goal from last time. What did the client actually do?
3. **Focus (15–20 minutes).** Explore one topic — sleep, stress, movement, food, or routine. Ask questions. Help the client notice patterns.
4. **Choose (10 minutes).** Agree on one small action for the coming week. Make it specific: what, when, where, and how the client will know it is done.
5. **Close (5 minutes).** Summarise what the client chose, confirm the next session, and end with encouragement.

That shape is the backbone of this whole programme. Modules 3 and 4 teach you how to run it. Module 9 teaches you how to repeat it across 12 weeks. The session script template in the templates folder is this shape written out word for word, ready to use.

### 1.3 Coaching is not teaching, training, or therapy

These four roles are often confused. Knowing the difference protects you and your clients.

- **Teaching** is giving information. A coach does share general education — for example, explaining why regular wake times support steadier energy. But information alone is not coaching. If you only lecture, the client may learn something and change nothing.
- **Training** is telling someone exactly what to do and correcting their form or performance. A fitness trainer prescribes workouts. A coach helps the client decide what movement fits their life and supports them in doing it.
- **Therapy and counselling** treat mental health conditions, process trauma, and diagnose psychological problems. That is licensed clinical work. A coach does not do it.
- **Coaching** is a partnership. The client is the expert on their own life. You are the expert on the process: asking good questions, keeping the conversation focused, helping the client set a goal, and holding them accountable with kindness.

When a client says, "Just tell me what to do," resist the urge to hand over a plan. Instead, ask what they have already tried, what a realistic version would look like in their week, and what they are willing to commit to. A plan the client designs is a plan the client follows.

### 1.4 The five foundations

Every client programme in this course is built on five foundations:

1. **Sleep** — regular timing, a wind-down routine, and a bedroom that supports rest.
2. **Stress and recovery** — noticing stress signals, building short calm practices, and protecting recovery time.
3. **Movement** — everyday activity woven into the day, not only formal exercise.
4. **Nutrition basics** — general education about balanced meals, hydration, and regular eating patterns.
5. **Habits and routines** — the systems that make the other four stick: planning, tracking, and accountability.

You will rarely work on all five at once. Most clients start with one. Your skill is choosing the right starting point — usually the foundation where a small change will make the biggest difference to how the client feels day to day.

### 1.5 Who you serve

Your most likely early clients are people much like the people you already know: busy adults who feel tired, stressed, or stuck in routines they do not enjoy, and who want practical support rather than another diet or fitness challenge. Yoga and fitness instructors and beauty professionals have a natural advantage here: you already have clients who trust you, see you regularly, and talk to you about their lives. Coaching is a natural second service for those relationships — provided you are clear that coaching is a separate service with its own sessions, price, and boundaries.

### 1.6 Action step

Write a one-paragraph description of the coach you want to be: who you help, what you help them with, and how a session with you feels. Keep it under 100 words. You will refine it in Module 10 when you write your practice offer.

---

## Module 2 — Scope of Practice, Ethics, and When to Refer

### 2.1 Why this module comes second

Scope of practice is not a boring legal footnote. It is the foundation your whole practice stands on. A coach who stays in scope is trusted by clients, respected by health professionals, and protected from the serious harm that comes from giving advice they are not qualified to give. Read this module carefully. Return to it whenever you are unsure.

### 2.2 Your scope: what you do

As a holistic wellness coach, you:

- Help clients reflect on their daily habits and routines.
- Share general education about sleep, stress, movement, and nutrition.
- Help clients set personal wellness goals and build habits.
- Support accountability through regular check-ins.
- Encourage clients to seek qualified professional advice for medical, nutritional, psychological, or physical concerns.

### 2.3 Outside your scope: what you do not do

You do not:

- Diagnose any illness, condition, or disorder — physical or mental.
- Treat, cure, or claim to improve any disease or condition.
- Prescribe, recommend, or adjust medication, supplements, or herbal remedies for a medical purpose.
- Create personalised diet plans, calorie targets, or meal plans for medical conditions.
- Design rehabilitation or corrective exercise programmes, or work with injuries.
- Provide psychotherapy, counselling, or trauma treatment.
- Interpret blood tests, scans, or other medical results.
- Tell a client to stop or change a treatment their doctor has prescribed.

If a client asks you to do any of these things, the correct answer is a warm, clear referral: "That is outside what I am trained to coach. I think you would get the best help from [the right professional], and I am happy to support you with the everyday habits alongside that care."

### 2.4 The referral rule

Use this rule in every session: **if you are unsure whether something is inside your scope, treat it as outside your scope and refer.** It is always better to refer unnecessarily than to miss a problem that needed professional care. No client has ever been harmed by a coach saying, "I think it is worth checking this with your doctor." Clients respect that honesty. It builds trust rather than losing it.

### 2.5 Red flags: refer promptly

Appendix A lists red flags in full. Learn the most important ones now. Refer a client to a qualified health professional promptly — and encourage urgent care where indicated — if they report:

- Chest pain, breathlessness, fainting, or a sudden severe headache.
- Thoughts of harming themselves or others.
- Rapid, unexplained weight loss or gain, or signs of an eating disorder.
- Persistent low mood, anxiety that interferes with daily life, panic attacks, or poor sleep that has lasted for weeks despite basic habit changes.
- A new or worsening symptom of any kind, pain that does not settle, or a lump, bleeding, or change they are worried about.
- Pregnancy, a recent surgery, a new diagnosis, or a change in medication — before starting any new movement or eating routine.
- Dizziness, numbness, or weakness.

You are not expected to assess these situations clinically. You are expected to notice them, take them seriously, and point the client to the right professional quickly. Keep the referral list in Appendix A with your intake forms.

### 2.6 Confidentiality and boundaries

Clients will tell you personal things. Protect that trust:

- Keep client notes private and secure. Do not share them, discuss clients by name with others, or post about a client on social media — even without a name, details can identify someone.
- Do not coach family members or close friends for money unless you can hold a professional boundary. It is usually wiser to practise with them for free and charge strangers and acquaintances.
- Keep sessions to their agreed time and place. Do not become a client's on-call counsellor between sessions. Offer a clear channel (for example, a short weekly check-in message) and clear limits.
- Do not accept gifts or favours that could compromise the professional relationship.

### 2.7 Honesty in marketing

Do not promise results you cannot guarantee. Do not claim a qualification, certification, or accreditation you do not hold. Do not use before-and-after photos, weight-loss claims, or health outcome claims to sell coaching. Describe what you do, who it is for, and how the programme works — and let the structure speak for itself. The sales page for this programme follows the same rule: no fabricated testimonials, no invented figures, no guaranteed outcomes.

### 2.8 Insurance and basic business protection

Before you take paying clients, look into professional liability insurance for wellness coaches in your country or state, and check whether your local area requires a business registration, a licence, or a particular qualification to use the title "coach." Rules vary widely by location, and this course cannot give legal advice for every jurisdiction. A short conversation with a local insurance broker and a check of your local regulator's guidance is a sensible first step. Keep a signed client agreement and intake form for every paying client (templates are included in this programme).

### 2.9 Action step

Copy the red-flag list from Appendix A onto a single page and keep it with your session script. Practise saying the referral sentence out loud three times until it feels natural: "That sounds important, and it is outside what I coach. I would like you to speak to your doctor about it, and I can keep supporting you with the everyday habits alongside that."

---

## Module 3 — The Coaching Conversation: Listening, Questions, and Trust

### 3.1 Listening is the skill

New coaches often worry about what to say. Experienced coaches know that listening matters more. A client who feels truly heard will tell you what they need. A client who feels lectured will stop talking.

Good listening in coaching means:

- **Give the client your full attention.** Put your phone away. Face the client. Take brief notes, but do not write while they are speaking about something emotional.
- **Do not interrupt.** Let the client finish. Silence is not a problem. A pause of five seconds often brings out the most honest sentence of the session.
- **Reflect back.** Repeat the heart of what you heard in your own words: "It sounds like mornings are the hardest part of your day." Reflection shows you listened and lets the client correct you if you misunderstood.
- **Notice what is not said.** A client who laughs while describing a stressful week, or who goes quiet when you mention sleep, is telling you something. Gently name it: "I noticed you went quiet when we talked about evenings. What is happening then?"

### 3.2 Questions that open, not close

Closed questions ("Do you sleep well?") get a yes or no and the conversation stops. Open questions invite the client to think and talk. Use them far more often.

Open questions to keep in your pocket:

- "What does a good day look like for you?"
- "What is getting in the way of that right now?"
- "What have you already tried, and what happened?"
- "What would a small step look like this week?"
- "How will you know it worked?"
- "What might make it hard, and how could you handle that?"
- "On a scale of 1 to 10, how important is this change to you — and why that number and not a lower one?"
- "What would you like to be different in three months?"

That last question about the scale is a powerful one. When a client says "7," ask why not a 5. Their answer tells you their real motivation — and motivation in their own words is far stronger than any reason you could give them.

### 3.3 Avoid the traps

Three habits quietly damage coaching conversations:

1. **Advice-giving.** Every time you say "You should…", you take ownership of the change away from the client. Replace advice with a question: "What options can you see?" If you do share an idea, frame it as one option and ask what the client thinks of it.
2. **Fixing feelings.** When a client is upset, do not rush to solve the problem. Acknowledge the feeling first: "That sounds really hard." Then, when they are ready, move to action.
3. **Judgement.** Never comment on a client's weight, food choices, or lifestyle with disapproval. Your tone must be warm and neutral at all times. A client who feels judged will not come back — and will not change.

### 3.4 Building trust in the first minutes

Trust is built from small consistencies: starting on time, remembering what the client said last week, following up on what you promised, and being honest about what you do not know. It is also built by how you handle the first difficult moment — the first time a client says they did not do what they agreed, or the first time they tell you something worrying. Respond with curiosity, not disappointment: "Thank you for telling me. Let us look at what got in the way together." That response is what turns a client into a long-term client.

### 3.5 Worked example: a five-minute coaching exchange

**Client:** "I know I should eat better, but by the evening I am too tired to cook, so I just order food."

**Coach (advice trap):** "You should meal-prep on Sundays." — The client hears a chore they will not do.

**Coach (coaching response):** "Evenings sound exhausting. What does a typical evening look like once you get home?" — The client talks. It turns out they get home at 7 p.m., hungry, and cooking feels like another hour of work.

**Coach:** "What would make evenings easier — something that takes less than ten minutes, or something you could prepare earlier?" — The client chooses: a few simple ten-minute meals they can make from cupboard ingredients.

**Coach:** "Which one could you try this week, and on which evening?" — The client picks Wednesday. The goal is now specific, small, and theirs.

Notice that the coach never prescribed a diet, never judged the takeaway food, and never gave a lecture about nutrition. The client left with one action they chose themselves.

### 3.6 Action step

Practise a ten-minute coaching conversation with a friend. Use only open questions and reflections — no advice, no "you should." Afterwards, ask your friend how it felt to be listened to that way. Write down what was hard about holding back advice.

---

## Module 4 — The First Session: Intake, Assessment, and the Client Snapshot

### 4.1 Why the first session matters

The first session sets the tone for everything that follows. A rushed first session produces a vague goal and a client who drifts away. A careful first session produces a clear picture of the client's life, one agreed focus area, and a client who feels understood. Take the full session for it. Do not try to do intake and deep coaching in the same hour.

### 4.2 Before the session: the intake form

Send the client intake form (in the templates folder) before the first session and ask them to complete it in advance. It covers:

- Contact details and emergency contact.
- Current daily routines: sleep times, work pattern, movement, meals.
- What they would like to change and why now.
- What they have tried before and what happened.
- Medical information relevant to coaching safety: current health conditions, medications, pregnancy, recent surgery, injuries, and their doctor's contact details if they are happy to share them.
- A consent and scope-of-practice acknowledgement: the client confirms they understand coaching is education and support, not medical care, and that they will seek professional advice for medical concerns.

Read the form before the session. Note anything that needs a referral conversation, and note the client's own words about what they want. Use their words back to them in the session — it shows you read it.

### 4.3 The first session structure (60 minutes)

**Minutes 0–10: Welcome and agreement.** Welcome the client. Explain how coaching works, what a session looks like, confidentiality, and your scope of practice in plain language. Agree how you will work together: session length, frequency, how check-ins work between sessions, and what happens if a session is missed. Ask: "What would make these sessions useful for you?"

**Minutes 10–30: The client snapshot.** Walk through the five foundations with the client. For each one, ask two questions: "How is this going at the moment?" and "How would you like it to be?" Keep notes under each heading. You are building a snapshot, not solving everything today.

- Sleep: bedtime, wake time, how rested they feel.
- Stress: what a stressful week looks like, what helps them recover.
- Movement: what a normal day involves, what movement they enjoy.
- Nutrition: a typical day of eating, where meals happen, how they feel after eating.
- Routines: mornings, evenings, weekends, and what a good day looks like.

**Minutes 30–45: Choose one focus.** Ask: "Of everything we talked about, which one change would make the biggest difference to how you feel day to day?" Help the client choose one foundation to start with. Resist the temptation to work on three things at once. One focus, done well, builds confidence. Three focuses, done badly, build discouragement.

**Minutes 45–55: Set the first small goal.** Use the goal-setting method from Module 9. Make the goal specific, small, and scheduled: what, when, where. Agree how the client will track it and how you will check in.

**Minutes 55–60: Close and confirm.** Summarise the focus and the goal in the client's words. Confirm the next session date. Thank the client. Send a short written summary within 24 hours.

### 4.4 The client snapshot: a worked example

**Client:** Mara, 38, works in a salon four days a week, on her feet all day, two children aged 6 and 9.

- **Sleep:** Bed 11:30 p.m., up 6:15 a.m. "I scroll my phone until I fall asleep." Feels tired most mornings.
- **Stress:** Busy Saturdays at the salon, school runs, "no time that is just mine." Recovers by watching television late.
- **Movement:** On her feet at work, but no deliberate movement. "I am too tired to exercise."
- **Nutrition:** Skips breakfast, eats lunch standing up, large evening meal, snacks late.
- **Routines:** Mornings are rushed. Evenings are the only quiet time, so she stays up late to enjoy them.

**Focus chosen:** Sleep — specifically, a regular wind-down that protects the quiet evening time she values while helping her fall asleep earlier. The goal: phone off at 10:30 p.m., 20 minutes of reading or stretching, lights out by 11 p.m., four nights a week. Notice how the goal protects what Mara values (quiet evening time) instead of taking it away. That is why it has a chance of working.

### 4.5 What not to do in the first session

- Do not give the client a long list of changes.
- Do not comment on weight, appearance, or food choices.
- Do not promise a result or a timeline for change.
- Do not skip the scope-of-practice explanation because it feels awkward. Say it plainly and warmly. Clients respect clarity.

### 4.6 Action step

Complete a blank intake form as if you were your own first client. Then write a one-page client snapshot for yourself using the five foundations. Notice which foundation you would choose first — and why.

---

## Module 5 — Sleep Foundations: Coaching Rest Without Medical Claims

### 5.1 What you coach — and what you do not

You coach everyday sleep habits: regular timing, a wind-down routine, and a bedroom environment that supports rest. You do not diagnose or treat insomnia, sleep apnoea, or any sleep disorder. If a client reports loud snoring with pauses in breathing, excessive daytime sleepiness, falling asleep while driving, or sleep problems that have lasted for weeks despite habit changes, refer them to their doctor. That referral is part of good coaching, not a failure of it.

### 5.2 General education: how sleep habits work

Share this general education with clients in plain language. Regular sleep and wake times help the body settle into a steady rhythm. Light in the morning and dimmer light in the evening support that rhythm. A consistent wind-down routine signals to the body that the day is ending. A cool, dark, quiet bedroom makes it easier to fall asleep and stay asleep. Caffeine late in the day and bright screens late at night can make falling asleep harder for many people. None of this is medical advice. It is general information about everyday habits, and the client's job is to test which changes help them personally.

### 5.3 The sleep coaching conversation

Start with the client's actual evenings, not with a list of rules. Ask:

- "What time do you usually go to bed, and what time do you get up — on work days and on days off?"
- "What do you usually do in the hour before bed?"
- "What does your bedroom feel like at night — light, noise, temperature?"
- "How do you feel when you wake up?"
- "What would a good night look like for you?"

Listen for the real obstacle. It is rarely a lack of knowledge. It is usually that the evening is the only free time the client has, that they share a bedroom with a snoring partner, that they work shifts, or that worry keeps them awake. Coach the real obstacle.

### 5.4 Practical strategies to offer as options

Offer these as a menu, not a prescription. The client picks one or two to try for a week.

- **Anchor the wake time.** Choose a regular wake time and keep it within about an hour even on days off. A steady wake time is often easier to hold than a steady bedtime.
- **Build a 30-minute wind-down.** The same short routine each night: dim the lights, put the phone to charge outside the bedroom or on silent, change into night clothes, read, stretch gently, or take a warm shower.
- **Make the bedroom a rest space.** Dark, cool, and quiet as far as practical. An eye mask or earplugs are simple, low-cost options if light or noise is the problem.
- **Move the last caffeine earlier.** Many people find that keeping caffeine to the morning and early afternoon helps their evenings. Suggest the client tests it for a week and notices the difference.
- **Keep a notepad by the bed.** If thoughts and tomorrow's tasks keep a client awake, writing them down before bed — or briefly during the night — can help the mind let go of them.
- **Get daylight in the morning.** A short walk or time by a window in the first hour after waking supports a steadier daily rhythm.

### 5.5 Worked example: coaching a shift worker

**Client:** Daniel, 44, works rotating shifts, including nights. He says, "I cannot have a routine. My shifts change every week."

A rigid bedtime rule would fail. Instead, the coach helps Daniel build a **portable wind-down** — a short routine he can use after any shift: a shower, a dark room, earplugs, and a consistent "after work" sequence that tells his body the working day is over, whatever the clock says. They also agree on one anchor: on days off, he keeps a regular wake time. The goal is not a perfect schedule. It is a repeatable routine that travels with his shifts.

### 5.6 Tracking sleep without obsession

A simple sleep log is enough: bedtime, wake time, a 1–5 rating of how rested the client feels, and one line about what helped or got in the way. Review it weekly. If the client starts checking the clock anxiously through the night or becomes distressed about sleep, that is a sign to step back from tracking and to suggest a conversation with their doctor.

### 5.7 Action step

Keep a sleep log for yourself for seven days using the format above. Note your own wind-down pattern honestly. Choose one change from the menu and test it for a week before you coach anyone else on sleep.

---

## Module 6 — Stress and Calm: Coaching Everyday Stress and Recovery

### 6.1 What you coach — and what you do not

You coach everyday stress: noticing stress signals, building short calm practices into the day, and protecting recovery time. You do not diagnose or treat anxiety, depression, burnout as a medical condition, panic disorder, or trauma. If a client reports persistent low mood, anxiety that interferes with daily life, panic attacks, or feeling unable to cope, refer them to their doctor or a qualified mental health professional. If a client expresses thoughts of harming themselves, take it seriously and encourage urgent professional help immediately.

### 6.2 General education: stress and recovery

Stress itself is not the enemy. Short periods of pressure followed by recovery are a normal part of life. Problems build when pressure continues without recovery — when there is no pause, no rest, and no time that belongs to the client. Coaching stress is therefore mostly coaching recovery: helping the client notice their own early signals and build small pauses into ordinary days.

Common early signals clients describe include tension in the shoulders or jaw, shallow breathing, irritability, difficulty concentrating, restless sleep, comfort eating, or withdrawing from people. Teach clients to notice their own signals rather than handing them a list to memorise. Ask: "How do you know you are stressed — what do you notice first in your body or your mood?"

### 6.3 The stress coaching conversation

- "What does a stressful week look like for you?"
- "What is the hardest part of the day?"
- "What helps you feel calmer, even a little?"
- "When did you last have time that was just for you?"
- "What would a calmer week look like — not a perfect week, a slightly calmer one?"

Listen for what the client already does that helps, and help them do more of it. Most clients already have a calming strategy — a walk, music, a bath, time with a friend — but have stopped making time for it. Restoring it is often more effective than introducing something new.

### 6.4 Practical strategies to offer as options

- **A two-minute pause.** Slow breathing: breathe in for a count of four, out for a count of six, for two minutes. Use it between clients, before a difficult conversation, or when tension builds.
- **A daily ten-minute recovery slot.** A fixed, protected ten minutes — a walk, sitting outside, stretching, listening to music. Put it in the diary like an appointment. Guard it.
- **Movement as a reset.** A short walk, especially outdoors, is one of the simplest recovery tools. It does not need to be exercise. It needs to be a break.
- **A worry window.** For clients whose minds race at night, agree a 15-minute "worry time" earlier in the evening: write down worries and one small next step for each, then close the notebook. It sounds simple. Clients often find it surprisingly effective.
- **One boundary.** Help the client choose one small boundary for the week: no work messages after a set time, one evening a week with no commitments, or saying no to one extra task. Boundaries are a coaching topic, not a personality flaw.
- **Connection.** Encourage the client to spend time with one person who leaves them feeling better, not drained. Social connection is a genuine recovery resource.

### 6.5 Worked example: coaching a salon owner

**Client:** Priya, 41, owns a small salon. She works six days a week, answers client messages late at night, and says she feels "always on."

The coach does not tell Priya to work less — she cannot, right now. Instead they design a recovery structure inside her real week: a two-minute breathing pause between clients, a 15-minute walk after lunch three days a week, and one boundary — no client messages after 8 p.m., with an automatic reply explaining when she will respond. After two weeks Priya reports that the 8 p.m. boundary, not the breathing, made the biggest difference: evenings finally feel like her own. The lesson: coach the change that gives the client their time back.

### 6.6 When stress coaching reaches its limit

If a client's stress is severe, persistent, or linked to a situation you cannot help with — a bereavement, a relationship breakdown, workplace bullying, financial crisis — be honest about the limit of coaching. Support the client with everyday habits and encourage them to seek the right professional support. Never present coaching as a substitute for that support.

### 6.7 Action step

For one week, track your own stress signals: what you notice first, what triggers it, and what helps. Write a short paragraph describing your own early-warning signal and your most reliable two-minute reset. You will use your own experience — carefully, without making the session about you — to coach with empathy.

---

## Module 7 — Movement Foundations: Coaching Everyday Activity

### 7.1 What you coach — and what you do not

You coach everyday movement: walking, stretching, and building activity into ordinary days. You do not prescribe exercise programmes, design rehabilitation, work with injuries, or give training advice for medical conditions. If a client has an injury, a heart condition, a new diagnosis, or is pregnant, encourage them to check with their doctor or a qualified exercise professional before starting a new activity routine — and coach within whatever guidance that professional gives.

### 7.2 General education: movement as part of the day

Most adults think of movement as something that happens in a gym, in special clothes, for an hour. That picture stops many people before they start. Coaching reframes movement as something that happens across the whole day: walking to the shops, taking the stairs, stretching while the kettle boils, playing with children, gardening, dancing in the kitchen. Small amounts of movement, spread through the day, add up — and they are far easier to sustain than an ambitious routine that collapses in week two.

Share this general education plainly: regular everyday movement supports energy, mood, and sleep for many people. Sitting for very long stretches without a break tends to leave people feeling stiff and tired. Short, frequent movement breaks are a practical answer. None of this is a medical claim or a prescription. It is an invitation to experiment.

### 7.3 The movement coaching conversation

- "What does movement look like in a normal day for you?"
- "What kind of movement do you actually enjoy — or used to enjoy?"
- "What stops you from moving more?"
- "If movement felt easy and enjoyable, what would you be doing?"
- "What is the smallest amount that would feel worth doing?"

Listen for enjoyment. A client who hated running as a teenager will not suddenly love it at 45. A client who loved dancing, swimming, or cycling as a young person often lights up when you ask about it. Build on enjoyment, not on guilt.

### 7.4 Practical strategies to offer as options

- **Walk more, on purpose.** A ten-minute walk after lunch, a walk while on the phone, parking further away, or getting off the bus one stop early. Agree a specific walk, at a specific time, on specific days.
- **Break up sitting.** Stand and stretch for two minutes every hour. Set a phone reminder. This is especially useful for clients who sit at a desk or a treatment chair all day.
- **Stretch where you are.** A five-minute gentle stretch routine in the morning or evening — neck, shoulders, back, hips, legs. Keep it simple and comfortable. Stop if anything hurts, and refer the client to a professional for pain.
- **Anchor movement to something that already happens.** Walk after breakfast. Stretch while the kettle boils. Take the stairs after lunch. Anchoring a new habit to an existing routine makes it far easier to remember.
- **Make it social.** Walk with a friend, join a class, or move with family. Clients who move with others keep going longer than clients who move alone.
- **Count the week, not the day.** A missed day is not a failure. A week with three active days is a good week. Teach clients to look at the pattern across the week rather than judging themselves on a single day.

### 7.5 Worked example: coaching a client who "hates exercise"

**Client:** Tom, 52, works at a desk, says he hates exercise and has "tried the gym three times and quit three times."

The coach does not argue for the gym. They ask what Tom enjoyed as a younger man: cycling. Tom still owns a bicycle. They agree a goal that has nothing to do with a gym: a 20-minute easy cycle ride on Saturday morning, and a ten-minute walk after lunch on weekdays. After three weeks Tom reports he looks forward to the Saturday ride. The coach's skill was not in prescribing exercise. It was in finding the movement Tom already liked and removing the barriers around it.

### 7.6 Tracking movement simply

A simple weekly log works best: what the client did, for how long, and how they felt afterwards (a 1–5 energy rating). Review it together each week. Celebrate consistency, not intensity. If a client reports pain, dizziness, or breathlessness during activity, stop the activity conversation and refer them to their doctor.

### 7.7 Action step

Design a "movement menu" of ten everyday activities you could offer a client — walking, stretching, dancing, gardening, swimming, cycling, playing with children, housework to music, stair climbing, and one more of your own. For each, note who it might suit and what barrier it avoids.

---

## Module 8 — Nutrition Basics: General Education, Not Diet Plans

### 8.1 What you coach — and what you do not

This is the module where scope of practice matters most. You share **general education** about balanced eating patterns. You do not create personalised diet plans, set calorie or macronutrient targets, recommend diets for medical conditions, or advise on supplements. If a client has diabetes, heart disease, kidney disease, a digestive condition, food allergies, an eating disorder, or is pregnant, refer them to their doctor or a registered dietitian for personalised nutrition advice. If a client asks you for a meal plan, the honest answer is: "I share general education about balanced eating, and I can help you build the habit of regular, balanced meals. For a personal plan, a registered dietitian is the right professional."

### 8.2 General education: balanced eating patterns

The general education in this module follows widely published public-health guidance about balanced eating. It is not a diet, and it is not personalised advice.

A balanced day of eating, in general terms, includes:

- **Regular meals.** Eating at roughly regular times, including breakfast, helps many people avoid extreme hunger later in the day.
- **A variety of foods.** Vegetables and fruit, whole grains, protein foods (such as beans, lentils, eggs, fish, poultry, or meat), and dairy or fortified alternatives.
- **Plenty of plants.** Filling roughly half the plate with vegetables or salad at main meals is a simple visual guide many people find useful.
- **Water.** Drinking water through the day and keeping a bottle nearby is a simple habit to build.
- **Mindful eating.** Eating slowly, without screens where possible, and noticing fullness. Many clients eat standing up, in the car, or at a desk — and then wonder why they never feel satisfied.

Share this as general information and invite the client to notice their own patterns. You are not telling them what to eat. You are helping them pay attention to how they eat.

### 8.3 The nutrition coaching conversation

- "Walk me through a typical day of eating — from the first thing you have in the morning to the last thing at night."
- "Where do your meals happen — at a table, at a desk, standing up, in the car?"
- "When do you feel most hungry, and when do you feel most satisfied?"
- "What does a good meal look like for you — one that leaves you feeling steady, not sluggish?"
- "What would be easier: changing what you eat, or changing when and how you eat?"

For many clients, the answer to that last question is "when and how." A client who skips breakfast, eats lunch standing up, and then eats a very large meal late at night does not need a new diet. They need a regular, sit-down breakfast and a proper lunch break. Coach the routine first.

### 8.4 Practical strategies to offer as options

- **Eat breakfast sitting down.** A simple, regular breakfast eaten at a table, not on the move. The content of the breakfast is the client's choice.
- **Plan one anchor meal.** Choose one meal a day to make regular and balanced — usually lunch or dinner — and build the habit around it.
- **Keep water visible.** A bottle on the desk or kitchen counter. Refill it at set points in the day.
- **Add, don't subtract.** Instead of banning foods, add something: a portion of vegetables at dinner, fruit with breakfast, a glass of water before a meal. Addition is easier to sustain than restriction, and it avoids the coach ever sounding like a diet enforcer.
- **Prepare for the hungry hour.** The hour when a client gets home hungry is the hour when unplanned eating happens. A simple plan for that hour — a prepared snack, a ten-minute meal, a glass of water first — prevents the 6 p.m. spiral.
- **Eat without screens once a day.** One meal a day eaten slowly, without a phone or television. Clients are often surprised how much more satisfied they feel.

### 8.5 Worked example: coaching the "hungry hour"

**Client:** Aisha, 33, works in a beauty salon, finishes at 6 p.m., gets home starving, and eats standing in the kitchen before dinner is even cooked.

The coach does not give Aisha a meal plan. They design a hungry-hour routine: a glass of water and a small prepared snack (chosen by Aisha) when she gets home, then a proper sit-down dinner 30 minutes later. After two weeks Aisha reports she eats less in the evening and enjoys dinner more. The change was not what she ate. It was when, how, and in what order.

### 8.6 Language that protects you and your client

Never use these phrases with a client: "This food is good/bad," "This will detox you," "This diet will fix your [condition]," "You need to lose weight," or "Take this supplement." Each one crosses a line — into judgement, medical claims, or advice you are not qualified to give. Instead, use neutral, curious language: "How did that meal leave you feeling?" "What would a steadier day of eating look like?" "What has worked for you before?"

### 8.7 Action step

Keep a food-and-feelings log for three days: what you ate, when, where, and how you felt afterwards (energy 1–5, fullness, mood). Do not count calories or judge yourself. Notice patterns in timing and setting, not in "good" or "bad" foods. Bring that awareness to your coaching.

---

## Module 9 — Goals, Habits, and Accountability: The 12-Week Client Programme

### 9.1 Why goals fail

Most goals fail for the same three reasons: they are too big, too vague, or unsupported. "Get healthy" is vague. "Exercise every day" is too big for someone who currently does nothing. "Eat better" has no support structure at all. Your job is to turn vague ambitions into goals that are specific, small, and supported.

### 9.2 A goal-setting method that works

Use this method with every client. It has five questions:

1. **What exactly will you do?** Name the action in plain words.
2. **When and where?** Name the day, time, and place.
3. **How will you know it is done?** Name the evidence — a ticked box, a logged walk, a phone on charge by 10:30 p.m.
4. **How confident are you, from 1 to 10, that you can do it this week?** If the answer is below 7, the goal is too big. Make it smaller until the client rates it 7 or above.
5. **What might get in the way, and what will you do then?** Name the obstacle and a backup plan in advance.

A goal that passes all five questions is a goal the client is likely to complete. Completion builds confidence. Confidence builds the next goal.

### 9.3 Worked example: goal-setting walkthrough

**Client:** Sam, 47, wants to "sleep better and feel less tired."

**Step 1 — Narrow it.** "Sleep better" becomes "a wind-down routine on four nights a week."

**Step 2 — Specify it.** "Phone off and charging outside the bedroom at 10:30 p.m., read for 20 minutes, lights out by 11 p.m., on Monday, Wednesday, Friday, and Sunday."

**Step 3 — Evidence.** "I will tick it in my habit tracker each night and send you the tracker on Sunday."

**Step 4 — Confidence.** Sam rates it 6. Too low. The coach asks what would make it an 8. Sam says: three nights instead of four, and the phone on silent in the bedroom rather than outside it. Revised goal, three nights, phone on silent. Confidence: 8.

**Step 5 — Obstacle plan.** "What might get in the way?" Late work emails. Backup plan: if work runs late, the routine still happens, just 30 minutes later, and the phone still goes on silent.

Notice what happened: the coach did not push the harder version. The coach helped the client design a version they believed they could do. That is the whole skill.

### 9.4 Habits: small, anchored, tracked

Habits work best when they are:

- **Small.** So small the client cannot reasonably fail. Two minutes of stretching beats a 30-minute routine the client never starts.
- **Anchored.** Attached to something the client already does every day: after breakfast, when the kettle boils, after the school run.
- **Tracked.** A simple tick on a tracker, a note in a phone, a message to the coach. Tracking is not surveillance. It is evidence — for the client — that they are changing.
- **Reviewed.** Every session, review the tracker together. Celebrate what happened. Investigate what did not, without blame.

When a habit fails, the coaching question is never "Why didn't you do it?" It is "What got in the way, and what would make it easier next week?" The habit may need to be smaller, the anchor may be wrong, or the timing may not suit the client's real life. Adjust the design, not the client.

### 9.5 The 12-week client programme

The 12-week programme template in the templates folder turns one client's goals into a structured journey. Its shape:

- **Weeks 1–2: Foundation.** Intake, client snapshot, choose one focus, set the first small goal. Build the tracking habit.
- **Weeks 3–4: Build.** Add a second small habit in the same foundation. Review what is working. Adjust what is not.
- **Weeks 5–6: Deepen.** Strengthen the routine. Add a second foundation if the client is ready — for example, a short walk alongside the sleep routine.
- **Weeks 7–8: Mid-point review.** A full review session: what has changed, what the client has learned about themselves, what to keep, what to change. Reset goals for the second half.
- **Weeks 9–10: Expand.** Add a third element or deepen the existing ones. The client begins to run the routine without prompting.
- **Weeks 11–12: Consolidate and plan ahead.** Review the whole 12 weeks. Celebrate progress. Design the client's own maintenance routine for after the programme ends, and agree what ongoing support looks like — a monthly check-in, a second programme, or a confident goodbye.

Each week has a theme, a session focus, one habit to practise, and a check-in. The template gives you the full week-by-week plan. Adapt it to the individual client — the template is a structure, not a script to follow rigidly.

### 9.6 Accountability that helps, not harasses

Accountability means the client knows someone will ask, kindly, how the week went. It does not mean daily messages, guilt, or pressure. Agree the check-in rhythm in the first session: a short message once a week, a tracker shared before each session, or a brief voice note. Keep your side of the bargain — reply when you said you would, remember what the client told you, and follow up on what you promised. That reliability is the accountability.

### 9.7 When a client disappears

Clients miss sessions. It happens. Do not chase them with guilt. Send one warm message: "I missed you at our session. I hope you are well. Your next session is [date] — let me know if that still works, or if you would like to move it." If they do not reply, send one more message a week later offering to reschedule or pause. Then leave the door open and move on. A client who feels pursued will not return. A client who feels welcomed will.

### 9.8 Action step

Take your own goal from Module 1 and run it through the five-question method. Write it out in full, rate your confidence, name your obstacle and backup plan, and track it for one week. You cannot teach a method you have not used yourself.

---

## Module 10 — Launching Your Practice: Packages, Pricing, and First Clients

### 10.1 Start with a clear offer

A practice launches on one clear offer, not five confusing ones. Your first offer is the 12-week programme from Module 9, delivered as weekly or fortnightly 45–60 minute sessions, with a weekly check-in between sessions. That is the product. Everything else — single sessions, workshops, group coaching — can come later.

Write your offer in one paragraph: who it is for, what it includes, how long it lasts, and what the client will be able to do by the end. Use the description you drafted in Module 1 and sharpen it now.

### 10.2 Pricing honestly

Price your work in a way you can sustain. Consider your time (sessions plus preparation and check-ins), your costs (insurance, booking tools, materials), and the value of a structured 12-week programme. Do not underprice to win clients — a price that leaves you resentful or exhausted will not last. Do not overpromise to justify a high price either. Research what coaches in your area charge for similar programmes, and set a price you can state calmly and confidently.

For reference, this foundations programme itself is priced at $397 as a self-study course with templates. Your live coaching — your time, attention, and accountability over 12 weeks — is a different service and is priced separately, by you, for your market. The two are not the same product, and you should not present the course price as your coaching price.

### 10.3 Packages and payment

Keep it simple at launch:

- **One package:** the 12-week programme, with a stated number of sessions and check-ins.
- **One price:** a single programme fee, or a monthly payment option if you can manage it.
- **One policy:** written cancellation and refund terms, given to the client before they pay.

Take payment before the programme starts, or take a deposit with the balance due by an agreed date. Do not coach on credit. Keep simple records: client name, programme start date, sessions delivered, payments received.

### 10.4 Finding your first clients

Your first clients are usually people who already know and trust you. If you are a yoga or fitness instructor or a beauty professional, your existing clients are your warmest audience — but approach them properly:

- Tell them, clearly and separately, that you now offer wellness coaching as a distinct service. Do not blur it into their existing treatment or class.
- Offer a free 20-minute introductory conversation — not a free coaching session — where the person can ask questions and you can both decide whether coaching is a good fit.
- Ask satisfied early clients whether they would be comfortable referring a friend. A personal recommendation is worth more than any advertisement.
- Use your existing channels — your class, your salon, your social media — to explain what coaching is, who it is for, and how it works. Teach, do not sell. A short post explaining the difference between coaching and a diet plan will attract better clients than a post shouting about a discount.

### 10.5 A simple launch plan (four weeks)

- **Week 1:** Finalise your offer paragraph, your intake form, your session script, and your client agreement. Set up a simple booking method and a payment method.
- **Week 2:** Tell your existing clients and contacts. Offer five free introductory conversations.
- **Week 3:** Hold the introductory conversations. Enrol your first two or three programme clients.
- **Week 4:** Run your first sessions. Ask each client for honest feedback on the experience. Refine your process.

That is a launch. It is not glamorous. It is a working practice.

### 10.6 Running the practice week to week

A sustainable coaching week has a shape:

- **Sessions:** your booked client sessions, with preparation time before each one.
- **Administration:** notes written within 24 hours of each session, payments tracked, messages answered.
- **Learning:** one hour a week reading, listening, or studying — keep building your knowledge, and stay current with the scope-of-practice guidance in your area.
- **Rest:** time that is not work. A coach who is exhausted cannot coach well. Protect your own sleep, movement, and recovery with the same seriousness you ask of your clients.

### 10.7 Growing without losing quality

Grow slowly and deliberately. Add a second package only when the first is running smoothly. Consider group coaching or a workshop only after you have run at least five individual 12-week programmes and know the material deeply. Keep learning: general courses in coaching skills, communication, and habit science will serve you far better than another pile of certificates in topics you will never coach.

### 10.8 Action step

Complete the practice-launch checklist in the workbook. Choose a launch date four weeks from today. Write down the names of five people you will tell about your coaching offer in week 2 — real names, not "my clients." Then tell the first one.

---

## Closing: Your First 30 Days as a Coach

Your first 30 days are not about being perfect. They are about being structured, honest, and consistent.

- **Days 1–7:** Re-read Modules 2 and 3. Complete the workbook exercises for Modules 1–4. Practise a full first session with a volunteer.
- **Days 8–14:** Run your first introductory conversations. Enrol your first client. Set up your notes, tracker, and booking system.
- **Days 15–21:** Deliver your first real sessions. Write your notes within 24 hours. Review what worked and what felt awkward.
- **Days 22–30:** Hold a mid-point check with yourself: are your sessions following the structure? Are your goals passing the five-question test? Are you staying in scope? Adjust, and keep going.

You now have the structure: a session shape, an intake process, five foundations of general education, a goal-setting method, a 12-week programme, and a launch plan. The knowledge was never the missing piece. The structure was. Use it, practise it, and refine it with every client.

Welcome to coaching.

---

## Appendix A — Red-Flag Referral List

Keep this page with your intake forms. If a client reports any of the following, encourage them to speak to a qualified health professional promptly, and encourage urgent care where the situation indicates it. You are not expected to assess these clinically — only to notice, take them seriously, and refer.

**Seek urgent care / encourage immediate professional help:**
- Chest pain, pressure, or breathlessness
- Fainting, collapse, or a sudden severe headache
- Thoughts of harming themselves or others
- Severe allergic reaction (swelling, difficulty breathing)
- Uncontrolled bleeding or a serious injury

**Refer to a doctor promptly:**
- A new symptom, pain, or lump that does not settle
- Rapid unexplained weight loss or gain
- Persistent low mood, anxiety that interferes with daily life, or panic attacks
- Sleep problems lasting weeks despite basic habit changes
- Loud snoring with pauses in breathing, or excessive daytime sleepiness
- Signs of an eating disorder or a very restricted eating pattern
- Dizziness, numbness, or weakness
- A new diagnosis, a change in medication, recent surgery, or pregnancy — before starting a new movement or eating routine

**Refer to the right professional:**
- Personalised nutrition advice or a medical diet: registered dietitian or doctor
- Injury, pain, or rehabilitation: doctor or physiotherapist
- Mental health concerns: doctor or qualified mental health professional
- Medication questions: doctor or pharmacist

When you refer, say so warmly and clearly, note the referral in your session notes, and continue to support the client with everyday habits alongside their professional care where appropriate.

---

## Appendix B — Glossary

- **Accountability:** Knowing someone will kindly ask how your week went — the support that helps a client follow through.
- **Anchor:** An existing daily routine used as a reminder for a new habit (for example, stretching after breakfast).
- **Client snapshot:** A one-page summary of a client's five foundations at the start of coaching.
- **Coaching:** A partnership in which the coach guides the process and the client designs their own change.
- **Foundations:** The five areas this programme coaches — sleep, stress, movement, nutrition basics, and habits.
- **Intake form:** The form a client completes before the first session, covering routines, goals, and safety information.
- **Scope of practice:** The boundary of what a coach is trained and qualified to do — and what must be referred to another professional.
- **Wind-down routine:** A short, consistent sequence of calm activities before bed that signals the day is ending.

---

*Holistic Wellness Coach Foundations — BEA-06. Education only. This programme does not provide medical advice, diagnosis, or treatment, and does not qualify the reader to provide medical, nutritional, psychological, or rehabilitative services. Always refer clients to qualified health professionals for medical concerns.*

---

## Appendix C — Three Sample Sessions in Full

Use these as rehearsal scripts. Read each one aloud, then run it with a volunteer playing the client.

### Sample Session 1: The first session (Mara, from Module 4)

The coach opens by explaining coaching, confidentiality, and scope of practice in plain words, then asks Mara what would make the sessions useful. Mara says she wants more energy. The coach walks through the five foundations, taking notes in Mara's own words, and notices the pattern: late nights are her only quiet time, so she protects them by staying up. The coach reflects this back: "It sounds like evenings are the one part of the day that feels like yours — and that makes going to bed earlier feel like losing something." Mara agrees. Together they design a wind-down that keeps her quiet time but moves it earlier: phone on silent at 10:30 p.m., twenty minutes of reading, lights out by 11 p.m., four nights a week. Mara rates her confidence at 8. The obstacle is a late salon shift on Saturdays; the backup plan is a shorter version of the routine on that night. The coach summarises the agreement in Mara's words, confirms the next session, and sends a written summary within 24 hours.

### Sample Session 2: A week-four review (Daniel, the shift worker, from Module 5)

Daniel reports that his portable wind-down worked on three of four shifts. The coach celebrates the three, then asks about the fourth: a night shift that ran two hours over, leaving him too wired to sleep. Together they adjust the routine for overrun shifts — a shorter version, a dark room, earplugs, and no phone scrolling — and agree to test it next time. The coach then asks what Daniel has noticed: he says he feels less groggy on days off since keeping a regular wake time. That observation becomes the foundation for the next goal: protecting the regular wake time on days off for two weeks, tracked in his sleep log. The session ends with the coach noting the adjustment and the new goal, and confirming the next check-in.

### Sample Session 3: The mid-point review (Priya, from Module 6)

At week seven, Priya reviews her first six weeks. The 8 p.m. message boundary is now automatic. The lunchtime walk happens twice a week, not three times, and Priya is honest that the third walk rarely fits. The coach does not push for three. They agree to keep two walks and add a different recovery habit instead: ten minutes of stretching after the salon closes on Fridays. Priya then chooses her second-half focus: movement, starting with a Saturday morning walk with her sister — social, enjoyable, and already on the calendar. The coach records the review, the kept habits, the changed habit, and the new focus, and they agree the plan for weeks eight to twelve. Priya leaves the session with a clear sense that the programme is adapting to her life, not the other way around.
