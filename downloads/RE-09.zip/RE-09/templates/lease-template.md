# Lease Template — General Educational Model

**SKU: RE-09 · The Property Management Business System**

> **IMPORTANT — READ FIRST.** This is a general educational template, **not a legal document and not legal advice**. It is not a substitute for a lease form appropriate to your state, and it is not a substitute for review by a licensed attorney in the jurisdiction where the property is located. Landlord–tenant law, fair-housing rules, security-deposit rules, notice periods, and late-fee limits vary by state and locality and change over time. Before using any lease, use a state-appropriate form (for example, from your state realtor association or landlord association), complete it for your property, and have a local attorney review it. Required disclosures — including the federal lead-based paint disclosure for housing built before 1978 and any state-required disclosures — must be attached separately.

---

## 1. Parties and Property

- **Landlord:** [Full legal name], [address, phone, email]
- **Tenant(s):** [Full legal name of each adult occupant]
- **Property:** [Street address, unit number, city, state, ZIP]
- **Lease term:** From [start date] to [end date]. At the end of the term, the tenancy [converts to month-to-month on the same terms / ends, and the tenant must vacate unless a new lease is signed — choose one and state it].

## 2. Rent

- **Monthly rent:** $[______], due on the [1st] of each month.
- **Payment methods accepted:** [bank transfer / online portal / check / money order]. Cash is not accepted.
- **Payment is counted as received** when the funds are received by the landlord, not when they are sent.
- **First month's rent** of $[______] and the security deposit of $[______] are due before move-in, by [certified funds / bank transfer].

## 3. Late Fee

- **Grace period:** [______] days. Rent received after the grace period is late.
- **Late fee:** $[______] flat, plus $[______] per day after the grace period, capped at [______]% of monthly rent, and in all cases within the limits set by state and local law.
- **Returned payments:** A fee of $[______] applies to any returned check or failed transfer. After a returned payment, all further payments must be made by certified funds.
- **Application of payments:** Payments are applied to the oldest balance first (fees, then rent), or as required by state law.
- **Partial payments:** [State your policy. Note: in some states, accepting a partial payment affects the landlord's right to proceed with a nonpayment notice. Verify your state's rule before accepting a partial payment.]

## 4. Security Deposit

- **Amount:** $[______].
- **Held in:** [account type and institution, as required by state law].
- **Return:** The deposit, less lawful deductions itemized in writing, will be returned within [______] days after move-out, as required by state law. Deductions may be made only for unpaid rent, damage beyond normal wear and tear, and other lawful charges documented with receipts or invoices.
- **Move-out inspection:** The landlord will inspect the unit at move-out, using the move-in inspection as the comparison. The tenant may be present.

## 5. Occupancy and Use

- The property is for residential use only, by the named tenant(s) and [______] occupants.
- No other person may live in the unit for more than [______] consecutive days without the landlord's written approval.
- The tenant will not use the property for any unlawful purpose.

## 6. Pets

- Pets are [not permitted / permitted as follows: ______].
- Any permitted pet requires a signed pet addendum, a pet deposit of $[______] and/or monthly pet rent of $[______], within state limits.
- Assistance animals are not pets under fair-housing law; requests for a reasonable accommodation are handled separately.

## 7. Maintenance and Repairs

- **Landlord's responsibility:** Maintain the property in habitable condition, including structural elements, plumbing, electrical, heating, and appliances provided with the unit.
- **Tenant's responsibility:** Keep the unit clean and in good condition; report problems promptly through [the single reporting channel: ______]; replace light bulbs; keep drains clear; change HVAC filters [if assigned to the tenant — state it here]; do not pour grease down drains; do not flush anything other than toilet paper.
- **Reporting:** Maintenance must be reported in writing through [channel]. The landlord will acknowledge requests within 24 hours and respond according to the triage standard (emergency within hours, urgent within 3–5 days, routine within 14 days).

## 8. Alterations

- The tenant will not paint, install fixtures, change locks, or make any alteration without the landlord's prior written permission.
- Any approved alteration becomes the landlord's property unless otherwise agreed in writing.

## 9. Entry

- The landlord may enter the unit for repairs, inspections, and showings, with the notice required by state law (commonly 24 hours, in writing), except in emergencies.
- The landlord will enter at reasonable times and will respect the tenant's privacy.

## 10. Utilities

- **Landlord pays:** [______]
- **Tenant pays:** [______]
- Shared utilities, if any, are allocated as follows: [______]

## 11. Insurance

- The tenant [is / is not] required to carry renter's insurance, with minimum liability coverage of $[______], and to provide proof of coverage at move-in and at each renewal.

## 12. Smoking

- Smoking is [prohibited inside the unit / permitted as follows: ______].

## 13. Assignment and Subletting

- The tenant will not assign the lease or sublet the unit without the landlord's prior written approval.

## 14. Early Termination

- If the tenant leaves before the end of the term, the tenant [is responsible for rent until the unit is re-rented, and the landlord will make reasonable efforts to re-rent promptly / will pay an early-termination fee of $______ — choose the provision that complies with your state's law].

## 15. Rules and Addenda

The following are attached and form part of this lease:

- [ ] Move-in inspection checklist
- [ ] Pet addendum (if applicable)
- [ ] Lead-based paint disclosure (required for housing built before 1978)
- [ ] [State-required disclosures: ______]
- [ ] Property rules (parking, trash, common areas, noise, quiet hours)

## 16. Notices

- Notices must be delivered by [mail / email / hand delivery / posting — as permitted by state law] to the addresses listed in Section 1. A notice counts as received [when delivered / on the date specified by state law].

## 17. General

- This lease is the entire agreement between the parties regarding the property. Changes must be in writing and signed by both parties.
- If any provision is found unenforceable, the remaining provisions remain in effect.
- This lease is governed by the laws of the State of [______].

**Signatures:**

Landlord: ______________________________ Date: __________

Tenant: ______________________________ Date: __________

Tenant: ______________________________ Date: __________
