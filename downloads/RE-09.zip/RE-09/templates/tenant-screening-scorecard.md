# Tenant Screening Scorecard

**SKU: RE-09 · The Property Management Business System**

*Education only — not legal advice. Fair-housing law applies to every landlord. Apply these criteria the same way to every applicant, and never make a leasing decision based on race, color, religion, sex, national origin, familial status, disability, or any additional protected class in your state or city. Verify your state's rules on credit, background, and criminal-history screening before you finalize your criteria.*

---

## Applicant Information

| Field | Entry |
|---|---|
| Applicant name | |
| Property / unit applied for | |
| Monthly rent | |
| Date application received | |
| Application number (order received) | |

## Written Criteria (set before screening)

| Criterion | Your standard |
|---|---|
| Minimum gross monthly income | 3× monthly rent = $______ |
| Minimum credit score | |
| Rental history standard | No evictions in ______ years; positive reference from most recent landlord |
| Background standard | |
| Maximum occupants | |
| Pet policy | |

## Scoring — 0 to 20 points per category, 100 total

| Category | 20 points | 10 points | 0 points | Score |
|---|---|---|---|---|
| **Income** | ≥3× rent, verified, stable 12+ months | 2.5–3× rent, or verified but <12 months in role | <2.5× rent or unverifiable | |
| **Credit** | At/above threshold, no landlord or utility collections | Slightly below threshold, or old resolved collections | Below threshold with active collections, or recent bankruptcy | |
| **Rental history** | Positive references, no late pattern, no eviction | One prior late pattern, or neutral reference | Eviction, negative reference, or history unverifiable | |
| **Employment** | Stable, same field 2+ years, verified | New job <6 months, or field change, verified | Unverifiable employment | |
| **Application quality** | Complete, honest, on time, responsive | Minor gaps, corrected promptly | Incomplete, inconsistent, or dishonest | |
| **TOTAL** | | | | **/ 100** |

## Decision Thresholds (set before screening)

- **70–100:** Approve
- **55–69:** Approve with conditions (higher deposit within the legal limit, or a qualified co-signer)
- **Below 55:** Decline

## Verification Checklist

- [ ] Income verified (pay stubs / bank statements / employer call)
- [ ] Current landlord contacted — notes: ______
- [ ] Previous landlord contacted — notes: ______
- [ ] Credit report run (with written consent)
- [ ] Background check run (with written consent)
- [ ] Identity matched to application and credit report
- [ ] Employer verified — notes: ______

## Decision

| Field | Entry |
|---|---|
| Total score | / 100 |
| Decision | Approve / Conditional approve / Decline |
| Conditions (if any) | |
| Reason (based on written criteria) | |
| Adverse action notice sent (if applicable) | Yes / No — date: ______ |
| Decided by | |
| Date | |

*File the completed scorecard in the unit's management file and keep it for the period your state requires.*
