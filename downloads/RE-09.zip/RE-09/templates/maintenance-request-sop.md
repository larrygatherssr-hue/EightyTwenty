# Maintenance Request Form and Vendor SOP

**SKU: RE-09 · The Property Management Business System**

*Part 1 is the form the tenant uses to report a problem. Part 2 is the standard operating procedure for handling it. Keep blank copies of the form where tenants can reach them, and keep the SOP in the management file.*

---

## Part 1 — Maintenance Request Form (tenant)

| Field | Entry |
|---|---|
| Tenant name | |
| Property address / unit | |
| Date of request | |
| Best contact number | |
| Best times to enter the unit | |

**What is wrong, and where?**

**When did it start?**

**Is it getting worse?** Yes / No

**Is there water, smoke, a smell, or a safety issue?** Yes / No — describe: ______

**Photos attached?** Yes / No

**Permission to enter:** The tenant authorizes the landlord or the assigned vendor to enter the unit to complete this repair, with the notice required by state law. Yes / No

Tenant signature: ______________________________ Date: __________

---

## Part 2 — Maintenance SOP (landlord / manager)

### Step 1 — Intake (same day)

- Log the request: date received, unit, tenant, description, photos.
- Acknowledge the tenant within **24 hours**, even if the answer is only a date: "Received. The plumber is scheduled for Thursday between 9 and 11 a.m."

### Step 2 — Triage (same day)

| Level | Definition | Respond | Fix by |
|---|---|---|---|
| **1 — Emergency** | Threat to life, safety, or structure: no heat in winter, no water, sewage backup, gas smell, major active leak, electrical hazard, unsecured exterior door/window, fire or flood | Within hours | Within 24 hours |
| **2 — Urgent** | Broken appliance, running toilet, minor leak, no hot water, broken interior lock, pest sighting | Within 24 hours | Within 3–5 days |
| **3 — Routine** | Dripping faucet, sticking door, cracked tile, loose handrail, cosmetic items | Within 48 hours | Within 14 days |

Record the level and the target date on the request. If the level changes, note the change and the reason.

### Step 3 — Work order

Create a written work order for every job, even a small one:

| Field | Entry |
|---|---|
| Work order number | |
| Date issued | |
| Unit and tenant | |
| Problem and photos | |
| Triage level and required completion date | |
| Vendor assigned | |
| Access arrangement | |
| Authorization limit for this job | $______ |

### Step 4 — Vendor dispatch

- Call the primary vendor; if unavailable, call the backup.
- Send the work order and the photos.
- Confirm the appointment time and tell the tenant in writing.

### Step 5 — Completion and verification

- Vendor returns the completed work order with the invoice and photos of the finished work.
- Confirm with the tenant that the problem is resolved.
- File the work order, invoice, and photos in the unit's management file.
- Record the cost in the maintenance log and the rent ledger's expense section.

### Step 6 — Follow-up

- If the same problem recurs within 30 days, treat it as a new request at one level higher and investigate the underlying cause.
- Quarterly, review the maintenance log: which units cost the most, which problems repeat, and what preventive work would stop them.

## Vendor Authorization Limits (fill in and send to each vendor in writing)

| Vendor / trade | Primary | Backup | Emergency limit (no call needed) | Routine limit |
|---|---|---|---|---|
| Plumber | | | $______ | $______ |
| Electrician | | | $______ | $______ |
| HVAC | | | $______ | $______ |
| Handyman | | | $______ | $______ |
| Cleaner | | | $______ | $______ |
| Locksmith | | | $______ | $______ |
| Painter | | | $______ | $______ |
| Landscaper | | | $______ | $______ |
| Pest control | | | $______ | $______ |

**Rule:** Any work above the authorization limit requires a call to the landlord or manager before the vendor proceeds.

## Emergency Instructions (give to every tenant at move-in)

- **Water leak:** Turn off the valve under the sink or at the fixture, then call [number].
- **Gas smell:** Leave the unit, do not flip switches, and call the utility emergency line at [number] and then the landlord at [number].
- **No heat in winter / no water / sewage backup:** Call [number] immediately.
- **Fire:** Call 911, leave the building, then call the landlord.
- **Lockout:** Call [locksmith / number]. The lockout fee is the tenant's responsibility unless the lease says otherwise.

## Maintenance Log (one row per request)

| Date | Unit | Issue | Level | Vendor | Date completed | Cost | Tenant confirmed |
|---|---|---|---|---|---|---|---|
| | | | | | | | |
| | | | | | | | |
| | | | | | | | |
