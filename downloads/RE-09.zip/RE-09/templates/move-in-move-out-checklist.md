# Move-In / Move-Out Inspection Checklist

**SKU: RE-09 · The Property Management Business System**

*Complete this checklist with the tenant present, at move-in and again at move-out, using the same form so the two inspections can be compared side by side. Take dated photos of every room and of any existing damage. Both parties sign. Give the tenant a copy; file the original with the photos in the management file.*

---

## Property and Tenancy

| Field | Entry |
|---|---|
| Property address / unit | |
| Tenant name(s) | |
| Inspection type | Move-in / Move-out (circle one) |
| Date and time | |
| Inspected by (landlord) | |
| Tenant present | Yes / No |

## Condition Key

- **E** — Excellent · **G** — Good · **F** — Fair · **P** — Poor · **N/A** — Not applicable

## Room-by-Room Condition

| Area | Item | Condition | Notes / existing damage |
|---|---|---|---|
| Living room | Walls, ceiling | | |
| Living room | Flooring | | |
| Living room | Windows, locks, screens | | |
| Living room | Doors, hardware | | |
| Living room | Lighting, outlets | | |
| Kitchen | Walls, ceiling, floor | | |
| Kitchen | Counters, cabinets | | |
| Kitchen | Sink, faucet | | |
| Kitchen | Stove / oven (run briefly) | | |
| Kitchen | Refrigerator (run briefly) | | |
| Kitchen | Dishwasher (if any) | | |
| Kitchen | Microwave (if any) | | |
| Bedroom 1 | Walls, ceiling, floor | | |
| Bedroom 1 | Windows, locks | | |
| Bedroom 1 | Closet, doors | | |
| Bedroom 2 | Walls, ceiling, floor | | |
| Bedroom 2 | Windows, locks | | |
| Bedroom 2 | Closet, doors | | |
| Bathroom 1 | Walls, tile, caulking | | |
| Bathroom 1 | Toilet, sink, tub/shower | | |
| Bathroom 1 | Faucets, water pressure | | |
| Bathroom 1 | Ventilation fan | | |
| Bathroom 2 | Walls, tile, caulking | | |
| Bathroom 2 | Fixtures, fan | | |
| Hall / other | Walls, flooring, doors | | |
| HVAC | Heating / cooling (run briefly) | | |
| HVAC | Filter condition | | |
| Water heater | Condition, leaks | | |
| Safety | Smoke detectors (tested) | | |
| Safety | Carbon-monoxide detectors (tested) | | |
| Exterior | Yard, fence, porch | | |
| Exterior | Parking area, trash bins | | |
| Other | | | |

## Keys and Access

| Item | Quantity issued | Quantity returned (move-out) |
|---|---|---|
| Unit keys | | |
| Mailbox keys | | |
| Garage remote / opener | | |
| Gate / building access | | |
| Other | | |

## Move-In Only

- [ ] Tenant given 48 hours after move-in to add items in writing.
- [ ] Tenant's additional notes (within 48 hours): ______

## Move-Out Only

- [ ] Unit cleaned to the move-out standard (see the move-out instructions).
- [ ] All personal belongings removed.
- [ ] All keys and remotes returned.
- [ ] Forwarding address provided by tenant: ______

## Photos

| Photo set | Taken |
|---|---|
| Every room, dated | Yes / No |
| Close-ups of existing damage (move-in) or new damage (move-out) | Yes / No |
| Exterior | Yes / No |

## Signatures

**Move-in:** The condition above is accurate as of the date shown.

Landlord: ______________________________ Date: __________

Tenant: ______________________________ Date: __________

**Move-out:** The condition above is accurate as of the date shown.

Landlord: ______________________________ Date: __________

Tenant: ______________________________ Date: __________

---

## Move-Out Cleaning Standard (give this to the tenant with the move-out instructions)

- All floors vacuumed and mopped; carpets free of debris.
- Kitchen: counters, sink, stove, oven, and refrigerator cleaned inside and out; cabinets wiped.
- Bathrooms: toilet, sink, tub/shower cleaned; mirrors and fixtures wiped.
- All trash and personal belongings removed.
- Walls free of marks beyond normal wear; nails and hooks removed and holes filled if required by the lease.
- Yard and exterior areas left tidy; trash bins at the curb or in their designated place.
