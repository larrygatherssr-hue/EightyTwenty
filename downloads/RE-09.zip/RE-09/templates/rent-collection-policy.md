# Rent Collection and Late-Fee Policy

**SKU: RE-09 · The Property Management Business System**

*This policy is a general educational template. Late-fee caps, grace periods, notice requirements, and the effect of accepting partial payments vary by state and locality. Verify the current law where your property is located and have a licensed attorney review this policy before you use it. Put the final version in the lease and in the move-in packet.*

---

## 1. Rent Due Date

Rent of $[______] per month is due on the **1st day of each month**. Rent is counted as paid when the funds are received by the landlord, not when they are sent.

## 2. Grace Period

A grace period of **[______] days** applies. Rent received after the grace period is late. The grace period is [required by state law / offered by the landlord — delete as applicable].

## 3. Late Fee

- **Flat fee:** $[______]
- **Daily fee:** $[______] per day after the grace period
- **Cap:** The total late fee will not exceed **[______]% of monthly rent**, and will in all cases stay within the limits set by state and local law.

**Worked example:** Rent $1,350, 5-day grace period, $75 flat fee plus $10 per day, capped at 10% of rent ($135). A tenant who pays on the 12th owes $75 + (7 × $10) = $145, capped at $135. A tenant who pays on the 8th owes $75 + (3 × $10) = $105.

## 4. Accepted Payment Methods

- [ ] Bank transfer / ACH
- [ ] Online payment portal: [______]
- [ ] Personal or cashier's check
- [ ] Money order

Cash is **not accepted**. A written receipt is issued for every payment.

## 5. Returned Payments

A fee of $[______] applies to any returned check or failed transfer. After a returned payment, all further payments must be made by certified funds (cashier's check or money order).

## 6. Partial Payments

[State your policy. Example: "Partial payments are accepted only under a written payment plan signed by both parties. Accepting a partial payment does not waive the landlord's right to collect the balance or to proceed under the lease and applicable law, except as the law of this state provides." — Verify your state's rule before using this language.]

## 7. Application of Payments

Payments are applied to the oldest balance first — fees, then rent — or as required by state law. Late fees are recorded on a separate line from rent in the ledger.

## 8. Collection Calendar

| Day | Action |
|---|---|
| 1st | Rent due. |
| 2nd | Friendly reminder to anyone unpaid (text or email). |
| End of grace period | Late fee applies. Written late notice sent, stating the amount owed and the date by which it must be paid. |
| 8th | Phone call. Record what the tenant says and the date they promise to pay. |
| 10th–12th | If no payment and no credible plan, send the formal pay-or-quit notice required by the state, served exactly as the state requires. |
| Notice expires unpaid | File for eviction or engage an attorney. Do not accept a partial payment that would reset the process unless the attorney advises it. |

## 9. Payment Plans

A payment plan is offered only in writing, signed by both parties, and states:

- The total amount owed (rent + fees, itemized).
- The exact payment dates and amounts.
- That missing a plan payment restarts the notice process.
- That the plan covers the stated balance only, and future rent remains due on the 1st.

Payment plans do not extend beyond 30 days without legal advice.

## 10. Fee Waivers

A late fee may be waived once, in writing, for a genuine hardship, with a note stating that the waiver is a one-time courtesy and that the policy stands. Fees are never waived silently or verbally.

## 11. Record-Keeping

Every unit has a rent ledger recording, for each month: rent due, date paid, amount paid, late fee, and balance. The ledger is reconciled on the 1st and the 15th of every month.

---

**Acknowledged by tenant:**

Tenant: ______________________________ Date: __________

Landlord: ______________________________ Date: __________
