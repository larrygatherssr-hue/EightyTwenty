# Monthly Owner Report

**SKU: RE-09 · The Property Management Business System**

*Complete this report by the 10th of the following month. If you manage for a client, send it with the bank statement or a transaction summary attached.*

---

## Report Header

| Field | Entry |
|---|---|
| Property / portfolio | |
| Reporting month | |
| Prepared by | |
| Date prepared | |

## 1. Income

| Line | Amount |
|---|---|
| Rent collected | $ |
| Late fees collected | $ |
| Pet rent | $ |
| Other income (describe) | $ |
| **Total income** | **$** |

## 2. Expenses

| Line | Amount |
|---|---|
| Mortgage (owner's record) | $ |
| Property taxes (if paid this month) | $ |
| Insurance | $ |
| Maintenance and repairs (itemize below) | $ |
| Turnover costs | $ |
| Utilities paid by owner | $ |
| Management software / other | $ |
| **Total operating expenses (excluding mortgage)** | **$** |

**Maintenance detail:**

| Date | Unit | Work done | Vendor | Cost |
|---|---|---|---|---|
| | | | | $ |
| | | | | $ |
| | | | | $ |

## 3. Occupancy

| Measure | Value |
|---|---|
| Units occupied / total units | / |
| Occupancy rate | % |
| Vacancy loss this month | $ |
| Units vacant (list) | |
| Days to lease (most recent turnover) | days |

## 4. Rent Status

| Unit | Tenant | Rent | Status (paid / late / unpaid) | Date paid | Balance |
|---|---|---|---|---|---|
| | | $ | | | $ |
| | | $ | | | $ |
| | | $ | | | $ |
| | | $ | | | $ |

## 5. Leases Expiring in the Next 90 Days

| Unit | Tenant | Lease end date | Renewal status |
|---|---|---|---|
| | | | |
| | | | |

## 6. Open Maintenance Items

| Unit | Issue | Level | Vendor | Scheduled date |
|---|---|---|---|---|
| | | | | |
| | | | | |

## 7. Reserves

| Line | Amount |
|---|---|
| Repairs Reserve balance (start of month) | $ |
| Monthly transfer in | $ |
| Maintenance paid from reserve | $ |
| **Repairs Reserve balance (end of month)** | **$** |
| Reserve floor (one month's rent) | $ |

## 8. Notes for the Owner

*(What happened this month that the owner should know? What is coming up next month?)*

---

## Worked Example — Mara, March (4 units)

- **Income:** Rent $5,200 (all four units paid; one paid late on the 6th, $105 late fee). Late fees $105. Pet rent $50. **Total income: $5,355.**
- **Expenses:** Mortgage $2,400. Insurance $180. Maintenance $320 (faucet replacement $140, HVAC filter service $180). Turnover $0. Software $29. **Total operating expenses (excluding mortgage): $529.**
- **Occupancy:** 4 of 4 units (100%). One lease expires June 30; the renewal conversation starts April 1.
- **Open items:** Unit 3 — sticking back door (Level 3), handyman scheduled April 8. Unit 1 — annual inspection due in May.
- **Reserve balance:** $6,420, after the $570 monthly transfer and $320 in maintenance spending.
