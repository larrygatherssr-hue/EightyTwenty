# Customer Onboarding Guide — The Property Management Business System

Welcome — and congratulations on deciding to run your rentals like a business. This guide tells you exactly what to do first, how to use each file, and how to work through the course in 90 days.

---

## What You Received

| File | What it is | Use it for |
|---|---|---|
| `content.md` (course manual) | The complete 12-module course | Read in order the first time; use as a reference after that |
| `workbook.md` | Companion workbook with eight worksheets | Do the work: portfolio numbers, leasing checklist, screening practice, rent-collection math, maintenance planning, tenant scenarios, owner-report practice, 90-day plan |
| `templates/tenant-screening-scorecard.md` | 100-point screening scorecard | Score every applicant the same way, every time |
| `templates/lease-template.md` | General educational lease model | Starting point only — use a state-appropriate form and have a local attorney review it before use |
| `templates/move-in-move-out-checklist.md` | Room-by-room inspection checklist | Move-in and move-out inspections, with photos |
| `templates/maintenance-request-sop.md` | Maintenance request form and vendor SOP | Tenant reporting, triage, work orders, authorization limits |
| `templates/rent-collection-policy.md` | Rent and late-fee policy | The written policy, collection calendar, and payment-plan terms |
| `templates/monthly-owner-report.md` | Monthly owner-report template | Produce your report by the 10th of each month |
| `sales-page.md` | The sales page copy | Reference only — not needed for the course |
| `cover.webp` | Product cover image | Reference only |

---

## What to Do First (Day 1)

1. **Read Module 1** of the course manual. It explains the five systems and the numbers that run the business. Write down, in one sentence, what "running it like a business" means for your rentals.
2. **Set up one management file per unit** (Module 1): lease, inspection, application and screening notes, rent ledger, maintenance records, and notices. Even if the first entries are reconstructed from memory, start today.
3. **Open a separate savings account** labeled "Repairs Reserve." Set up an automatic monthly transfer of 5–10% of rent into it. This is the single most protective step in the whole course.

## How to Use Each File

- **Course manual (`content.md`):** Read Modules 1–4 first — they are the foundation (the system, leasing, screening, the lease). Modules 5–8 cover inspections, money, and maintenance. Modules 9–12 cover people, renewals, difficult situations, and reporting. Every module ends with action steps. Do them before moving on.
- **Workbook (`workbook.md`):** Print it or copy it into an editable document. Complete Worksheet 1 (portfolio numbers) in Week 1. Complete Worksheet 3 (screening practice) before your next vacancy. Use Worksheet 7 (owner report) every month once the system is running.
- **Templates:** Print the scorecard, the move-in/move-out checklist, and the maintenance request form, and keep blank copies where you can reach them. The lease template is a starting point only — it must be replaced by a state-appropriate form reviewed by a local attorney before use.

## Suggested Schedule — 90 Days

**Days 1–30 — Foundation.**
- Management file for every unit; Repairs Reserve account opened and funded.
- Screening criteria, rent policy, and collection calendar written.
- Vendor list built (at least one vendor per trade).
- Every unit photographed in its current condition.

**Days 31–60 — Leasing and money.**
- Listing template and showing fact sheet written; move-in packet assembled.
- Rent ledger set up and reconciled on the 1st and 15th.
- First annual inspections run.
- Maintenance-reporting channel and triage standards set.

**Days 61–90 — Operations and reporting.**
- First monthly owner report produced.
- Vendor SOPs and authorization limits written and sent to vendors.
- Every lease expiration calendared with a 90-day renewal reminder.
- Landlord-tenant attorney identified; number saved in the management file.
- Quarterly review completed against the five measures (occupancy, delinquency, days to lease, maintenance cost, reserve balance).

## Important Notice

This product is **education only** — not legal, tax, or financial advice. Landlord–tenant law, fair-housing rules, security-deposit rules, notice periods, late-fee limits, and eviction procedures vary by state and locality and change over time. Before using any lease, notice, or policy in this product, verify the current law where your property is located and consult a licensed attorney for your situation. The templates are general educational models requiring local review.

## How to Get Support

For help with your order or the course files, email the marketplace support address with your order number and a description of the issue, and the support team will respond. For questions about your specific property, lease, or legal situation, consult a licensed attorney in your jurisdiction — the marketplace support team cannot provide legal advice.

## Your Guarantee

This product comes with a **14-day money-back guarantee**. If you are not satisfied within 14 days of purchase, contact support with your order number for a full refund, no questions asked.
