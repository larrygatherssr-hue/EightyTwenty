# Workbook — The Property Management Business System

**SKU: RE-09 · Companion to `content.md`**

*Education only — not legal, tax, or financial advice. Verify current local law and consult a licensed attorney before using any lease, notice, or policy in this course.*

Print this workbook or copy it into an editable document. Work through the exercises in order — each one installs a piece of the system. Blank lines and tables are yours to fill in.

---

## Worksheet 1 — Your Portfolio Numbers

Fill in your real numbers, using Mara's 4-unit example in Module 1 as a template.

| Measure | Your number |
|---|---|
| Number of units | |
| Monthly rent, unit 1 | |
| Monthly rent, unit 2 | |
| Monthly rent, unit 3 | |
| Monthly rent, unit 4 | |
| Gross scheduled rent (monthly) | |
| Gross scheduled rent (annual) | |
| Vacancy budget (5% of annual GSR) | |
| Other income (pet rent, fees) | |
| Effective gross income (EGI) | |
| Operating expenses (estimate) | |
| Net operating income (NOI) | |
| Maintenance budget (10% of EGI) | |
| Monthly transfer to Repairs Reserve | |
| Repairs Reserve floor (one month's rent) | |
| Repairs Reserve current balance | |

**Exercise:** Which number surprised you most? Write one sentence about what you will change because of it.

---

## Worksheet 2 — Leasing Checklist

Use this checklist for every vacancy. Check each item off and date it.

- [ ] Notice received in writing — date: ______
- [ ] Move-out date confirmed with tenant — date: ______
- [ ] Permission to show in the last two weeks requested — date: ______
- [ ] Listing photos taken — date: ______
- [ ] Listing drafted and posted — date: ______
- [ ] Showing fact sheet printed — date: ______
- [ ] Group showings scheduled (two blocks per week) — dates: ______
- [ ] Applications received — number: ______
- [ ] Screening completed (scorecard, credit, background, references) — date: ______
- [ ] Decision recorded in the file — date: ______
- [ ] Lease signed; first month's rent and deposit collected — date: ______
- [ ] Move-in inspection completed with tenant — date: ______
- [ ] Move-in packet delivered — date: ______

**Days from notice to new lease start:** ______ (target: 21 or fewer)

**Vacancy loss for this turnover:** ______ days × $______ daily rent = $______

---

## Worksheet 3 — Screening Practice

Score the three practice applicants below using the scorecard in `templates/tenant-screening-scorecard.md`. Then check your scores against the answers at the end of this worksheet.

**Practice Applicant 1 — Jordan.** Rent $1,400. Income $4,600/month, verified, 2 years in role. Credit score 710, no collections. Prior landlord: "Paid on time, left the place spotless, would rent again." Employment verified, same field 4 years. Application complete and responsive.

| Category | Score (0–20) |
|---|---|
| Income | |
| Credit | |
| Rental history | |
| Employment | |
| Application quality | |
| **Total** | |

Decision (approve / conditional / decline): ______

**Practice Applicant 2 — Sam.** Rent $1,400. Income $4,000/month, verified, 4 months in current job. Credit score 655, one old paid collection. Prior landlord: paid on time except three late payments in one year; reference neutral. Employment verified, new field. Application complete.

| Category | Score (0–20) |
|---|---|
| Income | |
| Credit | |
| Rental history | |
| Employment | |
| Application quality | |
| **Total** | |

Decision (approve / conditional / decline): ______

**Practice Applicant 3 — Alex.** Rent $1,400. Income $3,300/month, unverified. Credit score 575, active landlord collection. Prior landlord could not be reached; the landlord before that reported an eviction. Employment unverifiable. Application incomplete, with two inconsistent addresses.

| Category | Score (0–20) |
|---|---|
| Income | |
| Credit | |
| Rental history | |
| Employment | |
| Application quality | |
| **Total** | |

Decision (approve / conditional / decline): ______

**Answer key:** Applicant 1 — 100 points, approve. Applicant 2 — 60 points, conditional approve (consider a higher deposit within your state's limit). Applicant 3 — 10 points, decline with an adverse action notice. If your scores differ by more than 10 points from these, re-read Module 3 and check which category you weighted differently — then set your own thresholds and hold them.

**Now score a real applicant:** use a blank scorecard from the templates folder for your next vacancy, and file the completed scorecard in the management file.

---

## Worksheet 4 — Rent-Collection Practice

**Exercise A — Late-fee math.** Your policy: rent due the 1st, 5-day grace period, late fee $75 flat plus $10 per day after the 5th, capped at 10% of monthly rent.

1. Rent $1,200. Tenant pays on the 9th. Days past grace: ______ Flat fee: ______ Daily fee: ______ Uncapped total: ______ Cap (10%): ______ **Late fee charged: ______ Total due: ______**
2. Rent $1,600. Tenant pays on the 14th. Days past grace: ______ Flat fee: ______ Daily fee: ______ Uncapped total: ______ Cap (10%): ______ **Late fee charged: ______ Total due: ______**
3. Rent $950. Tenant pays on the 7th. Days past grace: ______ Flat fee: ______ Daily fee: ______ Uncapped total: ______ Cap (10%): ______ **Late fee charged: ______ Total due: ______**

**Answers:** 1) 4 days, $75 + $40 = $115, cap $120, fee $115, total $1,315. 2) 9 days, $75 + $90 = $165, cap $160, fee $160, total $1,760. 3) 2 days, $75 + $20 = $95, cap $95, fee $95, total $1,045.

**Exercise B — Your collection calendar.** Fill in your state's actual numbers (verify them — do not guess).

| Item | Your rule |
|---|---|
| Rent due date | |
| Grace period (days) | |
| Late fee (amount and formula) | |
| Late-fee cap in your state | |
| Day the friendly reminder goes out | |
| Day the written late notice goes out | |
| Day you call the tenant | |
| Pay-or-quit notice period in your state | |
| How the notice must be served in your state | |
| Attorney's name and phone | |

---

## Worksheet 5 — Maintenance Planning

**Exercise A — Your maintenance budget.** Using the three-line method from Module 7:

| Line | Basis | Annual amount |
|---|---|---|
| Routine maintenance and small repairs | 5% of EGI | |
| Capital reserves | 5% of EGI | |
| Turnover costs | Expected turnovers × $850 | |
| **Total** | | |
| **Monthly transfer to reserve** | Total ÷ 12 | |

**Exercise B — Triage practice.** Assign a level (1 emergency, 2 urgent, 3 routine) and a response deadline to each:

| Request | Level | Deadline |
|---|---|---|
| No heat, temperature 28°F outside | | |
| Dripping kitchen faucet | | |
| Sewage backing up into the bathtub | | |
| Sticking bedroom door | | |
| Broken refrigerator | | |
| Cracked bathroom tile | | |
| Gas smell in the kitchen | | |
| Running toilet | | |
| Loose stair handrail | | |
| No hot water | | |

**Answers:** No heat (1, within hours); dripping faucet (3, within 14 days); sewage backup (1, within hours); sticking door (3, within 14 days); broken refrigerator (2, within 3–5 days); cracked tile (3, within 14 days); gas smell (1, within hours — call the utility emergency line first); running toilet (2, within 3–5 days); loose handrail (2, within 3–5 days — it is a safety item); no hot water (2, within 3–5 days).

**Exercise C — Preventive schedule.** Write your annual schedule:

| Season | Tasks | Date scheduled |
|---|---|---|
| Spring | | |
| Summer | | |
| Fall | | |
| Winter | | |

---

## Worksheet 6 — Tenant-Relations Scenarios

For each scenario, write what you would do and say. There is no single right answer — the point is to practice responding with the rules from Module 9: respond within 24 hours, put it in writing, stay consistent and professional, and promise the process rather than the result.

**Scenario 1 — The late payer with a story.** A tenant who has always paid on time calls on the 4th and says they lost their job and cannot pay this month, but they will pay in full on the 20th. What do you say? Do you send the late notice on the 5th? Do you offer a written payment plan? Write your response.

**Scenario 2 — The unauthorized pet.** During an annual inspection you find a large dog in a no-pets unit. The tenant says the dog belongs to their sister, who is "just visiting" for three weeks. What do you do, in what order?

**Scenario 3 — The angry tenant.** A tenant calls, furious, because the plumber you sent did not show up. The tenant took the morning off work. What do you say on the call, and what do you do next?

**Scenario 4 — The noise complaint.** The downstairs tenant complains the upstairs tenant plays music loudly after midnight, three nights this week. The upstairs tenant says the downstairs tenant is exaggerating. What do you do?

**Scenario 5 — The repair the tenant caused.** A tenant reports a clogged drain. The plumber finds a child's toy in the pipe and charges $180. The lease says the tenant is responsible for clogs caused by misuse. How do you handle the charge?

Write your answers below, then compare them with the guidance in Modules 7, 9, and 11. Keep this page — the next time a real version of one of these happens, you will already have rehearsed it.

---

## Worksheet 7 — Monthly Owner Report Practice

Using Mara's March example in Module 12, fill in a report for one of your own months. Use the template in `templates/monthly-owner-report.md`.

| Line | Amount |
|---|---|
| Rent collected | |
| Late fees collected | |
| Other income (pet rent, etc.) | |
| **Total income** | |
| Mortgage (owner's record) | |
| Insurance | |
| Maintenance and repairs | |
| Turnover costs | |
| Software / other | |
| **Total operating expenses (excluding mortgage)** | |
| Occupancy (units occupied / total) | |
| Leases expiring in the next 90 days | |
| Open maintenance items | |
| Reserve balance | |

**Exercise:** After completing the report, answer: what is the one number in this report that most needs attention next month, and what will you do about it?

---

## Worksheet 8 — Your 90-Day Plan

Copy the plan from Module 12 and date each item.

**Days 1–30 — Foundation.**

| Task | Done | Date |
|---|---|---|
| Management file set up for every unit | | |
| Repairs Reserve account opened; transfer set up | | |
| Screening criteria written | | |
| Rent policy written | | |
| Collection calendar written | | |
| Vendor list built (one per trade) | | |
| Every unit photographed | | |

**Days 31–60 — Leasing and money.**

| Task | Done | Date |
|---|---|---|
| Listing template written | | |
| Showing fact sheet created | | |
| Move-in packet assembled | | |
| Rent ledger set up and reconciled | | |
| Annual inspections run | | |
| Maintenance-reporting channel and triage standards set | | |

**Days 61–90 — Operations and reporting.**

| Task | Done | Date |
|---|---|---|
| First monthly owner report produced | | |
| Vendor SOPs and authorization limits written | | |
| Lease expirations calendared (90-day reminders) | | |
| Landlord-tenant attorney identified | | |
| Quarterly review completed against the five measures | | |

---

*Workbook complete. File it with the course manual and the templates — it is part of your management system now.*
