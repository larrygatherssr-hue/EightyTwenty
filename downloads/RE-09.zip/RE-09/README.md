# The Property Management Business System — RE-09

**Price:** $347 one-time · **Category:** Real Estate · **SKU:** RE-09

*Manage rentals like a business — leasing, rent, maintenance, and tenants in one system.*

## Files in This Product

| File | Description |
|---|---|
| `content.md` | The complete 12-module course manual — full prose chapters with worked examples using real numbers (screening scorecard, late-fee math under a cap, maintenance budgeting, deposit accounting, owner report), action steps at the end of every module, three appendices, and a full education-only disclaimer |
| `workbook.md` | Companion workbook — eight worksheets: portfolio numbers, leasing checklist, screening practice with answer key, rent-collection math practice with answers, maintenance planning and triage practice, tenant-relations scenarios, monthly owner-report practice, and a dated 90-day plan |
| `templates/tenant-screening-scorecard.md` | 100-point tenant-screening scorecard with written criteria, decision thresholds (approve / conditional / decline), and a verification checklist |
| `templates/lease-template.md` | General educational lease model covering 17 essential sections — requires a state-appropriate form and local attorney review before use |
| `templates/move-in-move-out-checklist.md` | Room-by-room move-in/move-out inspection checklist with condition key, keys log, photo record, and move-out cleaning standard |
| `templates/maintenance-request-sop.md` | Maintenance request form and vendor SOP — triage levels, work-order format, vendor authorization limits, emergency instructions, maintenance log |
| `templates/rent-collection-policy.md` | Rent-collection and late-fee policy — due date, grace period, late-fee formula and cap, payment methods, partial payments, collection calendar, payment plans, fee waivers |
| `templates/monthly-owner-report.md` | Monthly owner-report template — income, expenses, occupancy, rent status, expiring leases, open maintenance, reserves, with a worked example |
| `sales-page.md` | Full sales page — headline, problem, solution, 12-module contents, who it is for / not for, price and 14-day guarantee, 8 FAQs, and the education-only disclaimer |
| `listing.json` | Marketplace listing data (SKU, name, category, price in cents, headline, description, delivery note, SEO keywords, refund policy, support) |
| `cover.md` | Cover design brief — black-and-gold luxury branding, typography, imagery, and layout direction |
| `cover.webp` | Generated product cover image (portrait, black-and-gold, rental building at dusk) |
| `onboarding.md` | Customer onboarding guide — what to do first, how to use each file, a suggested 90-day schedule, and how to get support |
| `README.md` | This file — index of the product's files |

## Key Facts

- **Worked example throughout:** Mara's 4-unit portfolio, $5,200/month gross scheduled rent ($62,400/year), $59,880 effective gross income, $38,922 net operating income — full screening example (100 / 60 / 10 points), late-fee math capped at 10% of rent, $6,838 annual maintenance budget, $635 in lawful deposit deductions with $715 returned, and a complete March owner report.
- **Disclaimer:** Education only — not legal, tax, or financial advice. Stated in `content.md`, `workbook.md`, `sales-page.md`, and `onboarding.md`; lease and policy templates flagged as requiring local attorney review.
- **Guarantee:** 14-day money-back guarantee, full refund, no questions asked.
