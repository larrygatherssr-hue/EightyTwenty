# The Property Management Business System

**Manage rentals like a business — leasing, rent, maintenance, and tenants in one system.**

*SKU: RE-09 · Category: Real Estate · Price: $347 one-time · Format: 12-module course + template pack*

---

## Important Notice — Please Read First

This course is **education only**. It is not legal advice, tax advice, or financial advice. Landlord–tenant law, fair-housing rules, security-deposit rules, notice periods, late-fee limits, and eviction procedures vary by state, county, and city, and they change over time. Some jurisdictions cap late fees, require specific notice language, limit application fees, or require a rental license. Before you use any lease, notice, or policy in this course, verify the current law where your property is located and have a licensed attorney in that jurisdiction review your documents. The templates in this course are general educational models, not attorney-drafted documents for your specific situation. Nothing in this course guarantees any income, occupancy rate, or tenant outcome.

---

## Who This Course Is For

- **Self-managing landlords with 1–10 units** who are tired of winging it — late rent, surprise repairs, tenants who drift, and paperwork in a drawer.
- **Aspiring property managers** who want to start a small management business and need a complete operating system they can run from day one.
- **Accidental landlords** — people who inherited a property, moved and kept the old house, or bought one rental and realized that owning property and managing property are two different jobs.

## Who It Is Not For

- Investors who want to buy more properties. That is a different skill (see the Rental Property Blueprint, RE-01). This course assumes you already have a property to manage, or a client who does.
- Anyone looking for a way to avoid local law. This system works *inside* the law — fair housing, habitability, and notice rules are load-bearing walls, not decorations.
- Anyone who wants a "set it and forget it" promise. A well-run rental still needs a few hours a month. What this system does is make those hours predictable instead of chaotic.

## What You Will Have at the End

By the end of Module 12 you will have:

1. A written leasing process, from listing to signed lease, that takes a vacancy from empty to occupied in a measured number of days.
2. A tenant-screening scorecard with written criteria you apply the same way to every applicant.
3. A rent-collection system with a written late-fee policy, a day-by-day collection calendar, and scripts for every conversation.
4. A maintenance system with request intake, triage, vendor SOPs, and a budget you can defend with numbers.
5. A monthly owner report you can produce in under an hour — whether the "owner" is you or a paying client.
6. A 90-day implementation plan that installs the system one piece at a time.

## How to Use This Course

Read the modules in order the first time. Each module ends with **Action Steps** — do them before moving on, because later modules assume the earlier ones exist. Keep the workbook open beside the course; the workbook exercises are the places where you fill in *your* numbers, *your* vendors, and *your* policies. The templates folder holds the documents you will actually use day to day. Print the scorecard, the move-in/move-out checklist, and the maintenance request form, and keep blank copies where you can reach them.

A note on numbers: every worked example in this course uses a consistent example portfolio so you can follow the math across modules. The example is a **4-unit portfolio**: two single-family houses and one duplex, in one city, owned by one landlord — "Mara." Her units rent for $1,150, $1,250, $1,350, and $1,450 per month, for **$5,200 per month gross scheduled rent**, or **$62,400 per year**. Her numbers are illustrative, not a promise. Your numbers will differ. The method is what transfers.

---

## Table of Contents

- Module 1 — Run It Like a Business: The Operating System
- Module 2 — Leasing: Marketing, Showings, and Applications
- Module 3 — Screening: The Scorecard That Protects You
- Module 4 — The Lease: Terms That Prevent Problems
- Module 5 — Move-In and Move-Out: The Inspection Habit
- Module 6 — Rent Collection and Late Fees: The Money System
- Module 7 — Maintenance: Triage, Budgets, and the Reserve
- Module 8 — Vendors and SOPs: Your On-Call Team
- Module 9 — Tenant Relations: Communication That Prevents Conflict
- Module 10 — Renewals, Rent Increases, and Turnovers
- Module 11 — Difficult Situations: Nonpayment, Violations, and Eviction
- Module 12 — Owner Reporting, Scaling, and Your 90-Day Plan
- Appendix A — The Numbers, All in One Place
- Appendix B — Document Checklist
- Appendix C — Glossary

---

# Module 1 — Run It Like a Business: The Operating System

## The problem with "managing" by memory

Most small landlords do not have a management problem. They have a *memory* problem. The lease is in a drawer. The plumber's number is in a phone. The last rent increase was "a couple of years ago, I think." The tenant's maintenance request was a text message that scrolled away. Nothing is written down, so every decision is made fresh, under pressure, and usually a little late.

That is expensive. A tenant who pays on the 12th instead of the 1st costs you eleven days of float every month. A turnover that takes 45 days instead of 21 costs you three weeks of rent — on Mara's $1,300 average unit, that is about $975. A repair you discover at move-out instead of at the annual inspection costs you the difference between a $180 fix and a $1,400 replacement. None of these losses feel dramatic on the day they happen. Added up over a year, they are the difference between a rental that pays you and a rental that owns you.

A property-management business system is simply this: **written processes, used the same way every time, with numbers you can check.** That is the whole secret. The rest of this course is the processes.

## The five systems

Everything in this course hangs on five systems. If you remember nothing else, remember these:

1. **Leasing** — how a vacancy becomes a signed lease (Modules 2–5).
2. **Money** — how rent gets collected, recorded, and reported (Module 6).
3. **Maintenance** — how problems get reported, triaged, fixed, and paid for (Modules 7–8).
4. **People** — how you communicate with tenants so small issues stay small (Module 9).
5. **Ownership** — how you measure the business and decide what to change (Modules 10–12).

Each system has three parts: a **written policy** (what the rule is), a **process** (the steps, in order), and a **record** (proof it happened). A policy without a process is a wish. A process without a record is invisible. You need all three.

## The numbers that run the business

A management business is measured in a handful of numbers. Learn them now; they recur in every module.

**Gross scheduled rent (GSR).** The rent if every unit were occupied all year at full rent. Mara: $5,200 × 12 = **$62,400**.

**Vacancy loss.** Rent lost to empty units. If one of Mara's units sits empty for one month, that is $1,300 of vacancy loss, or about 2.1% of annual GSR. A realistic budget for a well-managed small portfolio is **5% vacancy** — roughly 18 days per unit per year. Mara budgets $3,120 per year for vacancy.

**Effective gross income (EGI).** GSR minus vacancy loss, plus other income (pet fees, late fees, parking). Mara: $62,400 − $3,120 + $600 other income = **$59,880**.

**Operating expenses.** Everything except the mortgage: taxes, insurance, maintenance, repairs, turnover costs, management time, software, legal. Mara budgets 35% of EGI, about **$20,958** per year.

**Net operating income (NOI).** EGI minus operating expenses: $59,880 − $20,958 = **$38,922**. This is the number that tells you whether the business works before financing.

**The 1% maintenance rule and the reserve.** A common planning benchmark is to budget **1% of the property's value per year for maintenance**, or to set aside **5–10% of rent** in a separate reserve account. Mara's four units are worth roughly $620,000 combined; 1% is $6,200 per year, or about $517 per month. She uses the rent-percentage method instead: 8% of collected rent, about $400 per month, into a dedicated "Repairs Reserve" savings account. The method matters less than the habit: **the reserve is a separate account, and you do not spend it on anything else.**

**Days to lease.** The number of days from a unit becoming vacant (or a tenant giving notice) to a new lease start date. Mara's target is **21 days**. Every day beyond that is lost rent you can calculate exactly: daily rent = monthly rent ÷ 30. For her $1,350 unit, each extra day costs $45.

**Delinquency rate.** The share of rent more than 5 days late in a given month. Mara's target is **under 5%** — in a 4-unit portfolio, that means zero units late in most months, and one late unit is a signal to act, not a shrug.

## Your management file

Before Module 2, set up one folder per unit — physical or digital, but one folder, not five apps. Each folder holds:

- The current lease and all addenda
- The move-in inspection with photos
- The tenant's application and screening notes
- The rent ledger (every payment, date, and method)
- Maintenance requests and invoices for that unit
- All notices sent and received, with dates

This is your management file. If you manage for a client one day, this file is also your proof of work. If there is ever a dispute, a deposit claim, or an eviction, the file is what stands between you and a very bad day. Start it now, even if the first entries are reconstructed from memory. An imperfect file started today beats a perfect system started "next month."

## The weekly rhythm

A managed portfolio runs on a weekly rhythm, not on emergencies:

- **Monday:** Check the rent ledger. Who has not paid? Send the day-appropriate notice (Module 6).
- **Wednesday:** Maintenance review. What is open, what is waiting on a vendor, what is overdue?
- **Friday:** Leasing check. Any vacancies? Any showings scheduled? Any applications pending?
- **Monthly (1st week):** Owner report (Module 12). Income, expenses, occupancy, open maintenance, upcoming lease expirations.

Total time for a 4-unit portfolio once the system is running: roughly **3–5 hours a week**. The first month takes more, because you are building the system. After that, the rhythm is the system.

## Action Steps — Module 1

1. Create one management file per unit, with the six sections listed above.
2. Write down your portfolio numbers: GSR, vacancy budget, EGI, operating expenses, NOI. Use Mara's as a template and substitute your own.
3. Open a separate savings account labeled "Repairs Reserve" and set up an automatic transfer of 5–10% of monthly rent into it.
4. Block 30 minutes every Monday, Wednesday, and Friday for the weekly rhythm. Put it on your calendar now.

---

# Module 2 — Leasing: Marketing, Showings, and Applications

## The vacancy clock

The moment a tenant gives notice — or the moment you learn a unit will be empty — a clock starts. Every day on that clock costs you daily rent. For Mara's $1,300 average unit, the clock ticks at about **$43 a day**. A 21-day lease-up costs roughly $910 in lost rent. A 45-day lease-up costs about $1,950. The difference between a good leasing system and no system is roughly $1,000 per turnover, per unit, and it repeats every time a tenant leaves.

The goal of this module is to make leasing a pipeline, not a panic: list early, show efficiently, take applications in writing, and decide on a schedule.

## Step 1 — Pre-market before the unit is empty

The single highest-leverage habit in leasing is **pre-marketing**. When a tenant gives 30 days' notice, do not wait for them to leave. On the day notice arrives:

1. Confirm the move-out date in writing.
2. Ask the tenant (in writing) for permission to show the unit in the last two weeks, with 24 hours' notice, at agreed times. Many tenants will agree if you ask politely and keep showings short.
3. Take listing photos immediately — either of the current furnished unit (with the tenant's permission) or of a comparable unit. Photos of a lived-in but tidy unit beat no photos by a wide margin.
4. Draft the listing that day.

If you cannot show the current unit, photograph a comparable one and say so in the listing: "Photos show a comparable unit in the same building." Never photograph one unit and present it as another without saying so.

## Step 2 — The listing

A good listing answers the four questions every renter asks, in order: **How much? Where? What do I get? What are the rules?**

- **Price:** the monthly rent, the security deposit, and the application fee (where your state allows one, and within any cap). State them all. Hidden fees are the number-one source of bad first impressions.
- **Location:** neighborhood, nearest cross streets, commute notes, parking situation.
- **The unit:** bedrooms, bathrooms, square footage if known, appliances included, laundry, heating/cooling, outdoor space, pet policy.
- **The rules:** lease term (usually 12 months), move-in date, income requirement (commonly gross income of 3× monthly rent — see Module 3), credit and background screening, smoking policy, pet policy and any pet deposit or monthly pet rent allowed in your state.

Write the listing in plain language. "Bright 2-bedroom with in-unit laundry, off-street parking, and a fenced yard. Pets considered with deposit. $1,350/month, $1,350 deposit, 12-month lease. Available June 1." That is a better listing than three paragraphs of adjectives.

**Photos:** at least 8–10, in daylight, with the lights on. Photograph every room from the doorway corner so the room reads as a space, not a wall. Include the kitchen, bathroom, exterior, and any parking or yard. Clean first, even if the unit is empty — sweep, wipe counters, open blinds. A $0 cleaning pass is worth more than any photo filter.

**Where to list:** use the major rental listing sites for your market, plus local community boards where appropriate. Post the same day you draft. Respond to inquiries within a few hours — the best applicants inquire on several listings at once, and the first landlord to respond usually gets the showing.

## Step 3 — Showings

Showings are a screening step, not a sales pitch. Your job at a showing is to observe and to inform.

**Scheduling:** group showings into two or three time blocks per week (for example, Tuesday 5:30–7:00 p.m. and Saturday 10:00 a.m.–12:00 p.m.). Group showings save hours and create a mild, honest sense that the unit is in demand. Do not manufacture false urgency — just be efficient.

**At the showing:**

- Arrive 10 minutes early. Lights on, windows open if weather allows, unit clean.
- Give every visitor a one-page fact sheet: rent, deposit, lease term, pet policy, application fee, screening criteria summary, and how to apply. This sheet does the talking after you leave.
- Answer questions honestly. If the water pressure is weak, say so. If the upstairs neighbor is loud, say the building is older and sound carries. Applicants who discover a problem after signing become unhappy tenants; applicants who knew beforehand become tenants who stay.
- Note the basics: who came, whether they were on time, whether they asked reasonable questions. You are not judging character — you are noting reliability signals that your scorecard (Module 3) will weigh alongside the formal checks.
- **Never** ask about race, religion, family status, disability, national origin, sex, or any other protected characteristic, and never make a leasing decision based on one. Fair-housing law applies to every landlord, including owners of a single unit in many jurisdictions. Your criteria must be written, neutral, and applied to everyone. Module 3 explains how.

**Safety:** meet in daylight when possible, tell someone where you are, and keep your phone charged. If you show units alone, consider a check-in routine with a family member or colleague.

## Step 4 — Applications

Take applications **in writing, from everyone, every time** — even the applicant who "seems great" and even the friend of a friend. A verbal application is not an application; it is a conversation you cannot verify.

The application collects:

- Full legal name, date of birth, current address and landlord, previous address and landlord
- Employer, job title, length of employment, gross monthly income, and a pay-stub or bank-statement verification path
- Government-issued ID (copy it; store it securely)
- Rental history for the past 3–5 years, with landlord contact information
- Consent to run credit and background checks, and to contact employers and prior landlords
- Number of occupants, vehicles, and pets (with breed/size if your policy requires it)
- Any prior evictions or lease breaks, asked directly — self-disclosure is useful, and a lie discovered later is a decision input

Charge an application fee only where your state allows it, only up to any cap, and only to cover your actual screening costs. Keep receipts. Some states require you to refund the fee if you do not run the checks, or to provide a copy of the report. Know your state's rule before you charge a dollar.

**Timing:** process applications in the order received, and decide within **48–72 hours**. Tell every applicant the timeline up front. A fast, professional decision is itself a competitive advantage — good tenants choose landlords who act like professionals.

## Step 5 — The decision meeting (with yourself)

Do not decide at the showing. Decide at your desk, with the scorecard (Module 3), the credit report, the background check, the employer verification, and the landlord references in front of you. If two applicants qualify, the tie-breaker is the order received and the completeness of the application — not a gut feeling. Write the decision and the reason in the file. If you decline someone, keep the written criteria and the scorecard; that record is your fair-housing defense.

## Worked example — Mara's 21-day lease-up

Mara's duplex unit at $1,350/month turns over. Her tenant gives 30 days' notice on May 1, move-out June 1.

| Day | Action | Clock |
|---|---|---|
| May 1 | Notice received in writing; pre-marketing starts; photos taken | Day −31 |
| May 2 | Listing live on three sites; fact sheet printed | Day −30 |
| May 6–27 | Group showings, Tue evenings and Sat mornings | — |
| May 20 | First qualified application received | Day −12 |
| May 22 | Screening complete; lease offered | Day −10 |
| May 24 | Lease signed; deposit collected; move-in set for June 2 | Day −8 |
| June 1 | Old tenant out; inspection and cleaning | Day 0 |
| June 2 | New tenant moves in | Day 1 |

Vacancy loss: **1 day** (June 1), about $45, plus cleaning. Compare that with the landlord who starts marketing on June 1 and leases on July 5: 35 days, about $1,575 lost. The system paid for itself in a single turnover.

## Action Steps — Module 2

1. Write your standard listing template with all four question groups filled in for each of your units.
2. Create your one-page showing fact sheet.
3. Choose your showing schedule (two blocks per week) and your application form.
4. Write your pre-marketing checklist and tape it inside the management file: notice → confirm → photos → list → show → decide in 72 hours.

---

# Module 3 — Screening: The Scorecard That Protects You

## Why screening is the whole business

Ask any experienced landlord what determines whether a rental makes money, and the answer is almost always the same: **the tenant you choose**. A good tenant pays on time, reports problems early, and leaves the place clean. A bad tenant costs you late fees you never collect, repairs you discover too late, and months of your life. Screening is not about being suspicious of people. It is about applying the same written, neutral criteria to every applicant so that the good ones get in quickly and the risky ones do not — and so that every decision is defensible.

## The written criteria — set them before you screen

Write your criteria down **before** you look at any application, and apply them to everyone. Typical criteria for a small portfolio:

- **Income:** gross monthly income of at least 3× monthly rent (some landlords use 2.5× in lower-cost markets; pick one and hold it).
- **Credit:** a minimum credit score, or a defined standard for what counts as a problem (for example: no unpaid landlord or utility collections, no recent bankruptcy without explanation and documentation).
- **Rental history:** no evictions in the past 3–5 years (or ever, if that is your policy — check your state's limits), no more than one late-payment pattern with a prior landlord, and a positive reference from the most recent landlord.
- **Background:** no convictions for property damage, fraud, or violent offenses within a defined lookback period, applied consistently and in line with your state's rules on criminal-history screening. Some jurisdictions restrict how criminal history may be used — verify before you set this criterion.
- **Occupancy:** maximum occupants per bedroom under local occupancy rules.
- **Pets:** as your policy allows, with any deposit or monthly pet rent stated up front and within state limits.

**Fair-housing rule that overrides everything else:** your criteria must be neutral as to race, color, religion, sex, national origin, familial status, disability, and any additional protected classes in your state or city. You may not ask about these, steer applicants, or apply different standards to different people. If a criterion has a disparate effect on a protected group, it needs a genuine business justification. When in doubt, ask a local attorney before you finalize your criteria.

## The scorecard

Score every applicant on the same five categories, 0–20 points each, for a total of 100. The scorecard template is in `templates/tenant-screening-scorecard.md`. The categories:

| Category | 20 points | 10 points | 0 points |
|---|---|---|---|
| **Income** | ≥3× rent, verified, stable 12+ months | 2.5–3× rent, or verified but <12 months in role | <2.5× rent or unverifiable |
| **Credit** | Score at/above your threshold, no landlord/utility collections | Score slightly below threshold, or old resolved collections | Below threshold with active collections, or recent bankruptcy |
| **Rental history** | Positive references, no late pattern, no eviction | One prior late pattern, or neutral reference | Eviction, or negative reference, or landlord cannot be reached and history is unverifiable |
| **Employment** | Stable, same field 2+ years, verified | New job <6 months, or field change, verified | Unverifiable employment |
| **Application quality** | Complete, honest, on time, responsive | Minor gaps, corrected promptly | Incomplete, inconsistent, or dishonest |

Set your **approve threshold before you screen** — for example, 70 points to approve, 55–69 to approve with conditions (higher deposit where the law allows, or a qualified co-signer), below 55 to decline. The threshold is yours; the point is that it exists before the applicant does.

## Verifying, not just reading

An application is a claim. Screening is verification.

- **Income:** pay stubs for the last two months, or bank statements showing deposits, or an employer verification call. Do not accept a stated income number without a document behind it.
- **Landlord references:** call the *current* landlord and the *previous* one. The current landlord may have an incentive to give a glowing reference to get a problem tenant out; the previous landlord has no such incentive. Ask: Did they pay on time? Did they give proper notice? Would you rent to them again? Was the unit left in good condition? Did they report maintenance promptly?
- **Credit and background:** use a reputable tenant-screening service. You need the applicant's written consent. If you take adverse action (decline, or approve with conditions) based on a consumer report, federal law generally requires you to give the applicant an **adverse action notice** with the name and contact information of the reporting agency and a statement of their right to dispute. Keep a copy in the file.
- **Identity:** match the ID to the application name and to the credit report. Mismatches are a stop-and-check signal, not an automatic decline.

## Worked example — three applicants, one unit

Mara's $1,350 unit. Her criteria: income ≥3× rent ($4,050/month), credit score ≥620, no evictions in 5 years, positive landlord reference. Approve at 70+, conditional at 55–69, decline below 55.

**Applicant A — Dana.** Income $4,800/month, verified, 3 years in role (20). Credit 685, no collections (20). Prior landlord: paid on time, left unit clean, "would rent again" (20). Employment stable, verified (20). Application complete and responsive (20). **Total: 100. Approve.**

**Applicant B — Marcus.** Income $4,200/month, verified, 8 months in current job (10). Credit 640, one old medical collection, paid (10). Prior landlord: mostly on time, two late payments in two years, neutral reference (10). Employment verified, field change last year (10). Application complete (20). **Total: 60. Conditional approve** — Mara offers the unit with a higher security deposit within her state's legal limit, and a co-signer is not required. Marcus accepts.

**Applicant C — Priya.** Income $3,600/month, below the 3× threshold (0). Credit 590 with an active utility collection (0). Prior landlord could not be reached; previous landlord reported a lease break (0). Employment unverifiable — employer did not respond after two attempts (0). Application had gaps and an inconsistent address history (10). **Total: 10. Decline**, with an adverse action notice citing the credit report, and the scorecard kept in the file.

Note what happened: Marcus, at 60 points, is not a "bad" applicant — he is a *conditional* one. The scorecard turns a gut call into a documented decision with terms attached. And Priya's decline is based on written criteria applied the same way to Dana and Marcus, which is exactly the record you want if anyone ever asks.

## The three screening mistakes that cost the most

1. **Skipping the previous landlord.** The current landlord's reference is the least reliable reference in the file.
2. **Screening by conversation instead of by scorecard.** The applicant you liked at the showing is the applicant you are most likely to let slide on a weak credit report. The scorecard does not care whether you liked them.
3. **Rushing because the unit is empty.** An empty unit costs you $43 a day. A bad tenant costs you months. The math favors patience every time.

## Action Steps — Module 3

1. Write your screening criteria and your approve/conditional/decline thresholds. Put them on the scorecard.
2. Choose your screening service and confirm the cost, the consent form, and the adverse-action process.
3. Score your last three tenants (or your current ones) retroactively, to calibrate the scorecard against people you already know.
4. File the criteria in every unit's management file — the same criteria, everywhere.

---

# Module 4 — The Lease: Terms That Prevent Problems

## The lease is a system, not a form

A lease does three jobs: it states the deal (rent, term, deposit), it states the rules (who does what, and what happens when they do not), and it states the process (how notices work, how maintenance is reported, how the tenancy ends). Most lease disputes are not about what the lease says. They are about what the lease *does not* say, discovered at the worst possible moment.

Use a lease form appropriate to your state — many state realtor associations and landlord associations publish them — and have a local attorney review yours before you use it. The terms below are the ones to make sure your lease covers, in plain language.

## The essential terms

- **Parties, property, term.** Full legal names of all adult occupants, the exact property address and unit, the lease start and end dates, and whether it converts to month-to-month at the end (and on what terms).
- **Rent.** The amount, the due date, the accepted payment methods, where and how it is paid, and what counts as "paid" (received, not sent). State the late-fee rule in the lease itself — amount, when it applies, and any grace period — and make sure it complies with your state's cap, if any.
- **Security deposit.** The amount, where it is held, the conditions for deductions, the move-out inspection process, and the deadline for returning it or providing an itemized statement. Many states set a strict deadline (commonly 14–30 days) and penalize landlords who miss it. Put the deadline on your calendar the day the tenant moves out.
- **Occupancy and use.** Who may live there, that the unit is for residential use only, and the rule on guests and long-term visitors.
- **Pets.** Allowed or not, which animals, any deposit or monthly pet rent allowed by your state, and the tenant's responsibility for damage. Note: assistance animals are not pets under fair-housing law — a no-pets policy does not apply to a reasonable accommodation for a disability. Handle those requests separately, with advice, not with a form letter.
- **Maintenance and repairs.** What the tenant must report and how (see Module 7), what the landlord is responsible for, and what the tenant is responsible for (for example, replacing light bulbs, keeping drains clear, changing HVAC filters if your lease assigns that).
- **Alterations.** No painting, no fixtures, no locks changed without written permission.
- **Entry.** The landlord's right to enter for repairs, inspections, and showings, with the notice your state requires (commonly 24 hours, in writing, except in emergencies).
- **Insurance.** Whether the tenant must carry renter's insurance, and the minimum coverage. This is a reasonable requirement in many markets and protects both sides.
- **Utilities.** Who pays what, and how shared utilities are allocated if applicable.
- **Smoking.** Your policy, stated plainly.
- **Assignment and subletting.** Whether allowed, and on what approval.
- **Early termination.** What happens if the tenant leaves early — the fee or the obligation to pay rent until re-rented, within your state's rules. Some states require the landlord to mitigate damages by re-renting promptly.
- **Notices.** How notices are delivered (mail, email, posting, hand delivery) and when they count as received. This single clause saves more arguments than any other.
- **Rules and addenda.** Parking, trash, common areas, noise, and any property-specific rules, attached as addenda and signed with the lease.

## Addenda worth having

- **Move-in inspection addendum** (Module 5) — signed by both parties with photos.
- **Pet addendum** — if pets are allowed.
- **Smoking addendum** — if you prohibit smoking.
- **Lead-based paint disclosure** — federally required for housing built before 1978.
- **Any state-required disclosures** — mold, bedbugs, flood zone, registered sex-offender database notice, and others vary by state. Your attorney or state landlord association will have the list.

## The signing

Never let a tenant move in before the lease is signed and the first month's rent and deposit are paid. Walk through the lease with the tenant — not reading every line aloud, but covering rent, due date, late fee, maintenance reporting, entry notice, and move-out rules. Answer questions. Have every adult occupant sign. Give the tenant a complete copy the same day, and keep the original in the management file. Collect keys, remotes, and access codes on the move-in checklist, not on a sticky note.

## Action Steps — Module 4

1. Get a state-appropriate lease form and have a local attorney review it before your next vacancy.
2. Write your lease checklist: every term above, checked off before you hand the lease over.
3. List your state's required disclosures and addenda, and attach them to your lease packet.
4. Set the rule: no keys, no move-in, until the signed lease and first payment are in hand.

---

# Module 5 — Move-In and Move-Out: The Inspection Habit

## The inspection is the deposit dispute, decided in advance

Almost every security-deposit dispute comes down to one question: **was that damage there before the tenant moved in?** If you have a signed move-in inspection with photos, the question answers itself. If you do not, the question becomes an argument — and in many states, the landlord bears the burden of proof.

The move-in/move-out checklist in the templates folder is the document. This module is the habit around it.

## The move-in inspection

Do the inspection **with the tenant, on move-in day, before their boxes arrive** if possible. Walk every room together, with the checklist in hand:

- Walls, floors, ceilings, doors, windows, and locks — note condition and any existing marks.
- Kitchen: appliances (run each one briefly), counters, cabinets, sink, faucet.
- Bathrooms: fixtures, tile, caulking, ventilation fan, water pressure.
- HVAC, water heater, smoke and carbon-monoxide detectors (test them; note the date).
- Exterior: yard, fence, porch, parking area, trash bins.
- Keys, remotes, garage openers — count them, and record the count on the checklist.

Take dated photos of every room and of any existing damage, close up. Both parties sign the checklist. Give the tenant a copy. File the original with the photos in the management file. This takes 30–45 minutes. It is the best-spent 45 minutes in property management.

**The tenant's 48-hour window:** give the tenant 48 hours after move-in to add anything they notice to the inspection in writing. This is fair, it is documented, and it removes the "I didn't see it on move-in day" argument later.

## During the tenancy — the annual inspection

Inspect each unit **once a year**, with proper written notice under your state's entry rule (commonly 24 hours). This is not a white-glove inspection. You are looking for four things:

1. **Habitability issues** you are responsible for — leaks, mold, broken detectors, pest signs.
2. **Damage in progress** — a small leak under a sink, a running toilet, a cracked window — that is cheap now and expensive later.
3. **Lease compliance** — unauthorized occupants, unauthorized pets, alterations.
4. **Life-safety** — detectors working, exits clear, no blocked panels.

Write up the findings, photograph anything notable, and give the tenant a copy with any action items and dates. If you find a problem the tenant caused, say so in writing, with a date to fix it. The annual inspection is also your best turnover-prevention tool: tenants who see you maintaining the property tend to maintain it too.

## The move-out inspection

When the tenant gives notice, send them the move-out instructions in writing: the date and time of the inspection, what "clean" means (the move-out standard, in plain language), and the key-return process. Do the inspection **with the tenant present if they are available**, using the same checklist as move-in, room by room, with fresh photos.

Compare move-in and move-out condition side by side. The legal standard in most states is **normal wear and tear versus damage**. Normal wear and tear — faded paint, light scuffs, a worn carpet path — is the landlord's cost of doing business and cannot be charged to the tenant. Damage — a broken window, a hole in a wall, a stained carpet from a pet, an appliance broken by misuse — can be, with documentation and receipts.

**Worked example — Mara's deposit accounting.** Tenant leaves a $1,350 unit after two years. Deposit held: $1,350.

| Item | Cost | Chargeable? |
|---|---|---|
| Repaint two rooms (faded paint, light scuffs) | $420 | No — normal wear and tear |
| Carpet cleaning (routine) | $150 | No — routine turnover cost |
| Broken bedroom window (tenant's child, admitted) | $210 | Yes |
| Pet stain in living-room carpet, section replacement | $380 | Yes |
| Missing garage remote | $45 | Yes |
| **Total deductions** | **$635** | |
| **Deposit returned** | **$715** | |

Mara sends the itemized statement and the $715 refund within her state's 21-day deadline, with photos and receipts attached. The tenant disagrees about nothing, because the move-in inspection showed the window intact and the carpet unstained. Without that inspection, the $635 would have been an argument — and quite possibly a loss.

## The turnover sequence

A turnover is a project with a fixed sequence. Run it in order:

1. **Move-out inspection** and key return (day 0).
2. **Deposit accounting** — start it the same week; the legal clock is already running.
3. **Cleaning and repairs** — use your vendor list (Module 8). Get the unit rent-ready before you photograph it.
4. **Photos and listing** — pre-market if you had notice (Module 2); otherwise list the day the unit is clean.
5. **Showings, application, screening, lease** — Modules 2–4, on the clock.

Mara's turnover budget per unit: cleaning $250, minor repairs $300, paint touch-up $150, carpet cleaning $150 — about **$850** in routine turnover cost, plus vacancy loss. She budgets it every year whether or not a turnover happens, because over a 4-unit portfolio, roughly one unit turns over each year.

## Action Steps — Module 5

1. Print the move-in/move-out checklist and keep blank copies in the management file.
2. Schedule annual inspections for every unit and send the notices.
3. Write your move-out instruction letter (date, cleaning standard, key return, deposit timeline) and file it as a template.
4. Photograph every unit's current condition this week, even mid-tenancy — a dated photo set is better than no record at all.

---

# Module 6 — Rent Collection and Late Fees: The Money System

## Rent is a system, not a hope

Rent collection fails in one of two ways: there is no written policy, or there is a policy nobody follows. A tenant who pays on the 8th without consequence learns that the 8th is the due date. A tenant who gets a notice on the 2nd learns that the 1st is the due date. Your collection system is the teacher. Teach well.

## The policy — write it, put it in the lease, enforce it the same way every time

Your rent policy should state, in the lease and in a one-page handout at move-in:

- **Due date:** the 1st of the month (or whatever your lease says).
- **Grace period:** if your state allows a grace period, or if you choose to offer one — commonly 3–5 days. State the exact day the late fee applies. If your state sets a minimum grace period or a late-fee cap, your policy must comply.
- **Late fee:** the amount and how it is calculated — a flat fee, a percentage of rent, or a flat fee plus a daily amount after a certain day. State it exactly.
- **Accepted payment methods:** bank transfer, online portal, check, money order — whatever you accept, and what you do not accept (cash is best avoided: it has no paper trail unless you issue a receipt on the spot).
- **Returned payments:** the fee for a bounced check or failed transfer, and the requirement to pay by certified funds after a return.
- **Partial payments:** your policy on whether you accept them, and — critically — whether accepting a partial payment affects your right to proceed with a nonpayment notice in your state. In some states it does. Know before you accept a dollar.
- **How payments are applied:** typically to the oldest balance first (fees, then rent), or as your state requires.

## The collection calendar

The calendar is the system. Pin it to the wall.

| Day | Action |
|---|---|
| 1st | Rent due. |
| 2nd | Friendly reminder to anyone unpaid — text or email: "Rent was due yesterday. Please pay today to avoid the late fee on the 5th." |
| 5th (or end of grace period) | Late fee applies. Send the written late notice stating the amount owed (rent + fee) and the date by which it must be paid. |
| 8th | Phone call. Calm, factual: "Your rent of $1,350 plus a $75 late fee is now due. Can you tell me when it will be paid?" Write down what they say and the date they promise. |
| 10th–12th | If no payment and no credible plan, send the formal pay-or-quit notice required by your state (the notice period varies — commonly 3, 5, or 10 days). Do not send it late. Do not send it early. Send it exactly when your state's rule allows, because the notice period is the clock that leads to the next step. |
| Notice expires unpaid | File for eviction (Module 11) or engage your attorney. Do not accept a partial payment that would reset the process unless your attorney advises it. |

The key discipline: **the calendar runs on dates, not on feelings.** The tenant's story may be true, and you can still follow the calendar. Compassion and process are not opposites — the process is what keeps a hard month from becoming a lost quarter.

## Worked example — late-fee math

Mara's policy: rent due the 1st, 5-day grace period, late fee of **$75 flat plus $10 per day** after the 5th, capped at 10% of monthly rent. Her state's cap is 10% of rent — for the $1,350 unit, that is $135 — so the policy must cap there. Check the cap first; a policy that exceeds it is unenforceable and can create liability.

Tenant in the $1,350 unit pays on the 12th. Days late past the grace period: the 6th through the 12th is 7 days.

- Flat fee: $75
- Daily fee: 7 × $10 = $70
- Uncapped total: $145
- **Capped at 10% of rent: $135**
- Amount due: $1,350 rent + $135 late fee = **$1,485**

If the same tenant pays on the 8th: flat $75 + 3 × $10 = $105, under the cap, so the total is $105 and the amount due is $1,455.

Mara's ledger records rent and fees on separate lines, because fees are income but they are not rent, and a court will want to see the distinction. Her rule: **fees are never waived silently.** If she waives a fee for a genuine hardship, she does it once, in writing, stating that it is a one-time courtesy and that the policy stands. A waived fee with no note becomes a precedent the tenant will remember and you will not.

## The rent ledger

Every unit has a rent ledger — a simple table, one row per month:

| Month | Rent due | Date paid | Amount paid | Late fee | Balance |
|---|---|---|---|---|---|
| Jan | $1,350 | Jan 1 | $1,350 | $0 | $0 |
| Feb | $1,350 | Feb 6 | $1,350 | $105 | $0 |
| Mar | $1,350 | Mar 1 | $1,350 | $0 | $0 |

The ledger is the first thing a judge, an accountant, or a buyer of your property will ask for. Keep it current — reconcile it on the 1st and the 15th of every month, without exception. A ledger that is two months behind is a ledger you cannot trust, and a collection system you cannot trust is not a system.

## When a tenant cannot pay

Sometimes a tenant genuinely cannot pay — a lost job, a medical bill, a car repair. The system still applies, but the conversation changes. Ask for the facts: How much can they pay, and when? Can they pay half now and half on the 15th? Is there a payment plan that gets you whole within 30 days? Put any plan **in writing, signed by both parties**, with exact dates and amounts, and a clear statement that missing a plan payment restarts the notice process. A written plan protects the tenant (they know exactly what is expected) and protects you (you have a document, not a memory of a phone call).

Do not accept a plan that stretches past 30 days without legal advice. Do not accept a plan from a tenant who has broken two plans already. And never let sympathy stop the calendar: send the notices on schedule even while you negotiate. The notice is not an eviction; it is the paper trail that keeps your options open.

## Worked example — the cost of a slow collection

Mara's $1,250 unit. The tenant stops paying in March. Compare two responses:

- **Fast response:** notice sent on the 10th, eviction filed when the notice expires, tenant out by early May. Lost rent: about **2 months, $2,500**, plus filing costs.
- **Slow response:** landlord "gives them time," sends the notice in late April, files in May, tenant out in July. Lost rent: about **4 months, $5,000**, plus filing costs — and the unit needs more work because the tenant stopped caring in April.

The difference is **$2,500**, and it was decided on the 10th of March, not in the courtroom. Speed is not harshness. Speed is the system doing its job.

## Action Steps — Module 6

1. Write your rent policy and put it in the lease and the move-in handout.
2. Build the collection calendar and pin it where you work.
3. Set up the rent ledger for every unit and reconcile it on the 1st and 15th.
4. Choose your payment method and stop accepting cash without a written receipt.

---

# Module 7 — Maintenance: Triage, Budgets, and the Reserve

## Maintenance is where profit leaks

Maintenance is the largest controllable cost in property management, and the one most landlords manage worst — because it arrives as emergencies. A leak at 11 p.m. feels like an emergency. A leak discovered at the annual inspection is a $180 repair. The difference is not the leak. It is the system that found it.

## How tenants report maintenance

Give tenants **one** way to report maintenance, in writing: an online form, an email address, or a text number — pick one and put it in the lease and on the fridge. Verbal reports at the mailbox do not count, because they cannot be tracked. The request form (see `templates/maintenance-request-sop.md`) asks for:

- Unit and tenant name
- What is wrong, and where
- When it started
- Whether it is getting worse
- Whether there is water, smoke, smell, or a safety issue
- Photos (ask for them — a photo of a leak tells you more than a paragraph)
- Permission to enter, and the best times

Acknowledge every request within **24 hours**, even if the answer is "scheduled for Thursday." Silence is what turns a maintenance request into a tenant complaint, and a complaint into a bad review or a withheld-rent dispute.

## Triage — three levels, no guessing

Every request gets a level the day it arrives:

**Level 1 — Emergency (respond within hours, fix within 24 hours).** Anything that threatens life, safety, or the structure: no heat in winter, no water, sewage backup, gas smell, major active leak, electrical hazard, broken exterior door or window that leaves the unit unsecured, fire or flood damage. Call your emergency vendor immediately. If the tenant must leave the unit, document it and discuss temporary arrangements — and check your insurance and your state's habitability rules before you promise anything.

**Level 2 — Urgent (respond within 24 hours, fix within 3–5 days).** A broken appliance, a running toilet, a minor leak, a broken lock on an interior door, no hot water, a pest sighting. Uncomfortable and getting worse, but not dangerous today.

**Level 3 — Routine (respond within 48 hours, fix within 14 days).** A dripping faucet, a sticking door, a cracked tile, a loose handrail, cosmetic items. Schedule it with the next vendor visit or the next turnover.

Write the level on the request, with the date. If a Level 3 becomes a Level 2 — the drip becomes a leak — re-level it and note the change. The triage log is your proof that you responded promptly, which matters in habitability disputes.

## The maintenance budget — worked example

Mara's portfolio: 4 units, $62,400 annual GSR, $59,880 EGI. Her maintenance budget has three lines:

| Line | Basis | Annual amount |
|---|---|---|
| Routine maintenance and small repairs | 5% of EGI | $2,994 |
| Capital reserves (roof, HVAC, water heater, appliances) | 5% of EGI | $2,994 |
| Turnover costs | ~1 turnover/year at $850 | $850 |
| **Total** | | **$6,838** |

That is about **$570 per month** across the portfolio, or **$142 per unit per month**. She funds it with a monthly transfer of $570 into the Repairs Reserve account, and she spends from that account only. When the water heater dies in year two ($1,100), the money is there — because it was never spent on anything else.

**The reserve rule:** the reserve account balance should never fall below one month's rent for your portfolio, and your target is three months of maintenance budget. For Mara, the floor is $5,200 and the target is about $1,700 above the monthly funding — in practice she keeps a $6,000 floor and rebuilds it after any large spend.

**A real-numbers check:** Mara's actual maintenance spending in her first year was $4,920 — below budget, because the annual inspections caught two small leaks early. The $1,918 she did not spend stayed in the reserve. In year two, the water heater ($1,100) and a roof repair ($1,450) took $2,550 out of the reserve in one quarter, and the account still held $3,900. That is what a reserve is for: the bad quarter does not become a crisis.

## Preventive maintenance — the cheapest repairs are the ones you schedule

A small annual schedule prevents the expensive surprises:

- **Spring:** HVAC service, gutter cleaning, exterior walk, smoke-detector batteries, check for winter damage.
- **Summer:** pest inspection, check caulking and seals, water-heater flush (annually or per manufacturer).
- **Fall:** HVAC service, heating check before cold weather, gutter cleaning, check insulation and weatherstripping.
- **Winter:** check for frozen-pipe risk, confirm heat is working in vacant units, monitor for ice dams where applicable.

Put the schedule on the calendar in January. The total cost for Mara's four units is about $900 a year in scheduled service — and it is the reason her emergency calls dropped from nine in her first year to three in her second.

## The tenant's role

Tenants cause some maintenance, prevent some, and report most of it. The lease should make the tenant's responsibilities explicit: report problems promptly (a leak reported on day one is a $180 fix; a leak reported in month three is a $1,400 floor), keep the unit clean and ventilated, change HVAC filters if assigned, do not pour grease down drains, do not flush anything but toilet paper. Put the reporting instructions on a one-page sheet on the fridge at move-in. A tenant who knows how to report a problem — and believes you will respond — is your best early-warning system.

## Action Steps — Module 7

1. Choose your single maintenance-reporting channel and put it in the lease and on the fridge sheet.
2. Set up the triage log and the three response-time standards.
3. Build your maintenance budget using the three lines above, and fund the reserve monthly.
4. Put the preventive-maintenance schedule on the calendar for the full year.

---

# Module 8 — Vendors and SOPs: Your On-Call Team

## You do not need a staff. You need a list.

A small management business runs on vendors: a plumber, an electrician, an HVAC technician, a handyman, a cleaner, a locksmith, a painter, a landscaper, and a pest-control company. Nine names, with phone numbers, rates, and response times, is a team. The mistake is finding them during an emergency. The system is finding them before one.

## Building the vendor list

For each trade, find **two** vendors: a primary and a backup. The backup matters because your plumber will be on vacation the night the pipe bursts. For each vendor, record:

- Business name, contact name, phone, email
- License and insurance status (ask for a certificate of insurance; file it)
- Typical rates or service-call fee
- Response time (emergency and routine)
- Whether they bill you directly or the tenant
- Whether they can enter with the key or lockbox arrangement you use

**How to find them:** ask other small landlords, your local landlord association, and property managers you know. Check reviews, but weight a recommendation from another landlord above a review site. Start with one small, non-urgent job — a faucet replacement, a lock change — and judge the vendor on three things: did they show up when they said, did they charge what they quoted, and did they clean up? A vendor who passes the small job gets the emergency call.

**Pay promptly.** Vendors who are paid within a week answer the phone at 11 p.m. Vendors who chase invoices for 60 days do not. Prompt payment is the cheapest vendor-retention strategy there is.

## Vendor SOPs

A standard operating procedure (SOP) is a one-page sheet that tells a vendor — or you, at 11 p.m. — exactly what to do. The maintenance-request SOP in the templates folder covers the full flow, but the essentials for each trade are:

- **Plumber:** emergency shut-off locations for each unit (water main, fixture valves), the authorization limit for emergency work without your approval (for example, $500), and the rule that any work above the limit requires a call first.
- **Electrician:** panel locations, the rule that no work proceeds without the power confirmed off, and the authorization limit.
- **HVAC:** filter sizes for each unit, service history, and the replacement-versus-repair threshold (for example: repair if under $400 and the unit is under 10 years old; replace if over).
- **Handyman:** the list of jobs they may do without calling (touch-up paint, door adjustments, caulking, minor drywall) and the jobs that need a licensed trade (anything electrical beyond a switch plate, anything plumbing beyond a fixture).
- **Cleaner:** the turnover cleaning checklist (the move-out standard), the expected time per unit, and the photo requirement — the cleaner photographs the finished unit before leaving.

**Authorization limits** are the key control. Give each vendor a written limit: "You may proceed without calling me on emergency work up to $500. Above $500, call me first." This stops a $400 emergency from becoming a $1,800 surprise, and it gives the vendor confidence to act fast when it matters.

## The work order

Every job gets a work order — a short written instruction, even for a $150 fix:

- Unit, tenant name, and access arrangement
- Problem description and photos
- Triage level and required completion date
- Authorization limit
- Where to send the invoice

The vendor returns the completed work order with the invoice and photos of the finished work. You file both in the unit's management file. A job with no work order and no photo is a job you cannot verify, cannot bill correctly, and cannot defend.

## Worked example — the 11 p.m. leak, with and without a system

**Without a system:** tenant texts at 11 p.m. You wake up, search your phone for a plumber, call three numbers, reach one at midnight, he arrives at 1 a.m., charges $450 for the call-out, and you discover the next day that the water shut-off was behind a panel the tenant could not find. Total: $450, a flooded bathroom floor, and a tenant who spent the night mopping.

**With a system:** the tenant's fridge sheet says: "Water leak: turn off the valve under the sink, then call the emergency line." The tenant turns off the valve and calls. You call the primary plumber, who has the shut-off locations on file and a $500 authorization limit. He arrives at 11:40 p.m., fixes the failed supply line for $210, photographs the work, and sends the invoice. Total: $210, a dry floor, and a tenant who tells their friends their landlord responds fast.

The system saved $240 and a floor. It also saved the tenant relationship, which is worth more than either.

## Action Steps — Module 8

1. Build your vendor list: two vendors per trade, with license, insurance, rates, and response times recorded.
2. Write the authorization limit for each vendor and send it to them in writing.
3. Create the work-order form and use it for every job, starting with the next one.
4. Run one small test job with each new vendor before you need them in an emergency.

---

# Module 9 — Tenant Relations: Communication That Prevents Conflict

## Most tenant problems are communication problems first

A tenant who feels ignored will escalate. A tenant who gets a fast, honest answer will usually wait patiently for the repair. This is not soft advice — it is loss prevention. A tenant who leaves because they felt ignored costs you a turnover ($850 plus vacancy). A tenant who stays because they felt heard costs you a phone call. The math is not close.

## The communication rules

**1. Respond within 24 hours, always.** Even if the answer is "I don't know yet, and I will have an answer by Thursday." Silence is the only response that always makes things worse.

**2. Put it in writing.** Phone calls are fine for tone; follow up with a short email or text confirming what was agreed. "As discussed, the plumber is coming Thursday between 9 and 11 a.m. Please confirm the unit will be accessible." That message is worth more than a perfect memory.

**3. Be consistent.** The same rule for every tenant, every time. A tenant who hears that their neighbor got a late fee waived "because they asked nicely" will ask nicely too — and will be right to feel wronged if you say no. Consistency is fairness, and fairness is the thing tenants actually remember.

**4. Be professional, not personal.** You are not the tenant's friend, and you are not their enemy. You are the manager of a business they live in. Friendly, brief, factual. Never discuss one tenant with another. Never discuss a tenant's finances, background, or personal situation with anyone who does not need to know.

**5. Never make a promise you cannot keep.** "The plumber will be there Thursday" is a promise. "I have called the plumber and asked for Thursday, and I will confirm the time by Wednesday evening" is a process. Promise the process, deliver the result.

## The tenant welcome — set the tone on day one

The move-in packet is the tenant-relations system in miniature. It contains:

- The signed lease and addenda (their copy)
- The move-in inspection (their copy)
- The rent policy one-pager: due date, grace period, late fee, payment methods
- The maintenance-reporting sheet: the one channel, the triage levels, the response times, the emergency instructions
- The emergency contacts: your number, the plumber's emergency line, the local non-emergency police number, the utility emergency numbers
- The move-out standard: what "clean" means, so there are no surprises in a year
- A short welcome note: who you are, how to reach you, and that you want problems reported early

A tenant who receives this packet knows how the business works. A tenant who does not will invent their own version — and their version will not favor you.

## Difficult conversations — scripts that work

**The late-rent call (day 8):** "Hi, this is Mara. Your rent of $1,350 was due on the 1st, and I haven't received it. There is a $105 late fee, so the total now due is $1,455. Can you tell me when you will be able to pay?" Then listen. Then: "Thank you. I will note that you will pay in full on the 15th. I will send a written payment plan confirming that. If the payment does not arrive on the 15th, I will need to send the formal notice, so please let me know right away if anything changes."

**The lease-violation notice (unauthorized pet):** Written, factual, dated. "On [date], an unauthorized dog was observed at the unit. The lease, Section 9, prohibits pets without written approval. Please remove the animal or submit a pet application and deposit by [date, 10 days]. If the animal remains after that date, I will proceed under the lease and applicable law." No anger, no threats, no negotiation in the notice itself. The conversation can happen after the notice is sent.

**The noise complaint:** Listen to the complaining tenant, then speak to the other tenant separately. Do not repeat what one said about the other. "I have received a complaint about noise after 10 p.m. The lease requires quiet hours from 10 p.m. to 7 a.m. Please keep noise down during those hours." Document both conversations with dates.

**The tenant who is angry:** Let them finish. Repeat back what you heard: "I understand the heat has been out since Tuesday and that is unacceptable. Here is what I have done and what happens next." People de-escalate when they feel heard, and they escalate when they feel managed. Acknowledge first, solve second.

## Renewals and retention — the cheapest vacancy is the one that never happens

It costs roughly $850 plus vacancy loss to turn a unit over. It costs a phone call and a letter to keep a good tenant. Start the renewal conversation **90 days before the lease ends**: a short letter or email — "Your lease ends on [date]. I would like to offer you a renewal at [rent] for [term]. Please let me know by [date, 60 days before end] whether you would like to renew." A tenant who is asked early feels valued. A tenant who hears nothing until 30 days before the end assumes you do not care, and starts looking.

## Action Steps — Module 9

1. Write your move-in packet and assemble it for every current tenant who does not have one.
2. Adopt the 24-hour response rule and the written-follow-up habit.
3. Write the three scripts (late rent, lease violation, noise complaint) and keep them in the management file.
4. Calendar the renewal conversation 90 days before every lease expiration.

---

# Module 10 — Renewals, Rent Increases, and Turnovers

## The renewal decision

Every lease expiration is a decision point with three options: renew the tenant, renew with changes, or end the tenancy. Decide on the numbers and the record, not on a feeling.

**Renew** when the tenant pays on time, reports maintenance promptly, keeps the unit in good condition, and follows the lease. A good tenant at slightly below market rent is usually worth more than a new tenant at market rent, because the turnover costs more than the difference.

**Renew with changes** when the tenant is good but the rent is below market, or when a term needs updating (for example, adding a pet addendum, or updating the maintenance-reporting channel). Put the changes in writing with the renewal offer.

**End the tenancy** when the tenant has a pattern of late payment, lease violations, or damage — or when you need the unit back for a legitimate reason your state allows. Follow the notice rules exactly, in writing, with the required notice period. Never end a tenancy in retaliation for a tenant exercising a legal right (such as reporting a habitability problem), and never end one for a discriminatory reason. If you are unsure, get legal advice before you send the notice.

## Rent increases — the math and the message

A rent increase is a business decision and a communication exercise. The math first:

**Worked example — Mara's increase.** Her $1,250 unit is $100 below the comparable market rent of $1,350. The tenant has been there two years and pays on time. Mara's options:

- **No increase:** she leaves $1,200 a year on the table, but keeps a good tenant with certainty.
- **Increase to $1,300 (4%):** she gains $600 a year, the tenant stays (the increase is modest and the tenant avoids moving costs), and the rent is still below market.
- **Increase to $1,350 (8%):** she gains $1,200 a year, but the tenant may leave — and a turnover costs $850 plus roughly 21 days of vacancy ($875), for a total of about $1,725. If the tenant leaves, the increase loses money in year one.

Mara chooses $1,300, and she delivers it 90 days before the lease ends, in writing, with a renewal offer: "Your lease ends June 30. I am offering a 12-month renewal at $1,300 per month, an increase of $50. The renewal reflects the cost of maintaining the property, including the new water heater installed last year. Please let me know by April 30." The message is factual, it gives a reason, and it gives time. A tenant who has 90 days to decide is a tenant who can say yes calmly.

**Check your state's rules before any increase.** Some states and cities cap annual increases, require a minimum notice period (commonly 30, 60, or 90 days depending on the size of the increase), or prohibit increases during a lease term. Some require a specific form. Never increase rent in retaliation for a complaint, and never increase one tenant's rent for a discriminatory reason. The increase must be lawful first and smart second.

## The turnover, revisited — the 21-day plan

Module 5 gave you the turnover sequence. Here is the timeline that keeps it at 21 days:

| Day | Action |
|---|---|
| −30 | Notice received; pre-marketing begins; renewal decision already made (tenant is leaving) |
| −14 | Move-out instructions sent; cleaner and vendors booked |
| 0 | Move-out inspection; keys returned; deposit clock starts |
| 1–3 | Cleaning and repairs |
| 4 | Photos; listing live |
| 5–14 | Showings; applications |
| 15–18 | Screening; lease signed; deposit collected |
| 19–21 | New tenant moves in |

If the timeline slips past 21 days, find the bottleneck: was the listing late, were showings too sparse, was screening slow, or was the unit not rent-ready? Fix the bottleneck, not the tenant.

## Action Steps — Module 10

1. Calendar every lease expiration with a 90-day renewal reminder.
2. Research the market rent for each of your units (three comparable listings each) and record it.
3. Write your renewal-offer letter template, including the rent-increase language.
4. Review your last turnover: how many days did it take, and where did the time go?

---

# Module 11 — Difficult Situations: Nonpayment, Violations, and Eviction

## A note before this module

This module describes the *process* of handling difficult situations. It is not legal advice. Eviction law is the most jurisdiction-specific area in this entire course: notice periods, notice forms, filing procedures, court timelines, and tenant defenses all vary by state and often by county or city. Some jurisdictions require mediation before filing. Some restrict evictions during certain periods. **Do not file anything, serve anything, or change a lock based on this course alone.** Work with a licensed attorney in your jurisdiction the first time you go through the process, and use what you learn to handle later cases with the same attorney's guidance.

## The escalation ladder

Difficult situations escalate in a fixed order. Skipping steps costs you time, money, and credibility — and in some jurisdictions, skipping a required notice invalidates everything that follows.

1. **Conversation.** A call or a message, factual and dated. "Rent is 8 days late. When will it be paid?"
2. **Written reminder.** The late notice with the amount owed and the date.
3. **Payment plan (if appropriate).** Written, signed, with exact dates. See Module 6.
4. **Formal notice.** The pay-or-quit or cure-or-quit notice your state requires, served exactly as your state requires (hand delivery, posting, certified mail — the method matters, and the proof of service matters).
5. **Filing.** The eviction complaint (often called an unlawful detainer action), filed in the proper court, with the filing fee and the required documents.
6. **Hearing and judgment.** You present the ledger, the lease, the notices, and the proof of service. The tenant presents their side. The court decides.
7. **Enforcement.** If the court orders possession, the order is enforced by the sheriff or constable — never by you. **Never change locks, shut off utilities, remove a tenant's belongings, or threaten a tenant to force them out.** Self-help eviction is illegal in most states and can result in damages far larger than the rent owed.

## Nonpayment — the worked timeline

Mara's $1,350 unit. The tenant pays nothing in March.

| Date | Step |
|---|---|
| March 1 | Rent due. |
| March 2 | Reminder sent. |
| March 6 | Late fee applies ($75 + $10/day). Written late notice sent. |
| March 8 | Phone call. Tenant says they lost their job and can pay half on the 15th. |
| March 9 | Written payment plan signed: $675 on March 15, $675 + fees on March 25. |
| March 15 | $675 received. Plan on track. |
| March 25 | No payment. Plan broken. |
| March 26 | Formal 5-day pay-or-quit notice served (her state's period and method), stating the full balance due. |
| March 31 | Notice expires, unpaid. Attorney files the eviction complaint. |
| April (court date) | Hearing. Mara brings the ledger, the lease, the late notices, the payment plan, the pay-or-quit notice, and the proof of service. |
| April (judgment) | Court orders possession. Sheriff schedules the lockout. |

Mara's total loss: roughly two months' rent ($2,700) plus filing costs and attorney fees. It is a bad outcome — but it is a *bounded* bad outcome, because the calendar ran on time. The landlord who waits until May to send the notice loses four months instead of two, and the difference is $2,700.

## Lease violations

A lease violation is anything the tenant does that the lease prohibits, or fails to do that the lease requires: an unauthorized occupant, an unauthorized pet, smoking where prohibited, damage to the unit, failure to report a leak, or a noise pattern that breaches the lease. Handle violations in writing, in this order:

1. **Document it.** Date, time, what you observed, photos if applicable. A violation you cannot document is a violation you cannot prove.
2. **Send a cure notice** (if your state requires or allows one): state the violation, cite the lease section, state what the tenant must do, and give the deadline your state requires.
3. **Follow up.** Inspect on the deadline date. If cured, note it in the file and move on. If not cured, send the next notice your state's process requires, and consult your attorney.
4. **Do not retaliate and do not discriminate.** A violation notice sent the week after a tenant reports a habitability problem will look retaliatory even if it is not. If the timing is awkward, get legal advice before you send it.

## The tenant who stops communicating

A tenant who will not answer calls or messages is a tenant who has already decided something, and you do not know what it is. Keep communicating in writing — email and mail — so there is a record. Send the notices on schedule. Do not enter the unit except as the law allows (emergency, or with proper notice for a lawful purpose). If you have genuine concern for the tenant's safety, call the local non-emergency police number and ask for a welfare check. That is their job, not yours.

## Abandonment

If a tenant appears to have left — belongings gone, rent unpaid, no contact — do not assume the tenancy is over and do not dispose of belongings. Most states have a specific abandonment procedure: a notice, a waiting period, and rules for handling and storing left-behind property. Follow it exactly, with legal advice. Disposing of a tenant's property incorrectly can create a claim larger than the rent you are owed.

## When to call an attorney

Call an attorney — before you act, not after — when: you are filing an eviction for the first time; the tenant has an attorney; the tenant raises a habitability or discrimination claim; you are unsure about the notice form, the notice period, or the service method; the tenant is in bankruptcy; or the property is in a jurisdiction with rent control or just-cause eviction rules. A one-hour consultation is far cheaper than a dismissed case you must refile from the beginning.

## Action Steps — Module 11

1. Find a landlord-tenant attorney in your jurisdiction now — before you need one — and save their number in the management file.
2. Learn your state's notice periods and service methods, and write them on the collection calendar.
3. File the escalation ladder in the management file, with the attorney's number at the top.
4. Review your lease's notice clause (Module 4) and confirm it matches your state's requirements.

---

# Module 12 — Owner Reporting, Scaling, and Your 90-Day Plan

## The monthly owner report

Whether the "owner" is you or a paying client, the monthly owner report is the product of the management business. It answers four questions: How much money came in? How much went out? Is the property occupied? What is open or coming up?

Mara's report for March (4 units, $5,200 scheduled rent) looks like this:

**Income:** Rent collected $5,200 (all four units paid; one paid late on the 6th, $105 late fee). Late fees $105. Pet rent $50. Total income: **$5,355**.

**Expenses:** Mortgage (owner's cost, shown for the owner's records) $2,400. Insurance $180. Maintenance and repairs $320 (faucet replacement $140, HVAC filter service $180). Turnover $0. Management software $29. Total operating expenses (excluding mortgage): **$529**.

**Occupancy:** 4 of 4 units occupied (100%). One lease expires June 30; renewal conversation starts April 1.

**Open items:** Unit 3 — tenant reported a sticking back door (Level 3), handyman scheduled April 8. Unit 1 — annual inspection due in May.

**Reserve balance:** $6,420, after the $570 monthly transfer and $320 in maintenance spending.

The report takes Mara about 45 minutes to produce, because the ledger, the maintenance log, and the calendar are already current. The template is in `templates/monthly-owner-report.md`. If you manage for a client, send the report by the 10th of the following month, with the bank statement or a transaction summary attached. A client who receives a clear report on time does not call you on the 15th asking where the rent is.

## Measuring the business — the quarterly review

Once a quarter, step back and check five numbers against your targets:

| Measure | Target | Mara, Q1 |
|---|---|---|
| Occupancy rate | ≥95% | 100% |
| Delinquency rate (rent >5 days late) | <5% | 4.2% (one late payment in 12 unit-months) |
| Days to lease (average) | ≤21 days | 19 days |
| Maintenance cost as % of EGI | ≤10% | 6.8% |
| Reserve balance vs. floor | At or above floor | $6,420 vs. $5,200 floor — above |

If a number misses its target, the fix is a system fix, not a willpower fix. Delinquency is high? The collection calendar is not being followed. Days to lease is long? The listing is going up late. Maintenance is high? The preventive schedule is slipping, or the annual inspection is not catching problems early. The numbers tell you where to look.

## Scaling: from self-management to a management business

If you want to manage properties for other owners — the second audience for this course — the system you have built is the business. The steps to start:

1. **Check licensing.** Many states require a real-estate broker's license, or a property-management license, to manage property for others for a fee. Some allow an owner to manage their own property without a license but require one the moment you manage someone else's. Verify this before you take a client. This is the single most common legal mistake new managers make.
2. **Form the business.** A business entity, a business bank account, and insurance (general liability and errors-and-omissions coverage, at minimum). Client funds — rent and deposits — must be held in a separate trust or escrow account, never mixed with your operating money. Many states require this by law and audit it.
3. **Set your fee.** Common structures: a monthly management fee of 8–10% of collected rent, a leasing fee of 50–100% of one month's rent for placing a tenant, and a setup fee. Work the math on a small portfolio before you quote: at 8% of Mara's $5,200 monthly rent, the fee is $416 per month for four units. Make sure that covers your time.
4. **Write the management agreement.** The contract between you and the owner: your fee, your authority (what you may spend without approval — the authorization limit from Module 8, applied to the owner's money), the owner's responsibilities, the term, and the termination clause. Have an attorney draft or review it.
5. **Take on one client, not ten.** Run one owner's portfolio through the full system for three months. Produce the monthly reports. Learn where the system strains. Then grow.
6. **Never promise what the system cannot do.** You cannot promise an owner that a tenant will never be late, that a unit will never be vacant, or that a repair will never be expensive. You can promise a system, a report, and a response time — and then deliver them.

## Your 90-day plan

Install the system in order. Do not try to do it all in a weekend.

**Days 1–30 — Foundation.**
- Set up the management file for every unit.
- Open the Repairs Reserve account and start the monthly transfer.
- Write your screening criteria, your rent policy, and your collection calendar.
- Build the vendor list (at least one vendor per trade).
- Photograph every unit's current condition.

**Days 31–60 — Leasing and money.**
- Write the listing template and the showing fact sheet.
- Put the move-in packet together.
- Set up the rent ledger and reconcile it twice a month.
- Run the first annual inspections.
- Write the maintenance-reporting channel and the triage standards.

**Days 61–90 — Operations and reporting.**
- Produce the first monthly owner report.
- Write the vendor SOPs and the authorization limits.
- Calendar every lease expiration with a 90-day renewal reminder.
- Find your landlord-tenant attorney and save their number.
- Run the quarterly review against the five measures.

At day 90, the system is running. It will not be perfect — no system is, in its first quarter — but it will be written, measured, and improvable. That is the difference between a landlord and a business.

## The outcome

A managed rental is not a passive investment. It is a small business with a product (a home), customers (tenants), suppliers (vendors), and a ledger. Run it like a business — with written policies, a calendar, a reserve, and a report — and it behaves like one: predictable income, controlled costs, and problems that arrive as scheduled work instead of midnight emergencies. That is the whole promise of this course, and it is a promise you keep to yourself, one Monday, one Wednesday, and one Friday at a time.

---

# Appendix A — The Numbers, All in One Place (Mara's 4-Unit Example)

| Measure | Amount |
|---|---|
| Gross scheduled rent (annual) | $62,400 |
| Vacancy budget (5%) | $3,120 |
| Other income (fees, pet rent) | $600 |
| Effective gross income | $59,880 |
| Operating expenses (35% of EGI) | $20,958 |
| Net operating income | $38,922 |
| Maintenance budget (routine + capital + turnover) | $6,838/year ($570/month) |
| Repairs Reserve floor | $5,200 (one month's rent) |
| Repairs Reserve target | $6,000+ |
| Routine turnover cost | ~$850 per unit |
| Days-to-lease target | 21 days |
| Delinquency target | Under 5% |
| Late fee (example policy) | $75 flat + $10/day after 5-day grace, capped at 10% of rent |

---

# Appendix B — Document Checklist

- [ ] Lease (state-appropriate, attorney-reviewed) and all addenda
- [ ] Move-in/move-out inspection checklist with photos
- [ ] Tenant application and screening consent
- [ ] Tenant-screening scorecard (completed, filed)
- [ ] Adverse action notice (if applicable)
- [ ] Rent ledger (current, reconciled 1st and 15th)
- [ ] Rent policy and collection calendar
- [ ] Maintenance request form and triage log
- [ ] Vendor list with licenses, insurance, rates, authorization limits
- [ ] Work orders with invoices and completion photos
- [ ] Move-in packet (lease copy, rent policy, maintenance sheet, emergency contacts)
- [ ] Renewal-offer letter template
- [ ] Monthly owner report template
- [ ] Attorney contact and your state's notice requirements

---

# Appendix C — Glossary

- **Effective gross income (EGI):** Gross scheduled rent minus vacancy loss, plus other income.
- **Net operating income (NOI):** EGI minus operating expenses, before mortgage payments.
- **Gross scheduled rent (GSR):** Total rent if every unit were occupied all year at full rent.
- **Security deposit:** Money held by the landlord against damage or unpaid rent, returnable under state law with an itemized statement.
- **Pay-or-quit notice:** A formal notice requiring the tenant to pay the amount owed or vacate within a state-set period.
- **Cure-or-quit notice:** A formal notice requiring the tenant to fix a lease violation or vacate.
- **Normal wear and tear:** The gradual deterioration of a unit from ordinary use, which a landlord may not charge to a tenant.
- **Habitability:** The legal standard that a rental must be safe and livable — working heat, water, electricity, and a sound structure.
- **Adverse action notice:** A notice required when a landlord declines an applicant or approves with conditions based on a consumer (credit/background) report.
- **Fair housing:** Federal and state laws prohibiting discrimination in housing based on protected characteristics.
- **Turnover:** The process of preparing a unit for a new tenant after the old tenant leaves.
- **Authorization limit:** The maximum amount a vendor may spend without the landlord's prior approval.

---

*This course is education only. It is not legal, tax, or financial advice. Landlord–tenant law, fair-housing rules, and eviction procedures vary by state and locality and change over time. Verify current local law and consult a licensed attorney for your situation before using any lease, notice, or policy in this course.*
