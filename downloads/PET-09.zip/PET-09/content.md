# Pet Product Brand Builder: From Idea to Shelf-Ready Brand

**A complete brand-development system for launching a pet product line — product validation, sourcing, packaging, pricing, and getting into stores and online channels.**

---

## How to Use This Course

This is a self-paced written course manual. Each of the 12 modules is a complete lesson: read it, complete the exercise at the end, and do not move on until you have the deliverable for that module in hand. The course is designed to be worked through in order over 6 to 12 weeks, at roughly one module per week if you are building alongside a job, or two modules per week if you can dedicate focused time.

You will finish with five tangible assets:

1. A validated product concept with a written validation scorecard.
2. A shortlist of at least three qualified suppliers, with quotes compared on a like-for-like basis.
3. A finished costing and pricing model for your hero product.
4. Shelf-ready packaging and labelling that passes your own compliance checklist.
5. A retail pitch deck and a list of ten target buyers, with outreach sent.

Keep every worksheet in the companion workbook (`workbook.md`). Your scorecard, calculator, scripts, checklists, and pitch deck live in the `templates/` folder. Print them, fill them in by hand if that helps you think, and keep the completed versions together — they become your brand file, the document you show a manufacturer, a retail buyer, or a business partner when they ask, "How do you know this will work?"

### A note on safety and honesty

This course teaches you how to build a pet product brand. It does not replace professional advice. If your product is a food, treat, chew, or anything a pet eats or puts in its mouth, you must take ingredient safety, manufacturing standards, and labelling rules seriously from day one. Consult a veterinarian or a qualified animal nutrition professional before finalising any edible formulation, and consult a qualified professional about the regulations that apply in the markets where you intend to sell. Rules differ by country and by state, and they change. Nothing in this course is legal, veterinary, or regulatory advice, and no part of it guarantees sales, retail placement, or any particular income. What it does guarantee is a disciplined process: if you follow it, you will know — with evidence — whether your idea deserves your money, and you will be able to present it professionally to the people whose yes you need.

### Who this course is for

- An entrepreneur with a pet product idea — food, treats, toys, or accessories — who wants a disciplined route to launch.
- A pet owner who spotted a gap in the market and wants to test it properly before spending serious money.
- A small maker already selling at markets or online who wants to move into retail.
- A founder with a prototype who needs sourcing, costing, pricing, and a pitch that a buyer will take seriously.

### What this course is not

It is not a get-rich-quick programme. It will not teach you to cut corners on safety, copy a competitor's product, or mislead a retailer. It assumes you are willing to do the unglamorous work — talking to customers, requesting samples, reading labels, and doing the maths — before you spend money on inventory.

---

## Table of Contents

- Module 1 — The Pet Product Landscape: Where the Opportunity Actually Is
- Module 2 — Finding Your Niche and Your Customer
- Module 3 — Validating Demand Before You Spend a Dollar on Stock
- Module 4 — Designing a Product People Will Buy Twice
- Module 5 — Sourcing and Manufacturing: Finding the Right Partner
- Module 6 — Costing and Pricing: Making the Maths Work
- Module 7 — Packaging and Labelling That Sell and Comply
- Module 8 — Building the Brand: Name, Story, and Identity
- Module 9 — Launching Online: Your Store, Marketplaces, and Content
- Module 10 — Getting Into Retail: The Pitch, the Buyer, and the Terms
- Module 11 — Operations: Inventory, Fulfilment, and Cash Flow
- Module 12 — Growing the Brand: Line Extensions, Wholesale, and What Comes Next
- Worked Example A — The Validation Scorecard, Worked Through
- Worked Example B — Costing and Pricing With Real Numbers
- Worked Example C — A Retail Pitch, Start to Finish
- Your 90-Day Launch Plan
- Final Checklist: Shelf-Ready

---

## Module 1 — The Pet Product Landscape: Where the Opportunity Actually Is

### What you will learn

- How the pet market is structured, in plain terms.
- The four product categories in this course and how they differ.
- Why "the pet industry is huge" is not a business case.
- How to read a trend without chasing it.

### The market in plain terms

Pet products fall into a small number of buying occasions. A pet owner buys food and treats every week or two; toys and accessories every few months; and health, grooming, and special-occasion items when a need arises. That rhythm matters more than the size of the whole market. A brand that sells something a customer buys repeatedly has a fundamentally easier business than a brand that sells a one-off item, however beautiful that item is. When you choose your category, you are choosing your repeat-purchase rhythm, your price point, and your customer acquisition cost all at once.

The four categories this course covers are:

1. **Food and treats.** Highest repeat purchase, highest regulatory burden, highest trust barrier. A customer will switch treats more readily than they will switch a main food, which makes treats the usual entry point for a new food brand.
2. **Toys.** Lower regulatory burden than food, but safety still matters — choking hazards, materials, and durability are real concerns, and a toy that falls apart in a day generates returns and bad reviews faster than almost anything else.
3. **Accessories.** Collars, leads, beds, bowls, apparel, travel gear. Design-led, often higher margins, but more vulnerable to fashion cycles and to being copied.
4. **Care and wellness.** Grooming, dental, calming, and health-adjacent products. The highest claims risk: anything that sounds like a medical claim invites scrutiny. Never make a health claim you cannot substantiate, and never imply veterinary endorsement you do not have.

Do not try to launch in all four at once. Pick one hero product in one category. You can extend later — Module 12 covers how — but a launch with one clear product teaches you your customer, your supplier, and your numbers faster than a scattered range ever will.

### Why "the market is huge" is not a business case

A large market is not the same as an available market. Your available market is the number of people who (a) own the kind of pet your product is for, (b) buy products in your category at your price point, (c) shop where you intend to sell, and (d) would plausibly choose a new brand over the one they already buy. That number is always much smaller than the headline market size, and it is the only number that matters for your first year.

Work it out from the bottom up, not the top down. Start with a specific customer — for example, "owners of medium-sized dogs in my city who buy premium treats at independent pet stores" — and estimate how many of them exist, how often they buy, and what they spend. If that bottom-up number cannot support your costs, no headline market size will save you. Module 3 gives you the tools to test the estimate with real people instead of guessing.

### Trends: how to read them without chasing them

Three questions separate a durable trend from a fad:

1. **Is it driven by a real change in how people live?** Working from home, smaller living spaces, and pets treated as family members are durable drivers. A novelty shape or a viral colour is not.
2. **Does it change what the customer will pay for?** A trend that only changes aesthetics is easy for competitors to copy. A trend that changes what the customer values — for example, shorter ingredient lists, or products suited to small flats — creates room for a new brand.
3. **Can you serve it without betting the whole brand on it?** A good launch rides a trend with one product and keeps the brand broad enough to survive when the trend cools.

Write down the three trends you think matter most for your idea, and answer those three questions for each in your workbook before you go further.

### Exercise — Module 1

Write a one-paragraph description of the market you intend to enter, naming the category, the pet, the price tier, and the channel. Then write one sentence explaining why that market is available to a new brand, not merely large. If you cannot write that sentence honestly, your niche is not yet specific enough — Module 2 will fix that.

---

## Module 2 — Finding Your Niche and Your Customer

### What you will learn

- How to narrow from a broad idea to a defensible niche.
- How to build a customer profile from evidence, not imagination.
- How to map competitors honestly.
- How to write a positioning statement you can actually use.

### From idea to niche

Most pet product ideas start too broad: "healthy dog treats" or "stylish cat toys." A niche is a broad idea with three decisions made: **which pet, which problem, and which buyer.** "Healthy dog treats" becomes "single-protein, soft training treats for small-breed puppies, bought by first-time owners who shop at independent pet stores." That is a niche you can design for, price for, and pitch to a buyer. The broad version is a hope; the narrow version is a plan.

Narrowing feels like giving up customers. It is the opposite. A narrow niche lets you make a product that is clearly better for one group than anything else on the shelf, and that group will tell other people like them. A broad product competes with everyone and delights no one.

Use the three filters:

- **Pet filter.** Species, size, age, breed tendencies, health needs. A treat for a senior dog with dental issues is a different product from a treat for a puppy in training.
- **Problem filter.** What is the owner trying to solve? Training, boredom, anxiety, digestion, dental care, convenience, gifting, identity ("I want my dog to look smart")? Name the problem in the owner's words.
- **Buyer filter.** Who pays, where do they shop, and what do they already trust? A buyer who shops at a premium independent store behaves differently from one who buys the cheapest option online.

### Building a customer profile from evidence

A useful customer profile has five parts, and each one should come from something you observed or heard, not something you assumed:

1. **Who they are.** Age range, household, type of pet, lifestyle. Keep it factual.
2. **What they buy now.** Brand, price, pack size, where they buy it, how often.
3. **What frustrates them.** What do they complain about — price, ingredients, durability, mess, availability?
4. **What they value.** What would make them switch? What would make them pay more?
5. **Where they listen.** Which stores, accounts, vets, groomers, trainers, or friends influence them?

Get this evidence from ten conversations. Ten is a small number, but ten real conversations beat a hundred assumptions. Talk to owners at dog parks, pet stores, training classes, and in online communities where you are a genuine participant, not a salesperson. Ask open questions: "What treats do you buy, and why those?" "What have you stopped buying, and why?" Listen for the exact words they use — those words become your packaging copy and your pitch.

### Mapping competitors honestly

List your five closest competitors — the products your customer would buy instead of yours. For each, record: price per unit and per gram or per use, pack size, key ingredients or materials, where it is sold, and what customers praise and complain about in reviews. Read at least twenty reviews per competitor, and sort the complaints into themes. Complaints are your product brief: if every review of the leading toy says "my dog destroyed it in ten minutes," durability is your opening. If every review of a treat says "my dog loves it but the bag is tiny for the price," value per bag is your opening.

Do not copy a competitor. Use the map to find the gap — the combination of customer, problem, and price point that no one serves well — and build for that gap.

### Your positioning statement

Write one sentence in this form:

> For [customer], who [problem], [your brand] is the [category] that [key benefit], because [reason to believe].

Example: "For first-time owners of small-breed puppies, who struggle to find soft, small training treats that do not upset sensitive stomachs, PupStart is the training treat that uses a single protein and a soft texture sized for small mouths, because every batch is made in small runs with a short, named ingredient list."

If you cannot fill in the "because" with something true and specific, your positioning is a slogan, not a strategy. Go back to the competitor map and the customer conversations until you can.

### Exercise — Module 2

Complete the customer profile and competitor map in the workbook. Write your positioning statement and read it aloud. If it sounds like it could describe any brand, narrow it further.

---

## Module 3 — Validating Demand Before You Spend a Dollar on Stock

### What you will learn

- The difference between polite interest and real demand.
- Five validation methods, from free to paid, in order of strength.
- How to run a pre-order or waitlist test that tells you the truth.
- How to use the validation scorecard and what score means "go."

### Polite interest is not demand

"I love that idea!" is not validation. People are kind, and they like encouraging founders. Real demand is a behaviour: someone gives you money, gives you their email and then opens your follow-ups, spends time giving detailed feedback, or pre-orders. Design every validation test around a behaviour, not an opinion.

The question is never "Do people like my idea?" It is "Will enough of the right people pay my price, repeatedly, through a channel I can actually reach?" Everything in this module tests that question.

### Five validation methods, weakest to strongest

**1. Conversations (free).** The ten conversations from Module 2 count, but only if you asked about current behaviour and spending, not hypotheticals. "Would you buy this?" is a weak question. "What did you last spend on treats, and what would have to be true for you to switch?" is a strong one. Record exact quotes and spending figures.

**2. The landing page test (low cost).** Build a single page describing the product, price, and pack size, with an email signup for launch notification. Drive a small amount of traffic from the places your customer actually spends time — a local pet group, a relevant account, a market stall with a QR code. A signup rate below 2–3% of visitors, or signups that never open a follow-up email, tells you the message or the offer needs work before you spend on stock.

**3. The market stall or pop-up (moderate cost, high learning).** Sell a small batch — even a handmade or small-run batch — in person. You learn more in one afternoon watching people pick up, sniff, read, hesitate, and either buy or put it back down than in a month of online surveys. Ask every buyer why they bought, and every person who hesitated what stopped them. Note the exact price at which people hesitate.

**4. The pre-order test (strong).** Offer the product for pre-order at your real launch price, with a clear delivery date and a clear refund policy. Pre-orders are the strongest signal available before full production, because they require money. Set a threshold in advance — for example, 50 pre-orders in 30 days — and honour the result either way. If you do not reach it, you have learned something cheap. If you do, you have your first customers and your first cash.

**5. The small-batch pilot (strongest, most expensive).** Produce the smallest viable run your supplier allows and sell it through one channel only. This tests the whole system — product, packaging, price, fulfilment — at small scale. Only do this after the cheaper tests point the same way.

### The validation scorecard

The template in `templates/product-validation-scorecard.md` scores your idea on ten criteria, each from 0 to 3: clear customer, painful problem, willingness to pay, repeat purchase, reachable channel, defensible difference, supplier feasibility, safety and compliance feasibility, margin feasibility, and founder fit. A worked example is at the end of this course (Worked Example A). Score honestly, with evidence noted for each line. A total of 22 or above, with no single criterion at 0, is a reasonable "go" signal. A total below 18, or any 0 on willingness to pay, safety, or margin, is a "stop and rethink" signal — not a failure, but a prompt to change the product, the price, or the customer before spending more.

### Common validation mistakes

- **Asking friends and family.** They love you. Their praise is not data. Include them in your enthusiasm, not your evidence.
- **Surveying the wrong people.** A survey of general pet owners tells you little if your customer is a narrow niche. Recruit respondents who match your Module 2 profile.
- **Testing the wrong price.** Validating at a discount price tells you people like a bargain, not that they will pay your launch price. Always test at the real price.
- **Counting signups as sales.** An email list is an asset, but it is not revenue. Track open rates and, above all, conversions to paid orders.
- **Falling in love with the idea.** If three independent tests point the same negative way, believe them. Pivoting early is cheap; pivoting after a full production run is not.

### Exercise — Module 3

Run at least two validation methods and complete the scorecard with evidence for every line. Write down your go / no-go threshold before you see the results, and honour it.

---

## Module 4 — Designing a Product People Will Buy Twice

### What you will learn

- What makes a pet product worth repurchasing.
- How to write a product specification a supplier can actually make.
- Safety and quality decisions for each category.
- How to run a prototype and feedback loop.

### The second purchase is the business

The first purchase is driven by packaging, price, and curiosity. The second purchase is driven by the product itself: did the pet like it, did it last, did it solve the problem, was it easy to use, did it feel worth the money? Design for the second purchase from the start. Ask, for every feature: "Does this make the customer come back, or does it only make them pick it up the first time?" Features that only serve the first purchase — gimmicky shapes, excessive packaging — are costs, not assets.

For each category, the repeat-purchase drivers differ:

- **Food and treats:** palatability (the pet eats it eagerly), digestive tolerance, visible benefit the owner can see, and consistency from bag to bag. One bad batch loses a customer permanently.
- **Toys:** durability relative to price, safety, and whether the pet stays interested after the novelty fades. A toy the pet ignores after a day will not be repurchased, however well made.
- **Accessories:** comfort, fit, ease of cleaning, and durability. An accessory that is hard to clean or uncomfortable will be replaced by a competitor's, not by yours.
- **Care products:** ease of use, visible result, and gentleness. Anything that irritates skin or coat, or is unpleasant to apply, will not survive the first bottle.

### Writing a product specification

A supplier cannot make "a premium dog treat." They can make a product defined by a specification. Write yours before you contact any supplier. A good specification includes:

- **Product type and variant(s).** Exactly what it is, flavours or sizes, and what it is not.
- **Dimensions, weight, and pack size.** Net weight per pack, number of units, and tolerances.
- **Materials or ingredients.** For edibles, the full ingredient list in descending order, with sourcing requirements (for example, single named protein, no artificial colours). For non-edibles, materials, thicknesses, hardware, and finishes.
- **Performance requirements.** For a toy: intended chew strength, expected lifespan under normal use, and any testing standard you require. For a treat: texture, size, moisture content, and shelf life.
- **Safety requirements.** What the product must not contain, what testing you require, and what warnings must appear on the label. For anything a pet eats, flag allergen and ingredient safety explicitly and plan to consult a veterinarian or qualified animal nutrition professional before finalising the formulation.
- **Packaging requirements.** Pack format, materials, and labelling space.
- **Quality standard.** What counts as acceptable, and what counts as a defect — broken pieces, off-colour, incorrect weight, damaged packaging.

Write the specification as if a stranger in another country had to make your product from it alone, because that is often close to what will happen. Ambiguity in a specification becomes variation in the product, and variation becomes complaints.

### Safety first, by category

- **Edibles.** Ingredient safety is non-negotiable. Some ingredients that are safe for humans are dangerous for dogs or cats — never assume. Check every ingredient against reliable veterinary guidance, keep the ingredient list short and named (no vague "meat derivatives" if you claim transparency), and plan for shelf-life and storage testing. If you are unsure about any ingredient, ask a veterinarian or qualified professional before you proceed. Do not make health claims on the pack unless you can substantiate them and they are permitted in your market.
- **Toys and chews.** Consider size relative to the intended pet: a toy small enough to be swallowed whole is a hazard. Consider materials, dyes, and small parts that can detach. Test with the intended size and strength of pet, and be honest on the pack about supervision and intended use. No toy is indestructible — say so, and say what to do when it wears out.
- **Accessories.** Check hardware strength, stitching, and any coating or dye that contacts skin or fur. Test clasps, buckles, and adjusters under load.
- **Care products.** Patch-test thinking applies: ingredients that contact skin or coat must be suitable for the species, and the label must carry clear usage and warning instructions.

Keep a safety log: every ingredient or material, its source, and the basis on which you judged it suitable. That log is part of your brand file and will matter if a customer, retailer, or regulator ever asks.

### Prototyping and feedback

Get a prototype or small sample batch, then test it with real pets and real owners — not just your own. Give testers a simple form: Did the pet use/eat it? How quickly? Any adverse reaction? Would you buy it at the stated price? What would you change? Watch the pets, not just the owners: a dog that drops a treat and walks away has given you an answer no survey can.

Run at least two feedback rounds. The first round finds the big problems. The second round confirms you fixed them without creating new ones. Do not skip the second round to save time — it is cheaper than a recall, a flood of returns, or a dead launch.

### Exercise — Module 4

Write the full product specification for your hero product and run a prototype feedback round with at least five testers outside your household. Record every piece of feedback and the change you made (or deliberately did not make) in response.

---

## Module 5 — Sourcing and Manufacturing: Finding the Right Partner

### What you will learn

- Where to find suppliers, and how to tell a good one from a risky one.
- What to ask in a first enquiry, and what a good answer looks like.
- Minimum order quantities, lead times, and samples.
- How to protect yourself: contracts, quality checks, and payment terms.

### Where to find suppliers

Start with three routes, and use at least two of them:

1. **Trade directories and trade shows.** Industry directories, trade associations, and pet trade shows let you meet manufacturers and see products in person. A face-to-face conversation at a trade show, where you can handle samples, is worth many emails.
2. **Referrals.** Ask other founders — including founders in adjacent categories who are not direct competitors — who they use and who they would avoid. A referral from a working founder is the strongest signal you will get.
3. **Online sourcing platforms.** These are useful for a long list, but treat every listing as unverified until you have checked it. Never place a large order with a supplier you found only online and have never spoken to or sampled from.

Shortlist at least five suppliers, then narrow to three for serious discussion. A single supplier is a single point of failure; three gives you comparison, a backup, and negotiating context.

### The first enquiry

Your first message to a supplier should be short, specific, and professional. Use the scripts in `templates/supplier-outreach-scripts.md`. Include: who you are, the product (attach your specification), the quantity you expect for a first order and for a re-order, your target price range if you have one, and what you need from them (sample cost and timing, minimum order quantity, lead time, certifications, and payment terms). A supplier who replies with specific answers, asks good questions about your specification, and is transparent about minimums and lead times is worth more than one who replies instantly with the lowest price and no questions.

Red flags: no business address or verifiable company details; unwillingness to send a sample; pressure to pay in full upfront by an untraceable method; prices far below every other quote with no explanation; refusal to discuss quality testing or to put terms in writing. Walk away from any of these, however attractive the price.

### Minimum order quantities, samples, and lead times

- **Minimum order quantity (MOQ).** The smallest run a supplier will make. High MOQs are the most common reason a first-time founder over-orders. Ask whether the MOQ differs by variant (flavour, colour, size) and whether a higher per-unit price buys a lower MOQ for a first run. Sometimes it does, and it is worth paying.
- **Samples.** Always order a sample before a production run, and expect to pay for it. A sample tells you about quality, finish, and whether the supplier understood your specification. Budget for two rounds of samples: the first to check the product, the second to check the corrected version.
- **Lead time.** The time from confirmed order to delivery, including production, quality checks, and shipping. Add your own buffer for customs, delays, and your own quality check on arrival. Never promise a launch date that depends on the supplier's best-case lead time.

### Comparing quotes like-for-like

Quotes are only comparable when they cover the same thing. Build a comparison table with: unit price, MOQ, sample cost, tooling or setup fees, packaging cost, shipping cost, import duties or taxes if applicable, payment terms, lead time, and what quality checks are included. The cheapest unit price often hides the most expensive total cost. The costing calculator in `templates/costing-pricing-calculator.csv` is built for exactly this comparison.

### Protecting yourself

- **Get terms in writing.** Product specification, price, MOQ, lead time, payment schedule, quality standard, and what happens if the goods are defective. Email confirmation of agreed terms counts, but a simple written agreement is better.
- **Pay in stages.** A deposit plus a balance on shipment, or payment on delivery for a first small order, is normal. Full payment upfront for a first order with a new supplier is not.
- **Inspect on arrival.** Check a sample of every delivery against your specification before you sell any of it. Count, weigh, inspect, and test. Record the results.
- **Keep a second supplier warm.** Even after you choose a primary supplier, keep the runner-up informed and order an occasional small run if you can. If your primary supplier fails, you will be glad you did.
- **Intellectual property.** Do not send your full brand assets, packaging artwork, or formulation to a supplier before you have agreed terms. Use a simple non-disclosure agreement where appropriate, and keep records of what you shared and when.

### Exercise — Module 5

Send enquiries to at least five suppliers using the outreach scripts, and complete the quote comparison table for the three best replies. Order a sample from your leading supplier before moving on.

---

## Module 6 — Costing and Pricing: Making the Maths Work

### What you will learn

- Every cost that belongs in your landed cost, including the ones founders forget.
- How to set a retail price that leaves room for wholesale, retail margin, and profit.
- How to test whether your price is viable before you commit.
- What to do when the maths does not work.

### The costs founders forget

A product that costs $2 to make does not cost $2. Your landed cost — the full cost of one unit sitting in your hands, ready to sell — includes: product cost, packaging, labelling, shipping to you, import duties and taxes where applicable, payment fees, quality-check and sample costs spread across the run, storage, and a share of any tooling or setup fees. Founders who price from the product cost alone discover too late that they lose money on every sale.

List every cost in the calculator template. If you are unsure of a figure, estimate it honestly and mark it as an estimate, then replace it with the real figure as soon as you have it. A model built on honest estimates is useful; a model built on optimistic guesses is dangerous.

### The pricing chain

Your price must survive a chain of margins. A common structure for a product sold through retail is:

- **Your landed cost** — what one unit costs you, all in.
- **Your wholesale price** — what you charge a retailer. Retailers typically expect to sell at roughly double the wholesale price, though this varies by category and channel.
- **The retail price** — what the customer pays.

If your landed cost is $4 and your retail price is $10, there is $6 to share between your margin and the retailer's margin. If the retailer takes half the retail price ($5), you are left with $1 per unit before your own marketing, fulfilment, and overhead costs — which means you are almost certainly losing money. Work the chain backwards from the retail price your customer will accept: retail price, minus retailer margin, minus your fulfilment and marketing cost per unit, must leave you a real profit. If it does not, you have three options: lower your cost, raise your price (and test whether customers still buy), or change the channel (sell direct, where you keep the retailer's margin).

A worked example with real numbers is in Worked Example B at the end of this course. Work through it with your own figures before you set your price.

### Pricing for direct sales

Selling direct — from your own store or at a market — lets you keep the full retail price, but you pay for it in customer acquisition, fulfilment, and your own time. Price direct and wholesale consistently: a retailer will not stock a product that your own website undercuts. Many brands set one retail price everywhere and offer wholesale at a fixed discount from it. That discipline protects your retail partners and your brand.

### Testing your price

Test price before you commit to a large run. The market stall, the pre-order test, and the small-batch pilot from Module 3 are also price tests. Watch where hesitation starts. If customers consistently say "I love it but it is a bit expensive," they are telling you either the price is too high or the value is not clear enough. Both are fixable, but they are fixed differently: the first by cost or price, the second by packaging, story, and demonstration.

Do not compete on being cheapest. A new brand cannot win a price war against an established manufacturer. Compete on being clearly better for your specific customer, and price for that.

### When the maths does not work

If no price your customer will pay leaves you a profit, do not launch that product at that cost. Change something real: simplify the product, change the pack size, find a cheaper supplier or material that does not compromise safety or quality, reduce the MOQ, or choose a different channel. What you must not do is launch anyway and hope volume fixes it. Volume multiplies a loss exactly as efficiently as it multiplies a profit.

### Exercise — Module 6

Complete the costing and pricing calculator for your hero product, in both a direct-sale and a wholesale scenario. Write down the retail price you will test, and the minimum margin you will accept. If the margin is below that minimum, list the three changes you will test first.

---

## Module 7 — Packaging and Labelling That Sell and Comply

### What you will learn

- What packaging has to do in the first three seconds on a shelf.
- How to design for your channel: retail shelf, online listing, or both.
- Labelling requirements and the checks that catch expensive mistakes.
- How to brief a designer and approve artwork without wasting money.

### The three-second job

On a retail shelf, your packaging has about three seconds to do three things: be noticed, be understood, and be trusted. Noticed means it stands out without shouting — a clear brand block, a readable product name, and a colour or shape that reads at arm's length. Understood means a shopper can tell what it is, who it is for, and why it is different without picking it up. Trusted means it looks like a product made by a serious brand: clean type, honest claims, no clutter, and no promises it cannot keep.

Online, the job is similar but the medium is a thumbnail. Your pack must read at small size, and your listing images must do the work the shelf does in person: show the product, show it in use, show the size, and show the label clearly.

### Designing for your channel

- **Retail shelf.** Consider the shelf: how tall is the pack, how much facing will you get, will it hang or stand, does it need a barcode that scans cleanly, and will it survive being handled? A beautiful pack that falls over or hides its own name is a failed pack.
- **Online.** Consider the unboxing: the customer opens a parcel, not a shelf. The pack must survive shipping, look good in a photo, and carry the information a buyer needs without a shop assistant to explain it.
- **Both.** Design one pack that works in both places if you can. Two different packs double your cost and your complexity.

Choose materials with the product in mind: food and treats need barrier protection against moisture and air; toys need to be visible or at least clearly illustrated; accessories need to show size and fit. Choose materials you can afford at your MOQ, and ask your supplier what pack formats they can fill or assemble — a pack your supplier cannot produce is a design exercise, not a product.

### Labelling: the expensive mistakes

Labelling errors are among the most expensive mistakes a new brand makes, because a mislabelled run often has to be reprinted or destroyed. Use the packaging and labelling checklist in `templates/packaging-labelling-checklist.md` for every artwork approval, and get a second pair of eyes on it before you print.

As a minimum, check the following for your market — and confirm the current rules with a qualified professional, because they differ by country and by product type:

- **Product identity.** The correct product name and a clear statement of what it is.
- **Net quantity.** Weight or count, in the units your market requires, correctly measured.
- **Ingredients or materials.** For edibles, a full ingredient list in descending order by weight, with allergens highlighted as required. For non-edibles, materials and any care instructions.
- **Feeding or usage instructions.** For food and treats, feeding guidance appropriate to the pet's size and age. For toys and accessories, intended use, size guidance, and supervision advice.
- **Warnings.** Choking, supervision, storage, and "not suitable for" statements where relevant. For edibles, any ingredient that requires a warning in your market.
- **Manufacturer or distributor details.** Business name and address, and a batch or lot code so a product can be traced.
- **Best-before or expiry information.** Where required, with correct date format.
- **Barcode.** Correctly generated, correctly sized, and test-scanned before print.
- **Claims.** Every claim on the pack must be true, substantiated, and permitted. "Vet approved" means a veterinarian actually approved it. "Natural" means what your market's rules say it means. "Grain-free" must be accurate. When in doubt, leave the claim off — a missing claim costs you nothing; a false one can cost you the brand.

For pet food and treats specifically, seek professional advice on the labelling rules that apply in your market before you finalise artwork, and have a veterinarian or qualified animal nutrition professional review any nutritional or feeding statement. Do not rely on what a competitor's pack says — competitors make mistakes too.

### Briefing a designer

A good brief is one page: the product, the customer, the three-second message, the mandatory label elements, the pack format and dimensions, the brand colours and typefaces, and three packs you admire and why. Give the designer your specification and your checklist, not just a mood board. Approve artwork in stages — layout first, then copy, then final print files — and check a physical proof, not just a screen, before you commit to a print run. Colours, type sizes, and barcode scannability all behave differently on paper than on screen.

### Exercise — Module 7

Complete the packaging and labelling checklist for your hero product. Draft the front-of-pack copy (product name, one-line benefit, and the three facts a shopper needs) and have someone outside the business read it cold: can they tell you what it is, who it is for, and what it costs to try?

---

## Module 8 — Building the Brand: Name, Story, and Identity

### What you will learn

- How to choose a brand name that survives contact with reality.
- How to write a brand story that is true and useful.
- The minimum identity kit you need before launch.
- How to keep the brand consistent without spending a fortune.

### Choosing a name

A good brand name is easy to say, easy to spell, easy to remember, and available. Check all four before you fall in love with it:

- **Say it aloud.** If you have to spell it every time, customers will not remember it and retailers will misfile it.
- **Search it.** Search the name as a business, a product, and a social handle. Look for conflicts in your category and your market.
- **Check the domain and handles.** You need a workable website address and consistent social handles. Exact-match is ideal; close and consistent is acceptable.
- **Check the trademark position.** You do not need a lawyer to do a first search, but you do need professional advice before you invest heavily in a name. A name that infringes an existing trademark is a liability, however good it sounds.

Avoid names that lock you into one product: a brand called "Salmon Bites" cannot credibly sell a toy later. Choose a name that fits the brand you want in three years, not only the product you launch with. And avoid names that make a claim you cannot support — a name that promises a health outcome will be read as a claim.

### Your brand story

Your story is not your biography. It is the true, short answer to "Why does this brand exist, and why should I trust it?" A useful brand story has three parts:

1. **The problem you saw.** A real observation, in plain language. "I could not find a soft training treat small enough for my puppy that did not upset her stomach."
2. **What you did about it.** The work: the research, the testing, the formulation or design, the samples, the failures. Specificity builds trust; vagueness destroys it.
3. **What you promise now.** One clear promise, kept on every pack and every listing. Not five promises — one.

Write the story in under 150 words. If it needs more, it is not a story yet, it is a history. Use it on your website, in your pitch deck, and in your retailer conversations — the same story, told the same way, every time.

### The minimum identity kit

Before launch you need: a logo that works in one colour and at small size; two typefaces at most (one for headings, one for body); a colour palette of three to five colours with exact values; a pack design; and a one-page brand sheet that shows all of these together with your story and your promise. That is enough. You do not need a 40-page brand guideline before your first sale. Build the kit, use it consistently, and refine it after launch based on what customers actually respond to.

Consistency is the cheapest form of branding there is. The same logo, the same colours, the same voice, on the pack, the website, the market stall, and the pitch deck — repeated until customers recognise you without reading your name. Inconsistency, by contrast, makes every touchpoint feel like a different brand.

### Voice

Write the way you would speak to a customer in a good independent pet store: warm, knowledgeable, plain, and honest. Avoid jargon, avoid hype, and never talk down to the owner or sentimentalise the pet. If a sentence would embarrass you to say to a customer face to face, do not put it on a pack or a website.

### Exercise — Module 8

Shortlist three names, check each for sayability, search conflicts, domain and handle availability, and write your 150-word brand story. Build the one-page brand sheet and use it to check your packaging draft from Module 7 for consistency.

---

## Module 9 — Launching Online: Your Store, Marketplaces, and Content

### What you will learn

- How to choose your first online channel — and why one is enough.
- What a good product listing contains.
- How to use content to sell without shouting.
- How to handle reviews, questions, and complaints.

### One channel first

New founders try to be everywhere at once: their own store, two marketplaces, and four social accounts. The result is five half-finished channels and no learning. Pick one primary online channel for launch, based on where your Module 2 customer actually shops:

- **Your own store** gives you control, customer data, and full margin, but you must bring the traffic yourself.
- **A marketplace** gives you traffic and trust, but takes a fee and controls the customer relationship.
- **Social selling** works when your product is visual and your customer already follows accounts like yours, but it is a slow build.

One primary channel, done well, plus one supporting social account where you post consistently, is a launch plan. You can add channels after you know what sells and why.

### The product listing

A good listing answers, in order, the questions a buyer asks: What is it? Who is it for? What is in it / made of? How big is it? How do I use it? What does it cost, including delivery? What happens if it is not right? Write the listing for a buyer who will never speak to you. That means:

- A clear title with the product type, the pet, and the key benefit — not a clever title that hides what it is.
- At least four images: the pack front, the product itself, the product in use, and the size (shown against a common object or with dimensions).
- The full ingredient or materials list, feeding or usage instructions, and warnings — the same information as the pack, not less.
- Honest delivery information: how long it takes, what it costs, and where you ship.
- A returns policy you can actually honour.

Photography matters more than copy. Use natural light, a clean background, and real pets using the product where possible. A single honest photo of a dog enjoying a treat outsells a paragraph of adjectives.

### Content that sells

Content for a pet brand is not advertising; it is evidence. Show the product being made, tested, packed, and used. Show the pets. Answer the questions customers actually ask: "Is it suitable for puppies?" "How long does it last?" "What is in it?" Post consistently — three times a week beats thirty posts in one week followed by silence — and reply to every comment and message promptly. A brand that answers is a brand that can be trusted.

Do not buy followers, do not make claims you cannot support, and do not use another brand's images or a customer's pet photo without permission. Keep a simple content calendar in your workbook: the week's theme, the three posts, and the one question you will answer.

### Reviews, questions, and complaints

Ask every buyer for a review, and make it easy: a short message after delivery with a direct link. Thank people for positive reviews by name. For a negative review, reply promptly, politely, and publicly with what you will do — then do it. A handled complaint, visible to other shoppers, builds more trust than a page of five-star reviews. Never fabricate reviews, never pay for fake reviews, and never ask a reviewer to remove an honest negative review in exchange for a refund. Keep records of any product issue a customer reports, and act on patterns: three reports of the same problem are a product issue, not three difficult customers.

### Exercise — Module 9

Write the full listing for your hero product — title, description, images list, and policies — and publish it on your chosen primary channel, or draft it in full if your product is not yet ready to sell. Plan your first four weeks of content.

---

## Module 10 — Getting Into Retail: The Pitch, the Buyer, and the Terms

### What you will learn

- Which retailers to target first, and in what order.
- How a retail buyer thinks, and what they need from you.
- How to build and deliver a pitch deck.
- How to negotiate terms without giving the business away.

### Which retailers first

Start with independent pet stores, not national chains. An independent buyer can say yes in one conversation, will give you feedback, and will tell you quickly whether the product sells. A national chain buyer manages hundreds of suppliers, needs volume you may not have, and moves slowly. Your first ten retail targets should be independents within reach — stores you can visit, whose customers match your Module 2 profile, and whose shelves have a visible gap your product fills.

Visit each target store before you pitch. Note what they stock in your category, what price points they carry, how much shelf space your competitors get, and whether the staff recommend products or just stock them. A pitch that shows you have actually been in the store — "I noticed you carry X and Y but nothing at this price point for small-breed puppies" — is worth more than a generic deck.

### How a buyer thinks

A retail buyer is not buying your product because they like it. They are buying it because they believe it will sell through at a profit, without creating problems. Their questions, in order, are: Will my customers buy this? At what price? What margin do I make? How fast will it sell? What happens if it does not sell? What support will you give me — samples, display material, staff information? Answer those questions before they ask them, and you will stand out from most founders, who pitch the product and forget the retailer's business.

Bring the evidence: your validation results, your sell-through from your online channel or market stall, your reviews, and your pricing chain from Module 6. A buyer who sees that a product already sells somewhere is taking a much smaller risk than one being asked to be the first.

### The pitch deck

Your deck is ten slides at most, using the template in `templates/retail-pitch-deck.md`:

1. The brand and the product, in one line.
2. The customer and the problem.
3. The product: what it is, what is in it, and why it is different.
4. The evidence: validation, sales, reviews.
5. Pricing: retail price, wholesale price, and the retailer's margin.
6. The range: pack sizes, variants, and what comes next.
7. Support: samples, display, staff information, and marketing.
8. Logistics: MOQ, lead time, delivery, and payment terms.
9. Terms: what you are asking for — a trial order, a number of stores, a shelf position — and what you offer if it does not sell through.
10. The ask and the next step, with your contact details.

Keep each slide to one idea and one visual. The deck is a leave-behind; the pitch is a conversation. Rehearse it aloud until you can deliver it in ten minutes without reading it.

### Terms: what to expect and what to protect

Common retail terms you will meet include: wholesale discount (the difference between retail and wholesale price), payment terms (for example, payment within 30 days of delivery), a trial or sale-or-return arrangement for a first order, and promotional support (a discount or display for launch). Negotiate calmly and in writing. Do not agree to terms you cannot meet — a large first order with 60-day payment terms can break a small brand's cash flow even if the product sells well. It is better to start with a small trial in a few stores, prove sell-through, and grow from there than to accept an order that puts the business at risk. A worked pitch example is in Worked Example C.

Never promise a retailer exclusivity you cannot honour, or a sales volume you have not evidenced. If a buyer asks for something you cannot do, say so plainly and offer what you can do instead. Buyers respect a founder who knows their numbers and their limits.

### Exercise — Module 10

List ten target retailers, visit or research each one, and complete the pitch deck for your hero product. Pitch the first three, in person or by appointment, and record the outcome and the feedback from each.

---

## Module 11 — Operations: Inventory, Fulfilment, and Cash Flow

### What you will learn

- How much stock to order, and when to reorder.
- How to fulfil orders reliably, direct and wholesale.
- How to manage cash flow so growth does not break the business.
- How to handle returns, defects, and complaints operationally.

### How much stock to order

Order from demand, not from optimism. Your first production order should be the smallest quantity that (a) meets your supplier's MOQ, (b) covers your validated pre-orders plus a modest buffer for your launch channel, and (c) you can afford to hold if sales are slower than hoped. A common first-timer mistake is ordering six months of stock to get a better unit price, then discovering the product needs a change and the stock is unsellable. A slightly higher unit price on a smaller first run is usually the cheaper lesson.

Set a reorder point: the stock level at which you place the next order, calculated from your sales rate and your supplier's lead time. If you sell 20 units a week and your lead time is four weeks, you need to reorder when you have at least 80 units left, plus a buffer — not when you have 10 left. Track sales weekly, in a simple sheet, from day one. Memory is not inventory control.

### Fulfilment

Whether you fulfil orders yourself or use a third party, the customer experience is the same: the right product, undamaged, on time, with clear communication. Pack carefully — pet food and treats need protection from moisture and crushing; toys and accessories need protection from scuffing — and include a packing note with usage information and your contact details. Confirm dispatch, provide tracking where possible, and respond quickly if a parcel is delayed or damaged. For wholesale orders, confirm the delivery date in writing, pack to the retailer's requirements, and include the paperwork they need (invoice, batch code, and any certificates).

### Cash flow

Cash flow, not profit on paper, is what keeps a small brand alive. You pay your supplier before you are paid by the retailer; you pay for packaging and shipping before the customer buys. Map your cash cycle: money out (deposit, balance, shipping, packaging) against money in (direct sales immediately, wholesale sales on the buyer's payment terms). Keep a cash reserve for one reorder cycle, and do not spend launch revenue on the next product until the first product's cycle is funded. Review your bank balance and your outstanding orders weekly. A simple weekly cash check — money in, money out, money owed to you, money you owe — will catch most problems before they become crises.

### Returns, defects, and complaints

Have a written returns policy and honour it. Inspect returned products, record the reason, and look for patterns. A single defect is a one-off; a repeated defect is a supplier or design problem that needs fixing at source. Keep a complaints log with the date, the product batch, the issue, and what you did. If a safety issue is ever reported — a pet becomes unwell, a toy breaks into a hazardous piece — take it seriously immediately, stop selling the affected batch if there is any doubt, and seek veterinary and professional advice promptly. Customer safety comes before sales, always.

### Exercise — Module 11

Set your reorder point and your weekly tracking sheet. Write your returns policy and your complaints log format. Map your cash cycle for your first order, from deposit to final payment received.

---

## Module 12 — Growing the Brand: Line Extensions, Wholesale, and What Comes Next

### What you will learn

- When to extend the range, and when to hold.
- How to grow wholesale without losing control.
- How to decide whether to stay small and profitable or scale.
- How to keep learning from your customers.

### When to extend

Extend when your hero product has proven three things: it sells repeatedly, it sells profitably, and customers ask for the next thing. The most common next step is the lowest-risk one: a second flavour, size, or colour of the same product, using the same supplier and the same channel. It reuses everything you have learned and everything you have built. A new category — from treats to toys, for example — is a new business in miniature, with a new specification, new supplier, and new safety questions. Do it when the hero product funds it, not before.

Before any extension, repeat Modules 3, 4, and 6 for the new product, at least in abbreviated form: validate demand, write the specification, and redo the costing. An extension that skips validation is a gamble with the profits of the product that works.

### Growing wholesale

Grow wholesale in rings: your first independents, then more independents in nearby areas, then small regional groups, then — only when your supply, cash flow, and operations can support it — larger accounts. Each ring teaches you something: the first ring teaches you sell-through, the second teaches you logistics, the third teaches you whether your brand travels beyond your home market. Keep visiting stores, keep talking to buyers, and keep tracking sell-through by store. A store that stocks you but does not sell through is not a success — it is stock sitting on a shelf that will eventually be returned or discounted.

Support your retailers as you grow: staff information sheets, samples for staff to try with their own pets, simple display material, and a reliable contact who answers quickly. Retailers promote the brands that make their job easy.

### Stay small or scale?

Not every brand should scale. A small, profitable brand with one or two products, sold direct and through a handful of good independents, can be an excellent business — and a sustainable one. Scaling means more stock, more cash tied up, more suppliers, more staff or outsourcing, and more risk. Decide deliberately: what does success look like for you in three years — a business you run yourself, or a business with a team? Neither answer is wrong, but drifting into scale without choosing it is how founders lose control of a brand they built.

Whatever you choose, keep the discipline this course taught you: validate before you spend, cost before you price, check before you ship, and listen to customers before you decide.

### Keep learning

Your customers will keep teaching you if you keep asking. Review your reviews monthly, talk to five customers a month, visit your retailers quarterly, and revisit your scorecard every six months. The market, the regulations, and your customers will change. A brand that keeps learning stays relevant; a brand that stops learning becomes a snapshot of the year it launched.

### Exercise — Module 12

Write your 12-month plan: which product, if any, you will extend to; how many retail accounts you will target and in what order; and what "success" means for you at month 12, in numbers you can measure.

---

## Worked Example A — The Validation Scorecard, Worked Through

**The idea:** "PupStart" — soft, single-protein training treats for small-breed puppies, sold in 100 g resealable pouches at a retail price of $8.50.

**The founder's evidence:** ten conversations with owners of small-breed puppies at two training classes and one independent pet store; a landing page that drew 240 visitors from a local pet group and a training-class flyer, with 14 email signups; a market stall that sold 22 pouches in one Saturday at $8.50, with 6 buyers leaving their email for reorders.

| # | Criterion | Score (0–3) | Evidence |
|---|-----------|-------------|----------|
| 1 | Clear customer | 3 | Small-breed puppy owners, first-time owners, training-class attendees — named and reachable. |
| 2 | Painful problem | 2 | Owners said existing treats were too large, too hard, or upset stomachs; the problem is real but not urgent for every owner. |
| 3 | Willingness to pay | 3 | 22 pouches sold at $8.50 in one day; no buyer haggled; 6 left emails for reorders. |
| 4 | Repeat purchase | 3 | Training treats are used daily; a 100 g pouch lasts about a week for a puppy in training. |
| 5 | Reachable channel | 2 | Training classes and one independent store are reachable; online reach is untested. |
| 6 | Defensible difference | 2 | Single protein + soft texture + small size is a real combination, but a competitor could copy it; the defence is brand and consistency. |
| 7 | Supplier feasibility | 2 | Two suppliers quoted; MOQ 500 pouches; samples acceptable but one supplier's texture was too hard. |
| 8 | Safety and compliance feasibility | 2 | Short ingredient list; a veterinarian reviewed the formulation concept and flagged one ingredient to replace; labelling rules confirmed as manageable with professional advice. |
| 9 | Margin feasibility | 2 | Landed cost $3.40, retail $8.50 — margin works direct and at wholesale (see Worked Example B). |
| 10 | Founder fit | 3 | Founder owns a small-breed puppy, attends the training classes, and enjoys the in-person selling. |
| | **Total** | **24 / 30** | No criterion at 0. |

**Decision:** Go — with conditions. Proceed to a small-batch pilot of 500 pouches, sold through the training classes, the independent store, and a simple online listing. Re-score after the pilot. Note what the scorecard did: it did not say "this idea is brilliant." It said the evidence, taken together, supports a small, reversible next step. That is what a scorecard is for.

---

## Worked Example B — Costing and Pricing With Real Numbers

**The product:** PupStart training treats, 100 g pouch. First production run: 500 pouches.

**Costs for the run:**

| Cost item | Amount |
|---|---|
| Product cost (500 × $1.90 per pouch, made) | $950.00 |
| Pouches and labels (500 × $0.55) | $275.00 |
| Shipping from supplier to founder | $120.00 |
| Sample costs for this run (two rounds) | $85.00 |
| Payment and transaction fees on supplier payment | $32.00 |
| Storage (share of a month's shelf space, estimated) | $25.00 |
| **Total cost of the run** | **$1,487.00** |
| **Landed cost per pouch** | **$2.97** |

Note what is included and what is not: the founder's time is not in the landed cost, and neither is marketing. Those are real costs too, and the founder tracks them separately — but the per-unit maths must work before those are added, or it will never work after.

**Pricing:**

| | Direct sale | Wholesale |
|---|---|---|
| Retail price | $8.50 | $8.50 |
| Wholesale price (retailer pays) | — | $4.75 |
| Revenue per pouch to founder | $8.50 | $4.75 |
| Landed cost per pouch | $2.97 | $2.97 |
| Fulfilment / delivery cost per pouch | $1.10 (postage and mailer, direct) | $0.35 (delivery share, wholesale) |
| Gross margin per pouch | $4.43 | $1.43 |
| Gross margin % on revenue | 52% | 30% |

**Reading the numbers:** Direct sales are comfortably profitable. Wholesale, at a $4.75 wholesale price, leaves $1.43 per pouch before marketing and overhead — thin, but workable if wholesale volume is steady and the founder's marketing cost per wholesale pouch is low. If the retailer expected a larger margin and the wholesale price had to fall to $4.25, the margin would be $0.93 per pouch — too thin to sustain. That is the decision the numbers force: either hold the wholesale price and accept fewer, better retail partners, or reduce the landed cost (a larger run, a cheaper pouch, a closer supplier) before chasing wholesale volume. The founder chose to hold the price, launch direct and in two independents, and revisit wholesale pricing after the second run, when a larger order would bring the product cost down. That is the maths doing its job: it turned a vague hope ("wholesale will be good for us") into a specific, testable decision.

**Your turn:** Replace every figure above with your own, using the calculator template. If any line is an estimate, mark it, and replace it with the real figure as soon as you have it.

---

## Worked Example C — A Retail Pitch, Start to Finish

**The founder:** PupStart, after a 500-pouch pilot that sold through in five weeks across two training classes and one independent store, with 18 repeat buyers.

**The target:** An independent pet store, 20 minutes away, that stocks premium treats but has nothing specifically for small-breed puppies.

**Before the visit:** The founder visited the store twice as a customer, noted the treat shelf (three brands, $7–$11, no small-breed-specific product), and spoke briefly with a staff member about what puppy owners ask for. The founder prepared the ten-slide deck, printed a one-page sell sheet, and brought six sample pouches — three for the buyer, three for staff to try with their own dogs.

**The pitch (ten minutes):**

1. "PupStart is a soft, single-protein training treat made for small-breed puppies."
2. "Puppy owners at training classes told us existing treats are too big, too hard, or upset sensitive stomachs. We heard it ten times before we made anything."
3. The founder showed the pouch, opened it, and let the buyer see and smell the treats, and explained the short ingredient list.
4. "We sold 500 pouches in five weeks — 22 at a market stall in one day, the rest through classes and one store — and 18 customers have already reordered."
5. "Retail price $8.50, wholesale $4.75. That is a 44% margin for you on the retail price, and the pouch turns over weekly for a puppy in training."
6. "One product, one size to start, with a second flavour planned once this one proves itself here."
7. "We provide a staff information sheet, samples for your team, and a small shelf display card. We will also list your store on our website."
8. "Minimum order 24 pouches, delivery within a week, payment within 30 days."
9. "We are asking for a trial: 24 pouches on one shelf, for four weeks. If they have not sold through, we will take back the unsold stock."
10. "Can we start with 24 pouches next week? Here is my card and the sell sheet — the order form is on the back."

**The outcome:** The buyer agreed to the 24-pouch trial. The founder followed up by email the same day, confirming the terms in writing, and delivered the following week with the display card and staff sheets. Four weeks later, 21 of 24 pouches had sold, and the buyer reordered 48. The pitch worked not because it was slick, but because every claim was backed by evidence the founder could show, the terms were specific, and the risk to the retailer was small and explicit.

**What to copy from this example:** the preparation, the evidence, the specific terms, and the small, reversible ask. What not to copy: the numbers — yours will be different, and they must be yours.

---

## Your 90-Day Launch Plan

**Days 1–14: Decide and validate.** Complete Modules 1–3. Finish your customer profile, competitor map, and scorecard. Run at least two validation tests.

**Days 15–30: Design and source.** Complete Modules 4–5. Write your specification, contact five suppliers, order samples, and choose your primary supplier.

**Days 31–50: Cost, price, and package.** Complete Modules 6–8. Finish the calculator, set your test price, complete the packaging checklist, and build your brand sheet.

**Days 51–70: Build the sales channel.** Complete Module 9. Write your listing, photograph the product, and plan your first four weeks of content.

**Days 71–90: Sell, pitch, and learn.** Complete Modules 10–11. Sell your pilot batch, pitch your first three retailers, track every sale weekly, and re-score your validation scorecard with real sales data. Then read Module 12 and write your 12-month plan.

If a stage takes longer, let it. A launch delayed by two weeks because the samples were wrong is a launch saved. A launch rushed past a failed validation test is money spent on a lesson you already had.

---

## Final Checklist: Shelf-Ready

Before you call your brand shelf-ready, confirm each of these is true:

- [ ] Customer profile and competitor map completed, from real evidence.
- [ ] Validation scorecard scored at 22 or above, with no 0 on willingness to pay, safety, or margin.
- [ ] Product specification written and shared with your supplier.
- [ ] Samples approved after two rounds, and a safety review completed for any edible product with a veterinarian or qualified professional.
- [ ] Landed cost calculated, retail and wholesale prices set, and margins checked in both channels.
- [ ] Packaging and labelling checklist completed and artwork proofed on paper.
- [ ] Brand name checked, brand story written, identity kit built.
- [ ] Online listing written and live, or fully drafted with photography ready.
- [ ] Pitch deck completed and three retailers identified.
- [ ] Reorder point set, weekly tracking started, returns policy written.
- [ ] Cash cycle mapped and a reserve held for one reorder.

When every box is ticked, you are not guessing any more. You have a validated product, a supplier, a price that works, packaging you can stand behind, and a pitch a buyer can say yes to. That is what shelf-ready means.

*Good luck — and build it properly. The pets, and their owners, will notice.*
