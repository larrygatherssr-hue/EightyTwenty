# Welcome — Pet Product Brand Builder

Thank you for purchasing **Pet Product Brand Builder: From Idea to Shelf-Ready Brand**. This guide tells you what you have, what to do first, and how to work through the course.

## What You Received

| File | What it is |
|------|-----------|
| `content.md` | The full course — 12 modules, three worked examples, a 90-day launch plan, and a shelf-ready checklist. Start here. |
| `workbook.md` | Your companion workbook — exercises for every module, conversation and feedback logs, supplier and retail trackers, and a weekly sales tracker. |
| `templates/product-validation-scorecard.md` | Score your idea on 10 criteria, with go / no-go thresholds. |
| `templates/costing-pricing-calculator.csv` | Costing and pricing calculator (spreadsheet) with a supplier quote comparison. |
| `templates/supplier-outreach-scripts.md` | Six supplier scripts: first enquiry, follow-up, sample request, negotiation, order confirmation, quality problem. |
| `templates/packaging-labelling-checklist.md` | Full packaging and labelling checklist for every artwork approval. |
| `templates/retail-pitch-deck.md` | Ten-slide retail pitch deck template with a post-pitch follow-up guide. |
| `sales-page.md` | The full sales page for this product (for your reference). |
| `cover.png` | The product cover image (black-and-gold). |
| `cover.md` | The cover design brief. |
| `listing.json` | The marketplace listing data for this product. |
| `README.md` | Index of all files. |

## What to Do First

1. **Read the "How to Use This Course" section** at the top of `content.md` (5 minutes). It explains the five assets you will finish with and the safety note — read the safety note carefully, especially if your product is a food or treat.
2. **Print or copy the workbook** (`workbook.md`) and the five templates. These are working documents — you will fill them in as you go, and together they become your brand file.
3. **Do not skip ahead to sourcing or packaging.** The course is designed in order for a reason: validation (Module 3) comes before spending, and costing (Module 6) comes before pricing. Skipping ahead is how founders waste money.
4. **Set your schedule.** The course is designed for 6–12 weeks. Pick your pace now and put the module dates in your calendar (see the suggested schedule below).

## Suggested Schedule

**Pace A — one module per week (alongside other commitments, ~12 weeks):**

| Week | Module | Deliverable |
|------|--------|-------------|
| 1 | 1 — Landscape | One-paragraph market description |
| 2 | 2 — Niche and customer | Customer profile, competitor map, positioning statement |
| 3 | 3 — Validation | Two validation tests + completed scorecard |
| 4 | 4 — Product design | Product specification + prototype feedback |
| 5 | 5 — Sourcing | Five supplier enquiries, three quotes compared, sample ordered |
| 6 | 6 — Costing and pricing | Completed calculator, test price set |
| 7 | 7 — Packaging and labelling | Checklist completed, front-of-pack copy drafted |
| 8 | 8 — Brand | Name chosen, story written, identity kit built |
| 9 | 9 — Online launch | Listing written, photography done, content planned |
| 10 | 10 — Retail | Pitch deck completed, first three retailers pitched |
| 11 | 11 — Operations | Reorder point, tracking, returns policy, cash cycle mapped |
| 12 | 12 — Growth | 12-month plan written; re-score the validation scorecard with real sales data |

**Pace B — two modules per week (focused time, ~6 weeks):** combine Weeks 1–2, 3–4, 5–6, 7–8, 9–10, and 11–12 above. Do not combine the validation and sourcing weeks — give validation the full time it needs before you contact suppliers.

## How to Use the Materials

- **Work the exercises.** Each module ends with an exercise. The course only works if you do them — reading without doing is just reading.
- **Keep everything in one place.** Your completed workbook, scorecard, calculator, scripts, checklists, and pitch deck are your brand file. Keep the completed versions together and bring them to supplier and buyer conversations.
- **Replace example figures with your own.** The worked examples use illustrative figures for a fictional-style product idea. They show you how the methods work. Your supplier quotes, costs, and prices will be different — use the templates with your own numbers.
- **Re-score after your pilot.** Once you have real sales, re-score the validation scorecard with sales data instead of estimates. That second score is the one to trust.

## A Note on Safety

If your product is a food, treat, chew, or anything a pet eats or puts in its mouth: take ingredient safety, manufacturing standards, and labelling rules seriously from day one. Consult a veterinarian or a qualified animal nutrition professional before finalising any edible formulation, and consult a qualified professional about the regulations that apply in the markets where you intend to sell. This course is educational material — it does not replace veterinary, legal, or regulatory advice, and it does not replace veterinary care for any pet.

## How to Get Support

- **Order, delivery, or guarantee questions:** contact EightyTwenty marketplace support through the marketplace help or contact page, quoting your order number and the product SKU **PET-09**. Support replies within two business days.
- **Guarantee:** 14-day money-back guarantee. If you work through the first three modules and decide the course is not for you, contact support within 14 days of purchase. See the refund policy in the marketplace listing for the full terms.
- **Content questions:** include the module number in your message so support can direct it correctly. This product does not include one-to-one coaching, veterinary advice, or legal advice.

## Your First Step — Today

Open `content.md`, read Module 1, and complete Exercise 1 in the workbook. That is all. One module, one exercise, one deliverable — then the next.
