# Packaging and Labelling Checklist

Complete this checklist for every artwork approval, and have a second person check it before you print. A labelling error on a printed run is expensive — this checklist exists to catch it while it is still free to fix.

**Product:** _______________________________________________
**Pack format / size:** _______________________________________________
**Artwork version / date:** _______________________________________________
**Checked by:** ______________________ **Second check by:** ______________________

*Important: labelling rules differ by country and by product type. Confirm the current rules for your market with a qualified professional before finalising artwork. This checklist is a working aid, not legal advice.*

## Front of Pack

- [ ] Product name is correct, spelled correctly, and readable at arm's length
- [ ] Product type is immediately clear (what it is — treat, toy, collar, etc.)
- [ ] Target pet is clear (species, size, age where relevant)
- [ ] The one-line benefit is true and substantiated
- [ ] No claim appears that you cannot support ("vet approved", "natural", "grain-free", health claims — verify each one, and remove any you cannot substantiate)
- [ ] Net quantity is shown correctly and prominently
- [ ] Brand name and logo are correct and consistent with your brand sheet
- [ ] Colours and type match the brand palette; text is legible against the background
- [ ] No spelling or grammar errors (checked by a second person)

## Back / Side of Pack

- [ ] Full ingredient list (edibles) in descending order by weight — complete, with no ingredient omitted
- [ ] Allergens highlighted as required in your market
- [ ] Materials listed (non-edibles), including any care instructions
- [ ] Feeding guidance (food/treats) — appropriate to pet size and age, and reviewed by a veterinarian or qualified animal nutrition professional
- [ ] Usage instructions (toys/accessories/care) — clear, including size guidance
- [ ] Warnings present where relevant: supervision, choking / small parts, "not suitable for" statements, storage instructions
- [ ] Best-before / expiry date and batch (lot) code space included, with correct date format
- [ ] Business name and address (manufacturer and/or distributor, as required in your market)
- [ ] Country of origin, if required in your market
- [ ] Barcode present, correctly generated, correctly sized, and test-scanned from a printed proof
- [ ] Website / contact details correct

## Edibles — Extra Checks

- [ ] Every ingredient checked for safety for the target species; any ingredient you were unsure about was checked with a veterinarian or qualified professional (record who and when)
- [ ] No ingredient that is known to be unsafe for dogs or cats is present
- [ ] No health or nutritional claim appears unless substantiated and permitted in your market
- [ ] Feeding guidance does not overstate how much of the product should be fed
- [ ] Shelf-life and storage instructions are correct for the product

## Physical Pack Checks (from a printed proof)

- [ ] Proof checked on paper, not only on screen
- [ ] Colours match expectations; type sizes are readable at the intended size
- [ ] Pack stands / hangs correctly and does not fall over on a shelf
- [ ] Pack survives handling and (for online) shipping without damage to the label
- [ ] Barcode scans from the printed proof
- [ ] Pack size and weight are correct; the product fits as intended

## Before You Print

- [ ] Artwork approved in stages (layout, then copy, then final print files)
- [ ] Print quantity confirmed against your order quantity — do not over-print labels for a product that may change
- [ ] Supplier confirms they can fill / assemble this pack format
- [ ] Final file backed up with version and date in the filename

## Notes / Issues Found

| Issue | Found by | Action | Resolved? |
|-------|----------|--------|-----------|
| | | | |
| | | | |
| | | | |

**Sign-off:** I confirm the checks above are complete and the artwork is approved to print.
Signature / name: ______________________ Date: ______________________
