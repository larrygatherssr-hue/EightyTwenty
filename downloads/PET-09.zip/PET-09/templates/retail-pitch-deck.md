# Retail Pitch Deck Template

**Brand:** ______________________ **Product:** ______________________ **Date:** ______________________
**Pitching to:** ______________________ (store / buyer name)

Keep the deck to ten slides. One idea per slide, one visual per slide. The deck is a leave-behind — the pitch is a conversation. Rehearse it aloud until you can deliver it in ten minutes.

---

## Slide 1 — The Brand and the Product

One line: what the brand is, and what the product is.

> Example: "PupStart is a soft, single-protein training treat made for small-breed puppies."

Visual: the product pack, clean and large.

---

## Slide 2 — The Customer and the Problem

Who the customer is, and the problem in their own words.

- Customer: ______________________
- Problem (quote or paraphrase from real conversations): ______________________
- How many customers told you this: ______________________

Visual: a photo of the target pet / owner using the product, or a simple quote card.

---

## Slide 3 — The Product

What it is, what is in it (or made of), and why it is different.

- What it is: ______________________
- Ingredients / materials: ______________________
- What makes it different: ______________________
- Size / pack / variants: ______________________

Visual: the product itself, and the label / ingredient list.

*For edibles: note that the formulation was reviewed by a veterinarian or qualified professional, if that is true — and only if it is true.*

---

## Slide 4 — The Evidence

Proof it already sells. Use real numbers only.

- Units sold to date: __________
- Where: __________
- Repeat buyers: __________
- Reviews (number and summary): __________
- Pre-orders / waitlist: __________

Visual: a simple chart or three key numbers, large.

*Do not invent figures. If you have no sales yet, show validation results honestly and say so.*

---

## Slide 5 — Pricing and Margin

| | Amount |
|---|---|
| Retail price | $__________ |
| Wholesale price | $__________ |
| Retailer margin ($ and %) | $__________ (____%) |
| Recommended shelf position / companions | ______________________ |

Visual: the pricing chain as a simple diagram.

---

## Slide 6 — The Range

What you are offering now, and what comes next.

- Launch product(s): ______________________
- Pack sizes / variants: ______________________
- Next product (and when, honestly): ______________________

---

## Slide 7 — Support for the Retailer

What you will provide to help it sell:

- [ ] Staff information sheet
- [ ] Samples for staff to try with their own pets
- [ ] Shelf display card / point-of-sale material
- [ ] Listing on your website as a stockist
- [ ] Social media mention on launch
- [ ] Other: ______________________

---

## Slide 8 — Logistics

- Minimum order: __________ units
- Lead time: __________ (from order to delivery)
- Delivery: ______________________
- Payment terms: ______________________
- Reorder process: ______________________

---

## Slide 9 — Terms and the Trial

What you are asking for, and what you offer if it does not sell through.

- The ask: ______________________ (e.g., "A trial of 24 pouches on one shelf for four weeks.")
- If it does not sell through: ______________________ (e.g., "We will take back unsold stock.")
- Exclusivity offered: ______________________ (do not offer exclusivity you cannot honour)

---

## Slide 10 — The Ask and Next Step

- The specific ask, repeated in one sentence: ______________________
- Next step and date: ______________________
- Your name, email, phone, website: ______________________

Attach a one-page sell sheet with the same information, and leave sample product for the buyer and staff.

---

## After the Pitch

- Follow up by email the same day, confirming the terms in writing.
- Record the outcome and the buyer's feedback in the workbook (Exercise 10).
- If the answer is no, ask what would have to change for it to be a yes — and write the answer down.
