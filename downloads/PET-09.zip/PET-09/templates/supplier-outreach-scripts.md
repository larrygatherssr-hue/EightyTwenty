# Supplier Outreach Scripts

Use these scripts as starting points — adapt the bracketed details to your product, and attach your product specification to every enquiry. Keep a copy of every message you send and every reply you receive in your brand file.

---

## Script 1 — First Enquiry (email)

**Subject:** Enquiry — [product type] manufacturing, first order [quantity] units

Hello [Supplier name / team],

My name is [your name], and I run [brand name], a new pet product brand based in [city / country]. I am looking for a manufacturing partner for [product — e.g., soft single-protein training treats for small-breed puppies, 100 g pouches].

I have attached a product specification. In brief:
- Product: [one-line description]
- First order: [quantity] units
- Expected re-order: [quantity] units every [frequency]
- Target: [any target price range, if you have one — optional]

Could you please advise on:
1. Your minimum order quantity, and whether it differs by variant (flavour / colour / size)?
2. Sample cost and timing — I would like a sample before any production order.
3. Production lead time from confirmed order to delivery.
4. Any certifications you hold that are relevant to pet products [for edibles: food-safety / manufacturing standards].
5. Payment terms for a first order.
6. Whether you can also supply or source the packaging I have specified, or whether I should arrange that separately.

I am comparing a small number of suppliers and will be deciding by [date]. I would be glad to discuss by phone or video call if that is easier.

Thank you,
[Your name]
[Brand name] · [email] · [phone] · [website, if you have one]

---

## Script 2 — Follow-Up (if no reply in 5 working days)

**Subject:** Re: Enquiry — [product type] manufacturing

Hello [name],

I am following up on my enquiry of [date] about manufacturing [product]. I understand you may be busy — I would appreciate a brief reply, even if it is to let me know this is not a product you can make, so I can plan accordingly.

The key details: first order of [quantity] units, specification attached to my earlier email, sample required before production.

Thank you,
[Your name]

---

## Script 3 — Asking for a Sample

Hello [name],

Thank you for your reply and your quote. Before I place a production order, I would like to order a sample made to the attached specification.

Please could you confirm:
- The sample cost, including delivery to [your address].
- How long the sample will take.
- Whether the sample will be made to the full specification, including [packaging / flavour / material — name the critical detail].

Once I have approved the sample, I will confirm the production order of [quantity] units.

Thank you,
[Your name]

---

## Script 4 — Negotiating MOQ or Price (after you have two or more quotes)

Hello [name],

Thank you for your quote of [amount] per unit at a minimum of [quantity] units. I am comparing quotes from a small number of suppliers for the same specification.

For my first order, a lower minimum would help me manage cash flow while I prove sell-through. Would you consider a first order of [lower quantity] units at [proposed unit price], with a commitment to [larger quantity] on the second order if the first sells through as expected?

I am looking for a long-term manufacturing partner rather than a one-off order, so I would value terms we can both work with as volume grows.

Thank you,
[Your name]

*Only use this script when you genuinely have comparable quotes and genuinely intend to reorder. Do not invent a competing quote.*

---

## Script 5 — Confirming a Production Order (get this in writing)

Hello [name],

Thank you — I would like to confirm the production order as follows:

- Product: [product, exactly as specified in the attached specification, version/date]
- Quantity: [quantity] units, [variants and split if any]
- Unit price: [amount], total: [amount]
- Packaging: [as specified]
- Payment: [deposit amount and date] + [balance amount and trigger, e.g., on shipment]
- Lead time: [agreed lead time], delivery to [address]
- Quality standard: goods to match the approved sample and the specification; defective units to be [agreed remedy — replaced / credited].

Please confirm by reply that these terms are correct, and I will send the deposit. I will inspect the goods on arrival against the specification and approved sample before selling any of them.

Thank you,
[Your name]

---

## Script 6 — Raising a Quality Problem

Hello [name],

I have inspected the delivery of [quantity] units received on [date], order [reference]. I found the following issue(s):

- [Describe the problem precisely: e.g., 18 of 100 pouches checked were underweight at 92 g against a specified 100 g; photos attached.]

This does not match the specification / approved sample. Please could you advise how you propose to resolve this — [replacement / credit / rework] — and by when?

I value our working relationship and would like to resolve this promptly so we can proceed with the next order.

Thank you,
[Your name]

*Attach photos, weights, and counts. Keep the tone factual and professional. Record the outcome in your brand file.*

---

## Supplier Comparison Checklist

For every supplier, record the same fields so quotes can be compared like-for-like:

- [ ] Business name, address, and contact person verified
- [ ] Unit price (and what it includes / excludes)
- [ ] MOQ, and whether it differs by variant
- [ ] Sample cost and timing
- [ ] Tooling or setup fees, if any
- [ ] Packaging cost — included or separate?
- [ ] Shipping cost to you
- [ ] Import duties / taxes, if applicable
- [ ] Payment terms
- [ ] Lead time
- [ ] Quality checks included
- [ ] Relevant certifications
- [ ] References or referral source
- [ ] Red flags noted (see Module 5)
