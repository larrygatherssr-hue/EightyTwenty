# Product Validation Scorecard

**Product idea:** _______________________________________________
**Date scored:** ______________________ **Scored by:** ______________________

Score each criterion 0–3. Write the evidence for your score — a score without evidence is a guess. See Worked Example A in `content.md` for a completed example.

**Scoring guide:** 0 = no evidence / fails this test · 1 = weak or mixed evidence · 2 = good evidence with some gaps · 3 = strong, specific evidence.

| # | Criterion | What "good" looks like | Score (0–3) | Evidence |
|---|-----------|------------------------|-------------|----------|
| 1 | Clear customer | A named, reachable customer group — species, size/age, buyer type — not "pet owners". | | |
| 2 | Painful problem | Owners describe a real frustration in their own words; it matters enough to pay to solve. | | |
| 3 | Willingness to pay | People paid the real launch price (pre-orders, stall sales, pilot sales), not just said they would. | | |
| 4 | Repeat purchase | The product is used up, worn out, or needed again within weeks or months — not a one-off. | | |
| 5 | Reachable channel | You can name where the customer shops and how you will reach them there. | | |
| 6 | Defensible difference | A specific difference a competitor cannot copy in a week — formulation, fit, design, service, brand. | | |
| 7 | Supplier feasibility | At least one supplier can make it to your specification at a workable MOQ and lead time. | | |
| 8 | Safety and compliance feasibility | Ingredients/materials checked; professional advice sought where needed (veterinarian for edibles); labelling rules understood. | | |
| 9 | Margin feasibility | Landed cost and pricing chain leave a real profit in at least one channel (see costing calculator). | | |
| 10 | Founder fit | You have access to the customer, the motivation, and the time to build and sell this product. | | |
| | **TOTAL** | | **____ / 30** | |

## How to read your score

- **22 or above, with no 0s:** Reasonable "go" signal. Proceed to a small, reversible next step (small-batch pilot) and re-score after it.
- **18–21:** Promising but with gaps. Fix the lowest-scoring criteria before spending on stock.
- **Below 18, or any 0 on willingness to pay, safety, or margin:** Stop and rethink. Change the product, the price, or the customer — do not launch and hope.
- **Any 0 on safety (criterion 8):** Do not proceed until the safety question is resolved with qualified professional advice. No score elsewhere compensates for an unresolved safety issue.

## Decision

Total: ______ / 30 · Lowest criteria: ______________________
Decision (go / fix and re-score / rethink / stop): ______________________
Next step and date: ______________________
Re-score date (after pilot): ______________________
