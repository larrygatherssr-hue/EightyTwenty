# Pet Product Brand Builder — Companion Workbook

Use this workbook alongside `content.md`. Complete each exercise in order and keep the finished workbook as your brand file — the record you show a supplier, a retail buyer, or a business partner when they ask how you know your idea works.

---

## Exercise 1 — Your Market in One Paragraph (Module 1)

Category: _______________________________________________
Pet (species / size / age): _______________________________________________
Price tier: _______________________________________________
Channel: _______________________________________________

Market description (one paragraph):


Why this market is *available* to a new brand, not merely large (one sentence):


Three trends I think matter, and my answers to the three trend questions:

1. Trend: ______________________ Durable driver? __________ Changes what customers pay for? __________ Can I serve it without betting the brand on it? __________
2. Trend: ______________________ Durable driver? __________ Changes what customers pay for? __________ Can I serve it without betting the brand on it? __________
3. Trend: ______________________ Durable driver? __________ Changes what customers pay for? __________ Can I serve it without betting the brand on it? __________

---

## Exercise 2 — Customer Profile (Module 2)

Complete from evidence — conversations, observation, reviews — not imagination. Note the source for each line.

**Who they are:**


**What they buy now (brand, price, pack size, where, how often):**


**What frustrates them (exact quotes if possible):**


**What they value / what would make them switch:**


**Where they listen (stores, accounts, vets, groomers, trainers, friends):**


### Customer conversations log

Record ten conversations. For each: date, where, who (in general terms), what they buy now, what they spend, what frustrates them, exact quote worth keeping.

| # | Date / place | Customer (general) | Buys now / spends | Frustration | Quote |
|---|--------------|-------------------|-------------------|-------------|-------|
| 1 | | | | | |
| 2 | | | | | |
| 3 | | | | | |
| 4 | | | | | |
| 5 | | | | | |
| 6 | | | | | |
| 7 | | | | | |
| 8 | | | | | |
| 9 | | | | | |
| 10 | | | | | |

### Competitor map

List five closest competitors. Read at least 20 reviews per competitor.

| Competitor | Price / pack | Key ingredients or materials | Where sold | Praised for | Complained about |
|------------|--------------|------------------------------|------------|-------------|------------------|
| 1 | | | | | |
| 2 | | | | | |
| 3 | | | | | |
| 4 | | | | | |
| 5 | | | | | |

The gap no one serves well:


### Positioning statement

For ______________________, who ______________________, [Brand] is the ______________________ that ______________________, because ______________________.

---

## Exercise 3 — Validation (Module 3)

My go / no-go threshold, written BEFORE seeing results:


Validation test 1 (method, dates, result — behaviour, not opinion):


Validation test 2 (method, dates, result):


Validation test 3 (if any):


Complete the scorecard in `templates/product-validation-scorecard.md` and record the total here: ______ / 30

Decision (go / rethink / stop) and why:


---

## Exercise 4 — Product Specification (Module 4)

Product name: ______________________ Category: ______________________
Variant(s): ______________________

Dimensions / weight / pack size:


Materials or ingredients (full list):


Performance requirements:


Safety requirements (including any veterinary / professional advice sought, and when):


Packaging requirements:


Quality standard — what counts as acceptable, what counts as a defect:


### Prototype feedback log

| Tester | Pet (type/size) | Date | Did the pet use/eat it? | Owner's verdict | Would buy at stated price? | Change I will make |
|--------|-----------------|------|-------------------------|-----------------|----------------------------|---------------------|
| 1 | | | | | | |
| 2 | | | | | | |
| 3 | | | | | | |
| 4 | | | | | | |
| 5 | | | | | | |

Second-round feedback (after changes):


Safety log — ingredient/material, source, basis for judging it suitable:

| Ingredient / material | Source | Basis for suitability |
|-----------------------|--------|-----------------------|
| | | |
| | | |
| | | |

---

## Exercise 5 — Supplier Research (Module 5)

| Supplier | Contact / how found | MOQ | Unit price | Sample cost / time | Lead time | Certifications | Payment terms | Red flags? |
|----------|--------------------|-----|------------|--------------------|-----------|----------------|---------------|------------|
| 1 | | | | | | | | |
| 2 | | | | | | | | |
| 3 | | | | | | | | |
| 4 | | | | | | | | |
| 5 | | | | | | | | |

Chosen primary supplier and why:


Backup supplier:


Sample 1 result:


Sample 2 result (after corrections):


---

## Exercise 6 — Costing and Pricing (Module 6)

Complete `templates/costing-pricing-calculator.csv` and summarise here:

Landed cost per unit: $__________
Retail price (to test): $__________
Wholesale price: $__________
Direct margin per unit: $__________ (____%)
Wholesale margin per unit: $__________ (____%)
Minimum margin I will accept: $__________

If the margin is below my minimum, the three changes I will test first:
1.
2.
3.

---

## Exercise 7 — Packaging and Labelling (Module 7)

Complete `templates/packaging-labelling-checklist.md` and record the outcome here.

Front-of-pack copy:
- Product name:
- One-line benefit:
- Three facts a shopper needs: 1) __________ 2) __________ 3) __________

Cold-read test: I showed the pack to __________ on __________.
Could they tell what it is? ______ Who it is for? ______ What it costs to try? ______
What I changed as a result:


Professional advice sought on labelling rules (who, when, what they advised):


---

## Exercise 8 — Brand (Module 8)

Name shortlist and checks:

| Name | Easy to say/spell? | Search conflicts? | Domain available? | Handles available? | Trademark check done? |
|------|-------------------|-------------------|-------------------|--------------------|-----------------------|
| 1 | | | | | |
| 2 | | | | | |
| 3 | | | | | |

Chosen name and why:


Brand story (under 150 words):


Brand promise (one sentence):


Identity kit: logo ☐  typefaces ☐  colours (with values) ☐  pack design ☐  one-page brand sheet ☐

---

## Exercise 9 — Online Launch (Module 9)

Primary online channel: ______________________ Why this one: ______________________
Supporting social account: ______________________

Listing drafted ☐  Photography shot ☐  Policies written ☐

First four weeks of content:

| Week | Theme | Post 1 | Post 2 | Post 3 | Question I will answer |
|------|-------|--------|--------|--------|------------------------|
| 1 | | | | | |
| 2 | | | | | |
| 3 | | | | | |
| 4 | | | | | |

---

## Exercise 10 — Retail Pitch Practice (Module 10)

| # | Retailer | Type / location | Gap I spotted on their shelf | Contact / buyer | Date pitched | Outcome | Feedback |
|---|----------|-----------------|------------------------------|-----------------|--------------|---------|----------|
| 1 | | | | | | | |
| 2 | | | | | | | |
| 3 | | | | | | | |
| 4 | | | | | | | |
| 5 | | | | | | | |
| 6 | | | | | | | |
| 7 | | | | | | | |
| 8 | | | | | | | |
| 9 | | | | | | | |
| 10 | | | | | | | |

Pitch rehearsal notes (what felt strong, what stumbled, what I changed):


---

## Exercise 11 — Operations (Module 11)

Reorder point: __________ units (sales rate __________ / week × lead time __________ weeks + buffer __________)
Weekly sales tracking started: ☐ (date: __________)
Returns policy written: ☐
Complaints log started: ☐

Cash cycle map:
- Money out (deposit, balance, shipping, packaging): $__________ on (dates) __________
- Money in (direct sales, wholesale on terms): $__________ expected (dates) __________
- Reserve held for one reorder cycle: $__________

Complaints / returns log:

| Date | Product / batch | Issue | Action taken | Pattern? |
|------|----------------|-------|--------------|----------|
| | | | | |
| | | | | |
| | | | | |

---

## Exercise 12 — 12-Month Plan (Module 12)

Hero product performance after launch (repeat purchase? profitable? customers asking for more?):


Extension I will / will not pursue, and why:


Retail accounts targeted (in order):


What success looks like at month 12 (measurable numbers):


---

## Weekly Sales Tracker

| Week beginning | Units sold direct | Units sold wholesale | Revenue | Notes / what I learned |
|----------------|-------------------|----------------------|---------|------------------------|
| | | | | |
| | | | | |
| | | | | |
| | | | | |
| | | | | |
| | | | | |
| | | | | |
| | | | | |

---

*Keep this workbook with your scorecard, calculator, scripts, checklists, and pitch deck. Together they are your brand file.*
