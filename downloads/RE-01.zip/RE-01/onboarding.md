# Customer Onboarding Guide — The Rental Property Blueprint

Welcome — and congratulations on taking the first real step toward your first rental property. This guide tells you exactly what to do first, how to use each file, and how to work through the course in four weeks.

---

## What You Received

| File | What it is | Use it for |
|---|---|---|
| `content.md` (course manual) | The complete 16-module course | Read in order the first time; use as a reference after that |
| `workbook.md` | Companion workbook with fill-in worksheets and checklists | Do the work: buy box, deal analysis, financing comparison, screening, cash-flow planning |
| `templates/rental-deal-analyzer.csv` | Deal analyzer spreadsheet | Underwrite every property you consider |
| `templates/buy-box-worksheet.md` | Fill-in buy-box template | Define your investment criteria before you look at listings |
| `templates/tenant-screening-scorecard.md` | Screening scorecard | Screen every applicant with the same written criteria |
| `sales-page.md` | The sales page copy | Reference only — not needed for the course |
| `cover.webp` | Product cover image | Reference only |

---

## What to Do First (Day 1)

1. **Read Module 1** of the course manual. It explains how rentals build wealth — and the five ways they destroy it. Write down, in one sentence, why you want a rental property.
2. **Fill in the buy-box worksheet** (`templates/buy-box-worksheet.md`). Name your neighborhoods, set your minimum returns, and write your "will not buy" list. Do this before you look at a single listing.
3. **Open a separate savings account** labeled "Rental Reserves." This is where your capex and vacancy reserves will live. Fund it before you make your first offer.

## How to Use Each File

- **Course manual (`content.md`):** Read Modules 1–7 first — they are the analytical core. Modules 8–9 cover buying; Modules 10–13 cover tenants and maintenance; Modules 14–16 cover managing, deciding, and your first-year plan. Every module ends with action steps. Do them.
- **Workbook (`workbook.md`):** Print it or copy it into an editable document. Complete Worksheet 1 (buy box) in Week 1. Complete Worksheet 2 (deal analysis) for every property you seriously consider — aim for 20–30 before you buy. Use Worksheet 5 (12-month cash-flow planner) every month once you own a property.
- **Deal analyzer (`templates/rental-deal-analyzer.csv`):** Open it in Excel or Google Sheets. Replace the example values with your property's real numbers — the formulas calculate cash flow, cash-on-cash return, cap rate, and DSCR automatically. Verify rent with comparable rentals and taxes with the county; never trust listing numbers.
- **Buy-box worksheet:** Keep a copy with you when you talk to your agent and lender. Ask them to send you only properties that fit it.
- **Tenant-screening scorecard:** One copy per adult applicant. Apply the same criteria to every applicant, and keep completed scorecards for at least two years.

## Suggested 4-Week Schedule

**Week 1 — Learn and decide.**
Read Modules 1–4. Complete the buy-box worksheet. Add up your capital and complete the capital stack table in Module 3. Decide your financing route: conventional, FHA house hack, DSCR, or seller financing.

**Week 2 — Build your team and pipeline.**
Read Modules 5–7. Interview two investor-friendly real estate agents and two lenders; get pre-approved. Call a property manager and an insurance agent in your target market. Set up MLS alerts matching your buy box. Underwrite your first ten properties with the deal analyzer — no offers yet.

**Week 3 — Analyze and offer.**
Read Modules 8–9. Underwrite five more properties and visit three in person. Make your first offer on a property that meets your buy box, at or below your walk-away price. If it is rejected, learn from the counter and move on.

**Week 4 — Prepare to close and manage.**
Read Modules 10–13. Get a state-specific lease reviewed by a local attorney. Set up your operating and reserves accounts and an online rent collection system. Build your vendor bench (handyman, plumber, electrician, HVAC). Then follow Module 16's week-by-week plan through due diligence, closing, and your first tenant.

## A Note on the Numbers

The worked examples in this course use illustrative numbers (for example, a $185,000 duplex at 7.25% interest). Your market will differ. The method matters more than the numbers — learn the method, then plug in your market's real figures.

## How to Get Support

- **Problems with your order or the files:** Email the marketplace support address with your order number and a description of the issue, and the support team will respond.
- **14-day money-back guarantee:** If you are not satisfied within 14 days of purchase, contact support with your order number for a full refund, no questions asked.
- **Questions about your specific situation:** This course is real estate education only, not individualized investment, legal, tax, or financial advice. For advice about your situation, consult a qualified professional — a licensed real estate agent, mortgage lender, attorney, tax advisor, or financial advisor.

---

*Good luck — and remember: do not buy the first property you see, do not buy a property that loses money, and do not skip screening because a unit is vacant. Follow the process.*
