# The Rental Property Blueprint — RE-01

**Price:** $497 one-time · **Category:** Real Estate · **SKU:** RE-01

*Your first cash-flowing rental — find it, underwrite it, finance it, manage it.*

## Files in This Product

| File | Description |
|---|---|
| `content.md` | The complete 16-module course manual — full prose chapters with worked examples using real numbers, action steps at the end of every module, and a full education-only disclaimer |
| `workbook.md` | Companion workbook — buy-box worksheet, blank deal-analysis worksheets with formulas explained, financing comparison worksheet, tenant-screening scorecard, 12-month cash-flow planner, and offer / closing / move-in / monthly checklists |
| `templates/rental-deal-analyzer.csv` | Deal analyzer spreadsheet — enter a property's numbers; it calculates monthly cash flow, cash-on-cash return, cap rate, and DSCR, with formulas shown for rebuilding in Excel or Google Sheets |
| `templates/buy-box-worksheet.md` | Fill-in buy-box template — property criteria, minimum returns, deal-breakers, capital, and team contacts |
| `templates/tenant-screening-scorecard.md` | Tenant-screening scorecard — consistent, written screening criteria for every applicant |
| `sales-page.md` | Full sales page — headline, problem, solution, 16-module contents, who it is for / not for, price and 14-day guarantee, 8 FAQs, and the education-only disclaimer |
| `listing.json` | Marketplace listing data (SKU, name, category, price in cents, headline, description, delivery note, SEO keywords, refund policy, support) |
| `cover.md` | Cover design brief — black-and-gold luxury branding, typography, imagery, and layout direction |
| `cover.webp` | Generated product cover image (portrait, black-and-gold, duplex at dusk) |
| `onboarding.md` | Customer onboarding guide — what to do first, how to use each file, a suggested 4-week schedule, and how to get support |
| `README.md` | This file — index of the product's files |

## Key Facts

- **Worked example throughout:** a $185,000 duplex, $1,450/unit rent, 7.25% mortgage — full underwriting in Modules 6–7 (monthly cash flow ~$848, 17.9% cash-on-cash, 11.6% cap rate, 1.90 DSCR), plus a walk-away deal and a house-hack example.
- **Disclaimer:** Education only — not individualized investment, legal, tax, or financial advice. Stated in `content.md`, `workbook.md`, and `sales-page.md`.
- **Guarantee:** 14-day money-back guarantee, full refund, no questions asked.
