# The Rental Property Blueprint

## Your first cash-flowing rental — find it, underwrite it, finance it, manage it.

---

**IMPORTANT DISCLAIMER — PLEASE READ FIRST**

This course is real estate education only. It is not individualized investment, legal, tax, or financial advice, and it is not a recommendation to buy any specific property. Real estate investing involves risk, including the possible loss of some or all of your capital. Rents, expenses, interest rates, property values, and local laws change, and the examples in this course use illustrative numbers that will not match every market or every property. Before you buy, consult a qualified professional — a licensed real estate agent, mortgage lender, attorney, tax advisor, or financial advisor — for advice about your specific situation. Verify every number yourself. No return is guaranteed, and past performance of any market or strategy does not guarantee future results.

---

## How to Use This Course

This is a complete course manual for a first-time rental investor with roughly $10,000 to $50,000 in capital. Read it in order the first time: each module builds on the one before it. Then use it as a reference — when you are analyzing a deal, go straight to Modules 6 and 7; when you are screening a tenant, go to Module 10; when something breaks at 2 a.m., go to Module 13.

Every module ends with action steps. Do them. Reading about underwriting is not underwriting. The companion workbook (`workbook.md`) gives you the blank worksheets to do the work in, and the deal analyzer spreadsheet (`templates/rental-deal-analyzer.csv`) does the math for you once you enter a property's numbers.

A note on the numbers in this course: they are realistic, worked examples based on typical U.S. Midwest and Southeast small-multifamily markets at the time of writing, with interest rates around 7%–7.5% for investment-property mortgages. Your market will differ. The method matters more than the numbers — learn the method, then plug in your market's real numbers.

---

## Table of Contents

- Module 1 — Why Rentals Build Wealth (and When They Do Not)
- Module 2 — Setting Your Buy Box and Investment Criteria
- Module 3 — How Much Capital You Really Need
- Module 4 — Financing: Conventional, FHA House Hack, DSCR, Seller Financing
- Module 5 — Finding Deals On and Off Market
- Module 6 — Analyzing a Deal: Rent, Expenses, Vacancy, Capex Reserves
- Module 7 — The 1% Rule, Cap Rate, Cash-on-Cash Return, and DSCR — Worked Examples
- Module 8 — Making an Offer and Negotiating
- Module 9 — Inspection, Appraisal, and Closing
- Module 10 — Tenant Screening Done Right
- Module 11 — Leases That Protect You
- Module 12 — Rent Collection and Late Fees
- Module 13 — Maintenance Systems and Vendors
- Module 14 — Managing Cash Flow Month by Month
- Module 15 — When to Refinance, Sell, or Hold
- Module 16 — Your First 12 Months: Week-by-Week Action Plan

---

## Module 1 — Why Rentals Build Wealth (and When They Do Not)

A rental property makes money in four ways, and understanding all four is the difference between an investor and a speculator.

**1. Cash flow.** Rent minus all expenses, including the mortgage. This is the money that lands in your account each month. It is the only one of the four that pays your bills today, and it is the one this course cares about most. A property that does not cash flow is a liability you are subsidizing, not an investment.

**2. Loan paydown.** Every month, your tenant's rent pays a slice of your mortgage principal. On a $138,750 loan at 7.25%, roughly $130 of the first payments goes to principal, and that amount grows every month. After ten years, your tenant has paid down tens of thousands of dollars of your loan. You did not write that check; they did.

**3. Appreciation.** Over long periods, property values in most U.S. markets rise roughly in line with inflation — historically around 3%–4% per year on average nationally, with enormous local variation. Appreciation is real wealth, but it is the least reliable of the four. Markets fall. Neighborhoods change. Never buy a property that only works if it appreciates.

**4. Tax benefits.** Depreciation, mortgage interest, taxes, insurance, repairs, and management fees are generally deductible against rental income under U.S. tax law, and depreciation is a paper expense — you deduct it without spending the cash. Tax law is complex and changes; talk to a tax professional about your situation. Never let a tax benefit be the reason you buy a bad deal.

### The honest math of a good first deal

Take the example property we will use throughout this course: a $185,000 duplex in a solid working-class neighborhood. Each side rents for $1,450 a month, so gross rent is $2,900 a month, or $34,800 a year. You will see the full underwriting in Module 7, but the headline is this: after the mortgage, taxes, insurance, vacancy, maintenance, reserves, and management, it produces roughly $850 a month in cash flow on about $57,000 of total cash invested. That is real money — about $10,200 a year — but it is not "passive income" in the way social media sells it. You will spend evenings on tenant issues, weekends on turnover, and real money on roofs and water heaters. The wealth comes from doing that work, or paying someone competent to do it, for years.

### When rentals do NOT build wealth

Rentals destroy wealth in predictable ways. Learn the failure modes now so you can recognize them in yourself.

**Buying for appreciation only.** If a property loses $300 a month and you are counting on it being worth 20% more in three years, you are speculating, not investing. If the market stays flat, you have lost $10,800 and learned an expensive lesson.

**Underestimating expenses.** The most common beginner mistake is counting rent minus mortgage and calling the difference "profit." Taxes, insurance, vacancy, maintenance, capital reserves, and management are real, and together they typically consume 40%–50% of gross rent. A deal that looks great at rent-minus-mortgage often loses money once the real expenses are counted. Module 6 exists to prevent exactly this.

**Buying in the wrong neighborhood.** A cheap house in a declining area is not a bargain; it is a trap. High vacancy, high turnover, vandalism, and tenants who cannot pay are the tax you pay for buying the cheapest property in the worst area. A slightly more expensive property in a stable area usually earns more over ten years.

**Being undercapitalized.** If you put every dollar you have into the down payment and the water heater fails in month two, you are borrowing on a credit card at 24% to fix a rental. That is how a good property becomes a financial emergency. Module 3 covers exactly how much cash you need beyond the down payment.

**Managing badly.** The property is only half the business. The other half is people: screening, leasing, collecting, maintaining, and communicating. A great property with a bad tenant is a bad investment. Modules 10 through 13 are the people half of this course, and they matter as much as the numbers.

### What success actually looks like

A realistic first five years: you buy one solid duplex, it cash flows $500–$900 a month after all real expenses, you have two or three expensive surprises (a roof, a turnover, a vacancy), and you end year five with roughly $50,000–$60,000 in cash flow collected, $15,000–$20,000 of loan paydown, and modest appreciation. That is not a Lamborghini. It is the foundation of real wealth — and it compounds if you do it again.

### Action Steps

1. Write down, in one sentence, why you want a rental property. Tape it where you will see it when a deal tempts you.
2. Write down the maximum monthly loss you could tolerate for six months without panic. That number is your risk boundary.
3. Read Module 2 and start drafting your buy box before you look at a single listing.

---

## Module 2 — Setting Your Buy Box and Investment Criteria

A buy box is a written set of rules that defines exactly what you will buy and, just as importantly, what you will not buy. Without one, every listing looks like an opportunity, and you will either buy nothing (paralysis) or buy the wrong thing (impulse). Professional investors decide their criteria before they look at properties. Amateurs look at properties and then invent criteria to justify the one they like.

### What goes in a buy box

**Property type.** For a first rental, the strongest choices are a small multifamily (duplex, triplex, or fourplex) or a single-family home in a stable neighborhood. A duplex is the classic first deal: two rents cover one mortgage, and if one side is vacant you still have income. Avoid for your first purchase: large apartment buildings, commercial property, short-term rentals in regulated markets, and anything requiring a gut renovation.

**Price range.** Set a maximum purchase price based on your capital (Module 3), not on what a lender says you can borrow. A lender's maximum is not your maximum.

**Location.** Define it tightly: specific neighborhoods, zip codes, or a radius around a job center, hospital, university, or military base. Your location criteria should include: population stable or growing, diverse employers (no single employer over 20% of local jobs), crime at or below the metro average, and schools rated average or better. Drive the streets at night before you buy. A neighborhood that feels unsafe at 9 p.m. will have vacancy and turnover problems no spreadsheet can fix.

**Condition.** Decide in advance: cosmetic updates only (paint, flooring, fixtures), or light rehab (kitchen, bath, systems)? For a first deal, cosmetic-only or rent-ready is the safer choice. A full rehab is a second business — contracting — and it is where beginners lose the most money.

**Minimum returns.** Write down your minimums and do not negotiate with yourself later. A reasonable first-investor standard: minimum $200 per unit per month in cash flow after all expenses including reserves and management (even if you plan to self-manage at first — price the management in, because you may hire it later); minimum 8% cash-on-cash return; minimum 1.25 DSCR. If a deal does not meet your minimums, pass. There will be another deal.

**Tenant profile.** Who will rent this property? Working families, young professionals, graduate students, traveling nurses? Your property type, location, and price point should match a real, stable tenant pool. A three-bedroom house near good schools rents to families who stay for years. A one-bedroom near a hospital rents to nurses who stay for one contract. Both can work; know which one you are buying.

### Example buy box

Here is a complete example buy box for a first-time investor with $40,000 in capital:

- **Type:** Duplex or triplex, built after 1960, brick or vinyl siding, no flat roofs.
- **Price:** $150,000–$220,000.
- **Location:** Three named neighborhoods within 25 minutes of the regional hospital and the university; no flood zone; crime below metro average.
- **Condition:** Rent-ready or cosmetic only; roof less than 10 years old; HVAC less than 12 years old; no foundation issues, no knob-and-tube wiring, no galvanized plumbing.
- **Rents:** At least $1,300 per unit, verified against current comparable rentals.
- **Returns:** At least $250 per unit per month cash flow after all expenses; at least 10% cash-on-cash; DSCR of at least 1.25.
- **Will not buy:** Single-family homes over $250,000, properties needing more than $15,000 in work, HOA communities, properties with tenants already in place on below-market leases I cannot verify.

### The discipline of the buy box

Your buy box will feel too strict. That is the point. You should analyze twenty or thirty properties and make offers on two or three before one is accepted. A 5%–10% offer-to-acceptance rate is normal. If you are getting every offer accepted, you are overpaying.

Review your buy box every six months. Markets change, and a buy box written for one market may not fit another. But never change your buy box to justify a specific property you have fallen in love with. Change it based on market data, in a calm moment, away from any live deal.

### Action Steps

1. Fill in the buy-box worksheet in the companion workbook. Be specific — name the neighborhoods.
2. Set your minimum cash flow per unit, minimum cash-on-cash return, and minimum DSCR in writing.
3. Write your "will not buy" list. Five items minimum.
4. Share your buy box with your real estate agent and your lender, and ask them to send you only properties that fit it.

---

## Module 3 — How Much Capital You Really Need

The down payment is the most visible cost of buying a rental, and it is not the largest check you will write in your first year. Beginners who budget only for the down payment run out of money at exactly the wrong moment.

### The full capital stack

**Down payment.** For an investment property (one you will not live in), conventional lenders typically require 20%–25% down. On a $185,000 duplex at 25%, that is $46,250. For an owner-occupied house hack with an FHA loan, the down payment can be as low as 3.5% — see Module 4.

**Closing costs.** Budget 2%–5% of the purchase price. On $185,000, that is $3,700–$9,250. This includes lender fees, title insurance, recording fees, prepaid taxes and insurance, and attorney fees where applicable. Your lender's Loan Estimate will itemize these before closing — read it line by line.

**Initial repairs and make-ready.** Even a "rent-ready" property usually needs $2,000–$8,000: paint, cleaning, minor repairs, locks, smoke detectors, and appliance replacements. Budget $5,000 for a duplex in decent condition and verify it during inspection.

**Reserves — the money that saves you.** Keep a minimum of six months of total expenses (mortgage, taxes, insurance) in cash after closing, separate from your personal emergency fund. For our example duplex, monthly PITI (principal, interest, taxes, insurance) is about $1,397, so six months is roughly $8,400. This is not optional. Vacancies, evictions, and major repairs happen, and they happen to undercapitalized owners worst of all.

### The honest total for our example duplex

| Item | Amount |
|---|---|
| Down payment (25% of $185,000) | $46,250 |
| Closing costs (3%) | $5,550 |
| Initial repairs and make-ready | $5,000 |
| Reserves (6 months PITI) | $8,400 |
| **Total cash needed** | **$65,200** |

That is the real number for a $185,000 duplex. If you have $50,000, you have three honest options: buy a cheaper property (a $140,000 duplex needs roughly $49,000 all-in), house hack with an FHA loan (far less down, but you live there), or wait and save. What you should not do is drain your last dollar to close and hope nothing breaks. Hope is not a reserve fund.

### Where the capital comes from — and where it should not

Legitimate sources: savings, a home equity line on your primary residence (understand the risk — you are borrowing against your home), a partner's capital under a written agreement, or a house hack that reduces the down payment. Sources to avoid: credit cards, personal loans at high rates, borrowing from retirement accounts (taxes and penalties usually make this a bad trade), and "hard money" loans for a first buy-and-hold — hard money is a tool for experienced flippers, not for a first rental.

### A note on house hacking and lower capital

If $65,000 is out of reach, the house hack in Module 4 is the most realistic path for most first-time investors: buy a duplex with 3.5% down, live in one side, rent the other. On a $200,000 duplex, that is a $7,000 down payment instead of $50,000. You still need closing costs, make-ready, and reserves — budget $20,000–$25,000 all-in — but it puts a first property within reach of a $10,000–$25,000 capital position.

### Action Steps

1. Add up your actual available capital — money you could put into a property without touching your personal emergency fund.
2. Work the capital stack table above with your own target price. Write down the total.
3. If the total exceeds your capital, decide now: cheaper property, house hack, partner, or wait. Decide in a calm moment, not during a bidding war.
4. Open a separate savings account labeled "Rental Reserves" and fund it before you make your first offer.

---

## Module 4 — Financing: Conventional, FHA House Hack, DSCR, Seller Financing

Financing is where most first deals are won or lost. The loan you choose determines your down payment, your monthly payment, your cash flow, and your risk. There is no single best loan — there is a best loan for your situation.

### Option 1: Conventional investment-property loan

The standard route for a non-owner-occupied rental. You buy the property as an investment, you do not live there.

- **Down payment:** Typically 20%–25%. Some lenders allow 15% on a single-family investment property, but 25% is the common requirement for a two-to-four-unit property.
- **Rate:** Usually 0.5%–1% higher than an owner-occupied rate. At the time of writing, expect roughly 7%–7.75% for a well-qualified borrower.
- **Requirements:** Credit score of 680 or higher (720+ gets the best pricing), debt-to-income ratio generally under 45%, and six months of reserves in the bank. The lender will count some of the property's rental income toward your qualification — typically 75% of the market rent, to account for vacancy.
- **Best for:** Investors with 25% down who want a straightforward, long-term fixed-rate loan.
- **Watch out for:** Lenders may require the property to be in good condition; fixer-uppers can fail appraisal or condition requirements.

### Option 2: FHA house hack

You buy a two-to-four-unit property, live in one unit for at least one year, and rent the others. This is the single most powerful tool available to a first-time investor with limited capital.

- **Down payment:** As low as 3.5% of the purchase price. On a $200,000 duplex, that is $7,000.
- **Rate:** Owner-occupied rates, typically lower than investment rates.
- **Requirements:** Credit score of 580+ (620+ is more realistic in practice), you must move in within 60 days and live there for at least a year, and the property must pass an FHA appraisal, which has stricter condition standards than a conventional appraisal. You will pay mortgage insurance (MIP) — budget roughly 0.55% of the loan amount per year, or about $88 a month on a $193,000 loan.
- **The math that makes it work:** Buy a $200,000 duplex with 3.5% down ($7,000). Your loan is $193,000 plus the upfront MIP financed in. At 6.75%, 30 years, principal and interest is about $1,257 a month. Add taxes ($250), insurance ($150), and MIP ($88) and your total payment is about $1,745. Rent the other side for $1,400. You live in a home for roughly $345 a month out of pocket, before maintenance and reserves — while your tenant pays down your mortgage. After a year, you can move out, rent your side, and repeat.
- **Best for:** First-time investors with $15,000–$30,000 in capital who are willing to live in one unit of their investment.
- **Watch out for:** FHA condition standards can kill deals on older properties. You must actually live there — this is not a loophole to game. And you can only have one FHA loan at a time in most cases, so your second property will need a different loan.

### Option 3: DSCR loan

A Debt Service Coverage Ratio loan qualifies you based on the property's income, not your personal income. The lender looks at whether the rent covers the mortgage payment.

- **Down payment:** Typically 20%–25%.
- **Rate:** Usually 1%–2% above conventional rates.
- **Requirements:** The property's rent must cover the mortgage payment by a ratio the lender sets — commonly a DSCR of 1.0 to 1.25, meaning rent must equal or exceed the payment by that factor. Your credit score still matters (usually 660+), and many DSCR lenders require you to have some landlord experience or to own a primary residence.
- **Best for:** Self-employed investors whose tax returns understate their income, investors buying in an LLC, or anyone whose personal debt-to-income ratio blocks a conventional loan.
- **Watch out for:** Higher rates, prepayment penalties (often 3–5 years, declining), and less consumer protection than conventional loans. Read the prepayment penalty clause before you sign — it can cost thousands if you refinance early.

### Option 4: Seller financing

The seller acts as the bank. You pay them a down payment and monthly payments under a promissory note and mortgage or deed of trust, instead of borrowing from a bank.

- **Down payment:** Negotiable — often 10%–20%, sometimes less.
- **Rate and term:** Negotiable. Common structures: 7%–9% interest, 30-year amortization with a balloon payment in 5–10 years (meaning the remaining balance comes due at that point, and you must refinance or pay it off).
- **Best for:** Properties that do not qualify for bank financing, sellers who own the property free and clear and want monthly income, and buyers with unusual credit situations.
- **Watch out for:** Balloon payments are the danger. If you cannot refinance when the balloon comes due, you can lose the property. Have an attorney review every seller-financed deal, verify the seller actually owns the property free and clear, and confirm there are no hidden liens. Get title insurance.

### Comparing the four on our example duplex ($185,000)

| | Conventional | FHA house hack | DSCR | Seller financing |
|---|---|---|---|---|
| Down payment | $46,250 (25%) | $6,475 (3.5%) | $46,250 (25%) | ~$27,750 (15%) |
| Approx. rate | 7.25% | 6.75% + MIP | 8.25% | 8% (negotiated) |
| Monthly P&I on the loan | ~$947 | ~$1,160* | ~$1,017 | ~$1,000 |
| Lives in property? | No | Yes, 1 year min. | No | No |
| Main risk | Capital required | Must occupy; MIP cost | Higher rate; prepay penalty | Balloon payment |

*FHA example uses a $200,000 purchase price, not $185,000, so its payment is not directly comparable — it is shown to illustrate the house-hack structure.

### How to choose

- If you have 25% down and strong credit: conventional. Simplest, cheapest long-term.
- If you have under $30,000 and can live in the property: FHA house hack. Lowest barrier to entry.
- If you are self-employed or buying in an LLC and conventional underwriting blocks you: DSCR.
- If the property or your credit does not fit a bank: seller financing, with an attorney, and only if you have a credible plan for the balloon.

### Action Steps

1. Get pre-approved (not just pre-qualified) with at least two lenders before you make an offer. Compare the Loan Estimates side by side.
2. Ask each lender: "What is my maximum purchase price, what is my rate, and what reserves do you require?" Write the answers down.
3. If a house hack fits your life, talk to an FHA-experienced lender about condition requirements before you fall in love with an older duplex.
4. Never waive the financing contingency on your first deal.

---

## Module 5 — Finding Deals On and Off Market

Good deals are found, not stumbled upon. The investors who find them run a system: they look at many properties, they look every week, and they look in places other buyers ignore.

### On-market: the MLS and listing sites

Most first deals come from the public market. Your agent sets up an automated search matching your buy box, and you review new listings daily. This is not glamorous, but it works — especially in markets where the MLS is the dominant channel.

- **Look for stale listings.** A property sitting for 60+ days is a signal: the price is too high, the condition is worse than the photos suggest, or the seller is difficult. All three are negotiable. Call the listing agent and ask, directly, "Why hasn't this sold?"
- **Look for price reductions.** A property reduced twice in 30 days has a motivated seller. Track reductions weekly.
- **Look for the ugly photos.** Bad photos mean fewer competing buyers. A property with dark, blurry photos and a one-line description often hides a solid building behind a lazy listing.
- **Check the rent history.** If the listing says "currently rented at $900," verify it. Ask for the lease. Below-market rents are common, and they mean your real income is higher than the listing implies — or that the tenant is a problem the seller is exporting to you.

### Off-market: where the better margins live

Off-market deals — properties not listed publicly — often price 5%–15% below market because the seller avoids commissions, showings, and competition. They take more work to find.

- **Direct mail.** Send simple, plain letters to owners of duplexes and small multifamily properties in your target neighborhoods: "I'm a local investor looking to buy a duplex in your neighborhood. If you ever consider selling, I'd like to make you a fair offer." Expect a 1%–3% response rate. Mail the same list every 6–8 weeks; most responses come on the third or fourth mailing.
- **Driving for dollars.** Drive your target neighborhoods and note properties with overgrown lawns, boarded windows, piled-up mail, or visible neglect. Look up the owner in county records and contact them. This is slow, free, and surprisingly effective.
- **Wholesalers.** Other investors who find off-market deals and assign the contract to you for a fee. A legitimate wholesaler shows you the numbers transparently and lets you inspect. A bad one hides the fee and pressures you to close fast. Never buy a wholesale deal without your own inspection and your own underwriting.
- **Relationships.** Tell everyone you know that you buy rental property: your agent, your lender, your property manager, contractors, attorneys, and other investors. Most off-market deals travel by word of mouth before they ever reach a listing.
- **Expired listings.** Properties that were listed and did not sell. The seller wanted to sell once already. Your agent can pull the expired-listing report and you can reach out through the former listing agent.

### What a "deal" actually is

A deal is not a low price. A deal is a property whose income, at a price you can pay, meets your buy-box returns after honest expenses. A $120,000 house that rents for $900 and needs $20,000 in work is not a deal. A $185,000 duplex that rents for $2,900 and needs $5,000 in work is. Run the numbers on every property, in writing, before you decide whether it is a deal. Module 6 shows you how.

### Action Steps

1. Set up MLS alerts matching your buy box today, and commit to reviewing new listings every morning for 15 minutes.
2. Pick one off-market channel (direct mail or driving for dollars) and start it this week. Consistency beats intensity.
3. Build a simple tracking sheet: every property you analyze, its price, its rent, its cash flow, and your decision. After 30 properties, patterns will emerge.
4. Tell five people this week that you are looking to buy a rental property in your target neighborhoods.

---

## Module 6 — Analyzing a Deal: Rent, Expenses, Vacancy, Capex Reserves

Underwriting is the skill that separates investors from gamblers. It is not complicated, but it must be complete. Every expense you leave out is a surprise you will pay for later, with interest.

### Step 1: Verify the rent

Never trust the rent in a listing. Verify it three ways:

1. **Comparable rentals.** Find three to five currently listed or recently rented properties of similar size, condition, and location. Sites like Zillow, Rentometer, and Facebook Marketplace give you asking rents; your property manager or agent can tell you actual signed rents, which are usually 3%–5% lower than asking rents.
2. **The existing leases.** If the property is occupied, read the actual leases. Confirm the rent, the lease term, the security deposit, and whether the tenant is current. A seller who will not show you leases is hiding something.
3. **Your property manager.** Before you buy, call a local property manager and ask: "What would this rent for, and how long would it take to fill?" They know the market better than any website. This call is free, and it is the most valuable underwriting step you will take.

For our example duplex, verified rent is $1,450 per unit, $2,900 total, supported by three nearby two-bedroom units renting at $1,400–$1,500.

### Step 2: Count every expense

Use these rules of thumb as starting points, then replace them with real quotes wherever you can.

**Mortgage (principal and interest).** From your lender's Loan Estimate. On our example: $138,750 loan at 7.25%, 30 years = $947 a month.

**Property taxes.** From the county tax records, not the listing. Taxes can jump after a sale if the property is reassessed at the purchase price — in some states, a sale triggers a reassessment. Call the county assessor and ask what the taxes will be at your purchase price. Our example: $3,600 a year, $300 a month.

**Insurance.** Get a real quote before you offer. Landlord policies cost more than homeowner policies. Budget $1,500–$2,500 a year for a duplex in most markets. Our example: $1,800 a year, $150 a month. If the property is in a flood zone, add flood insurance — it can be $1,000–$3,000 a year and it changes the deal entirely.

**Vacancy.** Budget 5%–8% of gross rent. At 5%, a property is vacant about 18 days a year on average — one turnover every two to three years plus a few weeks between tenants. In weaker markets, use 8%–10%. Our example: 5% of $2,900 = $145 a month.

**Maintenance and repairs.** Budget 5%–10% of gross rent, higher for older properties. This covers the plumber, the clogged drain, the broken garbage disposal, the lawn care. Our example: 5% = $145 a month. A 1920s duplex with original plumbing should be budgeted at 8%–10%.

**Capital expenditures (capex) reserves.** The big, infrequent items: roof ($8,000–$15,000 every 20–30 years), HVAC ($5,000–$8,000 every 15–20 years), water heater ($1,200–$1,800 every 8–12 years), appliances, flooring, driveway. Budget 5%–10% of gross rent, set aside every month in a separate account, and do not spend it on anything else. Our example: 5% = $145 a month. On a $2,900 gross rent, $145 a month is $1,740 a year — enough to cover a water heater and an appliance most years, and to build toward a roof over a decade.

**Property management.** Budget 8%–10% of collected rent, even if you plan to self-manage. Two reasons: you may hire a manager later, and your time has value. If the deal only works when you manage it yourself for free, it is not a good deal — it is a second job you are not being paid for. Our example: 8% of effective rent ($2,755) = $220 a month.

**HOA fees.** If the property has an HOA, include the full monthly fee. Many investors avoid HOAs entirely for rentals because fees rise and rental restrictions can change. Our example duplex has no HOA.

**Utilities.** If you pay any utilities (common in small multifamily: water, sewer, trash, common-area electric), include them at the actual billed amount. Get twelve months of utility bills from the seller. Our example: tenants pay all utilities; the owner pays $0.

### Step 3: The full monthly underwriting of the example duplex

| Line item | Monthly amount |
|---|---|
| Gross rent (2 × $1,450) | $2,900 |
| Less vacancy (5%) | −$145 |
| **Effective gross income** | **$2,755** |
| Property taxes | −$300 |
| Insurance | −$150 |
| Maintenance (5%) | −$145 |
| Capex reserves (5%) | −$145 |
| Property management (8%) | −$220 |
| **Net operating income (NOI)** | **$1,795** |
| Mortgage (P&I) | −$947 |
| **Monthly cash flow** | **$848** |

Annual cash flow: $848 × 12 = $10,176. Total cash invested (down payment $46,250 + closing $5,550 + make-ready $5,000) = $56,800. Cash-on-cash return: $10,176 ÷ $56,800 = 17.9%. We will define and verify every one of these metrics in Module 7.

### The 50% rule — a quick sanity check

A useful rule of thumb: over the long run, total operating expenses (everything except the mortgage) tend to equal roughly 50% of gross rent. On our duplex, operating expenses are $960 on $2,900 of gross rent — about 33% — because taxes and insurance are low in this market and there is no HOA. In higher-tax markets, expenses run closer to 45%–50%. If your underwriting shows operating expenses below 30% of gross rent, you have probably left something out. Go back and check.

### Common underwriting mistakes

- **Using the seller's expense numbers.** Sellers understate expenses. Use your own numbers, your own quotes, and the percentages in this module.
- **Forgetting capex.** The roof is not an "if" — it is a "when." If you do not reserve for it monthly, you will pay for it in a lump sum at the worst possible time.
- **Counting rent that does not exist.** A vacant unit produces $0. A tenant paying below-market rent produces the below-market rent, not the market rent, until the lease ends.
- **Ignoring turnover cost.** Every turnover costs one month's rent in vacancy plus $1,000–$3,000 in cleaning, paint, and minor repairs. Budget for it through your vacancy and maintenance reserves.

### Action Steps

1. Underwrite five properties this week using the deal analyzer spreadsheet, even if you have no intention of buying them. Speed and accuracy come from repetition.
2. Call one property manager and one insurance agent in your target market this week. Get real numbers to replace the rules of thumb.
3. For any property you seriously consider, request twelve months of utility bills and the current leases before you offer.

---

## Module 7 — The 1% Rule, Cap Rate, Cash-on-Cash Return, and DSCR — Worked Examples

Four metrics, four different questions. Learn what each one answers, and you will never be confused by a listing again.

### The 1% rule — the 30-second screen

**Monthly gross rent should be at least 1% of the purchase price.**

Our duplex: $2,900 ÷ $185,000 = 1.57%. It passes easily.

The 1% rule is a screening tool, not an analysis. It tells you whether a property is worth the ten minutes of full underwriting. In expensive coastal markets, almost nothing passes the 1% rule — that tells you something important about those markets, namely that cash flow is hard to find there. In Midwest and Southeast markets, solid properties pass it regularly. A property at 0.6% is not automatically bad, but it needs an unusually good reason (very low taxes, very low expenses, a value-add opportunity) to justify a full analysis. Use the rule to filter, not to decide.

### Cap rate — the property's return, ignoring financing

**Cap rate = Annual Net Operating Income ÷ Purchase Price.**

NOI is the income after all operating expenses but before the mortgage. Our duplex: annual NOI is $1,795 × 12 = $21,540. Cap rate = $21,540 ÷ $185,000 = 11.6%.

That is a high cap rate — a strong deal. Typical cap rates for small residential rentals in stable markets run 6%–9%. Above 10% usually means either a genuinely good deal or a riskier property (weaker neighborhood, older building, higher vacancy) that the market is pricing accordingly. Below 6% means the property is expensive relative to its income, and your cash flow will be thin or negative once you add a mortgage.

Cap rate is useful because it lets you compare properties without the financing distorting the picture. A $185,000 duplex at an 11.6% cap and a $300,000 fourplex at a 7% cap are directly comparable on the property itself. Then you layer your financing on top.

### Cash-on-cash return — your return on the cash you actually put in

**Cash-on-cash return = Annual Cash Flow ÷ Total Cash Invested.**

Annual cash flow is NOI minus the mortgage payment. Total cash invested is the down payment plus closing costs plus initial repairs.

Our duplex: annual cash flow $10,176 ÷ total cash invested $56,800 = 17.9%.

This is the number that matters most to you personally, because it measures what your money earns. A reasonable minimum for a first investment is 8%–10%. Below 8%, you should ask whether the risk and work are worth a return that is only modestly better than a high-yield savings account or an index fund — both of which require no tenants and no roofs.

Note what cash-on-cash return ignores: loan paydown, appreciation, and tax benefits. Your total return is higher than your cash-on-cash return. But cash flow is the part that keeps you solvent, so it is the part this course optimizes for.

### DSCR — can the property pay its own mortgage?

**DSCR = Annual NOI ÷ Annual Debt Service (mortgage payments).**

Our duplex: annual NOI $21,540 ÷ annual mortgage payments ($947 × 12 = $11,364) = 1.90.

A DSCR of 1.90 means the property's net income covers the mortgage almost twice over. Lenders typically require a DSCR of 1.20–1.25 for DSCR loans, and 1.0 is break-even — the property exactly pays its mortgage and nothing else. Anything below 1.0 means the property loses money every month and you are subsidizing it.

DSCR is your safety margin. A property at 1.25 survives a vacancy or a rent cut. A property at 1.02 does not survive a bad month.

### Worked example 2: the deal you should walk away from

A single-family home listed at $240,000. Rent: $1,800 a month. Taxes $4,800 a year ($400 a month). Insurance $2,100 a year ($175 a month). Buyer puts 20% down ($48,000), loan $192,000 at 7.5%, 30 years. Monthly P&I: $1,342.

- Gross rent: $1,800. Vacancy 5% ($90) → effective gross $1,710.
- Expenses: taxes $400 + insurance $175 + maintenance 5% ($90) + capex 5% ($90) + management 8% ($137) = $892.
- NOI: $1,710 − $892 = $818 a month.
- Cash flow: $818 − $1,342 = **−$524 a month.**
- 1% rule: $1,800 ÷ $240,000 = 0.75%. Fails.
- Cap rate: $9,816 ÷ $240,000 = 4.1%. Weak.
- Cash-on-cash: −$6,288 ÷ ($48,000 + $7,200 closing + $3,000 make-ready) = −10.8%.
- DSCR: $9,816 ÷ $16,104 = 0.61. The property does not cover its own mortgage.

This property loses $524 every month, $6,288 every year, before a single repair surprise. The listing will call it a "great investment in a desirable neighborhood." The numbers say otherwise. Walk away — and notice how the 1% rule flagged it in ten seconds.

### Worked example 3: the house hack

A $210,000 duplex. You buy with an FHA loan, 3.5% down ($7,350), loan $202,650 at 6.75%. Monthly P&I: $1,314. Taxes $3,900 a year ($325). Insurance $1,900 a year ($158). MIP: $93 a month. Total monthly payment: $1,890.

You live in one side and rent the other for $1,450. Your out-of-pocket housing cost is $1,890 − $1,450 = $440 a month, plus maintenance and reserves. Compare that to renting a comparable apartment for $1,200–$1,400 a month. You are saving $800+ a month and building equity — and after one year you can move out, rent your side for $1,450, and the property grosses $2,900 against a $1,890 payment. That is the house hack, and it is the fastest honest path to a first rental for most people.

### Action Steps

1. Memorize the four formulas. Write them on a card and keep it with you when you look at properties.
2. Underwrite the example duplex yourself, by hand, from the numbers in Module 6. Your answer should match: 1.57%, 11.6% cap, 17.9% cash-on-cash, 1.90 DSCR.
3. Find one property in your market that fails the 1% rule and underwrite it fully. Seeing a bad deal on paper, before your money is involved, is free education.

---

## Module 8 — Making an Offer and Negotiating

Your offer is a business proposal, not a compliment. The seller does not care how much you love the house. They care about price, certainty, and timing. Structure your offer around what the seller needs and what the numbers allow.

### Before you offer: know your numbers cold

Your maximum price is set by your underwriting, not by the asking price. Work backwards: what is the highest price at which this property still meets your buy-box minimums? On our example duplex, if you pay $200,000 instead of $185,000 with the same rents, your down payment rises to $50,000, your loan to $150,000, your monthly P&I to about $1,023, and your cash flow falls from $848 to roughly $772 a month. Still a good deal. At $220,000, cash flow falls to about $640 a month and cash-on-cash to roughly 12% — still acceptable, but the margin is thinning. At $240,000, cash flow is about $510 and the deal is marginal. Know your walk-away price before you negotiate, and write it down. In the heat of a negotiation, your walk-away price will try to move. Do not let it.

### The anatomy of a strong offer

- **Price.** Start below asking when the numbers justify it — 5%–10% below is a normal opening on a property that has been listed for more than 30 days. On a fresh listing in a competitive market, you may need to offer at or above asking. Let the days-on-market and your underwriting set your price, not your enthusiasm.
- **Earnest money.** Typically 1%–2% of the purchase price, held in escrow. It signals seriousness. On a $185,000 purchase, $2,000–$3,500 is standard. You get it back if the deal fails under a valid contingency.
- **Contingencies — keep them on your first deal.** Inspection contingency (you can walk away or renegotiate if the inspection finds problems), financing contingency (you can walk away if the loan falls through), and appraisal contingency (you can walk away or renegotiate if the appraisal comes in below the purchase price). Experienced investors sometimes waive contingencies to win competitive deals. On your first deal, do not. A waived inspection contingency is how a $10,000 foundation problem becomes yours.
- **Closing timeline.** Twenty-one to thirty days is standard for a financed purchase. A faster close can win a competitive deal if your lender can do it — ask your lender before you promise it.
- **Proof of funds and pre-approval letter.** Include both. They prove you can close, and they separate you from buyers who cannot.

### Negotiation tactics that actually work

- **Negotiate on facts, not feelings.** "The roof is 22 years old and will cost $12,000 to replace; the inspection found $4,000 in plumbing work; comparable sales support $178,000" is a negotiation. "I really want this house" is not.
- **Ask for credits, not repairs.** A seller credit at closing ($5,000 toward the roof) is usually better than asking the seller to fix the roof, because you control the quality of the work and the contractor.
- **Trade what is cheap for you and expensive for them.** A flexible closing date, a larger earnest money deposit, or a shorter inspection period can be worth thousands in price to a seller who needs certainty or speed.
- **Be willing to walk away.** The single most powerful negotiating position is a genuine willingness to walk away. If you cannot walk away, you have already lost. There is always another property. The market produces a new listing every day.
- **Silence is a tool.** After you make an offer, stop talking. Let the seller respond. Nervous buyers bid against themselves.

### When the seller counters

Read the counter carefully. Sellers often counter on price but concede on credits, closing dates, or included items (appliances, washer/dryer). Evaluate the whole package against your walk-away price, not just the headline number. If the counter is above your walk-away price, decline politely and move on. Do not burn the relationship — deals come back. A seller who rejects you today may call your agent in three weeks when their other buyer falls through.

### Action Steps

1. Calculate your walk-away price for the next property you analyze, in writing, before you talk to your agent about an offer.
2. Ask your agent to show you a blank purchase contract and walk through every contingency with you before you are under deadline pressure.
3. Role-play one negotiation with your agent: they play the seller, you make the offer and handle the counter.

---

## Module 9 — Inspection, Appraisal, and Closing

An accepted offer is the beginning of due diligence, not the end of it. The inspection and appraisal period is your last chance to discover what you are really buying — and to walk away if it is not what you thought.

### The inspection

Hire a licensed, independent home inspector — not one recommended by the seller, and ideally not one recommended by the listing agent. Expect to pay $400–$700 for a duplex. Attend the inspection in person. Follow the inspector around, ask questions, and take notes. The written report matters, but being there teaches you the property in a way a PDF cannot.

What the inspector checks: roof, foundation, structure, electrical panel and wiring, plumbing and water pressure, HVAC, water heater, windows, drainage and grading, and signs of water damage, mold, or pests. For a duplex, ask the inspector to check both units, the shared systems, and the separation between units (fire separation matters for insurance and code compliance).

Also order, when appropriate: a sewer scope ($150–$300 — a collapsed sewer line costs $5,000–$15,000 to replace and a standard inspection will not find it), a radon test ($150–$250 in many markets), and a termite/pest inspection ($75–$150). On properties built before 1978, be aware of lead-based paint disclosure requirements; on any property, ask about the age of the roof and HVAC in writing.

### What inspection findings mean

- **Minor issues** (a dripping faucet, a missing GFCI outlet, peeling paint): normal. Ask for a credit or fix them yourself after closing.
- **Moderate issues** ($2,000–$10,000: an aging water heater, a section of roof, outdated electrical panel): negotiate. Ask for a seller credit equal to the repair cost, or a price reduction. Get contractor quotes so your ask is grounded in real numbers.
- **Major issues** (foundation movement, a failing roof, a sewer line collapse, knob-and-tube wiring throughout, structural damage): pause. Get specialist quotes. If the repair cost breaks your underwriting, walk away under your inspection contingency. Your earnest money comes back. A bad foundation is not a negotiation — it is an exit.

### The appraisal

Your lender orders an appraisal to confirm the property is worth what you are paying. If the appraisal comes in below the purchase price, you have three options: renegotiate the price down to the appraised value, pay the difference in cash, or walk away under your appraisal contingency. On an investment property, paying above appraised value in cash is rarely wise on a first deal — it increases your cash invested and reduces your return.

Appraisers also note condition issues. An FHA appraisal is stricter than a conventional one: peeling paint, missing handrails, a broken window, or a non-functioning system can be flagged as required repairs before closing. Budget time for these.

### Closing

In the final week before closing, you will receive a Closing Disclosure from your lender. Compare it line by line against your original Loan Estimate. Question anything that changed by more than a small amount. Do a final walkthrough of the property the day before or the morning of closing: confirm the agreed repairs were done, the appliances are present, and no new damage has occurred. Bring a cashier's check or wire the funds as your title company instructs — and verify wire instructions by phone using a number you already have, not a number from an email. Wire fraud in real estate closings is real, and it is devastating.

At closing you will sign a stack of documents: the note, the mortgage or deed of trust, and the settlement statement. Your title company or attorney will walk you through them. After closing, you own a rental property. The work in Modules 10 through 14 begins the same day.

### Action Steps

1. Interview two home inspectors before you need one. Ask how long their inspections take and whether they inspect both units of a duplex.
2. Budget $800–$1,200 for inspection, sewer scope, and pest inspection on your first purchase.
3. Put the final walkthrough on your calendar the moment a closing date is set. Never skip it.

---

## Module 10 — Tenant Screening Done Right

Your tenant is your business partner for the next year. A great tenant pays on time, reports problems early, and leaves the place clean. A bad tenant costs you months of rent, thousands in repairs, and possibly an eviction. Screening is the highest-leverage work in landlording: an hour of screening saves months of misery.

### The legal foundation — know the law before you screen

Federal Fair Housing law prohibits discrimination based on race, color, religion, sex (including sexual orientation and gender identity under current federal interpretation), national origin, familial status, and disability. Many states and cities add protections for source of income, criminal history, and more. You must apply the same written criteria to every applicant, every time. Never make exceptions, never rely on a gut feeling about a person, and never ask questions about protected characteristics. If you are unsure whether a criterion is lawful in your area, ask a local landlord-tenant attorney before you use it. A discrimination complaint costs far more than a vacant month.

### Written screening criteria

Publish your criteria before you screen anyone, and apply them identically to all applicants. A standard set:

- **Income:** Gross monthly income of at least 3 times the monthly rent (some landlords use 2.5 times; 3 times is the safer standard). Verify with pay stubs for the last two months and by calling the employer.
- **Credit:** Minimum credit score of 620–650, no recent evictions, no unpaid landlord judgments, no active collections from a prior landlord. A low score caused by medical debt is different from a low score caused by unpaid rent — look at the pattern, not just the number.
- **Rental history:** At least two years of verifiable rental history. Call the two most recent landlords — not just the current one, who may be motivated to give a good reference to get rid of a problem tenant. Ask: Did they pay on time? Did they give proper notice? Would you rent to them again? Was the deposit returned in full?
- **Background check:** Criminal history check through a reputable screening service. Apply your written policy consistently, and comply with your state and local rules on what you may consider and how far back you may look.
- **Occupancy:** State the maximum number of occupants per unit, consistent with local occupancy codes.

### The screening process, step by step

1. **Pre-screen by phone or message.** Before you show the property, ask: move-in date, number of occupants, pets, income, and reason for moving. This takes five minutes and eliminates half of unqualified applicants.
2. **Show the property.** Watch how they treat the space during the showing. People who are careless with your property during a showing will be careless as tenants.
3. **Collect the application and fee.** A standard application fee is $35–$75 per adult applicant, which covers the cost of the credit and background check. Collect the fee before you run the reports.
4. **Run the credit and background check.** Use a reputable service (such as TransUnion SmartMove, RentPrep, or your property manager's system). Review the full report, not just the score.
5. **Verify income and employment.** Call the employer at a number you look up independently, not the number the applicant gives you. Confirm position, length of employment, and income.
6. **Call prior landlords.** As above — the previous landlord, not just the current one.
7. **Decide on the criteria, not on a feeling.** If the applicant meets your written criteria, approve them. If they do not, deny them politely and in writing, with the specific criterion they did not meet. Keep records of every application and decision for at least two years.

### Red flags

- An applicant who pressures you to decide immediately or offers to pay six months up front in cash to skip screening. (Legitimate applicants with good credit do not need to buy their way past screening.)
- Inconsistent information between the application, the credit report, and the employer verification.
- A previous landlord who will not return your call, or who gives a suspiciously glowing reference for a tenant who "just moved in" six months ago.
- An applicant who cannot or will not provide a previous landlord's contact information.
- Multiple recent evictions or landlord collections.

### A note on pets

A reasonable pet policy earns you money: pet-friendly rentals fill faster and command $25–$50 a month in pet rent, plus a refundable pet deposit where your state allows it. Require: a pet application with breed, weight, age, and photo; proof of vaccinations; and a pet addendum to the lease. Check your insurance policy — some carriers exclude certain breeds, and your policy controls.

### Action Steps

1. Write your screening criteria today, before you have a vacancy. Use the tenant-screening scorecard in the workbook.
2. Choose a screening service and create an account before you need it.
3. Decide your pet policy and your occupancy limits now, in writing.
4. Never skip screening because a unit is vacant and you are in a hurry. A vacant unit costs you one month's rent. A bad tenant costs you six.

---

## Module 11 — Leases That Protect You

A lease is the operating manual for your relationship with your tenant. A good lease prevents most disputes by answering questions before they become arguments. A bad lease — or a handshake deal — guarantees them.

### Get a proper lease

Use a lease written or reviewed by a landlord-tenant attorney in your state, or a state-specific lease from a reputable source such as your state Realtors association. Never download a random lease from the internet and use it as-is: landlord-tenant law varies enormously by state, and a clause that is enforceable in Texas may be illegal in California or New York. The cost of an attorney-reviewed lease ($300–$600) is less than one hour of an eviction attorney's time.

### What every lease should cover

- **Parties, property, and term.** Full legal names of all adult occupants, the property address and unit, the lease start and end dates, and whether it converts to month-to-month at the end of the term.
- **Rent.** The monthly amount, the due date, the accepted payment methods, and where and how rent is paid. No ambiguity.
- **Security deposit.** The amount, the account it is held in if your state requires a separate account, the conditions for deductions, and the deadline for returning it after move-out. Follow your state's deposit law exactly — deposit disputes are the most common source of landlord lawsuits.
- **Late fees.** The amount, when they apply, and any grace period. See Module 12.
- **Maintenance responsibilities.** Who handles what: the landlord handles structural, plumbing, electrical, HVAC, and appliances provided with the unit; the tenant handles light bulbs, keeping the unit clean, and promptly reporting problems. State clearly that the tenant must report maintenance issues promptly — a leak reported on day one is a $50 fix; a leak reported after three months is a $5,000 mold remediation.
- **Occupancy and guests.** Who may live there, how long a guest may stay before becoming an unauthorized occupant (commonly 7–14 consecutive days), and that subletting requires written permission.
- **Pets.** Allowed or not, and under what conditions. If allowed, a pet addendum with pet rent, deposit, and the tenant's responsibility for damage.
- **Smoking.** State the policy explicitly. A no-smoking clause protects your property's value.
- **Alterations.** No painting, no mounting, no changes without written permission.
- **Entry.** Your right to enter for repairs, inspections, and showings, with the notice your state requires (commonly 24 hours, except in emergencies).
- **Termination and renewal.** How much notice is required, what happens if the tenant leaves early (early termination fee, forfeiture of deposit, or rent until re-rented — as your state allows), and the renewal process.
- **Renter's insurance.** Require it where your state allows. A $15-a-month policy protects the tenant's belongings and, more importantly, gives you a liable party's insurer to deal with if the tenant causes damage.

### The move-in inspection

Before the tenant moves in, walk the unit together and document its condition with dated photos and a written checklist, signed by both parties. This is the evidence that protects your deposit deductions at move-out. Store the photos in two places. This takes thirty minutes and prevents a hundred arguments.

### Renewals and rent increases

Review each lease 60–90 days before it expires. If the tenant is good, offer a renewal — keeping a good tenant is worth more than a small rent increase. If market rents have risen, raise the rent to market, or slightly below market for a renewing good tenant: a $50 increase that keeps a tenant is better than a $100 increase that causes a vacancy costing $1,450 plus turnover costs. Follow your state's notice requirements for rent increases and non-renewals exactly.

### Action Steps

1. Get a state-specific lease reviewed by a local attorney before your first tenant signs.
2. Create your move-in inspection checklist and photo process now, before you need it.
3. Put every lease renewal date on your calendar with a reminder 90 days out.
4. Never rent a unit without a signed lease, a signed move-in inspection, and the first month's rent and deposit collected.

---

## Module 12 — Rent Collection and Late Fees

Rent collection is a system, not a personality trait. Landlords who collect reliably are not tougher than landlords who do not — they have a written process and they follow it the same way every month.

### Set up payment before move-in

Use an online rent collection system (such as Apartments.com, Avail, TenantCloud, or your property manager's portal). Online payment gives you automatic records, automatic late fees, and no excuses about lost checks. Accept ACH/bank transfer as the primary method. Avoid cash — it creates disputes about whether payment was made. If you accept money orders, require them to be delivered with a receipt you both sign.

### The monthly rhythm

- **Day 1:** Rent is due. No reminders needed for a tenant who pays on time — the system handles it.
- **Day 2–3 (grace period, if your lease and state allow one):** No late fee yet, but an automated reminder goes out.
- **Day 4–5:** Late fee applies automatically. Your lease should state the fee — a common structure is $50, or 5% of rent, after a 3–5 day grace period. Check your state's limits: some states cap late fees.
- **Day 6–7:** Personal contact. A phone call, not a text: "Hi, I noticed rent hasn't come in yet. Is everything okay? When can I expect it?" Be human first. Sometimes there is a real emergency, and a good tenant having one bad month is not the same as a bad tenant.
- **Day 10–15:** Written notice. If rent is still unpaid, serve the formal pay-or-quit notice required by your state. This is a legal prerequisite to eviction in most states, and the clock starts when you serve it. Do not delay this step out of kindness — delay does not help the tenant, and it costs you a month of rent.
- **After the notice period expires:** File for eviction if the rent is still unpaid. Consult an eviction attorney for your first eviction. The filing fee is typically $150–$300, and an attorney's help is worth it the first time.

### The rules that protect you

- **Never accept partial payment without a written agreement** unless your attorney advises it — in some states, accepting partial payment can restart the eviction clock.
- **Never let a tenant "catch up next month."** A tenant who is one month behind is almost never one month behind for long. A written payment plan, with specific dates and amounts, is the only acceptable version of this conversation.
- **Never get angry, and never make it personal.** This is a business transaction governed by a lease and by law. Calm, written, consistent communication protects you legally and emotionally.
- **Document everything.** Every call, every text, every notice, every payment. If a dispute ever reaches a courtroom, your records are your case.

### When a good tenant has a bad month

It will happen: a job loss, a medical bill, a car repair. If the tenant has a twelve-month history of on-time payment and communicates early, a one-time written payment plan (for example, half now, half in two weeks, plus the late fee) is often the right business decision — keeping a good tenant is cheaper than a turnover. If the tenant has a history of late payments, or stops communicating, follow the formal process without delay. Compassion and process are not opposites; the process is what lets you be compassionate without being taken advantage of.

### Action Steps

1. Choose an online rent collection system and set it up before your first tenant moves in.
2. Write your late fee policy into your lease and confirm it complies with your state's limits.
3. Put the monthly collection calendar (due date, grace period, late fee date, notice date) in writing and follow it the same way every month.
4. Identify a local eviction attorney now, before you need one. Save their number.

---

## Module 13 — Maintenance Systems and Vendors

Maintenance is where rental income quietly leaks away — or where a well-run property earns its reputation. Tenants who get fast, professional repairs stay longer, pay on time, and take better care of the property. Tenants who wait three weeks for a plumber leave at the first opportunity and tell their friends.

### The maintenance request system

Give tenants one clear way to request repairs — an online portal, a dedicated email address, or a form — and one phone number for true emergencies (flooding, no heat in winter, a gas smell, a broken exterior door). Require written requests for non-emergencies. This creates a record, prevents "I told you about this three months ago" disputes, and lets you triage.

Triage every request the day it arrives:

- **Emergency (respond within hours):** Flooding, sewage backup, no heat when it is below freezing, no water, gas leak, fire, a door or window that will not secure. Call a vendor immediately, and call the tenant to confirm someone is coming.
- **Urgent (respond within 24–48 hours):** A broken appliance, a leaking faucet, a running toilet, a garage door that will not close, a pest problem.
- **Routine (respond within a week):** A dripping tap, a sticking door, a cracked outlet cover, cosmetic issues. Schedule them in a batch.

### Build your vendor bench before you need it

You need, at minimum: a handyman, a plumber, an electrician, an HVAC technician, a roofer, an appliance repair technician, a locksmith, and a cleaning crew for turnovers. Find them before an emergency, not during one. Ask other landlords and your property manager for referrals. Get two quotes for any job over $500. Pay promptly — vendors who are paid on time answer your calls first.

Keep a vendor list with names, phone numbers, rates, and notes on quality. Keep it in your phone and in the workbook. When a vendor does good work at a fair price, tell them you will be a repeat customer and ask for their best rate. A reliable plumber who answers on a Sunday is worth more than a cheap plumber who answers on Tuesday.

### Preventative maintenance — the cheapest repairs are the ones that never happen

- **HVAC:** Service twice a year (spring and fall), change filters every 1–3 months, and keep the area around outdoor units clear. A $150 service visit prevents a $5,000 replacement.
- **Water heater:** Flush annually, check the anode rod every few years, and replace at 10–12 years rather than waiting for a flood.
- **Roof and gutters:** Inspect annually, clean gutters twice a year, and replace missing shingles promptly. A $200 gutter cleaning prevents a $10,000 roof deck repair.
- **Smoke and CO detectors:** Test at every turnover and twice a year. This is a safety issue and, in many states, a legal requirement.
- **Caulk and seals:** Check bathrooms and kitchens annually. Water intrusion behind a tub is a slow, expensive disaster.
- **Winterization:** In cold climates, insulate exposed pipes, confirm the heat works before the first freeze, and tell tenants to keep the heat on and report frozen pipes immediately.

### Turnovers

When a tenant moves out, the clock is ticking: every vacant day costs you rent. Have a turnover checklist and a cleaning crew ready before the move-out date. A standard turnover for a two-bedroom unit takes 5–10 days and costs $1,000–$3,000: cleaning, paint touch-ups or full repaint, carpet cleaning or floor refinishing, minor repairs, lock changes, and a final inspection. Photograph everything before the new tenant moves in. The faster you turn a unit, the less vacancy costs you — but never rush past the inspection. A sloppy turnover creates maintenance requests in the first month, which is the worst possible first impression for a new tenant.

### The $500 rule

Give yourself a decision rule: any repair under $500, your handyman handles it without your prior approval (if you use a property manager, this is typically their authorization limit). Anything over $500, you get a quote and approve it. This keeps small problems from becoming big ones while keeping you in control of big spending.

### Action Steps

1. Build your vendor bench this month: find one handyman, one plumber, one electrician, and one HVAC technician. Save their numbers.
2. Set up a single maintenance request channel for tenants and put it in the lease.
3. Create a preventative maintenance calendar: HVAC spring and fall, gutters twice a year, detectors twice a year.
4. Write your turnover checklist now, before your first move-out.

---

## Module 14 — Managing Cash Flow Month by Month

Cash flow is not what your bank balance says on the first of the month. It is what remains after every real expense, including the ones that have not happened yet. Managing it well is mostly a matter of structure: separate accounts, a monthly review, and honest reserves.

### The account structure

- **Operating account.** Rent comes in here. The mortgage, taxes, insurance, and management fees are paid from here. This is the business's checking account.
- **Reserves account.** Capex and vacancy reserves live here — the $145 a month for capex and the $145 a month for vacancy from our example duplex, transferred automatically on the first of the month. Do not spend from this account except for its intended purposes: vacancies and capital expenses.
- **Security deposits.** Held in a separate account, as your state requires. This money is not yours. Never commingle it with operating funds.
- **Personal account.** Your cash flow distributions go here, monthly or quarterly, after the business's obligations are covered. Pay yourself from the business; do not pay business expenses from your personal account.

### The monthly review — 30 minutes, once a month

On the fifth of each month, sit down with your numbers and answer five questions:

1. Did all rent come in? If not, where is it in the collection process (Module 12)?
2. What expenses were paid, and were any of them unexpected?
3. Are the reserves at their target level? If a repair drew them down, what is the plan to rebuild them?
4. Is any lease expiring in the next 90 days? If so, what is the renewal plan?
5. Is there any maintenance that should be scheduled this month?

Use the 12-month cash-flow planner in the workbook for this review. Over a year, the planner shows you the truth: which months are strong, which months are thin, and whether the property is actually performing the way you underwrote it.

### A realistic year of cash flow for the example duplex

Monthly cash flow after all expenses, including reserves and management, is $848. Over twelve months, that is $10,176 — but it will not arrive evenly. A realistic year looks like this: ten months at +$848, one month at −$1,200 (a turnover: one unit vacant for three weeks plus $1,800 in paint and cleaning), and one month at −$600 (a water heater replacement, partially covered by reserves). The annual total is still about $6,800–$7,000 in that scenario, and the reserves account absorbs the shocks. This is why reserves matter more than the monthly number: the monthly number is an average, and averages do not pay for water heaters.

### Taxes and record-keeping

Keep every receipt, every lease, every invoice, and every bank statement. Use a simple accounting system — a spreadsheet is fine for one property; software such as Stessa, QuickBooks, or your property manager's portal is better as you grow. At tax time, your records determine your deductions: mortgage interest, taxes, insurance, repairs, management, mileage, and depreciation. A clean set of books is worth more than a clever tax strategy, and it is the first thing a lender will ask for when you apply for your second property.

### Action Steps

1. Open separate operating and reserves accounts before your first rent payment arrives.
2. Set up an automatic monthly transfer to the reserves account for the first of every month.
3. Do the monthly review on the fifth of every month, without exception, for the first year.
4. Track your actual cash flow against your underwriting for the first twelve months. If reality is worse than the plan by more than 20%, find out why before you buy a second property.

---

## Module 15 — When to Refinance, Sell, or Hold

Most first-time investors think the decision is "buy or don't buy." The harder decisions come later: hold, refinance, or sell. Each has a time and a reason, and each has a cost.

### Hold — the default, and usually the right answer

If the property cash flows, the tenant is good, and the neighborhood is stable, the best move is usually to hold. Every year you hold, the tenant pays down your loan, rents tend to rise with inflation, and your cash flow grows as the mortgage stays fixed while rents increase. On our example duplex, if rents rise 3% a year and expenses rise 2%, cash flow grows from $848 a month in year one to roughly $1,050 a month by year five. That growth is the quiet engine of rental wealth. Do not sell a good property to chase a shinier one.

### Refinance — when the numbers justify it

Refinancing makes sense when one of these is true:

- **Rates have fallen meaningfully.** If you can reduce your rate by at least 1% and the closing costs pay for themselves within two years, a rate-and-term refinance improves your cash flow permanently. On a $138,750 loan, a 1% rate reduction saves roughly $90 a month — $1,080 a year. If closing costs are $3,000, the payback period is under three years. Do the math; do not refinance for a 0.25% improvement.
- **The property has appreciated and you want to pull equity out.** A cash-out refinance lets you take some of your equity and use it as a down payment on a second property. Example: your duplex is now worth $240,000 and you owe $130,000. A cash-out refinance to 75% of value ($180,000) returns $50,000 in cash, minus closing costs, and your new mortgage payment rises — so your cash flow on the duplex falls. This is leverage, and it is powerful and dangerous in equal measure. Only do it if the second property's cash flow exceeds the reduction in the first property's cash flow, and only if you still have reserves after closing.
- **You need to remove mortgage insurance or change loan terms.** An FHA house hack can be refinanced into a conventional loan once you have 20% equity, eliminating the monthly MIP.

Refinancing costs money (typically 2%–5% of the loan amount in closing costs) and resets your amortization clock. Run the numbers honestly, including the closing costs, before you sign.

### Sell — when it is the right call

- **The property no longer cash flows** and the reason is structural, not temporary: taxes have risen sharply, the neighborhood has declined, or the building needs capital you do not have.
- **The property has appreciated far beyond its rental value** and the equity is worth more deployed elsewhere. If your duplex is worth $300,000 and rents for $2,900, its cap rate has fallen to roughly 6% — and the $150,000 of equity might earn more in two properties that cash flow better.
- **Your life has changed.** A move, a career change, a family situation. Real estate serves your life; your life does not serve your real estate.
- **You are selling to avoid a problem.** This is the wrong reason. Deferred maintenance, a bad tenant, and a vacancy are all fixable. Do not sell a good property because you are tired of managing it — hire a property manager instead.

Before you sell, understand the tax consequences: depreciation recapture and capital gains tax can take a significant share of your profit. A 1031 exchange — selling one investment property and buying another of equal or greater value — can defer those taxes, but it has strict deadlines (45 days to identify a replacement property, 180 days to close) and requires a qualified intermediary. Talk to a tax professional and a 1031 specialist before you sell, not after.

### The decision framework

Once a year, for each property, ask three questions: (1) Does it still meet my buy-box minimums? (2) Would I buy it today at its current value? (3) Is there a better use for this equity? If the answer to the first two is yes, hold. If the answer to the third is a clear, verified yes, consider a refinance or a sale — with professional advice.

### Action Steps

1. Put an annual portfolio review on your calendar for the same date every year.
2. Learn your property's current value once a year (your agent can run a comparative market analysis for free).
3. Never refinance or sell based on a single conversation or a single advertisement. Get the numbers, get a second opinion, and sleep on it.

---

## Module 16 — Your First 12 Months: Week-by-Week Action Plan

This module turns the course into a calendar. If you follow it, you will go from "interested" to "owner of a cash-flowing rental" in roughly a year — or less, if you move fast. Adjust the pace to your life, but keep the order: education, then capital, then team, then deal, then management.

### Weeks 1–4: Learn and decide

- **Week 1:** Read this course in full. Write your one-sentence reason for investing (Module 1). Open the "Rental Reserves" savings account.
- **Week 2:** Draft your buy box (Module 2). Name your neighborhoods. Set your minimum returns in writing.
- **Week 3:** Add up your capital and complete the capital stack table (Module 3). Decide: conventional, house hack, or wait and save.
- **Week 4:** Interview two real estate agents who work with investors, and two lenders. Get pre-approved. Ask the lender for your maximum purchase price and required reserves in writing.

### Weeks 5–8: Build your team and your pipeline

- **Week 5:** Find a property manager in your target market. Ask what your target property types rent for and how long they take to fill.
- **Week 6:** Get an insurance quote for a property like your target. Find a home inspector and a real estate attorney. Save their numbers.
- **Week 7:** Set up MLS alerts matching your buy box. Start your off-market channel (direct mail or driving for dollars).
- **Week 8:** Underwrite your first ten properties with the deal analyzer. Do not make an offer yet. You are training your eye.

### Weeks 9–16: Analyze and offer

- **Week 9–10:** Underwrite five more properties. Visit three in person. Drive the neighborhoods at night.
- **Week 11–12:** Make your first offer — on a property that meets your buy box and your walk-away price. If it is rejected, learn from the counter and move on.
- **Week 13–16:** Keep analyzing, keep offering. Expect two to four offers before one is accepted. Do not chase a deal above your walk-away price.

### Weeks 17–24: Due diligence and closing

- **Week 17–18:** Offer accepted. Order the inspection, sewer scope, and pest inspection. Attend the inspection in person.
- **Week 19–20:** Negotiate inspection findings. Confirm the appraisal. Review the Closing Disclosure line by line.
- **Week 21–22:** Final walkthrough. Close. Get the keys. Change the locks the same day.
- **Week 23–24:** Make-ready: paint, clean, repair, photograph. List the unit. Begin tenant screening.

### Weeks 25–36: First tenant, first systems

- **Week 25–28:** Screen applicants using your written criteria. Sign the lease, complete the move-in inspection with photos, collect the first month's rent and deposit.
- **Week 29–32:** Set up your operating and reserves accounts, your rent collection system, and your monthly review habit.
- **Week 33–36:** Build your vendor bench. Handle your first maintenance requests. Learn the property's quirks.

### Weeks 37–52: Operate, review, and decide what is next

- **Week 37–44:** Run the monthly review on the fifth of every month. Track actual cash flow against your underwriting. Fix whatever is underperforming.
- **Week 45–48:** Do your first quarterly deep review: rent, expenses, reserves, tenant satisfaction, and neighborhood conditions.
- **Week 49–52:** Annual review. Does the property still meet your buy box? Are you ready to repeat the process for property number two? If yes, start again at Week 1 — this time with experience, a team, and a track record.

### What to do when things go wrong

They will. A tenant will be late. A pipe will leak. A contractor will disappoint you. When it happens, return to the module that covers the problem, follow the process, and document what happened. Problems in landlording are rarely new — they are the same ten problems, and this course covers all of them. The investors who succeed are not the ones who avoid problems. They are the ones who have a process for each one and follow it calmly.

### Your first deal is the hardest. The second is easier.

After your first property, you will have a lender who knows you, an agent who knows your buy box, a property manager who knows your standards, vendors who answer your calls, and a track record that makes the next loan easier. The first deal builds the machine. Every deal after that is the machine working.

---

## A Final Word

You now have the complete method: define your criteria, know your capital, choose the right loan, find the deal, underwrite it honestly, negotiate from the numbers, inspect carefully, screen rigorously, lease properly, collect consistently, maintain proactively, and review monthly. None of it is complicated. All of it requires discipline.

Do not buy the first property you see. Do not buy a property that loses money and hope appreciation saves you. Do not skip screening because a unit is vacant. Do not spend your reserves. Do the work, follow the process, and let time do the rest.

Your first cash-flowing rental is not a lottery ticket. It is a system, executed patiently, one decision at a time.

---

*Disclaimer: This course is real estate education only. It is not individualized investment, legal, tax, or financial advice. Real estate investing involves risk, including possible loss of capital. Consult a qualified professional for advice about your specific situation before making any investment decision.*
