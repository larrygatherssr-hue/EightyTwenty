# The Rental Property Blueprint — Companion Workbook

**Disclaimer:** This workbook is real estate education only. It is not individualized investment, legal, tax, or financial advice. The worksheets help you organize your own analysis; they do not recommend any property or investment. Consult a qualified professional for advice about your specific situation.

**How to use this workbook:** Print it or copy it into a document you can edit. Work through the worksheets in order the first time, then reuse the deal-analysis worksheet for every property you consider. Keep a completed copy for each property you analyze — your notes are your record of why you bought, or why you passed.

---

## Worksheet 1 — Buy-Box Worksheet

Fill this in before you look at any listings. Be specific.

- **Property type(s) I will buy:** _______________________________________________
- **Property type(s) I will NOT buy:** ___________________________________________
- **Price range:** $__________ to $__________
- **Target neighborhoods / zip codes:** __________________________________________
- **Maximum distance from a major employer, hospital, or university:** ______________
- **Condition I will accept:** ☐ Rent-ready only  ☐ Cosmetic updates only  ☐ Light rehab (under $__________)
- **Maximum repair budget:** $__________
- **Minimum rent per unit:** $__________
- **Minimum cash flow per unit per month (after all expenses, including reserves and management):** $__________
- **Minimum cash-on-cash return:** __________%
- **Minimum DSCR:** __________
- **Minimum 1% rule result:** __________%
- **Tenant profile I am targeting:** ____________________________________________
- **Deal-breakers (things that mean an automatic pass):**
  1. ______________________________________________________________________
  2. ______________________________________________________________________
  3. ______________________________________________________________________
  4. ______________________________________________________________________
  5. ______________________________________________________________________

**My buy box, in one sentence:** _________________________________________________

---

## Worksheet 2 — Deal-Analysis Worksheet

Complete one copy per property. Use the deal analyzer spreadsheet for the arithmetic; use this sheet to record your assumptions and your decision.

- **Property address:** _______________________________________________________
- **Date analyzed:** __________________  **Asking price:** $____________________
- **Property type / units:** __________________  **Year built:** __________________
- **Source:** ☐ MLS  ☐ Off-market  ☐ Wholesaler  ☐ Other: ______________________

### Income

| Item | Monthly | Annual |
|---|---|---|
| Gross rent (Unit 1: $____ × 1) | $ | $ |
| Gross rent (Unit 2: $____ × 1) | $ | $ |
| Gross rent (other units) | $ | $ |
| **Total gross rent** | **$** | **$** |
| Less vacancy (____%) | −$ | −$ |
| **Effective gross income** | **$** | **$** |

### Operating expenses

| Item | Monthly | Annual |
|---|---|---|
| Property taxes (verified with county: ☐) | $ | $ |
| Insurance (quote received: ☐) | $ | $ |
| Maintenance (____% of gross rent) | $ | $ |
| Capex reserves (____% of gross rent) | $ | $ |
| Property management (____% of effective rent) | $ | $ |
| HOA | $ | $ |
| Utilities paid by owner | $ | $ |
| Other: __________________ | $ | $ |
| **Total operating expenses** | **$** | **$** |

### Financing

- **Purchase price:** $__________  **Down payment:** $__________ (__________%)
- **Loan amount:** $__________  **Interest rate:** __________%  **Term:** __________ years
- **Monthly principal & interest:** $__________
- **Closing costs (estimate):** $__________  **Initial repairs / make-ready:** $__________
- **Total cash invested (down payment + closing + repairs):** $__________

### Results

| Metric | Formula | Your result | Pass / fail |
|---|---|---|---|
| 1% rule | Monthly gross rent ÷ price | __________% | ☐ Pass ☐ Fail |
| Net operating income (NOI) | Effective gross income − operating expenses | $__________ / mo | — |
| Monthly cash flow | NOI − mortgage payment | $__________ / mo | ☐ Pass ☐ Fail |
| Cash flow per unit | Cash flow ÷ number of units | $__________ / mo | ☐ Pass ☐ Fail |
| Cap rate | Annual NOI ÷ purchase price | __________% | ☐ Pass ☐ Fail |
| Cash-on-cash return | Annual cash flow ÷ total cash invested | __________% | ☐ Pass ☐ Fail |
| DSCR | Annual NOI ÷ annual mortgage payments | __________ | ☐ Pass ☐ Fail |
| 50% rule check | Operating expenses ÷ gross rent | __________% | (Should be 30–50%) |

### Assumptions and verification

- **How I verified the rent:** ☐ Comparable rentals (list 3): __________________  ☐ Current leases reviewed  ☐ Property manager consulted
- **Roof age:** __________ years  **HVAC age:** __________ years  **Water heater age:** __________ years
- **Known issues from inspection / disclosure:** ____________________________________
- **Biggest risk with this property:** _______________________________________________
- **My walk-away price (highest price at which it still meets my buy box):** $__________

### Decision

☐ **Buy — make an offer at $__________**   ☐ **Pass — reason:** ________________________   ☐ **Watch — revisit if price drops to $__________**

**Notes:** _______________________________________________________________________

---

## Worksheet 3 — Financing Comparison Worksheet

Fill in one column per loan option for the same property, then compare.

| Item | Conventional | FHA house hack | DSCR loan | Seller financing |
|---|---|---|---|---|
| Purchase price | $ | $ | $ | $ |
| Down payment | $ | $ | $ | $ |
| Loan amount | $ | $ | $ | $ |
| Interest rate | % | % | % | % |
| Loan term | yrs | yrs | yrs | yrs |
| Monthly P&I | $ | $ | $ | $ |
| Mortgage insurance / MIP | $ | $ | $ | $ |
| Monthly taxes + insurance | $ | $ | $ | $ |
| **Total monthly payment** | **$** | **$** | **$** | **$** |
| Monthly cash flow (from Worksheet 2) | $ | $ | $ | $ |
| Cash-on-cash return | % | % | % | % |
| Prepayment penalty? | ☐ Yes ☐ No | ☐ Yes ☐ No | ☐ Yes ☐ No | ☐ Yes ☐ No |
| Balloon payment? When? | | | | |
| Must I live in the property? | ☐ Yes ☐ No | ☐ Yes ☐ No | ☐ Yes ☐ No | ☐ Yes ☐ No |
| Biggest risk of this loan | | | | |

**My choice and why:** ___________________________________________________________

---

## Worksheet 4 — Tenant-Screening Scorecard

One copy per adult applicant. Apply the same criteria to every applicant.

- **Applicant name:** ______________________________  **Date:** __________________
- **Property / unit:** _______________________________  **Monthly rent:** $__________

| Criterion | Standard | Applicant's result | Pass / fail |
|---|---|---|---|
| Gross monthly income | At least 3× rent ($__________) | $__________ | ☐ Pass ☐ Fail |
| Income verified? | Pay stubs + employer call | ☐ Verified ☐ Not verified | ☐ Pass ☐ Fail |
| Credit score | Minimum __________ | __________ | ☐ Pass ☐ Fail |
| Evictions (ever) | None / none in last ____ years | __________ | ☐ Pass ☐ Fail |
| Unpaid landlord judgments | None | __________ | ☐ Pass ☐ Fail |
| Rental history (2+ years) | Verified with 2 landlords | ☐ Verified ☐ Not verified | ☐ Pass ☐ Fail |
| Prior landlord reference | Would rent again | ☐ Yes ☐ No ☐ No answer | ☐ Pass ☐ Fail |
| Previous landlord reference | Would rent again | ☐ Yes ☐ No ☐ No answer | ☐ Pass ☐ Fail |
| Background check | Per written policy | ☐ Clear ☐ Issue: __________ | ☐ Pass ☐ Fail |
| Occupants | Max __________ | __________ | ☐ Pass ☐ Fail |
| Pets | Per policy | __________ | ☐ Pass ☐ Fail |

**Overall decision:** ☐ Approve  ☐ Deny — criterion not met: ________________________

**Notes (facts only — record what you verified, not impressions):** _____________________

*Reminder: apply these criteria identically to every applicant, and comply with federal, state, and local fair housing law. When in doubt, ask a local landlord-tenant attorney.*

---

## Worksheet 5 — 12-Month Cash-Flow Planner

Fill in actuals each month. The "planned" column comes from your underwriting; the "actual" column is reality. The gap between them is your education.

| Month | Rent planned | Rent actual | Expenses planned | Expenses actual | Mortgage | Cash flow planned | Cash flow actual | Reserves balance |
|---|---|---|---|---|---|---|---|---|
| 1 | $ | $ | $ | $ | $ | $ | $ | $ |
| 2 | $ | $ | $ | $ | $ | $ | $ | $ |
| 3 | $ | $ | $ | $ | $ | $ | $ | $ |
| 4 | $ | $ | $ | $ | $ | $ | $ | $ |
| 5 | $ | $ | $ | $ | $ | $ | $ | $ |
| 6 | $ | $ | $ | $ | $ | $ | $ | $ |
| 7 | $ | $ | $ | $ | $ | $ | $ | $ |
| 8 | $ | $ | $ | $ | $ | $ | $ | $ |
| 9 | $ | $ | $ | $ | $ | $ | $ | $ |
| 10 | $ | $ | $ | $ | $ | $ | $ | $ |
| 11 | $ | $ | $ | $ | $ | $ | $ | $ |
| 12 | $ | $ | $ | $ | $ | $ | $ | $ |
| **Total** | **$** | **$** | **$** | **$** | **$** | **$** | **$** | — |

**Year-end review:**
- Total actual cash flow: $__________ vs. planned $__________ — difference: $__________
- Biggest surprise expense: ______________________________________________________
- What I will do differently next year: ______________________________________________

---

## Checklist — Making an Offer

- ☐ Deal-analysis worksheet completed; property meets my buy box
- ☐ Walk-away price calculated and written down
- ☐ Rent verified (comparables, leases, or property manager)
- ☐ Taxes verified with the county (including any post-sale reassessment)
- ☐ Insurance quote received
- ☐ Pre-approval letter and proof of funds ready
- ☐ Offer includes inspection, financing, and appraisal contingencies
- ☐ Earnest money amount decided ($__________)
- ☐ Closing timeline confirmed with my lender (__________ days)
- ☐ Agent has submitted the offer in writing

## Checklist — Closing

- ☐ Home inspection completed; I attended in person
- ☐ Sewer scope ordered (if applicable) ☐ Radon test ☐ Pest inspection
- ☐ Inspection findings negotiated (credit or price reduction: $__________)
- ☐ Appraisal received; value $__________ vs. price $__________
- ☐ Loan commitment received from lender
- ☐ Closing Disclosure reviewed line by line against the Loan Estimate
- ☐ Homeowner / landlord insurance bound, effective on closing date
- ☐ Final walkthrough completed (repairs done, appliances present, no new damage)
- ☐ Wire instructions verified by phone using a number I already had
- ☐ Funds wired / cashier's check ready
- ☐ Keys received; locks changed the same day

## Checklist — Move-In

- ☐ Lease signed by all adult occupants
- ☐ Move-in inspection completed with dated photos, signed by tenant and landlord
- ☐ First month's rent collected: $__________
- ☐ Security deposit collected: $__________ (held in separate account, per state law)
- ☐ Pet addendum signed (if applicable); pet rent $__________ / pet deposit $__________
- ☐ Renter's insurance verified (if required)
- ☐ Tenant given: keys, maintenance request instructions, emergency number, utility transfer info, trash/recycling schedule
- ☐ Smoke and CO detectors tested and documented
- ☐ Utility accounts confirmed in tenant's name (where applicable)

## Checklist — Monthly Landlord Review (do on the 5th of each month)

- ☐ All rent received? If not, where is it in the collection process?
- ☐ Late fees applied where due
- ☐ Expenses paid and recorded; any unexpected costs noted
- ☐ Reserves transfer made ($__________ to reserves account)
- ☐ Reserves balance checked against target ($__________)
- ☐ Any maintenance requests outstanding? Any scheduled this month?
- ☐ Any lease expiring in the next 90 days? Renewal plan?
- ☐ Cash-flow planner updated with actuals
- ☐ Any tenant communication needed this month?

---

*Disclaimer: This workbook is real estate education only. It is not individualized investment, legal, tax, or financial advice. Consult a qualified professional for advice about your specific situation.*
