# Buy-Box Worksheet

*From The Rental Property Blueprint — fill this in before you look at any listings. Be specific. A vague buy box is no buy box at all.*

**Disclaimer:** This worksheet is real estate education only. It is not individualized investment, legal, tax, or financial advice.

---

## What I Will Buy

- **Property type(s):** _______________________________________________________
- **Number of units:** ☐ 1  ☐ 2  ☐ 3  ☐ 4
- **Price range:** $________________ to $________________
- **Year built:** __________ or newer
- **Target neighborhoods / zip codes:** __________________________________________
- **Maximum distance from major employer / hospital / university:** ________________
- **Condition I will accept:** ☐ Rent-ready only  ☐ Cosmetic updates only  ☐ Light rehab
- **Maximum repair budget:** $________________

## What I Will NOT Buy

1. ______________________________________________________________________
2. ______________________________________________________________________
3. ______________________________________________________________________
4. ______________________________________________________________________
5. ______________________________________________________________________

## My Minimum Returns (do not negotiate with yourself later)

- **Minimum rent per unit:** $________________ per month
- **Minimum cash flow per unit:** $________________ per month (after ALL expenses, including reserves and management)
- **Minimum cash-on-cash return:** ________________%
- **Minimum DSCR:** ________________
- **Minimum 1% rule result:** ________________%
- **Maximum operating expense ratio:** ________________%

## My Tenant Profile

- **Who will rent this property?** _____________________________________________
- **Why will they stay?** (schools, jobs, hospital, university, transit): _______________
- **Maximum occupants per unit:** ________________
- **Pet policy:** ☐ No pets  ☐ Pets allowed — pet rent $__________ / pet deposit $__________

## My Capital

- **Total capital available (excluding my personal emergency fund):** $________________
- **Down payment I can afford:** $________________
- **Reserves I will keep after closing (6 months of PITI):** $________________
- **Financing route:** ☐ Conventional  ☐ FHA house hack  ☐ DSCR  ☐ Seller financing  ☐ Undecided

## My Team

- **Real estate agent:** ________________________  Phone: ____________________
- **Lender:** ________________________  Phone: ____________________
- **Property manager:** ________________________  Phone: ____________________
- **Home inspector:** ________________________  Phone: ____________________
- **Attorney:** ________________________  Phone: ____________________
- **Insurance agent:** ________________________  Phone: ____________________

## My Buy Box in One Sentence

____________________________________________________________________________

____________________________________________________________________________

**Date completed:** __________________  **Review date (6 months):** __________________
