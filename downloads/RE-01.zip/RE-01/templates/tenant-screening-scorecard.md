# Tenant-Screening Scorecard

*From The Rental Property Blueprint — one copy per adult applicant. Apply the same written criteria to every applicant, every time.*

**Disclaimer:** This scorecard is real estate education only, not legal advice. Screening must comply with federal, state, and local fair housing law. If you are unsure whether a criterion is lawful in your area, ask a local landlord-tenant attorney before using it.

---

- **Applicant name:** ________________________________  **Date:** ________________
- **Property / unit:** ________________________________  **Monthly rent:** $__________
- **Application fee collected:** $__________  **Date received:** ________________

## Criteria

| # | Criterion | My standard | Applicant's result | Pass / Fail |
|---|---|---|---|---|
| 1 | Gross monthly income | At least 3× rent = $__________ | $__________ | ☐ Pass ☐ Fail |
| 2 | Income verified | Pay stubs (last 2 months) + employer call | ☐ Verified ☐ Not verified | ☐ Pass ☐ Fail |
| 3 | Credit score | Minimum __________ | __________ | ☐ Pass ☐ Fail |
| 4 | Evictions | None / none in last ____ years | __________ | ☐ Pass ☐ Fail |
| 5 | Unpaid landlord judgments / collections | None | __________ | ☐ Pass ☐ Fail |
| 6 | Rental history | 2+ years, verifiable | ☐ Verified ☐ Not verified | ☐ Pass ☐ Fail |
| 7 | Current landlord reference | Would rent again? | ☐ Yes ☐ No ☐ No answer | ☐ Pass ☐ Fail |
| 8 | Previous landlord reference | Would rent again? | ☐ Yes ☐ No ☐ No answer | ☐ Pass ☐ Fail |
| 9 | Background check | Per written policy | ☐ Clear ☐ Issue: __________ | ☐ Pass ☐ Fail |
| 10 | Occupants | Max __________ | __________ | ☐ Pass ☐ Fail |
| 11 | Pets | Per policy | __________ | ☐ Pass ☐ Fail |
| 12 | Move-in date | On or after __________ | __________ | ☐ Pass ☐ Fail |

## Verification Notes (facts only)

- **Employer contacted:** ________________________  **Date:** __________  **Confirmed:** ☐ Yes ☐ No
- **Current landlord contacted:** ________________________  **Date:** __________  **Notes:** ________________________
- **Previous landlord contacted:** ________________________  **Date:** __________  **Notes:** ________________________

## Decision

- ☐ **APPROVE** — applicant meets all written criteria.
- ☐ **DENY** — criterion not met: #__________ (_____________________________). Applicant notified in writing on: __________
- ☐ **CONDITIONAL APPROVAL** — condition: _____________________________ (e.g., additional deposit where state law allows, co-signer). Condition met: ☐ Yes ☐ No

**Decided by:** ________________________  **Date:** ________________

**Record retention:** Keep this scorecard and the application for at least two years.
