# Federal and State Incentive Guide

## GRN-02

Incentives change often and differ by location. This guide is general education, not tax or legal advice. It tells you where to look and what to record — you must verify every program yourself, close to the date you buy, before relying on it.

---

## How to Use This Guide

1. Work through the sources below in order. It should take about 30 minutes.
2. For every program you find, record the amount, the eligibility rules, the deadline, and the date you checked it.
3. Re-check every program the week you sign a contract. Programs close, budgets run out, and rules change.
4. Never let a salesperson's statement about an incentive be your only source. Confirm it with the administering agency.
5. If a tax credit is involved, confirm with a tax professional whether you can actually use it — a non-refundable credit only offsets tax you owe.

---

## Source 1 — DSIRE (Database of State Incentives for Renewables and Efficiency)

- Website: dsireusa.org
- What to do: enter your state and look under solar / residential. Note every program listed for homeowners.
- What to record for each program: name, amount or rate, who administers it, eligibility rules, deadline, and whether funding is still available.

| Program name | Amount / rate | Administered by | Eligibility | Deadline | Date checked |
|---|---|---|---|---|---|
| | | | | | |
| | | | | | |
| | | | | | |

## Source 2 — Federal Incentives

- Website: irs.gov (search for residential clean energy or solar tax credit) and energy.gov.
- What to do: check whether a federal tax credit for residential solar currently exists, what percentage it is, what costs it covers, and when it ends. The percentage, the eligibility rules, and the end date have all changed through legislation in the past — do not rely on what a credit used to be.
- Questions to answer:
  - Is a federal credit currently available? Yes / No / Unsure
  - Current rate (if any): __________ %
  - What costs does it cover: ________________________________________
  - End date or phase-down schedule: ________________________________________
  - Do you have enough tax liability to use a non-refundable credit? Yes / No / Ask a tax professional
  - Date checked: __________

## Source 3 — Your State Energy Office

- Website: search for your state name plus "energy office" or "solar incentives".
- What to do: check for state tax credits, rebates, sales-tax exemptions, property-tax exemptions, and low-interest loan programs.
- Notes: ________________________________________

| Program name | Amount / rate | Eligibility | Deadline | Date checked |
|---|---|---|---|---|
| | | | | |
| | | | | |

## Source 4 — Your Utility

- Website: your utility's solar or renewable energy page, or call their solar interconnection team.
- What to do: ask for (a) any rebate for installing solar, (b) the export rule and export rate for electricity you send to the grid, (c) any cap on system size, (d) whether the export rules are scheduled to change, and (e) the interconnection process and timeline. Ask for the answers in writing if you can.
- Rebate available: ________________________________________
- Export rule (net metering / other): ________________________________________
- Export rate: $__________ per kWh
- System size cap: __________ kW
- Rules scheduled to change? Yes / No — Details: ________________________________________
- Date checked: __________

## Source 5 — Solar Renewable Energy Certificates (SRECs)

- Available in your state? Yes / No
- If yes: how they work, current value, and how to register: ________________________________________
- Note: SREC values fluctuate and involve registration and paperwork. Do not count SREC income in your payback maths until you have confirmed the current value and the registration process.

## Source 6 — Local Programs

- City or county incentives, property-tax exemptions, or permit-fee waivers: ________________________________________
- Homeowners' association rules or approvals needed: ________________________________________

---

## Your Incentive Summary

| Program | Amount you expect to receive | Certain or assumed? | Verified on (date) | Verified with (source) |
|---|---|---|---|---|
| | $ | | | |
| | $ | | | |
| | $ | | | |
| | $ | | | |
| **Total incentives you can actually use** | **$** | | | |

**Rule:** only incentives marked "certain" and verified within the last 30 days belong in your payback calculation. Everything else is a bonus, not a plan.
