# Installer Quote Comparison Worksheet

## GRN-02

Copy this worksheet for each installer you contact. Fill in every line from the written quote — if a line is blank, ask the installer for it in writing before you compare. Compare quotes on price per watt and on verified production, not on headline price alone.

---

## Your Independent Figures (fill in first, from Modules 2–3)

- Adjusted annual usage: __________ kWh
- Your system size from your own maths: __________ kW
- PVWatts production estimate for that size: __________ kWh/year
- Your utility's export rate: $__________ /kWh — Retail rate: $__________ /kWh

---

## Quote A

- Installer name: ________________________________________
- Contact: ________________________________________
- Years in business / local track record: ________________________________________
- References checked? Yes / No — Notes: ________________________________________
- Site visit done? Yes / No — Shade analysis done? Yes / No
- System size: __________ kW (DC)
- Panels: __________ × __________ W — Make/model: ________________________________________
- Inverter: Type __________ — Make/model: ________________________________________
- Battery included? Yes / No — Capacity: __________ kWh — Cost: $__________
- Monitoring: Panel-level / System-level
- Estimated annual production: __________ kWh/year
- Production per kW implied: __________ kWh/kW/year — PVWatts check (within 10%?): Yes / No
- Total price (before incentives): $__________
- Itemised? Yes / No — Equipment $__________ — Labour $__________ — Permits $__________ — Interconnection $__________
- **Price per watt: $__________ /W**
- Electrical panel upgrade needed? Yes / No — Cost: $__________
- Not included (roof work, tree trimming, other): ________________________________________
- Warranties — Panels (product): ______ yrs — Panels (performance): ______ yrs — Inverter: ______ yrs — Workmanship/roof: ______ yrs
- Timeline to install: __________ — Who handles permits and interconnection: __________________________
- Payment schedule: ________________________________________
- Red flags: ________________________________________

## Quote B

- Installer name: ________________________________________
- Contact: ________________________________________
- Years in business / local track record: ________________________________________
- References checked? Yes / No — Notes: ________________________________________
- Site visit done? Yes / No — Shade analysis done? Yes / No
- System size: __________ kW (DC)
- Panels: __________ × __________ W — Make/model: ________________________________________
- Inverter: Type __________ — Make/model: ________________________________________
- Battery included? Yes / No — Capacity: __________ kWh — Cost: $__________
- Monitoring: Panel-level / System-level
- Estimated annual production: __________ kWh/year
- Production per kW implied: __________ kWh/kW/year — PVWatts check (within 10%?): Yes / No
- Total price (before incentives): $__________
- Itemised? Yes / No — Equipment $__________ — Labour $__________ — Permits $__________ — Interconnection $__________
- **Price per watt: $__________ /W**
- Electrical panel upgrade needed? Yes / No — Cost: $__________
- Not included (roof work, tree trimming, other): ________________________________________
- Warranties — Panels (product): ______ yrs — Panels (performance): ______ yrs — Inverter: ______ yrs — Workmanship/roof: ______ yrs
- Timeline to install: __________ — Who handles permits and interconnection: __________________________
- Payment schedule: ________________________________________
- Red flags: ________________________________________

## Quote C

- Installer name: ________________________________________
- Contact: ________________________________________
- Years in business / local track record: ________________________________________
- References checked? Yes / No — Notes: ________________________________________
- Site visit done? Yes / No — Shade analysis done? Yes / No
- System size: __________ kW (DC)
- Panels: __________ × __________ W — Make/model: ________________________________________
- Inverter: Type __________ — Make/model: ________________________________________
- Battery included? Yes / No — Capacity: __________ kWh — Cost: $__________
- Monitoring: Panel-level / System-level
- Estimated annual production: __________ kWh/year
- Production per kW implied: __________ kWh/kW/year — PVWatts check (within 10%?): Yes / No
- Total price (before incentives): $__________
- Itemised? Yes / No — Equipment $__________ — Labour $__________ — Permits $__________ — Interconnection $__________
- **Price per watt: $__________ /W**
- Electrical panel upgrade needed? Yes / No — Cost: $__________
- Not included (roof work, tree trimming, other): ________________________________________
- Warranties — Panels (product): ______ yrs — Panels (performance): ______ yrs — Inverter: ______ yrs — Workmanship/roof: ______ yrs
- Timeline to install: __________ — Who handles permits and interconnection: __________________________
- Payment schedule: ________________________________________
- Red flags: ________________________________________

---

## Side-by-Side Summary

| | Quote A | Quote B | Quote C |
|---|---|---|---|
| System size (kW) | | | |
| Estimated production (kWh/yr) | | | |
| Production vs PVWatts | | | |
| Total price (before incentives) | | | |
| **Price per watt** | | | |
| Inverter type | | | |
| Battery included | | | |
| Workmanship warranty (yrs) | | | |
| Site visit + shade analysis | | | |

**Best quote and why:** ________________________________________

**Quote rejected and why:** ________________________________________

**Questions still to ask before signing:** ________________________________________
