# Off-Grid Starter Checklist

## GRN-02

Off-grid means your home generates, stores, and manages all of its own electricity with no utility connection. It costs substantially more than a grid-connected system and requires a different way of living with energy. Work through this checklist honestly before spending anything. If several boxes cannot be ticked, a grid-connected system with a battery for backup is usually the better choice.

---

## Step 1 — Minimise Your Loads First

Off-grid systems are sized to the smallest load you can achieve, not the largest. Every kWh you cut is a kWh of panels and batteries you do not have to buy.

- [ ] Home energy audit completed (Workbook Exercise 2)
- [ ] Adjusted annual usage: __________ kWh/year
- [ ] Daily usage in the worst winter month: __________ kWh/day
- [ ] Largest loads identified and reduced or replaced (heating, cooling, water heating, cooking)
- [ ] Always-on loads measured and trimmed
- [ ] Electric heating replaced or supplemented where practical (wood, propane, or high-efficiency heat pump — note the electricity trade-off of each)

## Step 2 — Size the Battery Bank

- [ ] Essential daily load (what must run every day, no exceptions): __________ kWh/day
- [ ] Days of autonomy required (no sun): __________ days (two to three days is a common planning figure)
- [ ] Battery capacity needed: essential daily load × days of autonomy = __________ kWh
- [ ] Battery type chosen: ________________________________________ (lithium-ion is the common modern choice; lead-acid is cheaper upfront but shorter-lived and less usable capacity)
- [ ] Usable capacity vs nameplate capacity checked (not all of a battery's rated capacity is usable): __________ kWh usable
- [ ] Battery replacement budgeted (typically every 10–15 years): $__________

## Step 3 — Size the Solar Array for the Worst Month

- [ ] Worst-month solar production per kW checked (PVWatts, monthly figures, not annual average): __________ kWh/kW in __________ (month)
- [ ] Array size for the worst month: daily load ÷ (worst-month daily production per kW) = __________ kW
- [ ] Roof or ground space for that array confirmed: __________ sq ft available / __________ sq ft needed
- [ ] Note: sizing for the worst month means the array will overproduce heavily in summer. Plan for the surplus (extra loads, water heating, or simply accept it).

## Step 4 — Plan Backup Generation

- [ ] Backup generator chosen: ________________________________________
- [ ] Generator fuel type and storage: ________________________________________
- [ ] Automatic or manual start: ________________________________________
- [ ] Generator sized to: charge batteries / run essential loads / both
- [ ] Fuel budget per year: $__________

## Step 5 — Check Rules and Practicalities

- [ ] Local rules checked: does your area allow an off-grid dwelling, or require a utility connection?
- [ ] Building permits and electrical inspection requirements confirmed
- [ ] Water supply independent of grid power (well pump needs power — plan for it)
- [ ] Internet and communications during outages planned
- [ ] Home insurance covers an off-grid system: Yes / No — confirmed with insurer

## Step 6 — Budget the Whole System

| Item | Estimated cost |
|---|---|
| Solar array (panels, racking, inverter/charger) | $ |
| Battery bank | $ |
| Backup generator | $ |
| Installation and wiring | $ |
| Permits and inspection | $ |
| Monitoring and controls | $ |
| Contingency (10–15%) | $ |
| **Total** | **$** |

- [ ] Battery replacement reserve set aside or planned
- [ ] Total compared honestly against a grid-connected system with battery backup

## Step 7 — Your Load-Shedding Plan

Write down, in advance, what stays on and what goes off when stored energy runs low. This is the plan you will actually live by in a long cloudy spell.

**Always on (essential):** ________________________________________

**On when the battery is above 50%:** ________________________________________

**Off when the battery is below 25%:** ________________________________________

---

## Decision

- [ ] I have completed every step above and the numbers work for my home and budget.
- [ ] I understand that off-grid costs more than grid-connected solar and requires active energy management.
- [ ] I have spoken to an installer experienced with off-grid systems (not only grid-connected ones) and received a written quote.

**Decision:** Proceed with off-grid / Choose grid-connected with battery backup / Delay and reconsider

**Reason:** ________________________________________
