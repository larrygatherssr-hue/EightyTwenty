# Solar Savings Masterclass: Design, Price, and Power Your Home — GRN-02

A 9-module video course and toolkit for homeowners who want solar without overpaying for it. Learn to audit your home, size a system from your own bills, choose equipment, compare installer quotes, research incentives, and calculate your real payback. **$347, one-time payment.**

## Files

| File | Description |
|---|---|
| `content.md` | The complete 9-module course (10,471 words of full instructional prose, with worked examples: system sizing, a three-quote comparison, and three payback scenarios, plus glossary and quick-reference appendices). |
| `workbook.md` | Companion workbook: home energy audit, sizing exercises, quote comparison, incentive research, payback worksheets, off-grid starter checklist, and the ten-point decision checklist. |
| `templates/solar-sizing-payback-calculator.csv` | Sizing, price-per-watt, incentive, savings, payback, and lifetime-value calculator, including the course's worked example. |
| `templates/installer-quote-comparison.md` | Line-by-line comparison worksheet for up to three installer quotes. |
| `templates/incentive-guide.md` | Federal and state incentive research guide with sources (DSIRE, IRS, state energy office, utility) and a verification checklist. |
| `templates/off-grid-starter-checklist.md` | Off-grid starter checklist: load sizing, battery sizing, backup generation, rules, and budgeting. |
| `sales-page.md` | Full sales page: headline, problem, solution, module list, who it is for / not for, price, guarantee, 8 FAQs, disclaimers. |
| `listing.json` | Marketplace listing data (SKU GRN-02, $347, one-time). |
| `cover.md` | Cover design brief (black-and-gold luxury palette, typography, imagery, layout). |
| `cover.png` | The generated cover image (1200 × 1920 px). |
| `onboarding.md` | Customer onboarding guide: first steps, how to use the materials, suggested weekend and three-week schedules, support. |
