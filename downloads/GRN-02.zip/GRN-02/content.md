# Solar Savings Masterclass: Design, Price, and Power Your Home

## GRN-02 — Complete Course Text

**Price:** $347, one-time. **Format:** Written course manual (9 modules) — the complete course text, a companion workbook, a solar sizing and payback calculator, an installer quote comparison worksheet, a federal and state incentive guide, and an off-grid starter checklist.

---

## A Note Before You Begin

This course is education, not a sales pitch, and it is not personal financial, tax, or engineering advice. Solar savings depend on your location, your roof, your electricity use, your utility's rates and rules, and the incentives available when you buy — all of which vary widely and change over time. Nothing in this course guarantees a particular saving, payback period, or return. Where this course discusses incentives, it does so as general education: you must verify the current federal, state, and local programs, amounts, eligibility rules, and deadlines yourself, using the sources listed in Module 7 and the incentive guide template, before making any purchase decision. Worked examples in this course use clearly labelled assumptions so you can follow the maths; they are illustrations, not promises about your home.

If you take one idea from this course, let it be this: the most expensive solar system is the one that is the wrong size, bought from the wrong installer, at the wrong price, because nobody taught you how to check the numbers. By the end of Module 9 you will know how to check every number yourself.

---

## Table of Contents

- **Module 1 — How Solar Actually Works:** panels, inverters, the grid, and the units that matter (kW vs kWh)
- **Module 2 — Know Your Home First:** the energy audit, reading your electricity bill, and cutting waste before you buy panels
- **Module 3 — Sizing Your System:** how big a system your home really needs, with a full worked example
- **Module 4 — Choosing Your Equipment:** panels, inverters, batteries, and what is worth paying for
- **Module 5 — Your Roof and Your Site:** orientation, tilt, shade, roof condition, and when solar does not make sense
- **Module 6 — Reading and Comparing Installer Quotes:** what a quote should contain, red flags, and a worked three-quote comparison
- **Module 7 — Costs, Incentives, and Paying for It:** cash, loans, leases, and power purchase agreements, plus how to research incentives
- **Module 8 — Payback Maths:** simple payback, lifetime value, and three full scenarios worked through
- **Module 9 — Going Off-Grid (or Almost) and Going Live:** off-grid basics, the installation process, monitoring, and maintenance

---

## Module 1 — How Solar Actually Works

### 1.1 The simple version

A solar panel turns sunlight into direct current (DC) electricity. An inverter turns that DC electricity into alternating current (AC) electricity, which is what your home uses. When your panels produce more than your home needs, the extra flows out to the grid; when they produce less — at night, for example — your home draws electricity from the grid as usual. A meter tracks both directions. That is the whole system, in one paragraph. Everything else in this course is detail about getting the size, the equipment, the price, and the paperwork right.

### 1.2 The two units you must never confuse

Solar salespeople rely on customers confusing two units. Do not be that customer.

- **Kilowatt (kW)** is a rate — how much power a system can produce at a given moment. A system's size is quoted in kW. A "6 kW system" can produce up to 6,000 watts in ideal conditions.
- **Kilowatt-hour (kWh)** is an amount of energy — power used over time. Your electricity bill charges you per kWh. A 6 kW system running at full power for one hour produces 6 kWh.

Think of it like a tap and a bucket. kW is how wide the tap is open. kWh is how much water ends up in the bucket. Your bill is for buckets, not taps. A system is sold by the size of its tap, but it saves you money by filling buckets. Both numbers matter, and Module 3 shows you how to connect them.

Two more terms you will meet constantly:

- **Nameplate capacity** is the system's rated size in kW under standard test conditions — laboratory conditions that your roof will rarely match exactly. Real output is usually lower, and that is normal.
- **Production estimate** is how many kWh per year the system is expected to produce at your location. This is the number that drives your savings. Always ask for it in writing, and always ask what assumptions it is based on.

### 1.3 The parts of a system

**Solar panels.** The visible part. Modern residential panels are typically rated at 350–450 watts each, so a 6 kW system needs roughly 14–17 panels. Panels are rated for 25 years of warranted production and often keep working well beyond that, producing gradually less each year. Degradation of around 0.5% per year is typical — a panel producing 100 units in year one might produce about 90 units in year twenty. Ask any installer for the panel's degradation rate and its product and performance warranties, in writing.

**Inverter.** The box that converts DC to AC. There are three common approaches:

- **String inverters** serve a whole row of panels at once. They are the least expensive option and work well on unshaded roofs, but one shaded or underperforming panel can drag down the whole string.
- **Microinverters** sit behind each panel, so each panel works independently. They cost more, but they handle shade and mixed roof angles better, and they make it easy to see each panel's output.
- **Power optimisers** are a middle ground: a small device on each panel paired with a central inverter.

There is no single right answer. The right inverter depends on your roof's shade and layout, which Module 5 covers.

**Racking and mounting.** The rails and brackets that hold panels to your roof. Unremarkable, but important: poor mounting causes leaks. A good installer warranties their roof work — ask how long that warranty lasts and what it covers.

**Monitoring.** Most modern systems come with an app showing production per panel or per system, daily and monthly. Monitoring matters more than most buyers realise: it is how you discover, months later, that a panel has stopped producing. Check the monitoring before you sign, not after.

**Batteries (optional).** A battery stores excess daytime solar energy for use at night or during an outage. Batteries add significant cost and are not necessary for a grid-connected system to save money. Module 4 explains when a battery is worth it and when it is not.

### 1.4 What happens to the electricity

During a sunny day, your panels produce electricity, your home uses what it needs, and the surplus goes to the grid. Your utility credits you for that surplus under a policy called **net metering** or a similar export arrangement — but the rules, and the value of the credit, differ enormously by state and utility. Some utilities credit exported electricity at the full retail rate; others credit it at a much lower wholesale rate; some have moved to time-of-use rates where electricity is worth more at certain hours. This single policy difference can change your payback by years, which is why Module 8 runs scenarios rather than giving you one answer.

At night, the process reverses: your home draws from the grid, and you pay the normal rate. You do not need a battery to use solar at night — the grid acts as your storage, under whatever export rules your utility applies. That is the standard arrangement for most homeowners, and it is the arrangement this course focuses on.

### 1.5 What solar cannot do

Honesty first. Solar panels do not produce electricity at night. They produce less on cloudy days and in winter, when days are short. They do not make your home immune to grid outages unless you have a battery or a backup system — a standard grid-connected system shuts down during an outage for safety, so that it does not feed electricity into lines that repair crews are working on. Solar does not eliminate your electricity bill in most cases; it reduces it, and the size of the reduction depends on your system, your usage, and your utility's rules. A salesperson who promises a zero bill forever, or a fixed payback period with no caveats, is selling, not advising.

### Module 1 — Key takeaways

- kW is system size; kWh is energy produced and billed. Never let anyone blur the two.
- The production estimate (kWh per year) is the number that drives your savings — get it in writing.
- Batteries are optional for grid-connected homes; they buy backup power, not savings, in most cases.
- Your utility's export rules matter as much as your roof. Learn them before you buy.

---

## Module 2 — Know Your Home First: The Energy Audit

### 2.1 Why audit before you buy

Every kilowatt of solar you buy exists to cover electricity you actually use. If your home wastes electricity, you will buy a bigger system than you need — and pay for it for 25 years. The cheapest kilowatt-hour is the one you never use. A home energy audit is the unglamorous step that can save you thousands, and it costs little or nothing.

### 2.2 Reading your electricity bill

Gather twelve months of electricity bills before you talk to any installer. You need three numbers from them:

1. **Total kWh used per year.** Add up all twelve months. This is your annual usage — the foundation of your system size. A typical American home uses roughly 10,000–11,000 kWh per year, but the range is enormous: a small efficient apartment might use 4,000 kWh, a large home with electric heating, a pool, and two electric vehicles might use 20,000 kWh or more. Your number is the only one that matters.
2. **Your average price per kWh.** Divide your total annual bill (in dollars) by your total annual kWh. This blends together fixed charges, tiered rates, and taxes into one useful number. Be careful: many bills also include a fixed monthly service charge (often $10–$20) that solar will not eliminate. When you calculate savings, use the per-kWh rate, not the total bill.
3. **Your seasonal pattern.** Note your highest and lowest months. Summer air conditioning, winter electric heating, and pool pumps create peaks. A system sized to your annual average will overproduce in mild months and underproduce in peak months — that is normal, and net metering or your utility's export rules smooth it out over the year. But if your usage is about to change — a new electric vehicle, a heat pump, a home extension, children leaving home — size for the home you will have, not the home you had.

**Worked example — the Alvarez household.** The Alvarez family lives in a three-bedroom house and used 9,600 kWh over the last twelve months. Their total annual bill was $1,632, so their blended rate is $1,632 ÷ 9,600 = $0.17 per kWh. Their fixed service charge is $12 per month, or $144 per year, which solar will not remove. Their usage peaks in July and August (air conditioning) at around 1,100 kWh per month and falls to about 600 kWh per month in spring. Keep this household in mind: the worked sizing example in Module 3 and the payback scenarios in Module 8 are built on their numbers, so you can see one consistent story from audit to payback.

### 2.3 Finding the waste

Walk through your home with the workbook's energy audit and look for the big loads first. In most homes, heating and cooling dominate, followed by water heating, then laundry and kitchen appliances, then lighting and electronics.

- **Heating and cooling.** Check your thermostat settings and your insulation. A home that leaks conditioned air through gaps, thin attic insulation, or old windows is paying to heat the outdoors. Sealing air leaks and adding attic insulation are often the cheapest energy investments you will ever make, and they shrink the solar system you need.
- **Water heating.** A water heater set above 120°F (49°C) wastes energy. Shorter showers and a water-heater blanket on an older tank help. If your water heater is electric and old, its replacement is a decision that interacts with solar sizing — a heat-pump water heater uses far less electricity than a standard electric one.
- **Lighting.** If you still have incandescent bulbs anywhere, replace them with LEDs. It is a small saving per bulb, but across a whole house it adds up, and it is nearly free.
- **The always-on load.** Many homes have a constant background draw of 100–300 watts from devices that never truly switch off: televisions on standby, chargers, routers, game consoles, old appliances. Over a year, 200 watts running constantly is 1,752 kWh — roughly 18% of the Alvarez household's annual use. A plug-in energy monitor, borrowed or bought cheaply, can find the worst offenders in an afternoon.
- **The big one-off loads.** A pool pump running twelve hours a day, an old second fridge in the garage, a hot tub, an electric vehicle — each of these can use as much as a whole room of the house. Decide deliberately whether each one stays, and size your system accordingly.

### 2.4 The efficiency-first rule

Before you accept any system size, complete the audit and act on the cheap fixes. As a rule of thumb, if the audit finds more than 10% of your usage in easily fixable waste, fix it first and then re-run your annual usage number. An installer who wants to sell you a system sized to your current wasteful usage is not doing you a favour. The workbook's audit sheet walks you through this step by step and ends with a single number: your **adjusted annual usage** — the figure your system will be sized to.

### 2.5 Planning for future changes

Write down every change you expect in the next five years that will move your electricity use:

- Buying an electric vehicle (typically adds 2,000–4,000 kWh per year, depending on mileage)
- Replacing a gas furnace or water heater with an electric heat pump
- Adding air conditioning, a pool, or a hot tub
- A home extension or a new occupant
- Children leaving home (usage falls)

You do not have to size for all of it today — panels can usually be added later, though at extra cost and with a second round of paperwork. But a system that is too small for the home you will have in three years is a disappointment you can avoid by planning now. Note your expected changes in the workbook; Module 3 shows how to handle them in the sizing maths.

### Module 2 — Key takeaways

- Twelve months of bills give you annual kWh, blended price per kWh, and seasonal pattern. Get these before talking to installers.
- Fix cheap waste first — especially heating, cooling, and always-on loads — then size the system to your adjusted usage.
- Separate the fixed monthly service charge from the per-kWh rate: solar reduces the per-kWh part, not the fixed charge.
- Write down expected future changes in usage before you size anything.

---

## Module 3 — Sizing Your System

### 3.1 The sizing formula

System sizing is simple arithmetic once you have the inputs. The formula is:

**System size (kW) = Annual usage (kWh) ÷ Annual production per kW installed (kWh per kW per year)**

The second number — how many kWh one installed kW produces in a year at your location — is the key variable. It depends on sunlight, roof angle, orientation, shade, and local weather. In the sunnier parts of the United States it is often around 1,400–1,700 kWh per kW per year; in cloudier northern areas it may be 1,000–1,200. Your installer's production estimate is their version of this number: if they quote a 6 kW system producing 9,000 kWh per year, they are assuming 1,500 kWh per kW per year. Always divide their production estimate by their system size and ask whether that figure is realistic for your location and roof. A free public tool such as PVWatts, run by the U.S. National Renewable Energy Laboratory, lets you check any production estimate yourself in ten minutes — Module 3.5 shows you how.

### 3.2 The offset question: 100% is not always the target

Sizing to cover 100% of your annual usage sounds ideal, but it is not always the best financial choice. Under generous net metering, where every exported kWh earns full retail credit, 100% offset makes sense. Under less generous export rules, where exported electricity earns only a fraction of the retail rate, the last few panels — the ones whose output you mostly export rather than use yourself — earn far less than the first ones. In that case, sizing to 70–90% of annual usage can pay back faster. The right target depends on your utility's rules and your daytime usage pattern, which is why this course teaches you to calculate rather than to copy a rule of thumb.

### 3.3 Worked example — sizing for the Alvarez household

Recall the Alvarez household from Module 2: **9,600 kWh per year**, blended rate $0.17 per kWh, fixed charge $12 per month. They live in a sunny southern location. Three different installers will quote them in Module 6; first, let us size the system ourselves.

**Step 1 — Adjusted usage.** The Alvarez audit found an old garage fridge using about 700 kWh per year and a pool pump running longer than necessary, wasting about 500 kWh per year. They remove the fridge and re-time the pump, saving 1,200 kWh per year. Adjusted annual usage: 9,600 − 1,200 = **8,400 kWh**.

**Step 2 — Production per kW.** Using PVWatts for their location and a south-facing roof at a typical tilt, they find a realistic figure of **1,500 kWh per kW per year**.

**Step 3 — System size for 100% offset.** 8,400 ÷ 1,500 = **5.6 kW**. In practice, systems are built from whole panels: at 400 watts per panel, 5.6 kW needs 14 panels (5.6 kW exactly). So a 14-panel, 5.6 kW system is the 100%-offset design.

**Step 4 — Check the roof.** Each panel is roughly 18 square feet, so 14 panels need about 250 square feet of suitable roof, plus space for access and setbacks required by local fire codes. The Alvarez south-facing roof section has about 400 square feet available — plenty of room.

**Step 5 — Sanity-check against the installers.** When the quotes arrive in Module 6, the Alvarez family will compare each installer's proposed size and production estimate against this independent 5.6 kW figure. Any quote far above or below it needs an explanation.

**What if they add an electric vehicle?** A car driven 12,000 miles a year at roughly 3.5 miles per kWh uses about 3,400 kWh per year. Adding that to the adjusted usage: (8,400 + 3,400) ÷ 1,500 = **7.9 kW**, or about 20 panels. That is a materially bigger — and more expensive — system, and it is a decision to make deliberately, not to discover after signing.

### 3.4 Panel count and roof space

A quick reference for planning:

| System size | Panels at 400 W each | Approximate roof area needed |
|---|---|---|
| 4 kW | 10 | ~180 sq ft |
| 6 kW | 15 | ~270 sq ft |
| 8 kW | 20 | ~360 sq ft |
| 10 kW | 25 | ~450 sq ft |

These are planning figures, not installation drawings. Setbacks, chimneys, vents, and roof shape all reduce usable space, and your installer should produce a proper layout drawing before you sign.

### 3.5 Checking a production estimate with PVWatts

PVWatts (pvwatts.nrel.gov) is a free calculator from the U.S. National Renewable Energy Laboratory. Enter your address, draw your roof area or enter its tilt and direction, enter a system size, and it returns an estimated annual production. Use it to check every installer quote: enter the quoted system size, tilt, and direction, and compare PVWatts' annual kWh figure with the installer's. If the installer's figure is more than about 10% above PVWatts, ask them to explain the difference in writing. Optimistic production estimates are one of the most common ways a bad deal is dressed up as a good one.

### 3.6 Common sizing mistakes

- **Sizing to the highest month instead of the annual total.** A system that covers your July air-conditioning peak will overproduce massively in spring. Size to the annual total.
- **Sizing to the pre-audit usage.** Fix the waste first (Module 2), then size.
- **Accepting a round number without maths.** "Most people get 10 kW" is not a sizing method. Your home's number comes from your bills.
- **Ignoring future changes.** An electric vehicle or a heat pump changes everything. Plan for it or plan to expand later.
- **Forgetting the roof.** A system your roof cannot hold, or that shades itself, is a system that will never produce what the quote promised.

### Module 3 — Key takeaways

- System size = annual kWh ÷ kWh produced per kW per year at your location.
- Check every production estimate against PVWatts before you believe it.
- 100% offset is not always the best financial target — it depends on your utility's export rules.
- Size to adjusted usage, after the audit, and with future changes written down.

---

## Module 4 — Choosing Your Equipment

### 4.1 Panels: what actually differs

Most modern residential panels are good. The differences that matter are smaller than the marketing suggests, and they are all on the datasheet — which you should ask to see.

**Efficiency.** The percentage of sunlight a panel converts to electricity. Residential panels typically range from about 19% to 23%. Higher efficiency matters mainly when roof space is limited: a 22% efficient panel produces more from the same roof area than a 19% one. If you have ample roof space, paying a large premium for the highest efficiency rarely pays back.

**Temperature coefficient.** Panels lose output as they get hotter. The temperature coefficient, expressed as a percentage per degree Celsius (for example, −0.35%/°C), tells you how much. In hot climates a better (less negative) coefficient is worth real money over 25 years. In mild climates it matters less.

**Warranties — two of them.** Every panel carries a **product warranty** (typically 12–25 years, covering defects) and a **performance warranty** (typically 25 years, guaranteeing a minimum output, often around 85–92% of original output after 25 years). Read both. A long performance warranty from a manufacturer that may not exist in ten years is worth less than a shorter one from an established company — ask how long the manufacturer has been in business.

**What not to overpay for.** Brand prestige, marginal efficiency gains on a large roof, and cosmetic features such as all-black frames are the usual places buyers overspend. They are fine to want — but know you are paying for preference, not production.

### 4.2 Inverters: string, microinverter, or optimiser

From Module 1, the three options:

- **String inverters** are cheapest and simplest, with one central unit. Best for a simple, unshaded, single-direction roof. Their warranty is often 10–12 years (shorter than panels), so budget for a replacement during the system's life — a cost many quotes quietly omit.
- **Microinverters** cost more upfront but handle shade, multiple roof directions, and panel-level monitoring. Their warranties are often 25 years. They suit complex roofs.
- **Power optimisers** with a central inverter sit between the two on price and capability.

The honest way to choose: if your roof is simple and unshaded, a string inverter usually wins on value. If your roof has shade, dormers, or panels facing two directions, panel-level electronics usually earn their premium. Ask each installer to justify their inverter choice against your roof, not against a brochure.

### 4.3 Batteries: when they pay and when they do not

A home battery typically stores 10–15 kWh — roughly a night's worth of essential use, not a whole home's. A single battery plus installation commonly costs several thousand dollars on top of the solar system. Batteries make sense when:

- You experience frequent or long outages and value backup power highly.
- Your utility charges much more for electricity in the evening (time-of-use rates) than during the day, so storing daytime solar for evening use saves real money.
- Your utility pays very little for exported electricity, so using your own stored power beats selling it cheaply.

Batteries usually do **not** pay for themselves quickly when your utility offers full retail net metering and your grid is reliable — in that case the grid is already your free battery. Be wary of any salesperson who presents a battery as a money-saver without showing the maths for your utility's rates. Batteries also have their own lifespan (often around 10 years) and their own warranty — factor a replacement into any long-term calculation.

### 4.4 What a good equipment list looks like

Before signing, you should be able to write down, from the quote: the panel make and model, the number of panels, the panel wattage, the inverter make and model, whether a battery is included (and its capacity), the monitoring system, and the warranty length for each item. If a quote says only "premium panels" or "top-tier inverter" without a make and model, it is not a quote — it is a promise. Module 6 gives you the checklist to demand the specifics.

### Module 4 — Key takeaways

- Read the panel datasheet: efficiency, temperature coefficient, and both warranties.
- Match the inverter to your roof: string for simple unshaded roofs, microinverters or optimisers for shade and complexity.
- Batteries buy backup power and time-of-use arbitrage, not automatic savings. Do the maths for your utility.
- Get every component named by make and model in writing before you sign.

---

## Module 5 — Your Roof and Your Site

### 5.1 Direction and tilt

In the northern hemisphere, a south-facing roof generally produces the most total energy over the year. But "most energy" and "most value" are not always the same thing. A west-facing roof produces less total energy but more of it in the late afternoon, when many households use the most electricity and when time-of-use rates are often highest. East-facing roofs produce well in the morning. North-facing roofs in the northern hemisphere are usually poor for solar and often not worth covering.

Tilt matters less than most people think. A roof pitched between roughly 15 and 40 degrees performs well in most of the United States. Flat roofs can work too, with tilted racking. Do not let anyone sell you an expensive tilt-up system on a steep roof for a marginal gain — ask for the production estimate with and without it, and judge whether the extra cost earns its keep.

### 5.2 Shade: the silent killer

Shade is the single most underestimated factor in residential solar. A small amount of shade at the wrong time of day — a chimney shadow in winter, a neighbour's tree in the afternoon — can cut a panel's output sharply, and with a string inverter it can drag down the whole row. A proper site assessment measures shade across the year, not just on the day the salesperson visits. Ask for a shade analysis (a sun-path report or similar) for your roof, and be suspicious of any quote prepared without one. If a large tree shades your best roof section, compare the cost of trimming it (where allowed) with the cost of the lost production.

### 5.3 Roof condition: the question to ask first

Solar panels last 25 years or more. Your roof should too — or you will pay to remove and reinstall the panels when the roof needs replacing, a cost that commonly runs into thousands of dollars. Before you buy solar, answer honestly: how old is your roof, and how much life does it have left? If your roof is more than 15 years old, or shows wear, get a roofer's opinion before you sign a solar contract. Replacing the roof first is an extra cost, but it is far cheaper than removing and reinstalling a system later. A reputable installer will ask about your roof's age; one who never mentions it is a warning sign.

### 5.4 Roof type and structure

Most asphalt shingle roofs are straightforward for solar. Tile, slate, and metal roofs can all host solar, but the mounting methods and costs differ, and tile roofs in particular require an installer experienced with that material — a cracked tile is a leak. Flat roofs need ballasted or tilted racking and careful attention to drainage. If your roof is unusual, get a quote from an installer who has done that roof type before, and ask for references for similar jobs.

Your roof must also be structurally able to carry the panels. Panels and racking add weight — typically around 3–5 pounds per square foot. Most modern roofs handle this easily, but older homes or unusual structures may need an engineer's check. Your installer should confirm this as part of the site assessment, not after installation begins.

### 5.5 When solar does not make sense

A good course tells you when not to buy. Solar may be a poor investment for your home if several of these apply: your roof is heavily shaded most of the day; your roof is old and due for replacement and you cannot afford to do both; your electricity use is very low; your utility pays almost nothing for exported electricity and charges very little for power; you expect to move within a few years (a system rarely adds its full cost to a home's sale price in the short term, though it often adds some value); or your homeowners' association or local rules restrict installation and you cannot get approval. Working through this course honestly may lead you to delay or decline solar — and that is a successful outcome if it saves you from a bad purchase.

### Module 5 — Key takeaways

- South-facing is best for total energy; west-facing can be best for value under time-of-use rates.
- Get a proper shade analysis. Shade is the most common reason real production falls short of the quote.
- If your roof has less than 15–20 years of life left, deal with the roof first.
- Knowing when solar does not make sense is as valuable as knowing when it does.

---

## Module 6 — Reading and Comparing Installer Quotes

### 6.1 Get at least three quotes

This is the highest-value advice in the whole course: get at least three quotes from different installers, and compare them on paper, not from memory. Prices for the same system commonly vary by thousands of dollars between installers in the same area, and the cheapest quote is not always the best — nor is the most expensive. You need the quotes side by side, in the same format, which is exactly what the installer quote comparison worksheet in the templates folder is for.

Where to find installers: ask neighbours who have solar, check your state's solar association or consumer protection listings, and look for installers with several years of local history and verifiable reviews. Be cautious with door-to-door sales and with any company that pressures you to sign on the first visit. A legitimate installer will leave a written quote and let you compare it.

### 6.2 What every quote must contain

A complete quote lists:

1. **System size in kW (DC)** and the number, make, model, and wattage of the panels.
2. **Inverter make, model, and type** (string, microinverter, or optimiser).
3. **Estimated annual production in kWh**, with the assumptions behind it (location data, tilt, direction, shade).
4. **Total price**, itemised: equipment, labour, permits, interconnection fees, and any battery or extras — separately, not as one lump sum.
5. **Price per watt** (total price ÷ system watts). This is the single most useful comparison figure. As a broad planning range, residential solar in the United States commonly costs roughly $2.50–$3.50 per watt before incentives, but prices vary by region, roof complexity, and equipment. Use the range as a sanity check, not a target: a quote far above it needs justification, and a quote far below it needs scrutiny.
6. **Warranties**: panel product and performance, inverter, battery (if any), and — critically — the installer's workmanship and roof-penetration warranty, with its length.
7. **Timeline**: how long until installation, and who handles permits and utility interconnection.
8. **What is not included**: roof repairs, tree trimming, electrical panel upgrades, and any other likely extra — each with a price or a clear statement that it will be quoted separately.

If a quote is missing any of these, ask for it in writing before you compare. A quote that cannot be compared is a quote designed not to be compared.

### 6.3 Red flags

- **A quote given without a site visit or a shade analysis.** Production estimates made from satellite images alone are a starting point, not a final design.
- **Pressure to sign today** for a discount that expires at the end of the visit. Real incentives do not work that way.
- **No price per watt, or a refusal to itemise.** You cannot compare what you cannot see.
- **Production estimates far above PVWatts** with no explanation.
- **Vague equipment descriptions** ("premium panels") with no make or model.
- **A lease or power purchase agreement presented as if it were a purchase**, or described as "free solar" — see Module 7. Nothing about solar is free; someone always pays, and you need to know who.
- **A company with no local track record** and no local office or references you can check.

### 6.4 Worked example — comparing three quotes for the Alvarez household

Recall the Alvarez design from Module 3: a **5.6 kW** system producing about **8,400 kWh per year** at 1,500 kWh per kW. Here are three quotes they received. All prices are before any incentive, so they can be compared fairly.

**Quote A — Sunward Solar (local, 8 years in business).** 14 × 400 W panels (5.6 kW), string inverter, estimated production 8,300 kWh per year. Total price $16,800, itemised. Price per watt: $16,800 ÷ 5,600 = **$3.00/W**. Warranties: panels 25-year product and performance, inverter 12 years, workmanship 10 years. Timeline: 6–8 weeks. Electrical panel upgrade not needed. Roof age confirmed fine.

**Quote B — BrightHome Energy (national chain).** 16 × 400 W panels (6.4 kW), microinverters, estimated production 9,800 kWh per year. Total price $22,400. Price per watt: $22,400 ÷ 6,400 = **$3.50/W**. Warranties: panels 25 years, microinverters 25 years, workmanship 5 years. Timeline: 10–12 weeks. The quote includes a battery "at a special price" of $8,000, presented as part of the package, though the Alvarez family did not ask for one.

**Quote C — Value Solar Co. (new local company, 1 year in business).** 14 × 400 W panels (5.6 kW), string inverter, estimated production 9,600 kWh per year. Total price $13,400. Price per watt: $13,400 ÷ 5,600 = **$2.39/W**. Warranties: panels 25 years, inverter 10 years, workmanship 2 years. The quote was prepared from satellite images only, with no site visit and no shade analysis. Timeline: "2–3 weeks."

**Analysis.** Quote C is cheapest, but its production estimate (9,600 kWh from a 5.6 kW system) implies 1,714 kWh per kW per year — well above the PVWatts figure of 1,500 and above Quote A's 1,482. It was prepared without a site visit, the company is a year old, and the workmanship warranty is only two years. The low price may be real, but the production claim is not credible and the warranty is thin.

Quote B is the most expensive per watt, oversizes the system (6.4 kW against a 5.6 kW need), and bundles an $8,000 battery the family did not request. The microinverters are a genuine advantage on a shaded roof, but the Alvarez roof is unshaded, so that premium buys little. The 25-year inverter warranty is valuable, but not worth the overall premium once the unnecessary battery is removed.

Quote A matches the independent sizing, its production estimate is consistent with PVWatts, its price per watt sits in the normal range, its workmanship warranty is the longest, and the company has a local track record. The Alvarez family chooses Quote A — not because it is cheapest, but because it is the only quote whose numbers check out on every line. They also note the string inverter's 12-year warranty and budget for a replacement in year 12–15, rather than being surprised by it later.

That is the skill this module teaches: not finding the lowest number, but finding the quote whose numbers survive checking.

### Module 6 — Key takeaways

- Get at least three written quotes and compare them in the same format.
- Price per watt is your main comparison figure; production estimates must be checked against PVWatts.
- A missing item on a quote is a warning, not a detail.
- The best quote is the one whose numbers check out — not the cheapest and not the most expensive.

---

## Module 7 — Costs, Incentives, and Paying for It

### 7.1 What a system costs

The total cost of a residential solar system is the equipment (panels, inverter, racking, monitoring, and battery if any), the labour, permits, interconnection fees, and any extras such as an electrical panel upgrade. For the Alvarez 5.6 kW system at $3.00 per watt, the total is $16,800 before incentives. A 6 kW system at the same rate would be $18,000; an 8 kW system, $24,000. These are planning figures: your quotes are the real numbers, and Module 6 taught you how to judge them.

Costs that buyers forget: an electrical panel upgrade (commonly $1,000–$3,000 if your panel is old or full), roof work discovered during installation, tree trimming, and — for string inverters — an inverter replacement after 10–15 years. Ask each installer to state in writing whether a panel upgrade is needed and what it will cost.

### 7.2 Incentives: general education — verify everything

Incentives can reduce the cost of solar substantially, but they change often, and they differ by country, state, utility, and year. Treat everything in this section as a starting point for your own research, not as a statement of what is available to you today.

**Federal incentives (United States).** The United States has, at various times, offered a federal tax credit for residential solar installations, calculated as a percentage of the system's cost. The percentage, the eligibility rules, and the end date have all changed over the years through legislation, and a credit that exists today may be reduced, changed, or ended by the time you buy. Before relying on any federal credit: check the current rules on the IRS website and the Database of State Incentives for Renewables and Efficiency (DSIRE), confirm whether the credit applies to your situation (for example, whether you have enough tax liability to use it, since a non-refundable credit only offsets tax you owe), and consider speaking to a tax professional. Never let a salesperson's statement about a tax credit be your only source. The worked examples in Module 8 use an assumed credit purely to show the maths — the assumption is labelled, and you must substitute the figure that actually applies to you, if any.

**State and local incentives.** These vary enormously: some states offer tax credits, rebates, or exemptions from sales or property tax; some utilities offer rebates; some areas have none at all. Solar renewable energy certificates (SRECs) exist in some states and can provide additional income, but their value fluctuates and they involve registration and paperwork. Use DSIRE (dsireusa.org) to find the programs in your state, then confirm each one directly with the administering agency — programs close, budgets run out, and eligibility rules change.

**Net metering and export rules.** As covered in Module 1, what your utility pays for exported electricity matters as much as any upfront incentive. Ask your utility directly: what is the export rate, is there a cap on system size, and are the rules scheduled to change? Get the answer in writing if you can.

**How to research incentives in 30 minutes.** The incentive guide template in this product gives you a checklist: check DSIRE for your state, check your utility's website for rebates and export rules, check your state energy office, and note the amount, the eligibility rules, the deadline, and the source for each program you find. Fill it in before you sign anything, and re-check it the week you sign — a program that existed last month may have changed.

### 7.3 Paying for it: cash, loan, lease, or power purchase agreement

**Cash.** Paying outright gives you the lowest total cost: no interest, no fees, and you own the system and its incentives. It also means the largest upfront outlay. If you can afford it, cash is usually the best financial choice — but only you know your finances.

**Solar loan.** A loan spreads the cost over 5–20 years. Compare loans on the total amount you will repay, not the monthly payment: a low monthly payment over 20 years can cost far more in interest than a higher payment over 10. Watch for dealer fees — some solar loans include a fee of 15–30% of the loan amount, baked into the quoted price, which is why a cash price and a loan price for the same system can differ by thousands of dollars. Always ask for the cash price and the loan price separately, and ask for the loan's annual percentage rate, term, fees, and total repayment in writing.

**Lease.** You rent the system from a company, paying a monthly fee, usually with little or no upfront cost. You do not own the system, you usually do not receive the tax credits or incentives (the leasing company does), and selling your home with a leased system can complicate the sale — the buyer must agree to take over the lease. Leases can make sense for homeowners who cannot use a tax credit and do not want to own equipment, but read the escalation clause: many leases raise the monthly payment each year.

**Power purchase agreement (PPA).** Similar to a lease, but you pay for the electricity the system produces, per kWh, rather than a flat monthly fee. The same cautions apply: you do not own the system, incentives go to the system owner, and the per-kWh rate usually rises each year under an escalation clause. Compare the PPA rate, and its escalator, against your utility's current rate and its expected increases — a PPA that starts below your utility rate can end up above it.

**The rule for all four:** get the total cost over the full term in writing, including every fee and every annual increase, and compare that total against the cash price. A monthly payment that looks small can hide a large total.

### 7.4 The total-cost comparison

For the Alvarez household's $16,800 system (Quote A), the four options look roughly like this — these are illustrative figures, not quotes, and your numbers will differ:

- **Cash:** $16,800 upfront (before any incentive that may apply). Total cost: $16,800.
- **Loan (10 years, illustrative):** total repaid, including interest and fees, might be roughly $21,000–$23,000 depending on rate and fees. Total cost: the full repayment.
- **Lease (20 years):** monthly payments starting around $110–$130 and rising annually could total roughly $30,000 or more over 20 years, and you own nothing at the end.
- **PPA (20 years):** paying per kWh at a starting rate below the utility rate, with an annual escalator, could total a similar figure to the lease over 20 years — and again, you own nothing at the end.

Ownership is usually the better long-term financial outcome, which is why this course steers most homeowners towards cash or a loan. But the right answer depends on your finances, your tax situation, and how long you will stay in the home — run your own numbers before deciding.

### Module 7 — Key takeaways

- Incentives change. Verify federal, state, and local programs yourself, close to the date you buy, using DSIRE, the IRS, and your utility.
- A tax credit only helps if you owe enough tax to use it — confirm your situation with a tax professional.
- For any loan, lease, or PPA, get the total cost over the full term in writing, including fees and annual increases.
- Cash or a loan usually beats a lease or PPA over the long term, because you own the system and keep the incentives.

---

## Module 8 — Payback Maths

### 8.1 Simple payback: the first number everyone asks for

Simple payback answers one question: how many years until the money the system saves equals the money it cost? The formula is:

**Simple payback (years) = Net system cost ÷ Annual savings**

Net system cost is the total price minus any incentive you actually receive. Annual savings is the value of the electricity the system produces that you use or export, minus any ongoing costs. Both numbers are estimates, and small changes in either move the answer by years — which is why this module runs three scenarios instead of giving one number.

A note on what simple payback leaves out: it ignores the time value of money, future electricity price changes, inverter replacement, and the value of the system after payback. It is a useful first check, not a complete financial analysis. For a fuller picture, also calculate the lifetime value in Section 8.5.

### 8.2 Annual savings: how to calculate it honestly

Annual savings has two parts:

1. **Electricity you no longer buy.** The kWh your system produces that your home uses directly, valued at your retail electricity rate.
2. **Electricity you export.** The kWh your system produces beyond your immediate use, valued at your utility's export rate — which may be the full retail rate, or much less.

From these, subtract ongoing costs: any fixed service charge you still pay (solar rarely eliminates it), and a small allowance for maintenance and, for string inverters, a future replacement spread across the years.

A common mistake is valuing all production at the retail rate. That is only correct under full retail net metering. If your utility pays a lower export rate, the exported share must be valued at that lower rate — and the difference can be thousands of dollars over the system's life.

### 8.3 Scenario A — Full retail net metering (the favourable case)

**Assumptions (labelled, for illustration):** The Alvarez household buys the Quote A system: 5.6 kW, $16,800, producing 8,300 kWh per year. Their retail rate is $0.17 per kWh and their utility credits exports at the full retail rate. Assume, for illustration only, that a federal tax credit of 30% applies and that they have enough tax liability to use it — you must verify whether any credit applies to you.

- Net cost: $16,800 − (30% × $16,800) = $16,800 − $5,040 = **$11,760**.
- Annual savings: 8,300 kWh × $0.17 = **$1,411** per year. (Under full net metering, every kWh is worth the retail rate, so the split between used and exported does not matter.)
- Simple payback: $11,760 ÷ $1,411 = **8.3 years**.
- Without any credit, payback would be $16,800 ÷ $1,411 = **11.9 years**.

### 8.4 Scenario B — Low export rate (the common reality)

**Assumptions:** Same system and cost as Scenario A, same 30% credit assumption. But this utility credits exports at only $0.04 per kWh, while the retail rate remains $0.17. The Alvarez family uses about 60% of their solar production directly during the day and exports 40%.

- Electricity used directly: 60% × 8,300 = 4,980 kWh × $0.17 = $846.60.
- Electricity exported: 40% × 8,300 = 3,320 kWh × $0.04 = $132.80.
- Annual savings: $846.60 + $132.80 = **$979.40** per year.
- Simple payback: $11,760 ÷ $979.40 = **12.0 years**.
- Without any credit: $16,800 ÷ $979.40 = **17.2 years**.

The same panels, the same roof, the same sunshine — and payback stretches by nearly four years, purely because of the export rate. This is why Module 1 insisted you learn your utility's rules before buying. It also shows why using more of your solar power during the day (running the dishwasher, laundry, and water heater in daylight hours) matters more under a low export rate: every kWh you use yourself is worth $0.17, while every kWh you export is worth $0.04.

**What if the Alvarez family shifts usage?** If they move enough daytime load to use 80% of production directly instead of 60%, the maths changes: 6,640 kWh × $0.17 = $1,128.80, plus 1,660 kWh × $0.04 = $66.40, for annual savings of $1,195.20 and a payback of $11,760 ÷ $1,195.20 = **9.8 years**. Behaviour is free, and under a low export rate it is worth more than extra panels.

### 8.5 Scenario C — High electricity prices and rising rates

**Assumptions:** A household in an area with expensive electricity at $0.32 per kWh, buying a 6.5 kW system for $19,500 producing 9,500 kWh per year, under full retail net metering, with the same illustrative 30% credit assumption.

- Net cost: $19,500 − $5,850 = **$13,650**.
- Annual savings in year one: 9,500 × $0.32 = **$3,040**.
- Simple payback: $13,650 ÷ $3,040 = **4.5 years**.
- If electricity prices rise by 3% a year, savings grow each year and the real payback is shorter still — but do not count on price rises when you decide. A system that only pays back if prices rise sharply is a speculation, not an investment.

Scenario C shows why solar is far more compelling in high-price areas than in cheap-electricity areas, and why national averages and national advertising claims are useless for your decision. Your rate, your roof, your rules.

### 8.6 Lifetime value: looking past payback

Payback is the beginning of the story, not the end. A system that pays back in 10 years and then runs for another 15 years at minimal cost produces 15 years of largely free electricity. To estimate lifetime value:

1. Estimate total production over 25 years, allowing for degradation of about 0.5% per year. A system producing 8,300 kWh in year one produces roughly 7,400 kWh in year twenty-five, and about 195,000 kWh in total over 25 years.
2. Value that production at a realistic average rate — not today's rate, and not a fantasy rate. If you assume an average of $0.20 per kWh across the system's life under full net metering, lifetime value is roughly 195,000 × $0.20 = $39,000, against a net cost of $11,760 in Scenario A.
3. Subtract lifetime costs: an inverter replacement for string systems (budget roughly $1,500–$2,500 in today's money), occasional maintenance, and any monitoring subscription.
4. The remainder is the rough lifetime benefit — before tax effects and before any change in your home's value.

These are planning estimates with wide error bars. Present them to yourself as a range, never as a single confident figure, and never let a salesperson's lifetime-savings chart be the only analysis you see.

### 8.7 Sensitivity: what moves the answer most

Run your own numbers three ways — optimistic, central, and pessimistic — changing one variable at a time:

- **Production 10% lower than quoted.** Payback stretches by roughly a year in most scenarios. This is why verifying the production estimate matters.
- **No incentive available.** Payback stretches by three to four years in the Alvarez scenarios. Never buy on the assumption of an incentive you have not verified.
- **Electricity prices flat instead of rising.** Payback stretches modestly; the system still pays back if the central case is sound.
- **An inverter replacement in year 12.** Adds roughly a year to payback for string-inverter systems; budget for it from day one.

If the pessimistic case still looks acceptable to you, the decision is robust. If only the optimistic case works, wait, get better quotes, or reconsider.

### Module 8 — Key takeaways

- Simple payback = net cost ÷ annual savings. Both numbers are estimates — run scenarios, not a single figure.
- Value exported electricity at your utility's actual export rate, not the retail rate, unless you have full retail net metering.
- Shifting daytime usage matters enormously under a low export rate.
- Check the pessimistic case. If only the optimistic case works, the deal is not good enough.

---

## Module 9 — Going Off-Grid (or Almost) and Going Live

### 9.1 What off-grid really means

An off-grid home generates, stores, and manages all of its own electricity, with no connection to the utility at all. That means solar panels, a large battery bank, usually a backup generator, and a completely different approach to energy: you must produce enough in the worst week of winter, not the average week of the year, and you must manage demand ruthlessly. Off-grid living is a lifestyle choice as much as a technical one, and it costs substantially more than a grid-connected system for the same home. Most homeowners who ask about off-grid are better served by a grid-connected system with a battery for backup — the arrangement covered in Section 9.2.

### 9.2 The middle path: grid-connected with backup

A grid-connected system with a battery and a backup panel gives you the best of both worlds for most homes: you sell surplus to the grid under normal conditions, and during an outage the battery powers essential circuits — fridge, lights, internet, a few outlets, and medical equipment if applicable. Decide in advance which circuits are essential, because a single battery cannot run a whole home, and certainly not air conditioning, electric heating, or an electric oven for long. A load-shedding plan — a written list of what stays on and what goes off in an outage — is part of the design, not an afterthought.

### 9.3 Off-grid starter checklist

If you are seriously considering off-grid, work through the checklist in the templates folder before spending anything. In brief: audit and minimise your loads first (off-grid systems are sized to the smallest load you can achieve, not the largest); size the battery bank for at least two to three days of autonomy in winter; size the solar array for the worst month, not the annual average; plan a backup generator and its fuel; check local rules — some areas require a utility connection or restrict off-grid dwellings; and budget for battery replacement every 10–15 years. The checklist gives you each step with space to record your own numbers.

### 9.4 The installation process, step by step

1. **Contract and design.** You sign, the installer produces final engineering drawings, and you confirm the panel layout, inverter location, and monitoring.
2. **Permits.** The installer applies for a building permit and any electrical permit. This can take days or weeks depending on your area.
3. **Utility interconnection.** The installer applies to your utility to connect the system. The utility may need to upgrade your meter.
4. **Installation.** The physical work usually takes one to three days for a typical home: racking, panels, inverter, wiring, and monitoring.
5. **Inspection.** A local inspector checks the work against code. If anything fails, the installer corrects it.
6. **Permission to operate.** The utility gives final approval and swaps or reprograms your meter. Only then should the system be switched on for export. Do not let anyone switch the system on before permission to operate — it can create safety and billing problems.
7. **Monitoring setup.** The installer shows you the monitoring app, confirms every panel is reporting, and hands over warranties, manuals, and the final paperwork. Get all of this before making the final payment.

### 9.5 After installation: monitoring and maintenance

**Check monitoring weekly for the first month, then monthly.** Look for a panel producing far less than its neighbours, or days with zero production that are not explained by weather. Early detection is the difference between a warranty claim and a year of lost production.

**Keep panels reasonably clean.** In most areas rain does most of the work. If you live in a dusty area or near trees that drop sap or pollen, an occasional gentle rinse helps — never use abrasive tools or walk on the panels. If your roof is steep or high, hire someone; a fall costs more than any cleaning saves.

**Watch the inverter.** String inverters typically last 10–15 years; budget for replacement. Microinverters typically last longer. If the inverter shows an error, note the code and contact the installer — do not open it yourself.

**Keep your paperwork.** Warranties, the interconnection agreement, the inspection certificate, and the final invoice are the documents you will need for a warranty claim, an insurance claim, or a home sale. Store them where you can find them in ten years, not just ten days.

**Insurance.** Tell your home insurer about the system. Most policies cover it once notified, sometimes with a small premium change. An unreported system can complicate a claim.

### 9.6 Your decision checklist

Before you sign anything, confirm you can answer yes to each of these:

- I know my annual usage and my adjusted usage after the audit.
- I have an independent system size from my own maths, checked against PVWatts.
- I have at least three written quotes with price per watt, production estimates, and full equipment lists.
- I have verified the production estimates and the installers' warranties and track records.
- I have researched current incentives myself and know which ones I can actually use.
- I have compared cash, loan, lease, and PPA on total cost, and I know which I am choosing and why.
- I know my utility's export rules and how they affect my payback.
- I have run optimistic, central, and pessimistic payback scenarios, and the pessimistic one is still acceptable.
- My roof has enough life left, and I know what is not included in the quote.
- I have not signed under pressure, and I have had time to compare.

If you can answer yes to all ten, you are ready. If not, the step you cannot answer is your next step — not a signature.

---

## Your Outcome

You started this course unable to tell a good solar quote from a bad one. You finish it able to audit your home, size a system, judge equipment, read a roof, compare three quotes line by line, research incentives, choose how to pay, and calculate payback under three scenarios. That is the whole skill. Use it once to buy well, and keep the calculator and worksheets for the day you add panels, add a battery, or help a neighbour do the same.

One final reminder, because it matters more than any formula in this course: no one will ever care as much about your money as you do. The installer, the salesperson, and the finance company all have their own interests. Your interest is a system that is the right size, at the right price, that produces what it promised, for decades. Now you know how to check.

---

*This course is general education only. It is not financial, tax, legal, or engineering advice. Incentive programs, utility rules, prices, and regulations change — verify current details with the relevant agency, your utility, and a qualified professional before making a purchase. Savings and payback figures in worked examples are illustrations based on stated assumptions, not guarantees.*

---

## Appendix A — Glossary

- **AC (alternating current):** The type of electricity your home uses and the grid supplies.
- **DC (direct current):** The type of electricity solar panels produce.
- **kW (kilowatt):** A measure of power — system size. 1 kW = 1,000 watts.
- **kWh (kilowatt-hour):** A measure of energy — power used over time. Your bill charges per kWh.
- **Nameplate capacity:** A panel's or system's rated size under standard test conditions.
- **Degradation:** The gradual decline in a panel's output over time, typically around 0.5% per year.
- **String inverter:** A central inverter serving a whole row (string) of panels.
- **Microinverter:** A small inverter behind each individual panel.
- **Power optimiser:** A device on each panel that optimises its output, paired with a central inverter.
- **Net metering:** A billing arrangement under which exported electricity earns credit against electricity you import. Rules and rates vary by utility and state.
- **Export rate:** The price your utility pays (or credits) for electricity your system sends to the grid.
- **Time-of-use rate:** An electricity price that varies by time of day, usually higher in the evening peak.
- **Interconnection:** The process of connecting your system to the utility grid, including application and approval.
- **Permission to operate (PTO):** The utility's final approval to switch the system on and export electricity.
- **SREC (solar renewable energy certificate):** A tradable certificate representing the environmental benefit of solar generation, available in some states.
- **Offset:** The percentage of your annual electricity use that your system is designed to cover.
- **Price per watt:** Total system price divided by system size in watts — the main figure for comparing quotes.
- **Simple payback:** Net system cost divided by annual savings, in years.
- **DSIRE:** The Database of State Incentives for Renewables and Efficiency (dsireusa.org), the standard starting point for researching incentives in the United States.
- **PVWatts:** A free production calculator from the U.S. National Renewable Energy Laboratory (pvwatts.nrel.gov).

## Appendix B — Quick Reference: The Numbers to Know Before You Sign

| Number | Where it comes from | What good looks like |
|---|---|---|
| Annual usage (kWh) | Twelve months of bills, after the audit | Your number, not an average |
| Blended rate ($/kWh) | Total annual bill ÷ total annual kWh | Know it to the cent |
| Production per kW (kWh/kW/year) | PVWatts for your location and roof | Roughly 1,000–1,700 in the US, by region |
| System size (kW) | Annual kWh ÷ production per kW | Matches your own maths |
| Price per watt ($/W) | Quote total ÷ system watts | Commonly about $2.50–$3.50 before incentives |
| Production estimate (kWh/year) | The quote, checked against PVWatts | Within about 10% of PVWatts |
| Export rate ($/kWh) | Your utility, in writing | Know it before you size |
| Net cost | Total price minus incentives you can actually use | Verified, not assumed |
| Simple payback (years) | Net cost ÷ annual savings | Acceptable in the pessimistic case too |
| Workmanship warranty (years) | The quote, in writing | Longer is better; 10 years is a good benchmark |

## Appendix C — Sources to Check

- **PVWatts** (pvwatts.nrel.gov) — free production estimates from the National Renewable Energy Laboratory.
- **DSIRE** (dsireusa.org) — federal, state, and local incentive listings.
- **Your utility's website** — export rules, interconnection process, and rebates.
- **The IRS website** — current federal tax credit rules, if any apply.
- **Your state energy office** — state programs and consumer guidance.
- **Your local building department** — permit requirements and inspection rules.

Check each of these close to the date you buy. Programs, rates, and rules change, and a source checked six months ago is not a source checked today.
