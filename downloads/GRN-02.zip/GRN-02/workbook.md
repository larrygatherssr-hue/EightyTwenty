# Solar Savings Masterclass — Companion Workbook

## GRN-02

Work through this workbook alongside the course. Print it or copy it into a notebook or spreadsheet. Every exercise ends with a number you will use later — by the final page you will have your system size, your best quote, and your payback range in your own handwriting.

---

## Exercise 1 — Your Electricity Bills (Module 2)

Collect twelve months of bills. Fill in each month's kWh and total charge.

| Month | kWh used | Total bill ($) |
|---|---|---|
| 1 | | |
| 2 | | |
| 3 | | |
| 4 | | |
| 5 | | |
| 6 | | |
| 7 | | |
| 8 | | |
| 9 | | |
| 10 | | |
| 11 | | |
| 12 | | |
| **TOTAL** | **__________ kWh** | **$__________** |

**Your blended rate:** total bill ÷ total kWh = $__________ per kWh

**Your fixed monthly service charge (from the bill):** $__________ per month

**Highest month:** __________ kWh in __________

**Lowest month:** __________ kWh in __________

---

## Exercise 2 — Home Energy Audit (Module 2)

Walk through your home and record what you find. For each item, note the action and the estimated annual saving in kWh (use a plug-in energy monitor for always-on loads, or your best estimate).

### Heating and cooling

- Thermostat setting (summer): __________ °F — (winter): __________ °F
- Attic insulation depth/condition: ________________________________________
- Drafts or air leaks found: ________________________________________
- Action: ________________________________________ — Estimated saving: ______ kWh/year

### Water heating

- Water heater type and age: ________________________________________
- Temperature setting: __________ °F (120°F is usually enough)
- Action: ________________________________________ — Estimated saving: ______ kWh/year

### Lighting

- Number of non-LED bulbs remaining: __________
- Action: ________________________________________ — Estimated saving: ______ kWh/year

### Always-on loads

List devices that never switch off. Measure each with a plug-in monitor where you can.

| Device | Watts (standby/on) | Estimated kWh/year |
|---|---|---|
| | | |
| | | |
| | | |
| | | |
| **Total always-on** | | **______ kWh/year** |

### Big one-off loads

| Load (pool pump, second fridge, hot tub, EV, etc.) | Hours/day | Estimated kWh/year | Keep, cut, or replace? |
|---|---|---|---|
| | | | |
| | | | |
| | | | |

**Total audit savings:** __________ kWh/year

**Your adjusted annual usage:** total annual kWh (Exercise 1) − audit savings = __________ kWh/year

---

## Exercise 3 — Future Changes (Module 2)

| Expected change | When | Effect on annual usage (kWh) |
|---|---|---|
| e.g. Electric vehicle (~12,000 miles/year) | | + ~3,400 |
| | | |
| | | |
| | | |
| | | |

**Usage to size for (adjusted usage + expected additions):** __________ kWh/year

---

## Exercise 4 — System Sizing (Module 3)

1. Adjusted annual usage (from Exercise 2/3): __________ kWh
2. Production per kW per year at your location (from PVWatts): __________ kWh/kW/year
3. System size: usage ÷ production per kW = __________ kW
4. Panels needed (system kW × 1,000 ÷ panel wattage): __________ panels at __________ W each
5. Roof area needed (panels × ~18 sq ft): __________ sq ft
6. Usable roof area available: __________ sq ft — Does it fit? Yes / No

**Target offset:** __________ % (100% under full retail net metering; 70–90% may pay back faster under a low export rate — see Module 3.2)

**PVWatts check:** PVWatts estimate for your size, tilt, and direction: __________ kWh/year

---

## Exercise 5 — Roof and Site Assessment (Module 5)

- Roof direction(s) available: ________________________________________
- Roof tilt: __________ degrees
- Roof age: __________ years — Roof life remaining (roofer's opinion): __________ years
- Roof material: ________________________________________
- Shade analysis done? Yes / No — Who did it: __________________________
- Shade sources (trees, chimney, neighbour's building): ________________________________________
- Electrical panel age and capacity: ________________________________________ — Upgrade needed? Yes / No — Cost: $__________
- Structural check needed? Yes / No

**Decision:** Roof ready / Roof work needed first / Solar not suitable (note why): ________________________________________

---

## Exercise 6 — Equipment Choices (Module 4)

Record the equipment from your preferred quote, then judge it against your roof.

| Item | Make and model | Key figures | Your judgement |
|---|---|---|---|
| Panels | | Wattage: ______ W; Efficiency: ______ %; Temp. coefficient: ______ %/°C; Product warranty: ______ yrs; Performance warranty: ______ yrs | |
| Inverter | | Type: string / microinverter / optimiser; Make/model: ______; Warranty: ______ yrs | |
| Battery (if any) | | Capacity: ______ kWh; Warranty: ______ yrs; Cost: $______ | |
| Monitoring | | Panel-level / system-level | |

**Is a battery justified for your home?** (Frequent outages? Time-of-use rates? Low export rate?) ________________________________________

---

## Exercise 7 — Quote Comparison (Module 6)

Use one row per quote. Full detail goes in `templates/installer-quote-comparison.md`.

| | Quote A | Quote B | Quote C |
|---|---|---|---|
| Installer | | | |
| Years in business | | | |
| System size (kW) | | | |
| Panels (make/model/count) | | | |
| Inverter (type/make/model) | | | |
| Estimated production (kWh/yr) | | | |
| Production per kW (kWh/kW/yr) | | | |
| PVWatts check (within 10%?) | | | |
| Total price (before incentives) | | | |
| **Price per watt** | | | |
| Workmanship warranty (yrs) | | | |
| Timeline | | | |
| Extras / not included | | | |
| Site visit and shade analysis done? | | | |

**Best quote and why:** ________________________________________

**Red flags found:** ________________________________________

---

## Exercise 8 — Incentives Research (Module 7)

Fill in from DSIRE, the IRS, your state energy office, and your utility. Verify each item close to the date you buy.

| Program | Amount / rate | Eligibility | Deadline | Source and date checked |
|---|---|---|---|---|
| Federal tax credit (if any applies) | | | | |
| State incentive | | | | |
| Local / utility rebate | | | | |
| Sales or property tax exemption | | | | |
| SRECs (if available) | | | | |

**Your utility's export rule:** ________________________________________

**Export rate:** $__________ per kWh — **Retail rate:** $__________ per kWh

---

## Exercise 9 — Paying for It (Module 7)

| Option | Upfront cost | Total cost over full term | You own the system? | Incentives go to | Annual increases? |
|---|---|---|---|---|---|
| Cash | | | Yes | You | — |
| Loan | | | Yes | You | |
| Lease | | | No | Leasing company | |
| PPA | | | No | System owner | |

**Your choice and why:** ________________________________________

---

## Exercise 10 — Payback Worksheets (Module 8)

### Your central case

- System cost (before incentives): $__________
- Incentives you can actually use: − $__________
- **Net cost:** $__________
- Annual production: __________ kWh
- Share used directly: __________ % — valued at $__________ /kWh = $__________
- Share exported: __________ % — valued at $__________ /kWh = $__________
- **Annual savings:** $__________
- **Simple payback:** net cost ÷ annual savings = __________ years

### Your optimistic case (production 10% higher, incentives confirmed)

- Net cost: $__________ — Annual savings: $__________ — **Payback:** __________ years

### Your pessimistic case (production 10% lower, no incentive, inverter replacement budgeted)

- Net cost: $__________ — Annual savings: $__________ — **Payback:** __________ years

**Is the pessimistic case still acceptable?** Yes / No — **Your decision:** ________________________________________

### Lifetime value (rough estimate)

- Total production over 25 years (allowing ~0.5%/year degradation): __________ kWh
- Average value per kWh over the system's life: $__________
- Lifetime value: $__________
- Less lifetime costs (inverter replacement, maintenance): − $__________
- **Rough lifetime benefit:** $__________

---

## Exercise 11 — Decision Checklist (Module 9)

Tick each box only when you can honestly answer yes.

- [ ] I know my annual usage and my adjusted usage after the audit.
- [ ] I have an independent system size from my own maths, checked against PVWatts.
- [ ] I have at least three written quotes with price per watt, production estimates, and full equipment lists.
- [ ] I have verified the production estimates and the installers' warranties and track records.
- [ ] I have researched current incentives myself and know which ones I can actually use.
- [ ] I have compared cash, loan, lease, and PPA on total cost, and I know which I am choosing and why.
- [ ] I know my utility's export rules and how they affect my payback.
- [ ] I have run optimistic, central, and pessimistic payback scenarios, and the pessimistic one is still acceptable.
- [ ] My roof has enough life left, and I know what is not included in the quote.
- [ ] I have not signed under pressure, and I have had time to compare.

**Signed off on (date):** __________

---

## Exercise 12 — After Installation

- Installation date: __________
- Permission to operate received: __________
- Monitoring app set up and every panel reporting: Yes / No
- Warranties, manuals, inspection certificate, and final invoice filed: Yes / No
- Home insurer notified: Yes / No
- First-month production check (date and kWh): __________
- Notes: ________________________________________
