# Welcome — Solar Savings Masterclass

## GRN-02

Thank you for purchasing the Solar Savings Masterclass. This guide tells you what you received, what to do first, and how to use the materials so you finish ready to buy solar with confidence.

---

## What You Received

| File | What it is |
|---|---|
| `content.md` | The complete 9-module course text — the full instructional content of the course, with worked examples. |
| `workbook.md` | The companion workbook: energy audit, sizing exercises, quote comparison, incentive research, payback worksheets, and the decision checklist. |
| `templates/solar-sizing-payback-calculator.csv` | A spreadsheet for your system size, price per watt, incentives, savings, payback, and lifetime value — including the course's worked example. |
| `templates/installer-quote-comparison.md` | A line-by-line comparison worksheet for up to three installer quotes. |
| `templates/incentive-guide.md` | A research checklist for federal, state, and local incentives, with sources and verification steps. |
| `templates/off-grid-starter-checklist.md` | A step-by-step checklist for anyone seriously considering off-grid solar. |
| `sales-page.md` | The product sales page (for reference). |
| `listing.json` | The marketplace listing data for this product. |
| `cover.md` / `cover.png` | The cover design brief and the cover image. |

---

## What to Do First

1. **Read Module 1 and Module 2 of `content.md`.** They explain how solar works and how to read your electricity bills. Do not skip these — everything later depends on them.
2. **Gather twelve months of electricity bills.** You need your total annual kWh, your blended price per kWh, and your seasonal pattern. This takes about fifteen minutes and is the foundation of the whole course.
3. **Open the workbook and complete Exercises 1 and 2** (bills and energy audit). You will finish with your adjusted annual usage — the single number your system will be sized to.
4. **Bookmark PVWatts (pvwatts.nrel.gov) and DSIRE (dsireusa.org).** You will use both before you sign anything.

---

## How to Use the Materials

- **Course text and workbook together.** Each module in `content.md` has a matching exercise in `workbook.md`. Read a module, then do its exercise before moving on. The numbers you write down in the workbook are the numbers you will use to judge installer quotes.
- **Calculator.** Use `templates/solar-sizing-payback-calculator.csv` whenever you have a real quote in hand. Enter the quote's size, price, and production estimate, then your own usage and your utility's rates, and it will show you price per watt, net cost, annual savings, and payback — including optimistic and pessimistic cases. The worked example from the course is included so you can check your maths against it.
- **Quote comparison worksheet.** Fill in one section per installer as quotes arrive. Do not compare quotes from memory — put them side by side on paper.
- **Incentive guide.** Work through it before you sign, and re-check every program the week you sign. Only incentives you have verified within the last 30 days belong in your payback calculation.
- **Off-grid checklist.** Only if you are seriously considering off-grid. For most homeowners, a grid-connected system with a battery for backup (Module 9) is the better choice.

---

## Suggested Schedule

**Weekend plan (two days):**

- **Saturday morning:** Modules 1–2 and Workbook Exercises 1–3 (bills, audit, future changes).
- **Saturday afternoon:** Modules 3–5 and Workbook Exercises 4–6 (sizing, equipment, roof).
- **Sunday morning:** Modules 6–7 and Workbook Exercises 7–9 (quotes, incentives, paying for it).
- **Sunday afternoon:** Module 8 and Workbook Exercise 10 (payback scenarios). Request quotes from at least three installers.
- **Following week:** Module 9 and Workbook Exercises 11–12 when quotes arrive; complete the decision checklist before signing.

**Three-week plan (one module every two to three days):** work through one module and its workbook exercise at a time, and request installer quotes after Module 5 so they arrive while you are studying Modules 6–8.

Either pace works. The important thing is to complete the workbook exercises with your own numbers before you sign anything.

---

## Tips for Getting the Most from the Course

- **Use your own numbers, not the course's examples.** The Alvarez household in the worked examples is there to show you the method. Your bills, your roof, and your utility's rules are the numbers that decide your purchase.
- **Do the pessimistic case.** A system that only pays back in the optimistic scenario is not a good deal. Run all three scenarios in Module 8 before deciding.
- **Do not sign under pressure.** A legitimate installer will leave a written quote and let you compare it. If anyone pressures you to sign on the first visit, walk away and compare their quote against two others.
- **Keep your paperwork.** Once you buy, file your warranties, interconnection agreement, inspection certificate, and final invoice where you can find them in ten years.

---

## How to Get Support

For help with your order or the course files, email the marketplace support address with your order number and a description of the issue, and the support team will respond.

For questions about your home, your roof, your taxes, or your utility's rules, speak to a qualified local professional — a licensed installer for technical questions, a tax professional for tax questions, and your utility for export and interconnection questions. This course is general education, not professional advice, and it cannot answer questions specific to your home.

---

## Your Goal

By the end of this course you will be able to audit your home, size a system, judge equipment, read a roof, compare three quotes line by line, research incentives, choose how to pay, and calculate your payback under three scenarios. That is the whole skill — and it is the difference between a solar system that pays for itself and one that costs you thousands more than it should.
