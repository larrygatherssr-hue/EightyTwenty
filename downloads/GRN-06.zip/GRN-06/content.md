# The Sustainable Fashion Founder: Build an Ethical Clothing Brand

**SKU:** GRN-06 | **Category:** Green Living & Sustainability | **Price:** $297 (one-time)

**Headline:** Launch an ethical clothing brand — source sustainably, cost honestly, and prove it.

---

## Who This Programme Is For

This programme is for fashion entrepreneurs and designers who want to launch an eco-friendly clothing brand without greenwashing. You may be a designer with sketches and no supply chain, a career-changer who loves clothes and hates waste, or a small maker ready to turn a side project into a real label. No prior fashion-industry experience is assumed, and no large budget is required to begin — but this is not a get-rich-quick scheme. Building a clothing brand takes capital, patience, and honest work, and this programme tells you the truth about all three.

## What You Will Be Able To Do When You Finish

By the end of the nine modules you will be able to:

1. Define a brand position that is specific, believable, and defensible — not a vague promise to "be sustainable."
2. Choose materials with a clear understanding of their real environmental trade-offs, costs, and care requirements.
3. Find, contact, and vet suppliers, and read a fabric or factory claim with a sceptical, informed eye.
4. Cost a garment from fabric to freight, set a retail price that actually covers your costs, and know your margin before you order a single unit.
5. Plan a small, focused first collection that you can afford to produce and that a real customer will understand in ten seconds.
6. Make ethical claims that are specific, evidenced, and legal — and avoid the greenwashing traps that destroy small brands.
7. Tell a brand story that earns trust, and launch with a marketing plan you can execute on a small budget.
8. Read your first sales honestly, decide what to reorder, and plan the next collection without gambling the business.

## How To Use This Programme

Work through the modules in order. Each module ends with actions to complete before moving on, and the companion workbook (`workbook.md`) gives you the worksheets to do them in. The templates folder holds the tools you will reuse for every collection: the garment costing calculator, the supplier vetting checklist, the materials sourcing directory, and the brand story worksheet. Expect to spend roughly two to four hours per module, plus the time to contact real suppliers and get real quotes. The programme is designed to be completed over about 90 days alongside a normal job — see the 90-day action plan in the workbook.

A note on numbers: every worked example in this programme uses realistic, illustrative figures based on typical small-batch production. Prices for fabric, labour, and freight vary widely by country, order size, and season. Always replace the example numbers with your own quotes before making a decision. Nothing in this programme guarantees income, sales, or profit. Results depend on your market, your capital, your product, and your effort.

---

## Table of Contents

- Module 1 — Foundations: What "Sustainable Fashion" Actually Means
- Module 2 — Your Brand: Positioning, Customer, and the Promise You Can Keep
- Module 3 — Materials: Fibres, Fabrics, and the Truth About Each One
- Module 4 — Sourcing: Finding and Vetting Suppliers Without Getting Burned
- Module 5 — Costing and Pricing: The Maths That Decides Whether You Survive
- Module 6 — Designing Your First Collection: Small, Focused, Sellable
- Module 7 — Honest Claims: Certifications, Labelling, and Avoiding Greenwashing
- Module 8 — Brand Story and Ethical Marketing: Earning Trust and Being Found
- Module 9 — Launch, Sell, Learn: Your First 90 Days in the Market
- Appendix A — Glossary of Materials and Certifications
- Appendix B — Supplier Email Scripts
- Appendix C — Launch Budget Template (Illustrative)
- Disclaimer

---

## Module 1 — Foundations: What "Sustainable Fashion" Actually Means

### 1.1 Why most new "sustainable" brands fail before they start

Most new ethical fashion brands do not fail because their founders care too little. They fail because they start with a slogan instead of a system. "Sustainable," "eco-friendly," and "conscious" are not product specifications. A customer cannot verify a slogan, a retailer cannot stock one, and a journalist cannot write about one without asking the awkward follow-up question: sustainable how, compared with what, and proven by whom?

The brands that survive their first two years tend to share four habits. First, they pick one or two specific problems to solve — for example, eliminating virgin polyester from their range, or paying a documented living wage at their factory — rather than claiming to solve everything. Second, they know their unit economics before they order stock. Third, they can name their suppliers and show evidence for their claims. Fourth, they design clothes people actually want to wear, at a price those people can actually pay. Sustainability is the reason to choose your brand over a similar one. It is rarely, on its own, the reason someone buys a garment. Fit, quality, style, and price still decide the purchase.

### 1.2 The lifecycle of a garment

To make honest decisions you need to see the whole life of a garment, not just the fibre it is made from. A garment's environmental impact is spread across at least six stages:

1. **Raw material production** — growing cotton, raising sheep, extracting oil for synthetics, or processing wood pulp for regenerated fibres. Water use, land use, chemicals, and energy all matter here.
2. **Fibre and fabric processing** — spinning, weaving or knitting, dyeing, and finishing. Dyeing and finishing are often the most chemically intensive stages, and the ones a founder knows least about.
3. **Cutting and sewing** — the factory stage. Energy use, worker conditions, wages, and cutting waste (typically 10–20% of fabric in a conventional cut) all count.
4. **Transport** — fabric to factory, factory to warehouse, warehouse to customer. Air freight has a far larger footprint than sea freight, and is far more expensive.
5. **Use** — how the customer washes, dries, and wears the garment. A garment washed hot and tumble-dried weekly has a very different lifetime footprint from one washed cold and line-dried. Durability matters enormously here: a shirt worn 100 times spreads its production impact far more thinly than one worn five times.
6. **End of life** — resale, repair, recycling, or landfill. Most clothing today is not recycled into new clothing; blended fibres are particularly hard to recycle.

The practical lesson is that no single choice makes a garment "sustainable." A recycled-polyester jacket sewn in a factory with poor labour conditions is not an ethical product. An organic cotton T-shirt that falls apart after ten washes is not an environmental win. Your job as a founder is to improve as many stages as you realistically can, be honest about the ones you cannot yet fix, and keep improving.

### 1.3 The three pillars, in plain language

Sustainability in fashion is usually described in three pillars. Keep them as a checklist, not a slogan.

**Environmental.** Reduce harm to air, water, soil, and climate across the lifecycle above. This includes choosing lower-impact fibres, reducing waste, avoiding hazardous chemicals, and designing for longevity and repair.

**Social.** The people who make your clothes must be safe, paid fairly, and free from forced or child labour. This is not a branding extra. It is the minimum. If you cannot verify conditions at your factory, you cannot claim your brand is ethical, however green the fabric is.

**Economic.** Your business must make enough money to keep going and to keep paying its suppliers fairly. A brand that loses money on every sale and collapses after one season helps no one — not its workers, not its customers, and not the environment, because its unsold stock still exists. Profit is not the enemy of ethics. Profit is what lets you keep being ethical.

### 1.4 The greenwashing trap — and why honesty is a business strategy

Greenwashing means making an environmental claim that is vague, exaggerated, or untrue. The classic examples are everywhere: a collection labelled "conscious" because one garment in twenty uses some organic cotton; a "recycled" claim based on a lining that is 5% of the product; a picture of a forest next to a polyester dress. Regulators in the UK, the EU, and the US have all tightened the rules on this, and the direction of travel is clear: vague green claims are increasingly treated as misleading advertising, with fines and forced corrections as consequences.

For a small brand, the damage is worse than a fine. You have no marketing budget to rebuild trust. One exposed exaggeration can end you. The good news is that honesty is cheap and powerful. A founder who says "our T-shirts are made from certified organic cotton, sewn in a factory we have visited, and we are still working on recycled packaging — here is what we have done and what we have not" will be believed far more readily than a founder who claims perfection. Specific, modest, evidenced claims beat grand, vague ones every time. Module 7 covers this in detail, including the exact words to use and avoid.

### 1.5 Your starting position: an honest audit

Before you design anything, audit where you actually stand. Answer these questions in writing, in the workbook:

- What can you personally do well — design, sewing, marketing, numbers, photography?
- What do you not know yet, and who could teach you or do it for you?
- How much money can you realistically put into a first collection without risking rent or debt you cannot afford? Be specific. A real number, not a hope.
- How many hours a week can you give this for the next six months?
- What is the smallest version of this brand that would still feel real to you? Three T-shirts? Five pieces? One perfect shirt?

Many founders discover at this stage that their first collection should be much smaller than they imagined — and that is good news. A small, excellent first collection that sells through is worth far more than a large one that sits in boxes.

### Module 1 Actions

1. Complete the Brand Positioning Worksheet (Workbook, Worksheet 1) — draft only; you will refine it in Module 2.
2. Write your one-paragraph honest audit: skills, money, time, and the smallest real version of your brand.
3. List three fashion brands you admire and, for each, write down one specific thing they do well and one thing you would do differently.

---

## Module 2 — Your Brand: Positioning, Customer, and the Promise You Can Keep

### 2.1 Positioning is a choice, not a description

Positioning is the answer to a customer's unspoken question: "Why should I buy this instead of the ten similar things I just saw?" A brand that tries to be for everyone ends up meaning nothing to anyone. Your positioning has four parts:

- **Who it is for.** One specific customer, described as a real person with a life, a budget, and a wardrobe problem — not "women aged 25–45."
- **What problem it solves.** The gap in their wardrobe or their values that your product fills.
- **How it is different.** The one or two things you do that competitors do not, stated in a way a customer can check.
- **What it costs.** The price band you will live in, and why that price is fair.

**Worked example.** Consider a fictional founder, Maya, launching a small label in Manchester. Her customer is "Priya, 34, a primary school teacher who cycles to work, buys two or three good pieces a year, and is tired of work trousers that wear out at the thigh within a season." The problem: durable, comfortable, smart-looking workwear in natural fibres, in sizes that fit a real body, that lasts more than a year. The difference: trousers made from a heavyweight organic cotton twill with reinforced seams and a free repair service for two years. The price: £95–£120 per pair, explained openly on the product page with a cost breakdown. That is a position. "Sustainable fashion for modern women" is not.

### 2.2 Know your customer like a person, not a segment

Build a customer profile from observation, not imagination. Talk to at least ten people who resemble your intended customer. Ask what they bought recently, what they paid, what frustrated them, and what they wish existed. You are not selling to them yet; you are listening. Record the exact words they use — those words will become your product descriptions later, because customers trust language that sounds like their own thinking.

Pay attention to budget. A customer who says they care about sustainability but buys a £12 dress every month is not your customer yet, and that is fine. Your customer is the person whose actual spending matches your price. If your garment costs £85 to make well, your customer is someone who already spends £85 or more on a similar item, or who is willing to buy fewer, better things. Do not build a business on the hope that people will change their spending habits for you.

### 2.3 The promise you can keep

Your brand promise is the commitment you make on every product page and every label. It should be narrow enough that you can prove it on every single product, from day one. Examples of keepable promises:

- "Every garment is made from certified organic cotton, and we publish the certificate number."
- "Every garment is sewn in one factory in Porto, Portugal, which we visit twice a year."
- "Every garment is repaired free for two years — send it back and we fix it."

Examples of promises you cannot keep yet:

- "100% sustainable." (Meaningless and unprovable.)
- "Zero waste." (Almost certainly untrue once packaging, samples, and cutting waste are counted.)
- "Carbon neutral." (Only meaningful with a verified calculation and offset scheme, which a new brand rarely has.)

Write your promise as a single sentence. Then, for each word in it, ask: "How would a sceptical customer check this?" If you cannot answer, rewrite the sentence until you can.

### 2.4 Name, identity, and the long view

Your brand name should be easy to spell, easy to say aloud, and available as a domain and on the social platforms you plan to use. Check availability before you fall in love with a name. Avoid names that lock you into one product ("Organic Tee Co.") if you may later sell more than T-shirts, and avoid names that make a claim you cannot prove ("Pure Earth" invites a challenge).

Your visual identity — logo, colours, typography, photography style — should reflect the clothes, not the other way round. A luxury-leaning brand needs calm, generous photography and restrained type. A playful streetwear brand needs energy. Consistency matters more than expense: the same colours, the same tone of voice, and the same photographic style across your website, packaging, and social media will make a small brand look established. You do not need a branding agency. You need a simple, written style guide: two typefaces, three colours, and a one-page description of how your photographs should look. Keep it in the workbook.

### 2.5 Pricing band and business model, decided early

Decide now whether you are a direct-to-consumer brand (selling from your own website), a wholesale brand (selling to shops, who then mark up your price), or both. This decision changes your pricing completely. A wholesaler typically buys at 50% of your retail price, so a garment that retails at £100 earns you £50 from a shop — and that £50 must still cover your full cost. Many new brands discover this too late and find wholesale loses them money. Module 5 works through both models with numbers. For your first collection, direct-to-consumer is usually the safer route: you keep the full margin, you learn directly from customers, and you control the story.

### Module 2 Actions

1. Finish the Brand Positioning Worksheet (Workbook, Worksheet 1) and write your one-sentence brand promise.
2. Interview five to ten potential customers and record their exact words.
3. Check name, domain, and social handle availability for your top three brand names.
4. Write your one-page visual style guide: colours, typefaces, photography direction, tone of voice.

---

## Module 3 — Materials: Fibres, Fabrics, and the Truth About Each One

### 3.1 How to judge a material honestly

Every fibre has trade-offs. There is no perfect fabric — only better and worse choices for a specific garment, customer, and budget. Judge each material on five questions:

1. **What is it made from, and what did producing it cost the planet?** Water, land, energy, chemicals.
2. **How long will it last in real use?** Durability is an environmental feature. A long-lasting garment beats a "greener" one that falls apart.
3. **How is it cared for?** A fabric that needs dry cleaning or hot washing has a hidden lifetime cost.
4. **What happens at end of life?** Can it be recycled, composted, or resold — in practice, not in theory?
5. **What does it cost, and can your customer afford the finished garment?** A beautiful material you cannot afford to buy is not a business decision.

Be wary of any supplier or article that describes a material as simply "good" or "bad." The honest answer is almost always "it depends" — and this module gives you the "depends on what."

### 3.2 The major fibres, in plain terms

**Cotton.** The workhorse of fashion. Conventional cotton uses significant water and pesticides; organic cotton is grown without synthetic pesticides and fertilisers and is usually certified (see Module 7). Organic cotton typically costs 20–50% more than conventional cotton at fabric level. It is breathable, comfortable, easy to dye, and widely available — which is why it is a sensible first choice for many new brands. Its weakness is water use and the fact that it wrinkles and wears at stress points. Recycled cotton exists but is usually shorter-fibred, weaker, and best blended with virgin cotton or used in heavier fabrics.

**Linen (flax).** Made from the flax plant, which needs far less water and fewer chemicals than cotton and grows well in cooler climates. Linen is strong, breathable, and improves with wear. It wrinkles readily — sell that as character, not a flaw — and it is more expensive than cotton, with a more limited colour range in natural dyeing. A good choice for summer pieces and for brands that want a natural, textured look.

**Hemp.** One of the lowest-impact major fibres: fast-growing, needs little water or pesticide, and produces a strong, durable fabric. Historically it felt rough; modern processing has softened it considerably, and hemp-cotton blends are a practical compromise. Supply is smaller and less standardised than cotton, so prices and availability vary, and you may need to order further ahead.

**Wool.** A natural, renewable, biodegradable fibre with excellent insulation and odour resistance — a wool jumper needs washing far less often than a synthetic one. Responsible wool means certified animal welfare and land management; look for recognised certifications rather than taking a supplier's word. Wool costs more, needs care in washing (or a superwash treatment, which has its own chemical questions), and can irritate sensitive skin. Merino is the softest and most expensive grade.

**TENCEL™ / lyocell.** A regenerated fibre made from wood pulp (usually eucalyptus or beech) in a closed-loop process that recovers most of the solvent. It drapes beautifully, is soft and breathable, and is a strong choice for dresses, shirts, and linings. Note the trademark: "TENCEL™" is a brand name owned by Lenzing; generic lyocell from other producers may or may not use the same closed-loop process, so ask for the specific producer and process. Cost is mid-to-high.

**Viscose / rayon.** Also made from wood pulp, but usually in an open process with chemicals that can harm workers and waterways unless the producer is certified to a high standard. Cheap and widely available, with a lovely drape — but a risky choice for an ethical brand unless you can verify the producer (look for suppliers committed to responsible viscose production and third-party verification). If you cannot verify it, do not use it.

**Recycled polyester (rPET).** Made from recycled plastic bottles or, better, from recycled textiles. It keeps plastic out of landfill and uses less energy than virgin polyester, but it still sheds microfibres when washed, it is still plastic, and bottle-to-fibre recycling does not create a circular system for clothing. Use it where its properties genuinely help — outerwear, swimwear, activewear — not as a green badge on a product that would be better in a natural fibre.

**Virgin polyester, nylon, and acrylic.** Cheap, durable, and easy to care for — and the reason fast fashion is so cheap. They are made from fossil fuels, shed microplastics, and do not biodegrade. An ethical brand can sometimes justify a small amount of synthetic fibre for function — 2–5% elastane in jeans for stretch, for example — but a brand built on virgin synthetics cannot honestly call itself sustainable. If you use synthetics, say why, say how much, and say what you are doing about it.

**Leather and alternatives.** Conventional leather involves animal welfare questions and chromium tanning, which is hazardous unless carefully managed. Vegetable-tanned leather is slower and more expensive but avoids chromium. Plant-based alternatives (cactus, mushroom, pineapple-leaf) are real products but vary enormously in durability, plastic content, and cost — some are mostly polyurethane with a plant coating. Read the composition, not the marketing name.

### 3.3 Blends: the hidden compromise

Blended fabrics — cotton-polyester, wool-acrylic, linen-viscose — are everywhere because they combine properties and cut costs. The trade-off is end of life: a blended fabric is very hard to recycle, because the fibres cannot easily be separated. A 50/50 cotton-polyester shirt is likely to end in landfill even if both fibres were responsibly produced. As a rule, prefer single-fibre fabrics where you can, and use blends only when the function genuinely requires it (a little elastane for stretch, a little nylon for strength in a sock). When you do blend, disclose the exact composition on the label and the product page.

### 3.4 Dyes, finishes, and trims — where claims quietly fail

The fabric is only part of the story. Dyeing and finishing use large volumes of water and chemicals, and a "sustainable fabric" dyed with hazardous chemicals in an unregulated dyehouse is not a sustainable garment. Ask your fabric supplier what dyes are used and whether they comply with recognised restricted-substance standards. The same scrutiny applies to trims: buttons, zips, threads, labels, and interlinings. A garment with an organic cotton body, a polyester thread, a plastic zip, and a synthetic label is making a claim its details do not support. Natural trims — corozo nut buttons, organic cotton thread, recycled metal zips — cost a little more and are worth specifying from the start. Packaging counts too: a compostable mailer is a small cost and a visible signal, but do not claim your packaging is plastic-free if your garment arrives in a polybag inside it.

### 3.5 Fabric sourcing in practice

For a first collection, you have three realistic routes:

- **Stock fabrics from a reputable merchant.** You buy fabric that already exists, in smaller quantities, at a higher per-metre price. This is the lowest-risk route: no minimum order for custom dyeing, faster delivery, and you can see and feel the fabric before committing. The trade-off is that other brands may use the same fabric.
- **Custom-dyed or custom-woven fabric.** You choose a base cloth and dye or weave it to your specification. This gives you a unique product but usually requires a minimum order (often 300–1,000 metres) and a longer lead time, and you pay for sampling.
- **Deadstock fabric.** Leftover fabric from larger brands' production, sold by specialist dealers. It is genuinely waste-reducing and often high quality at a good price, but quantities are limited and cannot be reordered — when it is gone, it is gone, which makes it hard to build a repeatable product line. Excellent for limited editions; risky as the foundation of your core range.

**A realistic fabric budget example.** Suppose you are making a women's shirt in organic cotton poplin. A reputable merchant quotes £9.50 per metre; each shirt needs 1.6 metres including cutting waste, so fabric costs £15.20 per shirt. A conventional cotton poplin might cost £5.50 per metre (£8.80 per shirt). The organic choice adds £6.40 per shirt — real money, but a difference your retail price can absorb if your costing is honest (Module 5). Do this arithmetic for every fabric before you fall in love with it.

### 3.6 Building your materials library

Order swatches — small cuttings — from every supplier you consider. A swatch card with the supplier name, fabric name, composition, weight (grams per square metre, or GSM), width, price per metre, minimum order, and certifications is worth more than a hundred website descriptions. Wash the swatches. Stretch them. Leave them in sunlight for a week. A fabric that pills, fades, or shrinks in your hands will do the same for your customer, and returns will cost you far more than the fabric saved. Keep the library organised: one binder or box, one card per fabric, updated every time a price or minimum changes.

### Module 3 Actions

1. Complete the Materials Comparison Worksheet (Workbook, Worksheet 2) for your top three candidate fabrics.
2. Order swatches from at least three fabric suppliers and start your materials library.
3. For each fabric you are considering, write one sentence stating its main environmental strength and one sentence stating its main weakness. If you cannot name a weakness, you have not researched it enough.

---

## Module 4 — Sourcing: Finding and Vetting Suppliers Without Getting Burned

### 4.1 The supply chain you are actually buying

Your garment passes through several hands: fibre producer, spinner, weaver or knitter, dyer, cut-and-sew factory, trim supplier, and shipper. As a small brand you will rarely deal with all of them directly. Typically you will work with a fabric merchant (who sources cloth) and a cut-and-sew factory (often called a CMT unit — cut, make, trim — or a full-package factory that also sources fabric and trims for you). Know which type you are dealing with, because it changes who is responsible for what, and who you need to check.

A full-package factory is simpler for a beginner: one partner, one invoice, one point of accountability. A CMT factory is cheaper per unit but requires you to supply the fabric and trims yourself, which means more coordination and more risk if a delivery is late. For a first collection, full-package with a factory that already works with your chosen fabrics is usually the wiser choice.

### 4.2 Where to find suppliers

Start with sources you can verify: trade directories and exhibitions for your region, recommendations from other small brands, and industry associations. Textile trade shows — even attending one as a visitor — will teach you more in a day than a month of web searching, because you can handle fabrics, meet people, and hear how they talk about their work. Online B2B marketplaces can be useful, but they are also where the most exaggerated claims live: a listing that says "organic, fair trade, GOTS certified" with no certificate number and no verifiable company address should be treated as unproven until proven otherwise.

Ask other founders. The sustainable fashion community is small and generally generous with introductions. A recommendation from a brand at your stage is worth more than a search result, because it comes with lived experience of minimums, quality, and communication.

### 4.3 First contact: what to ask, and how to sound serious

Factories receive many enquiries from people who never order. To be taken seriously, your first email should be short, specific, and professional (scripts are in Appendix B). Include: who you are, what you want to make (garment type, fabric, approximate quantity), your target delivery date, and one or two direct questions (minimum order quantity, lead time, whether they work with your fabric). Do not ask for a price on a vague idea — "how much is a dress?" cannot be answered. A factory can quote when it has a sketch or tech pack, a fabric, a size range, and a quantity.

A tech pack is the document that tells a factory exactly what to make: flat sketches, measurements for each size, fabric and trim specifications, stitching and construction details, labelling, and packaging. You can create a basic tech pack yourself with the guidance in Module 6, or hire a freelance technical designer for a one-off fee (typically £150–£400 per style for a simple garment, depending on complexity). A clear tech pack is the single best protection against wrong samples, surprise costs, and disputes.

### 4.4 Vetting: trust, but verify

Use the Supplier Vetting Checklist in the templates folder for every supplier, and score them honestly. At minimum, verify:

- **The business is real.** A registered company, a physical address, a website or trade presence, and a named contact. Be cautious with suppliers who will only communicate through a messaging app and cannot provide a business address.
- **Certifications are genuine.** Ask for the certificate itself — not a logo on a website. Check the certificate number, the scope (does it cover the product you are buying?), and the expiry date. Many certification bodies have public databases where you can verify a certificate number. A certificate for organic cotton does not certify the factory's labour conditions, and a factory audit does not certify the fabric. Each claim needs its own evidence.
- **Labour conditions.** Ask for the factory's most recent social audit or assessment, who conducted it, and what corrective actions were taken. Be honest with yourself about what an audit can and cannot prove — audits are a snapshot, not a guarantee — but a factory that refuses to share anything is telling you something. If you can, visit. For a first collection, a factory within a few hours' travel is worth a premium, because a visit answers in an afternoon what months of email cannot.
- **Quality and reliability.** Ask for references from other customers at your scale, and contact them. Ask about defect rates, on-time delivery, and how problems were handled. Order a sample before committing to bulk, and inspect it as a customer would: seams, stitching, measurements, trims, labelling, and wash it once.
- **Payment terms.** Understand exactly when money is due. A common structure is a deposit (often 30–50%) to start production, with the balance before shipping. Never pay 100% upfront to a supplier you have not vetted. Use a payment method that leaves a record, and get everything in writing — price, quantity, delivery date, quality standard, and what happens if goods are defective or late.

### 4.5 Minimum order quantities (MOQs) and why they shape your brand

MOQ is the smallest quantity a supplier will produce. For fabric it may be 100–500 metres; for a factory it may be 50–300 units per style, sometimes per colour. MOQs are the single biggest constraint on a small brand, because they decide how much money you must commit before you have sold anything.

**Worked example.** A factory quotes a MOQ of 100 units per style in one colour, at a unit cost of £22. That is £2,200 committed to a single style before you have sold one. Three styles means £6,600 before fabric sampling, shipping, and packaging. If your total first-collection budget is £5,000, you cannot afford three styles at that factory — you can afford two, or you need a factory with a lower MOQ, or fewer colours. This is not a failure of ambition; it is arithmetic, and doing it before you order is what keeps you in business. Negotiating MOQs is possible — some factories will accept a lower first order if you pay a slightly higher unit price or commit to a reorder — but never agree to a quantity you cannot afford to hold as stock for six months.

### 4.6 Sampling: the step you must not skip

Production follows a sequence: initial sample (sometimes called a proto sample) to check the design and fit; a sales or photo sample in the correct fabric; and a pre-production sample, made on the actual production line, which you approve in writing before bulk cutting begins. Each round costs money — typically £50–£200 per sample plus courier fees — and takes one to three weeks. Budget for at least two rounds and do not approve bulk production from a photograph. Hold the physical sample, wash it, wear it, and measure it against your tech pack. A defect found in a sample costs tens of pounds. The same defect found in 200 finished garments costs thousands.

### 4.7 Red flags

Walk away — politely, and without arguing — if a supplier: refuses to provide certification documents; cannot name the factory where your garments will be made; subcontracts without telling you; demands full payment upfront; quotes a price far below every other quote (someone, somewhere, is paying the difference, and it is usually the worker or the environment); or pressures you to skip sampling. Any one of these is enough reason to pause. Two is enough reason to leave.

### Module 4 Actions

1. Complete the Supplier Vetting Scorecard (Workbook, Worksheet 3) for at least two candidate factories and two fabric suppliers.
2. Send first-contact emails to three suppliers using the scripts in Appendix B.
3. Order and evaluate samples for your leading fabric and factory combination before committing to bulk.
4. Record every supplier's MOQ, lead time, and payment terms in your sourcing directory.

---

## Module 5 — Costing and Pricing: The Maths That Decides Whether You Survive

### 5.1 Why most new brands price too low

The most common fatal mistake in fashion is underpricing. Founders price by feeling — "£45 feels right for a T-shirt" — or by copying a competitor without knowing that competitor's costs. Then the first order arrives, the real costs land, and the brand discovers it loses money on every sale. Underpricing does not buy loyalty; it buys a short life. A customer who buys because you are cheap will leave the moment someone cheaper appears. A customer who buys because the product is good and the price is honestly explained will stay.

The rule is simple: know your true cost per garment before you set your price, and set your price from your cost — not from your hopes.

### 5.2 The true cost of a garment

A garment's landed cost — what it costs you, in your hands, ready to sell — has more parts than most founders expect:

- **Fabric.** Metres used (including cutting waste, usually 10–15% extra) multiplied by price per metre.
- **Trims.** Thread, buttons, zips, labels, interlining, elastic, drawcords.
- **Labour (cut, make, trim).** The factory's charge per unit, which covers cutting, sewing, pressing, and quality checking.
- **Sampling and development.** Spread across the production run: if you spent £300 on samples for a style and produce 100 units, that is £3.00 per unit.
- **Freight and duty.** Shipping the finished garments to you, plus any import duty and customs handling. Air freight is fast and expensive; sea freight is slow and cheaper per unit but has minimum charges that punish small orders.
- **Packaging.** Mailers, tissue, hang tags, and the polybag or alternative that protects the garment in transit.
- **Payment and currency costs.** Card fees, transfer fees, and exchange rate movement on overseas payments.
- **Your time.** Not a line in the supplier's invoice, but real: if you spend 20 hours a week for three months launching a collection, that time has value, and the business must eventually pay for it.

The costing calculator in the templates folder (garment-costing-calculator.csv) has a row for each of these. Use it for every style, every time.

### 5.3 Worked example 1: an organic cotton T-shirt

Let us cost a women's organic cotton T-shirt, made in Portugal, in a run of 200 units. All figures are illustrative; replace them with your own quotes.

| Cost item | Calculation | Per unit |
|---|---|---|
| Fabric: 1.1 m at £9.00/m (incl. 10% waste allowance) | 1.1 × £9.00 | £9.90 |
| Trims (thread, labels, neck tape) | — | £1.20 |
| Labour (cut, make, trim) | — | £6.50 |
| Sampling spread over 200 units (£240 ÷ 200) | — | £1.20 |
| Freight, duty, and handling | — | £1.80 |
| Packaging (mailer, tag, tissue) | — | £0.90 |
| **Landed cost per unit** | | **£21.50** |

The landed cost is £21.50. Now the pricing. A direct-to-consumer brand typically needs a gross margin of 65–75% on the retail price to cover marketing, website costs, returns, discounts, photography, and the founder's time, and still leave a profit. Gross margin here means (retail price − landed cost) ÷ retail price.

At a retail price of £65: (£65 − £21.50) ÷ £65 = 67% margin. That works. At £45: (£45 − £21.50) ÷ £45 = 52% margin — thin, and one bad month of returns or a 20% discount code could wipe it out. At £35, the margin is 39%, and the business is unlikely to survive its first year.

Notice what this means: the T-shirt that "feels" like it should cost £35 cannot be made this way, at this quantity, at this standard, and sold profitably. You have three honest options: raise the price and explain why, reduce the cost (a cheaper fabric, a larger order, a different factory), or do not make that product. What you must not do is sell it at £35 and hope volume saves you. Hope is not a pricing strategy.

### 5.4 Worked example 2: a linen shirt dress, and the wholesale problem

Now a linen shirt dress, made in a run of 100 units:

| Cost item | Per unit |
|---|---|
| Fabric: 2.4 m at £14.00/m (incl. waste) | £33.60 |
| Trims (buttons, thread, labels, interfacing) | £3.40 |
| Labour (cut, make, trim — more complex garment) | £18.00 |
| Sampling spread over 100 units (£350 ÷ 100) | £3.50 |
| Freight, duty, and handling | £3.20 |
| Packaging | £1.30 |
| **Landed cost per unit** | **£63.00** |

Direct to consumer at £185: (£185 − £63) ÷ £185 = 66% margin. Healthy.

Now suppose a boutique wants to stock it and offers standard wholesale terms: they pay 50% of retail, so £92.50 per unit. Your margin becomes (£92.50 − £63) ÷ £92.50 = 32%. That has to cover your marketing, your website, returns, and your time — and it probably cannot. To wholesale profitably at a 50% retail split, your landed cost generally needs to be no more than 25–30% of the retail price. For this dress that would mean a retail price of £210–£250, or a lower landed cost. Many new brands learn this only after signing a wholesale order. Do the maths first, and if wholesale does not work at your current costs, say no politely and revisit it when your volumes are larger and your costs lower.

### 5.5 Keystone, multipliers, and the habit of checking

A common shortcut is the "multiplier": retail price = landed cost × 3, or × 2.5. For the T-shirt above, × 3 gives £64.50 — close to our £65. For the dress, × 3 gives £189 — close to our £185. Multipliers are a useful sense-check, not a substitute for real costing. Use a multiplier of 2.5–3 for direct-to-consumer pricing as a rough guide, then check the resulting margin line by line. If the multiplier gives you a price your customer will not pay, the product is wrong for your market at your current costs — change the product or the costs, not the maths.

### 5.6 Discounts, sales, and returns — the margin eaters

Three things quietly destroy margins, and you must plan for all of them:

- **Discounts.** A 20% discount code on a £65 T-shirt takes £13 off the price. Your margin falls from 67% to 59% — and if you run discounts constantly, customers learn never to pay full price. Use discounts sparingly: a launch offer, a genuine end-of-season clearance, a loyalty reward. Never build your business on permanent discounting.
- **Returns.** Online fashion return rates of 15–25% are normal. Every return costs you outward shipping, return shipping, inspection, and repackaging — and sometimes a garment that cannot be resold at full price. Build a realistic return rate into your plan (budget for 15% of units returned, and for a portion of those to be resold at a discount or not at all).
- **Dead stock.** Unsold sizes and colours are money sitting in boxes. A small first collection, a pre-order model, or made-to-order for slow styles can reduce this risk dramatically. Module 6 covers this.

**Worked example: a realistic first-season picture.** You produce 200 T-shirts at £21.50 landed cost: £4,300 in stock. You sell 140 at £65 (£9,100 revenue), 20 at a 20% discount (£52 each, £1,040), and 40 remain unsold. Gross profit on sold units: revenue £10,140 minus cost of sold units (160 × £21.50 = £3,440) = £6,700, before marketing, website, photography, and your time. The 40 unsold shirts represent £860 of cost tied up in stock — sell them later at a discount or carry them into next season, but do not pretend they are profit. This is a survivable first season. If you had produced 500 units instead, the unsold stock would be far larger and the cash tied up far more dangerous. Small is safe.

### 5.7 Break-even: the number that tells you when you are safe

Break-even is the number of units you must sell to cover all your costs. The formula is: fixed costs ÷ (retail price − landed cost per unit). Fixed costs are the costs that do not change with each unit sold: website, photography, launch marketing, samples.

**Worked example.** Your fixed launch costs are £2,400 (website £400, photography £800, samples £700, launch marketing £500). Your T-shirt sells at £65 with a landed cost of £21.50, so each sale contributes £43.50 toward fixed costs. Break-even = £2,400 ÷ £43.50 = 56 units (rounded up). You need to sell 56 of your 200 shirts before the collection has paid for itself. Knowing this number before you launch — and being honest about whether you can sell 56 units — is the difference between a plan and a wish.

### Module 5 Actions

1. Complete the Garment Costing Worksheet (Workbook, Worksheet 4) for your leading product, using real quotes wherever you have them and clearly marked estimates elsewhere.
2. Open the garment-costing-calculator.csv template and cost three products: your hero product, a lower-priced entry product, and a higher-priced statement product.
3. Calculate your break-even for the first collection, and write down what would have to be true for you to sell that many units.

---

## Module 6 — Designing Your First Collection: Small, Focused, Sellable

### 6.1 Less is more — and provably so

A first collection of three to five styles, in one or two colourways each, is the right size for most new brands. It is affordable to produce, easy for a customer to understand, easy to photograph, and easy to manage. A twelve-style collection with four colours each is 48 product variants: 48 sets of stock, 48 photographs, 48 chances for a size to sell out while another gathers dust. Every additional variant multiplies cost, complexity, and risk.

Choose your styles by the "wardrobe test": would your customer wear this at least twice a week, with things they already own? The garments that pass are usually simple, well-cut essentials with one distinctive detail — a better pocket, a beautiful button, an unusual seam — rather than dramatic statement pieces. Statement pieces photograph well and sell slowly. Essentials sell steadily and bring customers back.

### 6.2 The hero product

Every collection needs a hero: one product that carries the story, earns the best margin, and is the first thing a new visitor sees. The hero should be the product you are proudest of, the one whose materials and making you can talk about most convincingly, and the one that photographs best. Price it with confidence — it sets the tone for the whole brand. Your other products support it: an entry product at a lower price that lets a new customer try the brand with less risk (a T-shirt, a scarf, a tote), and one or two companions that complete an outfit with the hero.

**Worked example — a five-piece first collection:**

| Style | Fabric | Landed cost | Retail | Role |
|---|---|---|---|---|
| Organic cotton T-shirt | Organic cotton jersey | £21.50 | £65 | Entry product |
| Linen shirt dress | Linen | £63.00 | £185 | Hero product |
| Organic cotton twill trousers | Organic cotton twill | £38.00 | £115 | Companion |
| Hemp-blend overshirt | Hemp-cotton blend | £44.00 | £135 | Companion |
| Organic cotton tote | Organic cotton canvas | £8.00 | £28 | Low-price entry, gift item |

Five styles, each with a clear role and a margin of roughly 65–70%. Total stock cost at 100 units per style (50 for the dress) would be roughly £13,000 — still a large sum, which is why many founders start with 50 units per style, or use pre-orders to fund production. Reduce quantities before you reduce quality.

### 6.3 Fit, sizing, and the return problem

Fit is the top reason online fashion is returned, and returns are the top margin-killer for a new brand. Invest in fit: a proper size range (not just S/M/L if your customer needs more), a fit model or fit sessions with real customers, a clear size guide with garment measurements (not just body measurements), and honest photography showing the garment on more than one body type. Consider offering a broader size range from the start — inclusive sizing is both an ethical position and a commercial one, since underserved customers are loyal customers. It costs more in sampling and stock, so plan for it rather than adding it as an afterthought.

Design for real bodies and real movement: pockets that hold a phone, seams that do not split when sitting, lengths that work with the shoes your customer actually wears. Test garments by wearing them for a full day before approving production. A garment that is beautiful on a hanger and uncomfortable after an hour will come back.

### 6.4 The tech pack, step by step

Your tech pack does not need to be fancy; it needs to be complete. For each style, include:

1. A flat sketch (front and back), drawn clearly even by hand and photographed or scanned.
2. Fabric specification: name, composition, weight, colour reference, supplier.
3. Trim specification: every button, zip, label, and thread, with supplier and reference.
4. A measurement table for every size, with tolerances (for example, chest ±1 cm).
5. Construction notes: seam types, stitch density, hemming, pressing.
6. Labelling and packaging instructions: where labels go, what the hang tag says, how the garment is folded and bagged.
7. Quality standard: what counts as acceptable, and what counts as a defect.

Send the tech pack with your first enquiry, and ask the factory to confirm they understand it before sampling begins. Misunderstandings caught on paper cost nothing; misunderstandings caught in bulk production cost everything.

### 6.5 Pre-order and made-to-order: selling before you sew

Two models can dramatically reduce the cash risk of a first collection:

- **Pre-order.** Customers pay (in full, or a deposit) before production, and you produce only what is ordered, plus a small buffer. This funds production with customer money rather than your savings, and it proves demand before you commit. The trade-off is a longer wait for the customer — be honest about the timeline (typically 4–8 weeks) and communicate proactively if it slips.
- **Made-to-order.** Each garment is cut and sewn after the order arrives. This eliminates dead stock entirely and lets you offer more sizes and colours. The trade-off is a longer delivery time and a higher unit cost, since the factory cannot batch production efficiently. It suits higher-priced, simpler garments and small volumes.

Either model can be combined with a small ready-to-ship stock of your hero product. Whichever you choose, state the delivery time clearly on the product page, before the customer pays — not in the small print afterwards.

### Module 6 Actions

1. Choose your first collection: three to five styles, each with a role (hero, entry, companion), a fabric, and a target retail price.
2. Draft a basic tech pack for your hero product.
3. Decide your fulfilment model: ready stock, pre-order, made-to-order, or a combination — and write the delivery promise you will put on your product pages.
4. Plan your size range and size guide, including garment measurements.

---

## Module 7 — Honest Claims: Certifications, Labelling, and Avoiding Greenwashing

### 7.1 Why this module matters more than any other

You can survive a late delivery and a slow season. It is far harder to survive being publicly shown to have misled your customers. Ethical fashion is a trust business: your customer is paying a premium precisely because they believe your claims. If those claims turn out to be hollow, you have not just lost a sale — you have lost the only reason your brand exists. This module is the practical guide to making claims you can stand behind.

### 7.2 The certifications worth knowing

Certifications are third-party checks that a product or process meets a published standard. They are not perfect — no certification guarantees perfection — but they are far stronger than a supplier's own word, because an independent body has checked. The most relevant ones for a new fashion brand are:

- **GOTS (Global Organic Textile Standard).** Covers organic fibres through the whole supply chain, including processing, dyes, and social criteria. If you sell organic cotton, GOTS certification of the fabric and the supply chain is the strongest widely recognised evidence you can have. Ask for the certificate and check its scope.
- **OCS (Organic Content Standard).** Verifies the organic content of a product. Simpler than GOTS and useful when GOTS is not available, but it does not cover processing or social criteria.
- **Fairtrade.** Covers the farming and trading of raw materials such as cotton, with standards for prices and working conditions at farm level. It does not by itself certify the factory that sewed the garment.
- **Fair Wear Foundation and similar factory programmes.** Focus on labour conditions in garment factories: wages, safety, working hours, and freedom of association. Ask your factory what programme it participates in and what its most recent assessment found.
- **OEKO-TEX® Standard 100.** Tests the finished product for harmful substances. Useful evidence that a garment is safe against the skin, but it is not an environmental or social certification — do not present it as one.
- **GRS (Global Recycled Standard).** Verifies recycled content and covers processing, social, and chemical criteria. The right evidence for a recycled-fibre claim.
- **Responsible Wool Standard (RWS).** Covers animal welfare and land management for wool.
- **B Corp.** Certifies the whole company, not a product — governance, workers, community, and environment. Meaningful, but a significant undertaking for a new brand; a realistic goal for year two or three, not day one.

Practical advice: you do not need every certification. You need the one or two that match your main claims, with valid certificates you can show. A single genuine GOTS certificate for your hero fabric is worth more than five logos pasted on a website with no evidence behind them. And never use a certification logo you have not earned — certification bodies do pursue misuse, and a customer who checks will find out.

### 7.3 How to verify a certificate

1. Ask the supplier for the certificate document, not a screenshot of a logo.
2. Read it: who issued it, to whom, for what scope of products, and until when? An expired certificate is not evidence.
3. Check the certificate number against the issuing body's public database where one exists.
4. Confirm the scope covers the product you are buying. A GOTS certificate for a supplier's T-shirts does not cover their trousers.
5. Keep copies on file, and keep them updated. When a certificate is renewed, replace the old copy.

If a supplier cannot produce a certificate for a claim they are making, treat the claim as unproven. You may still buy from them — but you may not repeat the claim to your customers.

### 7.4 Words to use, words to avoid

Language is where greenwashing usually happens, one careless adjective at a time.

**Use — specific, verifiable, and true:**

- "Made from 100% GOTS-certified organic cotton" (with the certificate available).
- "Sewn in Porto, Portugal, at [factory name], which we visited in [month, year]."
- "Our packaging is home-compostable" (only if you have evidence for that specific packaging).
- "We repair this garment free for two years."

**Avoid — vague, absolute, or unprovable:**

- "Sustainable," "eco-friendly," "green," or "conscious" on their own, with nothing specific behind them.
- "100% sustainable" or "zero impact." No product is.
- "Ethical" as a blanket claim about the whole brand. Say what is ethical about it, specifically.
- "Natural" as a synonym for good. Arsenic is natural. Some natural fibres are heavily processed, and some synthetics have legitimate uses.
- "Recycled" without a percentage and a source: "made from 80% recycled polyester, from post-consumer plastic bottles, GRS-certified."
- "Carbon neutral" without a published calculation and a verified offset scheme.
- Images that imply more than the words say: a forest, a meadow, or a pair of hands holding soil next to a product that has nothing to do with them.

A useful test for every claim you write: could a sceptical journalist verify it in an afternoon? If the answer is yes, the claim is strong. If the answer is no, rewrite it until it is.

### 7.5 Labelling and the law

Legal requirements for clothing labels vary by country, but the essentials are consistent across the UK, the EU, and the US: fibre composition (with percentages), country of origin, and care instructions are generally required, and the information must be accurate. In the UK and the EU, fibre names and percentages follow specific rules; in the US, the Federal Trade Commission enforces textile labelling and advertising rules, and its Green Guides set out how environmental claims in marketing must be substantiated. The rules are tightening, not loosening — the EU in particular has moved toward requiring environmental claims to be specific and evidenced.

This programme is education, not legal advice. Before you launch, have a solicitor or a qualified adviser in your market review your labels and your main marketing claims — particularly if you sell internationally. A one-hour review is far cheaper than a regulatory complaint. Keep records of the evidence behind every claim: certificates, supplier statements, test results, and factory visit notes. If a claim is ever challenged, your records are your defence.

### 7.6 Transparency as a product feature

Some of the most trusted small brands publish more than the law requires: the name and location of their factory, a cost breakdown showing where the retail price goes, and an annual honest report of what went well and what did not. A cost breakdown is a powerful trust-builder. For the £65 T-shirt in Module 5, a product page might say: "Fabric £9.90, trims £1.20, making £6.50, sampling £1.20, freight £1.80, packaging £0.90 — total cost £21.50. The remaining £43.50 covers our website, photography, marketing, returns, and the time it takes to run the brand." Customers who understand the price are far more willing to pay it, and far less likely to haggle or complain. Transparency is not a risk. Secrecy is.

### Module 7 Actions

1. List every claim you plan to make about your brand and products. For each, write down the evidence you hold and where it is filed.
2. Rewrite any vague claims using the rules in section 7.4.
3. Check the labelling requirements for every country you plan to sell in, and note what your labels must carry.
4. Draft a cost breakdown for your hero product that you could publish on its product page.

---

## Module 8 — Brand Story and Ethical Marketing: Earning Trust and Being Found

### 8.1 Story is not decoration — it is the reason to believe

Your brand story is the true, specific account of why this brand exists, who makes the clothes, and what changes because the brand exists. It is not a fairy tale. The most effective brand stories are small and concrete: a founder who could not find durable work trousers; a designer who visited a factory and decided to do it differently; a maker who learned to sew from a grandparent and wanted the craft to survive. Customers remember a specific person and a specific problem. They forget "we believe in a better future for fashion."

Write your story in the Brand Story Worksheet (templates/brand-story-worksheet.md). It should answer, in plain language: who you are, what problem you saw, what you decided to do about it, who makes your clothes and where, what your clothes are made from and why, and what you are still working on. That last part — what you are still working on — is what makes the story believable. A brand that admits its unfinished work is trusted more than one that claims to have finished.

### 8.2 The marketing you can afford: content, not ads

A new brand rarely has an advertising budget that matters. What it has is a story, a product, and time. Spend them on marketing that compounds:

- **Product photography that shows the truth.** Well-lit, honest photographs on real bodies, showing the fabric texture, the fit, and the details. One good set of photographs per style is worth more than a month of social media posts. Show the garment being worn, being moved in, and close up.
- **The making-of.** Photograph and film the process: fabric arriving, cutting, sewing, pressing, packing. Customers who have seen a garment being made value it more and return it less. Always ask the factory's permission before photographing or filming, and respect any limits they set.
- **Education, not slogans.** Short, useful content that helps your customer: how to tell good stitching from bad, how to wash linen, how to repair a seam, what GOTS actually means. This content earns shares and search traffic, and it positions you as someone who knows their craft rather than someone shouting about it.
- **Email, from day one.** An email list is the only audience you own. Social platforms change their rules; your list does not. Offer something genuinely useful in exchange for an address — a fit guide, a fabric guide, early access to a launch — and write to the list regularly with real news, not constant discounts.
- **Search.** Customers searching for "organic cotton shirt dress" or "ethical linen trousers UK" are ready to buy. Use the exact words your customers use in your product titles and descriptions, and write descriptions that answer real questions: fabric, fit, care, origin, and why it costs what it costs.

### 8.3 Social media without the treadmill

Choose one or two platforms where your customer actually spends time, and do them well, rather than being thinly present on five. For most sustainable fashion brands, that means Instagram and either TikTok or Pinterest, depending on whether your customer prefers video or visual discovery. Post the making-of, the materials, the people, and the clothes being worn — and post consistently, even if that means three times a week rather than daily. Consistency beats volume. Respond to every comment and message in the early months: your first hundred customers are your marketing department, and how you treat them is the brand.

Do not buy followers, do not use engagement pods, and do not pay influencers who have never worn your clothes. If you work with creators, send the product, let them wear it for a week, and let them say what they actually think. One honest review from a creator who genuinely likes the garment is worth more than ten paid posts that read like adverts.

### 8.4 Launch marketing: a realistic plan

A launch does not need a big event. It needs a sequence:

1. **Four weeks before launch:** announce the launch date to your email list and social followers; share the making-of; open a waitlist with a small, genuine benefit (early access, not a deep discount).
2. **Two weeks before:** reveal the collection — photographs, prices, and the story behind each piece; answer questions publicly so everyone sees the answers.
3. **Launch week:** publish the collection, email the waitlist first, and be available to answer questions quickly. Slow replies in launch week lose sales.
4. **Two weeks after:** share customer photographs (with permission), answer the most common questions, and report honestly on what sold and what is left.

### 8.5 Pricing honesty in marketing

Never advertise a "was" price that the product was never sold at, and never invent a discount from an inflated price. Never use countdown timers or "only 2 left" claims that are not true. Scarcity is real for a small brand — you genuinely may have only a few units — but if you say it, it must be true, and it must stay true. Trust, once spent on a trick, does not come back.

### Module 8 Actions

1. Complete the Brand Story Worksheet (templates/brand-story-worksheet.md).
2. Write product descriptions for your hero product and entry product, using the honest-claim rules from Module 7.
3. Plan your first month of content: twelve posts across your chosen platforms, each with a purpose (educate, show the making, show the product, invite a question).
4. Set up your email list and write your welcome email.

---

## Module 9 — Launch, Sell, Learn: Your First 90 Days in the Market

### 9.1 Before launch day: the checklist

Launch day should be boring — because everything was checked the week before. Walk through this list and tick each item off:

- Every product page has correct photographs, prices, sizes, fabric composition, care instructions, origin, and delivery time.
- The checkout works end to end, including a test order you placed yourself.
- Your returns and exchanges policy is written in plain language and easy to find.
- Your packaging is ready, your labels are printed, and you have practised packing and posting one order.
- You know your stock levels by size and colour, and your website reflects them.
- Your email list and social channels are ready, and your launch email is written.
- You have a plan for the first customer service question, the first return, and the first complaint — because all three will arrive, and a calm, generous response turns a problem into a loyal customer.

### 9.2 The first 30 days: listen more than you sell

Your job in the first month is to learn. Track, every week: units sold by style, size, and colour; revenue; return rate and reasons; the questions customers ask (these tell you what your product pages failed to explain); and where orders came from. Talk to your first customers directly — a short email asking what they liked, what surprised them, and what would make them buy again will teach you more than any analytics dashboard. If a style is not selling, find out why before you discount it: is it the price, the photograph, the fit, or simply that nobody saw it?

Resist the urge to redesign everything in week two. Give the collection time to be found. Most new brands sell slowly at first and then steadily, as word of mouth and search visibility build. A slow first month is normal. A first month with no sales at all is information: something in the product, price, or presentation is not working, and your job is to find out which one by asking customers, not by guessing.

### 9.3 Reading the numbers honestly

At the end of 90 days, sit down with the real figures and answer these questions in writing:

- How many units did you sell, and at what average price?
- What was your gross profit after the cost of goods sold?
- What did you spend on marketing, website, photography, and packaging?
- What is your return rate, and what did returns cost you?
- Which style sold best, and which sold worst — and why?
- How much stock remains, and what is it worth at cost?
- Did you reach break-even (Module 5)? If not, how many more units would it take?

**Worked example — a 90-day review.** You launched with 350 units across five styles at a total stock cost of £9,800, plus £2,400 in fixed launch costs — £12,200 invested. In 90 days you sold 190 units for £15,400 in revenue. Cost of goods sold on those units was £5,320, giving a gross profit of £10,080. After fixed costs of £2,400 and marketing spend of £1,100, you have £6,580 before your own time — and 160 units of stock remaining, worth £4,480 at cost. You have not made yourself rich. You have, however, covered your costs, learned which styles sell, and still hold stock to sell. That is a successful first season for a new brand. The mistake would be to call it a failure because it was not an overnight success, or to call it a triumph and immediately order three times as much.

### 9.4 Reorder, restock, or redesign

Decide what to do next based on evidence, not enthusiasm:

- **Reorder** the styles that sold through quickly, in the sizes and colours that sold — not in the same spread as the first order. If size M sold out and size XS did not move, order more M and less XS.
- **Restock with changes** the styles that sold steadily but generated questions or returns — a better size guide, a small fit adjustment, a clearer photograph.
- **Retire** the styles that did not sell and did not generate interest. Discount the remaining stock honestly, learn the lesson, and move on. Do not keep producing a style because you love it if your customers do not.
- **Plan the next collection** as a small step, not a leap: one or two new styles, plus the proven sellers in a new colour. Your second collection should be cheaper and faster to produce than your first, because you already have the suppliers, the tech packs, and the lessons.

### 9.5 Growing without losing the plot

Growth in sustainable fashion is usually slow and then steady. The temptations to avoid: expanding into wholesale before your margins allow it; adding many new styles before the first ones have proven themselves; cutting costs by switching to a cheaper, unverified supplier; and making bigger claims to chase a bigger audience. Each of these trades the trust you have built for speed, and trust is the asset that is hardest to rebuild.

Instead, grow by deepening what works: better photography of proven products, a repair service that turns one-time buyers into repeat customers, a small loyalty benefit for returning customers, and a second collection that is visibly better than the first. Consider, when you are ready, the certifications that match your scale (Module 7), a B Corp assessment in year two or three, and partnerships with retailers whose values match yours — on terms your margins can support.

### 9.6 When to ask for help

You do not have to do everything yourself. As revenue grows, the first things worth paying for are usually: an accountant who understands small product businesses (before your first tax return, not after); a technical designer or pattern cutter for fit-critical styles; and a photographer whose work lifts the whole brand. Hire for the things you are weakest at and that cost you the most in returns or lost sales, not for the things you enjoy doing. And keep learning: visit a trade show once a year, talk to other founders, and stay current on the regulations in the markets where you sell — the rules on green claims are changing, and a founder who keeps up is a founder who stays in business.

### Module 9 Actions

1. Complete the Launch Checklist (Workbook, Worksheet 5) and the 90-Day Action Plan (Workbook, Worksheet 6).
2. Set up a simple weekly tracking sheet: units sold, revenue, returns, questions asked, and where orders came from.
3. Write your 90-day review date in your calendar now, and commit to doing the review in writing, with real numbers.
4. Decide your reorder rule in advance: at what stock level, and on what evidence, will you reorder each style?

---

## Your Outcome

If you have worked through all nine modules, you now hold the pieces of a real brand: a specific position and a promise you can keep; materials chosen with open eyes; suppliers you have vetted and can name; garments costed honestly and priced to survive; a small, focused first collection; claims that are specific and evidenced; a story worth telling; and a launch plan with a 90-day review built in. None of this guarantees success — no honest programme can. What it gives you is the best foundation a new ethical fashion brand can have: a product customers can trust, numbers you understand, and a business you can still be proud of in three years' time. Now go and make the first sample.

---

## Appendix A — Glossary of Materials and Certifications

- **CMT** — Cut, make, trim: a factory that sews garments from fabric and trims supplied by the brand.
- **Deadstock** — Leftover fabric from previous production, sold on rather than discarded.
- **Full-package** — A factory that sources fabric and trims as well as sewing the garment.
- **GOTS** — Global Organic Textile Standard: organic fibre certification covering processing and social criteria.
- **GRS** — Global Recycled Standard: certification for recycled content.
- **GSM** — Grams per square metre: a measure of fabric weight. Higher GSM generally means heavier fabric.
- **MOQ** — Minimum order quantity.
- **OEKO-TEX® Standard 100** — Testing of finished textiles for harmful substances.
- **RWS** — Responsible Wool Standard: animal welfare and land management certification for wool.
- **Tech pack** — The technical document specifying exactly how a garment is to be made.
- **TENCEL™** — A brand of lyocell fibre made by Lenzing in a closed-loop process.

## Appendix B — Supplier Email Scripts

**First contact with a cut-and-sew factory:**

> Subject: Enquiry — small first order, [garment type], [fabric]
>
> Hello, my name is [your name] and I am launching a small sustainable clothing brand, [brand name]. I am looking for a full-package / CMT (delete as appropriate) partner for [garment type, e.g. a women's organic cotton shirt], in a first order of around [quantity] units, for delivery by [month]. I have a tech pack / I am preparing a tech pack (delete as appropriate). Could you please tell me your minimum order quantity per style, your typical lead time from approved sample to delivery, and whether you work with [fabric, e.g. GOTS-certified organic cotton]? I would also be grateful for any information about your social and environmental certifications. Thank you, [your name], [website or email].

**First contact with a fabric supplier:**

> Subject: Fabric enquiry — [fabric type], [quantity] metres
>
> Hello, I am launching a small clothing brand and I am looking for [fabric, e.g. GOTS-certified organic cotton poplin, around 150–180 GSM] for a first order of approximately [quantity] metres. Could you please send me swatches, your price per metre, minimum order quantity, lead time, and a copy of the relevant certification? Thank you, [your name], [brand name].

**Asking for a certificate:**

> Hello, thank you for the information. Before I place an order, could you please send me a copy of the [GOTS / GRS / OEKO-TEX, as appropriate] certificate covering this product, including the certificate number and expiry date? I keep certification records on file for every material I use. Thank you.

## Appendix C — Launch Budget Template (Illustrative)

An illustrative first-collection budget for a five-style collection, 50 units per style (250 units total). Replace every figure with your own quotes.

| Item | Illustrative cost |
|---|---|
| Samples and development (5 styles, 2 rounds) | £1,200 |
| Stock: 250 units at an average landed cost of £32 | £8,000 |
| Photography (one day, 5 styles) | £800 |
| Website setup (first year) | £400 |
| Packaging (mailers, tags, tissue) | £350 |
| Launch marketing | £500 |
| Contingency (10%) | £1,125 |
| **Total illustrative budget** | **£12,375** |

This is an illustration, not a promise: your figures will differ by country, factory, fabric, and quantity. The point of the template is the discipline — budget for samples, photography, packaging, and a contingency, not just the stock. Founders who budget only for stock run out of money before they have anything to sell.

---

## Disclaimer

This programme is education only. It is not legal, tax, financial, or business advice, and it does not guarantee income, sales, profit, or business success. All worked examples use illustrative figures that will differ from real quotes; always obtain your own quotes and professional advice before spending money or making claims about your products. Results depend on your market, capital, product, and effort. Check the labelling, advertising, and environmental-claim rules in every country where you sell, and consult a qualified adviser before publishing claims or labels. The author and the marketplace accept no liability for business decisions made on the basis of this programme. If you are unsure about a legal or financial matter, seek advice from a qualified professional in your jurisdiction.
