# Customer Onboarding Guide — GRN-06

**Product:** The Sustainable Fashion Founder: Build an Ethical Clothing Brand
**SKU:** GRN-06

Welcome — and thank you for buying the programme. This guide tells you what to do first, how to use the materials, and how to get support.

## What You Have Received

Your download contains:

| File | What it is |
|---|---|
| `content.md` | The full programme — 9 modules, fully written, with worked examples and appendices |
| `workbook.md` | Companion workbook — 6 worksheets plus a launch checklist and 90-day action plan |
| `templates/garment-costing-calculator.csv` | Cost three styles line by line, with wholesale and break-even maths |
| `templates/supplier-vetting-checklist.md` | Scored checklist for vetting any supplier |
| `templates/materials-sourcing-directory.md` | Ten material entries with suppliers, channels, and what to verify |
| `templates/brand-story-worksheet.md` | Build your brand story for your About page and product pages |
| `sales-page.md` | The programme's sales page, for reference |
| `cover.png` | The programme cover image |
| `cover.md` | The cover design brief |
| `README.md` | Index of this folder |

All files are standard documents you can read on any device. Print the workbook and templates, or copy them into a notebook or document — the point is to write real answers with real numbers.

## What To Do First (Your First Hour)

1. **Read the introduction and Table of Contents in content.md** so you know where everything lives.
2. **Read Module 1.** It sets the honest foundation for everything that follows: the garment lifecycle, the three pillars, and why honesty is a business strategy.
3. **Write your honest audit** (Module 1.5): your skills, the money you can realistically put into a first collection, the hours you can give each week, and the smallest real version of your brand.
4. **Open the workbook** and start Worksheet 1 (Brand Positioning). It is a draft at this stage — you will refine it in Module 2.

## How To Use The Materials

- **Work through the modules in order.** Each module ends with actions to complete before moving on. Do not skip the supplier-contact and costing steps — they are where the real decisions happen.
- **Use the workbook alongside the programme.** Each worksheet is linked to a module; complete it as you finish that module.
- **Use the templates for every collection.** The costing calculator, vetting checklist, sourcing directory, and brand story worksheet are designed to be reused — copy them fresh for each new style or supplier.
- **Replace every example number with your own quotes.** All worked examples in the programme use illustrative figures. They show you the method; your supplier quotes give you the answer.
- **Keep your evidence filed.** Certificates, supplier emails, samples, and quotes should be kept together — when a claim is ever questioned, your records are your defence.

## Suggested Schedule — 90 Days

| Weeks | Focus |
|---|---|
| 1–2 | Foundations and positioning (Modules 1–2; Workbook Worksheet 1) |
| 3–4 | Materials (Module 3; Worksheet 2; order swatches) |
| 5–6 | Suppliers (Module 4; Worksheet 3; first-contact emails) |
| 7–8 | Costing and collection (Modules 5–6; Worksheet 4; tech pack) |
| 9–10 | Samples and honest claims (Module 7; claims list; brand story) |
| 11–12 | Marketing and launch preparation (Module 8; Worksheet 5; photography) |
| Launch week | Publish the collection; email your waitlist first |
| Days 30, 60, 90 | Review with real numbers (Module 9; Worksheet 6) |

Expect roughly two to four hours per module, plus the time to contact suppliers and get quotes. If you have more time, move faster — but do not skip steps.

## A Few Honest Expectations

- Launching a clothing brand takes capital, patience, and work. A slow first month is normal.
- You will not find a perfect fabric, a perfect factory, or a perfect claim. Your job is to make the best honest choices you can, say what you have done, and keep improving.
- Do not make a claim you cannot evidence — not on a product page, a label, or a social post. If you are unsure, check Module 7 or ask a qualified adviser.
- This programme is education only. It is not legal, tax, financial, or business advice, and it does not guarantee income, sales, or profit. Check the labelling, advertising, and environmental-claim rules in every country where you sell.

## How To Get Support

If you have a problem with your files or your download, contact support through the EightyTwenty marketplace help channel listed at checkout, quoting **SKU GRN-06** and your order number. Support covers file access, download problems, and questions about how to use the materials. Support does not provide legal, tax, or financial advice — for those matters, consult a qualified professional in your jurisdiction.

## Your Next Step

Open `content.md`, read Module 1, and write your honest audit. That single page — your real skills, money, and time — is the foundation everything else is built on.
