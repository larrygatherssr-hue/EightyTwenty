# Brand Story Worksheet

**SKU:** GRN-06 — The Sustainable Fashion Founder

Your brand story is the true, specific account of why this brand exists, who makes the clothes, and what changes because the brand exists. It is not a fairy tale and it is not a slogan. Work through the prompts below in plain language, then assemble the short version at the end. Use it on your About page, your product pages, and your launch email — the same story, told consistently, everywhere.

## 1. Who You Are

Write two or three sentences about yourself, as a person — not a company. What is your background, and what brought you to fashion?

___________________________________________________________________
___________________________________________________________________

## 2. The Problem You Saw

What specific problem did you notice — in your own wardrobe, in a shop, in a factory, or in the industry? Name the moment, if there was one. Be concrete: a garment that fell apart, a label that made a claim you could not believe, a maker whose work you admired.

___________________________________________________________________
___________________________________________________________________

## 3. What You Decided To Do About It

What is your brand's answer to that problem? State it in one or two sentences, without using the words "sustainable," "eco-friendly," or "conscious" on their own — say what you actually do.

___________________________________________________________________
___________________________________________________________________

## 4. Who Makes Your Clothes, and Where

Name the factory (or the type of maker, if you are sewing yourself) and the place. What do you know about the conditions there, and how do you know it? If you have visited, say when.

Factory / maker: ____________________________________________________
Location: __________________________________________________________
What I know about conditions, and how I verified it: ____________________
___________________________________________________________________

## 5. What Your Clothes Are Made From, and Why

For your hero product, state the material, why you chose it, and its honest trade-off — the weakness as well as the strength. Customers trust a founder who names the trade-off.

Material: __________________________________________________________
Why I chose it: _____________________________________________________
Its honest trade-off: ________________________________________________

## 6. What You Are Still Working On

List two or three things you have not solved yet — packaging, a fabric you want to replace, a certification you are working toward, a size range you want to extend. This is the part that makes the story believable. Do not hide it.

1. ________________________________________________________________
2. ________________________________________________________________
3. ________________________________________________________________

## 7. Your Promise (One Sentence)

Copy your brand promise from Workbook Worksheet 1. It must be specific and provable.

___________________________________________________________________

## 8. Your Story — Short Version (About Page, ~150 Words)

Assemble the answers above into a short story. Read it aloud. If it sounds like a press release, rewrite it until it sounds like a person talking.

___________________________________________________________________
___________________________________________________________________
___________________________________________________________________
___________________________________________________________________
___________________________________________________________________
___________________________________________________________________

## 9. Your Story — One Paragraph (Product Pages and Social Profiles)

Condense the short version to one paragraph of three to five sentences.

___________________________________________________________________
___________________________________________________________________
___________________________________________________________________

## 10. Story Checklist — Before You Publish

- [ ] Every claim in the story is specific and evidenced (see Module 7)
- [ ] No vague words ("sustainable," "eco-friendly," "green") stand alone without specifics
- [ ] The factory and place are named, or a clear reason is given for why not
- [ ] At least one honest "still working on" item is included
- [ ] The story names a real person and a real problem, not just a vision
- [ ] A sceptical reader could verify the main claims in an afternoon
- [ ] The tone matches your visual style guide (Workbook, Worksheet 1)
