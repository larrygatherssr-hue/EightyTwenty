# Sustainable Materials Sourcing Directory

**SKU:** GRN-06 — The Sustainable Fashion Founder

A working directory, not a shopping list. Use it to plan where to look, what to ask, and what to verify. Prices, minimums, and availability change constantly — always get a current quote and a swatch before deciding. Verify every certification claim against the certificate itself (see Module 7 and the Supplier Vetting Checklist).

## How To Use This Directory

For each material, the directory gives you: what it is, where it is typically sourced, what to verify, and the honest trade-offs. Add your own suppliers in the table at the end, with the date you contacted them and the quote they gave.

---

## 1. Organic Cotton

- **What it is:** Cotton grown without synthetic pesticides and fertilisers, usually certified to GOTS or OCS.
- **Best for:** T-shirts, shirting, trousers, dresses, jersey, canvas, denim.
- **Typical suppliers / channels:** Specialist organic fabric merchants and mills in Turkey, India, Portugal, and China; organic cotton merchants at textile trade shows; deadstock dealers for smaller quantities.
- **What to verify:** GOTS or OCS certificate, with certificate number, scope, and expiry date; check the number against the issuer's database. Confirm whether the certification covers the fabric you are buying, not just the raw cotton.
- **Typical price signal:** Roughly 20–50% more than conventional cotton at fabric level. Expect higher prices for low minimums and custom dyeing.
- **Trade-offs:** Still a thirsty crop; wrinkles and wears at stress points; recycled cotton is weaker and best blended.
- **Ask the supplier:** "Can you send the GOTS certificate covering this exact fabric, and a swatch in the weight I need?"

## 2. Linen (Flax)

- **What it is:** Fibre from the flax plant; needs far less water and fewer chemicals than cotton.
- **Best for:** Summer shirts, dresses, trousers, relaxed tailoring.
- **Typical suppliers / channels:** European linen mills (notably Belgium, France, Lithuania, Ireland); specialist linen merchants; trade shows.
- **What to verify:** Origin of the flax (European flax is generally well documented); any certification claimed; whether the linen is pure or blended, and with what.
- **Typical price signal:** More expensive than cotton; narrower colour range in natural dyeing.
- **Trade-offs:** Wrinkles readily (sell as character); limited stretch; strong and improves with wear.
- **Ask the supplier:** "Where is the flax grown and retted, and is the fabric pure linen or a blend?"

## 3. Hemp

- **What it is:** Fast-growing, low-water, low-pesticide fibre producing a strong, durable fabric.
- **Best for:** Overshirts, jackets, trousers, canvas goods; hemp-cotton blends for softer shirting and T-shirts.
- **Typical suppliers / channels:** Specialist hemp mills and merchants (China and Europe are the main sources); smaller supply base than cotton, so order further ahead.
- **What to verify:** Fibre content (pure hemp vs. blend, and the exact blend ratio); processing method; any certification claimed.
- **Typical price signal:** Variable; blends are usually more affordable and softer than pure hemp.
- **Trade-offs:** Smaller, less standardised supply; pure hemp can feel coarse; availability varies by season.
- **Ask the supplier:** "What is the exact blend ratio, and can you guarantee repeat supply of this cloth?"

## 4. Wool (Including Merino)

- **What it is:** Natural, renewable, biodegradable fibre with excellent insulation and odour resistance.
- **Best for:** Knitwear, tailoring, outerwear, winter layers.
- **Typical suppliers / channels:** Wool merchants and mills in the UK, Italy, Australia, and New Zealand; specialist knitwear factories.
- **What to verify:** Responsible Wool Standard (RWS) or equivalent certification for animal welfare and land management; whether the wool is superwash-treated and, if so, how; country of origin.
- **Typical price signal:** Mid-to-high; merino is the softest and most expensive grade.
- **Trade-offs:** Higher cost; needs care in washing; can irritate sensitive skin.
- **Ask the supplier:** "Is this wool RWS-certified, and is it superwash-treated?"

## 5. TENCEL™ / Lyocell

- **What it is:** Regenerated fibre from wood pulp (usually eucalyptus or beech). TENCEL™ is Lenzing's brand, made in a closed-loop process that recovers most of the solvent; generic lyocell may or may not use the same process.
- **Best for:** Dresses, shirts, blouses, linings, drapey pieces.
- **Typical suppliers / channels:** Lenzing-authorised mills and distributors; fabric merchants stocking branded TENCEL™.
- **What to verify:** Whether the fibre is branded TENCEL™ or generic lyocell; the producer and process; the exact blend (lyocell is often blended with cotton, linen, or wool).
- **Typical price signal:** Mid-to-high.
- **Trade-offs:** Beautiful drape and softness; weaker when wet unless blended; verify generic lyocell claims rather than assuming closed-loop production.
- **Ask the supplier:** "Is this branded TENCEL™ or generic lyocell, and who is the fibre producer?"

## 6. Viscose / Rayon

- **What it is:** Regenerated fibre from wood pulp, usually in an open chemical process.
- **Best for:** Drapey dresses and blouses — only when the producer is verified.
- **Typical suppliers / channels:** Large mills in Asia; verify producer commitments to responsible production.
- **What to verify:** The producer's environmental and chemical practices and any third-party verification. Do not accept a generic "eco viscose" claim without evidence.
- **Typical price signal:** Cheap and widely available — which is itself a warning sign for an ethical brand.
- **Trade-offs:** Lovely drape, but chemical-intensive unless responsibly produced. If you cannot verify the producer, do not use it.
- **Ask the supplier:** "Which producer makes this viscose, and what third-party verification supports the environmental claim?"

## 7. Recycled Polyester (rPET)

- **What it is:** Polyester made from recycled plastic bottles or, better, from recycled textiles; GRS is the relevant certification.
- **Best for:** Outerwear, swimwear, activewear — where its properties genuinely help.
- **Typical suppliers / channels:** Specialist recycled-fibre mills; GRS-certified suppliers.
- **What to verify:** GRS certificate with scope and expiry; the recycled content percentage; whether the source is post-consumer bottles or post-consumer textiles.
- **Typical price signal:** More expensive than virgin polyester; cheaper than most natural performance fabrics.
- **Trade-offs:** Still plastic; sheds microfibres when washed; bottle-to-fibre is not circular for clothing. Use where function justifies it, not as a green badge.
- **Ask the supplier:** "What is the recycled content percentage, and can you send the GRS certificate?"

## 8. Recycled Cotton and Recycled Wool

- **What it is:** Fibre reclaimed from pre-consumer cutting waste or post-consumer garments.
- **Best for:** Heavier fabrics, knitwear, casual pieces; often blended with virgin fibre for strength.
- **Typical suppliers / channels:** Specialist recyclers in India, Turkey, Italy (notably Prato for recycled wool), and Spain.
- **What to verify:** GRS certification; whether the input is pre-consumer or post-consumer; the blend ratio.
- **Typical price signal:** Competitive, but quality varies — always order a swatch and wash-test it.
- **Trade-offs:** Shorter fibres, weaker yarn, best blended; colour is often determined by the input waste, limiting dye options.
- **Ask the supplier:** "Is this pre- or post-consumer recycled, and what is the exact blend?"

## 9. Leather and Leather Alternatives

- **What it is:** Conventional leather (animal hide, usually chrome-tanned unless stated otherwise), vegetable-tanned leather, and plant-based alternatives (cactus, mushroom/mycelium, pineapple leaf).
- **Best for:** Bags, belts, jackets, footwear, trims.
- **Typical suppliers / channels:** Tanneries and leather merchants (Italy, Spain, India); specialist suppliers of plant-based alternatives.
- **What to verify:** Tanning method (chrome vs. vegetable); animal welfare and traceability claims; for alternatives, the full composition — some are mostly polyurethane with a plant coating. Read the composition, not the marketing name.
- **Typical price signal:** Vegetable-tanned leather is slower and more expensive; plant-based alternatives vary enormously in price and durability.
- **Trade-offs:** Chrome tanning is hazardous unless carefully managed; alternatives vary in durability, plastic content, and cost.
- **Ask the supplier:** "What is the full composition, including the percentage of polyurethane or other synthetic content?"

## 10. Trims, Threads, and Packaging

- **Buttons:** Corozo nut, recycled metal, or natural horn instead of virgin plastic. Ask for composition and origin.
- **Zips:** Recycled metal or recycled polyester tape; check the tape composition, not just the teeth.
- **Thread:** Organic cotton or recycled polyester thread to match the garment's claims.
- **Labels:** Organic cotton or recycled polyester labels; printed care information must be accurate.
- **Packaging:** Compostable or recycled mailers, recycled tissue, paper tape. Do not claim packaging is plastic-free if the garment arrives in a polybag inside it.

## My Supplier Contacts

| Material | Supplier name | Country | Contact | Date contacted | Price / MOQ quoted | Certificate seen? |
|---|---|---|---|---|---|---|
| | | | | | | |
| | | | | | | |
| | | | | | | |
| | | | | | | |
| | | | | | | |

## A Final Warning

A supplier listing that claims "organic, fair trade, GOTS certified" with no certificate number and no verifiable company address is an unproven claim, not a fact. Treat it as unproven until you have the certificate in hand and have checked it. The cheapest quote is often the most expensive mistake: if a price is far below every other quote, someone — usually the worker or the environment — is paying the difference.
