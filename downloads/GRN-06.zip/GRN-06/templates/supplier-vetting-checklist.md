# Supplier Vetting Checklist

**SKU:** GRN-06 — The Sustainable Fashion Founder

Use one copy of this checklist per supplier — fabric merchant, cut-and-sew factory, full-package factory, or trim supplier. Do not place a bulk order until every item is either verified or consciously accepted as a known gap, recorded in writing.

## 1. The Business Is Real

- [ ] Registered company name and registration number obtained
- [ ] Physical business address confirmed (not only a messaging-app profile)
- [ ] Named contact person, with role and direct email or phone
- [ ] Website, trade directory listing, or trade-show presence found
- [ ] How long has the business been trading? ______________________

## 2. Certifications — Verified, Not Assumed

- [ ] Certificate document received (not a logo or a screenshot)
- [ ] Issuing body named: ________________________________________
- [ ] Certificate number: ________________________________________
- [ ] Scope covers the exact product I am buying: ☐ Yes ☐ No ☐ Unclear
- [ ] Expiry date: ______________________ (in date? ☐ Yes ☐ No)
- [ ] Certificate number checked against the issuer's public database
- [ ] I understand what this certificate does and does not cover (e.g. a fabric certificate does not certify factory labour conditions)

**Certifications to ask about, as relevant:** GOTS, OCS, GRS, OEKO-TEX® Standard 100, Fairtrade, Responsible Wool Standard, factory social audit programmes (e.g. Fair Wear, SA8000, BSCI/amfori). Never use a certification logo you have not earned.

## 3. Labour and Working Conditions (Factories)

- [ ] Most recent social audit or assessment shared, with date and auditor named
- [ ] Corrective actions from the last audit described
- [ ] Working hours, wage, and safety policies described in writing
- [ ] Subcontracting disclosed: who makes what, and where
- [ ] Factory visit planned or completed: date ______________________
- [ ] No evidence of forced labour, child labour, or unsafe conditions

**Note:** An audit is a snapshot, not a guarantee. A factory that refuses to share anything is itself an answer.

## 4. Quality and Reliability

- [ ] References from other customers at my scale requested — and contacted
- [ ] Reference feedback recorded: ________________________________
- [ ] Sample ordered and received
- [ ] Sample inspected: seams, stitching, measurements, trims, labelling
- [ ] Sample washed once and checked for shrinkage, colour loss, pilling
- [ ] Defect rate and remedy agreed in writing (what happens if goods are faulty?)

## 5. Commercial Terms — In Writing Before You Pay

- [ ] Price per unit confirmed, with what it includes (fabric? trims? packing?)
- [ ] Minimum order quantity (MOQ): __________ units / metres per style / colour
- [ ] Lead time from approved sample to delivery: __________ weeks
- [ ] Payment terms: deposit ______% on order, balance ______% before shipping
- [ ] Currency and payment method agreed; fees understood
- [ ] Delivery terms agreed (who pays freight, duty, and customs handling?)
- [ ] What happens if delivery is late? Agreed in writing: _______________
- [ ] Pre-production sample approval required in writing before bulk cutting

**Never pay 100% upfront to a supplier you have not vetted. Get everything in writing.**

## 6. Red Flags — Walk Away If You See These

- [ ] Refuses to provide certification documents
- [ ] Cannot name the factory where your garments will be made
- [ ] Subcontracts without telling you
- [ ] Demands full payment upfront
- [ ] Quotes a price far below every other quote
- [ ] Pressures you to skip sampling
- [ ] Will only communicate through a messaging app, with no business address

Any one of these is a reason to pause. Two is a reason to leave — politely, and without arguing.

## Decision

**Supplier:** ______________________ **Date:** ______________________

**Score (from Workbook Worksheet 3):** ______ / 20

**Decision:** ☐ Proceed ☐ Proceed with conditions ☐ Do not proceed

**Conditions / next steps:** ________________________________________

**Evidence filed at:** _____________________________________________
