# GRN-06 — The Sustainable Fashion Founder: Build an Ethical Clothing Brand

**Category:** Green Living & Sustainability

**Price:** $297 (one-time)

**Headline:** Launch an ethical clothing brand — source sustainably, cost honestly, and prove it.

## Files in This Folder

| File | What it is |
|---|---|
| `content.md` | Full 9-module programme (written, self-paced), with worked examples and appendices — 12,218 words |
| `workbook.md` | Companion workbook: 6 worksheets (brand positioning, materials comparison, supplier vetting scorecard, garment costing, launch checklist, 90-day action plan) |
| `templates/garment-costing-calculator.csv` | Garment costing calculator — materials, labour, trims, shipping, margin, retail price, plus wholesale and break-even maths and two worked examples |
| `templates/supplier-vetting-checklist.md` | Supplier vetting checklist — business, certifications, labour, quality, commercial terms, red flags |
| `templates/materials-sourcing-directory.md` | Materials sourcing directory — 10 material entries with typical suppliers/channels and what to verify |
| `templates/brand-story-worksheet.md` | Brand story worksheet — build a true, specific brand story |
| `sales-page.md` | Full sales page (headline, problem, solution, module list, who it is/is not for, $297 price + 14-day guarantee, 8 FAQs, disclaimer) |
| `listing.json` | Marketplace listing data (SKU GRN-06, price_cents 29700, one-time billing, keywords, refund and support info) |
| `cover.png` | Cover image (premium black-and-gold) |
| `cover.md` | Cover design brief |
| `onboarding.md` | Customer onboarding guide |
| `README.md` | This index |

## Target Customer

Fashion entrepreneurs and designers who want to launch an eco-friendly clothing brand without greenwashing.

## Note

All content is original. No testimonials, sales figures, certifications, or reviews are fabricated. Worked numbers are realistic planning illustrations, and the disclaimer in content.md, workbook.md, and sales-page.md states that results vary and this is business education, not a guarantee of income. The programme warns against greenwashing throughout and requires honest, verifiable claims.
