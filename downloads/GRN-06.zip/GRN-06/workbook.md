# The Sustainable Fashion Founder — Companion Workbook

**SKU:** GRN-06 | **Programme:** The Sustainable Fashion Founder: Build an Ethical Clothing Brand

Work through these worksheets in order, alongside the programme modules. Print them or copy them into a notebook or document — the point is to write real answers, with real numbers, not to collect blank forms. Keep the completed workbook with your supplier records: it is the working file of your brand.

---

## Worksheet 1 — Brand Positioning (Module 2)

**Your customer, as a real person:**

- Name (give them a name): ________________________________________
- Age and life: ____________________________________________________
- What they do for work: ___________________________________________
- What they currently buy, and what they pay for it: ____________________
- The wardrobe problem that frustrates them most: _____________________
- The exact words they use to describe that problem: ___________________

**The problem your brand solves (one sentence):**

___________________________________________________________________

**How you are different — two things a customer can check:**

1. ________________________________________________________________
2. ________________________________________________________________

**Your price band:** from £/$ ______ to £/$ ______ per garment. Why this band is fair:

___________________________________________________________________

**Your brand promise (one sentence, provable — see Module 2.3):**

___________________________________________________________________

For each word in your promise, how would a sceptical customer check it?

___________________________________________________________________

**Business model:** Direct-to-consumer / Wholesale / Both (circle one). Why:

___________________________________________________________________

**Brand name — top three choices, with domain and social handle availability checked:**

1. ______________________  Domain: ☐ Available  Handles: ☐ Available
2. ______________________  Domain: ☐ Available  Handles: ☐ Available
3. ______________________  Domain: ☐ Available  Handles: ☐ Available

**Visual style guide:**

- Colours (three): _________________________________________________
- Typefaces (two): _________________________________________________
- Photography direction: ___________________________________________
- Tone of voice (three words): ______________________________________

---

## Worksheet 2 — Materials Comparison (Module 3)

Complete one row per candidate fabric. Get the figures from real supplier quotes and swatches, not from memory.

| | Fabric A | Fabric B | Fabric C |
|---|---|---|---|
| Fabric name and supplier | | | |
| Composition (exact %) | | | |
| Weight (GSM) and width | | | |
| Price per metre | | | |
| Minimum order | | | |
| Certifications (with certificate no.) | | | |
| Main environmental strength | | | |
| Main environmental weakness | | | |
| Durability in your wash/stretch test | | | |
| Care requirements | | | |
| End-of-life route | | | |
| Cost per garment (metres × price) | | | |
| Verdict: use / maybe / reject, and why | | | |

**Blends check:** Does any fabric contain a blend? If so, why is the blend necessary, and have you disclosed the exact composition?

___________________________________________________________________

**Trims and packaging notes (buttons, zips, thread, labels, mailers):**

___________________________________________________________________

---

## Worksheet 3 — Supplier Vetting Scorecard (Module 4)

Complete one scorecard per supplier. Score each item 0 (no evidence), 1 (partial), or 2 (verified). A supplier scoring below 10 out of 20 needs more evidence before you order; any single red flag (see Module 4.7) is a reason to pause regardless of score.

**Supplier name:** ______________________ **Type:** Fabric / Factory / Trims

**Contact name and role:** ______________________ **Date:** ______________

| Check | Evidence seen | Score (0–2) |
|---|---|---|
| Registered business, real address | | |
| Named contact, professional communication | | |
| Certificate(s) provided, in date, scope matches product | | |
| Certificate number verified against issuer database | | |
| Social audit or assessment shared, with corrective actions | | |
| References from customers at my scale, contacted | | |
| Sample ordered and inspected (fit, stitching, wash test) | | |
| MOQ, lead time, and payment terms in writing | | |
| Quality standard and defect/remedy terms agreed | | |
| Subcontracting disclosed (who makes what, where) | | |

**Total score: ______ / 20**

**Red flags noted:** _________________________________________________

**Decision:** Proceed / Proceed with conditions / Do not proceed

**Conditions or next steps:** _________________________________________

---

## Worksheet 4 — Garment Costing (Module 5)

Complete one worksheet per style. Use the garment-costing-calculator.csv template for the arithmetic, and record the summary here.

**Style:** ______________________ **Planned quantity:** ______ units

| Cost item | Per unit |
|---|---|
| Fabric (metres × price per metre, incl. waste) | |
| Trims | |
| Labour (cut, make, trim) | |
| Sampling spread (total sampling cost ÷ quantity) | |
| Freight, duty, and handling | |
| Packaging | |
| Payment / currency costs | |
| **Landed cost per unit** | |
| **Retail price** | |
| **Gross margin %: (retail − landed) ÷ retail × 100** | |
| **Margin per unit (£/$)** | |

**Wholesale check:** If a shop paid 50% of retail, my margin per unit would be: ________. Is wholesale viable at this cost? Yes / No — why: _______________

**Break-even for the collection:** Fixed launch costs £/$ ______ ÷ contribution per unit £/$ ______ = ______ units.

**What would have to be true for me to sell that many units?**

___________________________________________________________________

**Discount test:** At a 20% discount, my margin per unit would be: ________. How often will I discount, and why?

___________________________________________________________________

**Return allowance:** I am budgeting for a ______% return rate. Cost per returned unit: ________.

---

## Worksheet 5 — Launch Checklist (Module 9)

Tick each item when it is genuinely done — not when it is "nearly" done.

**Product pages**

- [ ] Correct photographs for every style, size, and colour
- [ ] Prices, sizes, fabric composition, and care instructions correct
- [ ] Country of origin stated
- [ ] Delivery time stated (including pre-order / made-to-order waits)
- [ ] Cost breakdown or materials story published for the hero product
- [ ] Returns and exchanges policy written in plain language and easy to find

**Store and fulfilment**

- [ ] Test order placed end to end, including payment
- [ ] Packaging ready; one order packed and posted as a trial
- [ ] Stock levels checked by size and colour; website matches physical stock
- [ ] Labels printed and correct

**Marketing**

- [ ] Launch email written and scheduled
- [ ] Launch posts prepared for chosen platforms
- [ ] Email list set up; welcome email written
- [ ] Plan for answering customer questions in launch week

**Customer care**

- [ ] First-question, first-return, and first-complaint responses drafted
- [ ] Support contact details published

**Launch date:** ______________________

---

## Worksheet 6 — 90-Day Action Plan (Modules 1–9)

**Weeks 1–2 — Foundations and positioning**

- [ ] Honest audit written (Module 1)
- [ ] Customer interviews: 5–10 people, exact words recorded
- [ ] Brand Positioning Worksheet completed (Worksheet 1)

**Weeks 3–4 — Materials**

- [ ] Swatches ordered from at least three suppliers
- [ ] Materials Comparison Worksheet completed (Worksheet 2)
- [ ] Materials library started

**Weeks 5–6 — Suppliers**

- [ ] First-contact emails sent to at least three suppliers
- [ ] Supplier Vetting Scorecards completed (Worksheet 3)
- [ ] Factory and fabric choices narrowed to one combination

**Weeks 7–8 — Costing and collection**

- [ ] Garment Costing Worksheets completed (Worksheet 4) for every style
- [ ] Break-even calculated
- [ ] First collection chosen: 3–5 styles with roles and prices
- [ ] Tech pack drafted for the hero product

**Weeks 9–10 — Samples and honest claims**

- [ ] Samples ordered, inspected, washed, and worn
- [ ] Claims list written with evidence filed for each claim
- [ ] Labelling requirements checked for every country of sale
- [ ] Brand Story Worksheet completed

**Weeks 11–12 — Marketing and launch preparation**

- [ ] Product descriptions written (honest-claim rules applied)
- [ ] Photography completed
- [ ] Email list and welcome email ready
- [ ] Launch Checklist completed (Worksheet 5)

**Launch week**

- [ ] Collection published; waitlist emailed first
- [ ] Customer questions answered the same day

**Days 30, 60, and 90 — Review**

- [ ] Weekly tracking sheet updated (units, revenue, returns, questions, sources)
- [ ] 90-day review written with real numbers (Module 9.3)
- [ ] Reorder / restock / retire decisions recorded with reasons

**My 90-day review date (write it in your calendar now):** ______________________

---

## Disclaimer

This workbook is education only. It is not legal, tax, financial, or business advice, and it does not guarantee income, sales, profit, or business success. All example figures in the programme are illustrative; always obtain your own quotes and professional advice before spending money or making claims about your products. Results depend on your market, capital, product, and effort. Check the labelling, advertising, and environmental-claim rules in every country where you sell, and consult a qualified adviser before publishing claims or labels.
