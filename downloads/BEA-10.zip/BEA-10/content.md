# The 12-Week Reset: Fitness, Habits & Lifestyle Transformation

**A self-paced 12-week fitness and lifestyle programme for busy adults aged 30–55.**

---

## Important Disclaimer — Please Read First

This programme is **fitness and lifestyle education only**. It is not medical advice, and it does not diagnose, treat, cure, or prevent any disease or health condition. The workouts, habit targets, and nutrition guidance in this book are general educational information for healthy adults.

**Consult a qualified clinician before starting any exercise or nutrition programme**, especially if you have an existing health condition, are pregnant, take medication, have a history of heart disease, high blood pressure, diabetes, joint problems, back pain, or any other medical concern, or have been inactive for a long time. Stop exercising and seek medical advice if you feel chest pain, dizziness, severe shortness of breath, or sharp joint pain.

No result is guaranteed. Your results will depend on your starting point, consistency, sleep, nutrition, and many factors outside this programme's control. The programme is designed to be progressive and safe, with modifications throughout, but you are responsible for listening to your body and working within your own limits. If an exercise causes pain (as distinct from effort or mild muscle soreness), stop and choose the modification or skip it.

---

## Table of Contents

1. Welcome: Why Most Resets Fail — and Why This One Is Different
2. How the Programme Works: The Three Pillars
3. Before You Begin: Your Starting Point, Your Kit, Your Rules
4. The Movement Library: How to Do Every Exercise Safely
5. Week 1 — Foundation: Move Daily, Drink Water, Sleep on Time
6. Week 2 — Rhythm: Building Your Training Week
7. Week 3 — Strength Basics: Learning the Big Moves
8. Week 4 — First Check-In: Measure, Review, Adjust
9. Week 5 — Energy: Eating for Steady Fuel
10. Week 6 — Midway Momentum: Adding Challenge
11. Week 7 — Consistency Under Pressure: Busy-Week Plans
12. Week 8 — Strength Progression: Heavier, Steadier, Stronger
13. Week 9 — Second Check-In: What Has Actually Changed
14. Week 10 — The Home Stretch: Raising the Bar Gently
15. Week 11 — Real-Life Proof: Training Around Life, Not Instead of It
16. Week 12 — Finish Strong: Your Reset Review and What Comes Next
17. After the Reset: The Maintenance Plan
18. The Recipe Collection: 40 Simple Meals
    - Breakfasts (Recipes 1–10)
    - Lunches (Recipes 11–20)
    - Dinners (Recipes 21–30)
    - Snacks and Sides (Recipes 31–40)
19. Appendix A: Exercise Glossary and Modifications
20. Appendix B: The 5-Minute Warm-Up and Cool-Down
21. Appendix C: Troubleshooting — Common Stalls and Fixes

---

## 1. Welcome: Why Most Resets Fail — and Why This One Is Different

You have probably done this before. A new programme, a burst of enthusiasm, two hard weeks, then life gets in the way — a late meeting, a bad night's sleep, a weekend away — and the whole thing quietly collapses. The problem was never your willpower. The problem was the plan.

Most fitness programmes fail busy adults for three reasons. First, they are too rigid: miss one session and you feel behind, so you quit. Second, they are too intense too soon: six hard workouts a week after months of inactivity is a recipe for soreness, exhaustion, and injury. Third, they treat exercise as separate from the rest of your life — as if sleep, food, stress, and a packed calendar do not matter. They do. They matter more than the workout itself.

The 12-Week Reset is built the other way around. It starts where you are, not where a fitness influencer is. It asks for three training sessions a week, not six. It treats walking, sleep, water, and simple home cooking as equal partners to the workouts, because for most people those habits move the needle further than any single exercise. And it is designed to bend: every week includes a "busy-week" version, so a hard week at work costs you a little progress, not the whole programme.

Over twelve weeks you will build, in order: a daily movement habit, a regular training rhythm, basic strength, better eating patterns, and the ability to keep going when life gets difficult. That is the whole secret. There is no trick, no detox, no extreme diet, no live coach required, and no gym membership needed — although the programme works just as well in a gym if you have one.

### Who this programme is for

- Adults aged roughly 30 to 55 who are busy, out of routine, or returning to exercise after a break.
- People who want structure without rigidity, and progress without punishment.
- People who can commit to about three hours a week of training plus small daily habits.
- People who want to feel stronger, sleep better, and have more energy — not chase a specific number on a scale.

### Who it is not for

- Anyone with a medical condition that affects exercise, unless a clinician has cleared them to follow a programme like this.
- Anyone looking for a rapid weight-loss plan, a bodybuilding programme, or preparation for a specific sport or competition.
- Anyone who wants a live coach, daily check-ins, or a meal plan with exact calorie counts. This is a self-paced programme; the structure is here, the doing is yours.

### What you will need

- A mat or a carpeted floor, a sturdy chair, and a wall.
- A pair of dumbbells or two filled water bottles to start (a light pair and, later, a heavier pair if you can get them). Resistance bands are a useful optional extra.
- A water bottle, comfortable shoes, and clothes you can move in.
- This book, the companion workbook, and the templates in the `templates/` folder.
- About 30 to 45 minutes, three times a week, plus 20 to 30 minutes of walking most days.

---

## 2. How the Programme Works: The Three Pillars

The Reset rests on three pillars. If one wobbles, the other two hold the programme up. That is deliberate — it is what makes the plan survivable.

**Pillar 1 — Move.** Three structured sessions a week, built around strength, walking, and mobility. Strength sessions use bodyweight and dumbbells, progress gradually, and always include a warm-up and a cool-down. Walking is the quiet engine of the programme: it burns energy, clears the head, aids recovery, and asks almost nothing of you.

**Pillar 2 — Habits.** Small daily targets that compound: water, sleep timing, a protein source at each meal, a daily walk, and one screen-free wind-down in the evening. You track them with the habit tracker, and you add only one new habit at a time. Habits are scored weekly, never daily — a bad Tuesday does not ruin a good week.

**Pillar 3 — Eat simply.** No calorie counting, no banned foods, no detox. The nutrition guidance in this programme is a plate method: half vegetables or salad, a quarter protein, a quarter slow carbohydrates, plus a thumb of healthy fat. You will plan three or four home-cooked dinners a week from the 40 recipes in this book, keep breakfast simple and protein-based, and build a lunch you can repeat without thinking.

### The weekly rhythm

Every week follows the same skeleton, so you never have to wonder what to do:

- **Monday:** Strength Session A (30–40 minutes)
- **Tuesday:** Walk 20–30 minutes + 5-minute mobility
- **Wednesday:** Strength Session B (30–40 minutes)
- **Thursday:** Walk 20–30 minutes + 5-minute mobility
- **Friday:** Strength Session C — or a full-body circuit (30–40 minutes)
- **Saturday:** Longer walk, bike ride, swim, or any activity you enjoy (30–60 minutes, easy pace)
- **Sunday:** Rest, meal planning (15 minutes), and the weekly check-in worksheet

If your week does not allow that shape, move the sessions. Three strength sessions in any order, on any days, with at least one rest day between strength days, is a complete week. That is the rule. Everything else is preference.

### The three levels

Every workout in this programme is written for three levels. Choose honestly, and re-choose at each four-week check-in.

- **Beginner:** You have done little or no structured exercise in the last six months, or you are returning after a long break. You will use bodyweight only at first, fewer sets, and longer rests.
- **Intermediate:** You exercise once or twice a week already, or you have trained before and remember the movements. You will use light dumbbells and the full set and rep ranges.
- **Advanced:** You train two or three times a week already and want a structured progression. You will use heavier dumbbells, extra sets, and harder variations.

A note on pride: starting at Beginner when you are capable of Intermediate costs you nothing and protects you from the soreness and discouragement that ends programmes in week two. Starting too high costs you the programme. Choose the level that lets you finish every session feeling like you could have done a little more.

### How progress works

Progress in this programme comes from small, regular increases — one more repetition, a slightly heavier dumbbell, a slightly longer walk, one more habit ticked most days. You will not add weight and reps and sets all at once. The rule is: when you can complete all the sets and reps of an exercise at your level with good form and two repetitions still in reserve, increase the difficulty next session — by adding reps first, then weight. If your form breaks down, stay where you are. Strength built slowly is strength that stays.

---

## 3. Before You Begin: Your Starting Point, Your Kit, Your Rules

Do not skip this chapter. The ten minutes you spend here save you from the two most common beginner mistakes: starting too hard, and having no record of where you began.

### Step 1: Get cleared if you need to

Re-read the disclaimer at the front of this book. If any of it applies to you, see your clinician before your first workout and bring this book. A clinician who knows your history can tell you which movements to avoid and which to favour. That conversation is worth more than any programme.

### Step 2: Take your starting measurements

On the morning of Day 1, before eating, fill in the measurement tracker in your workbook. Record your weight (if you choose to track it — it is optional and never the main measure of success), waist circumference at the navel, hip circumference, and resting heart rate if you have a watch or can count your pulse for 60 seconds. Take two photos — front and side, in fitted clothing, in the same spot with the same lighting — and log them in the progress photo log. You will repeat these in Week 4, Week 9, and Week 12. Photos and measurements are private; they are for your eyes only, and they exist so that on a week when you feel nothing has changed, you have evidence.

### Step 3: Set three goals — one for each pillar

Write one goal for movement, one for habits, and one for eating. Make each goal specific and forgiving. "Walk 25 minutes on five days a week" beats "get fit." "Cook dinner at home four nights a week" beats "eat better." "Be in bed by 10:30pm on weeknights" beats "sleep more." Write them in your workbook now, and review them at each check-in.

### Step 4: Prepare your space and your week

Lay out your mat, dumbbells, and water bottle where you will see them. Put your three training sessions in your calendar as appointments with yourself — same time each week if you can. Tell one person in your household what you are doing and when your sessions are, so they can give you the half hour uninterrupted. Then plan your first week's meals using the meal-planning template: pick three dinners from the recipe collection, write a shopping list, and shop once.

### Your rules for the next 12 weeks

1. **Never miss twice.** One missed session is life. Two in a row is a new habit. If you miss a session, do the next one — even the short version.
2. **Done beats perfect.** A 20-minute session counts. A short walk counts. A home-cooked meal counts, even if it is simple.
3. **Soreness is information, pain is a stop sign.** Mild muscle soreness for a day or two after a new session is normal. Sharp pain, joint pain, or pain that changes how you walk is not — stop, rest, and seek advice if it persists.
4. **Sleep is training.** A short night makes the next day's session harder and your appetite louder. Protect your bedtime like a session.
5. **The scale is the least interesting number.** Strength, energy, sleep quality, and how your clothes fit tell you far more. Weigh yourself at most once a week, at the same time, or not at all.

---

## 4. The Movement Library: How to Do Every Exercise Safely

Read this section once before Week 1, then refer back to it whenever a new exercise appears. Every exercise in the programme comes from this library. If a movement does not feel right, use the modification listed.

**General form rules for every exercise:** move slowly and with control, especially on the lowering phase (take two to three seconds); breathe out on the effort and in on the return; keep your spine in its natural position rather than rounding or over-arching your lower back; keep your knees tracking over your toes, never collapsing inward; and stop a set when your form breaks down, even if repetitions remain.

**Squat (bodyweight or goblet).** Feet shoulder-width apart, toes slightly out. Sit your hips back and down as if sitting into a chair, keeping your chest up and your weight through your heels. Go as low as you can with good form — thighs parallel to the floor is plenty. Stand by driving through your heels. *Modification:* hold a chair back for balance, or squat to a chair and stand up from it. *Harder:* hold a dumbbell at your chest (goblet squat).

**Glute bridge.** Lie on your back, knees bent, feet flat and close to your hips. Press through your heels to lift your hips until your body forms a straight line from shoulders to knees. Squeeze your glutes at the top, lower slowly. *Modification:* reduce the range. *Harder:* single-leg bridge, or a dumbbell resting on your hips.

**Push-up (wall, knee, or full).** Hands under your shoulders, body in a straight line from head to heels (or knees). Lower your chest toward the floor, elbows at roughly 45 degrees from your body, then press back up. *Modification:* hands on a wall, then on a sturdy table or bench, then knees on the floor. *Harder:* full push-ups, then feet elevated slightly.

**Dumbbell row.** Hinge forward from the hips with a flat back, one hand on a chair for support, a dumbbell in the other hand hanging toward the floor. Pull the dumbbell to your ribs, elbow close to your body, then lower slowly. *Modification:* use a water bottle or a lighter weight. *Harder:* heavier dumbbell, slower lowering phase.

**Overhead press.** Hold dumbbells at shoulder height, palms forward, core braced. Press overhead until your arms are straight but your elbows are not locked hard, then lower with control. *Modification:* seated on a chair with back support, or one arm at a time. *Harder:* heavier dumbbells.

**Romanian deadlift (dumbbell).** Stand tall holding dumbbells in front of your thighs. Hinge at the hips, pushing your hips back, knees soft, lowering the dumbbells along your legs until you feel a stretch in your hamstrings. Drive your hips forward to stand. Keep your back flat throughout — this is a hip hinge, not a bend at the waist. *Modification:* no weight, hands sliding down your thighs. *Harder:* heavier dumbbells.

**Reverse lunge.** Stand tall, step one foot back, lower until both knees are near 90 degrees, front knee over the ankle. Push through the front heel to return. Alternate legs. *Modification:* hold a chair for balance, or take a shorter step and reduce depth. *Harder:* hold dumbbells at your sides.

**Plank.** Forearms on the floor, elbows under shoulders, body in a straight line from head to heels. Brace your core as if someone were about to tap your stomach. Breathe normally. *Modification:* knees on the floor. *Harder:* longer holds, or lift one foot slightly.

**Dead bug.** Lie on your back, arms pointing to the ceiling, knees bent at 90 degrees. Slowly extend one arm overhead and the opposite leg out, keeping your lower back pressed gently into the floor. Return and switch sides. This teaches your core to stay stable while your limbs move.

**Bird dog.** On hands and knees, extend one arm forward and the opposite leg back, keeping your hips level. Hold briefly, return, switch sides. Move slowly.

**Side plank.** Lie on your side, elbow under your shoulder, body straight. Lift your hips. *Modification:* knees bent, lower leg on the floor. *Harder:* top leg lifted.

**March in place / step-ups.** For low-impact conditioning: march with high knees, or step up and down on a low sturdy step, alternating feet. Keep your chest up and step down with control.

**Walking.** The programme's base conditioning. Walk briskly enough that you can talk but not sing. Good posture: tall, shoulders relaxed, arms swinging naturally. Comfortable shoes matter more than speed.

**Stretching and mobility.** After every session, spend five minutes on gentle stretches: standing quad stretch, hamstring stretch, chest opener against a wall, cat-cow on hands and knees, and a slow neck roll. Hold each stretch for 20 to 30 seconds, breathing slowly. Never bounce, and never stretch into pain.

---

## 5. Week 1 — Foundation: Move Daily, Drink Water, Sleep on Time

**Weekly focus:** Start gently and prove to yourself that you can do this three times in one week. This week is about showing up, not performing.

The first week is deliberately easy. You will do three short full-body sessions of about 25 to 30 minutes, walk every day, and adopt two habits only: a glass of water with each meal and a fixed bedtime. If Week 1 feels too easy, that is correct. The programme is built so that Week 12 feels challenging; Week 1 should feel like a warm-up for your life, not a test.

**Workout A — Monday (full body, 25 minutes).** Warm up for 5 minutes (march in place, arm circles, gentle squats). Then perform 2 rounds of the following circuit, resting 60 to 90 seconds between exercises and 2 minutes between rounds:

- Beginner: bodyweight squat to chair — 8 reps; wall push-up — 8 reps; glute bridge — 10 reps; dumbbell row with water bottle — 8 reps each side; dead bug — 6 reps each side; plank on knees — 20 seconds.
- Intermediate: bodyweight squat — 10 reps; knee push-up — 10 reps; glute bridge — 12 reps; dumbbell row, light — 10 reps each side; dead bug — 8 reps each side; plank — 30 seconds.
- Advanced: goblet squat, light dumbbell — 12 reps; full push-up — 10 reps; single-leg glute bridge — 8 reps each side; dumbbell row, moderate — 12 reps each side; dead bug — 10 reps each side; plank — 40 seconds.

**Workout B — Wednesday (full body, 25 minutes).** Same structure, different emphasis: reverse lunge — 6 reps each leg (Beginner, holding a chair), 8 (Intermediate), 10 with dumbbells (Advanced); overhead press with water bottles or light dumbbells — 8/10/12 reps; Romanian deadlift with no weight or light dumbbells — 8/10/12 reps; bird dog — 6/8/10 reps each side; side plank — 15/20/30 seconds each side; march in place — 1 minute.

**Workout C — Friday (walk + mobility, 30 minutes).** A brisk 20-minute walk, then 10 minutes of gentle mobility: cat-cow, hip circles, chest opener, hamstring stretch, and deep breathing. This is a real session. Do not skip it because it feels easy — recovery and mobility are what let you train again on Monday.

**Habit targets this week:** Drink a glass of water with each meal (three glasses a day minimum, on top of what you already drink). Be in bed at your chosen time on at least five nights. Walk 15 minutes or more on at least five days. Tick each day in your habit tracker.

**Nutrition guidance this week:** Change nothing except breakfast. Make breakfast protein-based every day — eggs, Greek yoghurt, or porridge with nuts — instead of skipping it or eating something sweet. Eat lunch and dinner as normal. The point is to prove that one change is easy before adding more.

**Mindset note:** You are not "starting a fitness journey." You are running an experiment for twelve weeks. An experiment cannot be failed by one bad day; it can only be ended early. Keep the experiment running.

**End-of-week check-in:** Complete the Week 1 worksheet in your workbook. Score your habits out of 7 for each habit. Write one sentence about what felt easiest and one about what felt hardest. If you completed two of three sessions, that is a pass. Move on to Week 2 regardless.

---

## 6. Week 2 — Rhythm: Building Your Training Week

**Weekly focus:** Make the week repeatable. Same days, same times, same shape. Rhythm is what turns effort into routine.

Week 2 keeps the same exercises and adds a third round to Workout A and a little more walking. The goal is not to feel the burn; it is to feel the pattern settling in. By Sunday you should be able to describe your training week without looking at the book.

**Workout A — Monday.** Warm up 5 minutes. Three rounds of: squat — 8/10/12 reps; push-up (wall/knee/full) — 8/10/10 reps; glute bridge — 10/12/12 reps (single-leg for Advanced, 8 each side); dumbbell row — 8/10/12 reps each side; dead bug — 6/8/10 reps each side; plank — 20/30/40 seconds. Rest 60 seconds between exercises, 2 minutes between rounds.

**Workout B — Wednesday.** Three rounds of: reverse lunge — 6/8/10 reps each leg; overhead press — 8/10/12 reps; Romanian deadlift — 8/10/12 reps; bird dog — 6/8/10 reps each side; side plank — 15/20/30 seconds each side; march in place — 1 minute.

**Workout C — Friday.** Brisk walk 25 minutes, then 5 minutes of mobility. Add five minutes to last week's walk.

**Habit targets this week:** Keep last week's habits and add one: a protein source at lunch and dinner. That means eggs, fish, chicken, beans, lentils, tofu, or Greek yoghurt — something protein-based on the plate, not just a side of bread. Water, bedtime, and walking continue. You are now tracking four habits.

**Nutrition guidance this week:** Try the plate method at dinner three nights this week: half the plate vegetables or salad, a quarter protein, a quarter slow carbohydrate such as potatoes, rice, or wholemeal bread, and a thumb-sized portion of olive oil, nuts, or avocado. Pick three dinners from the recipe collection and cook them — Recipes 21, 22, and 23 are good starting points.

**Mindset note:** Motivation is unreliable, and this week is where most people discover that. You will not always feel like training. Train anyway, at the scheduled time, even if you do the shorter version. The feeling of having done it is the reward that builds the habit — not the feeling before you start.

**End-of-week check-in:** Score your four habits. Note any session you moved and why. If you trained three times, you are exactly on track. If you trained twice, you are still on track — repeat Week 2's structure next week rather than jumping ahead.

---

## 7. Week 3 — Strength Basics: Learning the Big Moves

**Weekly focus:** Learn the four big strength patterns properly — squat, hinge, push, and pull — before adding load. Good form now is what keeps you training in Week 10.

This week the sessions get a little longer and the movements get a little more deliberate. You will slow down: three seconds to lower on squats and rows, a pause at the bottom of the glute bridge, and a full breath between repetitions of the Romanian deadlift. Speed hides bad form; slowness reveals it, and that is what you want.

**Workout A — Monday (lower body + core).** Warm up 5 minutes. Three sets of each exercise, resting 60 to 90 seconds between sets:

- Squat: Beginner 3 × 8 (chair squat), Intermediate 3 × 10, Advanced 3 × 12 goblet squat.
- Romanian deadlift: Beginner 3 × 8 (no weight), Intermediate 3 × 10 (light dumbbells), Advanced 3 × 12 (moderate dumbbells).
- Glute bridge: 3 × 10 / 3 × 12 / 3 × 10 single-leg each side.
- Reverse lunge: 3 × 6 / 3 × 8 / 3 × 10 each leg.
- Dead bug: 3 × 6 / 3 × 8 / 3 × 10 each side.
- Cool down 5 minutes.

**Workout B — Wednesday (upper body + core).** Warm up 5 minutes. Three sets of each:

- Push-up (wall/knee/full): 3 × 8 / 3 × 10 / 3 × 10.
- Dumbbell row: 3 × 8 / 3 × 10 / 3 × 12 each side.
- Overhead press: 3 × 8 / 3 × 10 / 3 × 12.
- Bird dog: 3 × 6 / 3 × 8 / 3 × 10 each side.
- Plank: 3 × 20 / 3 × 30 / 3 × 40 seconds.
- Cool down 5 minutes.

**Workout C — Friday (full-body circuit).** Warm up 5 minutes. Two rounds (Beginner), three rounds (Intermediate and Advanced) of: squat 10 reps, push-up 8 reps, row 8 reps each side, glute bridge 10 reps, march in place 1 minute. Rest 90 seconds between rounds. Finish with 5 minutes of stretching.

**Habit targets this week:** Add a fifth habit — a 10-minute screen-free wind-down before bed on at least five nights. That means no phone, no television, no laptop: read, stretch, or simply sit. It sounds small; it is one of the most powerful sleep habits there is. Water, bedtime, walking, and protein continue.

**Nutrition guidance this week:** Cook four dinners at home, and prepare one lunch in advance — a big salad, a soup, or a grain bowl that covers two lunches. Batch cooking one item a week is the single most effective way to eat well on busy days. Choose a lunch recipe from Recipes 11–20.

**Mindset note:** You are learning skills, not just burning calories. The squat, the hinge, the row, and the press are skills you will use for the rest of your life — picking up grandchildren, carrying shopping, getting up off the floor. Treat each repetition as practice, not punishment.

**End-of-week check-in:** Rate your form confidence from 1 to 5 for each of the four big moves. Any move rated below 3 stays at the same weight and reps next week while the others progress. That is not falling behind; that is good coaching.

---

## 8. Week 4 — First Check-In: Measure, Review, Adjust

**Weekly focus:** Pause the progression, measure honestly, and adjust the plan. A check-in week is not a rest week — it is a smart week.

Week 4 keeps the same workouts as Week 3 but does not add weight or reps. Your body consolidates the gains from the first three weeks, and you get clean comparison data. Repeat your starting measurements and photos on the morning of Day 1 of this week, and fill in the Week 4 check-in worksheet in full.

**Workout A — Monday.** Same as Week 3 Workout A, same weights, same reps. Focus entirely on form: film yourself doing one set of squats on your phone if you are comfortable, and watch it back. Are your knees tracking over your toes? Is your chest up? Is your lower back neutral?

**Workout B — Wednesday.** Same as Week 3 Workout B, same weights, same reps. Focus on the lowering phase — count three seconds on every repetition.

**Workout C — Friday.** A 30-minute walk at an easy pace, plus 10 minutes of mobility. Enjoy it. You have earned an easier Friday.

**Habit targets this week:** No new habits. Score all five habits for the month so far. Which habit is easiest? Which is hardest? The hardest habit is usually the one that needs a smaller target, not more effort — if the wind-down is failing, make it five minutes instead of ten.

**Nutrition guidance this week:** Review your last three weeks of eating. What worked? Which recipes did you actually enjoy enough to cook again? Circle your five favourite recipes in the collection and build next month's meal plans around them. Variety is nice; repetition of meals you like is sustainable.

**Mindset note:** Four weeks is enough time for real change and not enough time for dramatic change. You may notice better sleep, more energy, less stiffness, and clothes fitting slightly differently. You may not see much change on the scale, and that is normal and fine. The scale measures one thing; your life measures many.

**End-of-week check-in:** This is a full review — complete the Week 4 worksheet in your workbook, compare your measurements and photos with Day 1, and decide your level for Weeks 5–8. Most people stay at their level; some move up. If you completed at least 10 of 12 sessions in the first month, move up if you want to. If you completed fewer, stay where you are and focus on consistency — that is the right call, not a failure.

---

## 9. Week 5 — Energy: Eating for Steady Fuel

**Weekly focus:** Food as fuel, not as a project. Steady energy comes from regular meals, protein, fibre, and water — not from willpower.

With four weeks of training behind you, your appetite may have changed. You may be hungrier, or you may notice that sugary snacks leave you crashing an hour later. This week you will build a simple, repeatable eating structure: three meals and one planned snack, each built around protein and fibre, eaten at roughly the same times each day.

**Workout A — Monday (lower body + core).** Warm up 5 minutes. Three sets:

- Squat: Beginner 3 × 10, Intermediate 3 × 12, Advanced 4 × 10 goblet squat (add a set rather than weight this week).
- Romanian deadlift: 3 × 10 / 3 × 12 / 4 × 10.
- Glute bridge: 3 × 12 / 3 × 12 / 3 × 12 single-leg each side.
- Reverse lunge: 3 × 8 / 3 × 10 / 3 × 12 each leg.
- Side plank: 3 × 20 / 3 × 30 / 3 × 40 seconds each side.
- Cool down 5 minutes.

**Workout B — Wednesday (upper body + core).** Warm up 5 minutes. Three sets:

- Push-up: 3 × 10 / 3 × 12 / 4 × 10 (Advanced: feet slightly elevated).
- Dumbbell row: 3 × 10 / 3 × 12 / 4 × 10.
- Overhead press: 3 × 10 / 3 × 12 / 4 × 10.
- Bird dog: 3 × 8 / 3 × 10 / 3 × 10 each side.
- Plank: 3 × 30 / 3 × 40 / 3 × 50 seconds.
- Cool down 5 minutes.

**Workout C — Friday (conditioning circuit).** Warm up 5 minutes. Three rounds of: march in place or step-ups 2 minutes, squat 10 reps, push-up 8 reps, row 8 reps each side, glute bridge 10 reps. Rest 90 seconds between rounds. Cool down 5 minutes.

**Habit targets this week:** Add a sixth habit — eat three regular meals, sitting down, without a screen, on at least five days. This is not about what you eat; it is about how you eat. Eating slowly and without distraction helps you notice fullness and enjoy food more. Water, bedtime, walking, protein, and the wind-down continue.

**Nutrition guidance this week:** Build your day around the plate method at every meal, and add one planned snack — a piece of fruit with a handful of nuts, or Greek yoghurt with berries — between lunch and dinner if you get hungry in the afternoon. A planned snack prevents the unplanned raid of the biscuit tin at 4pm. Cook four dinners from the recipe collection, and try two new recipes this week.

**Mindset note:** Hunger is not failure, and neither is enjoying food. A programme that makes you afraid of food is a programme that will end. Your job this week is to notice: which meals keep you full for three or four hours, and which leave you hungry again in one? Keep more of the first kind.

**End-of-week check-in:** Score your six habits. Write down your most reliable breakfast, lunch, and dinner — the three meals you could eat every week without getting bored. Those three meals are the backbone of your eating for the rest of the programme.

---

## 10. Week 6 — Midway Momentum: Adding Challenge

**Weekly focus:** You are halfway through. Add a little challenge — and notice how much stronger you already are.

Week 6 is the first week where the programme asks for a genuine step up: heavier dumbbells or harder variations on the main lifts, and a longer Saturday activity. If you have been using water bottles, this is the week to buy or borrow a pair of dumbbells. If you have dumbbells, go one step heavier on rows and Romanian deadlifts.

**Workout A — Monday (lower body + core).** Warm up 5 minutes. Three sets, heavier than Week 5:

- Goblet squat (or bodyweight squat with a 3-second lowering phase): 3 × 10 / 3 × 12 / 4 × 10.
- Romanian deadlift, heavier dumbbells: 3 × 10 / 3 × 12 / 4 × 10.
- Single-leg glute bridge: 3 × 8 / 3 × 10 / 3 × 12 each side.
- Reverse lunge with dumbbells: 3 × 8 / 3 × 10 / 3 × 12 each leg.
- Dead bug: 3 × 8 / 3 × 10 / 3 × 10 each side.
- Cool down 5 minutes.

**Workout B — Wednesday (upper body + core).** Warm up 5 minutes. Three sets:

- Push-up: 3 × 10 / 3 × 12 / 4 × 12.
- Dumbbell row, heavier: 3 × 10 / 3 × 12 / 4 × 10 each side.
- Overhead press, heavier: 3 × 10 / 3 × 12 / 4 × 10.
- Bird dog with a 3-second hold: 3 × 8 / 3 × 10 / 3 × 10 each side.
- Side plank: 3 × 25 / 3 × 35 / 3 × 45 seconds each side.
- Cool down 5 minutes.

**Workout C — Friday (conditioning circuit).** Warm up 5 minutes. Three rounds (Beginner), four rounds (Intermediate and Advanced) of: step-ups or marching 2 minutes, squat 12 reps, push-up 10 reps, row 10 reps each side, glute bridge 12 reps. Rest 90 seconds between rounds. Cool down 5 minutes.

**Saturday activity:** Extend your Saturday walk or activity to 45 to 60 minutes this week. Go somewhere pleasant — a park, a riverside path, a different neighbourhood. The Saturday session is as much about enjoyment as exercise.

**Habit targets this week:** No new habits. Your job is to hold all six. If one habit has been failing for two weeks, shrink it: a 10-minute walk instead of 20, a glass of water with two meals instead of three. A smaller habit done daily beats a bigger habit done never.

**Nutrition guidance this week:** Try one new breakfast and one new dinner from the recipe collection. Keep the rest of the week on your reliable meals. Experimenting with one new recipe a week keeps eating interesting without turning every meal into a project.

**Mindset note:** Halfway is a good time to notice what has changed that has nothing to do with appearance: stairs feel easier, you sleep more deeply, your back aches less after a long day, you have more patience in the evening. Write three of these changes in your check-in. They are the real results.

**End-of-week check-in:** Score your habits and write your three non-appearance changes. Rate your energy from 1 to 10 compared with Week 1. Most people report a clear improvement by now — if you do not, check your sleep first. Sleep is usually the missing piece.

---

## 11. Week 7 — Consistency Under Pressure: Busy-Week Plans

**Weekly focus:** Learn to train when life is difficult, because life will be difficult again — and the programme must survive it.

This is the most important week in the programme, and it is deliberately designed around a bad week. You will practise the short versions of every session, so that when a genuinely hard week arrives later, you already know what to do instead of quitting.

**The short session (20 minutes).** Warm up 3 minutes. Two rounds of: squat 10 reps, push-up 8 reps, row 8 reps each side, glute bridge 10 reps, plank 30 seconds. Cool down 2 minutes. That is a complete session. It maintains your strength and your habit, and it takes less time than an episode of television.

**The minimum week.** If you can only train once, do the short session once and walk 20 minutes on two other days. If you can train twice, do the short session twice and walk once. If you cannot train at all, walk 15 minutes a day and do the 5-minute mobility routine. A minimum week is not a failed week. It is a week you survived.

**Workout A — Monday (lower body + core, full version if you can).** Warm up 5 minutes. Three sets: squat 3 × 10 / 3 × 12 / 4 × 10; Romanian deadlift 3 × 10 / 3 × 12 / 4 × 10; glute bridge 3 × 12 / 3 × 12 / 3 × 12 single-leg; reverse lunge 3 × 8 / 3 × 10 / 3 × 12 each leg; dead bug 3 × 8 / 3 × 10 / 3 × 10 each side. Cool down 5 minutes.

**Workout B — Wednesday (upper body + core).** Warm up 5 minutes. Three sets: push-up 3 × 10 / 3 × 12 / 4 × 10; dumbbell row 3 × 10 / 3 × 12 / 4 × 10 each side; overhead press 3 × 10 / 3 × 12 / 4 × 10; bird dog 3 × 8 / 3 × 10 / 3 × 10 each side; plank 3 × 30 / 3 × 40 / 3 × 50 seconds. Cool down 5 minutes.

**Workout C — Friday.** Practise the short session (20 minutes) even if you have time for the full one. Learn what it feels like. Then walk 20 minutes.

**Habit targets this week:** Keep all six habits, but allow yourself a "busy-day" version of each: a 10-minute walk instead of 20, water with two meals instead of three, a 5-minute wind-down instead of 10. Tick the habit if you did the busy-day version. The tracker has a column for this — use it.

**Nutrition guidance this week:** Plan for the busy week in advance. Cook a double batch of one dinner and freeze half. Keep two quick meals in the house — tinned beans on toast with an egg, or a soup and bread — for nights when cooking properly is not going to happen. A planned quick meal beats a takeaway you did not want.

**Mindset note:** The goal of this week is not fitness. It is proof. Proof that you can keep going when things are hard, that a short session counts, and that missing a session is not the end. People who finish 12-week programmes are not the people who never miss a session. They are the people who miss a session and come back the next day.

**End-of-week check-in:** Write down your personal minimum week — the version of this programme you can do in your worst week. Keep it somewhere visible. It is your insurance policy for the next twelve weeks and beyond.

---

## 12. Week 8 — Strength Progression: Heavier, Steadier, Stronger

**Weekly focus:** The second progression. You are stronger than you were in Week 3 — train like it, with the same careful form.

Week 8 returns to full sessions with a step up in load or difficulty on the main lifts. This is the last big progression before the final phase, so make it count — but remember the rule: if your form breaks down, stay where you are for another week. There is no deadline on strength.

**Workout A — Monday (lower body + core).** Warm up 5 minutes. Four sets for Intermediate and Advanced, three for Beginner:

- Goblet squat: Beginner 3 × 10, Intermediate 4 × 10, Advanced 4 × 12.
- Romanian deadlift: 3 × 10 / 4 × 10 / 4 × 12.
- Single-leg glute bridge: 3 × 10 / 3 × 12 / 4 × 10 each side.
- Reverse lunge with dumbbells: 3 × 10 / 4 × 10 / 4 × 10 each leg.
- Dead bug: 3 × 8 / 3 × 10 / 3 × 12 each side.
- Cool down 5 minutes.

**Workout B — Wednesday (upper body + core).** Warm up 5 minutes. Four sets for Intermediate and Advanced, three for Beginner:

- Push-up: 3 × 12 / 4 × 10 / 4 × 12.
- Dumbbell row: 3 × 12 / 4 × 10 / 4 × 12 each side.
- Overhead press: 3 × 10 / 4 × 10 / 4 × 10.
- Bird dog with hold: 3 × 8 / 3 × 10 / 3 × 12 each side.
- Side plank: 3 × 30 / 3 × 40 / 3 × 50 seconds each side.
- Cool down 5 minutes.

**Workout C — Friday (conditioning circuit).** Warm up 5 minutes. Four rounds of: step-ups or marching 2 minutes, squat 12 reps, push-up 10 reps, row 10 reps each side, glute bridge 12 reps, plank 30 seconds. Rest 90 seconds between rounds. Cool down 5 minutes. Beginner: three rounds.

**Habit targets this week:** Add a seventh and final habit — one strength of character habit, not a fitness one: each evening, write down one thing that went well today. It takes one minute, it is not a gratitude journal in the formal sense, and it trains your attention toward what is working. This is the habit that keeps people going after the programme ends, because it makes progress visible.

**Nutrition guidance this week:** Cook five dinners at home this week, including one recipe you have not tried yet. By now you should have a set of eight to ten recipes you like and can cook without thinking. That is a complete repertoire. You do not need more.

**Mindset note:** Strength is a slow skill. The weight you lift today was impossible eight weeks ago, and the weight you will lift in four weeks is impossible today. That is the whole game, and you are playing it well. Trust the process and the measurements — not the mirror on a bad day.

**End-of-week check-in:** Score all seven habits. Note which exercises have progressed most since Week 3. If a lift has not progressed, that is useful information: it usually means the weight is too heavy, the form needs work, or you need more rest between sessions. Adjust one thing, not everything.

---

## 13. Week 9 — Second Check-In: What Has Actually Changed

**Weekly focus:** Measure again, compare honestly, and decide what the final three weeks are for.

Week 9 is the second check-in week, exactly like Week 4. Repeat your measurements and photos on the morning of Day 1, keep the workouts at Week 8's level without adding load, and fill in the full Week 9 worksheet. This is the week where most people see the clearest evidence of change — compare your photos side by side, not from memory.

**Workout A — Monday.** Same as Week 8 Workout A, same weights, same reps. Focus on form and on the lowering phase.

**Workout B — Wednesday.** Same as Week 8 Workout B, same weights, same reps. Notice which exercises feel easier than they did in Week 4. Write those down.

**Workout C — Friday.** A 30 to 40-minute walk at an easy pace, plus 10 minutes of mobility. Take the walk somewhere you enjoy.

**Habit targets this week:** No new habits. Score all seven. Look at the pattern across nine weeks: which habits are automatic now, which still need effort, and which have quietly become part of your day without you noticing? The automatic ones are the programme's real product.

**Nutrition guidance this week:** Review your recipe favourites again. You should now have a clear picture of your eating pattern: your reliable breakfast, your two or three lunches, your eight to ten dinners, and your planned snack. Write them on one page — that page is your personal eating plan, and it is worth more than any printed meal plan because it is built from your actual preferences.

**Mindset note:** Nine weeks is a long time to keep a promise to yourself, and you have done it. Whatever the measurements say, that is an achievement. If the numbers have not moved as much as you hoped, remember that strength, sleep, energy, and consistency are results too — and that the final three weeks are still ahead of you.

**End-of-week check-in:** Complete the Week 9 worksheet in full, compare measurements and photos with Day 1 and Week 4, and set one specific goal for the final three weeks. Not "do better" — something concrete, such as "complete all nine remaining sessions" or "cook at home five nights a week" or "walk every day for the final three weeks."

---

## 14. Week 10 — The Home Stretch: Raising the Bar Gently

**Weekly focus:** The final push is gentle, not frantic. Small increases, full recovery, and no heroics.

With three weeks left, the temptation is to do more — extra sessions, harder workouts, stricter eating. Resist it. The programme works because it is sustainable, and the final phase protects that. You will add a small amount of volume and one new challenge: a longer Saturday activity and a slightly harder Friday circuit. That is enough.

**Workout A — Monday (lower body + core).** Warm up 5 minutes. Four sets:

- Goblet squat: Beginner 3 × 12, Intermediate 4 × 12, Advanced 4 × 12 with a 3-second lowering phase.
- Romanian deadlift: 3 × 12 / 4 × 12 / 4 × 12.
- Single-leg glute bridge: 3 × 12 / 4 × 10 / 4 × 12 each side.
- Reverse lunge with dumbbells: 3 × 10 / 4 × 12 / 4 × 12 each leg.
- Side plank: 3 × 30 / 3 × 45 / 3 × 60 seconds each side.
- Cool down 5 minutes.

**Workout B — Wednesday (upper body + core).** Warm up 5 minutes. Four sets:

- Push-up: 3 × 12 / 4 × 12 / 4 × 12 (Advanced: slow 3-second lowering phase).
- Dumbbell row: 3 × 12 / 4 × 12 / 4 × 12 each side.
- Overhead press: 3 × 12 / 4 × 10 / 4 × 12.
- Bird dog with hold: 3 × 10 / 3 × 12 / 3 × 12 each side.
- Plank: 3 × 40 / 3 × 50 / 3 × 60 seconds.
- Cool down 5 minutes.

**Workout C — Friday (conditioning circuit).** Warm up 5 minutes. Four rounds of: step-ups or marching 2 minutes, squat 12 reps, push-up 12 reps, row 12 reps each side, glute bridge 12 reps, plank 40 seconds. Rest 60 to 90 seconds between rounds. Cool down 5 minutes.

**Saturday activity:** 60 minutes, easy pace — a long walk, a bike ride, a swim, or a hike. Bring someone with you if you can. This is the longest Saturday session of the programme, and it should feel like a pleasure, not a workout.

**Habit targets this week:** Hold all seven habits. If your energy is high, add five minutes to your daily walk. If it is low, hold steady. The final three weeks are about finishing strong, not about adding new demands.

**Nutrition guidance this week:** Keep your reliable meals, and cook one celebratory dinner from the recipe collection — something you have been saving, or a new recipe that looks enjoyable. Food is part of life, not just fuel, and a good meal is a reasonable way to mark ten weeks of consistency.

**Mindset note:** You are in the home stretch, and the most common mistake now is impatience. Three weeks is enough time to consolidate everything you have built. Do not try to compress twelve weeks of progress into three. Finish the programme as written, and the result will take care of itself.

**End-of-week check-in:** Score your habits and write one sentence about what you are most proud of so far. Keep it. You will read it again in Week 12.

---

## 15. Week 11 — Real-Life Proof: Training Around Life, Not Instead of It

**Weekly focus:** Prove that the programme fits your real life — by living your real life and keeping the programme inside it.

Week 11 is deliberately ordinary. No new exercises, no new habits, no new recipes. You will do the same sessions as Week 10, eat the same reliable meals, and keep the same habits — while living a normal week with work, family, social plans, and whatever else fills your calendar. This is the test that matters: can the reset survive a normal week? After eleven weeks of practice, the answer should be yes.

**Workout A — Monday (lower body + core).** Same as Week 10 Workout A. If you need to move it to Tuesday, move it. The week still counts.

**Workout B — Wednesday (upper body + core).** Same as Week 10 Workout B. If you need to shorten it, use the 20-minute short session from Week 7. The week still counts.

**Workout C — Friday (conditioning circuit).** Same as Week 10 Workout C, or the short session. Walk on Saturday for 30 to 60 minutes.

**Habit targets this week:** Hold all seven. This is the week to notice which habits have become automatic — the ones you do without thinking, without the tracker, without effort. Those habits are yours now. They do not need the programme any more.

**Nutrition guidance this week:** Eat your reliable meals, cook at home at least four nights, and allow yourself one meal out or one takeaway without guilt and without calling it a failure. A sustainable eating pattern includes meals out. The skill is not avoiding them; it is enjoying them and returning to your normal pattern the next day.

**Mindset note:** The programme was never meant to be your whole life. It was meant to fit inside your life and make it better. If you can train three times, walk most days, sleep reasonably, and cook most dinners during a normal busy week, you have built something that will last. That is the whole point of the reset.

**End-of-week check-in:** Score your habits. Write down the three habits that feel automatic now, and the one habit that still needs attention. The automatic ones go into your maintenance plan. The one that needs attention gets a smaller, easier target for the final week.

---

## 16. Week 12 — Finish Strong: Your Reset Review and What Comes Next

**Weekly focus:** Finish the programme properly — measure, review, celebrate, and decide what stays.

This is the final week. Train as normal, eat as normal, and keep your habits. On the morning of Day 1, take your final measurements and photos. On Sunday, complete the Reset Review worksheet in your workbook — it is the most important page in the whole programme.

**Workout A — Monday (lower body + core).** Warm up 5 minutes. Four sets: goblet squat 3 × 12 / 4 × 12 / 4 × 12; Romanian deadlift 3 × 12 / 4 × 12 / 4 × 12; single-leg glute bridge 3 × 12 / 4 × 12 / 4 × 12 each side; reverse lunge 3 × 12 / 4 × 12 / 4 × 12 each leg; dead bug 3 × 10 / 3 × 12 / 3 × 12 each side. Cool down 5 minutes.

**Workout B — Wednesday (upper body + core).** Warm up 5 minutes. Four sets: push-up 3 × 12 / 4 × 12 / 4 × 12; dumbbell row 3 × 12 / 4 × 12 / 4 × 12 each side; overhead press 3 × 12 / 4 × 12 / 4 × 12; bird dog 3 × 10 / 3 × 12 / 3 × 12 each side; plank 3 × 45 / 3 × 60 / 3 × 60 seconds. Cool down 5 minutes.

**Workout C — Friday (your choice).** Do your favourite session from the last twelve weeks — the one you enjoyed most, or the one that made you feel strongest. Then take a 30-minute walk. This session is a celebration, not a test.

**Habit targets this week:** Hold all seven habits for the final week. Tick them in the tracker, and notice how full the tracker looks compared with Week 1.

**Nutrition guidance this week:** Cook your favourite dinner from the recipe collection on Friday evening. You have cooked dozens of meals over twelve weeks; this one is a small celebration of that.

**Mindset note:** Read the sentence you wrote in Week 10 about what you are most proud of. Then write a new one for Week 12. Compare them. You have twelve weeks of evidence now — sessions completed, habits ticked, meals cooked, walks taken. That evidence is yours, and nobody can take it away from you.

**End-of-week check-in — the Reset Review:** Complete the Reset Review worksheet in your workbook. Compare your Day 1, Week 4, Week 9, and Week 12 measurements and photos. Count your completed sessions out of 36. Count your habit scores. Write down what you will keep, what you will change, and what you will stop. Then read the Maintenance Plan in the next chapter and choose your next step before the motivation of finishing fades.

---

## 17. After the Reset: The Maintenance Plan

Finishing a 12-week programme is an achievement. Keeping the results is a different skill, and it is simpler than you think. Maintenance is not a new programme; it is the same habits, at a slightly lower intensity, for as long as you want the benefits.

**The maintenance week.** Two strength sessions a week instead of three — pick your two favourite sessions from the programme and repeat them. Walk 20 to 30 minutes on most days. Keep your Saturday activity. Keep the five habits that became automatic, and let the others go if they never took hold — you can always add one back later. Cook at home most nights using your reliable meals and favourite recipes. That is the whole maintenance plan. It takes about two hours a week.

**When to do another round.** If you enjoyed the structure, you can repeat the 12-week programme from Week 5, starting at your current level and with slightly heavier weights. Many people repeat the programme twice a year — once in spring, once in autumn — and maintain in between. There is no rule about how often; there is only the question of what fits your life.

**When to change something.** If you get bored, change the Saturday activity, try new recipes, or swap one exercise for another from the movement library. If you plateau — the same weights for four weeks with no progress — add one set, add a little weight, or add a fourth session for two weeks, then return to three. If you get injured or ill, rest, recover, and restart at an easier week. The programme will still be here.

**What to keep forever.** The daily walk. A protein source at each meal. A regular bedtime. Three home-cooked dinners a week. Two strength sessions a week. Those five things, done most weeks for the rest of your life, will do more for your health and energy than any programme ever will. The reset was never the destination; it was the on-ramp.

---

## 18. The Recipe Collection: 40 Simple Meals

All recipes serve two people unless stated otherwise, use everyday ingredients, and take 30 minutes or less unless noted. Adjust quantities for your household. These are general nutrition education, not a prescribed diet — adapt them to your tastes, allergies, and any dietary guidance from your clinician.

### Breakfasts (Recipes 1–10)

**Recipe 1 — Simple Scrambled Eggs on Wholemeal Toast.** Ingredients: 4 eggs, a knob of butter or a teaspoon of olive oil, 2 slices of wholemeal bread, a handful of spinach, salt and pepper. Method: Beat the eggs with a pinch of salt. Melt the butter in a pan over medium heat, add the eggs, and stir gently until just set. Wilt the spinach in the same pan for 30 seconds. Serve the eggs on toast with the spinach on the side.

**Recipe 2 — Greek Yoghurt Berry Bowl.** Ingredients: 300 g Greek yoghurt, a handful of mixed berries, 2 tablespoons of oats, 1 tablespoon of mixed seeds, a drizzle of honey (optional). Method: Spoon the yoghurt into a bowl, top with berries, oats, and seeds, and drizzle with honey if using. No cooking required.

**Recipe 3 — Porridge with Banana and Peanut Butter.** Ingredients: 80 g oats, 300 ml milk or water, 1 banana, 1 tablespoon of peanut butter, a pinch of cinnamon. Method: Cook the oats in the milk or water over medium heat for 4 to 5 minutes, stirring, until thick and creamy. Top with sliced banana, peanut butter, and cinnamon.

**Recipe 4 — Avocado and Egg on Toast.** Ingredients: 2 slices of wholemeal bread, 1 ripe avocado, 2 eggs, lemon juice, chilli flakes, salt and pepper. Method: Toast the bread. Mash the avocado with lemon juice and salt and spread it on the toast. Fry or poach the eggs and place them on top. Sprinkle with chilli flakes.

**Recipe 5 — Veggie Omelette.** Ingredients: 3 eggs, a handful of chopped mushrooms, half a chopped pepper, a handful of spinach, a small handful of grated cheese, a teaspoon of olive oil. Method: Beat the eggs. Cook the vegetables in the oil for 2 to 3 minutes, pour in the eggs, and cook until almost set. Sprinkle with cheese, fold in half, and serve.

**Recipe 6 — Overnight Oats with Apple and Cinnamon.** Ingredients: 80 g oats, 150 ml milk, 100 g yoghurt, 1 grated apple, 1 teaspoon of cinnamon, 1 tablespoon of raisins. Method: Mix everything in a jar or bowl the night before, cover, and refrigerate. Eat cold in the morning, topped with extra apple if you like.

**Recipe 7 — Smoked Salmon and Cream Cheese Bagel.** Ingredients: 1 wholemeal bagel, 2 tablespoons of cream cheese, 60 g smoked salmon, a squeeze of lemon, a few capers or sliced cucumber. Method: Toast the bagel, spread with cream cheese, top with salmon, lemon, and capers or cucumber.

**Recipe 8 — Banana Oat Pancakes.** Ingredients: 2 ripe bananas, 2 eggs, 60 g oats, a pinch of cinnamon, a little butter or oil for the pan, berries to serve. Method: Blend the bananas, eggs, oats, and cinnamon until smooth. Cook small pancakes in a lightly oiled pan for 2 minutes each side. Serve with berries.

**Recipe 9 — Beans on Toast with a Fried Egg.** Ingredients: 1 tin of baked beans (reduced sugar if available), 2 slices of wholemeal bread, 1 egg, a teaspoon of olive oil. Method: Heat the beans. Toast the bread. Fry the egg in the oil. Spoon the beans over the toast and top with the egg.

**Recipe 10 — Cottage Cheese and Fruit Bowl.** Ingredients: 200 g cottage cheese, 1 sliced peach or a handful of berries, 1 tablespoon of chopped nuts, a drizzle of honey. Method: Spoon the cottage cheese into a bowl and top with fruit, nuts, and honey. A quick, protein-rich breakfast with no cooking.

### Lunches (Recipes 11–20)

**Recipe 11 — Chicken and Avocado Wrap.** Ingredients: 1 cooked chicken breast, sliced, 1 wholemeal wrap, half an avocado, a handful of salad leaves, 1 tablespoon of yoghurt or hummus. Method: Spread the wrap with yoghurt or hummus, add the chicken, avocado, and salad, roll up tightly, and cut in half.

**Recipe 12 — Lentil and Tomato Soup.** Ingredients: 1 onion, 2 garlic cloves, 200 g red lentils, 1 tin of chopped tomatoes, 600 ml vegetable stock, 1 teaspoon of cumin, a drizzle of olive oil. Method: Cook the onion and garlic in the oil for 3 minutes, add the lentils, tomatoes, stock, and cumin, and simmer for 20 minutes. Blend until smooth and serve with bread.

**Recipe 13 — Tuna and White Bean Salad.** Ingredients: 1 tin of tuna, 1 tin of cannellini beans (drained), half a red onion (finely sliced), a handful of cherry tomatoes (halved), lemon juice, olive oil, parsley. Method: Combine everything in a bowl, dress with lemon juice and olive oil, and season. Serve with crusty bread.

**Recipe 14 — Egg Fried Rice.** Ingredients: 2 portions of cooked rice (leftover is ideal), 2 eggs, a handful of frozen peas, 2 spring onions, 1 tablespoon of soy sauce, a teaspoon of sesame oil. Method: Scramble the eggs in a hot pan, set aside, then stir-fry the rice, peas, and spring onions for 3 minutes. Stir in the eggs and soy sauce and serve.

**Recipe 15 — Chickpea and Feta Salad.** Ingredients: 1 tin of chickpeas (drained), 100 g feta, half a cucumber (diced), a handful of cherry tomatoes, half a red onion, lemon juice, olive oil, oregano. Method: Combine everything in a bowl, dress with lemon and oil, and season. Keeps well for two days in the fridge.

**Recipe 16 — Turkey and Hummus Pitta.** Ingredients: 2 wholemeal pittas, 4 tablespoons of hummus, 4 slices of cooked turkey or chicken, a handful of salad leaves, half a cucumber (sliced). Method: Warm the pittas, split them open, spread with hummus, and fill with turkey, salad, and cucumber.

**Recipe 17 — Sweet Potato and Black Bean Bowl.** Ingredients: 1 large sweet potato (cubed), 1 tin of black beans (drained), 1 teaspoon of smoked paprika, a handful of sweetcorn, a dollop of yoghurt, lime juice. Method: Roast the sweet potato with paprika at 200°C for 20 minutes. Warm the beans, combine everything in a bowl, and top with yoghurt and lime.

**Recipe 18 — Tomato and Mozzarella Toast.** Ingredients: 2 thick slices of wholemeal bread, 2 tomatoes (sliced), 1 ball of mozzarella (sliced), basil leaves, olive oil, balsamic vinegar. Method: Toast the bread, layer with tomato and mozzarella, drizzle with oil and balsamic, and top with basil. Grill briefly if you like the cheese melted.

**Recipe 19 — Chicken Noodle Soup.** Ingredients: 1 cooked chicken breast (shredded), 1 litre of chicken stock, 100 g noodles, 2 carrots (sliced), 2 spring onions, a thumb of ginger (grated). Method: Simmer the stock with ginger and carrots for 10 minutes, add the noodles and cook for 5 minutes, then stir in the chicken and spring onions. Serve hot.

**Recipe 20 — Roasted Vegetable and Quinoa Salad.** Ingredients: 150 g quinoa, 1 courgette, 1 pepper, 1 red onion (all chopped), olive oil, lemon juice, a handful of feta, parsley. Method: Roast the vegetables at 200°C for 20 minutes. Cook the quinoa, combine everything, dress with lemon and oil, and top with feta.

### Dinners (Recipes 21–30)

**Recipe 21 — One-Pan Lemon Chicken and Vegetables.** Ingredients: 2 chicken breasts, 2 potatoes (cubed), 2 carrots (sliced), 1 courgette (sliced), lemon juice and zest, 2 garlic cloves, olive oil, thyme. Method: Toss the vegetables in oil and spread on a tray. Place the chicken on top, season, and scatter with garlic, lemon zest, and thyme. Roast at 200°C for 25 to 30 minutes until the chicken is cooked through. Squeeze lemon over before serving.

**Recipe 22 — Beef and Vegetable Stir-Fry.** Ingredients: 300 g beef strips, 1 pepper, 1 onion, a handful of broccoli florets, 2 tablespoons of soy sauce, 1 teaspoon of honey, a thumb of ginger, 1 tablespoon of oil, rice or noodles to serve. Method: Stir-fry the beef in the oil for 3 minutes and set aside. Stir-fry the vegetables for 4 minutes, return the beef, add soy, honey, and ginger, and cook for 2 minutes. Serve with rice or noodles.

**Recipe 23 — Tomato and Bean Chilli.** Ingredients: 1 onion, 2 garlic cloves, 1 tin of kidney beans, 1 tin of chopped tomatoes, 1 tablespoon of tomato purée, 1 teaspoon of chilli powder, 1 teaspoon of cumin, rice to serve. Method: Cook the onion and garlic for 3 minutes, add the spices, tomatoes, purée, and beans, and simmer for 20 minutes. Serve with rice and a dollop of yoghurt.

**Recipe 24 — Baked Salmon with Roasted Vegetables.** Ingredients: 2 salmon fillets, 1 courgette, 1 pepper, a handful of cherry tomatoes, lemon, olive oil, dill or parsley. Method: Toss the vegetables in oil on a tray and roast at 200°C for 15 minutes. Add the salmon, season, and roast for a further 12 minutes. Serve with lemon and herbs.

**Recipe 25 — Turkey Meatballs in Tomato Sauce.** Ingredients: 400 g turkey mince, 1 egg, 2 tablespoons of breadcrumbs, 1 jar of passata, 2 garlic cloves, 1 teaspoon of oregano, olive oil, spaghetti or crusty bread to serve. Method: Mix the mince, egg, breadcrumbs, and half the garlic, shape into balls, and brown in oil for 5 minutes. Add the passata, oregano, and remaining garlic, simmer for 15 minutes, and serve with spaghetti.

**Recipe 26 — Vegetable Curry with Rice.** Ingredients: 1 onion, 2 garlic cloves, 1 tablespoon of curry paste, 1 tin of coconut milk, 1 tin of chickpeas, 1 sweet potato (cubed), a handful of spinach, rice to serve. Method: Cook the onion and garlic, stir in the curry paste, add coconut milk, chickpeas, and sweet potato, and simmer for 20 minutes. Stir in the spinach until wilted and serve with rice.

**Recipe 27 — Pork Chops with Apple and Mash.** Ingredients: 2 pork chops, 1 apple (sliced), 4 potatoes, a knob of butter, a splash of milk, a teaspoon of wholegrain mustard, olive oil. Method: Boil and mash the potatoes with butter and milk. Fry the pork chops in oil for 4 to 5 minutes each side, add the apple slices for the last 2 minutes, and serve with the mash and mustard.

**Recipe 28 — Spaghetti Bolognese.** Ingredients: 400 g beef or turkey mince, 1 onion, 2 garlic cloves, 1 carrot (grated), 1 tin of chopped tomatoes, 1 tablespoon of tomato purée, 1 teaspoon of oregano, spaghetti, grated Parmesan. Method: Brown the mince, add the onion, garlic, and carrot, cook for 5 minutes, then add the tomatoes, purée, and oregano and simmer for 20 minutes. Serve over spaghetti with Parmesan.

**Recipe 29 — Sheet-Pan Sausage and Vegetables.** Ingredients: 4 good-quality sausages, 2 potatoes (cubed), 1 pepper, 1 red onion, a handful of cherry tomatoes, olive oil, rosemary. Method: Toss everything in oil on a tray, scatter with rosemary, and roast at 200°C for 25 to 30 minutes, turning once. Serve as it is, with bread or mustard.

**Recipe 30 — Lentil Shepherd's Pie.** Ingredients: 200 g green lentils, 1 onion, 2 carrots (diced), 1 tin of chopped tomatoes, 1 tablespoon of tomato purée, 4 potatoes, a knob of butter, a splash of milk. Method: Cook the lentils, onion, and carrots in the tomatoes and purée for 20 minutes. Boil and mash the potatoes. Spoon the lentil mix into a dish, top with mash, and bake at 200°C for 20 minutes until golden.

### Snacks and Sides (Recipes 31–40)

**Recipe 31 — Hummus and Crudités.** Ingredients: 1 tub of hummus, 2 carrots (cut into sticks), 1 cucumber (cut into sticks), 1 pepper (cut into strips). Method: Spoon the hummus into a bowl and arrange the vegetables around it. A simple, filling snack that takes two minutes.

**Recipe 32 — Apple Slices with Peanut Butter.** Ingredients: 1 apple, 2 tablespoons of peanut butter, a sprinkle of cinnamon. Method: Slice the apple and spread or dip with peanut butter. Sprinkle with cinnamon.

**Recipe 33 — Greek Yoghurt with Berries and Nuts.** Ingredients: 150 g Greek yoghurt, a handful of berries, 1 tablespoon of chopped nuts. Method: Combine in a bowl. A protein-rich snack or light dessert.

**Recipe 34 — Roasted Chickpeas.** Ingredients: 1 tin of chickpeas (drained and dried), 1 tablespoon of olive oil, 1 teaspoon of smoked paprika, half a teaspoon of garlic powder, salt. Method: Toss the chickpeas in oil and spices, spread on a tray, and roast at 200°C for 20 minutes until crisp, shaking halfway. Cool before eating.

**Recipe 35 — Cheese and Wholegrain Crackers.** Ingredients: 40 g hard cheese, 4 wholegrain crackers, a few grapes or apple slices. Method: Serve together as a balanced snack — protein, slow carbohydrate, and fruit.

**Recipe 36 — Garlic Green Beans.** Ingredients: 200 g green beans, 2 garlic cloves (sliced), 1 teaspoon of olive oil, lemon juice. Method: Cook the beans in the oil with the garlic for 4 to 5 minutes until tender and bright green. Squeeze lemon over and serve as a side.

**Recipe 37 — Simple Side Salad.** Ingredients: Mixed leaves, half a cucumber, a handful of cherry tomatoes, half a red onion, olive oil, lemon juice. Method: Combine the vegetables, dress with oil and lemon, and season. Serve alongside any dinner.

**Recipe 38 — Roasted Sweet Potato Wedges.** Ingredients: 2 sweet potatoes (cut into wedges), 1 tablespoon of olive oil, 1 teaspoon of paprika, salt. Method: Toss the wedges in oil and paprika, spread on a tray, and roast at 200°C for 25 minutes until crisp at the edges. Serve as a side or snack.

**Recipe 39 — Banana and Oat Energy Bites.** Ingredients: 2 ripe bananas, 100 g oats, 2 tablespoons of peanut butter, 1 tablespoon of honey, a handful of raisins. Method: Mash the bananas, mix in everything else, roll into balls, and refrigerate for 30 minutes. Keeps for three days in the fridge.

**Recipe 40 — Herbed Roast Potatoes.** Ingredients: 4 potatoes (cubed), 1 tablespoon of olive oil, 1 teaspoon of rosemary, 2 garlic cloves (crushed), salt and pepper. Method: Toss the potatoes in oil, rosemary, and garlic, spread on a tray, and roast at 200°C for 30 minutes until golden and crisp.

---

## Appendix A: Exercise Glossary and Modifications

Every exercise in this programme, with its easiest and hardest versions:

- **Squat:** Easiest — sit-to-stand from a chair. Standard — bodyweight squat. Hardest — goblet squat with a heavy dumbbell.
- **Glute bridge:** Easiest — short range, both feet down. Standard — full bridge. Hardest — single-leg bridge.
- **Push-up:** Easiest — wall push-up. Then — table or bench push-up, knee push-up, full push-up. Hardest — feet elevated, slow lowering.
- **Dumbbell row:** Easiest — water bottle, one hand supported. Standard — light dumbbell. Hardest — heavy dumbbell, slow lowering.
- **Overhead press:** Easiest — seated, one arm at a time, light weight. Standard — standing, two dumbbells. Hardest — heavier dumbbells.
- **Romanian deadlift:** Easiest — no weight, hands on thighs. Standard — light dumbbells. Hardest — heavy dumbbells.
- **Reverse lunge:** Easiest — holding a chair, short step. Standard — bodyweight. Hardest — dumbbells in hand.
- **Plank:** Easiest — knees down. Standard — full plank. Hardest — longer holds, one foot lifted.
- **Side plank:** Easiest — knees bent. Standard — full side plank. Hardest — top leg lifted.
- **Dead bug and bird dog:** Easiest — shorter range, no hold. Standard — full range. Hardest — 3-second holds at full extension.

If an exercise hurts a joint, swap it for the easiest version or drop it and use another exercise that works the same muscles. There is always a version that works.

## Appendix B: The 5-Minute Warm-Up and Cool-Down

**Warm-up (before every session):** March in place for 1 minute, arm circles for 30 seconds, gentle bodyweight squats for 30 seconds, hip circles for 30 seconds, shoulder rolls for 30 seconds, and 1 minute of easy walking around the room. You should feel warm and slightly out of breath, not tired.

**Cool-down (after every session):** Walk slowly for 1 minute, then hold each of these stretches for 20 to 30 seconds: standing quad stretch (each leg), hamstring stretch (each leg), chest opener against a wall, cat-cow on hands and knees, and a slow seated forward fold. Breathe slowly and never bounce.

## Appendix C: Troubleshooting — Common Stalls and Fixes

**"I missed a whole week."** Restart at the week you missed, not at Week 1. If you missed two weeks, restart at the previous check-in week (Week 4 or Week 9) and rebuild from there.

**"My weight has not changed."** Check your sleep, your walking, and your measurements and photos. Weight is the slowest and noisiest measure. If your clothes fit better and you are stronger, the programme is working.

**"I am bored."** Change the Saturday activity, try new recipes, or swap one exercise for a harder variation. Boredom is a signal to vary the programme, not to quit it.

**"I am too sore to train."** Take an extra rest day, walk instead, and check your form — soreness that lasts more than three days usually means the session was too hard or too new. Drop back one level for a week.

**"I cannot do a push-up."** Almost nobody can at first. Start at the wall, progress to a table, then to your knees, then to the floor. That progression is the programme working exactly as designed.

**"My knees hurt when I squat."** Shorten the range, sit to a chair, and keep your knees tracking over your toes. If pain persists, stop squatting and see a clinician — do not push through joint pain.

**"I keep forgetting the habits."** Put the habit tracker where you will see it — on the fridge, or next to your bed. Tie each habit to something you already do: water with meals, wind-down after brushing your teeth, walk after lunch. Habits stick when they are attached to something that already happens.

---

*The 12-Week Reset: Fitness, Habits & Lifestyle Transformation — BEA-10. Original educational content. No medical advice. Consult a qualified clinician before starting any exercise or nutrition programme.*
