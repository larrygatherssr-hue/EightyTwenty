# The 12-Week Reset — Companion Workbook

**Use this workbook alongside the programme book. Print it, or copy the pages into a notebook. Fill it in by hand — writing by hand makes the habit real.**

---

## Important Disclaimer

This workbook is **fitness and lifestyle education only**. It is not medical advice, and it does not diagnose, treat, cure, or prevent any disease or health condition. Consult a qualified clinician before starting any exercise or nutrition programme, especially if you have an existing health condition. Stop exercising and seek medical advice if you feel chest pain, dizziness, severe shortness of breath, or sharp joint pain. No result is guaranteed.

---

## How to Use This Workbook

- **Before Day 1:** Complete the Starting Point pages (goals, measurements, photos).
- **Every Sunday:** Complete the weekly check-in worksheet for that week (15 minutes).
- **Every day:** Tick your habits in the habit tracker (1 minute).
- **Weeks 4, 9, and 12:** Repeat your measurements and photos, and complete the full check-in.
- **Week 12:** Complete the Reset Review on the final page.

---

## Part 1: Your Starting Point

### My three goals

Write one goal for each pillar. Make each goal specific and forgiving.

**Movement goal:** _______________________________________________________________

**Habit goal:** __________________________________________________________________

**Eating goal:** __________________________________________________________________

### My starting measurements (Day 1)

Fill these in on the morning of Day 1, before eating. Weight is optional.

| Measure | Day 1 | Week 4 | Week 9 | Week 12 |
|---|---|---|---|---|
| Weight (optional) | | | | |
| Waist (at navel) | | | | |
| Hips | | | | |
| Resting heart rate | | | | |
| How my clothes fit (1–5) | | | | |
| Energy (1–10) | | | | |
| Sleep quality (1–5) | | | | |

### Progress photo log

Take two photos — front and side — in fitted clothing, in the same spot with the same lighting. These are private, for your eyes only.

| Date | Week | Front photo taken? | Side photo taken? | Notes |
|---|---|---|---|---|
| | Day 1 | ☐ | ☐ | |
| | Week 4 | ☐ | ☐ | |
| | Week 9 | ☐ | ☐ | |
| | Week 12 | ☐ | ☐ | |

### My level

My starting level is: ☐ Beginner · ☐ Intermediate · ☐ Advanced

My dumbbell weights: Light pair __________ · Heavier pair __________

My training days and times: ____________________________________________________

My bedtime: __________ · My wake time: __________

---

## Part 2: Weekly Check-In Worksheets

Complete one worksheet each Sunday. Score each habit out of 7 (the number of days you did it). A score of 5 or more is a good week. A score of 3 or 4 means shrink the habit next week, not abandon it.

### Week 1 — Foundation

| Habit | Mon | Tue | Wed | Thu | Fri | Sat | Sun | Total /7 |
|---|---|---|---|---|---|---|---|---|
| Water with each meal | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | /7 |
| In bed on time | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | /7 |
| Walk 15+ minutes | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | /7 |

Sessions completed this week: ☐ A · ☐ B · ☐ C (___ of 3)

What felt easiest this week? ____________________________________________________

What felt hardest this week? ____________________________________________________

One thing to adjust next week: __________________________________________________

### Week 2 — Rhythm

| Habit | Mon | Tue | Wed | Thu | Fri | Sat | Sun | Total /7 |
|---|---|---|---|---|---|---|---|---|
| Water with each meal | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | /7 |
| In bed on time | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | /7 |
| Walk 20+ minutes | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | /7 |
| Protein at lunch and dinner | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | /7 |

Sessions completed this week: ☐ A · ☐ B · ☐ C (___ of 3)

Did I train on my planned days? ☐ Yes · ☐ Moved a session — why? ________________

One thing to adjust next week: __________________________________________________

### Week 3 — Strength Basics

| Habit | Mon | Tue | Wed | Thu | Fri | Sat | Sun | Total /7 |
|---|---|---|---|---|---|---|---|---|
| Water with each meal | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | /7 |
| In bed on time | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | /7 |
| Walk 20+ minutes | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | /7 |
| Protein at lunch and dinner | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | /7 |
| 10-minute screen-free wind-down | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | /7 |

Sessions completed this week: ☐ A · ☐ B · ☐ C (___ of 3)

Form confidence (1–5) — Squat ___ · Hinge ___ · Push ___ · Pull ___

Any move rated below 3 stays at the same weight next week. Which one? _______________

### Week 4 — First Check-In (full review)

Repeat your measurements and photos first, then complete this worksheet.

| Habit | Total /7 |
|---|---|
| Water with each meal | /7 |
| In bed on time | /7 |
| Walk 20+ minutes | /7 |
| Protein at lunch and dinner | /7 |
| 10-minute screen-free wind-down | /7 |

Sessions completed in Weeks 1–4: ___ of 12

Measurements: see the Starting Point table. What changed? _________________________

What has improved that has nothing to do with appearance? __________________________

My five favourite recipes so far: ________________________________________________

My level for Weeks 5–8: ☐ Stay · ☐ Move up

One adjustment for next month: __________________________________________________

### Week 5 — Energy

| Habit | Mon | Tue | Wed | Thu | Fri | Sat | Sun | Total /7 |
|---|---|---|---|---|---|---|---|---|
| Water with each meal | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | /7 |
| In bed on time | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | /7 |
| Walk 20+ minutes | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | /7 |
| Protein at lunch and dinner | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | /7 |
| Screen-free wind-down | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | /7 |
| Three meals, sitting down, no screen | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | ☐ | /7 |

Sessions completed this week: ☐ A · ☐ B · ☐ C (___ of 3)

My most reliable breakfast: _____________________________________________________

My most reliable lunch: ________________________________________________________

My most reliable dinner: _______________________________________________________

### Week 6 — Midway Momentum

| Habit | Total /7 |
|---|---|
| Water with each meal | /7 |
| In bed on time | /7 |
| Walk 20+ minutes | /7 |
| Protein at lunch and dinner | /7 |
| Screen-free wind-down | /7 |
| Three meals, sitting down, no screen | /7 |

Sessions completed this week: ☐ A · ☐ B · ☐ C (___ of 3)

Three changes that have nothing to do with appearance: ____________________________

Energy compared with Week 1 (1–10): ___ (Week 1: ___)

If my energy has not improved, my sleep this week was: ☐ Good · ☐ Mixed · ☐ Poor

### Week 7 — Consistency Under Pressure

| Habit | Total /7 |
|---|---|
| Water with each meal | /7 |
| In bed on time | /7 |
| Walk (full or busy-day version) | /7 |
| Protein at lunch and dinner | /7 |
| Screen-free wind-down (full or 5-min version) | /7 |
| Three meals, sitting down, no screen | /7 |

Sessions completed this week: ☐ A · ☐ B · ☐ C (___ of 3) — short sessions count.

Did I use the short session or the minimum week? ☐ Yes · ☐ No

My personal minimum week (the version I can do in my worst week): __________________

______________________________________________________________________________

### Week 8 — Strength Progression

| Habit | Total /7 |
|---|---|
| Water with each meal | /7 |
| In bed on time | /7 |
| Walk 20+ minutes | /7 |
| Protein at lunch and dinner | /7 |
| Screen-free wind-down | /7 |
| Three meals, sitting down, no screen | /7 |
| One thing that went well today (evening note) | /7 |

Sessions completed this week: ☐ A · ☐ B · ☐ C (___ of 3)

Which exercises have progressed most since Week 3? ________________________________

Any lift that has not progressed? What will I adjust (one thing only)? _______________

### Week 9 — Second Check-In (full review)

Repeat your measurements and photos first, then complete this worksheet.

| Habit | Total /7 |
|---|---|
| Water with each meal | /7 |
| In bed on time | /7 |
| Walk 20+ minutes | /7 |
| Protein at lunch and dinner | /7 |
| Screen-free wind-down | /7 |
| Three meals, sitting down, no screen | /7 |
| One thing that went well today | /7 |

Sessions completed in Weeks 5–9: ___ of 15

Measurements: see the Starting Point table. What changed since Week 4? ______________

Which habits are automatic now? _________________________________________________

My personal eating plan (reliable breakfast, 2–3 lunches, 8–10 dinners, planned snack):

______________________________________________________________________________

My one specific goal for the final three weeks: ___________________________________

### Week 10 — The Home Stretch

| Habit | Total /7 |
|---|---|
| Water with each meal | /7 |
| In bed on time | /7 |
| Walk 20+ minutes | /7 |
| Protein at lunch and dinner | /7 |
| Screen-free wind-down | /7 |
| Three meals, sitting down, no screen | /7 |
| One thing that went well today | /7 |

Sessions completed this week: ☐ A · ☐ B · ☐ C (___ of 3)

What I am most proud of so far: _________________________________________________

### Week 11 — Real-Life Proof

| Habit | Total /7 |
|---|---|
| Water with each meal | /7 |
| In bed on time | /7 |
| Walk 20+ minutes | /7 |
| Protein at lunch and dinner | /7 |
| Screen-free wind-down | /7 |
| Three meals, sitting down, no screen | /7 |
| One thing that went well today | /7 |

Sessions completed this week: ☐ A · ☐ B · ☐ C (___ of 3)

Three habits that feel automatic now: ____________________________________________

The one habit that still needs attention (and its smaller target): ____________________

### Week 12 — Finish Strong

| Habit | Total /7 |
|---|---|
| Water with each meal | /7 |
| In bed on time | /7 |
| Walk 20+ minutes | /7 |
| Protein at lunch and dinner | /7 |
| Screen-free wind-down | /7 |
| Three meals, sitting down, no screen | /7 |
| One thing that went well today | /7 |

Sessions completed this week: ☐ A · ☐ B · ☐ C (___ of 3)

Total sessions completed in 12 weeks: ___ of 36

---

## Part 3: Habit Tracker (12-Week Overview)

Copy this table into your tracker or use `templates/habit-tracker.csv`. Tick each day you complete a habit. Score each week out of 7 per habit.

| Week | Water | Bedtime | Walk | Protein | Wind-down | Screen-free meals | Went well note |
|---|---|---|---|---|---|---|---|
| 1 | /7 | /7 | /7 | — | — | — | — |
| 2 | /7 | /7 | /7 | /7 | — | — | — |
| 3 | /7 | /7 | /7 | /7 | /7 | — | — |
| 4 | /7 | /7 | /7 | /7 | /7 | — | — |
| 5 | /7 | /7 | /7 | /7 | /7 | /7 | — |
| 6 | /7 | /7 | /7 | /7 | /7 | /7 | — |
| 7 | /7 | /7 | /7 | /7 | /7 | /7 | — |
| 8 | /7 | /7 | /7 | /7 | /7 | /7 | /7 |
| 9 | /7 | /7 | /7 | /7 | /7 | /7 | /7 |
| 10 | /7 | /7 | /7 | /7 | /7 | /7 | /7 |
| 11 | /7 | /7 | /7 | /7 | /7 | /7 | /7 |
| 12 | /7 | /7 | /7 | /7 | /7 | /7 | /7 |

**How to read your tracker:** A habit scoring 5 or more most weeks is becoming automatic. A habit scoring 3 or less for two weeks running needs a smaller target, not more effort. A blank week is information, not failure — note what happened and restart the next week.

---

## Part 4: Measurement Tracker

Record measurements on the morning of Day 1, Week 4, Week 9, and Week 12, before eating, in the same conditions each time.

| Measure | Day 1 | Week 4 | Change | Week 9 | Change | Week 12 | Change |
|---|---|---|---|---|---|---|---|
| Weight (optional) | | | | | | | |
| Waist (at navel) | | | | | | | |
| Hips | | | | | | | |
| Resting heart rate | | | | | | | |
| Energy (1–10) | | | | | | | |
| Sleep quality (1–5) | | | | | | | |
| Clothes fit (1–5) | | | | | | | |

**Notes on measuring:** Measure your waist at the navel, relaxed, after breathing out. Measure hips at the widest point. Weigh yourself at most once a week, at the same time of day, or not at all. The scale is the least interesting number — strength, energy, sleep, and how your clothes fit tell you far more.

---

## Part 5: Progress Photo Log

| Date | Week | Front | Side | Lighting / location | What I notice |
|---|---|---|---|---|---|
| | Day 1 | ☐ | ☐ | | |
| | Week 4 | ☐ | ☐ | | |
| | Week 9 | ☐ | ☐ | | |
| | Week 12 | ☐ | ☐ | | |

Compare photos side by side, in the same order, not from memory. Look for posture, how clothes sit, and overall shape — not for perfection.

---

## Part 6: Meal-Planning Template

Use one page per week. Pick three to five dinners from the recipe collection, one or two lunches to repeat, and one breakfast to repeat. Shop once from the list.

**Week of: __________**

| Day | Breakfast | Lunch | Dinner | Notes |
|---|---|---|---|---|
| Mon | | | | |
| Tue | | | | |
| Wed | | | | |
| Thu | | | | |
| Fri | | | | |
| Sat | | | | |
| Sun | | | | |

**Shopping list:** ________________________________________________________________

______________________________________________________________________________

**Batch cooking this week (one item to prepare in advance):** ________________________

**My five favourite recipes (update at each check-in):**

1. ____________________________ 2. ____________________________ 3. ____________________________
4. ____________________________ 5. ____________________________

---

## Part 7: Sleep and Energy Log

Complete this for one week at a time, whenever you want a closer look at your sleep and energy. A short version: bedtime, wake time, sleep quality (1–5), energy at midday (1–10), and energy in the evening (1–10).

| Day | Bedtime | Wake time | Hours slept | Sleep quality (1–5) | Midday energy (1–10) | Evening energy (1–10) | Notes (caffeine, screens, stress) |
|---|---|---|---|---|---|---|---|
| Mon | | | | | | | |
| Tue | | | | | | | |
| Wed | | | | | | | |
| Thu | | | | | | | |
| Fri | | | | | | | |
| Sat | | | | | | | |
| Sun | | | | | | | |

**What I notice after a week of logging:** __________________________________________

**One sleep change I will try next week:** __________________________________________

---

## Part 8: Reset Review Worksheet (Week 12)

Complete this on the Sunday of Week 12, after your final measurements and photos.

**My numbers:** Sessions completed ___ of 36 · Weeks with 3 sessions ___ of 12

**Measurements:** Compare Day 1, Week 4, Week 9, and Week 12. What changed?

______________________________________________________________________________

**Photos:** Compare Day 1 and Week 12 side by side. What do I notice?

______________________________________________________________________________

**Strength:** Which exercises progressed most? ______________________________________

**Habits:** Which habits are automatic now? ________________________________________

**Energy and sleep:** How do they compare with Week 1? _____________________________

**What I am most proud of (Week 12 sentence):** ____________________________________

**What I will keep:** ____________________________________________________________

**What I will change:** __________________________________________________________

**What I will stop:** ____________________________________________________________

**My maintenance plan (pick two strength sessions, my walking routine, and my five keep-forever habits):**

Strength sessions: ______________________ and ______________________

Walking: ______________________________________________________________________

Keep-forever habits: ___________________________________________________________

**My next step (one concrete action this week):** ___________________________________

---

*The 12-Week Reset — Companion Workbook (BEA-10). Original educational content. No medical advice. Consult a qualified clinician before starting any exercise or nutrition programme.*
