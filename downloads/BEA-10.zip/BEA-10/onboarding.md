# Customer Onboarding — The 12-Week Reset (BEA-10)

Welcome, and congratulations on starting the reset. This guide tells you exactly what to do first, how to use your files, and how to set up your first week. Read it once, then start.

---

## Important First Step — Read the Disclaimer

Before you do anything else, read the disclaimer at the front of the programme book (`content.md`). This programme is **fitness and lifestyle education only** — not medical advice. **Consult a qualified clinician before starting any exercise or nutrition programme**, especially if you have an existing health condition, are pregnant, take medication, or have been inactive for a long time. If any of that applies to you, have that conversation first. The programme will wait.

---

## Your Files

| File | What it is | Start here? |
|---|---|---|
| `content.md` | The full programme book — all 12 weeks, the movement library, 40 recipes, and appendices. | Yes — read Chapters 1–4 first. |
| `workbook.md` | The companion workbook — weekly check-in worksheets, habit tracker, measurement tracker, photo log, meal planner, sleep and energy log, and the Week 12 reset review. | Yes — complete the Starting Point pages. |
| `templates/habit-tracker.csv` | 12 weeks of daily habit checkboxes, in spreadsheet form. | Use daily. |
| `templates/meal-planner.md` | Weekly meal plan template with a shopping list. | Use every Sunday. |
| `templates/measurement-tracker.md` | Measurement and progress photo tracker for Day 1, Week 4, Week 9, and Week 12. | Use on Day 1. |
| `templates/workout-log.md` | Session log with a progression table for all 12 weeks. | Use at every session. |
| `sales-page.md` | The marketplace sales page copy for this product. | Reference only. |
| `listing.json` | Marketplace listing data. | Reference only. |
| `cover.md` / `cover.png` | Cover design brief and the generated cover image. | Reference only. |
| `README.md` | Index of this folder. | Reference only. |

---

## What to Do First (Day 0 — about 30 minutes)

1. **Read Chapters 1–4 of the programme book.** That is the welcome, how the programme works, the before-you-begin steps, and the movement library. Do not skip the movement library — it teaches you every exercise safely.
2. **Complete the Starting Point pages in the workbook.** Write your three goals (one for movement, one for habits, one for eating), choose your level (Beginner, Intermediate, or Advanced), and note your training days and times.
3. **Take your starting measurements and photos.** On the morning of Day 1, before eating: weight (optional), waist, hips, resting heart rate. Take front and side photos in the same spot with the same lighting. Log them in the workbook and in `templates/measurement-tracker.md`.
4. **Gather your kit.** A mat or carpeted floor, a sturdy chair, a wall, a water bottle, and a pair of dumbbells — or two filled water bottles to start. Put them where you will see them.
5. **Put your sessions in your calendar.** Three sessions a week, at the same time if you can. Treat them as appointments with yourself.
6. **Plan your first week of meals.** Use `templates/meal-planner.md`: pick three dinners from the recipe collection, write a shopping list, and shop once.

---

## Suggested Schedule

**Week 1 (your first week):**

- **Monday:** Strength Session A (25 minutes) + read the Week 1 chapter first.
- **Tuesday:** Walk 15 minutes.
- **Wednesday:** Strength Session B (25 minutes).
- **Thursday:** Walk 15 minutes.
- **Friday:** Walk 20 minutes + 10 minutes of mobility (Workout C).
- **Saturday:** A relaxed 20–30 minute walk or activity you enjoy.
- **Sunday:** Rest, plan next week's meals (15 minutes), and complete the Week 1 check-in worksheet in the workbook.

**Every week after that:** Follow the same skeleton — Monday, Wednesday, and Friday sessions, walking on the other days, and a 15-minute check-in every Sunday. The programme book gives you the full detail for each week.

**The golden rule:** Never miss twice. One missed session is life. If you miss one, do the next one — even the 20-minute short session from Week 7.

---

## How to Use the Materials

- **The programme book** is your instruction manual. Read the current week's chapter before Monday's session, and refer back to the movement library whenever a new exercise appears.
- **The workbook** is your record. Fill it in by hand if you print it — writing by hand makes the habit real. Complete one check-in worksheet every Sunday.
- **The habit tracker** (CSV or the workbook table) takes one minute a day. Tick each habit you did. Score each habit weekly out of 7 — a score of 5 or more is a good week.
- **The workout log** is where progression lives. When you can complete all sets and reps of an exercise with good form and two repetitions still in reserve, increase the difficulty next session — reps first, then weight.
- **The meal planner** is a Sunday habit, not a daily chore. Fifteen minutes once a week saves you from deciding what to eat every evening.

---

## How to Get Support

- **Questions about your order or the files:** Email the marketplace support address with your order number and a description of the issue, and the support team will respond.
- **Questions about an exercise or a health concern:** Ask a qualified clinician or a certified fitness professional in person. The support team cannot give medical or personal exercise advice.
- **If a file will not open:** Try opening it in a different app — the `.md` files open in any text editor or notes app, and the `.csv` file opens in any spreadsheet app.

---

## Your First Week Checklist

- ☐ Read the disclaimer and, if needed, spoke to my clinician
- ☐ Read Chapters 1–4 of the programme book
- ☐ Completed the Starting Point pages in the workbook
- ☐ Took my Day 1 measurements and photos
- ☐ Chose my level (Beginner / Intermediate / Advanced)
- ☐ Gathered my kit (mat, chair, dumbbells or water bottles)
- ☐ Put my three sessions in my calendar
- ☐ Planned my first week of meals and shopped once
- ☐ Completed my first session

Welcome to the reset. Start gently, show up three times this week, and let the programme do its work.
