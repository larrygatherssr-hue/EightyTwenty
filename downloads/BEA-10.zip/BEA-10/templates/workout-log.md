# Workout Log — The 12-Week Reset (BEA-10)

**How to use:** Log every strength session. Record the level, the weight used, and the sets and reps you completed. The progression rule: when you can complete all sets and reps of an exercise with good form and two repetitions still in reserve, increase the difficulty next session — add reps first, then weight. If your form breaks down, stay where you are.

**My level:** ☐ Beginner · ☐ Intermediate · ☐ Advanced
**My dumbbell weights:** Light __________ · Heavier __________

## Session Log

| Week | Day | Session (A / B / C) | Exercises and sets × reps | Weight used | How it felt (1–5) | Notes (form, soreness, changes) |
|---|---|---|---|---|---|---|
| 1 | | | | | | |
| 1 | | | | | | |
| 1 | | | | | | |
| 2 | | | | | | |
| 2 | | | | | | |
| 2 | | | | | | |
| 3 | | | | | | |
| 3 | | | | | | |
| 3 | | | | | | |
| 4 | | | | | | |
| 4 | | | | | | |
| 4 | | | | | | |
| 5 | | | | | | |
| 5 | | | | | | |
| 5 | | | | | | |
| 6 | | | | | | |
| 6 | | | | | | |
| 6 | | | | | | |
| 7 | | | | | | |
| 7 | | | | | | |
| 7 | | | | | | |
| 8 | | | | | | |
| 8 | | | | | | |
| 8 | | | | | | |
| 9 | | | | | | |
| 9 | | | | | | |
| 9 | | | | | | |
| 10 | | | | | | |
| 10 | | | | | | |
| 10 | | | | | | |
| 11 | | | | | | |
| 11 | | | | | | |
| 11 | | | | | | |
| 12 | | | | | | |
| 12 | | | | | | |
| 12 | | | | | | |

## The 20-Minute Short Session (Week 7 — use any time life gets busy)

Warm up 3 minutes. Two rounds of: squat 10 reps, push-up 8 reps, row 8 reps each side, glute bridge 10 reps, plank 30 seconds. Cool down 2 minutes. A short session counts.

## Progression Notes

| Exercise | Week 1 (sets × reps / weight) | Week 4 | Week 8 | Week 12 |
|---|---|---|---|---|
| Squat / goblet squat | | | | |
| Romanian deadlift | | | | |
| Glute bridge | | | | |
| Reverse lunge | | | | |
| Push-up | | | | |
| Dumbbell row | | | | |
| Overhead press | | | | |
| Plank (seconds) | | | | |

**Total sessions completed:** ___ of 36

---

*Education only — not medical advice. Stop exercising and seek medical advice if you feel chest pain, dizziness, severe shortness of breath, or sharp joint pain. Consult a qualified clinician before starting any exercise programme.*
