# Weekly Meal Planner — The 12-Week Reset (BEA-10)

**How to use:** Pick one breakfast and one or two lunches to repeat all week, and three to five dinners from the 40 recipes in the programme book. Write your shopping list from the plan, and shop once. Cook one item in advance (a soup, a grain bowl, or a double batch of dinner) to cover busy days.

**Week of:** __________________ **Week number in programme:** ______

## The Plan

| Day | Breakfast | Lunch | Dinner | Notes |
|---|---|---|---|---|
| Monday | | | | |
| Tuesday | | | | |
| Wednesday | | | | |
| Thursday | | | | |
| Friday | | | | |
| Saturday | | | | |
| Sunday | | | | |

## This Week's Reliable Meals

- **Breakfast I will repeat:** _____________________________________________________
- **Lunch I will repeat:** ________________________________________________________
- **Dinners (3–5 from the recipe collection):** _____________________________________
- **Planned afternoon snack:** ____________________________________________________

## Batch Cooking

**One item to prepare in advance this week:** ______________________________________

**Freezer backup meal (double batch of a dinner, frozen for a busy night):** ___________

## Shopping List

**Protein:** ____________________________________________________________________

**Vegetables and salad:** _________________________________________________________

**Fruit:** ______________________________________________________________________

**Carbohydrates (rice, potatoes, bread, oats, pasta):** _______________________________

**Dairy and eggs:** ______________________________________________________________

**Pantry and other:** ____________________________________________________________

## Plate Method Reminder

At lunch and dinner: **half the plate vegetables or salad, a quarter protein, a quarter slow carbohydrate, plus a thumb of healthy fat** (olive oil, nuts, or avocado). No calorie counting, no banned foods.

## End-of-Week Notes

**Recipes I enjoyed enough to cook again:** ________________________________________

**What worked this week:** _______________________________________________________

**What to change next week:** ____________________________________________________

---

*Education only — not medical advice. Adapt recipes to your tastes, allergies, and any dietary guidance from your clinician.*
