# Measurement Tracker — The 12-Week Reset (BEA-10)

**How to use:** Measure on the morning of Day 1, Week 4, Week 9, and Week 12, before eating, in the same conditions each time. Weight is optional — you may skip it entirely. The scale is the least interesting number; strength, energy, sleep, and how your clothes fit tell you far more.

## Measurements

| Measure | Day 1 (date: ______) | Week 4 (date: ______) | Week 9 (date: ______) | Week 12 (date: ______) |
|---|---|---|---|---|
| Weight (optional) | | | | |
| Waist (at navel, cm/in) | | | | |
| Hips (widest point, cm/in) | | | | |
| Resting heart rate (bpm) | | | | |
| Energy (1–10) | | | | |
| Sleep quality (1–5) | | | | |
| How my clothes fit (1–5) | | | | |

## Changes

| Measure | Day 1 → Week 4 | Week 4 → Week 9 | Week 9 → Week 12 | Day 1 → Week 12 |
|---|---|---|---|---|
| Weight (optional) | | | | |
| Waist | | | | |
| Hips | | | | |
| Resting heart rate | | | | |
| Energy | | | | |
| Sleep quality | | | | |
| Clothes fit | | | | |

## How to Measure

- **Waist:** At the navel, relaxed, after breathing out. Tape level, not pulled tight.
- **Hips:** At the widest point, feet together.
- **Resting heart rate:** First thing in the morning, before getting up if possible. Count your pulse for 60 seconds, or use a watch.
- **Energy, sleep quality, clothes fit:** Your honest rating on the day. There is no right answer.

## Progress Photos

Take two photos — front and side — in fitted clothing, in the same spot with the same lighting, on the same mornings as your measurements. Keep them private; they are for your eyes only.

| Date | Week | Front photo | Side photo | What I notice |
|---|---|---|---|---|
| | Day 1 | ☐ | ☐ | |
| | Week 4 | ☐ | ☐ | |
| | Week 9 | ☐ | ☐ | |
| | Week 12 | ☐ | ☐ | |

Compare photos side by side, not from memory. Look for posture, how clothes sit, and overall shape.

---

*Education only — not medical advice. If you have a health condition, discuss tracking and targets with your clinician.*
