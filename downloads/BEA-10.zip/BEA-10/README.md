# The 12-Week Reset: Fitness, Habits & Lifestyle Transformation — BEA-10

**Price:** $197 (one-time) · **Category:** Beauty & Health · **SKU:** BEA-10

A self-paced 12-week fitness and lifestyle programme for busy adults aged 30–55. Three progressive strength sessions a week at beginner, intermediate, and advanced levels, daily habit targets, simple nutrition guidance using a plate method, and 40 original recipes. No gym membership, extreme diet, or live coach required.

## Files

| File | What it is |
|---|---|
| `content.md` | The full programme text — welcome, how the programme works, the movement library, all 12 weeks fully written (weekly focus, workouts with sets/reps and progressions for 3 levels, habit targets, nutrition guidance, mindset notes), the maintenance plan, 40 original recipes, and troubleshooting appendices (~12,000 words). |
| `workbook.md` | Companion workbook — starting-point pages, weekly check-in worksheets for all 12 weeks, 12-week habit tracker overview, measurement tracker, progress photo log, meal-planning template, sleep and energy log, and the Week 12 reset review. |
| `templates/habit-tracker.csv` | 12-week habit tracker — daily checkboxes for every habit, week by week, in spreadsheet form. |
| `templates/meal-planner.md` | Weekly meal plan template with shopping list, batch-cooking section, and plate-method reminder. |
| `templates/measurement-tracker.md` | Measurement and progress photo tracker for Day 1, Week 4, Week 9, and Week 12, with how-to-measure guidance. |
| `templates/workout-log.md` | Workout log — session log for all 36 sessions, the 20-minute short session, and a progression table. |
| `sales-page.md` | Sales page copy — headline, subheadline, problem, solution, week-by-week contents, who it is for / not for, $197 price + 14-day guarantee, FAQ (8 questions), and disclaimers. |
| `listing.json` | Marketplace listing data (SKU, name, category, price_cents 19700, billing, headline, description, delivery note, SEO keywords, refund policy, support). |
| `cover.md` | Cover design brief — black-and-gold luxury branding, typography, imagery, layout. |
| `cover.png` | Generated premium cover image (black-and-gold, title readable, 1280 × 1920). |
| `onboarding.md` | Buyer onboarding — what to do first, how to use the materials, suggested schedule, how to get support. |
| `README.md` | This index. |

## Notes

- All content is original and education only. No medical advice, no diagnosis, no treatment or cure claims, no guaranteed results. The health/education disclaimer appears prominently in content.md, workbook.md, and sales-page.md, and buyers are told to consult a qualified clinician before starting any exercise or nutrition programme.
- No testimonials, sales figures, certifications, or reviews are fabricated anywhere in this product.
- Workouts are safe and progressive, with modifications for every exercise.
