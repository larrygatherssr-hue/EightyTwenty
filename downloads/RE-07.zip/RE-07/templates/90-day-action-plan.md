# 90-Day Action Plan

## RE-07 — The Real Estate Investing Foundations Academy

**Your chosen strategy for the next 90 days:** _______________________________________________
**Start date:** __________ **Day 90 date:** __________
**My go / no-go decision date:** __________

---

## Disclaimer

This plan is education only — not individualized investment, legal, tax, or financial advice. No income, return, or outcome is guaranteed. Verify all numbers yourself and consult licensed professionals before any transaction.

---

## Phase 1 — Days 1–30: Learn and Measure

*Goal: finish the course, know your real numbers, and build your team. Spend no money on a deal yet.*

### Week 1 — Foundations
- [ ] Read Modules 1–2 of the course manual.
- [ ] Complete Workbook Sections 1–2 (capital/time/risk self-assessment and goals).
- [ ] Check your credit reports for errors.
- [ ] Write your buy box (Workbook Section 8).
- [ ] Open or designate a separate reserves account and set a target balance: $ __________

### Week 2 — Financing and first numbers
- [ ] Read Modules 9–10.
- [ ] Speak with one mortgage professional: what can I borrow, at what rate, with what down payment?
- [ ] Underwrite 5 real listings on paper using the Workbook Section 5 practice sheet.
- [ ] Score all six strategies in the Strategy-Fit Quiz (Workbook Section 3).

### Week 3 — Team and market
- [ ] Read Modules 3–8 (one module per strategy).
- [ ] Interview one real estate agent and one property manager in your target area.
- [ ] Interview one contractor (or one experienced investor, if you chose wholesaling).
- [ ] Attend one local investor meetup or online investor group meeting.
- [ ] Research the local rules for your chosen strategy (wholesaling rules, STR rules, or landlord-tenant law — whichever applies).

### Week 4 — Choose and prepare
- [ ] Finalize your strategy choice in writing, with two sentences explaining why.
- [ ] Underwrite 5 more deals on paper (10 total for the month).
- [ ] Save the names and numbers of your team in Workbook Section 7.
- [ ] If wholesaling: identify a local real estate attorney and confirm your contract approach before any offer.
- [ ] Review: what did I learn this month? What surprised me? _______________________________________________

**Phase 1 checkpoint:** I can explain my strategy, my capital, my buy box, and my worst-case outcome in under two minutes. (Yes / Not yet — keep working.)

## Phase 2 — Days 31–60: Build and Test

*Goal: build your pipeline and test your strategy in the real world, on paper first.*

### Week 5–6 — Build
- [ ] Start your lead channel (wholesaling: direct mail, driving for dollars, or online leads) OR start viewing properties (rental / house hack / flip / BRRRR / STR).
- [ ] Build your buyers list to 10 names (wholesaling) OR your viewing shortlist to 5 properties (ownership strategies).
- [ ] Set a weekly activity target and track it: __________ conversations / viewings per week.
- [ ] Underwrite every property you view or consider — no exceptions.

### Week 7–8 — Test
- [ ] Underwrite 10 more deals (20 total across 60 days).
- [ ] Make your first practice offers on paper: what would you offer, and why? Record the reasoning.
- [ ] Follow up with every lead and contact from Weeks 5–6.
- [ ] Review your spending: marketing and education costs so far: $ __________
- [ ] Review: is my strategy still the right fit? What evidence do I have? _______________________________________________

**Phase 2 checkpoint:** I have a live pipeline (leads or viewings), a buyers list or shortlist, and 20 deals underwritten on paper. (Yes / Not yet.)

## Phase 3 — Days 61–90: Decide and Act

*Goal: make a real go / no-go decision on your best opportunity — with evidence.*

### Week 9–10 — Stress-test
- [ ] Pick your single best opportunity and stress-test it: rent 10% lower, repairs 20% higher, 3 months vacant. Write the results.
- [ ] Confirm your financing in writing (pre-approval or proof of funds) before any offer.
- [ ] Consult your attorney before signing any contract.
- [ ] Confirm your backup exit in writing: if this deal cannot close / sell / rent as planned, what happens?

### Week 11–12 — Decide
- [ ] Make your go / no-go decision on the date you set at the top of this plan.
- [ ] **If GO:** make the offer or close the deal, following your contract, inspection, and financing steps.
- [ ] **If NO-GO:** write down why, what you learned, and the date you will revisit (no later than 90 days from now).
- [ ] Complete a full 90-day review: deals underwritten ______, people spoken to ______, hours spent ______, money spent $ ______, money earned $ ______.
- [ ] Set your next 90-day goal: _______________________________________________

**Phase 3 checkpoint:** I made a dated, written decision — a deal or a deliberate wait — and I can explain why. (Yes / Not yet.)

---

## Weekly Review (copy this page each week)

**Week of:** __________
**Deals underwritten this week:** __________
**People I spoke to:** __________
**Hours spent:** __________
**Money spent this week:** $ __________
**What I learned:** _______________________________________________
**What I will do differently next week:** _______________________________________________

---

## Rules for the 90 Days

1. No deal without a written underwriting sheet.
2. No contract without attorney review on a first transaction.
3. No draining the emergency fund or the reserves account for a deal.
4. No buying a strategy course for a strategy I have not yet tested on paper.
5. Every week ends with a written review, even a short one.

---

*End of plan. This plan is education only — not individualized investment, legal, tax, or financial advice. No returns or outcomes are guaranteed.*
