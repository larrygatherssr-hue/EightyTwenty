# Strategy Comparison Guide

## RE-07 — The Real Estate Investing Foundations Academy

Use this guide with the Strategy-Fit Quiz in the workbook. Capital figures are broad, illustrative ranges for a modest single-family deal in a typical mid-sized US market. Your market will differ — always underwrite locally.

---

## 1. Long-Term Rentals

**What it is:** Buy a property, lease it to a tenant, collect rent that covers costs and leaves a monthly surplus. Hold for years.

**Capital to start:** $25,000–$50,000+ (down payment, closing costs, reserves) for a modest property.
**Time:** 1–3 hours per week with a property manager; 3–8 hours self-managing.
**Speed to income:** 1–2 months after closing and tenant placement.
**Income profile:** Modest monthly cash flow ($100–$400 per property is common on a well-bought single-family home) plus loan paydown and possible appreciation over years.
**Skills needed:** Deal analysis, tenant screening, basic landlord law, record-keeping.
**Main risks:** Vacancy, repairs, bad tenants, rent and tax increases, market downturns.
**Best for:** Patient investors with capital and a 5+ year horizon.
**Watch out for:** Underwriting without vacancy, maintenance, and capital reserves; buying in an area with falling rents.

**Example (course property):** $185,000 purchase, $1,900 rent → $188/month cash flow, 4.9% cash-on-cash, 7.3% cap rate.

## 2. House Hacking

**What it is:** Buy a property to live in and rent out part of it — a unit in a duplex/triplex/fourplex, a spare bedroom, or a legal accessory space.

**Capital to start:** $10,000–$25,000+ (often 3–5% down on an owner-occupied loan).
**Time:** 2–5 hours per week.
**Speed to income:** Immediate — your housing cost drops from the first month.
**Income profile:** Reduced housing cost first; a cash-flowing rental later if you move out and rent all units.
**Skills needed:** Landlord basics, living with tenants, basic analysis.
**Main risks:** Living next to tenants, illegal units, owner-occupancy loan requirements (usually at least one year).
**Best for:** Beginners planning to move or buy a home anyway; low-capital buyers.
**Watch out for:** Buying a unit that is not legally rentable; underwriting only the "live there" scenario and never the "rent it all" scenario.

**Example (course market):** $260,000 duplex, 5% down, one unit rented at $1,350 → owner's out-of-pocket housing cost about $830/month instead of $1,350 in rent.

## 3. Wholesaling

**What it is:** Find a motivated seller, put the property under contract, and assign the contract to a cash buyer for a fee. You typically never own the property.

**Capital to start:** $500–$2,000 per month in marketing, plus time. Little or no purchase capital.
**Time:** 10–20 hours per week of outreach, follow-up, and negotiation.
**Speed to income:** 30–90 days to a first assignment fee, with consistent effort.
**Income profile:** One-time fees per deal, often $5,000–$15,000 for a first deal; no ongoing income or equity.
**Skills needed:** Sales, negotiation, seller conversations, estimating value, building a buyers list.
**Main risks:** No buyer found, contract expires, legal rules (several states tightened wholesaling rules in 2024–2026 — check your state and consult an attorney before your first contract).
**Best for:** Time-rich, capital-poor beginners with strong people skills.
**Watch out for:** Marketing a property you do not own as though you own it; contracting at a price no buyer will accept; skipping attorney review of contracts.

**Example (course property):** Contract at $175,000, assign at $185,000 → $10,000 assignment fee at closing.

## 4. Fix-and-Flip

**What it is:** Buy below after-repair value, renovate, sell for a profit — usually in 3–9 months.

**Capital to start:** $50,000+ of accessible capital, or reliable hard-money/private financing.
**Time:** 10–20 hours per week during a project.
**Speed to income:** 3–9 months, at sale.
**Income profile:** One-time profit per deal; flip profits are generally taxed as ordinary business income.
**Skills needed:** Repair estimating, contractor management, project scheduling, ARV analysis.
**Main risks:** Renovation overruns, permit delays, market cooling before sale, holding costs.
**Best for:** Investors with capital and project-management or construction experience.
**Watch out for:** Paying above the maximum allowable offer; a single lump-sum repair guess instead of an itemized estimate; no second exit.

**Example (course property):** Buy $185,000 + $40,000 rehab + $30,250 buying/holding/selling costs → sell at $275,000 ARV = $19,750 profit before tax. A $10,000 overrun cuts that profit in half.

## 5. BRRRR (Buy, Rehab, Rent, Refinance, Repeat)

**What it is:** Buy distressed, renovate, rent, refinance based on the new value, recover capital, repeat.

**Capital to start:** $50,000+ or access to short-term (cash, private, or hard-money) financing.
**Time:** 10–15 hours per week during a project.
**Speed to income:** 6–12 months to complete a full cycle.
**Income profile:** A cash-flowing rental with little of your own money left in it — when the numbers work.
**Skills needed:** Flipping skills + landlording + refinancing knowledge, all at once.
**Main risks:** Low appraisal, long seasoning period before refinance, refinance denied, post-refinance cash flow too thin.
**Best for:** Experienced investors who already understand renovation and landlording.
**Watch out for:** A refinance that "recovers capital" but leaves a rental that does not cash flow. Always underwrite the post-refinance rental before you buy.

**Example (course property):** $230,000 all-in cost; refinance at 75% of $275,000 ARV returns $206,250 → about $23,750 left in the deal before refinance closing costs — and the rental does not cash flow after refinancing on these numbers.

## 6. Short-Term Rentals

**What it is:** Rent a property by the night on platforms such as Airbnb or Vrbo. A hospitality business, not a passive asset.

**Capital to start:** $40,000+ for purchase capital plus $10,000–$25,000 for furnishing.
**Time:** 5–15 hours per week, including weekends, even with a co-host.
**Speed to income:** 1–2 months after listing.
**Income profile:** Variable monthly income; can out-earn a long-term rental in a strong market, can under-earn it in a weak season.
**Skills needed:** Pricing, listing and photography, guest communication, cleaner management, review management.
**Main risks:** City bans or caps, seasonality, bad reviews, cleaner failures, higher insurance and utility costs.
**Best for:** Owners in strong visitor markets with time or a reliable team for turnovers.
**Watch out for:** Underwriting at peak-season rates all year; assuming a platform listing means the rental is legal locally; ignoring furnishing costs.

**Example (course property):** $160/night at 70% occupancy → $3,360/month gross, $423/month cash flow after all costs including furnishing amortized separately; at 50% occupancy the property loses money.

---

## Quick-Reference Table

| Strategy | Capital | Time/week | Speed to income | Income type | Main risk |
|---|---|---|---|---|---|
| Long-term rental | $25,000–$50,000+ | 1–3 hrs (managed) | 1–2 months | Monthly cash flow + equity | Vacancy, repairs |
| House hacking | $10,000–$25,000+ | 2–5 hrs | Immediate | Lower housing cost | Living with tenants |
| Wholesaling | $500–$2,000/mo marketing | 10–20 hrs | 30–90 days | One-time fee | No buyer, legal rules |
| Fix-and-flip | $50,000+ | 10–20 hrs | 3–9 months | One-time profit | Overruns, market drop |
| BRRRR | $50,000+ | 10–15 hrs | 6–12 months | Rental + recycled capital | Appraisal, refinance |
| Short-term rental | $40,000+ plus furnishing | 5–15 hrs | 1–2 months | Variable nightly income | Regulation, seasonality |

---

## How to Use This Guide

1. Read the strategy that matches your workbook quiz result first — then read the one that scored second.
2. For any strategy you are considering, write its capital, time, and risk numbers into the workbook's Section 4 comparison worksheet using *your* local figures.
3. Re-read the "Watch out for" line before you make any offer in that strategy. It is the most expensive line in this guide.

*This guide is education only — not individualized investment, legal, tax, or financial advice. No returns or outcomes are guaranteed.*
