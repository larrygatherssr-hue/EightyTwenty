# Glossary of Real Estate Investing Terms — 120 Terms

## RE-07 — The Real Estate Investing Foundations Academy

*Education only — definitions are general explanations, not legal, tax, or financial advice.*

1. **After-Repair Value (ARV)** — The estimated market value of a property after planned renovations are complete, based on comparable sales of similar renovated homes.
2. **Amortization** — The schedule by which a loan is repaid over time through regular payments of principal and interest.
3. **Appraisal** — A professional opinion of a property's market value, usually ordered by a lender before funding a loan.
4. **Appreciation** — An increase in a property's value over time.
5. **Assignment** — Transferring a purchase contract to another buyer, who then steps into the original buyer's position to close.
6. **Assignment fee** — The fee a wholesaler earns for assigning a purchase contract to an end buyer, usually paid at closing.
7. **Balloon payment** — A large lump-sum payment due at the end of a loan term, common in some short-term or seller-financed loans.
8. **Buy box** — A written set of criteria defining what an investor will buy: property type, price range, location, minimum returns, and deal-breakers.
9. **Buy-and-hold** — A strategy of buying property and holding it long-term for rental income and appreciation.
10. **Capitalization rate (cap rate)** — Net operating income divided by the property's price, expressed as a percentage; used to compare properties regardless of financing.
11. **Capital expenditure (CapEx)** — Spending on major, long-lived items such as a roof, HVAC system, or water heater; budgeted as a monthly reserve.
12. **Cash flow** — Money left over each month after all expenses, including mortgage, taxes, insurance, and reserves, are paid.
13. **Cash-on-cash return** — Annual cash flow divided by the total cash invested, expressed as a percentage.
14. **Cash-out refinance** — Refinancing a property for a larger loan than the current balance and taking the difference in cash.
15. **Closing costs** — Fees paid at the purchase or sale of a property, including lender fees, title fees, recording fees, and prepaid items.
16. **Closing** — The final step of a real estate transaction, when ownership legally transfers and funds are disbursed.
17. **Co-host** — A person or company that manages a short-term rental on the owner's behalf, handling guests, cleaning, and pricing.
18. **Comparable sales (comps)** — Recently sold properties similar in size, condition, and location, used to estimate a property's value or rent.
19. **Contingency** — A condition in a contract that must be met for the deal to proceed, such as an inspection or financing contingency; also, a budget allowance for unexpected costs.
20. **Contractor** — A licensed professional hired to perform renovation or repair work.
21. **Conventional loan** — A mortgage not insured or guaranteed by a government agency, with standard lender requirements for credit, down payment, and property condition.
22. **Debt service** — The total amount required to pay a loan, usually the monthly principal and interest payment.
23. **Debt Service Coverage Ratio (DSCR)** — Net operating income divided by annual debt service; a measure of whether a property's income covers its mortgage payments.
24. **Debt-to-income ratio (DTI)** — Monthly debt payments divided by monthly gross income; lenders use it to assess a borrower's ability to repay.
25. **Depreciation** — A tax concept allowing owners of rental property to deduct a portion of the building's value each year over its useful life, even if market value rises.
26. **Distressed property** — A property in poor condition, or whose owner is under financial or personal pressure to sell quickly.
27. **Down payment** — The portion of a property's purchase price paid in cash by the buyer at closing, with the rest financed by a loan.
28. **Due diligence** — The investigation a buyer performs before closing: inspections, title review, rent and expense verification, and document review.
29. **Earnest money** — A deposit made by a buyer to show serious intent, held in escrow and applied to the purchase at closing or forfeited under the contract's terms.
30. **Equity** — The difference between a property's market value and the amount owed on it.
31. **Escrow** — A neutral third-party arrangement holding funds or documents until the conditions of a transaction are met.
32. **Eviction** — The legal process of removing a tenant from a property, governed by state and local law.
33. **Fair housing** — Federal, state, and local laws prohibiting discrimination in housing on protected grounds, including in tenant screening and advertising.
34. **FHA loan** — A mortgage insured by the Federal Housing Administration, available for owner-occupied properties with a low down payment.
35. **Fix-and-flip** — Buying a property below its after-repair value, renovating it, and selling it for a profit.
36. **Forced appreciation** — Value created by the owner through renovation, better management, or adding rentable space, rather than by general market movement.
37. **Gross rent multiplier (GRM)** — A property's price divided by its annual gross rent; a rough screening tool, not a full analysis.
38. **Hard-money loan** — A short-term, asset-based loan from a private lender, typically at a higher rate with points, used for flips and BRRRR purchases.
39. **Home inspection** — A professional examination of a property's condition, covering structure, roof, plumbing, electrical, HVAC, and other systems.
40. **Homeowners association (HOA)** — An organization that manages a community or building and charges dues; its rules can restrict rentals, including short-term rentals.
41. **House hacking** — Living in a property you own while renting out part of it to reduce your housing cost.
42. **Interest rate** — The cost of borrowing money, expressed as a percentage of the loan balance per year.
43. **Investment property** — A property bought to earn income or profit, rather than to live in as a primary residence.
44. **Landlord** — The owner of a rented property.
45. **Lease** — A written agreement between a landlord and tenant setting out rent, term, responsibilities, and rules.
46. **Leverage** — Using borrowed money to control a larger asset than you could buy with cash alone; it increases both potential returns and potential losses.
47. **Lien** — A legal claim against a property for an unpaid debt, such as a mortgage or a contractor's lien.
48. **Loan-to-value ratio (LTV)** — The loan amount divided by the property's value, expressed as a percentage.
49. **Long-term rental** — A property leased to a tenant for months or years, usually on a 6- or 12-month lease.
50. **Maintenance reserve** — Money set aside each month for routine repairs and upkeep.
51. **Market appreciation** — An increase in property value driven by the local market — jobs, population, supply, and demand — rather than by the owner's actions.
52. **Market rent** — The rent a property can realistically command, based on comparable rented properties nearby.
53. **Mortgage** — A loan secured by real property, and the legal document that creates the lender's claim on the property.
54. **Mortgage insurance (PMI / MIP)** — Insurance that protects the lender when a borrower puts down less than a required amount; it adds to the borrower's monthly cost.
55. **Multifamily property** — A building with more than one separate living unit, such as a duplex, triplex, or apartment building.
56. **Net operating income (NOI)** — Annual rental income minus operating expenses, excluding mortgage payments; used to calculate cap rate and DSCR.
57. **Offer** — A formal proposal to buy a property at a stated price and terms.
58. **Operating expenses** — The ongoing costs of owning and operating a rental: taxes, insurance, maintenance, management, vacancy, and reserves.
59. **Owner-occupied** — A property the buyer lives in as a primary residence, which qualifies for different loan terms than an investment property.
60. **PITI** — Principal, interest, taxes, and insurance — the four main components of a monthly mortgage payment.
61. **Pre-approval** — A lender's conditional commitment to lend a specific amount, based on a review of the borrower's credit, income, and assets.
62. **Pre-qualification** — An informal estimate of how much a borrower might be able to borrow, based on self-reported information.
63. **Principal** — The amount borrowed on a loan, excluding interest; also the portion of each payment that reduces the loan balance.
64. **Private money** — Loans from individual lenders, negotiated directly, rather than from a bank or institutional lender.
65. **Property management** — The operation of a rental property: advertising, tenant screening, rent collection, maintenance, and accounting.
66. **Property manager** — A professional or company hired to manage a rental property on the owner's behalf, typically for 8–10% of rent.
67. **Property taxes** — Taxes levied by local government on real property, usually paid monthly through escrow or annually.
68. **Purchase agreement** — The written contract between a buyer and seller setting out the price, terms, and conditions of a sale.
69. **Real estate agent** — A licensed professional who represents buyers or sellers in property transactions.
70. **Real estate attorney** — A lawyer specializing in property transactions, contracts, title, and landlord-tenant matters.
71. **Refinance** — Replacing an existing loan with a new one, often to obtain a lower rate, different terms, or cash from equity.
72. **Rent control** — Local laws limiting how much a landlord can raise rent, where such laws exist.
73. **Rental arbitrage** — Renting a property long-term and re-renting it short-term; requires the landlord's permission and compliance with local rules.
74. **Rental income** — Money received from tenants for the use of a property.
75. **Reserves** — Money set aside for future expenses, vacancies, repairs, or emergencies.
76. **Return on investment (ROI)** — The profit from an investment divided by its cost, expressed as a percentage.
77. **Rehab** — Renovation work to repair or improve a property.
78. **Scope of work** — A written, itemized description of the renovation work a contractor agrees to perform, including materials and timeline.
79. **Seasoning period** — The length of time a lender requires a property to be owned (and often rented) before it can be refinanced based on a new value.
80. **Security deposit** — Money collected from a tenant at move-in to cover unpaid rent or damage beyond normal wear; handling is governed by state law.
81. **Seller financing** — An arrangement in which the seller acts as the lender and the buyer pays the seller over time under a promissory note.
82. **Short-term rental (STR)** — A property rented by the night, typically through a platform such as Airbnb or Vrbo.
83. **Single-family home** — A standalone residential property designed for one household.
84. **Syndication** — Pooling money from multiple investors to buy a larger property, usually with one operator managing the deal.
85. **Tenant** — A person who rents and lives in a property owned by someone else.
86. **Tenant screening** — Checking a rental applicant's income, rental history, credit, and background, using consistent written criteria and complying with fair housing law.
87. **Title** — Legal ownership of a property.
88. **Title insurance** — Insurance protecting the owner or lender against losses from defects in the property's ownership history.
89. **Underwriting** — The process of analyzing a property's numbers to decide whether it makes financial sense.
90. **Vacancy rate** — The percentage of time, or of units, that are unoccupied; also the share of rent lost to empty periods.
91. **Vacancy reserve** — Money set aside each month to cover periods when a property is unoccupied and earning no rent.
92. **Wholesaling** — Finding a property at a discount, putting it under contract, and assigning the contract to a cash buyer for a fee, without owning the property.
93. **Zoning** — Local government rules that determine how land and buildings in an area may be used.
94. **1031 exchange** — A provision of US tax law allowing some investors to defer capital-gains tax when selling one investment property and buying another qualifying property, subject to strict rules and timelines.
95. **Accessory dwelling unit (ADU)** — A secondary, self-contained living unit on the same lot as a primary home, such as a garage apartment or backyard cottage, where permitted.
96. **Adjustable-rate mortgage (ARM)** — A mortgage whose interest rate changes periodically after an initial fixed period.
97. **Annual percentage rate (APR)** — The total cost of borrowing expressed as a yearly rate, including interest and certain fees.
98. **Bridge loan** — A short-term loan used to cover a gap between buying one property and selling or refinancing another.
99. **Cash buyer** — A buyer who purchases a property with cash rather than a mortgage, able to close faster and often negotiate more strongly.
100. **Closing disclosure** — A document given to the borrower before closing, itemizing the loan terms and all closing costs.
101. **Comparative market analysis (CMA)** — An agent's estimate of a property's value based on comparable sales, listings, and market trends.
102. **Credit score** — A number summarizing a borrower's credit history, used by lenders to assess risk and set loan terms.
103. **Draw schedule** — A schedule of payments to a contractor tied to completed milestones during a renovation.
104. **Duplex** — A building with two separate living units.
105. **Fixed-rate mortgage** — A mortgage whose interest rate stays the same for the entire loan term.
106. **Gross rental income** — Total rent received before any expenses are deducted.
107. **Holding costs** — The costs of owning a property while it is not producing income, such as loan payments, taxes, insurance, and utilities during a renovation or sale.
108. **Lease option** — An agreement giving a tenant the option to buy the property at a set price within a set period.
109. **Loan origination** — The process of applying for and creating a new loan, including fees charged by the lender.
110. **Net cash flow** — Cash remaining after all expenses, including mortgage, taxes, insurance, and reserves, are paid.
111. **Occupancy rate** — The percentage of available nights or units that are rented over a given period.
112. **Points** — Upfront fees paid to a lender at closing, each point equal to 1% of the loan amount, to reduce the interest rate or as a loan fee.
113. **Pro forma** — A projection of a property's future income, expenses, and returns, based on stated assumptions.
114. **Rent roll** — A record of all units in a property, their tenants, rents, and lease terms.
115. **Turnkey property** — A property that is renovated, rented, and ready for an investor to own with minimal immediate work.
116. **Value-add** — A strategy of increasing a property's income or value through improvements or better management.
117. **BRRRR** — Buy, Rehab, Rent, Refinance, Repeat: a strategy of recycling capital through successive rental properties.
118. **Buyer's list** — A list of cash buyers an investor can contact when a deal becomes available, noting what each buyer wants.
119. **Motivated seller** — A property owner with a strong reason to sell quickly, such as relocation, financial pressure, or an inherited property.
120. **Small multifamily** — A residential property with 2–4 units, often financeable with an owner-occupied loan when the buyer lives in one unit.

*End of glossary — 120 terms.*
