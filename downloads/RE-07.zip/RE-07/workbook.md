# The Real Estate Investing Foundations Academy — Companion Workbook

## RE-07 · $297 one-time

---

## Disclaimer

This workbook is **education only**. It is not individualized investment advice, financial advice, legal advice, or tax advice. It does not recommend any specific property, strategy, or transaction. No income, return, or outcome is guaranteed, and results vary. Before making any investment decision, verify all numbers yourself and consult licensed professionals in your area — a real estate attorney, a tax professional, and a licensed mortgage professional. Laws and rules vary by state and city and change frequently.

---

## How to Use This Workbook

Work through the sections in order the first time. Section 1 and Section 2 come before you choose a strategy. Sections 3 and 4 are where the choice happens. Section 5 is your practice ground for deal analysis. Section 6 turns the choice into a dated plan. Print it or copy it into a notebook — the value is in writing your own answers, not in reading someone else's.

Keep your completed workbook. In 90 days, re-read it. Your answers will show you what you knew, what you assumed, and what changed — and that record is worth more than any single deal.

---

## Section 1 — Capital / Time / Risk Self-Assessment

Answer with real numbers. Guesses are fine for a first draft, but mark them as guesses and replace them with verified figures within 30 days.

### 1A. Capital

| Item | Amount |
|---|---|
| Total savings and accessible cash | $ __________ |
| Minus: 3 months of my living expenses (reserve — do not touch) | − $ __________ |
| Minus: money already committed elsewhere | − $ __________ |
| **Equals: my investing capital** | **$ __________** |
| Monthly amount I can add to investing capital from income | $ __________ per month |
| Credit cards or loans I would need to pay off first | $ __________ |

My investing capital today is: $ __________.
My honest assessment: this is enough to start (circle one): wholesaling only / house hacking / a modest rental / flipping or BRRRR / not yet — I need to build capital first.

### 1B. Time

| Item | Hours per week |
|---|---|
| Hours I can give real estate on weekdays | __________ |
| Hours I can give on weekends | __________ |
| **Total hours per week for the next 90 days** | **__________** |
| Hours I could give if a deal were live (evenings, calls, site visits) | __________ |

Which days and times? Write them here: _______________________________________________

What happens to this time when work or family gets busy? Write your honest answer: _______________________________________________

### 1C. Risk

Answer each question in writing. There are no right answers — only honest ones.

1. If my first deal lost $5,000, what would happen to me financially? _______________________________________________
2. If my first deal lost $5,000, what would happen to my confidence and my willingness to continue? _______________________________________________
3. What is the largest amount of money I could lose without serious harm to my household? $ __________
4. Am I comfortable talking to strangers about selling their home? (Yes / No / Willing to learn)
5. Am I comfortable managing contractors and projects? (Yes / No / Willing to learn)
6. Am I comfortable being a landlord, including handling late rent and maintenance calls? (Yes / No / Willing to learn)
7. Am I comfortable with income that varies month to month? (Yes / No)

My risk tolerance right now is (circle one): Low / Moderate / Higher — and the main reason is: _______________________________________________

### 1D. Skills and Network

Skills I already have that transfer to real estate (for example: sales, negotiation, project management, construction, bookkeeping, customer service): _______________________________________________

Skills I do not have yet and will need to learn or hire: _______________________________________________

Local contacts I already have (agent, lender, contractor, property manager, attorney, investor): _______________________________________________

Local contacts I need to find in the next 30 days: _______________________________________________

### 1E. My Starting Profile

Based on Module 2, my closest profile is (circle one): **A** (low capital, time-rich) / **B** (low capital, time-poor) / **C** (moderate capital, some time) / **D** (solid capital, little time) / **E** (capital and skills, new to real estate).

I am a blend of __________ and __________, because: _______________________________________________

---

## Section 2 — Goals Worksheet

Write one primary goal and two supporting goals. Each must have a number and a date.

**My primary goal (18 months or less):**
By __________ (date), I will _______________________________________________
(Example: "have one rental property producing at least $200 per month in cash flow after all reserves, bought with no more than $45,000 of my own capital.")

How I will know I achieved it: _______________________________________________

**Supporting goal 1 (90 days):**
By __________ (date), I will _______________________________________________

**Supporting goal 2 (90 days):**
By __________ (date), I will _______________________________________________

**Three things I will NOT do:**
1. _______________________________________________ (Example: I will not drain my emergency fund.)
2. _______________________________________________ (Example: I will not sign a contract I have not had reviewed.)
3. _______________________________________________ (Example: I will not buy a property I have not underwritten on paper.)

---

## Section 3 — Strategy-Fit Quiz

Score each strategy from 1 (poor fit) to 5 (excellent fit) on each question. Be honest — a high score on a strategy you cannot afford is not useful information.

### Quiz questions

For each strategy, ask:

1. Can I afford the capital it needs to start, with my reserves intact?
2. Can I afford the time it needs, every week, for at least six months?
3. Can I afford the worst realistic outcome if it goes wrong?
4. Does it match skills I have or can realistically learn in 90 days?
5. Does it move me toward my written goal?

### Scoring table

| Strategy | Q1 Capital (1–5) | Q2 Time (1–5) | Q3 Risk (1–5) | Q4 Skills (1–5) | Q5 Goal fit (1–5) | Total (out of 25) |
|---|---|---|---|---|---|---|
| Long-term rental | | | | | | |
| House hacking | | | | | | |
| Wholesaling | | | | | | |
| Fix-and-flip | | | | | | |
| BRRRR | | | | | | |
| Short-term rental | | | | | | |

**My top-scoring strategy:** _______________________________________________ (score: _____ / 25)
**My second choice:** _______________________________________________ (score: _____ / 25)

**Important check:** Did any strategy score 1 or 2 on Question 3 (worst realistic outcome)? If so, it is not a candidate right now, whatever its total score. Write it here and why: _______________________________________________

**My strategy choice for the next 90 days:** _______________________________________________

**Why this strategy, in two sentences:** _______________________________________________

---

## Section 4 — Strategy Comparison Worksheet

Fill in one column per strategy you are seriously considering. Use the strategy comparison guide (`templates/strategy-comparison-guide.md`) and the decision matrix (`templates/decision-matrix.csv`) alongside this worksheet. Use local numbers where you have them; mark estimates clearly.

| Factor | Long-term rental | House hacking | Wholesaling | Fix-and-flip | BRRRR | Short-term rental |
|---|---|---|---|---|---|---|
| Capital needed in my market | | | | | | |
| Hours per week in my life | | | | | | |
| Months until first income | | | | | | |
| Income in year one (realistic) | | | | | | |
| Worst realistic loss | | | | | | |
| Skills I need that I lack | | | | | | |
| Local rules I must check | | | | | | |
| My honest enthusiasm (1–5) | | | | | | |

**What surprised me most when I filled in this table:** _______________________________________________

**The strategy I am ruling out, and why:** _______________________________________________

---

## Section 5 — Deal-Analysis Practice Sheet

Use this sheet for every deal you underwrite. Copy it as many times as you need — ten deals on paper is the Module 10 homework.

### 5A. Property

Address / area: _______________________________________________
Property type: __________________ Bedrooms / baths: __________ Square feet: __________
Year built: __________ Condition (move-in ready / light rehab / heavy rehab): __________
Asking price: $ __________ My offer price (if any): $ __________
Source of the deal: _______________________________________________

### 5B. Rental screen

| Line | Monthly | Annual |
|---|---|---|
| Gross rent (from comparable rentals, not the seller) | $ __________ | $ __________ |
| Property taxes | $ __________ | $ __________ |
| Insurance | $ __________ | $ __________ |
| Vacancy reserve (5% of rent) | $ __________ | $ __________ |
| Maintenance reserve (5% of rent) | $ __________ | $ __________ |
| Capital expenditure reserve (5% of rent) | $ __________ | $ __________ |
| Property management (8% of rent, or 0 if self-managing — note the hours) | $ __________ | $ __________ |
| Other (HOA, utilities paid by owner, etc.) | $ __________ | $ __________ |
| **Total operating expenses** | **$ __________** | **$ __________** |
| **Net operating income (NOI)** | | **$ __________** |
| Mortgage payment (principal + interest) | $ __________ | $ __________ |
| **Monthly / annual cash flow** | **$ __________** | **$ __________** |

Cash invested (down payment + closing costs + initial repairs): $ __________
Cash-on-cash return (annual cash flow ÷ cash invested): __________ %
Cap rate (NOI ÷ purchase price): __________ %
DSCR (NOI ÷ annual mortgage payment): __________

**Rental verdict (circle one):** Pass / Offer lower / Needs more information / Walk away.
**Why:** _______________________________________________

### 5C. Flip screen (if applicable)

After-repair value (ARV), from comparable sales: $ __________
Repair estimate (itemized, with 10–20% contingency): $ __________
Maximum allowable offer (ARV × 70% − repairs): $ __________
Purchase price: $ __________ Buying closing costs: $ __________
Holding costs per month: $ __________ × __________ months = $ __________
Selling costs (roughly 7% of sale price): $ __________
Expected profit (ARV − all costs above): $ __________
Profit if ARV is 10% lower: $ __________
Profit if repairs cost 20% more: $ __________

**Flip verdict (circle one):** Pass / Offer lower / Needs more information / Walk away.
**Why:** _______________________________________________

### 5D. Stress tests

- If rent were 10% lower, monthly cash flow would be: $ __________
- If the property sat vacant for 3 months, I would need: $ __________ in reserves to carry it.
- If I could not sell / refinance / find a tenant, my backup exit is: _______________________________________________
- Can I afford that backup exit? (Yes / No)

### 5E. Worked example — check your method

Using the course's example property ($185,000 purchase, $1,900 rent, $148,000 loan at 6.5%), you should arrive at: monthly cash flow **$188**, annual cash flow **$2,256**, cash-on-cash return **4.9%**, cap rate **7.3%**, DSCR **1.20**. If your numbers differ, re-check each expense line — the most common error is leaving out vacancy, maintenance, or capital reserves.

Flip check: $275,000 ARV − $185,000 purchase − $40,000 repairs − $4,000 buying costs − $7,000 holding costs − $19,250 selling costs = **$19,750** profit before tax.

Wholesale check: contract at $175,000, assign at $185,000 = **$10,000** assignment fee.

BRRRR check: $230,000 all-in cost − $206,250 refinance (75% of $275,000) = **$23,750** cash left in the deal before refinance closing costs — and the post-refinance rental does not cash flow on these numbers, which is why the refinance test matters.

---

## Section 6 — 90-Day Action Plan

Copy your dated plan from `templates/90-day-action-plan.md` here, or use this summary and keep the full template as your working document.

### Days 1–30: Learn and measure

| Week | Actions | Done? |
|---|---|---|
| 1 | Finish Modules 1–2 and this workbook's Sections 1–3; check credit reports; write my buy box | ☐ |
| 2 | Interview one agent and one lender; underwrite 5 deals on paper | ☐ |
| 3 | Interview one property manager and one contractor; attend one investor meetup or group | ☐ |
| 4 | Underwrite 5 more deals; finalize strategy choice; set up reserves account | ☐ |

### Days 31–60: Build and test

| Week | Actions | Done? |
|---|---|---|
| 5–6 | Build team list (names, numbers); start lead channel or property viewings | ☐ |
| 7–8 | Underwrite 10 more deals; if wholesaling, build buyers list to 10 names | ☐ |

### Days 61–90: Decide and act

| Week | Actions | Done? |
|---|---|---|
| 9–10 | Stress-test best opportunity; consult attorney before any contract | ☐ |
| 11–12 | Make a go / no-go decision; either make first offer/deal or set a dated revisit plan | ☐ |

### My 90-day commitments

1. I will underwrite __________ deals on paper in 90 days.
2. I will have __________ local team contacts saved by day 30.
3. My go / no-go decision date is: __________
4. My reserves target by day 90 is: $ __________

### Weekly review (copy this page each week)

Week of: __________
Deals underwritten this week: __________
People I spoke to: __________
Hours spent: __________
What I learned: _______________________________________________
What I will do differently next week: _______________________________________________

---

## Section 7 — My Team and Resources

| Role | Name | Phone / email | Notes |
|---|---|---|---|
| Real estate agent | | | |
| Mortgage / lending professional | | | |
| Property manager | | | |
| Contractor | | | |
| Real estate attorney | | | |
| Insurance professional | | | |
| Tax professional | | | |
| Home inspector | | | |
| Investor group / meetup | | | |

## Section 8 — My Buy Box

Property type(s) I will buy: _______________________________________________
Area(s): _______________________________________________
Price range: $ __________ to $ __________
Minimum monthly cash flow after all reserves: $ __________
Minimum cash-on-cash return: __________ %
Maximum repair budget: $ __________
Deal-breakers (things that make me walk away automatically):
1. _______________________________________________
2. _______________________________________________
3. _______________________________________________

---

*End of workbook. This workbook is education only — not individualized investment, legal, tax, or financial advice. No returns or outcomes are guaranteed.*
