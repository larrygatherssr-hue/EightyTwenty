# The Real Estate Investing Foundations Academy

## RE-07 — Complete Course Manual

**Price:** $297 one-time · **Category:** Real Estate · **Format:** 12-module written course manual, with strategy-fit quiz and decision matrix, strategy comparison guide, glossary of 120 investing terms, and 90-day action plan

---

## Important Disclaimer — Please Read First

This course is **education only**. It is not individualized investment advice, financial advice, legal advice, tax advice, or a recommendation to buy, sell, finance, or hold any specific property. Real estate investing involves real risk, including the risk of losing money. No income, return, rent, appreciation, or outcome is guaranteed, and results vary widely based on the property, the market, financing, management, and the investor's own decisions and circumstances.

The numbers in this course are **worked examples for teaching purposes**, using one consistent example property so you can compare strategies fairly. They are not predictions, appraisals, or promises about any real property. Actual rents, prices, interest rates, taxes, insurance, repair costs, vacancy rates, and regulations change over time and differ by location. Before you make any investment, speak with licensed professionals in your area — a real estate attorney, a tax professional, a licensed mortgage professional, and, where relevant, a licensed real estate agent — and verify every number yourself.

Laws and rules that affect real estate investing — including wholesaling rules, short-term rental rules, landlord-tenant law, zoning, and lending rules — vary by state and city and change frequently. This course explains concepts at a general level; it does not and cannot tell you what is lawful in your jurisdiction. Check current local rules before you act.

---

## How to Use This Course

This manual is the complete written course manual for the 12-module course. Each module is a full chapter below. You do not need to read it in one sitting. The recommended path is:

1. **Read Modules 1 and 2 first.** They give you the language of investing and an honest picture of your own capital, time, and risk tolerance. Everything after them depends on that picture.
2. **Read Modules 3 through 8** — one module per strategy — and score each one against your own situation using the Strategy-Fit Quiz in the workbook.
3. **Read Modules 9, 10, and 11** — financing, deal analysis, and risk — before you look at any real deal.
4. **Finish with Module 12**, which turns your choice into a dated 90-day plan.

Keep the workbook open beside you. Every module ends with action steps, and the workbook is where those steps become decisions written in your own words. Do not skip the numbers. Real estate is a numbers business, and the habit of underwriting a deal on paper — before emotion, before a sales pitch, before a contract — is the single most valuable skill in this course.

### The Example Property Used Throughout This Course

To make the strategies comparable, every worked example in this course uses the **same property**:

- A 3-bedroom, 2-bathroom single-family house, 1,450 square feet, built in 1985, in a stable suburb of a mid-sized American city.
- **Purchase price:** $185,000 (as a move-in-ready rental or a flip candidate at a discount).
- **After-repair value (ARV):** $275,000 after a $40,000 renovation.
- **Market rent (long-term):** $1,900 per month.
- **Property taxes:** $220 per month ($2,640 per year).
- **Homeowner's insurance:** $120 per month ($1,440 per year) for a long-term rental.
- **Conventional financing used in the rental example:** 20% down ($37,000), loan of $148,000 at 6.5% fixed for 30 years, principal and interest of $935 per month.

These figures are invented for teaching. Your market will differ. The point is not the figures themselves — it is the method. When you can run these calculations on a property you are considering, you can compare strategies honestly instead of choosing by enthusiasm.

---

## Table of Contents

- Module 1 — How Real Estate Investing Actually Works
- Module 2 — Your Starting Position: Capital, Time, Risk, and Goals
- Module 3 — Long-Term Rentals: The Slow, Steady Strategy
- Module 4 — House Hacking: Live in Your First Investment
- Module 5 — Wholesaling: Deals Without Owning Property
- Module 6 — Fix-and-Flip: Buy, Renovate, Sell
- Module 7 — BRRRR: Buy, Rehab, Rent, Refinance, Repeat
- Module 8 — Short-Term Rentals: Nightly Income, Daily Work
- Module 9 — Financing: How Deals Are Actually Paid For
- Module 10 — Deal Analysis: Underwriting Any Property in 15 Minutes
- Module 11 — Risk, Law, and Taxes: What Can Go Wrong and How to Prepare
- Module 12 — Choosing Your Strategy and Your First 90 Days
- Appendix A — The Strategy Comparison at a Glance
- Appendix B — Glossary (120 Terms) — see `templates/glossary.md`

---

# Module 1 — How Real Estate Investing Actually Works

## 1.1 What you are actually buying

When people say "invest in real estate," they usually mean one of four different things, and confusing them is the first mistake beginners make.

**First, you can buy cash flow.** A property that brings in more rent each month than it costs to own and operate produces income. That is the rental model. The income is usually modest per property — often a few hundred dollars a month on a well-bought single-family home — and it arrives slowly, month after month, for years.

**Second, you can buy appreciation.** A property may rise in value over time because the area improves, demand grows, or you improve the property itself. Appreciation is real, but it is not guaranteed, it is not evenly distributed, and it cannot be counted on in any particular year. Anyone who tells you a market "always goes up" is selling you something.

**Third, you can buy a discount.** If you buy a property for less than it is worth — because the seller needs speed, the property needs work, or you found it before the open market did — you create value at the moment of purchase. Wholesaling and flipping are built on this idea. The discount is your margin, and it is earned by finding, negotiating, and solving problems, not by hoping prices rise.

**Fourth, you can buy a service business that happens to involve a house.** A short-term rental is closer to running a small hotel than to owning a passive asset. You are selling clean beds, fast replies, good photos, and a pleasant stay. The house is the stage; the business is hospitality.

Most strategies combine two or more of these. A rental produces cash flow and may appreciate. A flip captures a discount and forced appreciation from renovation. BRRRR tries to combine all of them. The confusion begins when a beginner expects one strategy to deliver another strategy's rewards — for example, expecting a long-term rental to produce flip-sized profits in six months, or expecting a short-term rental to run itself like a long-term rental. It will not, and the disappointment that follows is often blamed on "real estate" when the real problem was a mismatched expectation.

## 1.2 The four ways investors get paid

Every dollar an investor makes in real estate comes through one of four channels. Learn them now, because every strategy in this course is a different combination of them.

**Cash flow** is money left over after all expenses in a given month. It is the most honest measure of a rental's health, and the most commonly overstated. A property that "rents for $1,900" does not earn $1,900. It earns whatever remains after the mortgage, taxes, insurance, vacancy, maintenance, capital reserves, and management. You will calculate this properly in Module 10. Cash flow is taxed as income in most cases, and it is the only one of the four channels that pays you while you hold the property.

**Appreciation** is the increase in a property's value. It comes in two kinds. *Market appreciation* is driven by the local economy, jobs, population, interest rates, and supply — forces you do not control. *Forced appreciation* is value you create: a renovation, a better tenant mix, a legal additional unit, a rent increase supported by real improvements. Forced appreciation is the only kind you can influence directly, which is why flippers and BRRRR investors focus on it.

**Loan paydown** is the slow, quiet wealth builder. Every mortgage payment includes principal, and every principal payment increases your equity — the difference between what the property is worth and what you owe. On a rental, the tenant's rent is effectively making those payments for you. You do not see this money month to month, but over ten or twenty years it is often the largest single source of wealth in a rental portfolio. It is also the reason a property with thin monthly cash flow can still be a reasonable long-term hold — provided you are honest about the cash flow and can afford to hold it.

**Tax treatment** is the fourth channel, and the most misunderstood. Real estate offers deductions — mortgage interest, property taxes, insurance, repairs, and depreciation — that can reduce taxable income from the property. Depreciation is particularly important: the tax code allows you to deduct a portion of the building's value each year even though the building may be rising in market value. This is a real benefit, but it is not free money, and it is not a reason to buy a bad deal. A tax deduction on a losing property still leaves you with a losing property. Always discuss tax questions with a qualified tax professional; this course explains concepts, not your tax return.

## 1.3 Active, passive, and the space between

You will hear the words "passive income" constantly in real estate marketing. Treat the phrase with suspicion. Almost no real estate strategy is passive at the start.

- **Active strategies** pay you for your time and skill: wholesaling, flipping, managing a short-term rental yourself. Stop working and the income stops.
- **Semi-passive strategies** need systems and people: a long-term rental with a property manager still needs an owner who reviews statements, approves repairs, and watches the market. The work shrinks; it does not vanish.
- **Truly passive strategies** exist — for example, investing as a limited partner in someone else's deal — but they require capital, trust in the operator, and acceptance that you control very little. They are not beginner strategies, and they are not covered as a first step in this course.

The honest question is not "is this passive?" but "how many hours a week does this take, who does the work, and am I willing to do it or pay for it?" A strategy that needs ten hours a week is fine for someone with ten hours a week and a disaster for someone with two. Module 2 helps you answer that for yourself.

## 1.4 Why beginners lose money: the five common mistakes

**Mistake 1: Buying the strategy, not the fit.** A beginner with $3,000 in savings buys a $997 flipping course, then discovers flipping needs $50,000 or more in capital and a contractor network. The course may be excellent. It was the wrong course for that person. This academy exists to prevent exactly that.

**Mistake 2: Underwriting with hope.** Rent is estimated from the highest listing in the neighborhood. Vacancy is assumed to be zero. Maintenance is assumed to be zero because "the house looks fine." Every expense is rounded down and every income line is rounded up. The deal looks wonderful on paper and loses money in real life. Module 10 is the cure.

**Mistake 3: Ignoring the exit.** Every deal needs an exit before you enter it. If you flip and the market cools, can you rent it instead? If you wholesale and cannot find a buyer, can you walk away under the contract's terms? If you buy a short-term rental and the city bans them, can it cash flow as a long-term rental? A deal with one exit is a gamble; a deal with two or three exits is a plan.

**Mistake 4: Paying for education before doing free homework.** There is a place for paid courses — this one included — but a beginner who has not yet read a local market report, walked three neighborhoods, talked to one property manager, and underwritten ten listings on paper is not ready to benefit from an advanced course. The free homework comes first, and Module 12 sequences it.

**Mistake 5: Confusing a guru's life with a business model.** The person selling the course may genuinely have made money in real estate — often years ago, in a different market, with capital and connections a beginner does not have. Their lifestyle is not evidence that their strategy will work for you, in your city, with your capital, this year. Judge a strategy by its numbers and its fit, not by its presenter.

## 1.5 What "success" realistically looks like in year one

A realistic first year for a beginner who follows this course is not a portfolio. It is: a clear strategy choice, ten to twenty deals underwritten on paper, a local team of three to five contacts (agent, lender, property manager, contractor, attorney), and either one small first deal — a house hack, a wholesale assignment, or a modest rental — or a deliberate decision to wait and keep building capital. That is not a failure. That is a foundation. The investors who last are the ones who treat year one as education with a possible deal attached, not as a deadline for getting rich.

### Module 1 — Action Steps

1. Write down, in one sentence, what you want real estate to do for you in the next three years: income now, wealth later, a place to live, or a new skill.
2. Write down how many hours per week you can honestly give this for the next 90 days.
3. List the four pay channels (cash flow, appreciation, loan paydown, tax treatment) and, beside each, write whether it matters to you now or later.

---

# Module 2 — Your Starting Position: Capital, Time, Risk, and Goals

## 2.1 The honest inventory

Every strategy in this course has a minimum viable starting point. Not a marketing minimum — a real one. This module helps you find yours before you fall in love with a strategy you cannot afford to start.

**Capital.** Add up money you could actually use for real estate without endangering your rent, food, transport, insurance, or emergency fund. Do not count retirement accounts you would have to raid, credit cards, or money you hope to have next month. Then subtract a reserve: at least three months of your own living expenses, kept separate, untouched by any deal. What remains is your investing capital. For many beginners it is between $0 and $10,000. That is not a problem. It simply rules some strategies in and others out — for now.

**Time.** Count real hours, not intentions. A full-time job, family, and commute leave most people with five to fifteen usable hours a week. Wholesaling and flipping consume hours in bursts. Rentals consume hours in small, irregular doses. Short-term rentals consume hours every week, including weekends. Be specific: which days, which hours, and what happens when life interrupts?

**Credit.** Your credit score and history affect financing directly. Conventional rental loans generally require a stronger profile than an owner-occupied loan, and hard-money and private lenders price risk into their rates. You do not need perfect credit to start — house hacking with an owner-occupied loan and wholesaling, which uses little or no credit, are the usual low-credit starting points — but you do need to know where you stand. If you have not checked your credit reports recently, Module 12 puts that on your week-one list.

**Skills and network.** Have you ever managed a project, negotiated a price, fixed anything in a house, talked to strangers about selling, or kept books? Each of those maps to a strategy. Have you no local contacts at all? Then your first job is building a network, and the strategy that needs the smallest network wins. Wholesaling needs buyers; flipping needs contractors; rentals need a property manager or your own willingness to manage.

**Risk tolerance.** This is not a personality quiz answer. It is a practical question: if your first deal lost $5,000, what would happen? If the answer is "I would be in serious trouble," your risk tolerance is low right now, whatever a quiz says. Risk tolerance grows with capital, knowledge, and reserves. It is not a fixed trait, and it should not be tested with money you cannot afford to lose.

## 2.2 The five starting profiles

Most beginners fall into one of five profiles. Find the closest one — you may be a blend — and note it, because Modules 3 through 8 each end with a fit note for these profiles.

- **Profile A — Low capital ($0–$5,000), time-rich.** You have more hours than money. Wholesaling and lead generation are your natural starting points. You are selling effort and hustle, not capital.
- **Profile B — Low capital, time-poor.** You have a demanding job and little money. Your best move is usually to build capital and credit first, learn analysis, and consider house hacking when you next move — or wholesaling in a narrow, part-time way.
- **Profile C — Moderate capital ($10,000–$50,000), some time.** You can house hack, buy a modest rental, or partner on a flip. You have real options, which is why choosing carefully matters most for you.
- **Profile D — Solid capital ($50,000+), little time.** You can buy a rental with a property manager, or invest passively later. Your constraint is time, so systems and professional help matter more than doing it yourself.
- **Profile E — Capital and skills, new to real estate.** You may have a trade background, sales experience, or business experience. Flipping or BRRRR may fit, but only after you learn the local numbers — skill in one field does not automatically transfer to deal analysis.

## 2.3 Goals that actually guide decisions

"I want financial freedom" is not a goal; it is a wish. A usable goal has a number, a date, and a strategy attached. Compare:

- Weak: "I want to make money in real estate."
- Usable: "Within 18 months, I want one rental property producing at least $200 per month in cash flow after all reserves, in my city, bought with no more than $45,000 of my own capital."
- Usable: "Within 90 days, I want to complete five wholesale outreach conversations a week and make my first assignment offer, with no more than $1,000 spent on marketing."

The usable versions can be tested. At the deadline, you will know whether you hit them, and if not, you will know which part failed — the market, the capital, the time, or the plan. Module 12 turns your goal into a dated plan; for now, write a draft in the workbook.

## 2.4 The decision rule for the rest of the course

As you read each strategy module, score it on four questions:

1. Can I afford to start it — honestly, with my real capital and reserves intact?
2. Can I afford the time it takes, every week, for at least six months?
3. Can I afford the worst realistic outcome if it goes wrong?
4. Does it move me toward my written goal, or is it just exciting?

A strategy that scores "yes" on all four is a candidate. A strategy that fails question 3 is not a candidate, no matter how exciting it is. Keep this rule in front of you. It is the whole point of the academy.

### Module 2 — Action Steps

1. Complete the Capital / Time / Risk Self-Assessment in the workbook. Write the actual numbers.
2. Identify your closest starting profile (A–E) and write it down.
3. Draft one usable goal with a number and a date.
4. List three things you will not do: for example, "I will not drain my emergency fund," "I will not sign a contract I have not had reviewed," "I will not buy a property I have not underwritten on paper."


---

# Module 3 — Long-Term Rentals: The Slow, Steady Strategy

## 3.1 What it is

You buy a property, a tenant lives there under a lease, and the rent covers the mortgage, taxes, insurance, and operating costs, leaving a surplus — cash flow — each month. You hold the property for years. The tenant pays down your mortgage, the property may appreciate, and you benefit from the tax treatment described in Module 1. This is the oldest, most proven strategy in real estate, and the one most beginners imagine when they think of "investing in property."

It is also the slowest. A single-family rental rarely changes anyone's life in year one. Its power is compounding: one property, then a second, then a third, each adding a modest monthly surplus and a growing equity balance. Investors who describe rentals as "boring" are usually describing them accurately — and boring is a compliment in investing.

## 3.2 Who it fits — and who it does not

**It fits** Profile C and D investors with $25,000–$50,000 or more in capital for a modest property (down payment, closing costs, and reserves), a time horizon of five years or longer, and a temperament that can handle tenants, maintenance calls, and occasional vacancies without panic. It also fits patient learners who are willing to underwrite many deals and buy only one.

**It does not fit** someone who needs income in the next 90 days, someone with no reserves (one vacant month or one broken furnace can erase a year of cash flow), or someone who cannot tolerate being a landlord — legally and personally responsible for a habitable home and for following landlord-tenant law. If the idea of a tenant calling about a leak on a Sunday fills you with dread, you will need a property manager, which costs roughly 8–10% of rent and must be included in your numbers from the start — not added later as an afterthought.

## 3.3 Worked example: the example property as a long-term rental

Using the example property from the introduction — $185,000 purchase price, $1,900 monthly rent, 20% down ($37,000), $148,000 loan at 6.5% for 30 years:

**Monthly income:** $1,900 rent.

**Monthly expenses:**
- Principal and interest: $935
- Property taxes: $220
- Insurance: $120
- Vacancy reserve (5% of rent): $95
- Maintenance reserve (5% of rent): $95
- Capital expenditure reserve (5% of rent): $95
- Property management (8% of rent): $152
- **Total monthly expenses: $1,712**

**Monthly cash flow: $1,900 − $1,712 = $188 per month, or $2,256 per year.**

**Cash invested:** $37,000 down payment + approximately $5,500 closing costs + $4,000 in initial repairs and make-ready work = **$46,500**.

**Cash-on-cash return:** $2,256 ÷ $46,500 = **4.9% per year**. That is the return on the cash you actually put in, in year one, before tax effects and before appreciation or loan paydown.

**Net operating income (NOI):** Annual rent ($22,800) minus operating expenses excluding the mortgage — taxes ($2,640), insurance ($1,440), vacancy ($1,140), maintenance ($1,140), capital reserves ($1,140), and management ($1,824) = $9,324 — gives NOI of **$13,476 per year**.

**Capitalization rate (cap rate):** $13,476 ÷ $185,000 = **7.3%**. Cap rate lets you compare properties regardless of financing, because it ignores the mortgage.

Three lessons live in these numbers. First, the cash flow is real but modest — $188 a month is a useful supplement, not a salary. Second, the reserves are not optional padding: vacancy, maintenance, and capital items are real costs that arrive irregularly, and an investor who spends the full $188 every month will be unpleasantly surprised by a $2,400 roof repair or a six-week vacancy. Third, the return improves over time as rent rises and the mortgage balance falls — but only if you hold the property and manage it competently.

**What changes the answer:** If the same property rented for only $1,700, monthly cash flow would fall to roughly negative $12 — a losing deal at this price. If the purchase price were $165,000 instead, with the same rent, cash flow would rise to roughly $300 a month. Price and rent, more than anything else, decide whether a rental works. That is why underwriting matters more than enthusiasm.

## 3.4 Finding, screening, and keeping good tenants

A rental is only as good as its tenant and its lease. A good tenant pays on time, reports problems early, and cares for the home. A bad tenancy can cost more than a year of cash flow. The process is: advertise honestly with good photos; apply the same written screening criteria to every applicant (income, rental history, credit, and background checks, as permitted by law); verify employment and prior landlords yourself rather than trusting a form; use a written lease reviewed for your state; document the property's condition at move-in with photos; and respond to maintenance promptly. Fair housing law prohibits discrimination on protected grounds — apply your criteria consistently to everyone, keep records, and if you are unsure, get legal advice before you advertise.

Tenant retention is cheaper than tenant turnover. A small rent increase for a reliable long-term tenant is usually better than a larger increase that produces a vacancy, a repaint, and a month of lost rent. Treat tenants as customers of a service you provide, not as adversaries.

## 3.5 The costs beginners forget

- **Vacancy and turnover:** Even a good property sits empty between tenants. Budget 5–8% of rent, and budget a full month of lost rent plus cleaning and minor repairs at every turnover.
- **Capital expenditures:** Roofs, water heaters, HVAC systems, and appliances have finite lives. A $95-a-month reserve is not pessimism; it is arithmetic spread over time.
- **Insurance and taxes rise.** Both tend to increase over years. Underwrite with today's numbers and re-check them annually.
- **Legal and compliance costs:** Lease preparation, eviction (if it ever becomes necessary), and local registration or inspection requirements vary by city and cost real money.
- **Your own time.** Self-managing saves the 8% management fee but costs hours. Value those hours honestly when you compare self-managing with hiring a manager.

## 3.6 When to walk away

Walk away from a rental when the cash flow is negative after honest reserves, when the property needs more work than your reserves can cover, when the neighborhood's rents are falling or major employers are leaving, or when you cannot explain in one sentence why this property, at this price, beats the next ten you will see. There will be another property. There may not be another $46,500.

### Module 3 — Action Steps

1. Underwrite the example property yourself on the Deal-Analysis Practice Sheet in the workbook. Check that you arrive at $188 per month.
2. Find three real rental listings in your area, estimate their rents from comparable listings, and underwrite each one with the same method.
3. Call one local property manager and ask: what do you charge, what do you include, and what do you see beginners get wrong in this market?

---

# Module 4 — House Hacking: Live in Your First Investment

## 4.1 What it is

House hacking means buying a property to live in and renting out part of it — a spare bedroom, a basement unit, a separate unit in a duplex, triplex, or fourplex — so that someone else's rent reduces or covers your own housing cost. It is widely considered the lowest-risk first step in real estate, and for good reason: you are buying a home you would need anyway, and the rental income is a bonus rather than the sole justification.

The classic version is a small multifamily property: you live in one unit and rent the others. Another common version is a single-family house with roommates or a rentable accessory space, where permitted. A third is buying a home, living in it for a year or more, then keeping it as a rental when you move — a strategy sometimes called "live-in flipping" when combined with light renovation, though it should never be counted on to produce flip profits.

## 4.2 Why it is the best first deal for many beginners

Three advantages make house hacking special. **First, financing.** An owner-occupied loan typically requires a much smaller down payment than an investment-property loan — often 3–5% rather than 20–25% — and usually carries a lower interest rate. On a $250,000 duplex, a 5% down payment is $12,500 instead of the $50,000 an investor loan would require. That difference is what makes house hacking accessible to Profiles A and C who could not otherwise buy.

**Second, learning with training wheels.** You live in the building. You learn what breaks, what tenants ask for, what a lease means, and what property management involves — while your housing cost is subsidized. Mistakes are smaller and closer to home, literally.

**Third, the numbers are forgiving.** Because you would be paying rent or a mortgage anyway, even a partial offset is a win. If the other unit's rent covers half your mortgage, your housing cost has halved. That is a real, immediate improvement in your monthly life, not a distant promise.

## 4.3 Worked example: the example property as a house hack

Take a duplex version of our example market: a two-unit property priced at **$260,000**, each unit renting for $1,350 per month. You buy it as your primary residence with 5% down ($13,000) on a $247,000 loan at 6.25% for 30 years — principal and interest of about $1,521 per month. Add taxes of $300, insurance of $160, and reserves for the rented unit, and your total monthly cost of ownership is roughly $2,180. The tenant in the other unit pays $1,350. **Your out-of-pocket housing cost is about $830 per month** — before counting the principal portion of your payment, which builds your equity.

Compare that with renting a comparable apartment for $1,350 a month, where you build no equity at all. The house hack saves roughly $520 a month in housing cost and starts your investing education at the same time. If you later move out and rent both units, the property's total rent of $2,700 against costs of about $2,180 leaves roughly $520 a month in cash flow — a respectable rental, bought with an owner-occupied loan.

The same honesty rules apply, though: budget vacancy and maintenance for the rented unit, keep reserves, and verify that the second unit is legal — permitted, zoned, and separately metered or not, as local rules require. An illegal unit can create serious problems with lenders, insurers, and the city.

## 4.4 The realities nobody posts about

House hacking means living next to your tenant. You will hear their music, their guests, and their complaints — and they will hear yours. Boundaries matter: a written lease, even for a roommate arrangement, clear rules about shared spaces, and a plan for maintenance requests that does not involve knocking on your bedroom door at midnight. Some people love the arrangement; some find it stressful. Know yourself before you choose it.

It also means your home is partly a business. You must report rental income, keep records, and follow landlord-tenant law for the rented portion. And when you move out, you must be prepared for the property to be judged as a pure rental — will it cash flow without you living there? Underwrite both scenarios before you buy: with you living there, and without you.

## 4.5 House hacking and the "one-year rule"

Most owner-occupied loans require you to live in the property for at least a year. That is a commitment, not a loophole to be gamed. Plan to live there for at least a year, use the year to learn and save, and only then decide whether to keep the property as a rental, sell it, or repeat the process with a second property. Investors who repeat this cycle — live in one, rent it out, buy the next — build portfolios slowly and with far less capital than investors who buy pure rentals from day one.

### Module 4 — Action Steps

1. Price duplexes, triplexes, and fourplexes in your area. What do they cost, and what does each unit rent for?
2. Run the "live there" and "rent both units" numbers on one real property using the workbook's comparison worksheet.
3. Ask a local mortgage professional: what owner-occupied loan options exist for a 2–4 unit property, what down payment is required, and what does the one-year occupancy requirement mean in practice?


---

# Module 5 — Wholesaling: Deals Without Owning Property

## 5.1 What it is

A wholesaler finds a property owner who wants to sell quickly — often because the property needs work, the owner inherited it, is behind on payments, is relocating, or is simply tired of owning it — agrees a purchase price with the owner, puts the property under contract, and then assigns that contract to a cash buyer (usually a flipper or landlord) for a fee. The wholesaler typically never owns the property, never renovates it, and never takes out a mortgage on it. The fee — the difference between the contract price and the price the end buyer pays — is the wholesaler's income.

In plain terms: you are paid for finding a good deal and bringing it to someone who can close it. Your product is the deal itself.

## 5.2 Why beginners are drawn to it — and what the marketing leaves out

Wholesaling is attractive because it needs little capital: no down payment, no renovation budget, no mortgage. That is genuinely true, and it is why Profile A investors — time-rich, capital-poor — often start here. It also teaches the most transferable skills in real estate: talking to sellers, estimating value, negotiating, and building a buyers list.

What the marketing often leaves out is equally real. Wholesaling is a **sales and marketing business**, not a passive investment. You will spend most of your time finding sellers and talking to people who say no. Marketing costs money — driving for dollars, direct mail, online ads, or cold calling — and results take weeks or months of consistent effort. A beginner who sends fifty letters and expects a deal has misunderstood the volume involved; experienced wholesalers often speak to dozens of sellers for every contract signed, and sign several contracts for every completed assignment.

The legal landscape also matters more here than in any other strategy in this course. Several states tightened their wholesaling rules in 2024–2026, and some require a real estate license for certain wholesaling activity, restrict how contracts may be marketed, or require specific disclosures. **Do not wholesale in your state until you understand your state's current rules.** Speak with a local real estate attorney before your first contract, use contracts reviewed for your jurisdiction, and never market a property you do not own as though you own it. This course explains the concept; it does not provide legal advice or contract forms, and the templates in this academy deliberately do not include assignment contracts — those must come from a licensed attorney in your state.

## 5.3 How a wholesale deal actually works

**Step 1 — Find a motivated seller.** Common sources: driving through neighborhoods looking for distressed properties; direct mail to owners of vacant, inherited, or tax-delinquent properties; online leads; referrals from agents, attorneys, and other investors; and public records. Each channel has a cost, a response rate, and a learning curve. Start with one channel and learn it properly rather than trying five at once.

**Step 2 — Talk to the seller and understand the situation.** A good wholesaler listens first. Why are they selling? What do they need — speed, certainty, a specific price, help with a difficult situation? What does the property need? A seller who needs to close in two weeks and a seller who wants top dollar in six months are different conversations.

**Step 3 — Estimate value and make an offer.** Use the after-repair value (ARV) and the repair estimate to work backward to a price that leaves room for the end buyer to profit and for your fee. The standard beginner framework is the "70% rule" as a starting screen — offer no more than 70% of ARV minus repair costs — but treat it as a rough screen, not a law. Your local market, the buyer's financing, and the property's condition all change the right number. Verify ARV with comparable sales, not with optimism.

**Step 4 — Put it under contract.** With an attorney-reviewed contract appropriate to your state, including the terms you need — an inspection period, a closing timeline, and any assignment language your state permits. Never promise a seller a closing you cannot deliver.

**Step 5 — Find the end buyer.** This is why you build a buyers list *before* you need it: local flippers, landlords, and cash buyers who have told you what they buy, where, and at what price. You present the deal honestly — the price, the condition, the ARV basis, and the repair estimate — and the buyer decides.

**Step 6 — Assign and close.** The buyer takes over the contract for an assignment fee, and the deal closes through a title company or attorney. You are paid at closing, not before. If no buyer is found within the contract period, the contract expires — which is why honest pricing and a real buyers list matter more than aggressive marketing.

## 5.4 Worked example: the example property as a wholesale deal

Return to the example property: ARV $275,000, repairs estimated at $40,000.

A wholesaler using the 70% screen would calculate: 70% of $275,000 = $192,500, minus $40,000 in repairs = **$152,500** as a rough maximum offer before their own fee. In practice, suppose the wholesaler contracts the property at **$175,000** — higher than the strict 70% screen, because this market's buyers will accept a thinner margin on a clean, straightforward house — and assigns the contract to a flipper for **$185,000**. The wholesaler's assignment fee is **$10,000**, paid at closing.

Now compare the three parties. The seller receives $175,000 for a house needing $40,000 of work, quickly and without listing it. The flipper buys at $185,000, spends $40,000 on repairs, and sells at $275,000 — the flip math in Module 6. The wholesaler earns $10,000 without owning the property, but spent weeks finding the seller, paid marketing costs, and carried the risk that no buyer would take the deal. If the wholesaler had contracted at $200,000 instead, the flipper's margin would vanish, no buyer would accept the assignment, and the deal would expire — the wholesaler earning nothing for the same effort. **Pricing discipline is the whole business.**

Typical assignment fees for a first deal are often $5,000–$15,000, varying widely by market and deal size. Do not plan your finances around the largest fee you have heard about. Plan around a modest fee, a realistic close rate, and marketing costs deducted first.

## 5.5 The honest economics of starting

Budget for: marketing (often $500–$1,500 a month for a serious direct-mail or online effort, though driving for dollars and referrals cost mainly time); a phone and a simple system for tracking leads; attorney review of your contract; and earnest money where required. Also budget for time: ten to twenty hours a week of outreach and follow-up is a realistic minimum for someone trying to close a first deal within 90 days. Wholesaling rewards consistency over intensity — a few hours every day beats a frantic weekend once a month.

### Module 5 — Action Steps

1. Before anything else, research your state's current wholesaling rules and note the name of a local real estate attorney you will consult.
2. Build a starter buyers list: find ten local cash buyers (through investor meetups, online investor groups, and public records of cash sales) and record what each one buys.
3. Pick one lead channel, define a weekly activity target (for example, 20 seller conversations a week), and track it for four weeks before judging it.

---

# Module 6 — Fix-and-Flip: Buy, Renovate, Sell

## 6.1 What it is

You buy a property below its after-repair value, renovate it, and sell it for a profit — usually within three to nine months. The profit comes from the discount at purchase plus the value created by the renovation, minus every cost of buying, holding, renovating, and selling. Flipping is a project-management and construction business that happens to involve real estate. The people who do it well are usually excellent at estimating repair costs, managing contractors, and controlling a schedule. The people who lose money are usually excellent at imagining the finished kitchen.

## 6.2 Who it fits — and who it does not

**It fits** Profile C and E investors with $50,000 or more in accessible capital (or reliable access to private or hard-money lending), comfort managing people and projects, tolerance for surprises behind walls and under floors, and the ability to carry a property for months with no income from it. A construction, project-management, or sales background helps enormously.

**It does not fit** a beginner with $5,000, no contractor relationships, and no cushion for overruns — which describes many beginners who are sold flipping courses first. It also does not fit someone who cannot make fast decisions: a flip that stalls for two months while you choose tile is a flip paying interest, taxes, insurance, and utilities for two months with nothing coming in.

## 6.3 Worked example: the example property as a flip

Using the example property — purchase $185,000, renovation $40,000, ARV $275,000, six-month project:

**Costs:**
- Purchase price: $185,000
- Renovation: $40,000
- Buying closing costs: $4,000
- Holding costs for six months (loan interest, taxes, insurance, utilities): $7,000
- Selling costs (agent commissions and closing costs, roughly 7% of sale price): $19,250
- **Total cost: $255,250**

**Revenue:** Sale at ARV: $275,000

**Gross profit before tax: $275,000 − $255,250 = $19,750**

That is a real profit on a well-executed deal — but notice how thin the margin is relative to the risk. A $10,000 renovation overrun (a roof issue, a plumbing surprise, a permit delay) cuts the profit in half. A sale at $260,000 instead of $275,000 wipes it out. A three-month delay adds several thousand dollars in holding costs. This is why experienced flippers insist on buying at a genuine discount and budgeting a contingency of 10–20% on renovation costs. On a $40,000 renovation, that means holding $4,000–$8,000 in reserve for surprises — money that must exist before the project starts, not be hoped for later.

Also note the tax treatment: flip profits are generally taxed as ordinary business income rather than long-term capital gains, because the property is inventory held for sale rather than a long-term investment. Confirm the details with a tax professional; do not assume flip profits are taxed at favorable rates.

## 6.4 The five numbers that decide a flip

1. **ARV, verified.** Based on recent comparable sales of renovated homes nearby — same size, same condition, sold within the last three to six months. Not the highest sale in the city. Not the listing price of a home still for sale.
2. **Repair estimate, itemized.** Walk the property with a contractor. Price the roof, HVAC, plumbing, electrical, kitchen, baths, flooring, paint, and exterior separately. Add the contingency. A single lump-sum guess is how flippers lose money.
3. **Holding costs, per month.** Loan payments, taxes, insurance, utilities, and lawn care — multiplied by a realistic timeline, plus a month of buffer.
4. **Buying and selling costs.** Closing costs on purchase, commissions and closing costs on sale. On a $275,000 sale, 7% is $19,250 — the single largest cost after the purchase itself, and the one beginners most often forget.
5. **Your required profit.** Decide in advance the minimum profit that justifies the risk and the months of work. Many experienced flippers will not proceed below $20,000–$30,000 on a project of this size, or below a 10–15% return on the cash invested. If the numbers do not clear your minimum, walk away — the next deal is cheaper than a bad flip.

## 6.5 Managing the renovation

Get at least two, preferably three, written contractor bids with a detailed scope of work: what is included, what materials, what timeline, what payment schedule. Never pay a large sum upfront; tie payments to completed milestones and verify the work before each payment. Visit the site regularly. Photograph everything. Keep every receipt and change order in writing. A written scope of work is not bureaucracy — it is the document that prevents the argument about whether the $40,000 included the new water heater.

Permits matter. Work done without required permits can delay a sale, void insurance, and create liability. Check what your city requires before demolition starts, not after.

## 6.6 Exit options

Before you buy, know your exits. **Exit 1:** Sell at ARV, as planned. **Exit 2:** If the market cools or the sale stalls, can the property rent for enough to cover its costs? Run the rental numbers from Module 3 on the finished property. **Exit 3:** Can you refinance and hold it as a rental (the BRRRR path in Module 7)? A flip with no viable rental exit is a deal that must sell on schedule — and schedules slip.

### Module 6 — Action Steps

1. Re-run the flip numbers above with a $10,000 renovation overrun and a $260,000 sale price. What is the profit now?
2. Walk one property for sale in your area that needs work. List every repair you can see, room by room, and estimate each one.
3. Interview one local contractor: what do they charge, how do they bid, what payment schedule do they expect, and how far out are they booked?


---

# Module 7 — BRRRR: Buy, Rehab, Rent, Refinance, Repeat

## 7.1 What it is

BRRRR stands for **Buy, Rehab, Rent, Refinance, Repeat**. You buy a distressed property below market value, renovate it, rent it to a tenant, refinance it based on its new, higher value, and use the refinanced cash to recover most of your original investment — then repeat the process with the next property. The goal is to build a rental portfolio while recycling the same capital, rather than leaving a full down payment locked in every property.

It is an elegant idea, and it works — when the numbers work. It is also the most complex strategy in this course, because it combines the skills of flipping (buying at a discount, managing a renovation), landlording (finding and keeping a tenant), and financing (qualifying for a refinance on a timeline). A beginner who attempts BRRRR as a first deal is attempting three businesses at once. Most experienced investors recommend learning at least one of those skills first.

## 7.2 The five steps, in detail

**Buy.** Find a property at a genuine discount — typically a distressed property that conventional buyers overlook. Because distressed properties often do not qualify for standard mortgages in their current condition, BRRRR purchases are frequently funded with cash, private money, or hard-money loans. That is the first barrier: you need access to short-term capital before the refinance.

**Rehab.** Renovate to a durable, rentable standard — not a flip standard. The goal is a home a tenant will stay in for years, with materials that survive tenancy, not the most expensive finishes that impress a buyer. Over-renovating for a rental is wasted money; under-renovating produces vacancies and maintenance calls.

**Rent.** Place a tenant at market rent and establish a payment history. Lenders usually want to see the property rented — often for a seasoning period of six to twelve months after purchase or renovation, depending on the loan type — before they will refinance based on the new value. A vacant property at refinance time is a problem.

**Refinance.** A lender orders an appraisal. If the property appraises at the ARV, the lender will lend a percentage of that value — commonly 70–80% for an investment property. You use the new loan to pay off the short-term purchase financing and, if the numbers allow, recover some or all of your original cash.

**Repeat.** The recovered cash funds the next deal. In the ideal case, you end up owning a cash-flowing rental with little of your own money left in it. In the real world, most BRRRR deals leave some money in the deal — $10,000, $20,000, or more — and the "repeat" happens more slowly than the marketing suggests.

## 7.3 Worked example: the example property as a BRRRR

Using the example property — purchase $185,000, renovation $40,000, ARV $275,000, rent $1,900 per month:

**Cash in:** $185,000 purchase + $40,000 renovation + $5,000 closing and holding costs during renovation = **$230,000** of total cost, funded initially with cash or short-term financing.

**Refinance:** After renovation and tenant placement, the property appraises at $275,000. A lender refinances at 75% loan-to-value: 75% × $275,000 = **$206,250** in new loan proceeds.

**Cash left in the deal:** $230,000 − $206,250 = **$23,750**, plus refinance closing costs of roughly $4,000–$6,000, leaving around **$28,000–$30,000** of your money still in the property.

**Result:** You own a rental with $1,900 in monthly rent and a $206,250 mortgage. At roughly 7% over 30 years, principal and interest are about $1,372 per month — higher than the $935 in the Module 3 example, because the loan is larger. Total monthly costs come to roughly $2,150, against $1,900 in rent: **this BRRRR, on these numbers, does not cash flow**. That is a critical lesson. A BRRRR that "recovers your capital" but leaves you with a negative-cash-flow rental is not a success — it is a liability you now own.

For this deal to work as a BRRRR, something must change: a lower purchase price (say $160,000), a lower renovation cost, a higher rent, a higher appraisal, or a lower refinance rate. For instance, at a $160,000 purchase price, total cost falls to $205,000, the refinance returns $206,250, and you recover essentially all your cash — while the same $206,250 loan still produces the same tight cash flow, so rent would still need to support it. The point is not that BRRRR fails; it is that BRRRR only works when the *rental* numbers work after the refinance, and that test must be run before you buy, not discovered after.

## 7.4 What can go wrong

- **The appraisal comes in low.** If the appraiser values the property at $240,000 instead of $275,000, the 75% refinance returns $180,000 — leaving $50,000 of your money in the deal instead of $23,750. Appraisals are opinions based on comparable sales; they are not guaranteed to match your estimate.
- **The seasoning period is longer than expected.** Some lenders require six to twelve months before refinancing based on the new value. During that time your short-term loan is accruing interest, and your capital is locked up.
- **The refinance is denied.** Credit, income, debt-to-income ratio, the property's condition, or the lender's rules can all block a refinance. Have a backup plan: can you hold the property on the existing financing? Can you rent it and wait?
- **The renovation overruns.** Every $10,000 of overrun is $10,000 more left in the deal — or $10,000 you do not recover.
- **The rent does not support the new loan.** As the worked example shows, a bigger loan means a bigger payment. Always underwrite the *post-refinance* rental before you buy.

## 7.5 Who should consider BRRRR — and when

BRRRR fits an investor who already understands renovation and landlording, has access to short-term capital, has strong enough credit and income to refinance, and can afford the deal to leave money in place if the refinance disappoints. For most beginners, the right sequence is: learn rentals first (Module 3), learn renovation on a small project or a house hack (Module 4), and only then attempt a BRRRR — or partner with someone who has done one before.

### Module 7 — Action Steps

1. Take the BRRRR worked example and re-run it at a $160,000 purchase price. What is the cash left in the deal, and does the rental cash flow after refinancing?
2. Ask a local mortgage professional: what are your seasoning requirements for a cash-out refinance on an investment property, and what loan-to-value do you allow?
3. Write down your backup plan for a BRRRR refinance that comes in $25,000 below expectation. What would you do?

---

# Module 8 — Short-Term Rentals: Nightly Income, Daily Work

## 8.1 What it is

A short-term rental (STR) — a home, apartment, or room rented by the night on platforms such as Airbnb or Vrbo — earns income per night rather than per month. In a good market, a well-run STR can gross substantially more than the same property as a long-term rental. In a bad market, or a badly run one, it can earn less — with far more work. An STR is a hospitality business: pricing, photos, listings, guest messages, cleaning, restocking, reviews, and local rules, every week.

## 8.2 Who it fits — and who it does not

**It fits** investors with a property in a location people actually visit (tourist areas, cities with events and business travel, near hospitals, universities, or attractions), capital for furnishing ($10,000–$25,000 for a typical single-family home, often more), time or a reliable team for turnovers, and comfort with variable income. It also fits owners who already have a property and want to test the STR market before committing — for example, renting a home seasonally.

**It does not fit** someone who wants passive income, someone buying in a city that restricts or bans short-term rentals, or someone whose numbers only work at peak-season rates sustained all year. It also does not fit an investor who cannot handle a bad review, a late-night guest message, or a cleaner cancelling on a turnover day. Those are normal events in this business, not emergencies — but they feel like emergencies the first time.

## 8.3 The regulation question comes first

Before you look at a single property, check the rules where you intend to operate: does the city allow short-term rentals? Is a permit, license, or registration required? Are there limits on the number of nights per year, owner-occupancy requirements, zoning restrictions, or homeowner-association bans? Do you need to collect and remit occupancy or lodging taxes? Rules change — cities that allowed STRs freely five years ago now cap them — and enforcement can include fines and forced closure. Verify with the city's planning or licensing office and, if in doubt, a local attorney. Never assume a platform listing means the rental is legal; platforms do not verify local compliance for you.

## 8.4 Worked example: the example property as a short-term rental

Using the example property, furnished and listed at an average of **$160 per night**, with **70% occupancy** — roughly 21 booked nights per month:

**Monthly gross income:** 21 nights × $160 = **$3,360 per month**. Note the seasonality hidden in that average: summer may bring 90% occupancy at $190 a night, while winter may bring 45% at $130. An annual average is the only honest way to underwrite.

**Monthly expenses:**
- Mortgage principal and interest (same $148,000 loan at 6.5%): $935
- Property taxes: $220
- Insurance (short-term rental policy, higher than a long-term policy): $180
- Utilities (electric, water, internet — paid by the owner, not the tenant): $180
- Cleaning and turnover (21 turnovers is unrealistic; assume roughly 8 stays a month at $60 per clean, plus laundry): $480
- Platform and management fees (roughly 20% of gross for platform fees and a co-host or manager): $672
- Supplies, restocking, and minor replacements: $120
- Maintenance reserve: $150
- **Total monthly expenses: $2,937**

**Monthly cash flow: $3,360 − $2,937 = $423 per month, or $5,076 per year.**

That beats the $188-a-month long-term rental on the same property — but the comparison is incomplete without two more lines. **First, furnishing:** setting up the property costs roughly $15,000 for furniture, linens, kitchenware, and decor. **Second, your time:** even with a co-host, an STR needs owner attention every week. Add furnishing to the cash invested — $46,500 (as in Module 3) + $15,000 = $61,500 — and the cash-on-cash return is $5,076 ÷ $61,500 = **8.3%**, better than the rental's 4.9%, but earned with substantially more work, more variable income, and regulatory risk. If occupancy falls to 50% (15 nights a month), gross income falls to $2,400 and the property loses money. That sensitivity — the swing between a good month and a bad month — is the defining feature of STR income.

**Arbitrage note:** Some investors rent a property long-term and re-rent it short-term (rental arbitrage). This can work, but it requires the landlord's written permission, a lease that allows it, and compliance with local STR rules — and it carries the risk that the landlord or city ends the arrangement. Do not assume you can arbitrage a property you do not own.

## 8.5 What makes an STR succeed

- **Photos and listing quality.** Professional photos, an honest and detailed description, and a clear house manual. Guests choose with their eyes first.
- **Pricing that moves.** Nightly rates should change with demand — weekends, events, seasons — rather than sitting at one flat price all year. Pricing tools exist for this; manual review every week also works.
- **Fast, warm communication.** Response time affects search ranking and guest confidence. Templates for common messages save hours.
- **A reliable cleaner.** The cleaner is the most important hire in the business. A missed clean or a dirty bathroom produces the one-star review that costs you bookings for months.
- **Reviews as an asset.** Every five-star review compounds. Every honest response to a problem protects the next booking. Protect the rating as carefully as the property.

## 8.6 The honest comparison

An STR can out-earn a long-term rental on the same property, sometimes by a wide margin. It can also under-earn it, consume weekends, and be shut down by a rule change. Before choosing STR, underwrite three scenarios — good (75% occupancy), average (60%), and poor (45%) — and ask whether you can live with the poor one for six months. If the answer is no, the long-term rental on the same property is the safer choice.

### Module 8 — Action Steps

1. Underwrite the example STR at 50% occupancy. What is the monthly cash flow?
2. Research the STR rules in one city you are considering: permit required? Night caps? Taxes?
3. Price furnishing for one real property: list the furniture, linens, and supplies it would need, and total the cost.


---

# Module 9 — Financing: How Deals Are Actually Paid For

## 9.1 The financing menu

Most beginners think financing means "getting a mortgage." A mortgage is one item on a menu, and the right item depends on the strategy, the property's condition, and your profile.

**Conventional mortgages** are the standard tool for move-in-ready rentals and house hacks. For an investment property, expect a down payment of 20–25%, a credit score requirement that is higher than for a primary residence, and a limit on the number of financed properties you can hold. For an owner-occupied property, down payments are typically 3–5% with mortgage insurance, and rates are usually lower. The tradeoff is the occupancy requirement and the slower path to a portfolio.

**FHA and similar owner-occupied loans** allow low down payments on 1–4 unit properties you live in, making them a common house-hacking tool. They carry mortgage insurance premiums and property standards that can complicate a fixer purchase. They cannot be used for a pure investment property you will not live in.

**DSCR loans** (Debt Service Coverage Ratio loans) qualify the borrower based on the property's rental income rather than personal income. The lender asks: does the rent cover the mortgage payment by a sufficient margin — typically a ratio of 1.0 to 1.25 or higher? DSCR loans are useful for investors who have strong properties but complex personal income, and they often allow more properties than conventional limits. They usually require 20–25% down and carry higher rates than owner-occupied loans.

**Hard-money loans** are short-term, asset-based loans from private lenders, typically for flips and BRRRR purchases: 6–18 month terms, interest rates often in the double digits, plus origination points (each point is 1% of the loan). They fund quickly and based mainly on the deal, not your income — which is why flippers use them. They are expensive, and the clock is the risk: every extra month of renovation is another month of high interest.

**Private money** is borrowed from individuals — often people you know — on terms you negotiate together: rate, term, security, and repayment. It can be flexible and fast, but it must be documented properly, with a written agreement and, where appropriate, a recorded lien and attorney review. Never borrow from friends or family on a handshake. The relationship is worth more than the deal.

**Seller financing** means the seller acts as the lender: you pay them over time under a promissory note and mortgage or deed of trust, instead of borrowing from a bank. It can work when a seller owns the property outright and wants income rather than a lump sum, but it requires careful documentation and an attorney.

**Cash** is the simplest financing and the most demanding: it requires having the money. Cash buyers close fastest and negotiate hardest, which is why wholesalers seek them. Paying cash does not make a bad deal good — it just removes the lender from the decision.

**Partnerships** split a deal: one partner brings capital, another brings skill, time, or a deal. Partnerships can open doors a beginner cannot open alone, but they need a written agreement covering who contributes what, who decides what, how profits and losses are shared, and how the partnership ends. Agree on the exit before you agree on the deal.

## 9.2 The numbers that decide whether you can borrow

Lenders care about a small set of factors. Learn them, because improving them is the highest-return homework a beginner can do.

- **Credit score and history.** Pay bills on time, keep credit-card balances low relative to limits, and do not open new accounts shortly before applying for a mortgage. Check your credit reports for errors and dispute them through the proper channels.
- **Debt-to-income ratio (DTI).** Your monthly debt payments divided by your monthly gross income. Lenders generally prefer a DTI below roughly 43–50%, depending on the loan type. Rental income from a property you already own may count toward income, subject to the lender's rules.
- **Reserves.** Lenders often require you to show several months of mortgage payments in reserve after closing. This is also simply good practice — see Module 11.
- **The property itself.** A lender will order an appraisal and may require repairs before funding. A property that does not meet minimum standards may not qualify for a conventional loan at all, which is why distressed purchases often need hard money or cash first.
- **Your income and employment history.** Stable, documentable income matters, especially for conventional loans. Self-employed borrowers should keep clean, complete records and expect extra questions.

## 9.3 How rates and terms change the deal

A small rate change moves the numbers more than most beginners expect. On the example property's $148,000 loan, the principal-and-interest payment is about $935 a month at 6.5%. At 7.5%, it is about $1,035 — $100 more every month, $1,200 a year, enough to erase more than half of the $188 monthly cash flow in Module 3. At 5.5%, it is about $840, adding nearly $100 a month to cash flow. This is why "what rate can I actually get?" is a question to answer with a real lender quote, not a national average from a headline. Get pre-qualified or pre-approved before you make offers, so you know your real budget and your real payment.

Loan term matters too. A 30-year loan has lower payments than a 15-year loan but builds equity more slowly and costs far more interest over its life. For a rental, the lower payment of a 30-year loan usually produces better monthly cash flow, which is the priority for a hold strategy. For a flip or BRRRR, the loan is short-term by design, and the rate matters more than the amortization schedule.

## 9.4 Pre-approval, proof of funds, and credibility

Sellers and agents take you seriously when you can show you can close. A mortgage pre-approval letter from a lender, or proof of funds for a cash purchase, should be ready before you make offers. For wholesaling, your credibility with buyers comes from your buyers list and your track record, not from a loan — but your credibility with sellers comes from honesty about your process and timeline. Never claim you have financing or a buyer you do not have.

## 9.5 Financing mistakes to avoid

- Borrowing the maximum you qualify for, rather than the amount the deal supports.
- Choosing a loan by its rate alone, ignoring points, fees, prepayment penalties, and term.
- Using short-term, high-cost debt for a long-term hold with no refinance plan.
- Draining reserves for a down payment and having nothing left for repairs or vacancy.
- Signing loan documents you have not read, or that a professional has not explained to you.

### Module 9 — Action Steps

1. Speak with one mortgage professional and one DSCR or hard-money lender. Ask each: what do you require, what rates and terms are realistic for a beginner, and what would improve my application?
2. Calculate the monthly payment on a $148,000 loan at 5.5%, 6.5%, and 7.5% using an online mortgage calculator, and note how each rate changes the Module 3 cash flow.
3. Check your credit reports and list any errors or items to address before you apply for financing.

---

# Module 10 — Deal Analysis: Underwriting Any Property in 15 Minutes

## 10.1 The principle: paper first, emotion second

Underwriting is the discipline of deciding, on paper, whether a property makes financial sense — before you visit it a second time, before you tell anyone you love it, and certainly before you sign anything. The 15-minute version in this module is a screen, not a final decision. Its job is to reject bad deals fast so you can spend your time on the few that deserve a deeper look.

The rules of underwriting: use real, verifiable numbers wherever possible; estimate conservatively where you must estimate; include every expense, including the ones that do not arrive monthly; and write the numbers down. A deal analyzed in your head is a deal analyzed by your hopes.

## 10.2 The five numbers you need for any deal

1. **Purchase price** — the price you would actually pay, including your best estimate of closing costs.
2. **After-repair value (ARV)** — what the property will be worth after renovation, based on recent comparable sales. For a move-in-ready rental, ARV is simply the current market value.
3. **Repair estimate** — itemized, with a contingency, from a walk-through or contractor bid.
4. **Rent** — market rent, based on comparable rented properties nearby, not the seller's claim or the highest listing you can find.
5. **Financing terms** — down payment, interest rate, loan term, and monthly payment, from a real lender quote or a conservative estimate.

Everything else in this module is arithmetic on those five numbers.

## 10.3 The rental screen, step by step

Work through the example property as a rental:

**Step 1 — Gross monthly rent:** $1,900.

**Step 2 — Operating expenses (excluding mortgage):**
- Taxes $220 + insurance $120 + vacancy (5%) $95 + maintenance (5%) $95 + capital reserves (5%) $95 + management (8%) $152 = **$777 per month**.

**Step 3 — Net operating income:** Annual rent $22,800 − annual operating expenses ($777 × 12 = $9,324) = **$13,476 per year**.

**Step 4 — Mortgage payment:** $935 per month ($11,220 per year) on the $148,000 loan at 6.5%.

**Step 5 — Cash flow:** $13,476 − $11,220 = **$2,256 per year, or $188 per month**.

**Step 6 — Cash-on-cash return:** $2,256 ÷ $46,500 cash invested = **4.9%**.

**Step 7 — Cap rate:** $13,476 ÷ $185,000 = **7.3%**.

**Step 8 — DSCR:** $13,476 ÷ $11,220 = **1.20**. The property's income covers its mortgage payment 1.20 times — above the 1.0 minimum many DSCR lenders look for, and in line with the 1.20–1.25 range many prefer.

**Decision rules for a first rental:** Cash flow should be positive after all reserves — not before them. Cash-on-cash return should clear your personal minimum (many investors look for 8% or more on a single-family rental; this example at 4.9% would fail that screen, which is itself a useful lesson: a property can be a reasonable long-term hold and still fail a strict cash-flow screen). Cap rate should be comparable to or better than other properties in the same market. If a deal fails two of these three tests, it deserves a much lower offer or a pass.

## 10.4 The flip screen

**Maximum allowable offer (MAO)** is the standard flip screen: MAO = (ARV × 70%) − repair costs. For the example property: ($275,000 × 70%) − $40,000 = $192,500 − $40,000 = **$152,500**. The actual purchase price of $185,000 is well above the MAO, which tells you this property, at this price, is a poor flip by the strict 70% standard — even though Module 6 showed a $19,750 profit at that price. The two statements are both true: the 70% rule builds in a margin for profit, risk, and error, and a deal above the MAO can still profit if everything goes well. The rule exists because everything rarely goes well. Use the MAO as a discipline tool, and if you pay above it, do so knowingly, with a clear reason and a second exit.

Then verify the flip profit directly: ARV − purchase − repairs − buying costs − holding costs − selling costs = profit. You did this in Module 6. Do it for every flip, and re-do it with a 10% ARV reduction and a 20% repair overrun as a stress test. If the deal still profits under stress, it is a strong deal. If it loses under stress, it is a fragile one.

## 10.5 The same property, three strategies, one table

Here is the comparison this whole course has been building toward — the example property, analyzed three ways:

| Measure | Long-term rental | Fix-and-flip | Wholesale assignment |
|---|---|---|---|
| Cash needed to start | $46,500 | $230,000+ (or hard-money financing) | Marketing costs + time |
| Time to first income | First month of tenancy | 3–9 months, at sale | At closing of assignment |
| Income in the worked example | $188/month ($2,256/year) | $19,750 once, before tax | $10,000 once, at closing |
| Ongoing work | Low (with a manager) | Intense, then done | Intense, per deal |
| Main risk | Vacancy, repairs, bad tenant | Overruns, market drop, delay | No buyer, legal rules |
| Wealth built | Equity + appreciation over years | One-time profit | None — income only |
| Best for | Patient, capital-ready beginners | Skilled project managers | Time-rich, capital-poor beginners |

No strategy wins on every row. The rental wins on durability and wealth-building. The flip wins on speed and size of a single profit. Wholesaling wins on capital required. Your job is to decide which row matters most to you right now — and to revisit the decision as your capital, time, and skills change.

## 10.6 Stress-testing every deal

Before you commit to any deal, run three stress tests:

- **Rent test:** What happens if rent is 10% lower than expected? For the example rental, rent of $1,710 instead of $1,900 turns $188 of monthly cash flow into roughly negative $2. Still close to breakeven — a sign the deal is not fragile. A deal that goes deeply negative on a 10% rent miss is fragile.
- **Cost test:** What happens if repairs cost 20% more and take two months longer? For the flip, that erases most of the profit. Budget the contingency before you buy, not after.
- **Exit test:** What happens if you cannot sell, cannot refinance, or cannot find a tenant for three months? Can you carry the property? If the honest answer is no, the deal is too big for your current position — whatever the spreadsheet says.

## 10.7 The buy box

A buy box is a written set of criteria for what you will buy: property type, price range, location, minimum cash flow or return, maximum repair budget, and deal-breakers. Write yours in the workbook after finishing this module. Its purpose is to make "no" fast and automatic. When a property outside your buy box excites you, the buy box is the document that reminds you why you wrote it.

### Module 10 — Action Steps

1. Underwrite five real listings this week using the 15-minute screen. Reject at least four on paper.
2. Write your buy box in the workbook: property type, price range, area, minimum cash flow, and three deal-breakers.
3. Stress-test your best deal of the five with the rent, cost, and exit tests above.


---

# Module 11 — Risk, Law, and Taxes: What Can Go Wrong and How to Prepare

## 11.1 The risk map

Real estate risk is not one thing. It is a map with several territories, and each strategy visits different ones.

**Market risk.** Prices and rents can fall. Interest rates can rise, making your property worth less to the next buyer and your refinance more expensive. A major local employer can close. You cannot control market risk, but you can reduce your exposure to it: buy at a price that works at today's rent and today's rate, keep reserves, and avoid counting on appreciation to make a deal work.

**Property risk.** Roofs leak, pipes burst, foundations shift, and tenants damage things. Mitigation is inspection before purchase (a professional home inspection is money well spent on any purchase), insurance, reserves, and prompt maintenance. Never waive an inspection on your first deal to make an offer more competitive — you are buying information, and information is cheap compared with a $12,000 sewer repair.

**Tenant risk.** Non-payment, damage, and vacancy are normal parts of landlording, not rare disasters. Mitigation is screening, a clear lease, reserves equal to several months of expenses, and knowledge of your local eviction process — which varies widely and can take weeks or months. Budget for the possibility, and never count on a single tenant's rent to cover a payment you cannot otherwise make.

**Financing risk.** Rates rise, lenders change rules, appraisals come in low, refinances are denied. Mitigation is pre-approval, conservative underwriting, a backup exit for every deal, and never using short-term debt without a realistic plan to repay or refinance it.

**Legal and regulatory risk.** Wholesaling rules, short-term rental bans, rent control, zoning changes, and landlord-tenant law all change, and they change locally. Mitigation is the habit this course keeps repeating: check current local rules, use an attorney for contracts and first transactions, and keep records of everything.

**Fraud and bad actors.** Real estate attracts scams: fake sellers, forged documents, contractors who take deposits and disappear, "mentors" who sell access to deals that do not exist. Mitigation is verification — title insurance, licensed professionals, written contracts, and a refusal to wire money to anyone you have not verified through independent channels. If a deal feels rushed, secretive, or too good to be true, stop and verify before you send anything.

## 11.2 Insurance: the non-negotiable

Every property you own needs insurance appropriate to its use. A long-term rental needs a landlord policy, which differs from a homeowner's policy. A short-term rental needs a policy that covers short-term guests — a standard homeowner's or landlord policy may exclude them. A flip in progress needs builder's risk coverage. An umbrella liability policy is worth discussing with an insurance professional once you own property. Insurance is not the place to save money by under-insuring: the premium is small next to the loss it protects against. Review coverage annually and whenever the property's use changes.

## 11.3 Legal basics every beginner should understand

- **Contracts.** Every real estate transaction runs on written contracts: purchase agreements, leases, assignment contracts, contractor agreements, partnership agreements. Read them. Have an attorney review your first ones. Never sign a contract you do not understand, and never rely on a verbal promise about a material term.
- **Title and closing.** A title search and title insurance protect you against claims on the property's ownership history. Closings go through a title company or attorney depending on your state. Budget closing costs on every purchase and sale.
- **Entity structure.** Some investors hold property in an LLC for liability and organizational reasons; others hold in their own name. There are costs, tax effects, and financing consequences either way, and the right choice depends on your situation. Discuss it with an attorney and a tax professional before you form an entity — not after you have already bought property.
- **Fair housing and landlord-tenant law.** Federal, state, and local law govern who you can and cannot refuse as a tenant, what you must disclose, how deposits are handled, how notices work, and how evictions proceed. These rules are specific and carry real penalties. Learn your state's rules before your first tenant, and keep written records of every screening decision.
- **Wholesaling and STR rules.** As covered in Modules 5 and 8, these two areas carry the most fast-changing local regulation in this course. Re-check them before every deal, not once a year.

## 11.4 Taxes: concepts, not advice

This section explains concepts at a general level. Your tax situation is individual, and tax law changes. Work with a qualified tax professional.

- **Rental income** is generally taxable, and rental expenses — mortgage interest, taxes, insurance, repairs, management — are generally deductible against it. Keep receipts and records from day one; reconstructing a year's expenses from memory is painful and expensive.
- **Depreciation** allows you to deduct a portion of the building's value each year over its useful life (27.5 years for residential rental property under current US rules), even if the property's market value is rising. When you sell, depreciation may be "recaptured" — taxed at that point. Understand this before you sell, not after.
- **Flip profits** are generally treated as ordinary business income, as noted in Module 6.
- **1031 exchanges** allow some investors to defer capital-gains tax when selling one investment property and buying another qualifying property, subject to strict timelines and rules. It is a tool for experienced investors with professional guidance, not a beginner's first move.
- **Record-keeping.** Separate bank accounts for your investing activity, a simple bookkeeping system, and a file for every property — purchase documents, leases, receipts, tax forms — will save you money and stress every April. Start the system with your first dollar, not your first tax return.

## 11.5 Reserves: the habit that saves investors

Reserves are the single best predictor of whether a beginner survives their first problem. Keep, at minimum: three to six months of your own living expenses, separate from investing money; and for each rental property, at least three months of that property's total monthly costs (mortgage, taxes, insurance, and a maintenance allowance) in a separate account. A flip needs its renovation contingency plus carrying costs for two extra months beyond the planned timeline. These reserves are not "extra" money — they are part of the cost of being in the business. An investor without reserves is one broken furnace away from a forced sale.

## 11.6 When to get professional help

Get an attorney for: your first purchase contract, any wholesaling contract, any partnership agreement, any entity formation, and any dispute with a tenant, contractor, or seller. Get a tax professional before your first tax year as an investor and before any sale. Get an insurance professional when a property's use changes. Get a home inspector before every purchase. These professionals cost money; not using them costs more.

### Module 11 — Action Steps

1. List the insurance you would need for your chosen strategy and get one real quote.
2. Find a local real estate attorney's name and contact details and save them before you need them.
3. Open a separate bank account or sub-account for investing reserves, and set a target balance for it.

---

# Module 12 — Choosing Your Strategy and Your First 90 Days

## 12.1 The decision, made properly

You have now read six strategies, financing, analysis, and risk. It is time to choose — not forever, but for the next 90 days. A strategy chosen for 90 days is a test, not a life sentence. At the end of the 90 days you will review what happened and either continue, adjust, or switch, with evidence instead of guesswork.

Use the workbook's Strategy-Fit Quiz and Decision Matrix to score each strategy on capital, time, risk, skills, and goal fit. Then apply the Module 2 decision rule: Can I afford to start it? Can I afford the time? Can I afford the worst realistic outcome? Does it move me toward my written goal? The strategy with the highest honest score — not the most exciting one — is your first strategy.

For most beginners, the honest answer is one of three:

- **House hacking** if you are planning to move or buy a home anyway and have modest capital.
- **Wholesaling** if you have little capital, plenty of time, and strong people skills.
- **A modest long-term rental** if you have $25,000–$50,000 in capital, a longer horizon, and a preference for slow, steady progress.

Flipping, BRRRR, and short-term rentals are usually better as second strategies, attempted after you have learned analysis, built a local team, and grown your capital or skills. There is no penalty for starting with the simplest strategy that fits. There is a large penalty for starting with the hardest one that does not.

## 12.2 Your first 90 days

The full dated plan is in `templates/90-day-action-plan.md` and in the workbook. In summary:

**Days 1–30: Learn and measure.** Finish this course and the workbook. Check your credit reports. Define your buy box. Underwrite ten deals on paper. Interview one agent, one lender, one property manager, and one contractor. Attend one local investor meetup or online investor group meeting. Spend no money on a deal yet.

**Days 31–60: Build and test.** Finalize your strategy choice. Build your team list with names and numbers. Start your lead channel if you chose wholesaling, or start viewing properties if you chose rentals or house hacking. Underwrite ten more deals. If wholesaling, make your first offers only with attorney-reviewed contracts and a real buyers list.

**Days 61–90: Decide and act.** Make a go/no-go decision on your best opportunity, using the stress tests from Module 10. Either make your first offer or first deal — or make a deliberate, dated decision to keep building capital and revisit in 90 days. Both are legitimate outcomes. What is not legitimate is drifting for 90 days with no decision and no record of what you did.

## 12.3 The habits that compound

- **Underwrite every week.** Ten deals a month on paper keeps your judgment sharp and your expectations honest.
- **Track your numbers.** Capital, hours spent, leads contacted, offers made, deals analyzed. What gets measured gets improved; what is guessed stays vague.
- **Grow the team before you need it.** An agent, a lender, a property manager, a contractor, an attorney, an insurance professional, a tax professional. You do not need all seven on day one, but you should know the name of each one before your first deal.
- **Review quarterly.** Every 90 days, re-score your strategy, update your buy box, and check your reserves. Strategies that fit in January may not fit in July, and that is fine — the review is what keeps you honest.
- **Keep learning, cheaply.** Local investor groups, library books, and reputable free content are the right next step after this course. An expensive advanced course is justified only when you can name the specific skill it will teach you that you need for your next deal.

## 12.4 A final word

Real estate investing rewards patience, arithmetic, and honesty more than boldness. The investors who last are not the ones who made the biggest first deal. They are the ones who chose a strategy that fit, underwrote the numbers without flinching, kept reserves for the bad month, and stayed in the game long enough for compounding to work. Your first 90 days are not about getting rich. They are about becoming the kind of investor who can be trusted — by sellers, by lenders, by tenants, and by yourself — with larger decisions later.

Start right. Choose the strategy that fits your capital, your time, and your goals. Then do the work, one week at a time.

---

## Appendix A — The Strategy Comparison at a Glance

| Strategy | Capital to start | Time per week | Speed to income | Main risk | Best first fit |
|---|---|---|---|---|---|
| Long-term rental | $25,000–$50,000+ | 1–3 hrs (managed) | 1–2 months | Vacancy, repairs | Patient, capital-ready |
| House hacking | $10,000–$25,000+ | 2–5 hrs | Immediate (lower housing cost) | Living with tenants | Buyers planning a move |
| Wholesaling | $500–$2,000/mo marketing | 10–20 hrs | 30–90 days | No buyer, legal rules | Time-rich, low capital |
| Fix-and-flip | $50,000+ (or financing) | 10–20 hrs | 3–9 months | Overruns, market drop | Skilled project managers |
| BRRRR | $50,000+ (or short-term financing) | 10–15 hrs | 6–12 months | Appraisal, refinance denial | Experienced investors |
| Short-term rental | $40,000+ plus $10,000–$25,000 furnishing | 5–15 hrs | 1–2 months | Regulation, seasonality | Owners in strong visitor markets |

*Capital figures are broad, illustrative ranges for a modest single-family deal in a typical mid-sized US market. Your market will differ. Always underwrite locally.*

---

*End of course manual. The companion workbook (`workbook.md`), strategy comparison guide (`templates/strategy-comparison-guide.md`), decision matrix (`templates/decision-matrix.csv`), glossary (`templates/glossary.md`), and 90-day action plan (`templates/90-day-action-plan.md`) are part of this product. This course is education only — not individualized investment, legal, tax, or financial advice. No returns or outcomes are guaranteed.*
