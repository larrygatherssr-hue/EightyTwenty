# The Real Estate Investing Foundations Academy — RE-07

**Price:** $297 one-time · **Category:** Real Estate · **SKU:** RE-07

*Start right — compare every strategy and pick the one that fits your capital, time, and goals.*

## Files in This Product

| File | Description |
|---|---|
| `content.md` | The complete 12-module course manual (14,227 words) — full prose chapters with worked examples using real numbers on one consistent example property, action steps at the end of every module, and a full education-only disclaimer |
| `workbook.md` | Companion workbook — capital/time/risk self-assessment, goals worksheet, strategy-fit quiz, strategy comparison worksheet, deal-analysis practice sheets, and 90-day action plan |
| `templates/strategy-comparison-guide.md` | Strategy comparison guide — all six strategies: capital, time, speed to income, income profile, risks, and best fit |
| `templates/decision-matrix.csv` | Decision matrix spreadsheet — scores all six strategies on capital, time, speed, risk, skill barrier, and wealth building |
| `templates/glossary.md` | Glossary of 120 real estate investing terms in plain English |
| `templates/90-day-action-plan.md` | Dated, week-by-week 90-day action plan: learn and measure, build and test, decide and act |
| `sales-page.md` | Full sales page — headline, problem, solution, 12-module contents, who it is for / not for, price and 14-day guarantee, 9 FAQs, and the education-only disclaimer |
| `listing.json` | Marketplace listing data (SKU, name, category, price in cents, headline, description, delivery note, SEO keywords, refund policy, support) |
| `cover.md` | Cover design brief — black-and-gold luxury branding, typography, imagery, and layout direction |
| `cover.png` | Generated product cover image (portrait, black-and-gold, city skyline and homes at dusk) |
| `onboarding.md` | Customer onboarding guide — what to do first, how to use each file, a suggested schedule, and how to get support |
| `README.md` | This file — index of the product's files |

## Key Facts

- **Worked example throughout:** one consistent example property ($185,000 purchase, $1,900/month rent, $275,000 ARV after a $40,000 renovation) analyzed as a rental ($188/month cash flow, 4.9% cash-on-cash, 7.3% cap rate, 1.20 DSCR), a flip ($19,750 profit before tax), a wholesale deal ($10,000 assignment fee), a BRRRR ($23,750 left in the deal — and a post-refinance rental that does not cash flow on those numbers), and a short-term rental ($423/month at 70% occupancy).
- **Disclaimer:** Education only — not individualized investment, legal, tax, or financial advice. Stated in `content.md`, `workbook.md`, and `sales-page.md`.
- **Guarantee:** 14-day money-back guarantee, full refund, no questions asked.
