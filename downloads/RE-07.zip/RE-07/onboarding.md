# Welcome — The Real Estate Investing Foundations Academy

## RE-07 · $297 one-time

Welcome, and congratulations on starting right. This academy was built for one purpose: to help you compare every major real estate investing strategy and choose the one that fits your capital, your time, and your goals — before you spend money on an advanced course for the wrong strategy.

---

## What you received

| File | What it is |
|---|---|
| `content.md` | The complete 12-module course manual — full prose chapters with worked examples using real numbers, action steps at the end of every module, and a full education-only disclaimer |
| `workbook.md` | Companion workbook — capital/time/risk self-assessment, goals worksheet, strategy-fit quiz, strategy comparison worksheet, deal-analysis practice sheets, and a 90-day action plan |
| `templates/strategy-comparison-guide.md` | Every strategy on one page: capital, time, speed to income, income profile, risks, and best fit |
| `templates/decision-matrix.csv` | Decision matrix spreadsheet — score all six strategies on capital, time, speed, risk, skill barrier, and wealth building |
| `templates/glossary.md` | Glossary of 120 real estate investing terms in plain English |
| `templates/90-day-action-plan.md` | Dated, week-by-week 90-day plan: learn and measure, build and test, decide and act |
| `sales-page.md` | The full sales page for this product (for your reference) |
| `listing.json` | Marketplace listing data |
| `cover.md` / `cover.png` | Cover design brief and generated product cover |
| `README.md` | Index of this product's files |

---

## What to do first

### Day 1 — Read the disclaimer and Module 1
Read the disclaimer at the top of `content.md` first. This course is education only — not individualized investment, legal, tax, or financial advice. Then read Module 1, which explains how real estate investing actually works and the five mistakes beginners make.

### Days 1–7 — Know your starting position
Read Module 2 and complete Workbook Sections 1 and 2: the capital / time / risk self-assessment and the goals worksheet. Write real numbers, not wishes. Check your credit reports. Write your buy box (Workbook Section 8). Open or designate a separate reserves account.

### Weeks 2–4 — Learn the strategies and choose
Read Modules 3 through 8 — one module per strategy — and score each one in the Strategy-Fit Quiz (Workbook Section 3). Read Modules 9, 10, and 11 before you look at any real deal. Underwrite ten deals on paper using the deal-analysis practice sheets. Finish with Module 12 and the 90-day action plan.

---

## How to use the materials

- **Course manual (`content.md`):** Read it in order the first time. Each module ends with action steps — do them before moving on. The worked examples all use the same example property ($185,000 purchase, $1,900 rent, $275,000 after-repair value) so you can compare strategies fairly.
- **Workbook (`workbook.md`):** Keep it open beside the manual. Its value is in your written answers, not in reading it. Re-read your answers at day 90.
- **Decision matrix (`templates/decision-matrix.csv`):** Open it in any spreadsheet program. The scores in it are starting points from the course — replace them with your own scores from the workbook quiz.
- **Glossary (`templates/glossary.md`):** Use it whenever a term is unfamiliar. If a word appears in a module that you do not understand, look it up before continuing.
- **90-day action plan (`templates/90-day-action-plan.md`):** This is your working document for the first 90 days. Print it, check off each step, and do a short weekly review.

## Suggested schedule

| Period | Focus | Key output |
|---|---|---|
| Days 1–7 | Modules 1–2, workbook Sections 1–2 | Real capital, time, and risk numbers; written goal; buy box |
| Days 8–21 | Modules 3–8, strategy-fit quiz | Scored strategies; a chosen strategy for the next 90 days |
| Days 22–30 | Modules 9–11, 10 deals underwritten | Team contacts; financing picture; 10 paper underwritings |
| Days 31–60 | Build and test (see the 90-day plan) | Live pipeline; buyers list or viewing shortlist; 10 more deals |
| Days 61–90 | Stress-test and decide | A dated go / no-go decision on your best opportunity |

A realistic pace is 3–5 hours per week. If you can only give 2 hours a week, stretch the schedule — do not skip the workbook exercises.

## A note on the numbers

Every worked example in this course uses invented teaching numbers for one consistent example property. They are not predictions, appraisals, or promises about any real property. Your market will differ. Always verify rents, prices, rates, taxes, insurance, and repair costs locally, and consult licensed professionals before any transaction.

## How to get support

For help with your order or the course files, email the marketplace support address with your order number and a description of the issue, and the support team will respond. For questions about a specific property, financing, law, or tax, please consult a licensed professional in your area — the marketplace support team cannot give individualized investment, legal, or tax advice.

## Your 14-day guarantee

If you are not satisfied within 14 days of purchase, contact support with your order number for a full refund, no questions asked.

---

*Start right. Choose the strategy that fits — then do the work, one week at a time.*
