# PET-07 — The First 16 Weeks: Puppy Training Workbook & Training Guide

**Price:** $97 (one-time). **Category:** Pet Products & Pet Business.

**Format note:** this is a complete written workbook and training guide (not a video program). The catalog originally described this product as a "Video Program"; the delivered product is written only, and the sales page, listing, and delivery note all state this plainly.

## Files

| File | What it is |
|---|---|
| `content.md` | The full written training guide — foundations, week-by-week program for weeks 8–16, troubleshooting appendix, daily schedule examples, socialisation master list, and next steps. 13,749 words. |
| `workbook.md` | Companion workbook — weekly worksheets for weeks 8–16 (goals, daily schedule, socialisation checklist, house-training log, biting diary, progress tracker, notes), plus graduation checklist and progress summary. |
| `templates/daily-training-schedule.md` | Printable daily training schedule with worked example days for a 10-week-old and a 15-week-old puppy. |
| `templates/socialisation-checklist.md` | Full socialisation exposure checklist (people, sounds, surfaces, places, animals, handling, objects) with a reaction rating key. |
| `templates/progress-tracker.csv` | Week-by-week skill rating sheet for every cue and milestone, weeks 8–16. |
| `templates/house-training-log.csv` | House-training log for toilet trips, successes, and accidents, with example rows showing the format. |
| `sales-page.md` | Full sales page — headline, problem, solution, week-by-week contents, who it is for / not for, $97 price with 14-day guarantee, 10-question FAQ, and disclaimers. |
| `listing.json` | Marketplace listing data (SKU PET-07, price_cents 9700, one-time billing). |
| `cover.md` | Cover design brief — black-and-gold luxury, title, subtitle, palette, typography, imagery, and layout. |
| `cover.png` | Cover image, portrait 1280 × 1920 px, black-and-gold. |
| `onboarding.md` | Customer onboarding guide — what to do first, how to use the materials, suggested schedule, and support. |
| `README.md` | This index. |

## Methods and Safety

All training methods use positive reinforcement only — no punishment-based or aversive advice. The guide, workbook, and sales page all state clearly that the program never replaces veterinary care or a qualified veterinary behaviorist.
