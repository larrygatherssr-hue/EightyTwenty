# The First 16 Weeks — Companion Workbook

**A complete written workbook and training guide (not a video program).** This workbook is the companion to *The First 16 Weeks: Puppy Training Workbook & Training Guide*. Use it alongside the guide, one week at a time.

---

## Important Disclaimer — Please Read First

This workbook is for general education only. It is not veterinary advice, and it never replaces veterinary care or the help of a qualified veterinary behaviorist. If your puppy shows signs of illness, pain, fear that does not improve, aggression, or any behavior that worries you, contact your veterinarian promptly.

All training methods in this program use positive reinforcement only: rewarding the behavior you want, managing the environment so mistakes are less likely, and redirecting unwanted behavior to something better. This workbook contains no punishment-based or aversive methods.

---

## How to Use This Workbook

Print the pages you need, or copy them into a notebook. Each week has a worksheet with the same layout:

1. **Week goals** — tick them off as you achieve them.
2. **Daily training schedule** — plan the day, then record what actually happened.
3. **Socialisation checklist** — record each new exposure and your puppy's reaction.
4. **House-training log** — record every toilet trip, success, and accident.
5. **Biting diary** — record biting incidents and what came before them.
6. **Progress tracker** — rate each skill at the end of the week.
7. **Notes** — what worked, what did not, and what to try next week.

Fill it in daily if you can; even five minutes at the end of the day is enough. The records are what turn guesswork into progress. When you can see that accidents cluster twenty minutes after meals, or that biting spikes at 6 p.m. when your puppy is overtired, you can fix the cause instead of reacting to the symptom.

### Rating Key

Use this key in the progress tracker and the socialisation checklist:

- **R — Relaxed:** loose body, soft eyes, tail at a natural height, happy to engage.
- **C — Cautious:** noticed the new thing, a little unsure, but coped and recovered quickly.
- **W — Worried:** froze, tucked its tail, flattened its ears, tried to move away, or would not take treats. Go slower next time and increase the distance.

For skills, use:

- **0 — Not started**
- **1 — Learning:** your puppy is beginning to understand, with a lure or help.
- **2 — Improving:** your puppy does it most of the time with a cue, in a familiar place.
- **3 — Reliable:** your puppy does it in different places, with mild distractions.

---

## My Puppy's Details

| Item | Details |
|---|---|
| Puppy's name | |
| Breed / mix | |
| Date of birth | |
| Date brought home | |
| Age on arrival (weeks) | |
| Veterinarian name and phone | |
| Emergency vet phone | |
| Food brand and amount per meal | |
| Feeding times | |
| Toilet spot | |
| Crate location | |

---

## Weekly Worksheet — Week 8 (Orientation Week)

### Goals

- [ ] Puppy knows the toilet spot, sleeping place, and water bowl.
- [ ] Feeding and toilet schedule in place and followed.
- [ ] Crate introduced with the door open; puppy enters willingly for treats.
- [ ] Puppy responds to its name some of the time.
- [ ] First gentle socialisation exposures recorded.

### Daily Training Schedule

| Time | Activity | Done? | Notes |
|---|---|---|---|
| 7:00 | Wake, toilet trip, breakfast | | |
| 7:30 | Play and name practice (2 min) | | |
| 8:00 | Nap | | |
| 10:00 | Toilet, play, socialisation exposure | | |
| 10:30 | Nap | | |
| 12:00 | Lunch, toilet, garden play | | |
| 12:30 | Nap | | |
| 14:30 | Toilet, training (sit), chew time | | |
| 15:00 | Nap | | |
| 17:00 | Dinner, toilet, short garden time | | |
| 17:30 | Play, socialisation exposure | | |
| 18:30 | Frozen food toy, calm settle | | |
| 19:30 | Last toilet trip, wind down | | |
| 21:00 | Bedtime in crate | | |
| Night | Night toilet trip if needed | | |

### Socialisation Checklist — Week 8

| Exposure | Date | Reaction (R / C / W) | Notes |
|---|---|---|---|
| Vacuum cleaner from another room | | | |
| Washing machine running | | | |
| Doorbell | | | |
| Different family member | | | |
| Grass underfoot | | | |
| Hard floor underfoot | | | |
| Being picked up and held briefly | | | |
| Hairdryer from a distance | | | |
| | | | |
| | | | |

### House-Training Log — Week 8

Record every toilet trip. Use S for a success outside, A for an accident inside.

| Day | Time | S / A | What happened just before | Notes |
|---|---|---|---|---|
| Mon | | | | |
| Mon | | | | |
| Tue | | | | |
| Tue | | | | |
| Wed | | | | |
| Thu | | | | |
| Fri | | | | |
| Sat | | | | |
| Sun | | | | |

### Biting Diary — Week 8

| Date | Time | What happened just before | How long it lasted | What you did | Notes |
|---|---|---|---|---|---|
| | | | | | |
| | | | | | |
| | | | | | |

### Progress Tracker — End of Week 8

| Skill | Rating (0–3) |
|---|---|
| Name recognition | |
| Sit | |
| Toileting outside | |
| Settling in crate (door open) | |
| Accepting handling (ears, paws) | |

### Notes — Week 8

What worked this week?

What was hardest?

What will I do differently next week?

---

## Weekly Worksheet — Week 9 (Routine Week)

### Goals

- [ ] Daily routine is consistent: same feeding, toilet, and nap times.
- [ ] Puppy is toileting outside more often than inside.
- [ ] Crate door closed for short periods while puppy chews happily.
- [ ] Puppy responds to its name most of the time indoors.
- [ ] Socialisation moves beyond the home: front garden, car, quiet street sounds.

### Daily Training Schedule

| Time | Activity | Done? | Notes |
|---|---|---|---|
| 7:00 | Wake, toilet trip, breakfast | | |
| 7:30 | Play and sit practice (3 min) | | |
| 8:00 | Nap | | |
| 10:00 | Toilet, play, socialisation exposure | | |
| 10:30 | Nap | | |
| 12:00 | Lunch, toilet, garden play | | |
| 12:30 | Nap | | |
| 14:30 | Toilet, training (down), chew time | | |
| 15:00 | Nap | | |
| 17:00 | Dinner, toilet, short garden time | | |
| 17:30 | Play, socialisation exposure | | |
| 18:30 | Frozen food toy, calm settle | | |
| 19:30 | Last toilet trip, wind down | | |
| 21:00 | Bedtime in crate | | |
| Night | Night toilet trip if needed | | |

### Socialisation Checklist — Week 9

| Exposure | Date | Reaction (R / C / W) | Notes |
|---|---|---|---|
| Sitting in the front garden watching the street | | | |
| Short car ride (5 minutes) | | | |
| Traffic sounds from a distance | | | |
| One calm visitor at home | | | |
| Doorbell and someone coming in | | | |
| New surface: gravel or doormat | | | |
| | | | |
| | | | |

### House-Training Log — Week 9

| Day | Time | S / A | What happened just before | Notes |
|---|---|---|---|---|
| Mon | | | | |
| Tue | | | | |
| Wed | | | | |
| Thu | | | | |
| Fri | | | | |
| Sat | | | | |
| Sun | | | | |

### Biting Diary — Week 9

| Date | Time | What happened just before | How long it lasted | What you did | Notes |
|---|---|---|---|---|---|
| | | | | | |
| | | | | | |
| | | | | | |

### Progress Tracker — End of Week 9

| Skill | Rating (0–3) |
|---|---|
| Name recognition | |
| Sit | |
| Down | |
| Toileting outside | |
| Settling in crate (door closed briefly) | |
| Accepting handling | |

### Notes — Week 9

What worked this week?

What was hardest?

What will I do differently next week?

---

## Weekly Worksheet — Week 10 (Confidence Week)

### Goals

- [ ] Puppy comfortable with crate door closed for a few minutes during the day.
- [ ] House-training accidents down to one or two a day.
- [ ] Several new people met and several new sounds heard, all paired with treats.
- [ ] Sit reliable indoors; down improving.
- [ ] Handling practice daily: ears, paws, mouth, tail.

### Daily Training Schedule

| Time | Activity | Done? | Notes |
|---|---|---|---|
| 7:00 | Wake, toilet trip, breakfast | | |
| 7:30 | Play and recall practice indoors (3 min) | | |
| 8:00 | Nap | | |
| 10:00 | Toilet, play, socialisation exposure | | |
| 10:30 | Nap | | |
| 12:00 | Lunch, toilet, garden play | | |
| 12:30 | Nap | | |
| 14:30 | Toilet, training (down), chew time | | |
| 15:00 | Nap | | |
| 17:00 | Dinner, toilet, short garden time | | |
| 17:30 | Play, socialisation exposure | | |
| 18:30 | Frozen food toy, calm settle | | |
| 19:30 | Last toilet trip, wind down | | |
| 21:00 | Bedtime in crate | | |
| Night | Night toilet trip if needed | | |

### Socialisation Checklist — Week 10

| Exposure | Date | Reaction (R / C / W) | Notes |
|---|---|---|---|
| Visit to a friend's house | | | |
| Hairdryer in the same room, low volume | | | |
| Person wearing a hat and sunglasses | | | |
| Person with a walking stick | | | |
| Bicycle passing at a distance | | | |
| Pushchair passing | | | |
| Children playing in a park, from a distance | | | |
| Walking on a wet pavement | | | |
| Ride in a lift | | | |
| | | | |

### House-Training Log — Week 10

| Day | Time | S / A | What happened just before | Notes |
|---|---|---|---|---|
| Mon | | | | |
| Tue | | | | |
| Wed | | | | |
| Thu | | | | |
| Fri | | | | |
| Sat | | | | |
| Sun | | | | |

### Biting Diary — Week 10

| Date | Time | What happened just before | How long it lasted | What you did | Notes |
|---|---|---|---|---|---|
| | | | | | |
| | | | | | |
| | | | | | |

### Progress Tracker — End of Week 10

| Skill | Rating (0–3) |
|---|---|
| Name recognition | |
| Sit | |
| Down | |
| Recall (indoors) | |
| Toileting outside | |
| Settling in crate (door closed, few minutes) | |
| Accepting handling | |

### Notes — Week 10

What worked this week?

What was hardest?

What will I do differently next week?

---

## Weekly Worksheet — Week 11 (Manners Week)

### Goals

- [ ] Puppy sits to say please: before meals, before the door opens, before play.
- [ ] Biting reducing; puppy starting to redirect to toys on its own.
- [ ] Puppy settles on a mat for a few seconds with treats.
- [ ] Socialisation includes a calm, vaccinated adult dog.
- [ ] Handling easy: ears, paws, and mouth accepted.

### Daily Training Schedule

| Time | Activity | Done? | Notes |
|---|---|---|---|
| 7:00 | Wake, toilet trip, breakfast (sit first) | | |
| 7:30 | Play and settle-on-mat practice (3 min) | | |
| 8:00 | Nap | | |
| 10:00 | Toilet, play, socialisation exposure | | |
| 10:30 | Nap | | |
| 12:00 | Lunch, toilet, garden play | | |
| 12:30 | Nap | | |
| 14:30 | Toilet, training (leave it), chew time | | |
| 15:00 | Nap | | |
| 17:00 | Dinner, toilet, short garden time | | |
| 17:30 | Play, socialisation exposure | | |
| 18:30 | Frozen food toy, calm settle | | |
| 19:30 | Last toilet trip, wind down | | |
| 21:00 | Bedtime in crate | | |

### Socialisation Checklist — Week 11

| Exposure | Date | Reaction (R / C / W) | Notes |
|---|---|---|---|
| Meeting a calm, vaccinated adult dog (5 min) | | | |
| Pet-friendly shop entrance | | | |
| Person in a uniform | | | |
| Person using a wheelchair or crutches | | | |
| Lawnmower at a distance | | | |
| Rain on a window | | | |
| Car ride with a treat at the end | | | |
| | | | |

### House-Training Log — Week 11

| Day | Time | S / A | What happened just before | Notes |
|---|---|---|---|---|
| Mon | | | | |
| Tue | | | | |
| Wed | | | | |
| Thu | | | | |
| Fri | | | | |
| Sat | | | | |
| Sun | | | | |

### Biting Diary — Week 11

| Date | Time | What happened just before | How long it lasted | What you did | Notes |
|---|---|---|---|---|---|
| | | | | | |
| | | | | | |
| | | | | | |

### Progress Tracker — End of Week 11

| Skill | Rating (0–3) |
|---|---|
| Sit (to say please) | |
| Down | |
| Recall (indoors) | |
| Leave it | |
| Settle on mat | |
| Toileting outside | |
| Settling in crate (10–15 min) | |

### Notes — Week 11

What worked this week?

What was hardest?

What will I do differently next week?

---

## Weekly Worksheet — Week 12 (The Vet Visit and the Wider World)

### Goals

- [ ] Second vaccination and vet check completed; visit went well.
- [ ] Puppy walks on a lead in the garden and on a quiet street.
- [ ] House-training accidents occasional, not daily.
- [ ] Puppy comfortable being handled by a stranger (the vet) with treats.
- [ ] Socialisation includes a busier environment, at a distance the puppy can cope with.

### Daily Training Schedule

| Time | Activity | Done? | Notes |
|---|---|---|---|
| 7:00 | Wake, toilet trip, breakfast (sit first) | | |
| 7:30 | Play and lead-walking practice in garden (5 min) | | |
| 8:00 | Nap | | |
| 10:00 | Toilet, play, socialisation exposure | | |
| 10:30 | Nap | | |
| 12:00 | Lunch, toilet, garden play and recall | | |
| 12:30 | Nap | | |
| 14:30 | Toilet, training (recall), chew time | | |
| 15:00 | Nap | | |
| 17:00 | Dinner, toilet, short lead walk | | |
| 17:30 | Play, socialisation exposure | | |
| 18:30 | Frozen food toy, calm settle | | |
| 19:30 | Last toilet trip, wind down | | |
| 21:00 | Bedtime in crate | | |

### Socialisation Checklist — Week 12

| Exposure | Date | Reaction (R / C / W) | Notes |
|---|---|---|---|
| Vet waiting room and examination | | | |
| Short lead walk on a quiet street | | | |
| Bus passing | | | |
| Pet shop visit | | | |
| Café garden | | | |
| Child playing at a distance | | | |
| New texture: sand or metal grate | | | |
| | | | |

### House-Training Log — Week 12

| Day | Time | S / A | What happened just before | Notes |
|---|---|---|---|---|
| Mon | | | | |
| Tue | | | | |
| Wed | | | | |
| Thu | | | | |
| Fri | | | | |
| Sat | | | | |
| Sun | | | | |

### Biting Diary — Week 12

| Date | Time | What happened just before | How long it lasted | What you did | Notes |
|---|---|---|---|---|---|
| | | | | | |
| | | | | | |
| | | | | | |

### Progress Tracker — End of Week 12

| Skill | Rating (0–3) |
|---|---|
| Sit | |
| Down | |
| Recall (garden) | |
| Leave it | |
| Settle on mat | |
| Lead walking (garden) | |
| Toileting outside | |
| Settling in crate (daytime naps) | |
| Accepting handling by a stranger | |

### Notes — Week 12

What worked this week?

What was hardest?

What will I do differently next week?

---

## Weekly Worksheet — Week 13 (Independence Week)

### Goals

- [ ] Puppy left alone in pen or crate for 15–30 minutes without distress.
- [ ] Puppy plays independently with a food toy for a few minutes.
- [ ] Sit, down, and recall working in the garden as well as indoors.
- [ ] Socialisation includes a new place: a friend's house or a quiet park.
- [ ] Puppy comfortable with grooming: short brush, paw touch, looking at teeth.

### Daily Training Schedule

| Time | Activity | Done? | Notes |
|---|---|---|---|
| 7:00 | Wake, toilet trip, breakfast (sit first) | | |
| 7:30 | Play and drop-it practice (3 min) | | |
| 8:00 | Nap | | |
| 10:00 | Toilet, short alone-time practice (5–10 min) | | |
| 10:30 | Nap | | |
| 12:00 | Lunch, toilet, garden play | | |
| 12:30 | Nap | | |
| 14:30 | Toilet, training (settle), chew time | | |
| 15:00 | Nap | | |
| 17:00 | Dinner, toilet, short lead walk | | |
| 17:30 | Play, socialisation exposure | | |
| 18:30 | Frozen food toy, calm settle | | |
| 19:30 | Last toilet trip, wind down | | |
| 21:00 | Bedtime in crate | | |

### Socialisation Checklist — Week 13

| Exposure | Date | Reaction (R / C / W) | Notes |
|---|---|---|---|
| Different house | | | |
| Quiet park (carried or on a blanket) | | | |
| Car journey of 10–15 minutes | | | |
| Person wearing a motorcycle helmet | | | |
| Person with an umbrella opening and closing | | | |
| Dog barking at a distance | | | |
| Handling by someone other than me | | | |
| | | | |

### House-Training Log — Week 13

| Day | Time | S / A | What happened just before | Notes |
|---|---|---|---|---|
| Mon | | | | |
| Tue | | | | |
| Wed | | | | |
| Thu | | | | |
| Fri | | | | |
| Sat | | | | |
| Sun | | | | |

### Biting Diary — Week 13

| Date | Time | What happened just before | How long it lasted | What you did | Notes |
|---|---|---|---|---|---|
| | | | | | |
| | | | | | |
| | | | | | |

### Alone-Time Log — Week 13

| Date | Duration alone | Puppy's reaction | Notes |
|---|---|---|---|
| | | | |
| | | | |
| | | | |

### Progress Tracker — End of Week 13

| Skill | Rating (0–3) |
|---|---|
| Sit | |
| Down | |
| Recall (garden) | |
| Leave it | |
| Drop it | |
| Settle on mat | |
| Lead walking | |
| Toileting outside | |
| Being alone (15–30 min) | |
| Accepting grooming | |

### Notes — Week 13

What worked this week?

What was hardest?

What will I do differently next week?

---

## Weekly Worksheet — Week 14 (Distraction Week)

### Goals

- [ ] Sit, down, and recall work in the garden with mild distractions.
- [ ] Puppy walks on a loose lead for a few minutes on a quiet street.
- [ ] Socialisation includes busier places, with treats and retreat available.
- [ ] Puppy comfortable with a short grooming session.
- [ ] Alone time reaches 30–45 minutes without distress.

### Daily Training Schedule

| Time | Activity | Done? | Notes |
|---|---|---|---|
| 7:00 | Wake, toilet trip, breakfast (sit first) | | |
| 7:30 | Play and cue practice with distractions (5 min) | | |
| 8:00 | Nap | | |
| 10:00 | Toilet, lead walk (10 min) | | |
| 10:30 | Nap | | |
| 12:00 | Lunch, toilet, garden play | | |
| 12:30 | Nap | | |
| 14:30 | Toilet, training, chew time | | |
| 15:00 | Nap | | |
| 17:00 | Dinner, toilet, short lead walk | | |
| 17:30 | Play, socialisation exposure | | |
| 18:30 | Frozen food toy, calm settle | | |
| 19:30 | Last toilet trip, wind down | | |
| 21:00 | Bedtime in crate | | |

### Socialisation Checklist — Week 14

| Exposure | Date | Reaction (R / C / W) | Notes |
|---|---|---|---|
| Busier street at a distance | | | |
| Market or shopping area from the edge | | | |
| Bus stop | | | |
| Playground at a distance | | | |
| Dog barking behind a fence | | | |
| Person jogging past | | | |
| Cyclist passing | | | |
| Different pet-friendly place | | | |
| | | | |

### House-Training Log — Week 14

| Day | Time | S / A | What happened just before | Notes |
|---|---|---|---|---|
| Mon | | | | |
| Tue | | | | |
| Wed | | | | |
| Thu | | | | |
| Fri | | | | |
| Sat | | | | |
| Sun | | | | |

### Biting Diary — Week 14

| Date | Time | What happened just before | How long it lasted | What you did | Notes |
|---|---|---|---|---|---|
| | | | | | |
| | | | | | |
| | | | | | |

### Alone-Time Log — Week 14

| Date | Duration alone | Puppy's reaction | Notes |
|---|---|---|---|
| | | | |
| | | | |
| | | | |

### Progress Tracker — End of Week 14

| Skill | Rating (0–3) |
|---|---|
| Sit (with distractions) | |
| Down (with distractions) | |
| Recall (garden, with distractions) | |
| Leave it | |
| Drop it | |
| Settle on mat | |
| Lead walking (quiet street) | |
| Toileting outside | |
| Being alone (30–45 min) | |
| Accepting grooming | |

### Notes — Week 14

What worked this week?

What was hardest?

What will I do differently next week?

---

## Weekly Worksheet — Week 15 (Reliability Week)

### Goals

- [ ] Puppy house trained in main living areas; accidents rare.
- [ ] Alone time reaches 45 minutes to an hour without distress.
- [ ] Recall works in the garden with distractions, on a long line.
- [ ] Puppy settles on its mat for several minutes while you eat or work.
- [ ] Socialisation list reviewed; gaps filled.

### Daily Training Schedule

| Time | Activity | Done? | Notes |
|---|---|---|---|
| 7:00 | Wake, toilet trip, breakfast (sit first) | | |
| 7:30 | Training: recall and leave it in garden (5 min) | | |
| 8:00 | Nap | | |
| 10:00 | Toilet, lead walk (15 min) | | |
| 10:30 | Scent game or food puzzle, then nap | | |
| 12:30 | Lunch, toilet, socialisation outing | | |
| 14:00 | Nap | | |
| 16:00 | Wake, toilet, training (settle, stay), play | | |
| 17:30 | Dinner, toilet, short walk | | |
| 18:30 | Calm settle on mat while family eats; frozen chew | | |
| 20:00 | Last play, toilet trip, wind down | | |
| 21:30 | Bedtime in crate | | |

### Socialisation Checklist — Week 15

| Exposure | Date | Reaction (R / C / W) | Notes |
|---|---|---|---|
| Man with a beard | | | |
| Person in a hat | | | |
| Wheelchair | | | |
| Pushchair | | | |
| Umbrella opening | | | |
| Different floor surface | | | |
| Livestock at a distance | | | |
| Thunder recording, low volume | | | |
| Fireworks recording, low volume | | | |
| Short stay at a friend's house | | | |
| Longer car journey | | | |
| Happy visit to the vet (treats and weigh-in) | | | |
| | | | |

### House-Training Log — Week 15

| Day | Time | S / A | What happened just before | Notes |
|---|---|---|---|---|
| Mon | | | | |
| Tue | | | | |
| Wed | | | | |
| Thu | | | | |
| Fri | | | | |
| Sat | | | | |
| Sun | | | | |

### Biting Diary — Week 15

| Date | Time | What happened just before | How long it lasted | What you did | Notes |
|---|---|---|---|---|---|
| | | | | | |
| | | | | | |
| | | | | | |

### Alone-Time Log — Week 15

| Date | Duration alone | Puppy's reaction | Notes |
|---|---|---|---|
| | | | |
| | | | |
| | | | |

### Progress Tracker — End of Week 15

| Skill | Rating (0–3) |
|---|---|
| Sit | |
| Down | |
| Stay | |
| Recall (garden, distractions) | |
| Leave it | |
| Drop it | |
| Settle on mat (several minutes) | |
| Lead walking | |
| Toileting outside | |
| Being alone (45–60 min) | |

### Notes — Week 15

What worked this week?

What was hardest?

What will I do differently next week?

---

## Weekly Worksheet — Week 16 (Graduation Week)

### Goals

- [ ] I can list what my puppy does reliably and what still needs work.
- [ ] Vaccinations complete (or final appointment booked).
- [ ] Daily routine runs smoothly: feeding, toileting, training, play, rest.
- [ ] Plan in place for the next eight weeks: puppy class, continued socialisation, adolescence.
- [ ] Puppy is a confident, friendly, well-rested young dog that trusts me.

### Daily Training Schedule

| Time | Activity | Done? | Notes |
|---|---|---|---|
| 7:00 | Wake, toilet trip, breakfast (sit first) | | |
| 7:30 | Training: cues in a new place (5 min) | | |
| 8:00 | Nap | | |
| 10:00 | Toilet, lead walk (20 min) | | |
| 10:30 | Scent game or food puzzle, then nap | | |
| 12:30 | Lunch, toilet, socialisation outing | | |
| 14:00 | Nap | | |
| 16:00 | Wake, toilet, training, play with a suitable dog | | |
| 17:30 | Dinner, toilet, short walk | | |
| 18:30 | Calm settle on mat while family eats; frozen chew | | |
| 20:00 | Last play, toilet trip, wind down | | |
| 21:30 | Bedtime in crate | | |

### Socialisation Checklist — Week 16

| Exposure | Date | Reaction (R / C / W) | Notes |
|---|---|---|---|
| Busier place, lead walk | | | |
| Puppy class or supervised puppy play | | | |
| Visit to a friend's house | | | |
| Meeting a wider range of dogs | | | |
| Any remaining gaps from the master list | | | |
| | | | |
| | | | |

### House-Training Log — Week 16

| Day | Time | S / A | What happened just before | Notes |
|---|---|---|---|---|
| Mon | | | | |
| Tue | | | | |
| Wed | | | | |
| Thu | | | | |
| Fri | | | | |
| Sat | | | | |
| Sun | | | | |

### Biting Diary — Week 16

| Date | Time | What happened just before | How long it lasted | What you did | Notes |
|---|---|---|---|---|---|
| | | | | | |
| | | | | | |
| | | | | | |

### Alone-Time Log — Week 16

| Date | Duration alone | Puppy's reaction | Notes |
|---|---|---|---|
| | | | |
| | | | |
| | | | |

### Progress Tracker — End of Week 16 (Graduation)

| Skill | Rating (0–3) |
|---|---|
| Name recognition | |
| Sit | |
| Down | |
| Stay | |
| Recall | |
| Leave it | |
| Drop it | |
| Settle on mat | |
| Lead walking | |
| Toileting outside | |
| Settling in crate | |
| Being alone | |
| Accepting handling | |

### Graduation Checklist

- [ ] My puppy toilets outside reliably in its main living areas.
- [ ] My puppy sleeps in its crate willingly.
- [ ] My puppy can be left alone for 45 minutes without distress.
- [ ] My puppy responds to its name, sits, lies down, and comes when called in the garden.
- [ ] My puppy accepts handling of ears, paws, and mouth.
- [ ] My puppy has met a wide range of people, sounds, surfaces, and places.
- [ ] My puppy walks on a loose lead for a few minutes.
- [ ] Biting is occasional and mostly directed at toys.
- [ ] I have a vet I trust and the vaccination schedule is complete or booked.
- [ ] I know what to do when things go wrong: go back a step, make it easier, and ask for help.

### My Plan for the Next Eight Weeks

Puppy class booked? (name, date):

Socialisation I still want to do:

Skills I want to strengthen:

Questions for my vet or trainer:

---

## The Socialisation Master Checklist

Tick each item when your puppy has experienced it calmly. Copy this page if you need more room.

**People:** baby, toddler, child, teenager, adult man, adult woman, older person, person with a beard, person wearing a hat, person wearing sunglasses, person in a uniform, person with a walking stick, person in a wheelchair, person carrying bags, person with an umbrella, jogger, cyclist, delivery driver.

**Sounds:** vacuum cleaner, washing machine, tumble dryer, hairdryer, doorbell, telephone ringing, television, radio, traffic, bus, siren at a distance, aeroplane overhead, thunder recording (low volume), fireworks recording (low volume), children playing, dog barking at a distance, lawnmower at a distance.

**Surfaces:** grass, wet grass, gravel, sand, wood floor, tiles, carpet, metal grate, wet pavement, mud, wobble board, low platform, ramp, stairs.

**Places:** vet waiting room, friend's house, pet-friendly café, pet shop, quiet street, busier street at a distance, park, car, lift, car park, market edge.

**Animals:** calm adult dog, puppy of a similar age, cat at a distance, horse at a distance, sheep or livestock at a distance, birds in a garden.

**Handling:** ears touched, paws touched, nails touched, teeth looked at, tail touched, belly touched, being picked up, wearing a harness, wearing a collar, being brushed, having a bath, being dried with a towel.

**Objects:** umbrella opening, pushchair, bicycle, skateboard at a distance, suitcase with wheels, bin lorry at a distance, balloons, mirrors, flapping tarpaulin.

---

## My Puppy's Progress Summary

| Week | Best moment | Hardest moment | Skill I am proudest of |
|---|---|---|---|
| 8 | | | |
| 9 | | | |
| 10 | | | |
| 11 | | | |
| 12 | | | |
| 13 | | | |
| 14 | | | |
| 15 | | | |
| 16 | | | |

---

*This workbook is for general education only and never replaces veterinary care or the advice of a qualified veterinary behaviorist. If your puppy is ill, in pain, or showing behavior that worries you, contact your veterinarian promptly. All methods in this program use positive reinforcement only.*
