# Socialisation Checklist — The First 16 Weeks

Tick each item when your puppy has experienced it calmly, and note the date and your puppy's reaction.

**Reaction key:** R = Relaxed (loose body, soft eyes, happy to engage). C = Cautious (noticed it, a little unsure, but coped and recovered quickly). W = Worried (froze, tucked its tail, flattened its ears, tried to move away, or would not take treats — go slower next time and increase the distance).

**How to use it:** Aim for a few exposures from different categories every week. Short and sweet wins: five minutes of a new experience, paired with treats, is plenty. Never force your puppy toward something frightening — let it observe from a distance where it is relaxed, reward calm observation, and let it approach in its own time. Until your veterinarian confirms vaccinations are complete, avoid places where many unknown dogs toilet, and carry your puppy or use a clean blanket in high-traffic areas. Watching the world from your arms counts fully.

## People

| Exposure | Date | Reaction (R / C / W) | Notes |
|---|---|---|---|
| Baby | | | |
| Toddler | | | |
| Child | | | |
| Teenager | | | |
| Adult man | | | |
| Adult woman | | | |
| Older person | | | |
| Person with a beard | | | |
| Person wearing a hat | | | |
| Person wearing sunglasses | | | |
| Person in a uniform | | | |
| Person with a walking stick | | | |
| Person in a wheelchair | | | |
| Person carrying bags | | | |
| Person with an umbrella | | | |
| Jogger | | | |
| Cyclist | | | |
| Delivery driver | | | |

## Sounds

| Exposure | Date | Reaction (R / C / W) | Notes |
|---|---|---|---|
| Vacuum cleaner | | | |
| Washing machine | | | |
| Tumble dryer | | | |
| Hairdryer | | | |
| Doorbell | | | |
| Telephone ringing | | | |
| Television | | | |
| Radio | | | |
| Traffic | | | |
| Bus | | | |
| Siren at a distance | | | |
| Aeroplane overhead | | | |
| Thunder recording (low volume) | | | |
| Fireworks recording (low volume) | | | |
| Children playing | | | |
| Dog barking at a distance | | | |
| Lawnmower at a distance | | | |

## Surfaces

| Exposure | Date | Reaction (R / C / W) | Notes |
|---|---|---|---|
| Grass | | | |
| Wet grass | | | |
| Gravel | | | |
| Sand | | | |
| Wood floor | | | |
| Tiles | | | |
| Carpet | | | |
| Metal grate | | | |
| Wet pavement | | | |
| Mud | | | |
| Wobble board | | | |
| Low platform | | | |
| Ramp | | | |
| Stairs | | | |

## Places

| Exposure | Date | Reaction (R / C / W) | Notes |
|---|---|---|---|
| Vet waiting room | | | |
| Friend's house | | | |
| Pet-friendly café | | | |
| Pet shop | | | |
| Quiet street | | | |
| Busier street at a distance | | | |
| Park | | | |
| Car | | | |
| Lift | | | |
| Car park | | | |
| Market edge | | | |

## Animals

| Exposure | Date | Reaction (R / C / W) | Notes |
|---|---|---|---|
| Calm adult dog | | | |
| Puppy of a similar age | | | |
| Cat at a distance | | | |
| Horse at a distance | | | |
| Sheep or livestock at a distance | | | |
| Birds in a garden | | | |

## Handling

| Exposure | Date | Reaction (R / C / W) | Notes |
|---|---|---|---|
| Ears touched | | | |
| Paws touched | | | |
| Nails touched | | | |
| Teeth looked at | | | |
| Tail touched | | | |
| Belly touched | | | |
| Being picked up | | | |
| Wearing a harness | | | |
| Wearing a collar | | | |
| Being brushed | | | |
| Having a bath | | | |
| Being dried with a towel | | | |

## Objects

| Exposure | Date | Reaction (R / C / W) | Notes |
|---|---|---|---|
| Umbrella opening | | | |
| Pushchair | | | |
| Bicycle | | | |
| Skateboard at a distance | | | |
| Suitcase with wheels | | | |
| Bin lorry at a distance | | | |
| Balloons | | | |
| Mirrors | | | |
| Flapping tarpaulin | | | |

## My Puppy's Gaps

Look at the unticked rows above. Which ones matter most for the life my puppy will live? Write them here and plan one or two a week:

1.
2.
3.
4.
5.
