# Daily Training Schedule — The First 16 Weeks

Print this page and fill it in each morning. Puppies need 14 to 20 hours of sleep a day depending on age, so sleep is most of the day. Fit training into the waking windows in short sessions of three to five minutes.

## Today's Date: _______________  Puppy's Age: ______ weeks

| Time | Activity | Done? | Notes |
|---|---|---|---|
| | Wake, toilet trip, breakfast (sit first) | | |
| | Play and training (3–5 min) | | |
| | Nap | | |
| | Wake, toilet trip, socialisation exposure | | |
| | Nap | | |
| | Lunch, toilet trip, garden play | | |
| | Nap | | |
| | Wake, toilet trip, training (3–5 min), chew time | | |
| | Nap | | |
| | Dinner, toilet trip, short lead walk or garden time | | |
| | Play, socialisation exposure | | |
| | Frozen food toy, calm settle on the mat | | |
| | Last toilet trip, wind down | | |
| | Bedtime in crate | | |
| Night | Night toilet trip if needed | | |

## Example Day at 10 Weeks

- **7:00** — Wake, straight outside to toilet, praise and treat. Breakfast in a bowl or a food toy.
- **7:30** — Short play and training: five minutes of sit and name practice. Toilet trip.
- **8:00** — Nap in crate or pen.
- **10:00** — Wake, toilet trip, short play, socialisation exposure (vacuum sound from another room, treats).
- **10:30** — Nap.
- **12:00** — Lunch, toilet trip, garden play and recall practice.
- **12:30** — Nap.
- **14:30** — Wake, toilet trip, training session (down), chew time.
- **15:00** — Nap.
- **17:00** — Dinner, toilet trip, short lead walk in the garden or quiet street.
- **17:30** — Play, socialisation exposure (visitor or new sound).
- **18:30** — Frozen food toy, calm settle on the mat.
- **19:30** — Last toilet trip, final short play, then wind down.
- **21:00** — Bedtime: toilet trip, crate beside your bed, small treat.
- **2:00 or 3:00** — Night toilet trip if needed.

## Example Day at 15 Weeks

- **7:00** — Wake, toilet trip, breakfast. Sit before the bowl goes down.
- **7:30** — Training: recall and leave it in the garden, five minutes. Toilet trip.
- **8:00** — Nap.
- **10:00** — Wake, toilet trip, lead walk (15 minutes) with loose-lead practice.
- **10:30** — Scent game or food puzzle, then nap.
- **12:30** — Lunch, toilet trip, socialisation outing (a new place or a friend's house).
- **14:00** — Nap.
- **16:00** — Wake, toilet trip, training (settle on the mat, stay), play with a suitable dog if available.
- **17:30** — Dinner, toilet trip, short walk.
- **18:30** — Calm settle on the mat while the family eats; frozen chew.
- **20:00** — Last play, toilet trip, wind down.
- **21:30** — Bedtime in the crate.

## Rules That Make the Schedule Work

1. **Toilet first, always.** Every waking window starts with a toilet trip.
2. **Short training, often.** Three to five minutes, three to five times a day, beats one long session.
3. **Nap after every play and training session.** A tired puppy cannot learn, and an overtired puppy bites.
4. **One or two new things a day, maximum.** Socialisation is quality, not quantity.
5. **If the day falls apart, keep the meals, the toilet trips, and the sleep.** Everything else can wait until tomorrow.
