# Onboarding Guide — The First 16 Weeks

Welcome, and congratulations on your new puppy. This guide tells you what to do first, how to use the materials in this product, and how to follow the program week by week.

**Please note the format:** this is a complete written workbook and training guide (not a video program). You receive written chapters, worksheets, schedules, checklists, and trackers as downloadable files. There are no video lessons included.

---

## What You Received

| File | What it is |
|---|---|
| `content.md` | The full written training guide — foundations, the week-by-week program for weeks 8–16, troubleshooting, schedules, and the socialisation master list. |
| `workbook.md` | The companion workbook — weekly worksheets for weeks 8–16 with goals, schedules, checklists, logs, and progress trackers. |
| `templates/daily-training-schedule.md` | A printable daily planner with worked example days. |
| `templates/socialisation-checklist.md` | The full socialisation exposure checklist with a reaction rating key. |
| `templates/progress-tracker.csv` | A week-by-week skill rating sheet (open in any spreadsheet app). |
| `templates/house-training-log.csv` | A ready-to-use house-training log with example rows showing the format. |
| `sales-page.md` | The full sales page for this product. |
| `cover.png` | The product cover image (portrait, 1280 × 1920). |
| `cover.md` | The cover design brief. |
| `onboarding.md` | This guide. |
| `listing.json` | The marketplace listing data. |
| `README.md` | An index of the product's files. |

---

## What to Do First

### 1. Read the foundations (30 minutes)

Before your puppy arrives — or tonight, if it already has — read these chapters in `content.md`:

- Chapter 1, How to Use This Guide.
- Chapter 2, Before Your Puppy Comes Home — Setup and Supplies.
- Chapter 3, The First 48 Hours — Settling In.
- Chapter 4, Foundations of Positive Reinforcement.
- Chapter 5, House Training, Step by Step.
- Chapter 6, Crate Training, Step by Step.
- Chapter 7, Biting and Mouthing.
- Chapter 8, Socialisation — The Window That Matters Most.
- Chapter 9, Basic Cues.

These chapters give you the whole method. The week chapters then tell you what to do with it, week by week.

### 2. Set up the space

Follow Chapter 2: choose the puppy's area, set up the crate with the door open, put out water, chews, and a toilet route, and puppy-proof the room. Agree the household rules with everyone who lives with the puppy — same cue words, same toilet spot, same response to biting — and put them on the fridge.

### 3. Print this week's worksheet

Open `workbook.md`, find the worksheet for your puppy's current week, and print it (or copy it into a notebook). Print the daily training schedule from `templates/daily-training-schedule.md` and the socialisation checklist from `templates/socialisation-checklist.md`. Open the progress tracker and house-training log CSVs in your spreadsheet app.

### 4. Start at the right week

If your puppy is 8 weeks old, start at Week 8. If it is 9, 10, or older, start at the week matching its age and work forward. Do not try to cram missed weeks into a few days.

---

## How to Use the Materials Each Week

1. **Sunday evening (or the night before the week starts):** read the coming week's chapter in `content.md`. Note the goals, the socialisation exposures, and the cue to practise.
2. **Each morning:** fill in the daily training schedule. Plan the day's meals, toilet trips, naps, training sessions, and one or two socialisation exposures.
3. **During the day:** run short training sessions of three to five minutes, three to five times a day. Reward good behavior the moment it happens. Log toilet trips, successes, and accidents in the house-training log. Record biting incidents in the biting diary.
4. **Each evening:** tick off the socialisation exposures you completed, note your puppy's reaction, and jot down what worked and what did not.
5. **End of the week:** rate each skill in the progress tracker, tick off the week's goals, and write your notes for next week.

---

## Suggested Schedule

A typical day looks like this (adjust times to your household):

- **Morning:** wake, toilet trip, breakfast (sit first), short training session, nap.
- **Late morning:** wake, toilet trip, play and one socialisation exposure, nap.
- **Midday:** lunch, toilet trip, garden play, nap.
- **Afternoon:** wake, toilet trip, training session and chew time, nap.
- **Evening:** dinner, toilet trip, short lead walk or garden time, play, frozen food toy, calm settle.
- **Night:** last toilet trip, bedtime in the crate, and a night toilet trip if needed.

Puppies need 14 to 20 hours of sleep a day depending on age. Sleep is not wasted time — it is when learning consolidates. If your puppy is wild and bitey, it is almost certainly overtired. Enforce naps.

---

## The Three Rules

1. **Reward what you like, the moment it happens.** Carry treats in a pocket at home for the first month.
2. **Manage the environment so the right choice is the easy choice.** Gates, a crate, and a playpen stop your puppy rehearsing mistakes while it is still learning.
3. **When in doubt, the puppy needs the toilet, a nap, or a calmer moment.** Most "bad behavior" in a young puppy is one of those three things in disguise.

---

## When Things Go Wrong

Go back to the troubleshooting appendix in Chapter 19 of `content.md`. The most common fixes are: go back to the week-eight toilet schedule for three days, make training easier, increase distance from something frightening, and give the puppy more sleep. Regression is normal — it is your puppy telling you it needs support, not a sign of failure.

---

## Safety — Please Read

This program is for general education only. It never replaces veterinary care or the help of a qualified veterinary behaviorist. If your puppy shows signs of illness, pain, fear that does not improve, aggression, or any behavior that worries you, contact your veterinarian promptly.

All methods in this program use positive reinforcement only. There are no punishment-based or aversive methods.

---

## How to Get Support

For questions about the training materials, your download, or a refund request, contact EightyTwenty marketplace support and include your order number, the product SKU (PET-07), and a description of your question. Please allow up to 2 business days for a reply. Support covers the training materials and delivery; it does not include veterinary advice or one-to-one dog training. If your puppy is ill, in pain, or showing behavior that worries you, contact your veterinarian promptly.
