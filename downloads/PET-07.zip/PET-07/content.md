# The First 16 Weeks: Puppy Training Workbook & Training Guide

**A complete written workbook and training guide (not a video program).** This guide is a written, week-by-week puppy training program. It contains no video lessons. Everything you need is in the written chapters, worksheets, schedules, and checklists that come with it.

---

## Important Disclaimer — Please Read First

This guide is for general education only. It is not veterinary advice, and it never replaces veterinary care or the help of a qualified veterinary behaviorist. If your puppy shows signs of illness, pain, fear that does not improve, aggression, or any behavior that worries you, contact your veterinarian promptly. A veterinarian can rule out medical causes and, if needed, refer you to a certified veterinary behaviorist or a qualified force-free trainer in your area.

All training methods in this guide use positive reinforcement only: rewarding the behavior you want, managing the environment so mistakes are less likely, and redirecting unwanted behavior to something better. This guide contains no punishment-based or aversive methods — no leash corrections, no alpha rolls, no spray bottles, no shouting, no physical punishment, and no shock, choke, or prong collars. Those methods can damage trust, increase fear, and make biting and anxiety worse. If anyone advises you to use them, disregard that advice.

Puppies are individuals. Timelines in this guide are typical ranges, not deadlines. A puppy that takes an extra week to master a skill is not behind; it is learning at its own pace. Never compare your puppy to another dog and never rush the process.

---

## Table of Contents

1. How to Use This Guide
2. Before Your Puppy Comes Home — Setup and Supplies
3. The First 48 Hours — Settling In
4. Foundations of Positive Reinforcement
5. House Training, Step by Step
6. Crate Training, Step by Step
7. Biting and Mouthing — What Is Normal and What to Do
8. Socialisation — The Window That Matters Most
9. Basic Cues — Sit, Down, Come, Name, Leave It, Drop It, Settle
10. Week 8 — Orientation Week
11. Week 9 — Routine Week
12. Week 10 — Confidence Week
13. Week 11 — Manners Week
14. Week 12 — The Vet Visit and the Wider World
15. Week 13 — Independence Week
16. Week 14 — Distraction Week
17. Week 15 — Reliability Week
18. Week 16 — Graduation Week and the Road Ahead
19. Troubleshooting Appendix — Common Problems, Solved Calmly
20. Daily Schedule Templates and Worked Examples
21. The Socialisation Master List
22. What Comes Next After Week 16

---

## 1. How to Use This Guide

This program covers the nine weeks from your puppy's eighth week of life to the end of its sixteenth week. If you bring your puppy home at eight weeks, Week 8 is your first week together. If your puppy comes home at nine or ten weeks, start at the week that matches your puppy's age and work forward; do not try to cram missed weeks into a few days.

Read the foundations chapters (Chapters 2 through 9) before your puppy arrives if you can. Then follow one week chapter at a time. Each week chapter has the same structure so you always know where to look:

- **Goals for the week** — what you are aiming for, in plain language.
- **House training** — what to practise and what progress to expect.
- **Crate training** — the next step in the crate progression.
- **Biting and mouthing** — what is normal this week and how to respond.
- **Socialisation exposures** — the sounds, surfaces, people, and places to introduce.
- **Basic cues** — the cue to teach or strengthen this week.
- **Play and rest** — how much of each, and how to balance them.
- **Common problems** — the difficulties most owners meet this week and how to handle them.

You do not need long training sessions. Puppies learn best in short bursts: three to five minutes, three to five times a day, woven into ordinary life. A five-minute session before a meal, a two-minute practice while you wait for the kettle, and a short game after a nap will teach your puppy far more than one long session ever will. End every session while your puppy is still keen, not after it has lost interest.

Keep the companion workbook beside this guide. Each week has a worksheet. Fill in the daily schedule, tick off socialisation exposures, log toilet successes and accidents, and note biting incidents. The records matter: they show you patterns you would otherwise miss, such as the fact that accidents cluster twenty minutes after meals, or that biting spikes when your puppy is overtired. When you can see the pattern, you can fix the cause instead of reacting to the symptom.

A note on language: this guide uses "cue" instead of "command." A cue is a signal that tells your puppy what behavior earns a reward. It is an invitation, not an order. That distinction shapes everything that follows.

### The Three Rules That Carry the Whole Program

1. **Reward what you like, the moment it happens.** A treat delivered within two seconds of a behavior teaches faster than a treat delivered ten seconds later. Carry treats in a pocket or a pouch at home for the first month.
2. **Manage the environment so the right choice is the easy choice.** Baby gates, a crate, a playpen, and a lead indoors are not punishments. They are tools that stop your puppy rehearsing mistakes while it is still learning.
3. **When in doubt, the puppy needs the toilet, a nap, or a calmer moment.** Most "bad behavior" in a young puppy is one of those three things in disguise.

---

## 2. Before Your Puppy Comes Home — Setup and Supplies

Preparation done before arrival day saves you from improvising while a small, frightened animal is crying in your kitchen. Set up the space first, then bring the puppy into it.

### The Puppy's Area

Choose one room, or part of a room, as the puppy's base. A kitchen or utility room with a hard floor is ideal because accidents are easy to clean. Block it off with a baby gate or a puppy playpen. Inside the area, place:

- A crate, with the door open, lined with a washable blanket.
- A water bowl, heavy enough not to tip, refreshed twice a day.
- A few safe chew toys of different textures.
- A toilet area: either direct access to the garden through a door, or puppy pads near the exit if you live in a flat.

The puppy's area is not a prison. It is a nursery. Your puppy should spend time there when you cannot supervise, and come out for supervised play, training, and cuddles. A puppy that is never left alone in its area will not learn to settle there; a puppy that is left there all day will not learn anything at all.

### Supplies Checklist

- **Food:** the same food your puppy's breeder or rescue was feeding, enough for at least two weeks. Change foods gradually over seven days if you switch, mixing increasing amounts of the new food into the old.
- **Treats:** small, soft, pea-sized treats your puppy can swallow in one second. You will use dozens a day. Keep a jar by the back door and a pouch in your pocket.
- **Crate:** sized so your puppy can stand, turn around, and lie down stretched out, but not so large that it can toilet in one corner and sleep in the other. Use a divider if the crate is sized for an adult dog.
- **Lead and harness:** a light, flat lead and a well-fitting harness. Avoid retractable leads for training; they teach pulling.
- **Collar and ID tag:** with your phone number. Your puppy should wear it whenever it is awake and supervised.
- **Bowls:** one for food, one for water, both heavy and non-tip.
- **Enzyme cleaner:** an enzymatic cleaner made for pet urine. Ordinary cleaners leave a scent your puppy can still detect, which invites repeat accidents in the same spot.
- **Chews:** a frozen stuffed Kong or similar food toy, a puppy teething ring, and a safe rubber chew. Rotate them so they stay interesting.
- **Grooming basics:** a soft brush, puppy shampoo, nail clippers or a file, and a toothbrush and dog toothpaste for later weeks.
- **Playpen or baby gates:** to manage space.
- **A blanket that smells of the litter:** ask the breeder or rescue for one. Familiar scent is the single most comforting thing you can provide on the first night.

### Puppy-Proofing

Get down on your hands and knees at puppy height and look around. Remove or secure: electrical cables, phone chargers, medicines, cleaning products, houseplants (many are toxic to dogs — check each one), shoes, children's small toys, coins, and anything with stuffing your puppy could swallow. Block gaps behind furniture. If you have stairs, fit a gate at the top and bottom until your puppy is older and coordinated.

### The Household Meeting

Before arrival day, agree as a household on the rules, and write them down. Everyone must use the same cue words, the same toilet spot, and the same response to biting. A puppy that hears "down" from one person and "off" from another, or is allowed on the sofa by one person and scolded for it by another, is not being naughty. It is being confused. Decide: where does the puppy sleep? Where does it toilet? Is it allowed on furniture? Who feeds it, and when? Put the answers on the fridge.

---

## 3. The First 48 Hours — Settling In

Your puppy has just left everything it has ever known: its mother, its littermates, and the only home it has had. Expect crying, clinginess, a poor appetite for a day, and a wobbly toilet routine. All of this is normal. Your job in the first 48 hours is not training. It is comfort, safety, and the beginning of a routine.

**Arrival.** Bring your puppy straight to the toilet spot when you arrive home. Wait quietly. If it toilets, praise gently and give a treat. Then carry or lead it into its area. Let it explore for a few minutes, then offer water and a small meal if it is mealtime. Keep the first day quiet: no visitors, no trips out, no baths, no training sessions. Let the puppy sleep as much as it wants. Puppies of eight weeks sleep 18 to 20 hours a day, and sleep is when learning consolidates.

**The first night.** Place the crate beside your bed for the first week. Your puppy can hear you breathe, and you can hear it stir. When it wakes and whimpers in the night, take it straight outside to the toilet spot, wait without playing, then return it to the crate with a small treat. Do not turn on bright lights or start a game at 3 a.m.; night-time toilet trips are business trips, not social visits. Most puppies need one or two night trips in the first two weeks. This phase passes.

If your puppy cries in the crate, do not ignore it completely on the first nights, and do not take it into your bed as a permanent solution unless that is your long-term plan. Instead, sit beside the crate with your hand near the door until the puppy settles, then gradually move your hand away over successive nights. A ticking clock wrapped in a blanket, or a warm water bottle wrapped in a towel, can mimic littermate warmth. Never use a hot water bottle unwrapped, and never leave an electric heat pad in the crate.

**Feeding.** Feed three to four small meals a day at set times. A regular feeding schedule produces a regular toilet schedule, which makes house training far easier. Pick the food up after fifteen minutes if it is uneaten; do not leave food down all day. Fresh water should always be available except that you may lift the water bowl an hour before bedtime in the first weeks to reduce night waking — but never restrict water during the day, and never restrict water for a puppy that is ill or on a hot day.

---

## 4. Foundations of Positive Reinforcement

Positive reinforcement means adding something your puppy wants — usually a treat, sometimes a game, a cuddle, or the chance to go outside — immediately after a behavior you want to see again. It is the most effective and most humane way to train a dog, and it is the only method used in this guide.

### How It Works in Practice

When your puppy sits on its own, say "yes" and give a treat. You have just taught it that sitting pays. When your puppy looks at you, mark and reward. When it toilets outside, celebrate quietly and reward. You are not bribing your puppy; you are paying it for work, the same way an employer pays a wage. Over time, as behaviors become habits, you can reward less often, but never stop rewarding entirely. Even adult dogs deserve a wage.

### The Marker Word

Choose a marker word — "yes" is the most common — and use it the same way every time: the instant the behavior happens, say "yes" in a bright tone, then deliver the treat within two seconds. The marker word is a camera shutter: it captures the exact moment your puppy did the right thing. Practise without your puppy first: say "yes" and reach for a treat until the two feel like one motion.

Some trainers use a clicker instead of a word. A clicker works well because its sound is precise and consistent, but it is one more thing to hold. Either is fine. Pick one and be consistent.

### Treat Delivery

Deliver the treat where you want the behavior to happen again. If you are rewarding a sit, deliver the treat at your puppy's nose height while it is still sitting, not after it has jumped up. If you are rewarding calm settling on a mat, place the treat on the mat between its paws. Where the treat lands is where the puppy will go next time.

Keep treats small. A pea-sized piece of soft food is enough. You will deliver dozens a day in the early weeks, so cut treats up and subtract them from your puppy's daily food allowance if your vet advises it. Use part of the daily kibble ration as training treats where possible, and save high-value treats — small pieces of cooked chicken, cheese, or commercial training treats — for difficult tasks like recall and socialisation.

### What to Do Instead of Punishing

Punishment after the event teaches your puppy nothing except to fear you. A puppy that is scolded for an accident it had ten minutes ago does not connect the scolding to the accident; it connects it to your presence. It learns to hide from you to toilet, which makes house training harder, not easier.

When your puppy does something you do not want, use one of these instead:

- **Prevent it.** Manage the environment so it cannot happen.
- **Interrupt gently.** A calm "oops" or a hand clap, then redirect to the right behavior.
- **Redirect.** Offer a chew toy when it mouths your hand; ask for a sit when it jumps.
- **Reward the alternative.** A puppy cannot jump up and sit at the same time. Reward the sit.

If you feel frustrated, step away. Put the puppy safely in its pen with a chew, make a cup of tea, and come back calm. Training done in anger is training undone.

### The Five-Second Rule for Timing

If you cannot reward within a few seconds of the behavior, the moment is lost. Do not chase your puppy with a treat after the fact. Just wait for the next opportunity and be ready for it. Puppies offer good behavior constantly — a glance at you, four paws on the floor, a quiet moment on the mat. Catching those moments is the whole job.

### Handling and Consent

From the first week, touch your puppy gently all over, for a few seconds at a time, and pair each touch with a treat: ears, paws, belly, tail, mouth. This is not just cuddling; it is preparation for vet visits, grooming, and nail trims for the rest of your dog's life. If your puppy pulls away, let it, and try again more briefly with a better treat. Never hold a puppy down to "get it used to it." Consent and patience build trust; force destroys it.

---

## 5. House Training, Step by Step

House training is not about teaching your puppy that toileting indoors is wrong. It is about teaching your puppy that toileting outdoors is rewarding, and about giving it enough opportunities to succeed that the habit forms. Most puppies are reliably house trained between four and six months of age. That is the normal range. Expect accidents until then, and treat them as information, not failure.

### The Schedule Is Everything

A young puppy needs to toilet: first thing in the morning, after every meal, after every nap, after every play session, after excitement, and every one to two hours in between. Write the schedule on the workbook's house-training log and follow it even when it feels excessive. The puppies that are house trained fastest are the ones whose owners took them out most often.

Take your puppy to the same spot every time, on a lead. Stand still and quiet. Do not play, do not walk around, and do not talk much. Give it up to five minutes. The moment it starts to toilet, say your toilet cue softly — "go toilet" or "be quick" — so the words become associated with the act. When it finishes, praise warmly and give a treat immediately, right there in the toilet spot. Then you can play.

If nothing happens in five minutes, bring the puppy back inside, keep it in your sight or in its pen, and try again in fifteen minutes. Do not give it freedom to wander the house after an unsuccessful trip; that is when accidents happen.

### Reading the Signs

Learn your puppy's pre-toilet signals: circling, sniffing the floor intensely, squatting, walking to a door, whining, or suddenly disengaging from play. The moment you see one, move calmly and quickly to the door. Do not shout or run at the puppy; sudden movement can startle it into toileting on the spot.

### When an Accident Happens

Stay calm. If you catch your puppy in the act, say "oops" gently, pick it up or lead it outside to the toilet spot, and reward if it finishes there. If you find an accident after the fact, say nothing, clean it with enzymatic cleaner, and review your schedule: the puppy was unsupervised for too long, or it needed a trip you did not offer. Never rub a puppy's nose in a mess, never shout, and never punish. It does not work and it damages trust.

### Night Training

Most eight-week-old puppies cannot hold their bladder all night. Expect one or two night trips for the first few weeks. Set an alarm if your puppy does not wake you — a trip at around 2 or 3 a.m. prevents an accident and teaches the puppy that nights are for sleeping, not toileting in the crate. Gradually push the alarm later as your puppy grows. By sixteen weeks, many puppies sleep six to seven hours; some take longer, and that is fine.

### Puppy Pads: A Decision to Make Early

If you live in a flat or a home without immediate garden access, puppy pads near the door are a practical bridge. But know the trade-off: pads teach your puppy that toileting indoors on a soft surface is acceptable, which can slow the move to outdoor-only toileting and can confuse puppies about rugs and bedding. If you use pads, place them right by the exit door, move them gradually closer to the door over two weeks, and then move them outside. If you have garden access, skip pads entirely and go straight outside every time. Either way, pick one approach and stick to it; switching back and forth confuses the puppy.

---

## 6. Crate Training, Step by Step

A crate, introduced correctly, becomes a bedroom, not a cage. Dogs are den animals; a small, cosy, safe space appeals to them. A crate introduced badly — by shutting a frightened puppy in it and walking away — becomes a source of panic. The difference is entirely in the introduction.

### The Progression

**Step 1 — The crate is a treat dispenser.** Leave the crate door open. Scatter treats inside it several times a day. Let the puppy walk in and out freely. Feed meals just outside the crate, then just inside the doorway, then at the back. Never close the door in step one.

**Step 2 — Short closed-door moments.** When the puppy walks in willingly, close the door for five seconds while you stand beside it, then open it and give a treat. Repeat, building to thirty seconds, then a minute. Always open the door before the puppy gets distressed. If it whines, you went too fast — go back a step.

**Step 3 — Short absences.** With the puppy settled in the crate with a chew, step out of sight for ten seconds, return, and reward calm. Build up gradually: thirty seconds, a minute, five minutes. Vary the durations so the puppy cannot predict when you will return; unpredictability teaches it that your return is always coming, which is the opposite of panic.

**Step 4 — Daytime naps in the crate.** Encourage naps in the crate with the door closed. A tired puppy that falls asleep in its crate wakes up feeling safe there, and that feeling compounds.

**Step 5 — Overnight.** Once the puppy naps happily in the crate during the day, move to overnight sleeping with the crate beside your bed, as described in Chapter 3.

### Rules for Crate Use

- The crate is never a punishment. Never put a puppy in the crate because you are angry, and never use it to "teach a lesson."
- Maximum crate time for a young puppy is its age in months plus one, in hours — and that is a maximum, not a target. An eight-week-old puppy should not be crated for more than two hours at a stretch during the day, and needs toilet breaks, play, and training between crated periods.
- Always give the puppy a toilet trip before crating and immediately after.
- Leave a safe chew in the crate, but never leave a collar on an unsupervised crated puppy, and never leave toys with parts that can be chewed off and swallowed.
- Cover the crate with a blanket on three sides to make it den-like, leaving the front open for airflow. Some puppies settle far better with a covered crate; if yours does not, leave it uncovered.

### If Your Puppy Panics in the Crate

Stop and go back. A puppy that is drooling, pawing frantically, howling without pause, or trying to escape is not "protesting" — it is panicking. Forcing it to endure panic teaches it that the crate is a terrible place and can create lasting confinement anxiety. Go back to step one, make the crate the best place in the house with high-value chews and meals, and progress more slowly. If panic persists after a week of gentle work, talk to your veterinarian or a qualified force-free trainer. Some puppies, particularly those with early separation distress, need professional support, and there is no shame in that.

---

## 7. Biting and Mouthing — What Is Normal and What to Do

Puppy biting is normal. It is not aggression, it is not dominance, and it is not a sign of a bad dog. Puppies explore the world with their mouths, play with their littermates by biting, and go through teething from about twelve weeks. Every puppy bites. The question is never how to stop it instantly; it is how to teach bite inhibition — the ability to control the force of the mouth — and how to redirect the biting onto appropriate things.

### Why Puppies Bite More at Certain Times

Biting spikes when a puppy is tired, overexcited, hungry, or overstimulated. The witching hour — typically early evening — is when most owners report the worst biting. That is not a coincidence: it is when the puppy is tired from the day and its self-control is lowest. If biting suddenly escalates, check the clock. The answer is usually a nap, not a training technique.

### The Method: Withdraw, Redirect, Reward Calm

When your puppy's teeth touch your skin or clothing, use this sequence every time:

1. **Go still and quiet.** Freeze. Do not pull your hand away — pulling triggers a chase-and-grab reflex and makes the bite harder. A high-pitched yelp works for some puppies and overexcites others; if a yelp makes your puppy bite harder, drop the yelp and simply go still.
2. **Withdraw attention for a few seconds.** Turn away, tuck your hands under your arms, and be boring for three to five seconds.
3. **Redirect.** Offer a suitable chew toy or a game with a toy. The moment the puppy takes the toy, praise it.
4. **Reward calm.** When the puppy is playing with the toy or lying quietly, give a treat or gentle praise.

If the puppy bites again immediately, repeat the sequence once, then calmly place the puppy in its pen with a chew and leave the room for thirty seconds. This is a time-out from fun, not a punishment: it teaches the puppy that biting makes the fun stop. Return calmly after thirty seconds.

### What Does Not Work

- Smacking, flicking the nose, holding the mouth shut, or pushing the puppy away. These increase arousal and fear, and they teach the puppy that hands are dangerous. A puppy that is punished for biting often bites harder and with less warning as an adult.
- Shouting. It raises the energy in the room and excites the puppy further.
- Rough play with hands. If you wrestle with your hands, you are teaching your puppy that hands are toys. Hands are for feeding, petting, and holding the lead. Toys are for biting.
- Expecting it to stop in a week. Bite inhibition takes weeks to months. Teething peaks around four to five months, and biting often gets worse before it gets better. Consistency across the whole household is what makes the difference.

### Children and Biting

Children are the most common targets of puppy biting because they move quickly, make high-pitched noises, and are at puppy height. Teach children to "be a tree": stand still, fold their arms, and look away when the puppy gets mouthy. Never leave a young child unsupervised with a puppy. Give children a job in training — dropping treats for a sit, for example — so the puppy learns that children are a source of good things, not moving chew toys.

---

## 8. Socialisation — The Window That Matters Most

The socialisation window — roughly three to twelve weeks of age — is the period when a puppy's brain is most open to new experiences. Positive experiences during this window build a confident adult dog. Missed or frightening experiences during it are much harder to fix later. This is the single most important chapter in the book, and it is the reason the program is structured week by week: you cannot redo week ten when your puppy is six months old.

### What Socialisation Actually Means

Socialisation is not "meeting lots of dogs" and it is not "taking the puppy everywhere." It is controlled, positive exposure to the sights, sounds, surfaces, people, animals, and situations your puppy will meet as an adult, at a level it can cope with, paired with good things. Quality beats quantity. One calm, treat-filled five-minute experience with a vacuum cleaner is worth more than an hour at a crowded market that overwhelms your puppy.

### The Rules of Good Socialisation

1. **Let the puppy choose the distance.** Never force a puppy toward something frightening. Let it observe from a distance where it is relaxed, reward calm observation, and let it approach in its own time. Retreat is always allowed.
2. **Pair new things with treats.** New sound? Treat. New person? Treat. New surface? Treat. You are building the association "new things predict good things."
3. **Watch the body language.** A relaxed puppy has a loose body, soft eyes, and a wagging tail held at a natural height. A worried puppy freezes, tucks its tail, flattens its ears, yawns, licks its lips, or tries to move away. If you see worry, increase the distance and make it easier. Never comfort-flood a frightened puppy by holding it in place.
4. **Short and sweet.** Five minutes of a new experience is plenty. End while your puppy is still happy.
5. **Before vaccinations are complete, be careful about ground contact.** Until your veterinarian confirms vaccinations are complete (usually around sixteen weeks), avoid places where many unknown dogs toilet — dog parks, busy pavements outside pet shops — and carry your puppy or use a clean blanket in high-traffic areas. Socialisation does not require paws on the ground: watching the world from your arms, from a car, or from a clean blanket counts fully.

### The Exposure Categories

Each week chapter lists exposures from these categories. Aim for a few from each category every week:

- **People:** different ages, heights, hats, uniforms, wheelchairs, people with beards, children (supervised, calm), people carrying bags or umbrellas.
- **Sounds:** vacuum cleaner, washing machine, hairdryer, doorbell, traffic, sirens at a distance, thunder recordings at low volume, fireworks recordings at low volume, children playing.
- **Surfaces:** grass, gravel, wet pavement, wood floors, tiles, carpet, metal grates, sand, a wobble board.
- **Places:** the vet waiting room, a pet-friendly café, a friend's house, a quiet street, a car journey, a lift.
- **Animals:** calm, vaccinated adult dogs known to be friendly with puppies; cats at a distance; livestock at a distance.
- **Handling:** ears, paws, teeth, tail, brushing, being picked up, wearing a harness, wearing a collar.

Use the socialisation checklist in the workbook to record every exposure and rate your puppy's reaction: relaxed, cautious, or worried. Cautious is fine — it means the puppy noticed and coped. Worried means go slower next time.

---

## 9. Basic Cues — Sit, Down, Come, Name, Leave It, Drop It, Settle

Teach one cue at a time, in short sessions, and practise it in real life rather than only in formal sessions. A cue your puppy only knows in the kitchen is not yet learned. A cue it knows in the kitchen, the garden, and the park is a real skill.

### Name Recognition

Say your puppy's name once, in a happy tone. The moment it looks at you, mark ("yes") and reward. Repeat five times, then stop. Practise at random moments through the day. Your puppy's name should predict good things. Never use the name to scold — "Bella, no!" teaches the puppy that its name predicts trouble, and it will stop responding to it.

### Sit

Hold a treat at your puppy's nose, then move it slowly up and back over its head. As the nose follows the treat, the bottom goes down. The instant it touches the floor, mark and reward. After five or six repetitions, add the word "sit" just before you move the treat. Practise before meals, before going outside, and before play. Sit is the most useful cue you will ever teach: it is the polite alternative to jumping, pulling, and barging through doors.

### Down

From a sit, hold a treat at the puppy's nose and lower it slowly to the floor between its paws, then slide it along the floor away from the puppy. As it follows, its body folds into a down. Mark and reward the moment its elbows touch the floor. Some puppies need the treat lured in an L-shape: down, then forward. Be patient; this cue is physically harder for some puppies than others.

### Come (Recall)

Recall is a safety skill and the hardest cue to make reliable, so start now and keep it fun forever. Indoors, crouch down, say your puppy's name and "come" in an excited voice, and reward with a high-value treat and a party when it arrives. Never call your puppy to you for something unpleasant — a bath, nail trim, or the end of play — or it will learn that coming to you ends the fun. Always go to the puppy for unpleasant things. Practise recall in the garden on a long line before you ever try it off-lead in an open space, and do not attempt off-lead recall in an unfenced area until your puppy is reliably coming to you on a long line with distractions present.

### Leave It

Hold a treat in a closed fist. Let your puppy sniff and paw at it. The moment it pulls its nose away, even slightly, mark and reward with a different, better treat from your other hand. Repeat until the puppy looks at you instead of the fist. Then add the words "leave it" just before you present the fist. This cue can one day stop your puppy eating something dangerous, so practise it seriously and often.

### Drop It

Offer your puppy a toy, let it take it, then present a high-value treat near its nose. The moment it drops the toy to take the treat, say "drop it," mark, and give the treat. Then give the toy back. Giving the toy back is essential: it teaches the puppy that dropping things does not mean losing them, which makes it far more willing to drop things in future. Never chase your puppy to retrieve an item or prise its mouth open; chasing turns the item into a prize.

### Settle (Go to Mat)

Place a mat on the floor. Every time your puppy steps on it, mark and reward. Gradually reward only longer stays on the mat, then add the word "settle." Over weeks, this becomes your puppy's place to relax while you eat dinner, while visitors arrive, or while you work. Start with seconds and build to minutes. A settle mat is one of the best investments in a calm adult dog.

### How to Practise Cues Across the Program

Each week chapter names the cue to focus on. Spend three to five minutes on it, three times a day, and then use it in real life: a sit before the food bowl goes down, a recall from the garden, a leave-it when a leaf blows past. Real-life practice, rewarded, is what turns a trick into a habit.

---

## 10. Week 8 — Orientation Week

**Age:** 8 weeks. **Theme:** Safety, comfort, and the first routines.

### Goals for the Week

- Your puppy knows where to toilet, where to sleep, and where its water is.
- You have a feeding schedule and a toilet schedule, and you are following both.
- The crate is a pleasant place with the door open.
- Your puppy knows its name and has started to sit.
- You have started a short list of gentle socialisation exposures inside the home.

### House Training

Take your puppy out every hour during the day, plus after meals, naps, and play. Expect accidents — probably several a day — and clean them without fuss. Keep a log in the workbook; by the end of the week you should start to see a pattern in timing. Night trips: one or two. If your puppy sleeps through the night, wonderful; do not wake it.

### Crate Training

Follow Step 1 from Chapter 6 all week: treats in the crate, meals near and then inside it, door open. At night, the crate sits beside your bed. If your puppy cries, place your hand near the crate door until it settles. Do not close the door for longer than a few seconds yet, and only when the puppy is happily eating a chew inside.

### Biting and Mouthing

Biting will be frequent this week as your puppy explores. Use the freeze-and-redirect sequence from Chapter 7 every time. Keep a toy within arm's reach in every room. Notice the times biting is worst — usually late afternoon and evening — and schedule a nap before those times rather than after the biting starts.

### Socialisation Exposures

Keep it gentle and at home this week: the sound of the vacuum from another room, the washing machine running, the doorbell, different family members, the feel of grass and hard floors, being picked up and held briefly, the sound of a hairdryer from a distance. Three to five short exposures a day is plenty. Record each one in the checklist.

### Basic Cues

**Name recognition and sit.** Practise name recognition five times, three times a day. Lure the sit with a treat before meals so the puppy learns that sitting makes food appear. Keep sessions to two minutes.

### Play and Rest

Play in short bursts: five to ten minutes of gentle play, then rest. Puppies need 18 to 20 hours of sleep a day. If your puppy is wild and bitey, it is almost certainly overtired. Enforce naps in the pen or crate after every play session and every training session. A puppy that naps on schedule is a puppy you can train.

### Common Problems

**"My puppy cries all night."** Normal. Keep the crate beside your bed, respond to toilet needs, and be boring at night. It usually improves markedly by the end of the second week. If crying continues beyond three weeks despite consistent routine, speak to your vet.

**"My puppy will not eat."** A new home suppresses appetite for a day or two. Offer the same food the breeder used, at set mealtimes, and remove it after fifteen minutes. Do not add tempting extras to coax eating; that teaches fussiness. If your puppy refuses food for more than 24 hours, or is lethargic, vomiting, or has diarrhoea, call your vet the same day.

**"My puppy follows me everywhere."** Normal at eight weeks. Your puppy has lost its family and you are its new anchor. Let it follow you for now. Independence is built gradually in later weeks; it cannot be rushed in week one.

---

## 11. Week 9 — Routine Week

**Age:** 9 weeks. **Theme:** The routine becomes predictable, and your puppy starts to trust it.

### Goals for the Week

- The daily routine is consistent: same feeding times, same toilet trips, same nap times.
- Your puppy is toileting outside more often than inside.
- The crate door can be closed for short periods while your puppy chews happily.
- Your puppy responds to its name most of the time indoors.
- Socialisation moves beyond the home: the front garden, the car, and quiet street sounds.

### House Training

You should now see fewer accidents if the schedule is consistent. If accidents cluster at a particular time, add a toilet trip just before it. Start watching for your puppy going to the door — reward immediately when it does, even if it does not toilet that trip, because going to the door is the behavior you want to strengthen. Introduce a bell on the door if you wish: hang a small bell at nose height, and every time you take the puppy out, gently tap its paw or nose to it first. Many puppies learn to ring the bell to ask to go out within a few weeks.

### Crate Training

Move to Step 2: close the door for a few seconds while the puppy chews, then open it. Build to a minute over the week. Start short absences: step out of the room for ten seconds and return before the puppy fusses. Begin moving the crate a little further from your bed at night if the first week went well — a few feet, not across the house.

### Biting and Mouthing

Biting is still frequent. Add a new element: teach the household to be consistent. Everyone uses the same freeze-and-redirect response. If children are in the house, practise "be a tree" with them this week. Start a biting diary in the workbook: time, what happened just before, and how long the biting lasted. You will likely find that biting follows overtiredness and overstimulation, and that a nap prevents it better than any technique.

### Socialisation Exposures

This week, broaden the world: sit in the front garden together and watch the street, take a short car ride (five minutes, puppy secured in a crate or harness), listen to traffic from a distance, meet one calm visitor at home, hear the doorbell and see someone come in. Introduce a new surface: gravel or a doormat. If your puppy is worried by traffic noise, move further away until it relaxes, reward calm, and try again closer another day.

### Basic Cues

**Sit, strengthened, and down introduced.** Sit should now happen quickly with a lure. Start fading the lure: use a smaller hand movement, then just the word with a hand signal. Introduce down using the lure in Chapter 9. Practise both before meals.

### Play and Rest

Introduce a simple game: rolling a ball a short distance and rewarding the puppy for returning toward you. Keep tug games gentle and short, and always trade for a treat to end the game — this is your first drop-it practice in a real game. Sleep is still 18 hours a day. Keep enforcing naps.

### Common Problems

**"My puppy has diarrhoea."** Mild, short-lived loose stools are common in the first weeks — new home, new water, new excitement. If it lasts more than 24 hours, if there is blood, vomiting, lethargy, or refusal to drink, call your vet the same day. Puppies dehydrate quickly. Do not change foods suddenly to fix it.

**"My puppy eats everything on the ground."** Normal. Puppies explore by mouth. Manage it by keeping the floor clear and using leave-it practice with boring items indoors. Outdoors, keep the puppy on a lead until recall and leave-it are stronger. If your puppy swallows something dangerous — a sock, a stone, a battery, medication — call your vet immediately.

---

## 12. Week 10 — Confidence Week

**Age:** 10 weeks. **Theme:** New experiences, gently, with treats.

### Goals for the Week

- Your puppy is comfortable with the crate door closed for a few minutes during the day.
- House training accidents are down to one or two a day.
- Your puppy has met several new people and heard several new sounds, all paired with treats.
- Sit is reliable indoors; down is improving.
- Handling practice is a daily habit: ears, paws, mouth, tail.

### House Training

Stretch the daytime interval to every 90 minutes if accidents have dropped, but keep the after-meal, after-nap, and after-play trips. This is the week many owners get complacent and accidents return — consistency is still the whole game. If you use a door bell, most puppies are ringing it inconsistently by now; reward every ring that leads to an outdoor toilet.

### Crate Training

Build closed-door crate time to five minutes during the day with a chew, while you stay in the room. Then try five minutes while you step into another room. Keep departures and returns low-key: no big hellos or goodbyes, which teach the puppy that your leaving and returning are dramatic events. A calm exit and a calm return produce a calm puppy.

### Biting and Mouthing

Teething is approaching but not yet here. Biting may increase as your puppy gains confidence. This is the week to be strictest about hands never being toys: if anyone in the house is still wrestling with hands, stop it now. Introduce a frozen stuffed food toy in the evening — it soothes gums, occupies the puppy, and gives you a calm hour.

### Socialisation Exposures

Aim for two new exposures a day. Ideas for this week: a visit to a friend's house (carried in, or on a clean blanket), the sound of a hairdryer in the same room at low volume, a person wearing a hat and sunglasses, a person with a walking stick, a bicycle passing at a distance, a pushchair, the sound of children playing in a park from a distance, walking on a wet pavement, and a ride in a lift if you have access to one. Take treats everywhere and reward calm observation.

### Basic Cues

**Down, strengthened, and recall introduced.** Practise down from a sit and from a stand. Introduce recall indoors: call your puppy from a few feet away, reward with a high-value treat and a fuss. Practise in different rooms. Never call the puppy for something it dislikes.

### Play and Rest

Play can be a little longer now — ten to fifteen minutes — but still followed by enforced rest. Introduce a wobble board or a low, stable platform to stand on, rewarded with treats: this builds body confidence and is good preparation for agility or balance work later. Sleep is still around 18 hours a day.

### Common Problems

**"My puppy is scared of the vacuum cleaner."** Very common. Do not drag the vacuum toward the puppy. Put the vacuum in the room switched off, scatter treats around it, and let the puppy investigate. Next day, switch it on in another room with the door open. Next day, run it in the same room for thirty seconds while someone feeds treats. Build over days, not minutes. The same gradual approach works for any feared sound or object.

**"My puppy barks at visitors."** At ten weeks this is usually excitement or uncertainty, not aggression. Ask visitors to ignore the puppy until it has four paws on the floor, then let them drop a treat. Teach visitors to crouch sideways rather than looming over the puppy. If barking persists, increase distance and reward quiet.

---

## 13. Week 11 — Manners Week

**Age:** 11 weeks. **Theme:** Polite behavior starts now — four paws on the floor, gentle mouth, waiting at doors.

### Goals for the Week

- Your puppy sits to say please: before meals, before the door opens, before play.
- Biting is reducing in frequency, and the puppy is starting to redirect to toys on its own.
- The puppy can settle on a mat for a few seconds with treats.
- Socialisation includes a calm, vaccinated adult dog.
- Handling is easy: the puppy accepts ears, paws, and mouth being touched.

### House Training

Most puppies are now giving clearer signals — going to the door, circling, or whining. Reward every signal immediately, even if you are busy. This is the behavior you want to grow. Night trips may drop to one, or none on good nights. If accidents still happen daily, review the log: is there a time of day you keep missing? Is the interval too long after meals?

### Crate Training

Build to ten to fifteen minutes of calm crate time during the day. Practise leaving the house for a few minutes: put the puppy in the crate with a chew, leave quietly, return after five minutes. Vary the time. Keep a radio or calm music on if it seems to help. Some puppies settle better with a covered crate; try it this week if you have not already.

### Biting and Mouthing

By now the freeze-and-redirect sequence should be automatic for the humans. This week, add the next layer: when your puppy approaches you and chooses a toy instead of your hand, reward it enthusiastically. You are reinforcing the decision you want, not just correcting the one you do not. Keep the biting diary going; compare this week with last week. Most owners see a real reduction by week eleven, even though biting is far from gone.

### Socialisation Exposures

The highlight this week: a meeting with a calm, fully vaccinated adult dog that is known to be gentle with puppies. Keep it short — five minutes — on neutral ground, both dogs on leads, with plenty of space to move away. Reward calm behavior from both. Do not let the adult dog overwhelm the puppy, and do not let the puppy pester the adult. A good first meeting is boring: a sniff, a wander, and a calm parting. That is success.

Also this week: a pet-friendly shop entrance (carried or on a blanket), a person in a uniform, a person using a wheelchair or crutches if you can arrange it, the sound of a lawnmower at a distance, and rain on a window. If your puppy has not yet travelled in the car happily, practise short rides with a treat at the end.

### Basic Cues

**Settle on a mat introduced, and leave it introduced.** Start settle by rewarding any interaction with the mat, as in Chapter 9. Start leave it with a treat in a closed fist, indoors, with no distractions. Both cues take weeks to become reliable, so begin now and be patient.

### Play and Rest

Introduce a simple search game: scatter a few treats in the grass or on a snuffle mat and let your puppy find them. Scent games tire a puppy out mentally, which is often more effective than physical exercise, and they teach the puppy to use its nose. Sleep is still around 17 to 18 hours a day.

### Common Problems

**"My puppy jumps up at everyone."** Jumping is rewarding for a puppy: it gets attention and face contact. The cure is to make jumping unrewarding and sitting rewarding. When the puppy jumps, turn away and be boring. The instant all four paws are on the floor, reward. Ask visitors to do the same. Never push the puppy down with your hands — pushing is attention, and attention is the reward the puppy wants. Consistency from every person the puppy meets is essential; one person who allows jumping will undo the work of five who do not.

**"My puppy steals food from the table and counters."** Manage the environment: keep food out of reach, never leave a puppy unsupervised in a kitchen with food out, and teach a strong leave-it and a settle on a mat during your meals. A puppy that is rewarded for settling on its mat while you eat learns that the mat is where good things happen at mealtimes.

---

## 14. Week 12 — The Vet Visit and the Wider World

**Age:** 12 weeks. **Theme:** The second vaccination, the vet as a friend, and the world opening up.

### Goals for the Week

- Your puppy has its second vaccination and a vet check, and the visit goes well.
- Your puppy can walk on a lead in the garden and on a quiet street.
- House training accidents are occasional, not daily.
- The puppy is comfortable being handled by a stranger (the vet) with treats.
- Socialisation includes a busier environment, at a distance your puppy can cope with.

### House Training

By now the schedule is a habit for both of you. Start stretching intervals to two hours during the day if accidents are rare. Keep the after-meal and after-nap trips non-negotiable. If your puppy is reliably going to the door, you can begin to rely on signals more and on the clock less — but keep the log for one more week so you can spot any regression.

### Crate Training

Your puppy should now nap in the crate willingly during the day and sleep in it at night. This week, begin moving the crate to its long-term location if you plan to move it out of your bedroom — move it a few feet at a time over several nights rather than all at once. If the puppy's sleep gets worse after a move, move it back a step and try again in a few days.

### Biting and Mouthing

Teething is beginning: baby teeth start to loosen around twelve weeks. Expect biting to increase again as gums get sore. Offer cold chews — a wet flannel twisted and frozen, a frozen stuffed food toy, a chilled teething ring. Never give ice cubes to a very small puppy unsupervised, and never give cooked bones, which splinter. If your puppy's gums look red or swollen, or it is reluctant to eat hard food, soften the food with warm water and mention it to your vet.

### Socialisation Exposures

The vet visit is the main event: take treats, ask the vet and nurse to give your puppy treats, and practise handling on the table. Let your puppy sniff the waiting room and be rewarded for calm. After the vet confirms the vaccination schedule, ask when it is safe for paws on the ground in busier places and follow that advice exactly — it varies by area and disease risk.

Other exposures: a short lead walk on a quiet street, a bus passing, a pet shop visit (carried or on a blanket if the vet advises), a café garden, a child playing at a distance, and a new texture underfoot such as sand or a metal grate. Watch for tiredness: a twelve-week-old puppy can be overwhelmed by too many new things in one day. One or two new things a day is the right pace.

### Basic Cues

**Lead walking introduced, and recall practised in the garden.** For lead walking, reward your puppy for being near you and for the lead being loose. Take one step, reward; two steps, reward. If the puppy pulls, stop and wait for the lead to slacken, then move again. Do not yank the lead. Keep first walks to five minutes. For recall, practise in the garden with a long line, calling the puppy from increasing distances and rewarding with high-value treats.

### Play and Rest

Sleep is still 16 to 18 hours a day. Play sessions can be fifteen minutes, but rest remains the priority. Introduce a flirt pole or a toy on a rope for chase games in the garden, keeping the puppy's feet on the ground — no jumping or sharp turns at this age, as joints are still developing.

### Common Problems

**"My puppy is terrified of the vet."** A bad vet visit at twelve weeks can color every future visit. Prevent it: bring treats, keep the visit short, ask the staff to go slowly, and reward your puppy throughout. If the puppy is already frightened, ask the vet to do the examination on the floor rather than the table, and to pair every touch with a treat. Book a "happy visit" — a trip to the vet just for treats and a weigh-in, with no examination — in the coming weeks.

**"My puppy pulls on the lead already."** Normal. Puppies pull because the world is exciting and pulling gets them there faster. The cure is patience: reward a loose lead, stop when it tightens, and keep walks short. Pulling is fixed over months, not days. Never use a choke, prong, or shock collar; they cause pain and fear and can injure a growing neck.

---

## 15. Week 13 — Independence Week

**Age:** 13 weeks. **Theme:** Short absences, solo play, and confidence alone.

### Goals for the Week

- Your puppy can be left alone in its pen or crate for 15 to 30 minutes without distress.
- Your puppy plays independently with a food toy for a few minutes.
- Sit, down, and recall are working in the garden as well as indoors.
- Socialisation includes a new place: a friend's house or a quiet park, at a distance the puppy can cope with.
- The puppy is comfortable with grooming: a short brush, a paw touch, and looking at its teeth.

### House Training

Accidents should now be occasional. If your puppy has had a full week with no accidents, you can start to trust it in one puppy-proofed room for short periods, but keep the toilet schedule going. One common trap: owners relax the schedule the moment things improve, and accidents return within days. Keep the routine for the full sixteen weeks, then taper gradually.

### Crate Training

Build alone time to 20 to 30 minutes. Use a food toy or a long-lasting chew at departure, and leave the radio on. Practise leaving the house: go out the front door, wait a minute, come back in quietly. Increase the time gradually. If your puppy is distressed — howling, drooling, trying to escape — you have gone too far too fast. Go back to shorter absences and build more slowly. Separation anxiety is easier to prevent than to cure, and prevention is exactly what these short, successful absences are doing.

### Biting and Mouthing

Teething is now in full swing and biting may be at its worst. This is the week most owners feel like giving up. Do not. The biting diary will show that the pattern has changed: biting is now concentrated at teething times and overtired times, and your puppy is beginning to redirect to toys without prompting. Keep frozen chews in the freezer at all times. If your puppy bites hard enough to break skin, use the time-out from fun (thirty seconds in the pen, no drama) and then redirect to a chew. Hard bites that break skin are a sign to check with your vet or a force-free trainer that your bite-inhibition plan is on track — but they are not, on their own, a sign of aggression in a thirteen-week-old puppy.

### Socialisation Exposures

New places this week: a different house, a quiet park (carried or on a blanket until vaccinations allow ground contact), a car journey of ten to fifteen minutes, a person wearing a motorcycle helmet, a person with an umbrella opening and closing, and a dog barking at a distance. Also practise being handled by someone other than you: ask a friend to gently touch ears and paws while you feed treats. This is preparation for groomers and vets for life.

### Basic Cues

**Drop it, strengthened, and settle extended.** Practise drop it in play every day, always giving the toy back. Extend settle on the mat from seconds to a minute, rewarding calm lying down. Start using settle during your own mealtimes: puppy on its mat, treats delivered quietly for staying there.

### Play and Rest

Independent play is the goal this week. A puppy that can entertain itself with a food toy for five minutes is learning to be content alone, which is a life skill. Rotate toys so they stay novel: keep half the toys put away and swap them every few days. Sleep is around 16 hours a day.

### Common Problems

**"My puppy destroys everything."** Puppies chew. It is how they explore and how they soothe teething gums. The answer is management plus appropriate outlets: puppy-proof the room, provide a range of chew textures, and rotate them. A puppy that is chewing a table leg is a puppy that does not have a better chew within reach, or is overtired. Never punish chewing after the fact. If your puppy swallows a non-food item, call your vet.

**"My puppy will not come when called outside."** Outside is far more exciting than indoors, and your puppy's recall is not yet strong enough for it. Go back to the garden on a long line, use higher-value treats outside than inside, and never call the puppy when you are sure it will not come — every ignored recall teaches the puppy that recall is optional. Instead, go and get the puppy, or wait until it looks at you and then call.

---

## 16. Week 14 — Distraction Week

**Age:** 14 weeks. **Theme:** The cues you taught indoors, practised with the world turned up.

### Goals for the Week

- Sit, down, and recall work in the garden with mild distractions.
- Your puppy can walk on a loose lead for a few minutes on a quiet street.
- Socialisation includes busier places, with treats and retreat always available.
- Your puppy is comfortable with a short grooming session: brushing, nail touch, and ear check.
- Alone time reaches 30 to 45 minutes without distress.

### House Training

Most puppies are now reliable in the rooms they live in, with occasional accidents when excited or when the routine slips. If your puppy still has daily accidents, do not worry — but do review the log carefully. Common causes at fourteen weeks: the interval after meals is too long, the puppy has access to too much space unsupervised, or a urinary infection is making it hard to hold on. If accidents are frequent and sudden after a period of success, ask your vet to check for a urinary infection.

### Crate Training

Your puppy should now settle in the crate within a few minutes. This week, practise crating at different times of day, not just at night, so the crate does not become a signal that you are leaving for hours. A midday crate nap with a chew, with you at home in another room, is excellent practice.

### Biting and Mouthing

Biting should be noticeably less frequent than at eight weeks, though teething is still active. The key measure is not whether your puppy still bites — it will — but whether it is learning to choose toys and to soften its mouth. If you compare the biting diary from week nine with this week, you should see fewer incidents and shorter episodes. If you do not, check the two usual causes: is the puppy getting enough sleep, and is every person in the house using the same response?

### Socialisation Exposures

Raise the difficulty gently: a busier street at a distance, a market or shopping area from the edge, a bus stop, a playground at a distance, a dog barking behind a fence, a person jogging past, a cyclist passing, and a visit to a different pet-friendly place. Keep each exposure short and end on a success. If your puppy is overwhelmed, move away, let it recover, and try an easier version another day. Overwhelming a puppy does not toughen it up; it teaches it that the world is frightening.

### Basic Cues

**All cues practised with distractions.** Practise sit and down in the garden with a toy visible nearby. Practise recall in the garden when a family member is walking around. Practise leave it with a boring item dropped on the floor. Reward generously: distractions make the task harder, so the pay should be better. If your puppy fails, make it easier — move further from the distraction or reduce it — and try again. Failure is information about the difficulty level, not about your puppy.

### Play and Rest

Play is now fifteen to twenty minutes, and your puppy's coordination is improving fast. Introduce gentle games of fetch in the garden: roll the ball, not throw it far, and reward the return. Keep jumping to a minimum — no jumping for toys, no stairs as exercise, no long runs on hard surfaces — because growth plates are still open and joints are vulnerable. Sleep is around 16 hours a day.

### Common Problems

**"My puppy is suddenly scared of things it was fine with."** This can happen around fourteen weeks and again in adolescence: a normal fear period. A puppy that was confident with the vacuum may suddenly be wary of it. Do not force the issue and do not make a fuss. Go back to an easier distance, pair the scary thing with treats, and let confidence return over days. Never punish fear. Fear periods pass, and how you handle them shapes your adult dog.

**"My puppy barks at everything on walks."** At fourteen weeks this is usually excitement or uncertainty. Increase distance from the trigger, reward quiet observation, and keep walks short. Do not drag your puppy past something frightening, and do not let strangers rush up to greet it. A puppy that learns it can move away from scary things is a puppy that does not need to bark at them.

---

## 17. Week 15 — Reliability Week

**Age:** 15 weeks. **Theme:** The routine holds together without you watching every minute.

### Goals for the Week

- Your puppy is house trained in its main living areas, with accidents rare.
- Alone time reaches 45 minutes to an hour without distress.
- Recall works in the garden with distractions, on a long line.
- Your puppy can settle on its mat for several minutes while you eat or work.
- Your puppy has met a wide range of people, sounds, surfaces, and places — check the socialisation list for gaps.

### House Training

By fifteen weeks, many owners can leave the back door routine to the puppy's signals during the day, with scheduled trips still anchoring the morning, after meals, and before bed. If you are moving toward free access to more rooms, do it one room at a time, and supervise in each new room for the first week. A puppy that is reliable in the kitchen is not automatically reliable in a carpeted bedroom.

### Crate Training

The crate is now a habit. This week, start thinking about the long term: the crate can stay as your puppy's bedroom for as long as it likes it, and many dogs keep using theirs for life with the door open. Never remove the crate suddenly; if you plan to phase it out, do it gradually over weeks, starting with the door left open at night.

### Biting and Mouthing

Biting is now occasional rather than constant for most puppies, and it is increasingly directed at toys. Keep the freeze-and-redirect response in place for the bites that remain. This is also the week to check your puppy's mouth: baby teeth should be falling out and adult teeth coming through. If a baby tooth is still firmly in place next to an adult tooth — a retained baby tooth, most commonly a canine — mention it to your vet, as retained baby teeth can cause problems.

### Socialisation Exposures

Review the socialisation checklist and fill the gaps. Common gaps at fifteen weeks: men with beards, people in hats, wheelchairs, pushchairs, umbrellas, different floor surfaces, livestock at a distance, and the sound of fireworks or thunder at low volume (use recordings, starting very quietly, paired with treats). Also practise a short stay at a friend's house, a longer car journey, and a visit to the vet for a happy visit — treats and a weigh-in, no examination.

### Basic Cues

**Stay introduced, and all cues chained into daily life.** Teach stay by asking for a sit, holding your palm up, waiting two seconds, then marking and rewarding. Build duration slowly: two seconds, then five, then ten. Practise sit-stay before meals and before the door opens. Chain cues into routines: sit before the lead goes on, down before the food bowl goes down, recall from the garden before coming inside for a treat.

### Play and Rest

Your puppy's energy is increasing. A fifteen-week-old puppy needs more than a garden: it needs short lead walks in the world, play with appropriate dogs, and mental work like scent games. A good rule for lead walks is five minutes per month of age, twice a day — about 20 minutes for a fifteen-week-old puppy — and that is a maximum, not a target. Mental work counts as exercise: ten minutes of scent games can tire a puppy as much as a walk. Sleep is still around 15 to 16 hours a day.

### Common Problems

**"My puppy is chewing the furniture, the skirting boards, everything."** Teething peaks between four and five months, and this is it. Provide a range of safe chews, rotate them, freeze them, and smear them with a little dog-safe spread. Protect furniture with bitter apple spray made for dogs if needed, and manage access with gates. Do not punish the chewing; redirect it. This phase passes as adult teeth come through.

**"My puppy will not settle in the evening."** The evening witching hour is still real at fifteen weeks. The fix is a structured evening: a short walk or play session, a frozen food toy, and then a calm settle on the mat with a chew. If your puppy is wild every evening, look at the whole day: was there enough sleep, enough mental work, and enough toileting? A puppy that has napped poorly will be wild in the evening, and no training technique fixes a tired puppy except sleep.

---

## 18. Week 16 — Graduation Week and the Road Ahead

**Age:** 16 weeks. **Theme:** Celebrate how far you have come, check what is solid, and plan the next stage.

### Goals for the Week

- You can list what your puppy can do reliably and what still needs work.
- Your puppy's vaccinations are complete (or the final appointment is booked) and wider socialisation is opening up.
- The daily routine runs smoothly: feeding, toileting, training, play, rest.
- You have a plan for the next eight weeks: a puppy class, continued socialisation, and the adolescent stage ahead.
- Your puppy is a confident, friendly, well-rested young dog that trusts you.

### House Training

By sixteen weeks, most puppies are house trained or very close: accidents are rare and usually linked to excitement or a missed trip. If your puppy is still having regular accidents, revisit the schedule, check for a urinary infection with your vet, and keep going — some puppies, particularly small breeds, take longer, and that is normal. Do not compare your puppy to anyone else's. Keep the log for another two weeks so you have evidence of progress.

### Crate Training

Your puppy should now see the crate as its bedroom. From here, the crate becomes a tool for life: for travel, for vet stays, for rest after exercise, and for safety when you cannot supervise. Keep it comfortable and keep the association positive.

### Biting and Mouthing

Biting is not gone, and it will flare again during teething and adolescence, but the foundation is laid: your puppy knows that biting people makes fun stop, that toys are for biting, and that a soft mouth earns rewards. Keep the response consistent through the next months. The work you did in the first sixteen weeks is what makes an adult dog with a reliable soft mouth.

### Socialisation Exposures

With vaccinations complete, the world opens: proper lead walks in busier places, puppy class, visits to friends' houses, and meeting a wider range of dogs. Keep going. Socialisation does not stop at sixteen weeks — it continues through adolescence — but the window of greatest openness is closing, so the exposures you do now matter most. Keep the checklist going for another month and aim to fill every category.

### Basic Cues

**Review and consolidate.** Test each cue in a new place: sit in the garden, down in a friend's house, recall in the park on a long line, leave it with a real-world item. Reward generously for success in new places. If a cue fails in a new place, it is not that your puppy is being stubborn; it is that the cue is not yet generalised. Practise it there, at an easier level, and build up again.

### Play and Rest

Your puppy can now walk for about 20 minutes twice a day, play with suitable dogs, and enjoy longer training games. Sleep is still 14 to 16 hours a day — a puppy that sleeps less than that is likely overtired, and overtired puppies bite, bark, and cannot learn.

### Common Problems

**"My puppy was doing so well and now it has gone backwards."** Regression is normal. Puppies regress after a vet visit, a house move, a change in routine, a growth spurt, or a fear period. When it happens, go back to the basics: a tighter toilet schedule, shorter training sessions, easier socialisation, more sleep. Regression is not failure. It is your puppy telling you it needs support, and support is what you are good at by now.

**"What do I do next?"** Book a puppy training class with a force-free trainer, if you have not already. Keep socialising. Start thinking about adolescence: from about five to six months, your puppy will test boundaries, forget cues it knew, and seem like a different dog. That is normal, and the foundations you built in these sixteen weeks are what carry you through it. Keep this guide and the workbook, and return to the troubleshooting appendix whenever a new problem appears.

### Graduation Checklist

Tick each one honestly. Anything unticked is your plan for the next month, not a failure.

- [ ] My puppy toilets outside reliably in its main living areas.
- [ ] My puppy sleeps in its crate willingly.
- [ ] My puppy can be left alone for 45 minutes without distress.
- [ ] My puppy responds to its name, sits, lies down, and comes when called in the garden.
- [ ] My puppy accepts handling of ears, paws, and mouth.
- [ ] My puppy has met a wide range of people, sounds, surfaces, and places.
- [ ] My puppy walks on a loose lead for a few minutes.
- [ ] Biting is occasional and mostly directed at toys.
- [ ] I have a vet I trust and the vaccination schedule is complete or booked.
- [ ] I know what to do when things go wrong: go back a step, make it easier, and ask for help.

Congratulations. You have done the hardest and most important weeks of your dog's life. The next sixteen weeks will be easier because of the work you did here.

---

## 19. Troubleshooting Appendix — Common Problems, Solved Calmly

### Toilet Training Regressions

Go back to the week-eight schedule for three days: hourly trips, after every meal, nap, and play session. Check for a medical cause with your vet if regression is sudden. Check for a change in the household: a new person, a move, building work, or a change in feeding times can all cause regression.

### Separation Distress

Signs include howling or barking the whole time you are gone, drooling, destructive behavior focused on exits, toileting in the crate despite being taken out, and refusing food when alone. If you see these, do not try to fix it alone with longer absences — that makes it worse. Speak to your veterinarian, who can rule out medical causes and refer you to a veterinary behaviorist. Separation distress is a welfare issue, not a training failure, and it responds well to professional help.

### Fear of Sounds

Use the gradual approach from Chapter 8: distance, low volume, treats, and time. Recordings of thunder and fireworks, played very quietly while your puppy eats, can build a positive association before the real thing happens. Start weeks before firework season, not the night before.

### Resource Guarding

If your puppy stiffens, growls, or snaps when you approach its food bowl, chew, or toy, do not punish the growl — the growl is a warning, and punishing warnings teaches a dog to bite without warning. Instead, practise trading: approach, drop a high-value treat near the puppy, and walk away. Over time, your approach predicts better things, not loss. If guarding is serious or escalating, speak to a qualified force-free trainer or veterinary behaviorist promptly.

### Barking

Barking is communication. Work out what the barking is for: excitement, fear, attention, boredom, or alerting. Then address the cause: more exercise and mental work for boredom, more distance and treats for fear, and rewarding quiet for attention barking. Never shout at a barking puppy; it sounds like you are barking too.

### Digging and Destructive Chewing

Provide a legal outlet: a digging pit in the garden (a sandpit with buried treats), a range of chews, and enough mental work. A puppy that digs and chews destructively is usually bored, teething, or overtired. Supervise, manage, and redirect; the phase passes.

### Jumping Up at Children

Manage it physically: keep the puppy on a lead when children are around, reward four paws on the floor, and teach children to be a tree. Never let a puppy rehearse jumping on small children; a single knock-over can frighten a child for years.

### When to Get Professional Help

Get help promptly if you see: aggression with intent to harm (not normal puppy mouthing), persistent fear that does not improve over two weeks, separation distress, resource guarding that escalates, or any behavior that makes you feel unsafe. Choose a trainer who uses positive reinforcement only and who is certified or accredited by a recognised body. Ask directly: "Do you use punishment, corrections, or aversive tools?" If the answer is yes, or if it is evasive, find another trainer.

---

## 20. Daily Schedule Templates and Worked Examples

### Worked Example: A Day at 10 Weeks

- **7:00** — Wake, straight outside to toilet, praise and treat. Breakfast in a bowl or a food toy.
- **7:30** — Short play and training: five minutes of sit and name practice. Toilet trip.
- **8:00** — Nap in crate or pen.
- **10:00** — Wake, toilet trip, short play, socialisation exposure (vacuum sound from another room, treats).
- **10:30** — Nap.
- **12:00** — Lunch, toilet trip, garden play and recall practice.
- **12:30** — Nap.
- **14:30** — Wake, toilet trip, training session (down), chew time.
- **15:00** — Nap.
- **17:00** — Dinner, toilet trip, short lead walk in the garden or quiet street.
- **17:30** — Play, socialisation exposure (visitor or new sound).
- **18:30** — Frozen food toy, calm settle on the mat.
- **19:30** — Last toilet trip, final short play, then wind down.
- **21:00** — Bedtime: toilet trip, crate beside your bed, small treat.
- **2:00 or 3:00** — Night toilet trip if needed.

### Worked Example: A Day at 15 Weeks

- **7:00** — Wake, toilet trip, breakfast. Sit before the bowl goes down.
- **7:30** — Training: recall and leave it in the garden, five minutes. Toilet trip.
- **8:00** — Nap.
- **10:00** — Wake, toilet trip, lead walk (15 minutes) with loose-lead practice.
- **10:30** — Scent game or food puzzle, then nap.
- **12:30** — Lunch, toilet trip, socialisation outing (a new place or a friend's house).
- **14:00** — Nap.
- **16:00** — Wake, toilet trip, training (settle on the mat, stay), play with a suitable dog if available.
- **17:30** — Dinner, toilet trip, short walk.
- **18:30** — Calm settle on the mat while the family eats; frozen chew.
- **20:00** — Last play, toilet trip, wind down.
- **21:30** — Bedtime in the crate.

### How to Build Your Own Day

Start with the fixed points: meals, toilet trips, and sleep. Puppies need 14 to 20 hours of sleep depending on age, so sleep is most of the day. Fit training into the waking windows in three-to-five-minute sessions. Fit socialisation into one or two waking windows a day. If a day has no time for a training session, a single sit before a meal still counts. Small and consistent beats occasional and heroic.

---

## 21. The Socialisation Master List

Tick each item when your puppy has experienced it calmly, and note the date and your puppy's reaction in the workbook checklist.

**People:** baby, toddler, child, teenager, adult man, adult woman, older person, person with a beard, person wearing a hat, person wearing sunglasses, person in a uniform, person with a walking stick, person in a wheelchair, person carrying bags, person with an umbrella, jogger, cyclist, delivery driver.

**Sounds:** vacuum cleaner, washing machine, tumble dryer, hairdryer, doorbell, telephone ringing, television, radio, traffic, bus, siren at a distance, aeroplane overhead, thunder recording (low volume), fireworks recording (low volume), children playing, dog barking at a distance, lawnmower at a distance.

**Surfaces:** grass, wet grass, gravel, sand, wood floor, tiles, carpet, metal grate, wet pavement, mud, a wobble board, a low platform, a ramp, stairs (carried at first, then one or two steps when old enough).

**Places:** the vet waiting room, a friend's house, a pet-friendly café, a pet shop, a quiet street, a busier street at a distance, a park, a car, a lift, a car park, a market edge.

**Animals:** calm adult dog, puppy of a similar age, cat at a distance, horse at a distance, sheep or livestock at a distance, birds in a garden.

**Handling:** ears touched, paws touched, nails touched, teeth looked at, tail touched, belly touched, being picked up, wearing a harness, wearing a collar, being brushed, having a bath (when needed, with treats), being dried with a towel.

**Objects:** umbrella opening, pushchair, bicycle, skateboard at a distance, suitcase with wheels, bin lorry at a distance, balloons, mirrors, a flapping tarpaulin.

---

## 22. What Comes Next After Week 16

The first sixteen weeks are the foundation, not the finished house. Here is what to focus on next:

- **Puppy class.** A force-free puppy class gives your puppy supervised social time with other puppies and gives you a trainer to ask questions. Choose a class that uses positive reinforcement, keeps numbers small, and separates play by size and confidence.
- **Adolescence.** From about five months, expect testing, forgetting, and a second fear period. Keep the routine, keep rewarding, and do not take regression personally. The foundations you built will carry you through.
- **Continued socialisation.** Keep exposing your puppy to new things, one or two a week, for the first year. A dog that stops meeting new things at sixteen weeks can become nervous of novelty as an adult.
- **Neutering, diet, and exercise.** Discuss timing with your veterinarian — it varies by breed, size, and sex. Feed a good-quality puppy food until your vet advises switching to adult food. Increase exercise gradually: the five-minutes-per-month-of-age rule for lead walks is a useful guide for the first year.
- **Keep training.** Teach new cues, practise old ones in new places, and keep rewarding. A dog that is trained a little every day is a dog that is easy to live with for the next fifteen years.

Thank you for reading, and for doing this work. Your puppy will not remember the treats or the schedules. It will remember that the world was safe, that you were kind, and that learning was fun. That is the whole program.

---

*This guide is for general education only and never replaces veterinary care or the advice of a qualified veterinary behaviorist. If your puppy is ill, in pain, or showing behavior that worries you, contact your veterinarian promptly. All methods in this guide use positive reinforcement only.*
