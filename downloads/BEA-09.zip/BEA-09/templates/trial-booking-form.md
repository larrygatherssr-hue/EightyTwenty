# Bridal Trial Booking Form

Complete one form per bride. Keep it with the contract and the client intake worksheet. Bring it on the wedding day.

## Client Details

- **Bride name:** __________
- **Phone / email:** __________
- **Wedding date:** __________
- **Wedding venue:** __________
- **Getting-ready address:** __________
- **Trial date and time:** __________
- **Trial place:** __________

## Before the Trial — Please Tell Us

- **Allergies or sensitivities (as stated by the client):** __________
- **Products you cannot use:** __________
- **Skin concerns (as stated by the client — factual only):** __________
- **Have you had a reaction to makeup before?** Yes / No — Details: __________
- **Dress style and colour:** __________
- **Hair style planned:** __________
- **Veil or hair accessory:** __________
- **Photographs of looks you like:** attached / shown — **Looks you do not like:** __________
- **How do you want to look and feel on the day?** __________

> If you report a skin condition, allergy, infection, or medical concern, we will not diagnose it or advise on treatment. We may advise you to consult a qualified medical or dermatology professional, and we may decline to apply makeup to an affected area if application would be unsafe.

## Trial Record (Artist to Complete)

- **Skin preparation used:** __________
- **Primer:** __________
- **Foundation — brand, shade:** __________
- **Concealer — brand, shade:** __________
- **Powder:** __________
- **Eyes — shadows, liner, brow:** __________
- **Lashes:** __________
- **Cheeks — blush, bronzer, highlighter:** __________
- **Lips:** __________
- **Setting spray:** __________
- **Photographs taken:** Daylight [ ] / Indoors [ ] / Front [ ] / Side [ ]

## Agreed Changes

- **What the bride liked:** __________
- **What to change for the wedding day:** __________
- **Products or shades to change:** __________
- **Timings agreed for the wedding day:** Bride ready by __________ — Arrival __________

## Trial Fee and Booking

- **Trial fee:** $__________
- **Paid on:** __________
- **Wedding-day booking confirmed?** Yes / No
- **Booking fee paid:** $__________ on __________
- **Balance due:** $__________ by __________

**Bride signature:** ______________________________ Date: __________

**Artist signature:** ______________________________ Date: __________

---

*General template for education only. Not legal advice. If a health question arises, refer the client to a qualified professional.*
