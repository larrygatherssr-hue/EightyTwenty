# Kit Inventory and Hygiene Checklist

Use this checklist monthly, and the hygiene section at every booking. Print it and keep it with your kit.

## Monthly Inventory Count

For each item, record the quantity, the date opened, and whether it needs restocking. Discard anything expired, separated, smelling unusual, or past its recommended period after opening.

### Base and Skin Preparation
- [ ] Moisturiser — Qty: ____ — Opened: ____ — Restock? ____
- [ ] Primer (s) — Qty: ____ — Opened: ____ — Restock? ____
- [ ] Foundation — light shades — Qty: ____ — Restock? ____
- [ ] Foundation — medium shades — Qty: ____ — Restock? ____
- [ ] Foundation — deep shades — Qty: ____ — Restock? ____
- [ ] Concealer — range of shades — Qty: ____ — Restock? ____
- [ ] Setting powder — Qty: ____ — Restock? ____
- [ ] Colour corrector — Qty: ____ — Restock? ____

### Eyes and Brows
- [ ] Eyeshadow palettes — Qty: ____ — Restock? ____
- [ ] Eyeliner (pencil / liquid / gel) — Qty: ____ — Restock? ____
- [ ] Brow products — Qty: ____ — Restock? ____
- [ ] Mascara — Qty: ____ — Restock? ____ (Use disposable wands; never share mascara)
- [ ] False lashes — styles: ____ — Qty: ____ — Restock? ____
- [ ] Lash glue — Qty: ____ — Opened: ____ — Restock? ____

### Cheeks and Lips
- [ ] Blush — Qty: ____ — Restock? ____
- [ ] Bronzer / contour — Qty: ____ — Restock? ____
- [ ] Highlighter — Qty: ____ — Restock? ____
- [ ] Lipstick — range of shades — Qty: ____ — Restock? ____
- [ ] Lip gloss / lip liner — Qty: ____ — Restock? ____

### Setting and Tools
- [ ] Setting spray — Qty: ____ — Restock? ____
- [ ] Brushes — full set clean and complete? Yes / No
- [ ] Brush cleaner — Qty: ____ — Restock? ____
- [ ] Sponges — Qty: ____ — Restock? ____
- [ ] Palettes (mixing) — clean? Yes / No
- [ ] Pencil sharpener — clean? Yes / No

### Hygiene and Disposables
- [ ] Hand sanitiser — Qty: ____ — Restock? ____
- [ ] Disposable mascara wands — Qty: ____ — Restock? ____
- [ ] Disposable lip applicators — Qty: ____ — Restock? ____
- [ ] Cotton buds — Qty: ____ — Restock? ____
- [ ] Tissues — Qty: ____ — Restock? ____
- [ ] Waste bags — Qty: ____ — Restock? ____

### Touch-Up Kits
- [ ] Small bags / pouches — Qty: ____
- [ ] Blotting papers — Qty: ____
- [ ] Mini powder — Qty: ____
- [ ] Lip product for kit — Qty: ____

**Restock order list (this month):**


**Total replacement value of kit:** $__________
**Insurance current?** Yes / No — **Renewal date:** __________

## Hygiene Checklist — Use at Every Booking

- [ ] Hands washed and sanitised before the first client
- [ ] Hands sanitised between every client
- [ ] Clean brushes for every client — no shared brush without proper cleaning between clients
- [ ] Disposable mascara wands — one per client, never reused or double-dipped
- [ ] Disposable lip applicators — one per client, never reused or double-dipped
- [ ] Creams and foundations dispensed onto a clean palette or sanitised hand, never straight from the container onto a client's face
- [ ] Pencils sharpened and wiped before each use
- [ ] Palette, work surface, and tools clean at the start of the booking
- [ ] Kit stored in clean, closed containers
- [ ] Station left clean; waste disposed of after the last client

## If a Client Reports a Skin Concern

- Note what the client says, factually and in their own words.
- Do not diagnose the condition or advise on treatment.
- Do not apply makeup to an affected area if application would be unsafe.
- Advise the client to consult a qualified medical or dermatology professional.
- Record what happened and what you advised, briefly and factually.

---

*General checklist for education only. Follow the hygiene and product-safety rules that apply where you work.*
