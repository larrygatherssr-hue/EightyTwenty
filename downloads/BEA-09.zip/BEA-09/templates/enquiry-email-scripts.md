# Enquiry-to-Booking Email Scripts

Adapt these scripts to your own voice. Keep the structure: warm greeting, availability, price, what is included, and one clear next step. Replace every [ ] blank with your own details. Do not copy them word for word if they do not sound like you — rewrite them until they do, and then use the same version every time so every bride gets the same clear information.

---

## Script 1 — First Reply to a Bridal Enquiry

**Subject:** Your wedding date — [Date] — and bridal makeup details

Hi [Bride's name],

Thank you for getting in touch, and congratulations on your wedding.

I am available on [date], and I would love to help with your bridal makeup.

My bridal prices are:
- Bride on the wedding day: $[Amount], including lashes and a touch-up kit
- Each additional adult (bridesmaid, mother of the bride, or guest): $[Amount] per person
- Bridal trial: $[Amount], including a full application and a record of every product and shade we agree

[Travel within X miles/km is included. / Travel to your venue is an additional $[Amount].]

The next step is a trial, where we agree your look, test how it photographs and lasts, and plan your wedding-morning timings. Would you like me to hold your date while you decide? I can hold it until [date — seven days from now], and a booking fee of $[Amount] secures it after that.

Please let me know if you have any questions, or if you would like to find a trial date.

Warm wishes,
[Your name]
[Phone] / [Website or social profile]

---

## Script 2 — Follow-Up After No Reply (Send Once, After 3–5 Days)

**Subject:** Just checking in — [Date]

Hi [Bride's name],

I hope you are well. I am just checking in on my message about your wedding on [date].

Did you have any questions about the trial, the prices, or the wedding-day timings? I am happy to help, and there is no obligation.

If you have already booked with another artist, please let me know and I will release your date — no hard feelings at all.

Warm wishes,
[Your name]

---

## Script 3 — Confirming a Booking (After Deposit and Contract)

**Subject:** You are booked — [Date]

Hi [Bride's name],

Thank you — you are now booked for your wedding on [date].

Here is a summary:
- Services: [Bride plus X additional adults, as agreed]
- Total fee: $[Amount]
- Booking fee received: $[Amount] on [date]
- Balance of $[Amount] due by [date]
- Trial: [date, time, and place]
- Arrival on the wedding day: [time] at [address]

I will send your wedding-morning timeline two weeks before the wedding, and I will confirm it again in the final week.

Please keep this email somewhere safe, and let me know if anything changes.

I am looking forward to it.

Warm wishes,
[Your name]

---

## Script 4 — Trial Reminder and Preparation Note

**Subject:** Your trial on [date] — what to bring

Hi [Bride's name],

I am looking forward to your trial on [date] at [time] at [place].

To get the most from it, please:
- Arrive with clean, moisturised skin
- Bring photographs of looks you like — and any you do not like
- Bring your veil or hair accessory if you have one
- Wear a top in a similar colour to your dress, if you can

Please also let me know before we meet about any allergies or products you cannot use.

The trial takes about 90 minutes. We will agree your look together, photograph it in daylight and indoors, and write down every product and shade so the wedding day matches exactly.

See you then.

Warm wishes,
[Your name]

---

## Script 5 — After the Trial

**Subject:** Thank you — your trial and next steps

Hi [Bride's name],

Thank you for today. I loved creating your look, and I hope you are happy with it.

Here is what we agreed:
- Look: [Short description]
- Changes for the wedding day: [List, or "None — we will repeat the trial look"]
- Wedding-day arrival: [Time] at [Address]
- Balance of $[Amount] due by [Date]

If you would like any changes, please let me know before the wedding so I can plan for them.

Thank you for trusting me with your wedding morning.

Warm wishes,
[Your name]

---

## Script 6 — Price Question / "Can You Do It Cheaper?"

Hi [Bride's name],

Thank you for asking. My prices reflect the trial, the products, the travel, the wedding-morning time, and the preparation that goes into making your makeup last all day and photograph well.

I do not offer discounts on bridal bookings, because every bride receives the same care, products, and time. If the full party is beyond your budget, I am happy to help you find an option that fits — for example, makeup for the bride alone, or a trial only — and I can also recommend a colleague if that would help.

Please let me know what you would like to do.

Warm wishes,
[Your name]

---

## Script 7 — Date Not Available

Hi [Bride's name],

Thank you for getting in touch, and congratulations on your wedding.

I am sorry, but I am already booked on [date]. I would not want to keep you waiting, so I wanted to let you know straight away.

[Optional: I can recommend a colleague I trust — [Name, contact] — who may be available.]

I wish you a wonderful wedding day.

Warm wishes,
[Your name]

---

*General templates for education only. Adapt prices, terms, and wording to your own business and local requirements.*
