# Bridal / Booking Contract — General Template

> **Important — read this first.** This is a general educational template, not legal advice, and it is not a substitute for advice from a qualified solicitor or attorney in your area. Have it reviewed by a qualified legal professional and adapted to the laws where you work before you use it with paying clients. Fill in every blank marked [ ]. Delete any clause that does not apply, and do not rely on this template for any booking until it has been reviewed locally.

---

**Makeup Artist:** [Your full business name]
**Contact:** [Phone] / [Email] / [Website or social profile]

**Client:** [Client full name]
**Contact:** [Phone] / [Email]
**Address:** [Client address, if needed for travel]

**Date of this agreement:** [Date]

## 1. Services

The Artist agrees to provide makeup services as follows:

- **Event:** [Wedding / occasion / photoshoot / lesson]
- **Date:** [Date]
- **Getting-ready address:** [Address]
- **Arrival time:** [Time]
- **Bride / main client ready by:** [Time]
- **People included:** [Number] — Names and roles: [List]
- **Services included:** [For example: bridal makeup including lashes and touch-up kit; makeup for 4 additional adults]
- **Trial:** [Included / separate — date, time, and place, if agreed]

Any additional people, locations, or services requested after this agreement is signed will be charged at the Artist's standard rates, if the Artist's schedule allows.

## 2. Fees

- **Total fee:** $[Amount]
- **Booking fee (deposit):** $[Amount], due on [Date], to secure the date. The booking fee is deducted from the total fee.
- **Balance:** $[Amount], due on [Date — for example, four weeks before the event].
- **Included travel:** [Distance / area included in the fee]
- **Additional charges:** Early start before [7 a.m.]: $[Amount]. Travel beyond the included area: $[Amount] per mile/km. Extra location: $[Amount]. Stay for touch-ups: $[Amount] per hour.

Payment methods accepted: [Bank transfer / card / cash — list what you accept].

## 3. Booking Fee and Cancellation

The booking fee is non-refundable, because the Artist holds the date and turns other work away. Please read this section carefully before signing.

- If the Client cancels, the booking fee is retained by the Artist. Any balance already paid will be refunded, less the booking fee and less any costs already incurred.
- If the Client postpones to a new date on which the Artist is available, the Artist will transfer the booking fee to the new date where reasonably possible.
- If the Artist must cancel because of illness or emergency, the Artist will refund all money paid and, where reasonably possible, help the Client find a replacement artist. The Artist's liability is limited to the refund of money paid under this agreement.

## 4. Trial

If a trial is booked, it is charged at $[Amount] and is payable at the time of the trial / at booking [delete as applicable]. The trial is an opportunity to agree the look, products, and timings. Changes agreed at the trial will be recorded on the trial form and followed on the day where reasonably possible.

## 5. Client Responsibilities

The Client agrees to:

- Arrive with clean, moisturised skin, unless the Artist advises otherwise.
- Tell the Artist before the trial about any allergies, sensitivities, or skin concerns, and about any products they cannot use.
- Make sure all people receiving makeup are present at the agreed times, so the schedule can be kept.
- Provide a suitable work area, including a table, chairs, natural light or good lighting, and access to power, where reasonably possible.

The Artist will not diagnose any skin condition or give medical advice. If a Client reports a skin condition, allergy, infection, or medical concern, the Artist may decline to apply makeup to the affected area and may advise the Client to consult a qualified medical or dermatology professional.

## 6. Hygiene

The Artist will follow professional hygiene practice, including clean brushes for each client, disposable applicators for mascara and lip products, and products dispensed onto a clean palette rather than applied directly from containers.

## 7. Photographs

The Artist may take photographs of their work for portfolio and marketing use, with the Client's permission. The Client may decline, and declining will not affect the service in any way.

Photograph permission: Client initials — Yes [ ] / No [ ]

## 8. Conduct and Safety

Both parties agree to behave respectfully. The Artist may leave, and may end the service, if the working environment becomes unsafe or abusive. In that case the Artist will follow the cancellation terms in Section 3 as far as they reasonably apply.

## 9. Changes on the Day

Changes requested on the day — including additional people — will be accommodated only if time and schedule allow, and will be charged at the Artist's standard per-person rate.

## 10. Governing Law

This agreement is governed by the laws of [Your country / state]. Any dispute will be handled under those laws.

---

**Signed:**

Artist: ______________________________ Date: __________

Client: ______________________________ Date: __________

---

*General template for education only. Not legal advice. Have it reviewed locally before use.*
