# Onboarding Guide — Makeup Artist to Business Owner (BEA-09)

Welcome. This guide tells you what to do first, how to use the materials, and how to work through the programme without getting stuck.

## What You Have Bought

- **content.md** — the full programme: introduction, 8 modules, outcome summary, and appendices.
- **workbook.md** — the companion workbook with worksheets, trackers, and checklists.
- **templates/** — the bridal pricing calculator (CSV), contract template, trial booking form, enquiry email scripts, and kit inventory checklist.
- **cover.png** — the programme cover image.
- **sales-page.md** — the sales page text for this product (for the seller's reference; buyers do not need to act on it).

All files are standard formats (Markdown text and CSV) that open in any text editor or spreadsheet app. No special software is needed.

## What to Do First (Day 1)

1. **Read the disclaimer** at the top of `content.md`. This programme is business education only. Its templates are general educational templates, not legal advice, and they need local professional review before you use them with paying clients.
2. **Read the Introduction and Module 1.** Then do the Module 1 actions: the one-hour audit, your service menu, your positioning paragraph, and your minimum viable day rate. Use Worksheet 1 in the workbook.
3. **Open the pricing calculator** (`templates/bridal-pricing-calculator.csv`). Replace the example figures with your own costs and rates. The example numbers are teaching examples only.
4. **Book your weekly marketing hour** in your calendar — one hour, same time each week, for the next twelve weeks.

Do not try to read everything on day one. The programme works when you do the actions, not when you read quickly.

## How to Use the Materials

- **Read a module, then do its actions, then move on.** Each module ends with a short action list. A rough price list you actually use beats a perfect one you never finish.
- **Use the workbook alongside the text.** The modules refer to it by worksheet number. Print it, or copy its tables into a notebook or spreadsheet.
- **Use the templates with real clients.** Adapt the email scripts to your voice, fill in the trial form at every trial, and use the kit checklist monthly and at every booking.
- **Keep one folder per client** for the contract, trial form, intake worksheet, messages, and payment records.

## Suggested Schedule

**Four to eight weeks (around existing bookings) — recommended for most artists:**
- Week 1: Modules 1–2 (positioning, pricing) + pricing worksheet.
- Week 2: Modules 3–4 (bridal, contracts) + trial form and contract review arranged.
- Week 3: Module 5 (kit and hygiene) + kit audit and inventory.
- Week 4: Modules 6–7 (marketing, portfolio) + content plan and bio update.
- Weeks 5–8: Module 8 (growth) + 90-day plan, Friday reviews, and finishing any actions left over.

**Two focused weeks (if you have open days):**
- Days 1–3: Modules 1–2.
- Days 4–6: Modules 3–4.
- Days 7–9: Modules 5–6.
- Days 10–12: Modules 7–8.
- Days 13–14: Finish the workbook, review your numbers, and write your 90-day plan.

Either pace works. Finishing works better than rushing.

## A Note on the Contract Template

The contract template is a general educational template in plain English. Before you use it with a paying client, have it reviewed by a qualified solicitor or attorney in your area and adapt it to your local laws. Do not skip this step. The same applies to tax: consult an accountant or tax adviser for your own tax position.

## If a Client Reports a Skin or Health Concern

Do not diagnose it or advise on treatment. Note what the client says, factually, decline to apply makeup to an affected area if application would be unsafe, and advise the client to consult a qualified medical or dermatology professional.

## How to Get Support

Contact the seller through the EightyTwenty marketplace support channel for help with downloading or opening the files, questions about how to use the materials, and refund requests within the 14-day guarantee period (see the listing). Support does not include legal, tax, financial, or medical advice, and does not include one-to-one business coaching. For questions about contracts or local rules, consult a qualified local professional.

## Your First Win

Your first win is not a booking. It is a finished price list, built from your real numbers, that you are willing to say out loud. When you have that, the rest of the programme gets easier — and your business starts to pay like a business.
