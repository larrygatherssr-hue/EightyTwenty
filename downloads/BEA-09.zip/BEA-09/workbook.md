# Workbook — Makeup Artist to Business Owner: Bridal, Freelance & Studio Growth

## Education-Only Disclaimer

This workbook is business education only. It is not legal advice, tax advice, financial advice, or medical advice. The worksheets here help you organise your own numbers and plans. Have any contract or form you use with clients reviewed by a qualified legal professional in your area. Nothing in this workbook diagnoses, treats, or prevents any skin or health condition. If a client reports a skin condition, allergy, infection, or medical concern, do not diagnose it or advise on treatment — refer them to a qualified medical or dermatology professional.

Print this workbook or copy its tables into a notebook or spreadsheet. Fill it in as you work through the programme. A completed workbook is your business plan.

---

## Worksheet 1 — Business Audit (Module 1)

**Last three months — money**
- Total paid by clients: $__________
- Total spent on products: $__________
- Total spent on travel: $__________
- Total spent on insurance, phone, website, other business costs: $__________
- Money left after business costs: $__________

**Last three months — work**
- Number of jobs: __________
- Total hours worked (including messages, travel, set-up, admin): __________
- Best-paying job per hour: __________ — why? __________
- Worst-paying job per hour: __________ — why? __________
- Jobs that led to a rebooking or referral: __________

**Your time**
- Real hours per week you can give this business: __________
- Hours currently spent on admin/marketing per week: __________

**Your conclusion (two sentences):**


---

## Worksheet 2 — Pricing Worksheet (Module 2)

Complete one row per service. Use the formula: Price = direct costs + (total hours × hourly rate) + margin.

**Your numbers**
- My target hourly rate: $__________ per hour
- My minimum viable day rate: $__________ per day
- Margin I will add (suggested 10–20%): __________%

| Service | Product cost | Travel / other direct costs | Total hours (incl. admin & travel) | Hours × rate | Subtotal | + Margin | My price |
|---|---|---|---|---|---|---|---|
| Bridal — bride on the day | $ | $ |  | $ | $ | $ | $ |
| Bridal trial | $ | $ |  | $ | $ | $ | $ |
| Additional adult (per person) | $ | $ |  | $ | $ | $ | $ |
| Occasion makeup | $ | $ |  | $ | $ | $ | $ |
| Makeup lesson (1-to-1) | $ | $ |  | $ | $ | $ | $ |
| Photoshoot day rate | $ | $ |  | $ | $ | $ | $ |

**Packages**
- Package 1 name and contents: __________ — Price: $__________
- Package 2 name and contents: __________ — Price: $__________
- Package 3 name and contents: __________ — Price: $__________

**Minimums and add-ons**
- Peak Saturday minimum total: $__________
- Early start fee (before 7 a.m.): $__________
- Travel beyond included radius (per mile/km): $__________
- Extra location fee: $__________
- Stay for touch-ups fee: $__________
- Included travel radius: __________ miles/km

**Discount policy (write it in one paragraph):**


---

## Worksheet 3 — Bridal Booking Tracker (Modules 3, 4, 6)

Copy this table for each month. One row per enquiry.

| Date enquired | Bride name | Wedding date | Service / party size | Price quoted | Reply sent | Follow-up sent | Deposit received | Contract signed | Trial date | Balance due | Balance paid | Outcome |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|  |  |  |  | $ |  |  |  |  |  |  |  |  |
|  |  |  |  | $ |  |  |  |  |  |  |  |  |
|  |  |  |  | $ |  |  |  |  |  |  |  |  |
|  |  |  |  | $ |  |  |  |  |  |  |  |  |
|  |  |  |  | $ |  |  |  |  |  |  |  |  |

**Monthly review**
- Enquiries received: __________
- Bookings confirmed: __________
- Conversion rate (bookings ÷ enquiries): __________%
- Average booking value: $__________
- Enquiries lost to no reply (no follow-up sent): __________
- What I will change next month: __________

---

## Worksheet 4 — Kit Inventory Checklist (Module 5)

Count stock monthly. Record the date opened and the replacement date for each product.

| Product | Shade / variant | Quantity | Date opened | Replace by | Restock? |
|---|---|---|---|---|---|
| Foundation |  |  |  |  |  |
| Foundation |  |  |  |  |  |
| Concealer |  |  |  |  |  |
| Powder (setting) |  |  |  |  |  |
| Primer |  |  |  |  |  |
| Eyeshadow palette |  |  |  |  |  |
| Eyeliner |  |  |  |  |  |
| Mascara (use disposables — never share) |  |  |  |  |  |
| False lashes |  |  |  |  |  |
| Blush |  |  |  |  |  |
| Bronzer / contour |  |  |  |  |  |
| Highlighter |  |  |  |  |  |
| Lipstick / lip gloss |  |  |  |  |  |
| Setting spray |  |  |  |  |  |
| Brush cleaner / sanitiser |  |  |  |  |  |
| Disposable applicators |  |  |  |  |  |
| Cotton buds / tissues |  |  |  |  |  |
|  |  |  |  |  |  |

**Kit audit notes**
- Products expired or to discard: __________
- Shade gaps to fill: __________
- Total replacement value of kit: $__________
- Insurance current? Yes / No — renewal date: __________

---

## Worksheet 5 — Hygiene Checklist (Module 5)

Use at every booking. Tick each item. Do not skip steps when you are busy — busy days are when hygiene matters most.

- [ ] Hands washed and sanitised before the first client
- [ ] Hands sanitised between every client
- [ ] Clean brushes for every client (no shared brush without proper cleaning between clients)
- [ ] Disposable mascara wands — one per client, never reused or double-dipped
- [ ] Disposable lip applicators — one per client, never reused or double-dipped
- [ ] Creams and foundations dispensed onto a clean palette or sanitised hand, not applied straight from the container
- [ ] Pencils sharpened and wiped before each use
- [ ] Palette, work surface, and tools clean at the start of the booking
- [ ] Kit stored in clean, closed containers
- [ ] Waste disposed of; station left clean after the last client
- [ ] Any skin concern noted factually and client referred to a qualified professional where appropriate (no diagnosis or treatment advice given)

**Notes from today:**


---

## Worksheet 6 — Portfolio Planner (Module 7)

**Current portfolio audit**
- Strong images I am proud to show: __________
- Weak images to remove: __________
- Gaps (skin tones, ages, looks, occasions not yet shown): __________

**Shoot to fill the biggest gap**
- Look / client type: __________
- Model or client: __________
- Date: __________
- Photographs needed (front, angle, close-up, full look): __________

**Four-week content plan** — one finished-work post, one process post, one answer post, and one proof post per week.

| Week | Finished work | Process | Answer (question brides ask) | Proof |
|---|---|---|---|---|
| 1 |  |  |  |  |
| 2 |  |  |  |  |
| 3 |  |  |  |  |
| 4 |  |  |  |  |

---

## Worksheet 7 — Client Intake Worksheet (Modules 3 and 4)

Complete one per bridal client. Keep with the contract and trial form.

- Bride name: __________
- Contact (phone / email): __________
- Wedding date and time: __________
- Venue and getting-ready address: __________
- Number of people for makeup: __________
- Names and roles: __________
- Day-of contact (not the bride): __________ — Phone: __________
- Arrival time agreed: __________ — Bride ready by: __________
- Allergies or sensitivities (as stated by the client): __________
- Skin concerns noted (factual only — no diagnosis): __________
- Products to avoid (as stated by the client): __________
- Look agreed at trial: __________
- Products and shades used at trial: __________
- Changes agreed after trial: __________
- Total fee: $__________ — Booking fee paid: $__________ on __________
- Balance due: $__________ by __________
- Travel / early-start fees: $__________
- Photograph permission: Yes / No
- Notes: __________

---

## Worksheet 8 — 90-Day Action Plan (Module 8)

**Days 1–30: Foundations**
- [ ] Price list finished and published
- [ ] Contract adapted and sent for local legal review
- [ ] Trial process written (preparation note, form, follow-up)
- [ ] Kit audited and inventory started
- [ ] Bio and listings updated
- [ ] Referral partners contacted (names): __________
- [ ] Weekly marketing hour booked in calendar

**Days 31–60: Visibility**
- [ ] Four weeks of content published
- [ ] Every trial and wedding photographed (with permission)
- [ ] Every enquiry followed up once
- [ ] One portfolio-gap shoot completed
- [ ] Day-60 review: enquiries ____, conversion ____%, average booking $____, hours/week ____

**Days 61–90: Growth**
- [ ] One price reviewed and, if the diary supports it, raised for new enquiries
- [ ] One larger party taken with an assistant (or reason it did not happen): __________
- [ ] Next step decided: more bridal dates / lessons / studio feasibility check (circle one)
- [ ] Next 90-day plan written before this one ends

**Friday review (10 minutes, every week)**
- Enquiries this week: __________ — Bookings: __________ — Money in: $__________
- One thing that worked: __________
- One thing to change next week: __________

---

*Workbook companion to BEA-09. Business education only; see the disclaimer at the top of this document.*
