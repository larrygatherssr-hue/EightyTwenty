# BEA-09 — Makeup Artist to Business Owner: Bridal, Freelance & Studio Growth

**Price:** $297 — one-time payment
**Category:** Beauty & Health
**SKU:** BEA-09

A business-development programme for makeup artists covering bridal bookings, pricing, kit management, contracts, and building a freelance or studio business.

## Files in This Folder

- **content.md** — The full programme text: introduction, all 8 modules fully written, outcome summary, and appendices with worked pricing examples and a glossary. (10,275 words.)
- **workbook.md** — Companion workbook: business audit, pricing worksheet, bridal booking tracker, kit inventory checklist, hygiene checklist, portfolio planner, client intake worksheet, and 90-day action plan.
- **templates/bridal-pricing-calculator.csv** — Bridal pricing calculator with time, product, travel, and assistant costs.
- **templates/contract-template.md** — Plain-English booking/bridal contract template. General template requiring local legal review; not legal advice.
- **templates/trial-booking-form.md** — Bridal trial booking form, including product/shade record and agreed changes.
- **templates/enquiry-email-scripts.md** — Seven enquiry-to-booking email scripts, from first reply to follow-up, booking confirmation, trial notes, and handling price questions.
- **templates/kit-inventory-checklist.md** — Kit inventory checklist plus the hygiene checklist for every booking.
- **sales-page.md** — Full sales page: headline, problem, solution, what is inside, who it is for / not for, $297 price + 14-day guarantee, FAQ, and disclaimers.
- **listing.json** — Marketplace listing data (sku, name, category, price_cents 29700, billing one_time, headline, description, delivery note, SEO keywords, refund policy, support instructions).
- **cover.md** — Cover design brief (black-and-gold luxury palette, typography, imagery, layout).
- **cover.png** — The generated cover image (1280 × 1920 px PNG).
- **onboarding.md** — Customer onboarding guide: what to do first, how to use the materials, suggested schedule, and how to get support.

## Notes

- All content is original business education. No testimonials, sales figures, certifications, or reviews are fabricated, and no market data is invented. Worked examples use clearly labelled example figures.
- Education-only disclaimer appears in `content.md`, `workbook.md`, and `sales-page.md`. No medical advice is given; skin/health topics direct the reader to consult a qualified professional.
