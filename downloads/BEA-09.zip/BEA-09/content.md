# Makeup Artist to Business Owner: Bridal, Freelance & Studio Growth

## Education-Only Disclaimer

This programme is business education only. It is not legal advice, tax advice, financial advice, or medical advice. The contract and form templates included are general educational templates. Have them reviewed by a qualified solicitor or attorney in your area, and by an accountant or tax adviser for your own tax position, before you use them with paying clients. Nothing in this programme diagnoses, treats, or prevents any skin condition or health condition. If a client tells you about a skin condition, allergy, infection, or medical concern, do not diagnose it or advise on treatment. Refer them to a qualified medical or dermatology professional, and follow that professional's guidance about whether makeup application is appropriate. Always follow the hygiene and product-safety rules in Module 5, and check the regulations that apply to cosmetic services in your own country, state, and city, because licensing, insurance, and health rules differ by location.

---

## Table of Contents

- Introduction: From Talented Artist to Paid Professional
- Module 1 — The Business You Actually Have: Positioning, Identity, and Your First Numbers
- Module 2 — Pricing With Confidence: Day Rates, Bridal Packages, and Profitable Math
- Module 3 — Bridal, Start to Finish: Enquiries, Trials, Timelines, and the Wedding Morning
- Module 4 — Contracts, Deposits, and Boundaries That Protect You
- Module 5 — Your Kit, Your Hygiene, and Your Professional Standard
- Module 6 — Booking Consistently: Marketing That Fits a Working Artist
- Module 7 — Portfolio, Instagram, and the Content Plan That Books Brides
- Module 8 — Growing Beyond Yourself: Assistants, Studios, and a 90-Day Growth Plan
- Your Outcome: What Changes When You Finish
- Appendix A — Worked Pricing Examples
- Appendix B — Glossary

---

## Introduction: From Talented Artist to Paid Professional

You can do the makeup. That part is not the problem. The problem is everything around the makeup: the enquiry that never replies, the bride who asks for a discount before she has even booked a trial, the Saturday that earns less than the products you used, the month with no bookings at all, and the quiet feeling that you are working hard and still not getting ahead.

This programme is built for that gap. It is for the trained or self-taught makeup artist who is good at the craft and underpaid for it. Over eight modules you will rebuild the business side of your work, step by step, in the order you actually need it: first you decide what you sell and who it is for, then you price it so it pays, then you learn to run bridal work — the highest-value, highest-pressure work most freelance artists do — from first message to final touch-up. Then you protect yourself with contracts and deposits, run a kit that is clean, organised, and costed, and market yourself in a way that brings enquiries in every week, not only when someone happens to recommend you.

Nothing here requires you to become a different person, to post every day, or to spend money you do not have. It does require you to make decisions and write them down: your prices, your terms, your minimums, your working hours, and your plan for the next ninety days. Artists who do that work stop negotiating against themselves. They stop saying yes to jobs that lose money. They start booking brides who respect their terms, because clear terms are part of what makes a professional look professional.

How to use this programme: work through the modules in order the first time. Each module ends with actions. Do them before you move on, even if your first version is rough. A rough price list you actually use beats a perfect one you never finish. Use the workbook alongside the text — it holds the worksheets, trackers, and checklists the modules refer to — and use the templates folder for the documents you will send to real clients. Give yourself four to eight weeks to complete the programme if you are working around clients, or two focused weeks if you have open days. Either pace works. Finishing works better than rushing.

A note on numbers: every worked example in this programme uses clearly labelled example figures. They are teaching examples, not promises and not market data. Your real prices must come from your own costs, your own time, and the market where you actually work. The formulas are the point; the example numbers are only there so you can see the formulas working.

---

## Module 1 — The Business You Actually Have: Positioning, Identity, and Your First Numbers

### 1.1 Start with an honest audit

Before you change anything, write down where you are. Most artists skip this step because it feels uncomfortable, and then they spend months fixing the wrong problem. Take one hour, a notebook, and your phone, and answer these questions in writing.

First, your money. Look at the last three months. How much did clients actually pay you, after refunds and discounts? How much did you spend on products, travel, insurance, and anything else for the business? How many jobs did you do, and how many hours did each one take, including travel, messages, trials, and set-up? Do not guess. Open your bank statements, your messages, and your calendar. If the answer is "I don't know," that is useful information: it tells you that your first business system is a simple record of money in, money out, and hours worked.

Second, your work. Which jobs paid best per hour? Which ones left you tired, late, or resentful? Which clients rebooked, referred friends, or left kind reviews — and which ones haggled, arrived late, or asked for extra people at the last minute? Patterns live in those answers. An artist who earns well from bridal trials and poorly from last-minute party makeup is not failing at party makeup; she is learning where her profitable work is.

Third, your time. How many hours a week can you honestly give this business, including admin and marketing, without burning out? An artist with fifteen hours a week needs a different plan from one with forty. Write the real number down. Plans built on fantasy hours collapse in week two.

### 1.2 Choose what you sell — and what you do not

A freelance makeup business usually sells a small number of services. Trying to sell everything to everyone is the fastest way to be forgettable. Choose a core offer and build around it.

For most artists reading this programme, the core offer is bridal makeup, because it is the highest-value regular work: a bride books months ahead, pays a deposit, usually brings a party, and cares deeply about the result. Around it, you can offer trials, bridesmaid and guest makeup, occasion makeup, lessons, and photoshoot work. You do not have to offer all of them. In fact, you should not, at least not yet. Pick the two or three services you enjoy, do well, and can price profitably, and make those your menu. Everything else is a polite no, or a referral to a colleague.

Write your service menu now, in one page. For each service, write one sentence describing who it is for and what is included. Example: "Bridal makeup — for the bride on her wedding day, including lashes, touch-up kit, and travel within 20 miles." If you cannot describe a service in one sentence, you do not yet understand what you are selling, and your clients will not either.

### 1.3 Positioning: why a bride chooses you

Positioning is simply the reason a client picks you instead of the artist she saw first. It is not your logo. It is the clear, specific promise in your work. Three questions decide it.

Who is your ideal client? Be specific. "Brides" is not specific enough. "Brides in their late twenties and thirties who want a polished, natural look that lasts all day and photographs well" is a client you can speak to, photograph for, and price for. "Brides who want bold, glamorous, full-coverage looks for large weddings" is a different client, and a different business. Neither is better. But you must choose, because your portfolio, your prices, and your words will all point at one of them.

What do you do differently? This does not have to be dramatic. It can be your trial process, your calm manner on a wedding morning, your experience with a particular skin tone range, your longevity, or your reliability. Ask three past clients what they valued most. Their words are often more useful than your own, because clients describe the experience, and artists describe the technique.

What do you not do? Saying no is positioning too. An artist who does not do 5 a.m. starts without a fee, does not travel more than an hour, or does not take bookings with fewer than three people is not being difficult. She is running a business with limits, and limits are what make a business sustainable.

Write a one-paragraph positioning statement and keep it where you can see it. It might read: "I am a bridal makeup artist for brides who want to look like themselves, only more polished, and to still look that way at midnight. I work with a small number of weddings each month so every bride gets a calm, unhurried morning and a trial that settles every detail in advance." That paragraph now guides your portfolio, your Instagram bio, and every enquiry reply.

### 1.4 Your first numbers: the minimum you must earn

Before Module 2 teaches pricing in full, you need one number now: your minimum viable day rate. This is the lowest amount you can accept for a full working day without losing money or resenting the work.

Work it out like this. Add up your monthly business costs — products used, insurance, travel, phone, website, and a small amount set aside for replacing kit — and add the monthly amount you need the business to contribute to your living costs. Divide that total by the number of paid working days you can realistically book in a month. The result is your floor. It is not your price; it is the line below which you say no, or you change the job until it clears the line.

Example, clearly labelled as an example: monthly business costs $400, living contribution needed $1,600, total $2,000. Realistic paid days per month: 8. Floor: $2,000 divided by 8 = $250 per paid day. Any job that pays less than $250 for a full day, after costs, is not a job; it is a hobby that costs you money. Short jobs are different — a two-hour booking can be priced by the hour — but the floor stops you accepting full days at part-day prices.

If your floor shocks you, good. That shock is the programme working. Most undercharging is not a pricing problem; it is a not-knowing problem. Once you know your floor, every later decision gets easier.

### 1.5 The five systems every small makeup business needs

You do not need complicated software. You need five simple systems, and you need them written down so you use them the same way every time.

1. **Enquiries:** one place where every enquiry lands, one reply template, and one rule — every enquiry gets a reply within one working day.
2. **Bookings:** one calendar, one deposit rule, one contract, and one confirmation message.
3. **Money:** one account or one clear record for business money, one price list, and a weekly ten-minute check of what came in and what went out.
4. **Kit:** one inventory list, one hygiene routine, and one restock rule (covered in Module 5).
5. **Marketing:** one weekly action that puts your work in front of future clients (covered in Modules 6 and 7).

If any of these is currently "in my head" or "in my messages somewhere," that is your first fix. A business that lives in your head cannot grow, because you cannot hand it to an assistant, a colleague, or your future self on a busy Saturday.

### Module 1 Actions

1. Complete the one-hour audit: money in, money out, hours worked, best and worst jobs, real weekly hours.
2. Write your service menu: two or three core services, one sentence each.
3. Write your positioning paragraph and your ideal-client description.
4. Calculate your minimum viable day rate using the formula above, with your real numbers.
5. Set up your five systems in their simplest form: one enquiry inbox, one calendar, one money record, one kit list, one weekly marketing slot.

---

## Module 2 — Pricing With Confidence: Day Rates, Bridal Packages, and Profitable Math

### 2.1 Why artists undercharge

Undercharging rarely comes from kindness. It comes from four habits. First, pricing by what feels acceptable instead of what the work costs. Second, forgetting the invisible hours: messages, trials, travel, set-up, clean-down, and admin. Third, comparing your price to the cheapest artist you know instead of to the value you deliver. Fourth, fear — fear that a higher price means no bookings, when in practice a clear, confident price often brings better clients, because it signals professionalism.

Read that again: a price is not only a number. It is a message. A bride comparing two artists does not only compare prices; she compares confidence. The artist who states her price plainly, explains what is included, and asks for a deposit looks safer than the artist who apologises for her price and offers a discount before being asked.

### 2.2 The pricing formula: cost plus time plus value

Every price you set should pass through three checks.

**Cost:** what does this job cost you in products, travel, parking, tolls, and any assistant or second artist? Products are not free because you already own them. Every application uses product, and product must be replaced. Work out a per-application product cost for your main services. Weigh it or estimate it honestly: if a foundation bottle costs $48 and gives roughly 40 applications, that is $1.20 per application for foundation alone. Add primer, concealer, powder, eyes, lashes, lips, setting spray, and disposables. Many artists are surprised to find a full bridal application uses $12 to $25 of product. Use the bridal pricing calculator in the templates folder to build this up line by line, and update it whenever a product price changes.

**Time:** how many hours does the job take in total, not just the time with the brush in your hand? A bridal booking that looks like three hours of makeup is often six hours of work once you count the enquiry, the trial, messages, travel, set-up, and clean-down. Price the whole job, not the visible part.

**Value:** what is this worth to the client? A wedding happens once. The photographs last for decades. A bride is not buying forty-five minutes of makeup; she is buying confidence on the most photographed day of her life, and the certainty that her makeup will last from the first photograph to the last dance. That value is real, and it belongs in your price. Value does not mean charging whatever you like; it means refusing to price once-in-a-lifetime work as if it were a quick errand.

A simple formula to hold in mind: **Price = (product cost + travel and other direct costs) + (total hours × your hourly rate) + a margin for skill, risk, and business costs.** Your hourly rate should be at least your minimum viable day rate divided by the hours in a working day, and usually higher, because skilled freelance work is not paid at the same rate as employed work — you carry the risk, the costs, and the gaps between bookings.

### 2.3 Worked example: building a bridal price

This is a teaching example with invented round numbers. Replace every figure with your own.

Imagine you charge for a bride alone, on the wedding day, without a trial. Your costs: products $18, travel $25 (fuel and parking), disposables $4. Total direct costs: $47. Your time: 30 minutes of messages and admin, 60 minutes of travel there and back, 30 minutes of set-up and clean-down, 75 minutes of application. Total: 3 hours 15 minutes, call it 3.25 hours. Your target hourly rate: $65. Time cost: 3.25 × $65 = $211.25. Add direct costs: $258.25. Add a margin for business costs, insurance, and the risk of a date held in your diary for months: 15 percent, about $39. Total: about $297. Rounded to a clean price: **$295 for the bride alone on the day**.

Now add the trial. A trial is a separate service: 90 minutes of application plus messages and set-up, with its own product cost. Using the same rate, a trial might price at $95 to $125. Many artists charge the trial separately and deduct nothing from the wedding day, or deduct a small amount when the bride books. Either is fine; what matters is that the trial is not free, because a free trial is unpaid skilled work, and it attracts clients who were never going to book.

Now add the party. Each additional adult — bridesmaid, mother of the bride, guest — takes 45 to 60 minutes, uses $10 to $15 of product, and is priced per person. In this example, $85 per additional adult is a clean, profitable figure. Four bridesmaids at $85 is $340, plus the bride at $295, plus the trial at $110: a wedding booking worth $745 before travel beyond your included radius or an early start fee. That is the difference between a price list built from formulas and one built from feelings. The feelings list would have said "$150 for the bride, $50 per bridesmaid" and left you earning less than your costs on a twelve-hour day.

See Appendix A for three more worked examples: a small wedding party, a large wedding party with an assistant, and a non-bridal occasion booking.

### 2.4 Packages, minimums, and add-ons

Packages make decisions easier for clients and income more predictable for you. Build two or three, not ten. A useful structure:

- **The Bride Alone:** bride only, on the day, plus a trial booked separately.
- **The Bridal Party:** bride plus three or more additional adults, trial included for the bride, touch-up kit included.
- **The Full Morning:** bride plus party, trial, early start, travel, and a second artist or assistant, priced as one number so the bride does not have to do the maths.

Set a **minimum booking** for peak dates. On Saturdays in wedding season, a single one-person booking that blocks your whole morning may cost you a full party booking. A minimum — for example, a minimum total of $450 on Saturdays from April to October, or a minimum of bride plus two — protects your diary. State it on your price list. Clients respect a stated minimum far more than a last-minute "actually, I need to charge more."

Add-ons are priced extras, not free favours: early starts before 7 a.m., travel beyond your included radius, a stay for touch-ups after the ceremony, false lashes beyond a standard set, tattoo cover, or a second location. Price each one, list it, and charge it. Every free add-on trains clients to expect free add-ons.

### 2.5 Raising prices without losing your clients

Raise prices in steps, with notice, and never apologise for them. A practical method: raise prices for new enquiries first, honour existing bookings at the price they booked at, and tell your regular clients one month before a change takes effect. A short message is enough: "From 1 September my bridal price will be $325. All bookings confirmed before then stay at the current price."

Do not raise prices and add nothing. Pair a rise with something visible: a better trial experience, a touch-up kit, clearer communication, or a small improvement to your kit. Clients accept a rise when they can see what it pays for.

And do not lower your price to win a booking. If a bride says she cannot afford you, thank her, offer a smaller service that fits her budget — a trial only, or makeup for the bride alone without the party — or refer her to a colleague. A discount given in panic becomes your new price, and the next bride will expect it too.

### 2.6 Discounts, friends, and family

Decide your discount policy before anyone asks. A workable policy: no discounts on bridal work; one clearly defined offer per year at most (for example, a weekday discount in your quiet season); friends and family pay a stated rate — many artists use a fixed "friends and family" price that is lower than full price but never free — and you do a fixed number of free or reduced jobs per year, chosen by you, for portfolio or charity, and no more. Write it down. When the policy is written, you do not have to decide under pressure. You just follow it.

### 2.7 Day-rate math for non-bridal work

Photoshoots, lessons, and events are often priced by the day or half day. Use the same formula. Example: a photoshoot day, 9 a.m. to 5 p.m., with two models and touch-ups through the day. Direct costs $40. Hours: 8 on set plus 1.5 travel and set-up, 9.5 total. At $65 an hour, time cost $617.50. Add costs and a margin, and a day rate of $700 to $750 is the honest figure. If the client offers $300 for the day, you now know exactly why you are declining: it pays less than half your rate, before costs. That clarity is the whole point of pricing math. You can still accept a low-paid job if it serves a clear purpose — a portfolio piece, a connection, a cause you support — but you will accept it as a choice, not by accident.

### Module 2 Actions

1. Build your product cost per application for bridal, occasion, and trial services using the calculator.
2. Calculate your hourly rate from your minimum viable day rate, then set your target hourly rate.
3. Price your core services with the formula: costs + (hours × rate) + margin.
4. Write your price list with two or three packages, a peak-date minimum, and priced add-ons.
5. Write your discount and friends-and-family policy in one paragraph.

---

## Module 3 — Bridal, Start to Finish: Enquiries, Trials, Timelines, and the Wedding Morning

### 3.1 The enquiry: reply fast, reply well

Most brides enquire with three or four artists at once. The first useful reply often wins, not the cheapest. Your enquiry system should do four things within one working day: thank her, confirm you are available on her date (or say honestly that you are not), give her the price for what she asked about, and give her one clear next step.

A reply that works looks like this: a warm greeting, one line confirming availability, the price for the bride and for each additional person, what the trial costs and what it includes, and a question — "Would you like me to hold your date while you decide, and shall we find a trial date?" Do not send your whole life story. Do not send a price with no context. Do send the price, because hiding it wastes both of your time and makes you look uncertain.

Hold dates carefully. A date held without a deposit is a date you cannot sell to anyone else. A fair rule: hold a date for seven days while a bride decides, then release it. Tell her so, kindly, in writing. "I can hold Saturday 12 June for you until Friday. After that I will need the booking fee to keep it held." Brides respect this. It tells them other brides want your dates too.

Use the enquiry email scripts in the templates folder and adapt them to your voice. Keep the structure; change the words until they sound like you.

### 3.2 The trial: where bookings are won

The trial is the most important hour in bridal work. It is where a nervous bride decides she can trust you, and where you learn everything you need for the wedding day. Treat it as a professional appointment, not a casual practice run.

Before the trial, send a short preparation note: arrive with clean, moisturised skin, bring photographs of looks you like and do not like, bring your veil or hair accessory if you have one, and wear a top in a similar colour to your dress. Ask about allergies, skin sensitivities, and any products she cannot use. Record the answers on the trial form. If she reports an allergy or a skin condition, do not diagnose or advise on treatment; note it, choose products accordingly, and if you are unsure whether application is appropriate, advise her to consult a qualified professional.

During the trial, do three things that most artists skip. First, listen before you start: ask what she wants to look like, what she dislikes in photographs of herself, and what her dress, venue, and time of day are. A garden wedding at noon and a candlelit evening wedding need different looks. Second, photograph the finished look in daylight and indoors, front and side, and agree together what to change. Third, write everything down: every product, every shade, every change. The trial form in the templates folder exists for exactly this. On the wedding morning, you will not remember the shade from three months ago. The form will.

After the trial, send a short follow-up within a day: thank her, confirm what you agreed, confirm the wedding-day timings, and confirm the remaining balance and its due date. This message prevents most wedding-morning surprises.

Charge for trials, as Module 2 explains. A bride who pays for a trial values it. A bride who books a free trial with four artists values none of them.

### 3.3 Timelines: planning the wedding morning backwards

A wedding morning runs on a timeline, and the makeup artist is often the person holding it together. Build every timeline backwards from the time the bride must be ready — usually thirty to forty-five minutes before the ceremony, to allow for photographs and dressing.

Worked example: ceremony at 2 p.m. Bride ready by 1:15 p.m. Bride's makeup takes 75 minutes, so it starts at noon. Four bridesmaids at 50 minutes each is 200 minutes, so they start at 8:40 a.m. Add fifteen minutes of set-up before the first face and a short break, and you are arriving at 8:15 a.m. That is a realistic timeline. The unrealistic version — arriving at 10 a.m. for five faces before a 2 p.m. ceremony — is how wedding mornings go wrong.

Send the timeline to the bride two weeks before the wedding, and confirm it again the week of the wedding. Include arrival time, order of faces, who needs to be where and when, and what you need: a table near natural light, two chairs, and access to power. Ask for the names and contact number of one person who is not the bride — the maid of honour or a family member — so that on the day, if someone is late, you are not asking a bride in a robe to chase her own bridesmaids.

### 3.4 The wedding morning: calm is a service

On the morning, your manner is part of what the bride paid for. Arrive early, set up quietly and efficiently, and greet the room warmly. Work in the order on your timeline. Keep your kit organised so you are not searching for a brush while the clock runs. Keep conversation light and calm; the room will take its mood from you.

Plan for the usual problems. Someone will be late. Someone will arrive with no skincare on, or with a spray tan that changes her foundation shade, or with a photograph of a look that is nothing like the trial. Stay calm, adapt where you safely can, and do not let one change unravel the timeline. If the schedule slips, tell the bride early and plainly, and offer a solution: shorten the last faces slightly, or ask your assistant to start the next person.

Take a photograph of the finished bride in good light, with her permission, for your portfolio. Leave a touch-up kit with the bride or maid of honour: lipstick or gloss, blotting papers, and a small powder, labelled and explained in thirty seconds. Then leave on time. Staying late for unpaid touch-ups is kind once; as a habit, it is unpaid work.

### 3.5 After the wedding

Send a short thank-you message the next day, and ask — once, politely — whether she would be happy to leave a review or let you share a photograph. Do not chase. A bride who loved her morning will often tag you herself. Record the booking in your tracker: what you earned, what it cost, how long it took, and what you would change. That record is how your next wedding goes better than your last.

### Module 3 Actions

1. Write your enquiry reply template and your seven-day hold rule.
2. Build your trial process: preparation note, trial form, follow-up message.
3. Practise building a timeline backwards from a 2 p.m. ceremony for a party of five.
4. Write your wedding-morning checklist: what you bring, what you need in the room, who your day-of contact is.

---

## Module 4 — Contracts, Deposits, and Boundaries That Protect You

### 4.1 Why a contract is kindness, not suspicion

New artists often avoid contracts because they feel unfriendly. The opposite is true. A contract is a written agreement about what will happen, what it costs, and what happens if plans change. It protects the bride as much as it protects you: she knows exactly what she is paying for, when the balance is due, and what happens if she needs to change her date. Professionals use contracts. Amateurs rely on messages and hope.

Use a contract for every bridal booking and every booking above a value you set — many artists use contracts for all bookings over a modest threshold, and a simple booking confirmation for smaller ones. The contract template in this programme is a general educational template. Have it reviewed by a qualified legal professional in your area before you use it, and adjust it to your local laws.

### 4.2 What a good booking contract covers

Your contract should cover, in plain language: the services and the date, time, and location; the total fee and what is included; the booking fee (deposit) and when it is due; when the remaining balance is due; what happens if the client cancels or postpones; what happens if you are ill or unable to attend; travel and early-start fees; the number of people included and the charge for additional people; the trial terms; and a short clause about photographs — whether you may share images of your work, and that the client can decline.

Write it in plain English. A contract your client cannot understand is a contract that will cause an argument. Short sentences, clear headings, no unnecessary legal language. The template in this programme is written that way on purpose.

### 4.3 Deposits: the rule that changes everything

Take a booking fee — a deposit — for every bridal booking, and take it before you hold the date beyond your seven-day hold. A common structure is a non-refundable booking fee of 25 to 50 percent of the total, with the balance due two to four weeks before the wedding. The exact percentage is your choice; the principle is not negotiable. A booking without a deposit is not a booking. It is a pencilled hope, and it will be cancelled the week another artist offers a lower price.

Explain the deposit plainly in your enquiry reply: "To secure your date I take a booking fee of $150, which comes off your total. The remaining balance is due four weeks before your wedding." Brides understand this. They pay deposits to venues, photographers, and dress shops. Yours is no different.

Keep deposit money separate in your records, and know your own cancellation terms before you need them. A fair and common approach: the booking fee is non-refundable because you turned other work away to hold the date; if the client postpones to a date you are free, you transfer the fee; if you must cancel, you refund in full and help her find a replacement if you can. Whatever you choose, write it in the contract and apply it consistently. Inconsistent terms are where disputes begin.

### 4.4 Boundaries: hours, travel, and last-minute changes

Boundaries are the daily version of a contract. Decide them now, write them down, and enforce them kindly.

**Hours:** state your working hours and your reply times. You do not need to answer messages at midnight. A reply within one working day is professional. An auto-reply outside hours is better than a resentful midnight reply.

**Travel:** state your included travel radius and your charge beyond it, and your early-start fee. Travel time is working time. A two-hour drive each way is four hours of your day, and it belongs in the price.

**Last-minute changes:** state your rule. A common one: additional people can be added up to seven days before the wedding if your schedule allows, at the standard per-person price; changes on the day are accommodated only if time allows and are charged at the same rate. This prevents the wedding-morning surprise of three extra faces and no extra time or pay.

**Behaviour:** you have the right to a safe, respectful working environment. If a client or guest is abusive, you may leave, and your contract should say so in plain language. This is rare, but writing it down means you do not have to decide in the moment.

### 4.5 When things go wrong

Even careful artists have bad days: illness, a family emergency, a car that will not start. Have a plan before you need it. Keep a short list of two or three trusted colleagues who could cover for you, and agree with them in advance that you would do the same for them. Tell the client as early as you can, in person by phone rather than by message, refund or rearrange as your contract provides, and help her find a replacement. How you handle a problem is often what a client remembers most. A calm, honest, fast response preserves your reputation; silence destroys it.

Keep records of every booking: the contract, the messages, the payments, and the trial form. If a dispute ever arises, records matter more than memory. Save them in one folder per client, and keep them for at least as long as your local rules require.

### Module 4 Actions

1. Adapt the contract template to your services, prices, and local requirements, and arrange a local legal review.
2. Set your deposit structure: percentage, due dates, and cancellation and postponement terms.
3. Write your boundary rules: hours, travel, early starts, last-minute changes.
4. Make your cover list of two or three colleagues and agree mutual cover in principle.

---

## Module 5 — Your Kit, Your Hygiene, and Your Professional Standard

### 5.1 Your kit is a business asset

Your kit is not a collection of products you like. It is a business asset that must earn its keep. Every product in it should have a reason: it serves a client you actually book, in a shade range you actually need, and it is used often enough to justify its cost and its space. A kit full of products you never use is money sitting in a bag.

Audit your kit once, properly. Lay everything out. Check expiry dates and discard anything expired, separated, smelling unusual, or past its recommended period after opening. Group products by step — skin preparation, base, eyes, cheeks, lips, setting — and note what is missing for the clients you serve. Do you have a full shade range for the skin tones you work with? Do you have options for sensitive or reactive skin? Do you have enough lashes, disposables, and tools for a party of six without washing brushes mid-morning?

Cost your kit. Add up what it would cost to replace it. That number is your asset value, and it belongs in your business records. It also tells you why insurance matters: a stolen or damaged kit is a business-ending event for an uninsured artist, and a recoverable one for an insured artist. Check what insurance is available and required where you work, including public liability cover, and keep the policy current.

### 5.2 Hygiene: the standard your clients cannot see but must be able to trust

Hygiene is not a preference. It is the foundation of professional makeup work. A client trusts you with her face on her wedding day. That trust is earned by visible, consistent hygiene, every time, with every client.

The rules are simple and non-negotiable. Wash and sanitise your hands before every client, and between clients. Use clean brushes for every client — never use the same brush on two people without cleaning it properly in between, and carry enough brushes for a full party. Use disposable applicators for mascara, lip products, and anything that touches eyes or lips, and never double-dip. Dispense creams, foundations, and lip products onto a clean palette or the back of a sanitised hand, never straight from the container onto a client's face. Sharpen pencils before each use and wipe them with a suitable sanitiser. Keep your kit, your palette, and your work surface clean, and keep your tools in clean, closed containers.

If a client has a visible skin infection, cold sore, conjunctivitis, or any condition that makes application unsafe, do not apply makeup to the affected area, and advise the client to consult a qualified medical professional. This is not a diagnosis; it is a safety boundary. Record what happened and what you advised, briefly and factually. Do not attempt to treat the condition, and do not use products to cover a condition in a way that could spread infection or cause harm.

Carry a small hygiene kit separately from your main kit: hand sanitiser, brush cleaner, disposable applicators, cotton buds, tissues, and a small waste bag. Clean as you go, not only at the end of the day. A tidy station looks professional, photographs well, and keeps you fast.

### 5.3 Kit management: inventory, restocking, and cost control

Use the kit inventory checklist in the templates folder. Count your stock monthly, or after every large booking. For each product, record the shade, the quantity, the date opened, and the date it should be replaced. Set a restock rule: when a core product falls below a set level — for example, one backup remaining — order a replacement. Never discover on a wedding morning that you are out of your most-used foundation shade.

Control costs by buying for use, not for desire. Before you buy a new product, ask: which client, which service, and how many uses will it serve? A product that serves one look for one client is a luxury; a product that serves twenty clients is an investment. Track your product cost per application, as Module 2 explains, and review it every three months. If a product's cost per use is high and its bookings are low, it is a candidate for removal.

Store products correctly: away from heat and sunlight, lids closed, and in the conditions the manufacturer recommends. Heat and sunlight shorten the life of products and can change their performance. Check your storage the same day you do your inventory.

### 5.4 Your professional standard, in writing

Write a one-page professional standard for yourself. It covers your hygiene routine, your arrival time (aim to arrive fifteen minutes before your set-up time), your dress code (clean, practical, professional, and comfortable enough to work in for hours), your phone use (silent, and never used for personal scrolling while a client is in your chair), and your conduct (punctual, calm, respectful, and discreet). Share the relevant parts with assistants when you start working with them in Module 8. A written standard is what turns a good artist into a reliable business.

### Module 5 Actions

1. Audit your kit: discard expired products, group by step, note gaps in shade range and quantity.
2. Cost your kit and check your insurance cover.
3. Write your hygiene routine as a checklist and use it at every booking.
4. Set up your inventory system and your restock rule, and do your first monthly count.
5. Write your one-page professional standard.

---

## Module 6 — Booking Consistently: Marketing That Fits a Working Artist

### 6.1 The real marketing problem

Most artists do not have a marketing problem. They have a consistency problem and a clarity problem. They post three times in one week, then nothing for a month. They post a photograph with no caption, no price, no next step, and no reason for a bride to message them. Then they conclude that marketing does not work.

Marketing that books brides is simple, and it is mostly repetition: the same clear message, shown to the right people, often enough that they remember you when they are ready to book. Brides often book six to twelve months before a wedding. That means the bride who books you in June may have first seen your work in January. Consistency over months matters more than any single post.

### 6.2 Your marketing, in three parts

**Part one: be findable.** A bride who has heard your name should be able to find you in one search and understand in ten seconds what you do, where you work, and how to enquire. That means your Instagram bio, your Google business listing if you have one, and any directory listing should all say the same thing: bridal makeup artist, your area, and a link or button to enquire. Check all three today. If any of them is out of date, fix it before you post anything new.

**Part two: be referable.** Most bridal bookings come from recommendations: past brides, photographers, hair stylists, venues, and wedding planners. Build those relationships deliberately. After a wedding, thank the photographer and the hair stylist, and share their work with credit. Offer a simple referral arrangement with a small number of trusted professionals — not a payment for every referral, which can create awkward obligations, but a genuine mutual recommendation between people whose work you trust. Keep a list of your referral partners and contact them a few times a year, not only when you need something.

**Part three: be visible.** Post your work regularly, in the places your ideal client actually looks. For most bridal artists that is Instagram first, then a search listing or a website, then word of mouth. You do not need to be everywhere. You need to be consistent in one or two places. Module 7 gives you the full content plan.

### 6.3 The weekly marketing hour

Set aside one hour a week for marketing, at the same time each week, and protect it. In that hour: reply to every enquiry and comment; post or schedule one piece of content; contact one referral partner or past client; and check your bookings for the next four weeks for gaps. That is the whole system. An hour a week, every week, beats a frantic weekend of posting once a quarter.

If you have no enquiries this week, use the hour to create: photograph a look on a model or a friend, write a caption that answers a question brides actually ask, or update your price list page. Marketing is not only posting. It is everything that makes the next enquiry more likely.

### 6.4 Enquiry follow-up: the bookings you are losing

A large share of lost bookings is not lost to a competitor. It is lost to silence. A bride enquires, you reply, she does not answer, and neither of you speaks again. Follow up, once, politely, a few days later: "Just checking in — did you have any questions about the trial or the wedding-day timings?" That single message recovers bookings. It also tells the bride you are organised and attentive, which is exactly what she wants on her wedding morning.

Track your enquiries in the workbook's booking tracker: date, name, wedding date, service, price quoted, reply date, follow-up date, and outcome. After a month, you will see your conversion rate — the share of enquiries that become bookings — and you will know whether your problem is too few enquiries or too few conversions. Those are different problems with different fixes, and guessing which one you have wastes time.

### 6.5 Pricing and marketing together

Your price and your marketing must agree. If your work looks premium and your price is low, clients will wonder what is wrong. If your price is premium and your photographs are poor, clients will not believe the price. Raise the quality of your photographs and your words at the same pace as your prices. That is why Modules 2, 6, and 7 belong together: price, visibility, and portfolio are one system, not three separate jobs.

### Module 6 Actions

1. Check and align your bio, search listing, and directory listings: same service, same area, same enquiry link.
2. List your referral partners — photographers, hair stylists, venues, planners — and contact two this week.
3. Book a weekly marketing hour in your calendar and protect it for the next twelve weeks.
4. Start your enquiry tracker and follow up every unanswered enquiry once, after three to five days.

---

## Module 7 — Portfolio, Instagram, and the Content Plan That Books Brides

### 7.1 Your portfolio is your shop window

A bride decides in seconds whether to enquire, and she decides from your photographs. Your portfolio — whether it lives on Instagram, a website, or both — must answer three questions fast: can this artist do the look I want, has she done it for brides like me, and does the makeup last and photograph well?

Build your portfolio deliberately. You need a range of looks, a range of skin tones and ages, and photographs taken in good light that show the makeup clearly. Close-ups matter more than wide shots for makeup, but include one or two full images so a bride can see the whole look. Remove weak photographs. A portfolio with twelve strong images books more brides than one with forty mixed ones. If you have gaps — for example, no photographs of mature brides, or no photographs on deeper skin tones — plan a shoot to fill them, using a model or a willing friend, and do the makeup exactly as you would for a paying client.

Always get permission before sharing a client's photograph, in writing if you can, and respect a no. A bride who declines is not rejecting you; she is exercising a choice your contract already gave her.

### 7.2 Instagram that works while you are working

Instagram rewards consistency and clarity, not volume. A profile that books brides has: a clear bio (what you do, where, for whom, and how to book), highlights that answer common questions (prices, trials, reviews, recent weddings), and a feed that shows your work, your process, and your personality in balance.

Use the content plan in the workbook. In brief, rotate four types of post: finished work (a bride or model, well photographed, with a caption that names the look and the occasion); process (a short video or photograph of your kit, your set-up, or a technique, which builds trust); answers (a post that answers a question brides ask, such as how long makeup lasts, or what to bring to a trial); and proof (a thank-you message, a review with permission, or a behind-the-scenes photograph from a wedding morning). One of each per week is a complete plan. You do not need to post daily.

Write captions that help a bride decide. Name the look, say who it suits, say how long it lasts, and end with one clear next step: "Enquire through the link in my bio for 2027 dates." A caption that only says "Beautiful bride" gives a bride nothing to act on.

### 7.3 Photographing your work

Good photographs are a skill, and they are worth learning. The essentials: natural daylight where possible, or a consistent ring light if you work indoors; a clean background; the client's face at eye level; photographs from the front and from a slight angle; and no heavy filter that changes the makeup colours. Take photographs before and after where the client agrees, because the comparison shows your skill more clearly than either image alone. Check the photograph before the client leaves — a blurred image discovered at home is a lost portfolio piece.

### 7.4 Content without burnout

Content creation burns artists out when it is treated as a daily emergency. Treat it as a batch job. Once a month, spend two hours creating four weeks of content: photograph two or three looks, write the captions, and schedule them. Then, during the week, you only need to reply to comments and messages. Batching is what makes a content plan sustainable for a working artist with clients, a kit, and a life.

Repurpose everything. One trial can produce a finished photograph, a short process video, a caption answering a trial question, and a story showing your kit. One wedding morning can produce a behind-the-scenes story, a finished bride photograph, and a thank-you post. You do not need new ideas every week. You need to use the work you are already doing.

### Module 7 Actions

1. Audit your portfolio: remove weak images, list the gaps, and plan one shoot to fill the biggest gap.
2. Rewrite your Instagram bio and highlights to answer: what, where, for whom, how to book.
3. Build your four-week content plan from the workbook's portfolio planner, and batch-create week one.
4. Set your photograph routine: daylight or ring light, front and angle, check before the client leaves.

---

## Module 8 — Growing Beyond Yourself: Assistants, Studios, and a 90-Day Growth Plan

### 8.1 When to grow

Growth is not a reward for being busy. It is a response to a specific problem: you are turning away bookings you want, you cannot cover large parties alone, or you have a waiting list for dates you cannot serve. If none of those is true, your next step is probably better pricing or better marketing, not growth. Growing too early adds costs and complexity to a business that is not yet stable.

The first growth step for most artists is an assistant or a second artist for large wedding parties. The second is a regular collaboration with a hair stylist. The third — much later, and only when the numbers support it — is a studio of your own.

### 8.2 Working with an assistant or second artist

An assistant makes a large party possible and a wedding morning calmer. Choose someone whose work you trust, whose hygiene standard matches yours, and who is reliable under pressure. Agree the terms in writing before the first job: the fee (a day rate or per-face rate), the hours, who supplies products, who is responsible if a client is unhappy, and how payment works. Pay promptly. A reliable assistant who is paid late once will not be available the next time you need her.

On the day, brief your assistant clearly: the timeline, who does which faces, the look for each person, and your professional standard from Module 5. Check her work before the client leaves, kindly and directly. After the job, debrief briefly: what went well, what to change. That short conversation is how a one-off assistant becomes a trusted team.

Cost your assistant into the price. In the worked example in Appendix A, a party of eight with an assistant is priced so that the assistant's fee, the extra products, and the extra time are all covered, with margin left over. If a job cannot cover an assistant, it is a job for one artist and a smaller party, not a job where you hope the assistant will work for less.

### 8.3 The studio question

A studio — your own room, a chair in a salon, or a shared space — is a large commitment. Before you sign anything, answer four questions in writing. How many bookings will the studio bring that you cannot already serve? What is the full monthly cost, including rent, utilities, insurance, and set-up? How many bookings at your current prices would cover that cost? And what happens in your quiet months? If the answers do not work on paper, they will not work in practice. A studio that costs $800 a month needs, at a $95 trial price, roughly nine extra trials a month just to break even — before products, travel, or your time. Do that maths first, with your real numbers, and revisit it every year.

Alternatives to a studio include renting a chair for trial days only, sharing a space with a hair stylist, or working from a well-presented home studio if local rules allow it. All three are legitimate. The right choice is the one your numbers support.

### 8.4 Lessons, courses, and other income

Once your bridal work is steady, you can add income that does not depend on Saturdays. Popular options: one-to-one makeup lessons, small group lessons, a short online course in your own specialism, or a "learn your own face" session for clients who will never book bridal work. Price these with the same formula from Module 2, and start small: one lesson format, one price, offered to your existing audience first. A lesson business built on your reputation is far easier than one built from scratch.

### 8.5 Your 90-day growth plan

Use the 90-day action plan in the workbook. In outline, it runs like this.

**Days 1–30: Foundations.** Finish your price list, contract, trial process, and kit audit. Update your bio and listings. Contact your referral partners. Set your weekly marketing hour. This month is unglamorous and essential. Do not skip it to post more photographs.

**Days 31–60: Visibility.** Publish your content plan for four weeks. Photograph every trial and wedding with permission. Follow up every enquiry. Fill one portfolio gap with a planned shoot. Review your numbers at day 60: enquiries, conversion rate, average booking value, and hours worked.

**Days 61–90: Growth.** Raise one price if your diary supports it. Take on one larger party with an assistant if the opportunity arises. Decide your next step — more bridal dates, lessons, or a studio feasibility check — based on your day-60 numbers, not on a feeling. Write the next 90-day plan before this one ends, so momentum does not stop.

Review the plan every Friday for ten minutes. A plan reviewed weekly gets finished. A plan written once and forgotten does not.

### Module 8 Actions

1. Decide honestly whether you are ready to grow, and which problem growth would solve.
2. Find and brief one assistant or second artist for large parties, with written terms.
3. If you are considering a studio, complete the four-question feasibility check with your real numbers.
4. Start your 90-day plan in the workbook, and book your first Friday review.

---

## Your Outcome: What Changes When You Finish

When you finish this programme and do the actions, you will have: a service menu you can explain in one sentence per service; prices built from your real costs and time, with packages, minimums, and add-ons; an enquiry system that replies within a day and follows up once; a trial process that wins bookings; a contract and deposit structure that protects your diary and your income; a clean, costed, organised kit; a weekly marketing hour and a four-week content plan; a portfolio that shows your best work to the brides you want; and a 90-day plan for what comes next.

That is a business, not just a talent. The makeup was never the problem. Now the business around it is built too.

---

## Appendix A — Worked Pricing Examples

All figures in this appendix are teaching examples with invented round numbers. Replace them with your own costs, rates, and market.

### Example 1: Small wedding party — bride plus two

Bride on the day $295, trial $110, two additional adults at $85 each ($170). Total $575. Direct costs: products about $45, travel $25, disposables $8 — $78. Time: enquiry and admin 1 hour, trial 2 hours including set-up, wedding day 5 hours including travel and set-up — 8 hours total. At a $65 hourly rate, time cost $520. Costs plus time: $598, before margin. This example shows why small parties need either a higher per-person price or a minimum booking: at these figures the booking is close to break-even. Options: raise the additional-adult price to $95, set a Saturday minimum of $650, or offer the small party on a weekday at the standard price and reserve Saturdays for larger parties.

### Example 2: Large wedding party — bride plus six, with an assistant

Bride $295, trial $110, six additional adults at $85 ($510), assistant fee $220, early start fee $50. Total charged: $1,185. Direct costs: products about $95, travel $40, disposables $15, assistant $220 — $370. Your time: admin and trial 3 hours, wedding day 7 hours — 10 hours at $65 is $650. Costs plus time: $1,020, leaving about $165 margin before business costs. This booking works because the assistant's fee is charged to the client, not absorbed by you, and the early start is priced. Without those two lines, the same booking would lose money.

### Example 3: Non-bridal occasion booking — one client, evening event

Occasion makeup $120, including lashes. Direct costs: products $12, travel $15 — $27. Time: messages 20 minutes, travel 40 minutes, set-up 15 minutes, application 60 minutes, clean-down 15 minutes — 2 hours 30 minutes at $65 is $162.50. Costs plus time: $189.50, so a $120 price loses about $70 on this job. The fix is not to work faster; it is to price the job at $175 to $195, or to offer occasion makeup only as an add-on to a bridal booking, or only in your studio where travel is zero. This is the example most artists need most: the small job that feels profitable and is not.

---

## Appendix B — Glossary

- **Booking fee (deposit):** the part-payment taken to secure a date, usually non-refundable, deducted from the total fee.
- **Trial:** a full makeup application before the wedding, used to agree the look, products, and timings.
- **Touch-up kit:** a small kit left with the bride for the day, usually lip product, blotting papers, and powder.
- **Day rate:** a fee for a full working day, used for photoshoots, events, and teaching.
- **Conversion rate:** the share of enquiries that become confirmed bookings.
- **Per-person price:** the fee charged for each additional adult beyond the bride.
- **Minimum booking:** the lowest total fee accepted for a date, usually applied to peak Saturdays.
- **Add-on:** a priced extra beyond the standard service, such as an early start or extra travel.

---

*Makeup Artist to Business Owner: Bridal, Freelance & Studio Growth — BEA-09. Business education only; see the disclaimer at the top of this document.*

---

## Appendix C — Quick Reference: Your Numbers at a Glance

Keep this page printed or saved on your phone. It is the whole programme on one page, and it is the page to check before you quote a price, accept a booking, or agree to a change.

**Before you quote:** check your price list, check the date is free, and check the travel distance and start time. If any of those changes the price — travel beyond your included radius, an early start, extra people — say so in the first reply, not on the wedding morning. A price given late feels like a surprise. A price given early feels like professionalism.

**Before you hold a date:** confirm the seven-day hold in writing, with the date the hold ends and the booking fee that secures it. Do not hold dates indefinitely, and do not hold the same date for two brides. One diary, one rule, applied to everyone.

**Before a trial:** send the preparation note, confirm the time and place, and bring the trial form. Record allergies and sensitivities exactly as the client states them, and if anything she tells you raises a health question, advise her to consult a qualified professional rather than offering your own assessment.

**Before the wedding:** send the timeline two weeks ahead and confirm it again in the final week. Confirm the balance is paid, the people and order are settled, and you have a day-of contact who is not the bride. Pack the night before, check your kit against the inventory list, and charge your phone.

**On the morning:** arrive early, set up quietly, work in timeline order, photograph the finished look with permission, leave the touch-up kit, and leave on time. If the schedule slips, tell the bride early and offer a solution rather than letting the delay grow silently.

**After the booking:** record the money in and out, the hours worked, and one lesson for next time. Send a thank-you message the next day, and ask once — politely — for a review or permission to share a photograph. Then file the contract, trial form, and payment record in the client's folder.

**Every week:** one marketing hour, every enquiry answered within one working day, every unanswered enquiry followed up once, and a ten-minute check of money in, money out, and bookings for the next four weeks. Small weekly habits are what turn a talented artist into a booked, paid, and steadily growing business owner. That is the work, and it is work you can now do.
