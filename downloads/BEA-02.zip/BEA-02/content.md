# Formulate & Sell: Natural Skincare Product Development Masterclass

## Welcome — and an important note before you begin

This course teaches you to design your own skincare formulas from first principles: to understand what each ingredient does, to write a formula in percentages, to build a stable emulsion, to preserve it properly, to test its pH and its stability, and to cost, label, and sell it honestly. By the end you will not be copying recipes from the internet. You will be writing your own, repeating them reliably, and knowing exactly why they work — or why they failed, and how to fix them.

This course is education only. It is not medical advice, and it is not a substitute for a dermatologist, a doctor, or a qualified regulatory adviser. Nothing in this course claims that any product treats, cures, or prevents any skin condition or disease. Cosmetic products are meant to cleanse, moisturise, protect, and beautify the skin's appearance. If you or a customer has a skin condition, a rash, an infection, or a reaction, the right step is professional medical advice, not a different cream.

Safety runs through every module, because it is not an add-on to formulation — it is formulation. Three rules underpin everything you will learn here, and you should memorise them now:

1. **Never sell an unpreserved water-based product.** Any formula that contains water — a cream, a lotion, a gel, a toner, a cleanser — can grow bacteria, yeast, and mould. A broad-spectrum preservative, used at the supplier's recommended level and tested, is not optional. "Natural" does not mean "safe without preservation." In fact, natural ingredients often spoil faster.
2. **Patch test everything.** Test every new formula on a small area of skin (usually the inner forearm) for at least 24 to 48 hours before wider use, and advise your customers to do the same. Keep a record of what you tested, on whom, and what happened.
3. **Know your pH, and keep it in a skin-compatible range.** Most leave-on skincare should sit roughly between pH 4.5 and 5.5, and most rinse-off products between about 5.0 and 6.5. Measure it with a calibrated pH meter, not guesswork, and record it in every batch record.

Cosmetics regulation varies by country and by region. In general, a cosmetic placed on the market must be safe and honestly labelled, with a full ingredient list in the required format, the net contents, the maker's name and address, and any required warnings. The details — which ingredients are restricted, what claims you may make, whether you must register, notify, or have a safety assessment done — differ between the United States, the European Union and United Kingdom, Canada, Australia, and elsewhere. This course gives you the principles and the questions to ask. It does not replace checking your own local requirements, and you must do that before you sell a single jar.

### How to use this course

Work through the modules in order. Modules 1 to 3 give you the science and the maths. Modules 4 to 7 teach the craft: emulsions, preservation, pH, colour and scent. Modules 8 to 10 take you from a good formula to a tested, packaged, costed product ready to sell. The 25 base formulas at the end of the course are starting points, not finished products: each one is written in percentages with a full method, and each one is designed for you to adapt, test, and make your own. The companion workbook gives you the templates — formulation worksheet, batch record, costing worksheet, pH log, stability tracker, supplier shortlist, and launch checklist — that turn the lessons into a repeatable system.

You will need some basic equipment before you start formulating: a digital scale accurate to 0.1 g (0.01 g is better for small test batches), a calibrated pH meter or pH strips as a backup, a thermometer, a stick blender or small homogeniser, a double boiler or water bath, heat-safe beakers, spatulas, sanitiser (70% isopropyl alcohol), gloves, and clean, labelled containers. Buy the scale and the pH meter first. Formulation without accurate weighing and pH measurement is guessing, and guessing is how batches fail.

### What you will be able to do when you finish

You will be able to write a formula in percentages, scale it up or down, calculate the cost of every gram, choose and use a preservative correctly, test and adjust pH, run a simple stability test, keep a batch record that lets you repeat a success, label a product honestly, and price it so the business actually makes money. That is the outcome this course is built around: not a shelf of copied recipes, but a repeatable, documented, safe way of working that you own.

---

## Module 1 — Skincare Science Foundations

### 1.1 What skin actually does

Skin is not a passive surface. It is a living barrier, and understanding that barrier is the foundation of every good formula. The outermost layer, the stratum corneum, is often described as a brick wall: the "bricks" are dead skin cells called corneocytes, and the "mortar" is a mixture of lipids — ceramides, cholesterol, and fatty acids — that holds them together. That wall does two jobs at once. It keeps water in, and it keeps the outside world — microbes, irritants, pollutants — out. Healthy skin loses water slowly and steadily; damaged skin loses it faster, which is why it feels dry, tight, and rough.

A moisturiser does not add water to the skin and leave it there. It works in three overlapping ways. Humectants, such as glycerin and hyaluronic acid, attract water — from the formula, from the air, and from the deeper layers of skin — into the stratum corneum. Emollients, such as plant oils and butters, fill the gaps between the corneocytes and make the surface feel smooth and supple. Occlusives, such as shea butter, beeswax, and heavier oils, sit on the surface and slow water loss. A good cream uses all three: humectant to draw water in, emollient to smooth, occlusive to hold it there. A formula that is only oil feels greasy and does little for hydration. A formula that is only humectant can feel sticky and, in very dry air, can actually draw water out of the skin. Balance is the skill.

Skin is also slightly acidic. The surface of healthy skin sits at roughly pH 4.5 to 5.5, a state sometimes called the acid mantle. That acidity supports the skin's barrier and its resident microbes, and it discourages the growth of many unwanted organisms. A product that is far too alkaline — a traditional true soap, for example, often sits at pH 9 to 10 — disrupts that acidity temporarily, and skin takes time to recover. That is why pH matters so much in formulation, and why Module 6 is devoted to it. You are not making a product for a neutral surface. You are making it for a mildly acidic, living barrier, and your formula should respect that.

### 1.2 What a cosmetic can and cannot do

A cosmetic product works on the surface of the skin and, at most, in its upper layers. It can cleanse, moisturise, soften, protect the appearance of the skin, and make it look and feel better. It cannot change the structure or function of the body, treat a disease, or alter skin permanently. That distinction is not just a legal one, though it is a legal one in most countries: products that claim to treat, cure, or prevent disease are regulated as drugs, not cosmetics, and carry far heavier requirements. It is also a practical one. A formulator who promises a customer that a cream will "cure eczema" or "remove wrinkles" is making a promise no cream can keep, and is creating risk for the customer and liability for themselves.

So what can you honestly promise? You can describe what a product is, what it contains, how it feels, and what it is intended to do in cosmetic terms: "a rich moisturising cream for dry skin," "a gentle cleanser that leaves skin feeling soft," "a light facial oil that absorbs quickly." You can talk about the properties of individual ingredients in general terms, but be careful with the leap from "this ingredient is known for its moisturising properties" to "this product will fix your skin." Keep your claims modest, truthful, and supported by what the product actually does. Module 9 covers labelling and claims in detail.

### 1.3 How ingredients are named and listed

When you buy ingredients, you will meet two naming systems. The common name — shea butter, jojoba oil, glycerin — is what you and your customers recognise. The INCI name — the International Nomenclature of Cosmetic Ingredients — is the standardised name used on labels: Butyrospermum Parkii Butter, Simmondsia Chinensis Seed Oil, Glycerin. INCI names exist so that the same ingredient is recognised everywhere, whatever language the label is in, and so that a person with an allergy can identify what they must avoid. Learn to read INCI names. Your supplier's specification sheets will list them, your labels must use them in most markets, and your allergen awareness depends on them. A customer allergic to almonds needs to recognise Prunus Amygdalus Dulcis Oil on your label, not just the words "sweet almond oil" in your marketing copy.

Ingredients are listed on a label in descending order of concentration down to 1%, and below 1% they may be listed in any order. That ordering rule matters when you read other products' labels: the first few ingredients are the bulk of the formula, and the ingredients at the end, however exotic they sound, may be present in tiny amounts. It also matters for your own honesty. If your marketing names an ingredient, it should be present in a meaningful amount, not a token sprinkle at the end of the list.

### 1.4 The formulator's mindset

Good formulation is systematic, not inspired. The difference between a hobbyist and a professional is not talent; it is documentation. A professional writes the formula down before making it, weighs everything, records the temperature, the pH, the appearance, the smell, and the result, and can repeat the batch a month later and get the same product. A hobbyist remembers roughly what they did and wonders why the second batch separated.

Adopt the professional habits from your very first batch. Always work from a written formula in percentages. Always weigh, never measure by volume — a tablespoon of shea butter and a tablespoon of oil weigh different amounts, and "a splash of glycerin" is not a formula. Always sanitise your equipment and work surfaces. Always label your test batches with the date, the formula code, and the batch number. And always keep your notes, including your failures: a failed batch with good notes is worth more than a lucky batch with none, because the notes tell you what to change next time.

Finally, respect the limits of your knowledge. You are learning a craft that touches other people's skin. When you are unsure whether an ingredient is safe at a given level, check the supplier's recommended usage rate and safety data sheet. When you are unsure about a regulation, ask a qualified adviser in your country. When a customer reports a reaction, take it seriously, keep the batch sample, and investigate. Humility is a formulation skill.

---

## Module 2 — Ingredients and How They Work

### 2.1 The ingredient families

Every skincare formula is built from a small number of ingredient families, and learning to think in families — rather than memorising hundreds of individual ingredients — is what makes formulation manageable.

**Water and water-based ingredients.** Purified or distilled water is the most common ingredient in skincare, and it is also the one most often taken for granted. Tap water contains minerals and, sometimes, microbes; it is not suitable for products you intend to sell. Use distilled or deionised water, or water that has been boiled and cooled for small test batches. Floral waters (hydrosols) such as rose water or lavender water are water-based too, and they need preserving just like plain water. Aloe vera juice is another water-based ingredient: useful, but it spoils quickly and must be preserved. Any formula containing water needs a preservative. No exceptions.

**Humectants.** Glycerin (also called glycerol) is the workhorse humectant: inexpensive, effective, and well tolerated at 2% to 5% in most leave-on products. Above about 10% it can feel sticky. Propanediol and butylene glycol are synthetic humectants that feel lighter and less sticky. Hyaluronic acid (sodium hyaluronate) is a powerful humectant used at very low levels — typically 0.1% to 0.5% — because it thickens water dramatically and can feel tacky if overused. Honey and sorbitol are natural humectants. Use humectants at modest levels, and always pair them with emollients and occlusives so the water they attract stays in the skin.

**Emollients and oils.** Plant oils are the heart of natural formulation, and they differ far more than their names suggest. Jojoba oil is technically a liquid wax, closely resembles the skin's own sebum, absorbs well, and is very stable — an excellent all-rounder. Sweet almond oil is light, affordable, and widely tolerated, but it is a nut oil, so allergen labelling matters. Olive oil is rich and nourishing but heavy and strongly scented, and it can feel greasy. Sunflower oil is light and high in linoleic acid, which suits many skin types, but it oxidises faster than jojoba. Rosehip oil is prized for its colour and its fatty acid profile but is expensive and oxidises quickly — keep it cool, keep it dark, and use it at modest percentages. Argan oil is light and fast-absorbing. Coconut oil is solid at room temperature, feels rich, and is very popular, but it is highly comedogenic for some people and should be used thoughtfully in facial products. Castor oil is thick, glossy, and useful in lip products and balms. Learn three or four oils deeply — their feel, their smell, their stability, their cost — before you buy twenty.

**Butters.** Shea butter is the classic: rich, creamy, protective, and widely loved, used at 5% to 20% in creams and up to 100% in balms. Cocoa butter is harder and more brittle, with a distinctive chocolate scent; it gives body to balms and sticks. Mango butter is lighter and less greasy than shea, with almost no scent, which makes it useful when you want the fragrance to come from your essential oils rather than your butter. Butters are solid at room temperature and melt on skin contact, which is part of their appeal. They also vary by batch and supplier, so buy from a supplier who provides a specification sheet and, ideally, a certificate of analysis.

**Waxes.** Beeswax is the traditional structuring wax: it thickens, stabilises, and adds a protective feel, used at 2% to 8% in creams and up to 20% or more in balms. Candelilla wax and carnauba wax are plant-based alternatives, harder than beeswax and used at lower levels. Waxes are what turn an oil into a balm and give a cream its body. Too much wax makes a product drag and feel waxy; too little and it will not hold its shape.

**Emulsifiers.** These are the ingredients that let oil and water live together in one product, and they are the most technical part of natural formulation. An emulsifier has a water-loving end and an oil-loving end, and it sits at the boundary between the two, holding droplets of one phase suspended in the other. Common natural-leaning emulsifiers include glyceryl stearate (often paired with PEG-100 stearate, though that combination is not always accepted as "natural" by every standard), cetearyl alcohol with cetearyl glucoside, polyglyceryl-3 stearate, and lecithin. Each emulsifier has a recommended usage rate, usually 3% to 6%, and a recommended processing temperature. Follow the supplier's instructions exactly: the wrong temperature or the wrong phase order will produce a separated, grainy, or unstable cream, and no amount of stirring afterwards will fix it. Module 4 covers emulsions in full.

**Thickeners and stabilisers.** Cetearyl alcohol (a fatty alcohol, not the drying kind) thickens creams and stabilises emulsions. Xanthan gum thickens water phases and gives a smooth, gel-like feel at 0.2% to 0.5%. Carbomer is a synthetic gelling agent that needs neutralising to thicken. Cetyl alcohol adds body and a soft feel. These ingredients are the difference between a cream that feels luxurious and one that feels thin and watery.

**Preservatives.** Covered in full in Module 5. For now, know that a preservative is a non-negotiable ingredient in any water-containing product, that it must be used at the supplier's recommended level, and that "natural" preservatives such as grapefruit seed extract or vitamin E are not preservatives at all. Vitamin E (tocopherol) is an antioxidant: it slows the oxidation of oils, which is valuable, but it does not kill bacteria or mould.

**Antioxidants.** Tocopherol (vitamin E) at 0.2% to 1% protects oils from going rancid. Rosemary leaf extract is a natural antioxidant used at low levels. These extend shelf life; they do not replace preservation.

**Actives and botanicals.** This is the broadest and most tempting category: plant extracts, clays, vitamins, and specialty ingredients. Green tea extract, chamomile extract, calendula extract, niacinamide, panthenol (pro-vitamin B5), allantoin, and zinc oxide (a mineral UV filter and skin protectant) all have their place. Use them at the supplier's recommended levels, understand what each one actually does, and resist the urge to load a formula with ten actives at once. A formula with two well-chosen actives at effective levels will outperform a formula with ten actives at token levels, and it will be far easier to troubleshoot when something goes wrong.

**Fragrance and essential oils.** Essential oils are potent, concentrated plant extracts, and they are also among the most common causes of skin reactions in natural products. Lavender, tea tree, peppermint, citrus oils, and many others must be used at low, safe levels — generally 0.5% to 1% in leave-on products, and less for sensitive-skin products. Some essential oils are phototoxic: bergamot and other citrus oils can make skin more sensitive to sunlight. Some are not suitable for children, or during pregnancy. Always check the safety data sheet and the International Fragrance Association (IFRA) limits for the oil you are using, and always declare known allergens on the label as your local rules require. Fragrance is optional. An unscented product is a perfectly good product, and for sensitive skin it is often the better choice.

### 2.2 Reading a supplier specification sheet

Before you use any ingredient, read its specification sheet and its safety data sheet. The specification sheet tells you what the ingredient is, its appearance, its recommended usage rate, its solubility, its pH range, and its storage conditions. The safety data sheet tells you its hazards, its safe handling, and what to do if it contacts eyes or skin. Keep both on file for every ingredient you use. They are your first line of defence when a customer asks a question, and your regulator will expect you to have them.

Buy ingredients from reputable cosmetic suppliers, not from food shops or general retailers, when you intend to sell. Cosmetic-grade ingredients come with documentation, batch numbers, and known purity. Food-grade oil from a supermarket may be fine for your own kitchen experiments, but it will not come with the paperwork your business needs.

### 2.3 Building your ingredient palette

Start small. Choose a palette of about fifteen ingredients that you know well: distilled water, glycerin, two or three oils, one butter, one wax, one emulsifier, one thickener, one preservative, one antioxidant, two or three essential oils, and one or two actives. Learn how each one behaves alone and in combination. Make small test batches — 50 g or 100 g — and record everything. Only when you can predict what your palette will do should you expand it. A small, well-understood palette will produce better products than a shelf of a hundred ingredients you have never tested.

---

## Module 3 — Formulation Math: Percentages, Phases, and Batch Scaling

### 3.1 Why percentages, always

Every professional formula is written in percentages that add up to 100%. This is the single most important discipline in formulation, and it is what makes everything else possible: scaling, costing, comparing formulas, and repeating a batch.

A recipe written in grams or spoonfuls only works at one batch size. A formula written in percentages works at any batch size. If your cream is 70% water phase, 25% oil phase, and 5% cool-down phase, you can make 50 g for a test or 5 kg for a production run, and the formula is the same. Percentages also make costing straightforward: if you know the price per gram of each ingredient, you can calculate the cost of 100 g of product in a few minutes, and then the cost of any batch size.

Never write a formula in millilitres, drops, or spoonfuls. Liquids have different densities, drops vary in size, and spoonfuls are not a unit of measurement. Weigh everything in grams, write everything in percentages, and your formulas will be repeatable.

### 3.2 Converting percentages to grams

The conversion is simple: grams of an ingredient = (percentage ÷ 100) × total batch weight.

Worked example: you are making a 100 g test batch of a face cream with this formula:

- Distilled water: 68%
- Glycerin: 4%
- Sweet almond oil: 10%
- Shea butter: 5%
- Emulsifier: 5%
- Cetearyl alcohol: 3%
- Preservative: 1%
- Vitamin E: 0.5%
- Essential oil blend: 0.5%
- Xanthan gum: 0.3%
- Citric acid solution: as needed to adjust pH (record the actual amount used)

For a 100 g batch, the maths is easy: 68% is 68 g, 4% is 4 g, and so on. For a 250 g batch, multiply each percentage by 2.5: water 170 g, glycerin 10 g, sweet almond oil 25 g, shea butter 12.5 g, emulsifier 12.5 g, cetearyl alcohol 7.5 g, preservative 2.5 g, vitamin E 1.25 g, essential oil 1.25 g, xanthan gum 0.75 g. For a 1 kg batch, multiply by 10.

Always check that your percentages add up to 100% before you start weighing. A formula that adds up to 97% or 103% has an error in it, and the error will show up in the product. The workbook's formulation worksheet includes a check row for exactly this purpose.

### 3.3 Phases: how a formula is organised

A formula is organised into phases, and each phase is a group of ingredients that are heated, mixed, or added together at the same stage.

**Phase A — the water phase.** Usually the largest phase. Distilled water, glycerin, humectants, water-soluble thickeners such as xanthan gum, and water-soluble actives. Heated to around 70–75°C for an emulsion.

**Phase B — the oil phase.** Oils, butters, waxes, emulsifier, and oil-soluble ingredients. Heated to the same temperature as the water phase, usually 70–75°C, until everything is fully melted and clear.

**Phase C — the cool-down phase.** Added when the emulsion has cooled to around 40°C or below. Heat-sensitive ingredients go here: preservatives (many are damaged by high heat), essential oils and fragrance (which evaporate), some actives, and pH adjusters. Adding a preservative to a 75°C cream can destroy it, leaving your product unprotected. Adding essential oils to a hot cream wastes them into the air.

This phase structure is not decoration. It is the order of operations, and following it is what produces a stable product. Write your formula in phases, and write the temperature for each step next to it.

### 3.4 Scaling up — and why it is not just multiplication

Scaling a 100 g test batch to 1 kg is mostly multiplication, but scaling to 10 kg or 50 kg introduces real changes. Larger batches heat and cool more slowly, which changes how an emulsion forms. A stick blender that works beautifully at 100 g may not mix 10 kg evenly. Evaporation losses change: you lose a larger proportion of water from a small hot batch than from a large one, because the surface-to-volume ratio is different. Some ingredients, particularly thickeners and emulsifiers, behave differently at scale.

The safe approach is to scale in steps: 100 g, then 500 g, then 1 kg, then 5 kg, testing at each step. At each step, record the actual yield (what you got out, versus what went in), the appearance, the pH, and the viscosity. If the product changes at a larger scale, adjust the process — longer mixing, different equipment, slower cooling — before you change the formula. And always make a small pilot batch on your production equipment before committing to a full run.

### 3.5 Worked costing example

Costing is formulation maths applied to money, and it is covered again in Module 10. Here is a short worked example so you can see the method early.

Take the 100 g face cream above. Suppose your ingredient costs per gram are: distilled water $0.002, glycerin $0.02, sweet almond oil $0.03, shea butter $0.02, emulsifier $0.08, cetearyl alcohol $0.03, preservative $0.12, vitamin E $0.15, essential oil $0.40, xanthan gum $0.10. Multiply each ingredient's grams by its cost per gram:

- Water 68 g × $0.002 = $0.14
- Glycerin 4 g × $0.02 = $0.08
- Sweet almond oil 10 g × $0.03 = $0.30
- Shea butter 5 g × $0.02 = $0.10
- Emulsifier 5 g × $0.08 = $0.40
- Cetearyl alcohol 3 g × $0.03 = $0.09
- Preservative 1 g × $0.12 = $0.12
- Vitamin E 0.5 g × $0.15 = $0.08
- Essential oil 0.5 g × $0.40 = $0.20
- Xanthan gum 0.3 g × $0.10 = $0.03

Total ingredient cost for 100 g: $1.54. If you fill 50 g jars, the ingredient cost per jar is $0.77. Add the jar, lid, and label (say $0.90), and your direct cost per unit is $1.67. That number is the foundation of your price — and it is only knowable because the formula is written in percentages and weighed in grams.

---

## Module 4 — Creating Stable Emulsions

### 4.1 What an emulsion is

An emulsion is a mixture of two liquids that do not normally mix — oil and water — held together by an emulsifier. Most creams and lotions are oil-in-water emulsions: tiny droplets of oil suspended in a continuous water phase. They feel light, absorb quickly, and rinse off easily. A smaller number are water-in-oil emulsions: droplets of water in a continuous oil phase. They feel richer, heavier, and more protective, and are useful for very dry skin and barrier creams. This module focuses on oil-in-water emulsions, because they are the most common and the most useful starting point.

An emulsion is not a true solution. It is a temporary truce, and it will break if the truce is not properly made. When an emulsion breaks, you see separation: a layer of oil on top, water at the bottom, or a grainy, curdled texture. Separation is the most common failure in cream-making, and it almost always comes back to one of four causes: the wrong emulsifier, the wrong temperature, insufficient mixing, or the wrong proportions.

### 4.2 Choosing an emulsifier

Choose your emulsifier before you write the rest of the formula, because it shapes everything else. Read the supplier's data sheet and note four things: the recommended usage rate (usually 3% to 6%), the recommended oil-phase size it can support (an emulsifier rated for 20% oil will struggle with 35%), the processing temperature, and whether it needs a co-emulsifier or a stabiliser such as cetearyl alcohol or xanthan gum. Many emulsifiers work best as a system — for example, an emulsifier plus 2% to 3% cetearyl alcohol — rather than alone.

Do not swap emulsifiers casually. Two emulsifiers with similar names can behave very differently. If you change the emulsifier, treat the formula as a new formula: make a test batch, check the stability, and record the result.

### 4.3 The emulsion method, step by step

1. **Sanitise.** Clean and sanitise all equipment, beakers, and containers with 70% isopropyl alcohol and allow them to dry. Wash your hands and wear gloves.
2. **Weigh Phase A** (water phase) into a heat-safe beaker. Weigh Phase B (oil phase) into a second beaker. Weigh Phase C (cool-down) ingredients separately and set them aside.
3. **Heat both phases** in a water bath to 70–75°C. Stir the water phase to dissolve the xanthan gum or other thickeners fully. Make sure the oil phase is completely melted and clear, with no solid lumps of butter or wax remaining.
4. **Combine.** Remove both beakers from the heat. Pour the water phase into the oil phase (or the oil phase into the water phase, following your emulsifier supplier's instruction — this matters, so check), and mix immediately with a stick blender for 1 to 2 minutes, keeping the blender head submerged to avoid whipping in air.
5. **Cool and stir.** Continue stirring gently as the emulsion cools — by hand or with a spatula, or with the stick blender in short bursts. As it cools it will thicken. This cooling stir is important: an emulsion that is left to cool undisturbed can separate or form a skin.
6. **Add Phase C** when the temperature reaches 40°C or below. Add the preservative, essential oils, and any other cool-down ingredients. Stir thoroughly to distribute them evenly.
7. **Test the pH** (Module 6) and adjust if needed. Record the pH, the temperature at which you added Phase C, and the final appearance, texture, and smell.
8. **Fill** into clean, sanitised containers. Label each one with the formula code, batch number, and date.

### 4.4 Troubleshooting emulsions

**It separated immediately.** The phases were probably at different temperatures, the emulsifier level was too low for the oil load, or the mixing was too brief. Check your temperatures with a thermometer, increase the emulsifier within its recommended range, and blend for longer.

**It separated after a few days.** This is a stability problem, and Module 8 will teach you to test for it deliberately. Common causes: too much oil for the emulsifier, not enough stabiliser, or a formula that is too thin. Try adding 0.2% xanthan gum to the water phase or 1% to 2% cetearyl alcohol to the oil phase.

**It is grainy.** The butter or wax did not melt fully, or it cooled too slowly and formed crystals. Shea butter is prone to graininess if it is melted and then cooled slowly. Melt it fully, cool the emulsion with steady stirring, and avoid reheating a finished cream.

**It is too thin.** Increase the oil phase slightly, add a thickener, or increase the cetearyl alcohol. Check whether you lost water to evaporation during heating — if your test batch lost 5% of its water, the formula you wrote is not the formula you made.

**It is too thick or waxy.** Reduce the wax or the cetearyl alcohol, or increase the water phase. A cream that drags on the skin usually has too much solid fat or wax.

**It feels greasy.** Reduce the heavier oils, replace part of the oil phase with a lighter oil such as jojoba or sunflower, or increase the water phase. A small amount of a light ester or a dry-feel oil can help, but keep the formula simple while you are learning.

Keep a troubleshooting log. Every failure with a recorded cause is a lesson you will not have to relearn.

---

## Module 5 — Preservatives and Why They Matter

### 5.1 The non-negotiable rule

Any product that contains water can grow microbes. That includes creams, lotions, gels, toners, cleansers, floral waters, and aloe-based products. It also includes products that do not contain water in the formula but will get water in them during use — a cream in a jar that a customer dips wet fingers into, for example. Microbial contamination is invisible at first. A contaminated cream can look, smell, and feel perfectly normal while carrying bacteria, yeast, or mould that can cause skin irritation, infection, or worse, particularly for people with broken skin, weakened immunity, or very young or old skin.

This is why preservation is not a preference and not a marketing choice. It is a safety requirement. A product that is sold without adequate preservation is unsafe, and a maker who sells it is responsible for the consequences. No customer expects a handmade cream to make them ill. Your job is to make sure it cannot.

### 5.2 What preservatives do — and what does not count

A broad-spectrum preservative protects against bacteria, yeast, and mould. That breadth matters: an ingredient that inhibits bacteria but not mould leaves half the job undone. Common broad-spectrum preservatives used by independent makers include phenoxyethanol-based systems (often combined with ethylhexylglycerin), benzyl alcohol with dehydroacetic acid, and potassium sorbate with sodium benzoate (which works best in acidic products). Each has a recommended usage rate, a pH range in which it works, and a maximum temperature for addition. Read the supplier's data sheet and follow it exactly.

These ingredients do **not** preserve a product, despite what you may read online:

- **Vitamin E (tocopherol).** An antioxidant. It slows oil oxidation. It does not kill microbes.
- **Grapefruit seed extract.** Not a reliable preservative. Products preserved with it alone have repeatedly failed microbial testing.
- **Essential oils.** Some have antimicrobial properties in a laboratory dish, but at the low levels safe for skin they do not preserve a product.
- **High levels of glycerin or alcohol.** These can reduce microbial growth in specific formulations, but they are not a preservation system on their own, and relying on them is not adequate for a product you sell.
- **"Natural" or "preservative-free" claims.** A water-based product labelled "preservative-free" is either unpreserved and unsafe, or preserved with something the maker has chosen not to call a preservative. Neither is acceptable. If you want to market a product as natural, choose a preservative that meets your chosen natural standard and say so honestly — do not claim the product is unpreserved.

Anhydrous products — balms, body butters, lip balms, and pure oil blends that contain no water — do not need a preservative, because microbes need water to grow. They do need an antioxidant such as vitamin E to slow rancidity, and they do need to be protected from water contamination during use. A balm that a customer uses with wet hands can still become contaminated. Design your packaging and your instructions with that in mind.

### 5.3 Choosing and using a preservative

Choose a preservative that is effective across the pH range of your product, compatible with your other ingredients, and accepted by your target market and your local regulations. Some preservatives are restricted or limited in certain regions. Check your local rules before you commit to one.

Use it at the supplier's recommended level — not less, and not more. Using less than the recommended level leaves the product under-protected. Using more increases the risk of skin irritation and may exceed legal limits. Weigh it accurately. Add it at or below its maximum temperature, usually in the cool-down phase. Record the preservative, the supplier, the batch number, and the percentage in every batch record.

### 5.4 Preservation testing

A preservative in the formula is not proof that the product is preserved. The only proof is testing. Professional makers use challenge testing (also called preservative efficacy testing), in which a laboratory deliberately introduces microbes into a sample and measures whether the preservative kills them over 28 days. Challenge testing costs money, and for a small maker it is a significant expense — but it is the standard of proof for a product you sell, and you should budget for it for each product line, or at minimum for each distinct formula type, before you scale up.

While you are developing a formula, you can do simpler checks: make a batch, store samples at room temperature and in a warm place, and observe them over 4 to 12 weeks for changes in smell, colour, texture, or visible mould. Keep a control sample in the refrigerator for comparison. These observations are useful, but they are not a substitute for challenge testing — a product can be contaminated without any visible sign. Be honest with yourself about that limit.

### 5.5 Hygiene in the workshop

Preservation starts before the preservative goes in. Work in a clean space. Sanitise equipment and containers. Wash your hands, wear gloves, and tie back your hair. Use distilled water, not tap water. Keep raw materials sealed, labelled, and within their shelf life. Make products in small, fresh batches rather than one huge batch that sits for a year. And keep a sample from every batch you sell — a retained sample, stored in the same conditions as the product, labelled with the batch number — so that if a customer ever reports a problem, you can check the batch yourself.

---

## Module 6 — pH Testing and Adjusting

### 6.1 Why pH matters

pH is a measure of how acidic or alkaline a substance is, on a scale from 0 to 14. Below 7 is acidic, 7 is neutral, above 7 is alkaline. Healthy skin sits at roughly pH 4.5 to 5.5. A product that matches that range is comfortable for the skin's barrier. A product that is far outside it — very alkaline, or very acidic — can irritate, disrupt the barrier, and make the skin more vulnerable.

pH also affects your product itself. Preservatives work within specific pH ranges; outside that range they may stop working. Thickeners such as carbomer only thicken at the right pH. Some actives are only stable or effective at a particular pH. And some ingredients, such as certain acids, are only safe at controlled levels. Measuring pH is not a formality. It is a safety and quality check that belongs in every batch record.

### 6.2 Target pH ranges

As a general guide:

- **Leave-on facial products (creams, serums, lotions):** pH 4.5 to 5.5.
- **Body lotions and creams:** pH 4.5 to 5.5.
- **Rinse-off cleansers:** pH 5.0 to 6.5. A cleanser slightly above the skin's natural pH is acceptable because it is rinsed off, but avoid going above about 6.5.
- **Shampoos:** pH 4.5 to 5.5.
- **Products containing alpha hydroxy acids or other exfoliating acids:** these are deliberately acidic, but they require specialist knowledge, careful concentration control, and clear safety warnings. Do not formulate with strong acids until you have studied them specifically and understand the risks.

These are general ranges, not legal limits. Your preservative supplier will specify the pH range in which the preservative is effective — for example, some preservatives work best below pH 6, others up to pH 8. Your product's target pH must sit inside the preservative's effective range. If it does not, choose a different preservative.

### 6.3 Measuring pH

Use a calibrated digital pH meter. pH strips are inexpensive and useful as a rough check, but they are not accurate enough to be your only measurement, especially for a product you sell. A meter costs more, but it is one of the two most important pieces of equipment you will buy, alongside your scale.

Calibrate the meter before each session, using fresh calibration buffers (usually pH 4.0 and pH 7.0). Rinse the electrode with distilled water between measurements. Measure the product at room temperature, and measure it the same way every time so your results are comparable. For a cream, you can measure directly by inserting the electrode into the product, or dilute a small sample (1 g of product in 9 g of distilled water) and measure the dilution — but note which method you used, because the two give slightly different readings. Record the method, the reading, and the date in your batch record.

Measure pH at three points: after the cool-down phase, after 24 hours (pH can drift as the emulsion settles), and after your stability test. If the pH has moved significantly after 24 hours, adjust it and re-check.

### 6.4 Adjusting pH

To lower pH (make a product more acidic), use a dilute solution of citric acid — typically a 10% or 20% solution in distilled water — added a few drops at a time, stirring well and re-measuring after each addition. To raise pH (make a product more alkaline), use a dilute solution of sodium hydroxide (lye) at very low concentration, or a sodium bicarbonate solution, again a few drops at a time. Handle sodium hydroxide with care: wear gloves and eye protection, and never add it undiluted to a product.

Add adjusters slowly. pH does not move in a straight line, and it is easy to overshoot. A single drop too many can take a cream from pH 5.0 to pH 3.5. If you overshoot, you can adjust back the other way, but each correction adds water and salt to the formula and can affect stability, so aim to get it right in small steps. Record exactly how much adjuster you used, so you can build it into the formula next time. Over several batches, you will learn how much your standard formula needs, and the adjustment will become routine.

### 6.5 A worked example

You have made a 200 g batch of face cream. After cooling, the pH reads 6.2. Your target is 5.0 to 5.5, and your preservative works best below pH 6.0. You prepare a 10% citric acid solution (10 g citric acid in 90 g distilled water). You add 4 drops (about 0.2 g) to the cream, stir thoroughly, and re-measure: pH 5.8. You add 4 more drops: pH 5.4. You add 2 more drops: pH 5.2. You stop. You record: "Citric acid 10% solution, 0.5 g total added (0.25% of batch), final pH 5.2 at 25°C, measured 24 hours after making." Next time you make this formula, you can add 0.5 g of the citric acid solution during the cool-down phase and expect a similar result — but you will still measure, because raw materials vary.

---

## Module 7 — Natural Colourants and Fragrance

### 7.1 Colour: what to use and what to avoid

Colour in a natural product comes from the ingredients themselves — the golden tone of shea butter, the green of olive oil, the pale pink of rosehip oil — and from added natural colourants. Useful natural colourants include beetroot powder (pink to red), turmeric (yellow), spirulina and chlorophyll (green), cocoa powder (brown), and mineral pigments such as iron oxides and mica (a wide range of colours, widely used in cosmetics and generally well accepted). Use colourants at low levels, typically 0.1% to 1%, and disperse them thoroughly — a clump of undispersed pigment in a cream looks like a stain, not a colour.

Be careful with food colourings and craft dyes. Many are not approved for cosmetic use, and some can stain skin or cause irritation. Check that any colourant you use is approved for cosmetics in your market, and check its recommended usage rate. Some botanical colourants, such as beetroot powder, fade over time, especially in light. Store coloured products away from direct sunlight, and test how the colour holds up over your stability-test period.

Keep colour honest. A cream does not need to be bright pink to be a good cream, and a colour that suggests an ingredient that is barely present — a deep rose colour in a product with a token amount of rose — is misleading. Let the colour follow the formula, not the marketing.

### 7.2 Fragrance: essential oils done properly

Essential oils give a natural product its scent, and scent is one of the first things a customer notices. It is also one of the most common causes of reactions. Treat essential oils with respect.

**Safe usage levels.** For leave-on products, keep total essential oil content at or below 1%, and at or below 0.5% for products intended for sensitive skin or for the face. For rinse-off products, up to 1% to 2% is commonly used. For products for children, the levels are lower still, and some oils should not be used at all. Check the safety data sheet and IFRA standard for each oil, and stay within the recommended limits.

**Allergens.** Many essential oils contain components that are recognised allergens — limonene and linalool in citrus and lavender oils, geraniol in rose and geranium oils, eugenol in clove oil, and others. In the EU and UK, these must be declared on the label when they exceed a threshold (0.01% in rinse-off products, 0.001% in leave-on products). Even where declaration is not legally required, listing them is good practice: a customer who knows they are allergic to limonene needs to be able to find it on your label.

**Phototoxicity.** Some citrus essential oils, notably bergamot (unless it is bergapten-free), lemon, lime, and grapefruit, can make skin more sensitive to sunlight and cause a reaction when the skin is exposed to UV light after application. Do not use phototoxic oils in leave-on products that will be worn in daylight, or use only the bergapten-free version at a safe level.

**Blending.** A good fragrance blend usually has three layers: top notes (citrus, mint — bright, evaporate quickly), middle notes (lavender, geranium, rose — the heart of the scent), and base notes (sandalwood, cedarwood, vetiver — deep, long-lasting). A simple starting blend is two parts middle note, one part top note, one part base note. Blend your essential oils together first, let the blend rest for 24 hours, then smell it again before adding it to a product — a blend changes as it matures. Record your blends in percentages, just like your formulas, so you can repeat them.

**When to skip fragrance.** An unscented product is a legitimate, marketable choice, and for sensitive skin, for babies, and for customers with fragrance sensitivities, it is often the best choice. You can also use a very light fragrance — 0.2% to 0.3% — that gives a subtle scent without a high allergen load. Never use fragrance to mask a bad smell from a spoiled or oxidised ingredient. If a batch smells wrong, find out why.

### 7.3 Working with clays, botanicals, and extracts

Clays (kaolin, bentonite, French green clay, pink clay) are used in masks and cleansers, typically at 5% to 20%. They absorb oil and give a smooth, matte feel. Botanical powders (oatmeal, calendula, chamomile) add texture and a story, but they can also introduce contamination if they are not clean — use cosmetic-grade powders from a reputable supplier, and remember that anything plant-based in a water formula needs preserving. Extracts (glycerin-based or water-based) are typically used at 1% to 5%. Buy extracts with documentation of their concentration and solvent, and do not assume that a higher percentage is better — extracts are concentrated, and more is not always more effective.

---

## Module 8 — Testing for Stability and Safety

### 8.1 Why testing matters more than the first batch

A cream that looks perfect on the day you make it has not yet proved anything. Stability testing is how you find out whether it will still be a good product in three months, in a warm bathroom, in a cold delivery van, and on a shelf in summer. Every professional product has been through some form of stability testing. Yours should be too, before you sell it.

### 8.2 The basic stability test

Make a test batch and divide it into samples stored in different conditions:

- **Room temperature** (around 20–25°C), in its normal container, on a shelf out of direct sunlight.
- **Warm** (around 40°C), in an oven or incubator if you have one, or in a warm room. Heat accelerates the changes that would happen slowly at room temperature.
- **Cold** (in a refrigerator, around 4°C), then brought back to room temperature.
- **Light**, on a windowsill or under a lamp, to check for colour and scent changes.
- **Freeze–thaw cycles:** 24 hours in a freezer, 24 hours at room temperature, repeated three times. This is a harsh test, and many emulsions will fail it — but if your product survives, it is robust.

Check each sample weekly for at least 4 weeks, and ideally for 8 to 12 weeks, before you commit to selling the formula. At each check, record: appearance (any separation, graininess, or colour change), smell (any rancid, sour, or "off" note), texture (thinner, thicker, gritty), and pH. Compare each sample with a control kept in the refrigerator. If the warm sample separates at week 2, the formula needs work — more stabiliser, a different emulsifier, or a lower oil load. If the pH drifts by more than 0.5 over the test period, investigate why. The stability tracker in the workbook is built for exactly this record-keeping.

### 8.3 Microbial testing

As discussed in Module 5, challenge testing by a laboratory is the professional standard for preservation. For your own development work, you can also send samples for a basic microbial count (total viable count, yeast and mould count) to check whether a batch is contaminated. This is cheaper than a full challenge test and is a useful check on your hygiene and your preservation. If a count comes back high, do not sell the batch. Investigate the cause — contaminated water, unclean equipment, under-dosed preservative, or a preservative added at too high a temperature — and re-test.

### 8.4 Patch testing and user testing

Before you sell a product, patch test it yourself and with a small group of volunteers. Apply a small amount to the inner forearm, cover it with a plaster if you wish, and leave it for 24 to 48 hours. Look for redness, itching, swelling, or rash. Record the result for each person, including anyone who had no reaction. If anyone reacts, take it seriously: keep the batch sample, note the full ingredient list, and consider whether a particular ingredient is the cause.

User testing goes further: give the product to a small group of people who match your target customer, ask them to use it for two weeks, and collect structured feedback — how it feels, how it smells, how it absorbs, whether they would buy it, and what they would change. This is not a clinical trial, and it does not prove the product does anything medical. It tells you whether real people like using it, which is the most important commercial question there is.

### 8.5 When a batch fails

Every formulator has failed batches. The question is what you do with them. Do not sell a batch that has separated, smells off, has visible mould, or has failed a microbial test. Do not try to "fix" a contaminated batch by adding more preservative after the fact. Discard it safely, record what happened, and work out the cause. A discarded batch costs you ingredients. A sold bad batch costs you your reputation, and possibly a customer's health. There is no comparison.

Keep a retained sample from every batch you sell — a small jar, labelled with the batch number and date, stored at room temperature. If a customer ever reports a problem, you can examine the sample and, if needed, send it for testing. Keep retained samples for at least the shelf life of the product plus a few months.

---

## Module 9 — Packaging and Labelling Basics

### 9.1 Choosing packaging

Packaging is not decoration. It protects the product, it controls how the customer uses it, and it is part of the product's safety.

- **Jars** are attractive and easy to fill, but the customer dips fingers into them, which introduces contamination. Use jars for thick products (balms, rich creams) and consider a spatula or a pump alternative where practical.
- **Pumps and airless pumps** reduce contamination and oxidation, and they dispense a controlled amount. They cost more and are harder to fill by hand, but they are the best choice for lotions and for products with a shorter shelf life.
- **Tubes** are hygienic, portable, and good for creams and gels. They are harder to fill without equipment.
- **Dropper bottles** suit serums and facial oils. Use amber or cobalt glass to protect light-sensitive oils.
- **Glass versus plastic.** Glass looks premium and is recyclable, but it is heavy and breakable. PET plastic is light, shatterproof, and widely accepted for cosmetics. Avoid jars and bottles that are not designed for cosmetics — food containers may not seal properly or may react with the product.

Test your packaging with your product before you commit: fill it, store it for a few weeks, and check for leaks, discolouration, cracking, or changes in the product. Some essential oils and some ingredients can degrade certain plastics. Your supplier should be able to advise on compatibility.

### 9.2 What a label must carry

The exact requirements vary by country, but a compliant cosmetic label generally includes:

- **The product name and what it is** ("Moisturising Face Cream").
- **The net contents** (weight or volume, in the units your market requires).
- **The full ingredient list** in INCI names, in descending order down to 1%.
- **The name and address of the maker or the responsible business.**
- **A batch or lot number**, so a batch can be traced.
- **The shelf life or best-before date**, and any "period after opening" symbol (the open-jar symbol with a number of months, such as 6M or 12M).
- **Any required warnings** — for example, "avoid contact with eyes," "discontinue use if irritation occurs," or "keep out of reach of children."
- **Directions for use** and storage instructions ("store in a cool, dry place, away from direct sunlight").

In the EU and UK, the ingredient list must follow INCI naming and the label must carry the name and address of the Responsible Person. In the United States, the label must carry the identity of the product, the net quantity, the ingredient list, and the name and place of business of the manufacturer, packer, or distributor. These are summaries, not legal advice — check your local requirements in full before you print a label.

### 9.3 Claims: what you can and cannot say

Your label and your marketing must be honest. You can say what the product is, what it contains, and what it is intended to do in cosmetic terms. You cannot claim it treats, cures, or prevents any disease or condition. Avoid words such as "heals," "cures," "treats eczema," "removes wrinkles," "anti-ageing" as a medical claim, or "dermatologically proven" unless you have the evidence to support it. Avoid "chemical-free" (everything is made of chemicals, including water) and "preservative-free" for a water-based product. If you claim a product is "natural" or "organic," be prepared to explain what you mean and to meet the standard you are invoking — some markets have legal definitions, and some certification bodies have their own rules.

A useful test for any claim: could you explain it to a regulator, with evidence, in one sentence? If not, do not print it.

### 9.4 Shelf life and period after opening

Set a realistic shelf life. For a well-preserved cream, 12 months unopened is a common claim; for a product with a high proportion of oxidisable oils, 6 to 9 months may be more honest. The period-after-opening symbol tells the customer how long the product should be used once opened — commonly 6M or 12M. Base these numbers on your stability testing, not on optimism. A shorter, honest shelf life is better than a long one you cannot support.

---

## Module 10 — Moving from Kitchen to Selling: Costing, Batch Records, and Supplier Sourcing

### 10.1 Costing: knowing what a jar really costs

Many new makers price by feeling: they look at what similar products sell for and pick a number. That is backwards. Price from your costs upward, then check the market. If your costs do not support a viable price, the product is not ready to sell — or it needs a cheaper formula, a cheaper pack, or a larger batch.

**The full cost of one unit has five parts:**

1. **Ingredients.** Calculated from your formula, as shown in Module 3. Use the actual price you paid, including delivery, divided by the quantity you bought, to get a cost per gram.
2. **Packaging.** Jar or bottle, lid or pump, label, box, and any insert. Include the cost of the label printing.
3. **Labour.** Your time has a value. Time yourself making a batch: weighing, heating, mixing, filling, labelling, cleaning up. Divide the batch time by the number of units to get the labour time per unit, and multiply by an hourly rate — even if you are not paying yourself yet, you need to know what the business would cost if you did.
4. **Overheads.** A share of your fixed costs: insurance, testing, website fees, market stall fees, equipment, and the cost of retained samples and failed batches. Allocate a small amount per unit.
5. **Fees and tax.** Marketplace fees, payment processing fees, delivery costs, and any sales tax or VAT you must account for. Check your local rules: in some places you must register for sales tax above a threshold, and the price you charge must account for it.

### 10.2 Worked costing example: a 50 g face cream

Take the face cream from Module 3. For one 50 g jar:

- Ingredients: $0.77 (calculated in Module 3)
- Jar, lid, and label: $0.90
- Labour: you make 20 jars in 2 hours, and you value your time at $20 per hour. Labour per jar: 2 hours × $20 ÷ 20 jars = $2.00
- Overheads: $0.40 per jar (insurance, testing, fees allocated across the batch)
- Payment and marketplace fees: allow 10% of the selling price

Total direct cost before fees: $0.77 + $0.90 + $2.00 + $0.40 = $4.07 per jar.

If you sell the jar for $18.00, the fees are about $1.80, leaving $18.00 − $4.07 − $1.80 = $12.13 gross profit per jar, a margin of about 67%. That is a healthy margin, and it leaves room for a wholesale price (typically 50% of retail, or $9.00 in this example — which would leave $9.00 − $4.07 − fees = roughly $4.00 profit per jar at wholesale) and for discounts and promotions.

Now run the same numbers at a $9.00 selling price, which is what many new makers charge because it "feels" affordable. Fees of $0.90 leave $9.00 − $4.07 − $0.90 = $4.03 profit per jar. That is still a profit, but it leaves almost nothing for wholesale, for a market stall fee, or for a batch that fails. And it undervalues the work: two hours of skilled labour for 20 jars is real work, and the price should reflect it.

**Worked example two: a 100 g body butter (anhydrous).** A body butter has no water phase, so its ingredient cost is higher per gram — it is mostly butters and oils — but it needs no preservative and is simpler to make. Suppose the ingredient cost for 100 g is $2.10, the jar and label cost $1.10, labour is $1.50 per jar (a simpler, faster process), and overheads are $0.40. Total direct cost: $5.10. Sold at $22.00, with fees of about $2.20, the profit is $22.00 − $5.10 − $2.20 = $14.70 per jar. Sold at $12.00, the profit is $12.00 − $5.10 − $1.20 = $5.70. The lesson is the same: cost it properly, then choose a price that leaves a real margin.

**Worked example three: a 30 ml facial oil.** Facial oils are simple — a blend of carrier oils, vitamin E, and essential oil — and the ingredient cost can be high if you use expensive oils. Suppose 30 ml costs $1.85 in ingredients (rosehip and jojoba are not cheap), the dropper bottle and label cost $1.20, labour is $0.80 per bottle, and overheads are $0.40. Total: $4.25. Sold at $24.00, with fees of $2.40, the profit is $17.35 per bottle. This is why facial oils are popular with small makers: simple to make, easy to preserve (no water, so no preservative needed), and a strong margin — provided you cost the expensive oils honestly and do not under-price.

Use the costing worksheet in the workbook for every product. If the margin is below 50% at your planned retail price, change something — the formula, the pack, the batch size, or the price — before you launch.

### 10.3 Batch records: the document that makes you repeatable

A batch record is a single sheet that captures everything about one batch: the formula code and version, the date, the batch number, the batch size, the name of the maker, the supplier and lot number of each ingredient, the actual weights used, the temperatures, the pH readings, the appearance, and any deviations or problems. It is the single most valuable document in your business. Without it, you cannot repeat a success, trace a problem, or answer a customer's question about a jar they bought six months ago.

Fill in the batch record as you work, not from memory afterwards. Weigh each ingredient, write the weight down, and tick it off. If you substitute an ingredient or change a percentage, write it down and give the batch a new version note. File batch records by date and batch number, and keep them for at least the shelf life of the product plus one year. The batch-record template in this course is ready to print and use.

### 10.4 Supplier sourcing

Buy from cosmetic ingredient suppliers who provide specification sheets, safety data sheets, batch numbers, and certificates of analysis. Ask a new supplier three questions before you order: Do you provide a specification sheet and safety data sheet for every ingredient? What is the shelf life and the recommended storage? What is your minimum order, your delivery time, and your returns policy for a damaged or incorrect item?

Order small quantities of a new ingredient first, and test it before you commit to a large order. Check the ingredient when it arrives: does it look, smell, and feel as the specification sheet says it should? Is it within its shelf life? Is the batch number on the delivery note the same as the one on the container? Record the supplier, the batch number, and the date received on the container and in your records.

Build relationships with two or three reliable suppliers rather than buying from a different source every time. Consistency of supply is consistency of product: the same oil from a different supplier can have a different colour, smell, and fatty acid profile, and that can change your product. When you find a supplier whose ingredients work in your formulas, stay with them.

### 10.5 Before you sell: the launch checklist

Before a single jar leaves your hands, confirm each of these:

- The formula has been stability tested for at least 4 weeks, and preferably 8 to 12.
- The preservation has been considered and, for a product you will sell at scale, challenge tested or at least microbial-count tested.
- The pH has been measured and recorded, and sits in the target range.
- The label carries the full ingredient list, net contents, your business name and address, a batch number, and a shelf life or best-before date.
- You have checked your local cosmetics regulations and, where required, completed any notification, registration, or safety assessment.
- You have product liability insurance, or you have checked whether you need it.
- You have costed the product and set a price that leaves a real margin.
- You have a retained sample from the batch.
- You have a system for handling a customer complaint or a reaction report: who to contact, what to record, and what to do with the batch.

That list is the launch checklist in the workbook. Print it, work through it for each product, and do not skip a step because you are in a hurry. A careful launch is slower. It is also the launch that builds a business that lasts.

### 10.6 Your first year: a realistic path

Start with one or two products, not ten. Choose the simplest formulas you can make well — a body butter and a face cream, or a facial oil and a gentle cleanser — and make them repeatedly until your batches are consistent. Sell to people you know, collect honest feedback, and refine. Then add a third product, and a fourth. Each new product should reuse ingredients and equipment you already have, so your costs stay low and your knowledge compounds.

Keep learning. Read supplier data sheets. Take a short course on cosmetic science or on your local regulations when you can. Join a community of makers and share what you learn. And keep your notes: a year from now, your batch records and your stability logs will be the most valuable thing you own, because they are the record of what you know, what you tried, and what worked.

You now have the knowledge to design your own formulas. The next section gives you 25 starting points. Use them, adapt them, test them, and make them yours.

---

## The 25 Base Formulas

Each formula below is written in percentages that add to 100% (excluding pH adjuster, which is added as needed and recorded). All water is distilled water. All percentages are by weight. Make a 100 g test batch first, check the pH and the stability, and only then scale up. Each formula includes a method summary; the full emulsion method is in Module 4 and the pH method is in Module 6. Preservative percentages are given as a typical recommended level — always confirm the level on your own preservative supplier's data sheet, because it varies by product.

**Safety note for every formula:** patch test before wider use. Do not sell a water-based formula without a preservative. Keep essential oils within the levels given. Check local regulations before selling.

### Formula 1 — Everyday Face Cream (normal to dry skin)
Water 68.0% · Glycerin 4.0% · Sweet almond oil 10.0% · Shea butter 5.0% · Emulsifier (cetearyl glucoside system) 5.0% · Cetearyl alcohol 3.0% · Xanthan gum 0.3% · Preservative 1.0% · Vitamin E 0.5% · Lavender essential oil 0.5% · Citric acid solution as needed to pH 5.0–5.5. Method: heat Phases A (water, glycerin, xanthan gum) and B (oils, butter, emulsifier, cetearyl alcohol) separately to 72°C, combine and blend 2 minutes, cool with stirring, add Phase C (preservative, vitamin E, essential oil) below 40°C, adjust pH. A balanced, forgiving first emulsion and the reference cream used in Modules 3 and 10.

### Formula 2 — Light Day Lotion (normal to combination skin)
Water 74.0% · Glycerin 3.0% · Sunflower oil 8.0% · Jojoba oil 4.0% · Emulsifier 4.0% · Cetearyl alcohol 2.0% · Xanthan gum 0.2% · Preservative 1.0% · Panthenol 1.0% · Vitamin E 0.3% · Geranium essential oil 0.4% · Citric acid solution as needed to pH 5.0–5.5. Method: as Formula 1, with a lower oil phase for a lighter feel. Absorbs quickly and layers well under makeup.

### Formula 3 — Rich Night Cream (dry skin)
Water 60.0% · Glycerin 5.0% · Shea butter 10.0% · Avocado oil 8.0% · Jojoba oil 5.0% · Emulsifier 5.0% · Cetearyl alcohol 3.0% · Xanthan gum 0.3% · Preservative 1.0% · Vitamin E 0.5% · Rosehip oil 1.0% · Frankincense essential oil 0.4% · Citric acid solution as needed to pH 5.0–5.5. Method: as Formula 1; add rosehip oil and essential oil in the cool-down phase to protect them from heat. Rich and protective; best used at night.

### Formula 4 — Sensitive Skin Cream (fragrance-free)
Water 70.0% · Glycerin 4.0% · Sunflower oil 8.0% · Shea butter 5.0% · Emulsifier 5.0% · Cetearyl alcohol 3.0% · Xanthan gum 0.3% · Preservative 1.0% · Allantoin 0.3% · Vitamin E 0.5% · Citric acid solution as needed to pH 5.0–5.5. Method: as Formula 1; dissolve allantoin in the warm water phase. No essential oil and no fragrance. A good base for customers with reactive skin — but still patch test, and still preserve.

### Formula 5 — Soothing Oat Face Cream
Water 68.0% · Glycerin 4.0% · Colloidal oatmeal 2.0% · Sweet almond oil 9.0% · Shea butter 5.0% · Emulsifier 5.0% · Cetearyl alcohol 3.0% · Xanthan gum 0.3% · Preservative 1.0% · Vitamin E 0.5% · Chamomile essential oil (Roman) 0.3% · Citric acid solution as needed to pH 5.0–5.5. Method: disperse the oatmeal in the water phase before heating; stir well to avoid lumps. The oatmeal gives a soft, comforting feel.

### Formula 6 — Balancing Facial Oil (combination skin)
Jojoba oil 60.0% · Sunflower oil 25.0% · Rosehip oil 8.0% · Squalane (olive-derived) 5.0% · Vitamin E 1.0% · Tea tree essential oil 0.5% · Lavender essential oil 0.5%. Method: anhydrous — no water, no preservative needed. Weigh all oils into a clean beaker, stir until uniform, add vitamin E and essential oils, stir again, fill into amber dropper bottles. Use 3–4 drops on damp skin. Store away from light and heat.

### Formula 7 — Nourishing Facial Oil (dry skin)
Sweet almond oil 40.0% · Avocado oil 25.0% · Argan oil 20.0% · Rosehip oil 10.0% · Vitamin E 1.0% · Frankincense essential oil 0.5% · Geranium essential oil 0.5% · Evening primrose oil 3.0%. Method: as Formula 6. Rich and slow-absorbing; best at night or as a facial massage oil.

### Formula 8 — Gentle Foaming Face Wash
Water 55.0% · Decyl glucoside (or coco glucoside) 20.0% · Glycerin 5.0% · Cocamidopropyl betaine 10.0% · Panthenol 1.0% · Xanthan gum 0.3% · Preservative 1.0% · Citric acid solution as needed to pH 5.0–5.5 · Lavender essential oil 0.3% · Aloe vera juice 7.4%. Method: no heating needed. Dissolve xanthan gum in water, add glycerin and aloe, then add the surfactants slowly with gentle stirring to avoid foam. Add preservative and essential oil, adjust pH, and fill. Do not shake vigorously. Rinse-off product; keep the pH in the 5.0–5.5 range.

### Formula 9 — Cream Cleanser (dry and sensitive skin)
Water 62.0% · Glycerin 4.0% · Sweet almond oil 12.0% · Shea butter 4.0% · Emulsifier 5.0% · Cetearyl alcohol 3.0% · Xanthan gum 0.3% · Preservative 1.0% · Vitamin E 0.5% · Chamomile extract 2.0% · Citric acid solution as needed to pH 5.0–5.5. Method: make as an emulsion (Module 4), using a low oil load and a soft emulsifier. Massage onto damp skin and rinse or wipe off with a warm cloth.

### Formula 10 — Micellar-Style Cleansing Water
Distilled water 88.0% · Glycerin 3.0% · Decyl glucoside 3.0% · Panthenol 1.0% · Rose water 3.0% · Preservative 1.0% · Citric acid solution as needed to pH 5.0–5.5. Method: stir all ingredients together at room temperature in order, adjust pH, and fill into a pump or flip-top bottle. Use with a cotton pad. Because it is almost entirely water, preservation and hygiene are critical — do not make this formula without a preservative.

### Formula 11 — Hydrating Face Toner
Rose water 70.0% · Distilled water 20.0% · Glycerin 4.0% · Aloe vera juice 4.0% · Panthenol 1.0% · Preservative 1.0% · Citric acid solution as needed to pH 5.0–5.5. Method: stir together at room temperature, adjust pH, fill into a spray or flip-top bottle. Light and refreshing; apply after cleansing and before moisturiser.

### Formula 12 — Simple Hydrating Serum (gel)
Distilled water 88.0% · Glycerin 5.0% · Sodium hyaluronate 0.3% · Panthenol 1.0% · Aloe vera juice 4.0% · Preservative 1.0% · Citric acid solution as needed to pH 5.0–5.5. Method: sprinkle sodium hyaluronate slowly into the water while stirring to avoid clumps; allow it to hydrate fully (several hours or overnight) before adding the remaining ingredients. The result is a clear, smooth gel. Use a pea-sized amount under moisturiser.

### Formula 13 — Vitamin C-Style Brightening Serum (stable derivative)
Distilled water 80.0% · Glycerin 5.0% · Sodium ascorbyl phosphate 5.0% · Panthenol 1.0% · Sodium hyaluronate 0.2% · Preservative 1.0% · Citric acid solution as needed to pH 6.0–6.5. Method: dissolve the sodium ascorbyl phosphate (a stable vitamin C derivative, not pure ascorbic acid) in the water phase at room temperature; hydrate the hyaluronate separately and combine. Note: this formula uses a derivative because pure vitamin C is unstable in water and requires specialist formulation. Do not claim this product "brightens" or "evens skin tone" as a proven effect — describe it as a hydrating serum with a vitamin C derivative.

### Formula 14 — Clay Face Mask (dry powder base)
Kaolin clay 60.0% · Bentonite clay 20.0% · Colloidal oatmeal 10.0% · Rosehip powder 5.0% · Chamomile powder 5.0%. Method: anhydrous powder — blend all powders thoroughly, sieve to remove lumps, and fill into a jar. The customer mixes one teaspoon with water, rose water, or yoghurt to form a paste, applies it for 10 minutes, and rinses off. Because it contains no water as sold, it needs no preservative; the customer mixes it fresh each time. Label it clearly as a powder to be mixed before use, with a use-by date.

### Formula 15 — Creamy Clay Mask (ready to use)
Water 55.0% · Kaolin clay 20.0% · Glycerin 5.0% · Sweet almond oil 6.0% · Emulsifier 4.0% · Cetearyl alcohol 2.0% · Xanthan gum 0.4% · Preservative 1.0% · Vitamin E 0.3% · Lavender essential oil 0.3% · Citric acid solution as needed to pH 5.0–5.5. Method: make the emulsion first, then add the clay slowly to the cooled emulsion with steady stirring. Apply a thin layer, leave for 10 minutes, rinse off. Contains water, so it must be preserved.

### Formula 16 — Whipped Body Butter
Shea butter 60.0% · Mango butter 20.0% · Coconut oil 10.0% · Sweet almond oil 8.0% · Vitamin E 1.0% · Vanilla oleoresin or lavender essential oil 1.0%. Method: anhydrous. Melt the butters and coconut oil gently in a water bath, remove from heat, cool until the mixture begins to thicken at the edges, then whip with a hand mixer until light and fluffy. Fill into wide-mouth jars. No water, so no preservative — but add the vitamin E to slow oxidation, and keep water out of the jar during use.

### Formula 17 — Body Lotion (everyday)
Water 72.0% · Glycerin 4.0% · Sunflower oil 10.0% · Shea butter 4.0% · Emulsifier 4.0% · Cetearyl alcohol 2.0% · Xanthan gum 0.2% · Preservative 1.0% · Vitamin E 0.3% · Sweet orange essential oil 0.5% · Citric acid solution as needed to pH 5.0–5.5. Method: as Formula 1, with a thinner, more fluid emulsion. Fill into a pump bottle. A good everyday product and a strong first seller because it is easy to make and easy to use.

### Formula 18 — Rich Body Cream (very dry skin)
Water 60.0% · Glycerin 5.0% · Shea butter 12.0% · Cocoa butter 5.0% · Olive oil 6.0% · Emulsifier 5.0% · Cetearyl alcohol 3.0% · Xanthan gum 0.3% · Preservative 1.0% · Vitamin E 0.5% · Cedarwood essential oil 0.4% · Citric acid solution as needed to pH 5.0–5.5. Method: as Formula 1. Thick and protective; best applied after a shower while the skin is still slightly damp.

### Formula 19 — Hand Cream (working hands)
Water 62.0% · Glycerin 5.0% · Shea butter 10.0% · Sweet almond oil 8.0% · Beeswax 2.0% · Emulsifier 5.0% · Cetearyl alcohol 3.0% · Xanthan gum 0.3% · Preservative 1.0% · Vitamin E 0.5% · Allantoin 0.3% · Lavender essential oil 0.4% · Citric acid solution as needed to pH 5.0–5.5. Method: as Formula 1; melt the beeswax with the oil phase. The wax gives a protective, long-lasting feel that suits hands that are washed often.

### Formula 20 — Lip Balm (stick or tin)
Cocoa butter 30.0% · Shea butter 25.0% · Beeswax 20.0% · Sweet almond oil 15.0% · Castor oil 8.0% · Vitamin E 1.0% · Peppermint essential oil 1.0%. Method: anhydrous. Melt all ingredients except vitamin E and essential oil in a water bath, remove from heat, stir in vitamin E and essential oil below 40°C, and pour into lip balm tubes or tins before it sets. Work quickly — this formula sets fast. Peppermint gives a cooling feel; keep it at 1% or below.

### Formula 21 — Lip Scrub
Sugar (fine caster sugar) 60.0% · Sweet almond oil 25.0% · Shea butter 10.0% · Honey 3.0% · Vitamin E 1.0% · Vanilla oleoresin 1.0%. Method: anhydrous. Melt the shea butter gently, stir in the oil, honey, and vitamin E, then fold in the sugar last so it stays suspended. Fill into small jars. The customer rubs a pea-sized amount on the lips and rinses off. Keep water out of the jar.

### Formula 22 — Bath Soak (salts)
Epsom salt (magnesium sulfate) 60.0% · Fine sea salt 25.0% · Baking soda (sodium bicarbonate) 10.0% · Sweet almond oil 3.0% · Lavender essential oil 1.0% · Dried lavender buds 1.0%. Method: anhydrous. Mix the salts and baking soda, drizzle in the oil and essential oil while stirring, then fold in the lavender buds. Fill into jars or pouches. The customer adds a handful to a warm bath. Label the essential oil content and advise against use on broken skin.

### Formula 23 — Shower Gel (gentle)
Water 60.0% · Decyl glucoside 15.0% · Cocamidopropyl betaine 10.0% · Glycerin 5.0% · Aloe vera juice 5.0% · Xanthan gum 0.3% · Preservative 1.0% · Panthenol 1.0% · Citric acid solution as needed to pH 5.0–5.5 · Sweet orange essential oil 0.5% · Salt (sodium chloride) as needed to thicken (add a pinch at a time). Method: as Formula 8 — gentle stirring, no vigorous shaking. Add salt very slowly; a little thickens the gel, too much thins it again.

### Formula 24 — Hair Oil (scalp and ends)
Jojoba oil 50.0% · Argan oil 25.0% · Sweet almond oil 20.0% · Vitamin E 1.0% · Rosemary essential oil 1.0% · Lavender essential oil 1.0% · Castor oil 2.0%. Method: anhydrous; stir all ingredients together and fill into a dropper bottle. Apply a few drops to the ends of the hair, or massage into the scalp and leave for 30 minutes before washing. Do not claim it promotes hair growth — describe it as a conditioning hair oil.

### Formula 25 — Solid Lotion Bar
Cocoa butter 35.0% · Shea butter 30.0% · Beeswax 20.0% · Sweet almond oil 13.0% · Vitamin E 1.0% · Lavender essential oil 1.0%. Method: anhydrous. Melt everything except vitamin E and essential oil in a water bath, remove from heat, stir in the remaining ingredients below 40°C, and pour into silicone moulds. Allow to set fully at room temperature before removing from the moulds. The bar melts on contact with warm skin. Wrap each bar and label it with the full ingredient list.

---

## Closing: what you own now

You own a method, not a set of recipes. You can write a formula in percentages, choose ingredients for a reason, build a stable emulsion, preserve it properly, test its pH, test its stability, cost it, label it honestly, and keep a record that lets you repeat it. That is the whole craft, and it is yours to build on.

Start with one formula. Make it three times. Record everything. When the third batch matches the first, you are ready to sell it — and you will know, because your notes will prove it, not because you hope so. Good formulating.
