# Customer Onboarding — Formulate & Sell: Natural Skincare Product Development Masterclass

Welcome. You now own the full masterclass: the 10-module course, the 25 base formulas, the companion workbook, and the printable templates. This guide tells you what to do first and how to get the most from the materials.

## What you received

- **content.md** — the full course: 10 modules and 25 original base formulas, written in full.
- **workbook.md** — the companion workbook: formulation worksheet, batch-record template, costing worksheet, pH log, stability-test tracker, supplier shortlist, and launch checklist.
- **templates/** — printable templates: formulation-worksheet.md, batch-record-template.md, product-costing-calculator.csv (with example numbers), supplier-shortlist.md.
- **sales-page.md** — the product's sales page copy (for reference).
- **cover.webp** — the product cover image.

## What to do first

1. **Read the welcome and safety notes at the start of the course.** The three rules matter more than any formula: never sell an unpreserved water-based product, always patch test, and always measure pH.
2. **Buy the two essential tools if you do not own them already:** a digital scale accurate to 0.1 g (0.01 g is better for small batches) and a calibrated pH meter. Also gather a thermometer, a stick blender, heat-safe beakers, spatulas, 70% isopropyl alcohol for sanitising, and gloves.
3. **Print the templates.** Print several copies of the formulation worksheet and the batch-record template — you will use one per formula and one per batch.
4. **Read Modules 1–3 before making anything.** They give you the science, the ingredient families, and the maths. Formulation without them is guessing.

## How to use the materials

- **Work through the modules in order.** Modules 1–3 are the foundation, Modules 4–7 are the craft, and Modules 8–10 take you from a good formula to a tested, packaged, costed product.
- **Make a test batch as you finish each practical module.** Small batches (50–100 g) are best for learning: they are cheap to get wrong and easy to compare.
- **Fill in the workbook as you go.** Complete a formulation worksheet before every new formula and a batch record for every batch, including failures. Your notes are what make a success repeatable.
- **Use the 25 base formulas as starting points, not finished products.** Each one is written in percentages with a full method. Adapt it, test it for stability and pH, patch test it, and only then consider selling it.
- **Cost every product with the costing calculator** before you set a price. The example numbers in the spreadsheet show the method; replace them with your actual costs.

## Suggested schedule

- **Week 1:** Read Modules 1–3. Buy or gather equipment. Print the templates. Order a small starter set of ingredients from a reputable cosmetic supplier.
- **Week 2:** Read Module 4 and make Formula 1 (Everyday Face Cream) at 100 g. Measure the pH at cooling and at 24 hours. Start a stability test on the batch.
- **Week 3:** Read Modules 5–6. Make Formula 1 again with one deliberate change (for example, a different oil). Compare the batches. Practise pH adjustment with a citric acid solution.
- **Week 4:** Read Module 7. Make an anhydrous product — Formula 16 (Whipped Body Butter) or Formula 6 (Balancing Facial Oil). Cost it with the costing worksheet.
- **Weeks 5–8:** Read Modules 8–10. Run the stability test to 8 weeks, work through the launch checklist for your best product, and check your local cosmetics regulations.
- **After that:** add one new formula at a time, reusing ingredients and equipment you already own. There is no deadline — revisit the modules whenever you need them.

## Safety reminders

- This course is education only. It is not medical advice and is not a substitute for a dermatologist or a qualified regulatory adviser.
- Never sell an unpreserved water-based product. Always patch test. Keep products in skin-compatible pH ranges.
- Cosmetics regulations vary by country. Check your local requirements — ingredient restrictions, labelling, notification or registration, safety assessment, and insurance — before selling.

## How to get support

For help with your order or the course files, email the marketplace support address with your order number and a description of the issue, and the support team will respond. For questions about your local regulations or a specific skin condition, consult a qualified adviser or medical professional in your country.
