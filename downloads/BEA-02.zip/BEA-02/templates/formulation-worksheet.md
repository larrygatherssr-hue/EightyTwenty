# Formulation Worksheet

Complete this sheet for every new formula **before** you start weighing. Do not proceed until the percentages add to 100%.

- Product name:
- Formula code (e.g. FC-001):
- Formula version:
- Date:
- Product type (cream / lotion / oil / cleanser / balm / other):
- Target skin type:
- Target pH range:
- Batch size for this test (g):
- Preservative chosen, and why:
- Emulsifier chosen, and why:

| Phase | Ingredient | INCI name | % | Grams (for this batch) | Supplier | Supplier lot no. |
|---|---|---|---|---|---|---|
| A | | | | | | |
| A | | | | | | |
| A | | | | | | |
| B | | | | | | |
| B | | | | | | |
| B | | | | | | |
| C | | | | | | |
| C | | | | | | |
| C | | | | | | |
| **Total** | | | **100%** | | | |

- Percentages add to 100%? Yes / No
- Method notes (temperatures, order of addition, mixing times):
- pH adjuster planned:
- Expected appearance, texture, and scent:
- What am I testing with this batch?
- Result after making (appearance, texture, smell, pH at 24 hours):
- What will I change next time?
