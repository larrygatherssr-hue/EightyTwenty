# Supplier Shortlist

Keep one row per supplier and ingredient. Record the documentation you received and the cost per gram — that figure feeds directly into your costing worksheet.

| Ingredient | Supplier name | Contact / website | Price and pack size | Cost per gram | Spec sheet received? | Safety data sheet received? | Certificate of analysis? | Shelf life | Storage | Notes |
|---|---|---|---|---|---|---|---|---|---|---|
| Distilled water | | | | | | | | | | |
| Glycerin | | | | | | | | | | |
| Sweet almond oil | | | | | | | | | | |
| Jojoba oil | | | | | | | | | | |
| Shea butter | | | | | | | | | | |
| Emulsifier | | | | | | | | | | |
| Cetearyl alcohol | | | | | | | | | | |
| Preservative | | | | | | | | | | |
| Vitamin E (tocopherol) | | | | | | | | | | |
| Xanthan gum | | | | | | | | | | |
| Essential oil | | | | | | | | | | |

## Questions to ask a new supplier

1. Do you provide a specification sheet and safety data sheet for every ingredient?
2. What is the shelf life and the recommended storage?
3. What is your minimum order, your delivery time, and your returns policy for a damaged or incorrect item?
4. Can you provide a certificate of analysis for this batch?
5. Is this ingredient cosmetic grade, and is the batch number printed on the container?

## Supplier notes

- Preferred supplier 1:
- Preferred supplier 2:
- Backup supplier:
