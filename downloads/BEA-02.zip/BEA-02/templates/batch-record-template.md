# Batch-Record Template

Complete one record for every batch you make, including test batches. Fill it in as you work, not from memory afterwards. File by batch number and keep for at least the shelf life of the product plus one year.

- Product name and formula code:
- Formula version:
- Batch number:
- Date made:
- Made by:
- Batch size planned (g):
- Actual yield (g):
- Container type and size:
- Number of units filled:

## Ingredients

| Ingredient | Supplier | Supplier lot no. | % | Grams weighed (actual) | Added (tick) |
|---|---|---|---|---|---|
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |

## Process

- Water phase temperature at combining (°C):
- Oil phase temperature at combining (°C):
- Mixing method and time:
- Temperature when cool-down phase added (°C):
- pH after cooling:
- pH after 24 hours:
- pH adjuster used (type and amount):
- Appearance:
- Texture:
- Smell:
- Any deviations from the formula or method:

## Disposition

- Retained sample kept? Yes / No — where stored:
- Disposition: keep / rework / discard — reason:
- Notes:
