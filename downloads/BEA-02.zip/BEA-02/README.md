# BEA-02 — Formulate & Sell: Natural Skincare Product Development Masterclass

Price: $597 (59700 cents), one-time. Category: Beauty & Health.

## Files

- **content.md** — full course: 10 modules fully written + 25 original base formulas with percentages and methods (12,945 words).
- **workbook.md** — companion workbook: formulation worksheet, batch-record template, costing worksheet, pH log, stability-test tracker, supplier shortlist, launch checklist, starter plan.
- **templates/formulation-worksheet.md** — printable formulation worksheet.
- **templates/batch-record-template.md** — printable batch-record template.
- **templates/product-costing-calculator.csv** — costing calculator with example numbers (face cream worked example).
- **templates/supplier-shortlist.md** — supplier shortlist with questions to ask a new supplier.
- **sales-page.md** — full sales page: headline, problem, solution, module list, who it is for / not for, $597 price, 14-day guarantee, 10 FAQs, disclaimers.
- **listing.json** — marketplace listing data (price_cents 59700, billing one_time).
- **cover.md** — cover design brief (black-and-gold luxury palette).
- **cover.webp** — generated cover image.
- **onboarding.md** — customer onboarding guide with a suggested 8-week schedule.
