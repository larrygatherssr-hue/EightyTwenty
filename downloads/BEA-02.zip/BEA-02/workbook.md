# Companion Workbook — Formulate & Sell: Natural Skincare Product Development Masterclass

Use this workbook alongside the course. Print the templates, fill them in by hand as you work, and file them with your batch records. A filled-in workbook is the difference between a hobby and a business: it is the record that lets you repeat a success, trace a problem, and prove what you did.

---

## 1. Formulation Worksheet

Complete one worksheet for every new formula before you make it. Do not start weighing until this sheet is finished and the percentages add to 100%.

- Product name:
- Formula code (e.g. FC-001):
- Formula version:
- Date:
- Product type (cream / lotion / oil / cleanser / balm / other):
- Target skin type:
- Target pH range:
- Batch size for this test (g):
- Preservative chosen, and why:
- Emulsifier chosen, and why:

| Phase | Ingredient | INCI name | % | Grams (for this batch) | Supplier | Supplier lot no. |
|---|---|---|---|---|---|---|
| A | | | | | | |
| A | | | | | | |
| B | | | | | | |
| B | | | | | | |
| C | | | | | | |
| C | | | | | | |
| **Total** | | | **100%** | | | |

- Percentages add to 100%? Yes / No (do not proceed until yes)
- Method notes (temperatures, order of addition, mixing times):
- pH adjuster planned (citric acid solution / sodium hydroxide solution):
- Expected appearance, texture, and scent:
- What am I testing with this batch? (new emulsifier / new oil / higher oil load / fragrance level / other):
- Result after making (appearance, texture, smell, pH at 24 hours):
- What will I change next time?

---

## 2. Batch-Record Template

Complete one record for every batch you make, including test batches. File by batch number. (A printable copy is in templates/batch-record-template.md.)

- Product name and formula code:
- Batch number:
- Date made:
- Made by:
- Batch size (g planned / g actual yield):
- Container type and size:
- Number of units filled:

Ingredient table: ingredient, supplier, supplier lot number, percentage, grams weighed (actual), tick when added.

Process record:

- Water phase temperature at combining:
- Oil phase temperature at combining:
- Mixing method and time:
- Temperature when cool-down phase added:
- pH after cooling:
- pH after 24 hours:
- pH adjuster used (type and amount):
- Appearance, texture, and smell:
- Any deviations from the formula or method:
- Retained sample kept? Yes / No — where stored:
- Disposition: keep / rework / discard — reason:

---

## 3. Costing Worksheet

Complete one worksheet per product, per batch size. Use actual prices paid, including delivery.

Product name:
Batch size (g):
Units per batch (and unit size):

| Ingredient | % | Grams per batch | Cost per gram | Cost per batch |
|---|---|---|---|---|
| | | | | |
| **Ingredient subtotal** | | | | |

| Other cost | Amount per unit |
|---|---|
| Jar / bottle | |
| Lid / pump / dropper | |
| Label (printed) | |
| Box / insert | |
| **Packaging subtotal** | |

- Labour: batch time (hours) × hourly rate ÷ units per batch =
- Overheads allocated per unit =
- Payment / marketplace fees per unit (as % of selling price) =
- **Total cost per unit** (ingredients per unit + packaging + labour + overheads + fees) =
- Planned selling price =
- Gross profit per unit =
- Gross margin % =
- Wholesale price (if offered) and profit at wholesale =
- Does the margin support the price? If below 50% gross margin, what will change?

Worked examples for a face cream, a body butter, and a facial oil are in Module 10 of the course.

---

## 4. pH Log

Record every pH measurement. Always note the method (direct or diluted), the meter calibration date, and the temperature.

| Date | Product / batch no. | Method | Meter calibrated? | pH after cooling | pH after 24 hrs | pH after stability test | Adjuster used | Amount | Final pH | Notes |
|---|---|---|---|---|---|---|---|---|---|---|
| | | | | | | | | | | |
| | | | | | | | | | | |
| | | | | | | | | | | |
| | | | | | | | | | | |
| | | | | | | | | | | |

Target ranges reminder: leave-on face and body products pH 4.5–5.5; rinse-off cleansers pH 5.0–6.5. Your preservative's effective pH range must contain your target pH — check the supplier data sheet.

---

## 5. Stability-Test Tracker

One tracker per formula. Store samples as described in Module 8 and check weekly.

Product name / formula code:
Batch number and date made:
Test start date:

| Week | Date | Room temp sample: appearance / smell / texture / pH | Warm (40°C) sample | Cold (fridge) sample | Light sample | Freeze–thaw sample | Action needed? |
|---|---|---|---|---|---|---|---|
| 1 | | | | | | | |
| 2 | | | | | | | |
| 4 | | | | | | | |
| 8 | | | | | | | |
| 12 | | | | | | | |

- Any separation? When and in which sample?
- Any colour or scent change?
- pH drift over the test period:
- Verdict: stable / needs reformulation — what will change?

---

## 6. Supplier Shortlist

Keep one row per supplier and ingredient. Record the documentation you received.

| Ingredient | Supplier name | Supplier contact / website | Price and pack size | Cost per gram | Spec sheet received? | Safety data sheet received? | Certificate of analysis? | Shelf life | Storage | Notes |
|---|---|---|---|---|---|---|---|---|---|---|
| | | | | | | | | | | |
| | | | | | | | | | | |
| | | | | | | | | | | |

Questions to ask a new supplier: Do you provide a specification sheet and safety data sheet for every ingredient? What is the shelf life and recommended storage? What is the minimum order, delivery time, and returns policy?

---

## 7. Launch Checklist

Work through this list for each product before it goes on sale. Do not skip a step.

- [ ] Formula stability tested for at least 4 weeks (ideally 8–12)
- [ ] Preservation reviewed; challenge test or microbial count arranged where appropriate
- [ ] pH measured and recorded, inside the target range
- [ ] Patch test completed (self and, where possible, volunteers) with results recorded
- [ ] Full ingredient list written in INCI names, in descending order
- [ ] Label drafted: product name, net contents, ingredient list, business name and address, batch number, shelf life / best-before date, period-after-opening symbol, warnings, directions for use
- [ ] Local cosmetics regulations checked (notification, registration, or safety assessment where required)
- [ ] Product liability insurance checked
- [ ] Product costed; selling price set with a real margin (see costing worksheet)
- [ ] Packaging tested with the product (leaks, compatibility, shelf storage)
- [ ] Retained sample from the batch stored and labelled
- [ ] Customer complaint / reaction-report process written down
- [ ] Supplier details and ingredient lot numbers filed with the batch record

Product name:
Date checklist completed:
Signed (maker):

---

## 8. Your First Three Batches — a starter plan

1. **Batch one:** Formula 1, Everyday Face Cream, 100 g. Follow the method exactly. Record everything. Measure the pH at cooling and at 24 hours.
2. **Batch two:** Formula 1 again, 100 g, with one deliberate change — for example, swap sweet almond oil for jojoba oil. Compare the two batches side by side. Which do you prefer, and why?
3. **Batch three:** Formula 16, Whipped Body Butter, 100 g. An anhydrous product, so you can practise working with butters and waxes without the emulsion step. Cost it with the costing worksheet.

After three batches, you will have a formulation worksheet, three batch records, pH readings, and a costed product. That is the system working. Keep going.
