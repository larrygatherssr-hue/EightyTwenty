# Tax-Prep Organizer

General education only — this organizer helps you gather records. It is not tax advice. Confirm what you need, and by when, with your CPA or tax professional.

## My tax facts

- Estimated combined tax rate on business profit: ____%
- Revenue-based set-aside percentage: ____%
- Estimated / instalment tax payment dates: ___________________________________________
- CPA / tax preparer: ______________________ Contact: ______________________
- Tax year end: ______________ Filing deadline: ______________

## Set-aside tracker

| Month | Revenue received | Set-aside % | Amount to Tax account | Date transferred |
|---|---|---|---|---|
| January | $ | % | $ | |
| February | $ | % | $ | |
| March | $ | % | $ | |
| April | $ | % | $ | |
| May | $ | % | $ | |
| June | $ | % | $ | |
| July | $ | % | $ | |
| August | $ | % | $ | |
| September | $ | % | $ | |
| October | $ | % | $ | |
| November | $ | % | $ | |
| December | $ | % | $ | |
| **Year total** | **$** | | **$** | |

## Quarterly estimated payments

| Quarter | Due date | Amount paid | Date paid | Confirmation # |
|---|---|---|---|---|
| Q1 | | $ | | |
| Q2 | | $ | | |
| Q3 | | $ | | |
| Q4 | | $ | | |
| **Total paid** | | **$** | | |

## Documents to gather (check off as filed)

- [ ] Last year's tax return and any carry-forward items
- [ ] Full-year profit and loss, by month
- [ ] Bank and card statements for all business accounts, full year
- [ ] Receipts folder, organized by category
- [ ] Mileage log, totalled for the year (total business miles: __________)
- [ ] Contractor payment totals and details (information returns may be required above a threshold — ask your CPA)
- [ ] Home-office measurement and costs
- [ ] Records of estimated tax payments made, with confirmations (see table above)
- [ ] New asset purchases (equipment, vehicle) with invoices
- [ ] Loan statements, if any
- [ ] Retirement contribution records, if any
- [ ] Health insurance premium records, if applicable to your structure

## Deduction categories to track during the year

Home office (business portion only) · Business vehicle use (mileage or actual expenses, business percentage only) · Business insurance, licences, professional fees · Software, tools, equipment, supplies · Advertising and marketing · Business travel and business meals (limits and documentation rules apply in many systems) · Contractor payments · Retirement contributions (where the structure and plan allow) · Health insurance premiums (in some structures and systems)

Do not claim personal expenses as business expenses, and do not estimate deductions from memory at tax time. Confirm availability and rules with your CPA.

## Questions for my CPA

1. ___________________________________________________________________________
2. ___________________________________________________________________________
3. ___________________________________________________________________________
