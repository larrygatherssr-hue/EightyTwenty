# Monthly Bookkeeping Checklist

**Month: _______________ Close completed on: _______________**

Do this in the first five working days of each month, for the month just ended.

## Gather

- [ ] Downloaded bank statements for all business accounts
- [ ] Downloaded card statements for all business cards
- [ ] Collected receipts for any cash spending
- [ ] Noted invoices issued and invoices received this month

## Record income

- [ ] Listed every payment received, by client and invoice
- [ ] Marked invoices issued but not yet paid
- [ ] Listed overdue invoices and chased the oldest one

## Record expenses

- [ ] Went through each statement line by line and categorized every transaction
- [ ] Looked up any unclear transaction now, while it is still fresh
- [ ] Filed receipts over $75 (named by date and vendor, e.g. 2026-03-04_OfficeDepot.jpg)

## Reconcile

- [ ] Compared records to bank statements — every statement transaction is in the books
- [ ] Bank balance matches book balance (difference, if any: $______ — explain it: __________________)
- [ ] Noted timing differences (e.g. a payment not yet cleared)

## Check the system

- [ ] Tax transfer happened as planned (amount: $______)
- [ ] Owner pay transfer happened as planned (amount: $______)
- [ ] Reserve transfer happened as planned (amount: $______)
- [ ] Mileage log updated (business miles this month: __________)

## Close

- [ ] Produced the one-page monthly summary (revenue, expenses by category, net, owner pay, tax set aside, closing balances)
- [ ] Calculated the five ratios (gross margin, net margin, operating expense ratio, receivables days, reserve coverage)
- [ ] Filed the month's records and backed them up (cloud copy as well as local)
- [ ] Updated the cash-flow forecast with actuals and rolled it forward one month

## Notes

Anything unusual this month: ___________________________________________

Questions for my bookkeeper or CPA: ___________________________________________
