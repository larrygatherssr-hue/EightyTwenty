# Owner-Pay Planner

## My sustainable owner pay

| Line | Annual | Monthly |
|---|---|---|
| Expected revenue | $ | $ |
| Business expenses | $ | $ |
| Tax set-aside | $ | $ |
| Reserve contribution | $ | $ |
| **Available for owner pay** | **$** | **$** |
| **My set owner pay** | **$** | **$** |

Formula: (Annual revenue − annual business expenses − annual tax − annual reserve target) ÷ 12 = sustainable monthly owner pay. If the result is below what your household needs, fix the business side (price, volume, or costs) or the personal side — do not quietly fund the business from personal savings without recording it and setting a limit.

## My pay plan

- Monthly owner pay: $__________
- Paydays: __________ and __________ of each month
- Transfer from: Owner Pay account → personal checking
- Structure: __________________ (sole proprietor / LLC / corporation / partnership — confirm the correct treatment with your CPA)
- Confirmed with my CPA on: ______________

## Personal budget check

| Personal monthly cost | Amount |
|---|---|
| Housing (rent/mortgage, utilities) | $ |
| Food and household | $ |
| Transport | $ |
| Insurance (personal) | $ |
| Debt payments (personal) | $ |
| Personal savings | $ |
| Other | $ |
| **Total household need** | **$** |
| **Owner pay** | **$** |
| **Gap (pay − need)** | **$** |

If there is a gap, my plan to close it: ___________________________________________

## Pay log

| Date | Amount | Type (regular / bonus) | Notes |
|---|---|---|---|
| | $ | | |
| | $ | | |
| | $ | | |
| | $ | | |
| | $ | | |
| | $ | | |

## Rules

- Pay stays the same in a bad month. The reserve absorbs the miss; the quarterly review decides whether pay changes.
- A bonus is decided at the quarterly review, only if the reserve is full and the tax account is on track. It is transferred once and recorded as owner pay (bonus).
- Never skip pay to "help" the business without a written note: how much, why, and when it resumes.
- Never take pay by swiping the business card for personal spending. Pay is a transfer, recorded as owner pay.
