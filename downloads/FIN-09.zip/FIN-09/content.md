# The Small Business Money System

## Cash Flow, Pricing, and Taxes in One Monthly System

**A complete course for small business owners and solopreneurs**

---

## Important Disclaimer — Please Read First

This course is general financial education. It is not individualized financial advice, tax advice, accounting advice, or legal advice, and it does not create a client relationship with any accountant, tax preparer, or financial adviser. Every business is different, and tax rules, deduction rules, and filing requirements vary by country, state, and business structure, and they change over time.

The examples in this course use simplified, illustrative numbers. They are teaching examples, not promises. No result is guaranteed. A business that follows this system may still have slow months, unexpected expenses, or a tax bill that surprises it. Use the material to understand your numbers better, then confirm decisions that affect tax, legal structure, payroll, or large financial commitments with a qualified CPA, enrolled agent, or tax professional who knows your specific situation.

If a section says "ask your CPA," that is not filler. It is the correct next step for that decision.

---

## Who This Course Is For

This course is for small business owners and solopreneurs, typically aged 30 to 55, with annual revenue roughly between $50,000 and $500,000, who are good at the work itself — the craft, the service, the product — and tired of feeling behind on the money side.

It is especially for you if any of these sound familiar:

- You price by feel, by what competitors charge, or by what a client will accept, and you are never quite sure whether a job actually made money.
- Personal and business money live in the same account, or in accounts you move money between without a clear rule.
- You find out about cash problems when the bank balance is already low, not weeks earlier when something could have been done.
- Tax time is a scramble: a box of receipts, a spreadsheet you have not opened since March, and a bill you did not expect.
- You pay yourself whatever is left over, which some months is plenty and some months is nothing.
- Your business looks busy and still feels broke.

You do not need an accounting background. You do not need expensive software to start. You need a system you can run in a few hours a month, with numbers you understand and decisions you can make before a problem arrives.

## Who This Course Is Not For

- Businesses with employees on payroll at scale, complex inventory, or multi-entity structures. The principles still apply, but you will need a bookkeeper and a CPA working with you, not instead of this course.
- Anyone looking for tax avoidance schemes, offshore structures, or ways to hide income. This course teaches clean, legal, boring-in-a-good-way money management.
- Anyone who wants a promise of a specific income. There is none here. There is a system that makes your real numbers visible so you can act on them.

## What You Will Have When You Finish

- Separate business accounts and a clear rule for moving money between business and personal.
- A 12-month cash-flow forecast you update monthly, so you see a shortfall six weeks before it happens.
- A pricing method built from your real costs, your time, and the margin you need — not from guesswork.
- A monthly bookkeeping routine that takes about two hours and keeps your records clean all year.
- A tax set-aside habit and a tax-prep organizer, so April is a filing, not a crisis.
- An owner-pay plan that pays you regularly and on purpose, instead of whatever is left.
- A monthly money meeting: one page, one hour, five decisions.

## How to Use This Course

The course has 10 modules, and this complete written text is the full teaching. Work through the modules in order the first time. Each module ends with action steps. Do them before moving on — the system is built by doing, not by reading.

You will need: your last 12 months of bank and card statements (business and, if mixed, personal), last year's tax return if you have one, and a list of your current prices and your biggest recurring costs. The workbook and templates that come with this course give you the forms to fill in as you go.

**The running example.** Throughout this course we follow one fictional business so the numbers stay consistent and comparable:

**Juniper Studio** — a two-person brand-design studio run by its owner, Dana. Annual revenue $240,000. One part-time contractor. No employees. Dana has been mixing personal and business money in one checking account, pricing projects by feel, and paying herself whatever is left. By Module 10, Juniper Studio runs on the full system. Every worked example that says "Juniper Studio" uses the same business, so you can watch the numbers build. A second, smaller example — **Rivera Home Repair**, a one-person trades business with $118,000 in revenue — appears where a different shape of business makes the point clearer.

All names, businesses, and figures are invented for teaching. Any resemblance to a real business is coincidence.

---

## Table of Contents

- Module 1 — The Money Map: Separate, See, and Simplify
- Module 2 — Cash Flow: Know Before You Need It
- Module 3 — Pricing for Profit: Build the Price from the Costs Up
- Module 4 — Owner Pay: Pay Yourself on Purpose
- Module 5 — Bookkeeping: The Two-Hour Monthly Close
- Module 6 — Taxes: The Set-Aside Habit and the Quarterly Rhythm
- Module 7 — Reserves, Debt, and Growth Decisions
- Module 8 — Reading Your Numbers: Profit and Loss, Balance Sheet, and the Five Ratios That Matter
- Module 9 — The Annual Plan: A Budget You Can Actually Keep
- Module 10 — The Monthly Money Meeting: Running the System for Good

---

# Module 1 — The Money Map: Separate, See, and Simplify

**Time: about 45 minutes of teaching. Action time: one afternoon to set up accounts.**

## The problem this module solves

Most small business money problems are not math problems. They are visibility problems. When personal and business money share an account, you cannot answer the simplest questions: Did the business make money last month? How much did I actually pay myself? What do I owe in tax? You are guessing, and guessing feels like stress.

The fix is not complicated accounting. It is separation and a map: every dollar has a home, and you can see, at a glance, where money comes in, where it sits, and where it goes.

## Lesson 1.1 — Why separation comes first

Mixing funds creates three real costs.

First, it costs you time. Every bookkeeping session becomes detective work: was that grocery run personal or a client lunch? Was that hardware store trip for the house or a job? A bookkeeper or CPA sorting that out bills by the hour, and you pay for the confusion.

Second, it costs you clarity. If the account holds $18,000, you do not know whether $14,000 of it is business money you need for rent and tax, or money you can safely spend. So you either spend too freely and hit a shortfall, or you live anxiously and underpay yourself even in good months.

Third, it can cost you legally. If your business is an LLC or corporation, mixing funds — lawyers call it commingling — can weaken the separation between you and the business. That separation is much of the point of having the entity. This course is not legal advice, and the details depend on your state and structure, but the practical rule is simple and safe: the business is the business, and you are you. Keep the money apart.

Dana at Juniper Studio had one checking account and one credit card for everything. In a typical month she could not say whether the studio had made $3,000 or lost $1,000. Her first week on the system was not about spreadsheets. It was about opening accounts.

## Lesson 1.2 — The five accounts

You need five business accounts. They can be checking or savings accounts at the same bank, or spread across banks if you prefer. The names matter more than the bank: name each account for its job, so a transfer is a decision, not a mystery.

1. **Income (operating checking).** All customer payments land here first. Nothing else goes in. This is the front door.
2. **Operating expenses (checking).** Rent, software, supplies, contractor payments, and day-to-day business costs come out of here. You fund it from Income on a set schedule.
3. **Tax (savings).** A fixed percentage of every payment goes here the moment it arrives, before you spend anything. This is not your money to spend. It is money you are holding for the tax authority.
4. **Owner pay (checking or savings).** Your pay comes from here, on a set schedule, like a salary. It is funded from Income on the same schedule as Operating.
5. **Profit / reserve (savings).** A small percentage of every payment goes here. This is your buffer and your reward — the account that turns a good quarter into a cushion instead of a spending spree.

If five accounts feel like a lot, start with three: Income, Tax, and Operating. Add Owner Pay and Profit/Reserve in your second month. But do not stay at one account. One account is the problem.

**A note on personal accounts.** Keep your personal checking and savings as they are. Your owner pay lands in your personal checking on payday, exactly like a salary from an employer. From that moment it is personal money, and you spend it however you like without guilt or tracking. The boundary is the transfer.

## Lesson 1.3 — The allocation habit

Every time money arrives in Income, you split it the same day, or on a fixed weekly allocation day if daily feels fussy. Percentages are targets you set once and adjust quarterly. Here is a starting split for a service business with moderate costs, and how it works on a $10,000 month:

| Account | Percentage | On $10,000 received |
|---|---|---|
| Tax | 25% | $2,500 |
| Owner pay | 40% | $4,000 |
| Operating expenses | 30% | $3,000 |
| Profit / reserve | 5% | $500 |
| **Total** | **100%** | **$10,000** |

These are starting points, not rules. A product business with heavy materials costs needs a larger operating share. A high-cost business may need 50% operating and 30% owner pay. A low-cost solo consultant might manage 20% tax, 50% owner pay, 25% operating, 5% profit. Module 4 works through owner pay in detail, and Module 6 works through the tax percentage. For now, pick percentages that add to 100 and that roughly match your last year's real split — you will refine them with real numbers in Module 8.

Dana's first allocation: Juniper Studio's average month brings in $20,000. She set Tax 25% ($5,000), Owner Pay 40% ($8,000), Operating 30% ($6,000), Profit 5% ($1,000). The first month felt tight in Operating — because for the first time, Operating was a real limit instead of "whatever is in the account." That tightness was information, not failure. It told her the studio's software and contractor costs were higher than she had assumed, which is exactly the kind of thing Module 3's pricing work would later fix.

## Lesson 1.4 — What counts as a business expense

A business expense is a cost that is ordinary and necessary for your business. Ordinary means common in your line of work. Necessary means helpful and appropriate, not indispensable. Keep it practical:

- **Clearly business:** rent for a business space, business software, tools and materials for jobs, business insurance, advertising, contractor payments, business travel, professional fees.
- **Mixed or partial:** a home office (only the business portion, measured by space or by a method your CPA approves), a phone used for both (the business percentage), a vehicle used for both (mileage or actual expenses by the business percentage). Keep a simple log. Guessing at tax time is how deductions get lost or overstated.
- **Personal, even if it feels work-related:** groceries, family travel, personal clothing (unless it is a uniform or protective gear required for the work), personal entertainment. Pay for these from your owner pay, after it lands in your personal account.

Rule of thumb for the whole course: **if you cannot explain in one sentence why the business needed it, pay for it personally.**

## Lesson 1.5 — The weekly 15-minute money check

Every Friday, or whatever day you choose, spend 15 minutes:

1. Check the Income account: what came in this week?
2. Make the allocations (or confirm the automatic transfers ran).
3. Check the Operating balance against the forecast (Module 2).
4. Note anything unusual: a late-paying client, a big bill coming, a refund.
5. Write one line in a notebook or note: the week's income, the week's biggest expense, and anything to watch next week.

Fifteen minutes a week prevents the three-hour panic at month end.

## Module 1 action steps

1. Open (or rename) your five business accounts. If your bank limits accounts, open the three essentials first: Income, Tax, Operating.
2. Move all business income to land in the Income account. Update your payment links, invoicing tool, and any marketplace payout settings.
3. Choose your starting allocation percentages. Write them down.
4. Do your first allocation on the next money that arrives.
5. Set a recurring calendar reminder: the Friday 15-minute money check.

**Outcome:** By the end of this module, business and personal money are separate, every dollar has a named home, and you can see your business balance without guessing.

---

# Module 2 — Cash Flow: Know Before You Need It

**Time: about 60 minutes of teaching. Action time: two hours to build your first forecast.**

## The problem this module solves

Profit and cash are not the same thing. A business can be profitable on paper and still run out of money, because the money arrives after the bills are due. A client pays in 45 days; rent is due on the 1st. A big project is invoiced in June and paid in August, while the contractor who helped deliver it is paid in June. This timing gap is the cash-flow problem, and it kills healthy businesses.

The solution is a forecast: a simple month-by-month (and, in busy periods, week-by-week) picture of money in and money out, so a shortfall shows up while there is still time to act.

## Lesson 2.1 — Cash flow is timing

Three timing patterns cause most cash-flow trouble:

- **Slow payers.** You do the work, you send the invoice, the client pays late. The gap between work and payment is an interest-free loan you gave your client.
- **Lumpy income.** A few big projects or a seasonal rush, then quiet weeks. The busy month's money has to carry the quiet month's bills.
- **Up-front costs.** You pay for materials, a contractor, or a venue before the client pays you. You are funding the job out of your own pocket.

A forecast does not fix slow payers by itself. It shows you, in advance, that a slow payer will create a $4,000 gap in the third week of next month — and that gives you time to chase the invoice, delay a purchase, or move a payment date.

## Lesson 2.2 — Build the 12-month forecast

Use the cash-flow forecast spreadsheet in your templates (cash-flow-forecast.csv). The structure is simple. For each month, list:

**Money in:** expected client payments (not invoices sent — payments you realistically expect to receive that month), product sales, any other income. Be honest about timing: if a client usually pays 30 days after invoicing, the money lands a month after the invoice date.

**Money out:** rent, payroll/contractors, software subscriptions, insurance, materials, loan payments, owner pay transfers, tax set-asides, and a line for "other / unexpected."

**The three lines that matter:**

- Opening balance (what you start the month with)
- Net cash flow (money in minus money out)
- Closing balance (opening plus net)

If the closing balance goes negative in any month, you have found a problem while it is still a forecast — which is the entire point.

**Juniper Studio worked example — a three-month forecast.** Dana's studio starts March with $14,000 in the Income account. She has two large projects invoiced, one retainer client, and regular costs. Her forecast:

| | March | April | May |
|---|---|---|---|
| Opening balance | $14,000 | $15,500 | $11,700 |
| Client payments received | $22,000 | $16,000 | $26,000 |
| Total money in | $22,000 | $16,000 | $26,000 |
| Rent | $1,800 | $1,800 | $1,800 |
| Contractor | $4,500 | $3,000 | $5,000 |
| Software & tools | $620 | $620 | $620 |
| Insurance | $240 | $240 | $240 |
| Owner pay transfer | $8,000 | $8,000 | $8,000 |
| Tax set-aside | $5,500 | $4,000 | $6,500 |
| Other / misc. | $840 | $2,140 | $940 |
| Total money out | $21,500 | $19,800 | $23,100 |
| Net cash flow | +$500 | −$3,800 | +$2,900 |
| **Closing balance** | **$15,500** | **$11,700** | **$14,600** |

Reading it: March is fine. April is tight — the studio spends $3,800 more than it brings in, because a big client pays in May, not April. But Dana can see that in March. She has choices: ask the May client for a 50% deposit in April, move a $1,500 software renewal to May, or simply accept the dip because the closing balance stays above $10,000. Without the forecast she would have discovered April's tightness in the middle of April, with no time to change anything.

**Rivera Home Repair example — seasonality.** Rivera's revenue peaks in spring and summer (outdoor repairs) and dips in January and February. His forecast shows January closing at $2,100 after a $3,400 negative month. His fix is different from Dana's: he builds the reserve in the good months (Module 7) and offers winter maintenance packages in November to smooth January. Same tool, different answer — that is why the forecast is yours, not a template answer.

## Lesson 2.3 — The 13-week cash view

When money is tight, or during a busy or seasonal period, run a weekly view for the next 13 weeks: expected receipts each week, bills due each week, and the running balance. Weekly is where the real pinches hide — a month can look fine while one bad week inside it goes negative.

Update the weekly view every Friday in your 15-minute check. It takes five minutes once the monthly forecast exists, because you are only moving numbers between weeks as dates firm up.

## Lesson 2.4 — Five levers when the forecast shows a gap

When a future month goes negative or too low, you have five levers. Use them in this order:

1. **Speed up money in.** Invoice immediately on delivery, not at month end. Ask for deposits (30–50% up front is normal in many service businesses). Offer a small discount for payment within 7 days. Chase overdue invoices the day they become overdue — polite, prompt, persistent.
2. **Slow down money out (without breaking trust).** Ask a supplier for 30-day terms. Move a discretionary purchase to next month. Pause a subscription you are not using. Do not delay paying contractors who did the work — that is a reputation cost you cannot afford.
3. **Cut or pause a cost.** Subscriptions are the classic leak: the average small business in this course's experience pays for tools it has not opened in months. Audit them quarterly.
4. **Use the reserve.** That is what the Profit/Reserve account is for. A planned dip into reserves is a system working, not a failure. Record it and rebuild it.
5. **Borrow deliberately, as a last resort.** A short-term line of credit, used to bridge a known, dated receivable, is a tool. Borrowing to cover an ongoing loss is not a plan — it is a delay. If the forecast shows a structural gap (money out exceeds money in month after month), the fix is pricing or costs, covered in Modules 3 and 7, not a loan.

## Lesson 2.5 — Getting paid faster: terms that protect you

- **Deposit up front.** For project work, 30–50% before you start. For product orders, payment before shipping or on delivery.
- **Clear payment terms on every invoice.** "Due within 14 days" beats "due upon receipt" for getting paid on time, because it gives a real date. Put the due date on the invoice, not just the terms.
- **Late fees, stated kindly.** "A 1.5% monthly late fee applies after the due date" is standard and rarely needs enforcing — the sentence itself speeds payment.
- **One reminder system.** Day 1 after due: friendly reminder. Day 7: firmer reminder with a new copy of the invoice. Day 14: phone call. Day 30: pause further work until the balance is settled, and say so in advance in your terms.

## Module 2 action steps

1. Fill in the cash-flow forecast spreadsheet for the next 12 months. Start with the next three months in detail; months 4–12 can be rougher estimates.
2. Circle any month where the closing balance drops below one month of operating costs. Those are your watch months.
3. For the nearest watch month, pick one lever from Lesson 2.4 and act on it this week.
4. Set a monthly reminder: update the forecast on the first working day of the month with actuals, and roll it forward one month.

**Outcome:** You can see the next 12 months of cash, you know which months are tight and why, and you have a plan for each tight month before it arrives.

---

# Module 3 — Pricing for Profit: Build the Price from the Costs Up

**Time: about 60 minutes of teaching. Action time: two hours to reprice your top three offers.**

## The problem this module solves

Most small business owners price backwards: they look at what competitors charge, or what they think a customer will pay, and hope the costs fit underneath. Often they do not. The business stays busy and the owner stays broke, because the price was set by the market's guess instead of the business's own numbers.

Pricing from the costs up flips that. You work out what a job truly costs — including your time, overhead, and the margin the business needs — and that gives you a floor. The market tells you whether the floor is achievable. If it is not, you change the offer, the costs, or the customer — you do not quietly absorb the loss.

## Lesson 3.1 — The three costs every price must cover

Every price must cover three things, in this order:

1. **Direct costs.** What this specific job costs you: materials, a contractor's hours on this job, delivery, transaction fees, any cost that only exists because this job exists.
2. **Your time.** Your hours on the job, valued at a real hourly rate — not $0 because you are the owner. Unpaid owner time is the most common hidden subsidy in small business.
3. **Overhead and margin.** Your share of rent, software, insurance, and other costs that exist whether or not this job happens — plus profit. A price that covers direct costs and time but leaves nothing for overhead or profit is a hobby with invoices.

If a price does not cover all three, you are paying the customer for the privilege of working for them.

## Lesson 3.2 — Your real hourly rate

Before you can price a job, you need to know what an hour of your time must earn. Work it out like this:

**Step 1 — Your target owner pay.** How much do you need the business to pay you in a year? Be honest. Include the pay you need to live on. Dana's target: $96,000 a year ($8,000 a month).

**Step 2 — Your annual business overhead.** Rent, software, insurance, marketing, accounting, and other costs that are not tied to a single job. Juniper Studio: $42,000 a year.

**Step 3 — Your billable hours.** How many hours a year do you actually do work a client pays for? Not admin, not marketing, not learning — billable work. A realistic number for a solo owner is 1,000–1,300 hours a year (roughly 20–25 billable hours a week for 50 weeks). Dana's: 1,100 hours.

**Step 4 — The calculation.**

Required hourly rate = (target owner pay + annual overhead) ÷ billable hours

Dana: ($96,000 + $42,000) ÷ 1,100 = $138,000 ÷ 1,100 = **$125.45 per billable hour**

That is Dana's floor rate — the rate at which the studio covers her pay and its overhead if she bills 1,100 hours. Anything below it, sustained over a year, means either lower pay or an uncovered overhead bill. She rounds her working rate to $135 an hour to leave room for non-billable time and a small profit margin. That rounding is a decision, made with the number in front of her — very different from guessing.

**Rivera Home Repair.** Target owner pay $72,000, overhead $28,000 (truck, insurance, tools, phone), billable hours 1,400 (trades work bills more hours). ($72,000 + $28,000) ÷ 1,400 = $71.43 an hour. His working rate: $85 an hour, plus materials at cost plus 20%. Before this exercise he was charging $55 an hour because "that is what people around here charge." At $55 he was earning well below his target and had no idea why the year always ended tight.

## Lesson 3.3 — The pricing build-up: a worked example

Use the pricing calculator in your templates (pricing-calculator.csv). The build-up for a single job has five lines:

**Juniper Studio — brand identity package for a local bakery.**

| Line | Calculation | Amount |
|---|---|---|
| Direct costs (contractor illustrator, stock photos, printing proofs) | actual quotes | $1,850 |
| Your time (24 hours × $135 working rate) | 24 × $135 | $3,240 |
| Overhead share (10% of time + direct costs, as a simple method) | 10% × $5,090 | $509 |
| Subtotal (true cost) | $1,850 + $3,240 + $509 | $5,599 |
| Profit margin (20% on the subtotal) | 20% × $5,599 | $1,120 |
| **Price** | | **$6,719 → round to $6,750** |

Dana had been charging $4,500 for this package — $2,250 less than the built-up price. At $4,500 she covered direct costs and part of her time, and nothing else. Every package she sold made the studio poorer in real terms, while looking successful. The fix was not to apologize for the new price. It was to present the package's value clearly, keep the scope tight, and let the clients who only wanted a $4,500 logo go to someone else.

**Rivera Home Repair — bathroom faucet replacement and re-caulking.**

| Line | Calculation | Amount |
|---|---|---|
| Materials (faucet, supply lines, sealant) at cost | actual | $210 |
| Materials markup (20%) | 20% × $210 | $42 |
| Labour (3 hours × $85) | 3 × $85 | $255 |
| Travel / overhead share | flat | $45 |
| Subtotal | | $552 |
| Profit margin (15%) | 15% × $552 | $83 |
| **Price** | | **$635** |

Rivera had been quoting $420 for this job — below his true cost once his own time was valued. The $635 price felt high to him until he saw the build-up. Customers who want the cheapest faucet job are not his customers; customers who want it done right, on time, by someone who answers the phone are.

## Lesson 3.4 — Margin and markup are not the same

Confusing margin and markup is a classic pricing error, and it always costs you money.

- **Markup** is a percentage added to cost. Cost $100, markup 25%, price $125.
- **Margin** is the percentage of the price that is profit. Price $125, cost $100, profit $25, margin 20% ($25 ÷ $125).

If you want a 25% margin, you need a 33.3% markup: cost $100, price $133.33, profit $33.33, margin 25%. If you apply a 25% markup when you meant a 25% margin, you have given away a third of the profit you intended. Decide which one you mean, write it on your pricing sheet, and use the calculator to check it.

## Lesson 3.5 — Raising prices on existing customers

Raising prices feels harder than setting them for new customers. Three rules make it manageable:

1. **Raise on new work first.** New clients get the new price from today. Existing clients get notice — 30 days is fair — and the new price from a stated date.
2. **Give a reason, not an apology.** "From June 1, the brand identity package is $6,750, reflecting the full scope including illustration and print proofs" is a statement. Long apologies invite negotiation.
3. **Raise a little, often.** A 5–8% rise once a year is absorbed far more easily than a 30% rise after three years of silence. Put an annual price review in your calendar (Module 9).

If a client leaves over a justified price rise, you have learned something valuable: they were buying the low price, not your work. Replacing them with a client who pays the real price is a gain, not a loss.

## Lesson 3.6 — Discounts: the quiet profit killer

A 10% discount does not cost you 10% of your profit. It costs far more, because your costs do not shrink. On a job priced at $1,000 with $700 of costs, profit is $300. A 10% discount takes the price to $900 and profit to $200 — a third of your profit gone for a 10% gesture. A 20% discount takes profit to $100 — two-thirds gone.

If you discount, discount with a reason and a limit: a first-order offer, a payment-in-full incentive, a bundle. Never discount because a client asked and you felt awkward. Awkward is cheaper than broke.

## Module 3 action steps

1. Calculate your real hourly rate using Lesson 3.2.
2. Price your top three offers with the build-up method. Write down the current price and the built-up price side by side.
3. For any offer where the built-up price is more than 15% above the current price, decide this week: raise the price, reduce the scope or cost, or retire the offer.
4. Put an annual price review date in your calendar.

**Outcome:** Every price you quote has a costed floor underneath it, and you know which offers make money and which ones only look busy.

---

# Module 4 — Owner Pay: Pay Yourself on Purpose

**Time: about 45 minutes of teaching. Action time: one hour to set your pay plan.**

## The problem this module solves

"Pay yourself whatever is left" is the most common pay plan in small business, and it fails in both directions. In good months you overpay yourself and leave the business short. In bad months you pay yourself nothing and quietly fund the business from your personal savings, which hides the problem and burns you out. Either way, you never know what the business can actually afford to pay you — and that is the number everything else depends on.

Owner pay is a transfer on a schedule, for a set amount, decided in advance. Like a salary. Because that is what it is.

## Lesson 4.1 — How much can the business afford?

Start with the last 12 months of real numbers:

1. Total revenue for the year.
2. Total business expenses for the year (excluding anything you already paid yourself).
3. Tax you paid or owe for the year.
4. What is left is what the business could have paid you and still covered its costs — before reserves.

**Juniper Studio, last year:** Revenue $240,000. Business expenses (rent, contractor, software, insurance, other) $82,000. Tax $38,000. Left for owner pay and reserves: $120,000. Dana actually took $104,000 in irregular drips and lump sums, and the reserve account ended the year at $3,000. The business could afford $8,000 a month in owner pay with $2,000 a month going to tax already accounted for — but because the pay was irregular, Dana felt broke in February and flush in October, while the business as a whole was doing fine.

**Rivera Home Repair, last year:** Revenue $118,000. Expenses $34,000. Tax $17,000. Left: $67,000. Rivera took $58,000 and kept no reserve. His sustainable pay is about $5,000 a month, with $500 a month to reserves — if he prices correctly (Module 3) and the work stays steady.

The formula for your sustainable monthly owner pay:

(Annual revenue − annual business expenses − annual tax − annual reserve target) ÷ 12

If that number is lower than what you need to live on, you have a clear problem statement: either revenue must rise, costs must fall, or prices must rise. That is useful. Guessing is not.

## Lesson 4.2 — The owner-pay calculation: worked example

Dana's plan for the coming year, built from her forecast rather than last year's luck:

| Line | Annual | Monthly |
|---|---|---|
| Expected revenue | $264,000 | $22,000 |
| Business expenses (rent, contractor, software, insurance, other) | $84,000 | $7,000 |
| Tax set-aside (25% of revenue, Module 6) | $66,000 | $5,500 |
| Reserve contribution (5% of revenue) | $13,200 | $1,100 |
| **Available for owner pay** | **$100,800** | **$8,400** |

Dana sets her owner pay at $8,000 a month — slightly below the $8,400 the plan supports, so the extra $400 a month builds the reserve faster. She pays herself twice a month, on the 1st and the 15th, $4,000 each time, transferred from the Owner Pay account to her personal checking. In a month when revenue beats the forecast, the surplus stays in the business until the quarterly review (Module 10), when she decides whether it becomes a bonus, a reserve top-up, or a tax top-up. In a month when revenue misses, her pay does not change — the business absorbs the miss from the reserve, and the quarterly review decides whether pay needs adjusting. That stability is the point: your household budget should not swing with every late invoice.

## Lesson 4.3 — Salary, draw, or both

How you take the money depends on your business structure, and this is a question for your CPA — the rules and tax treatment differ for sole proprietors, LLCs, partnerships, and corporations, and getting it wrong is expensive. In general terms:

- **Sole proprietors and single-member LLCs (default treatment):** the owner typically takes a draw — a transfer from the business to the owner. The business's profit is generally taxed whether or not you draw it, which is one more reason the tax set-aside matters.
- **Corporations and LLCs taxed as corporations:** the owner is typically an employee and takes a salary through payroll, with tax withheld. This adds payroll administration and cost, and it has rules about reasonable compensation.
- **Partnerships:** partner draws under the partnership agreement.

Whatever your structure, the discipline is the same: a set amount, on a set schedule, recorded as owner pay. Do not take money by swiping the business card at the grocery store. That is not pay. That is commingling, and it destroys your records (Module 1).

## Lesson 4.4 — Personal budget: the other half of the equation

Owner pay only works if your personal spending fits inside it. If your household needs $9,000 a month and the business can sustainably pay $7,000, no amount of money-system discipline closes that gap by itself. You need to know the household number. Add up your personal monthly costs — housing, food, transport, insurance, debt payments, personal savings — and compare them with your owner pay. If pay is short:

- In the short term, cut a personal cost or use savings deliberately, with a date to stop.
- In the medium term, fix the business side: price, volume, or costs (Modules 3, 7, 9).
- Do not quietly fund the business from personal savings month after month without recording it and setting a limit. Silent subsidy is how owners wake up two years later with an empty savings account and a business that was never viable at its prices.

## Lesson 4.5 — Bonuses, bad months, and the quarterly review

- **Good quarter?** At the quarterly review, if the reserve is full and the tax account is on track, a bonus is fine. Decide the amount in the review, transfer it once, and record it as owner pay (bonus).
- **Bad month?** Pay stays the same. The reserve absorbs it. If two bad months in a row use the reserve, the quarterly review asks whether pay or costs need to change — a decision made with numbers, not panic.
- **Never skip pay to "help" the business** without a written note: how much, why, and when it resumes. Unrecorded sacrifice becomes permanent sacrifice.

## Module 4 action steps

1. Work out your sustainable monthly owner pay from last year's numbers.
2. Set your pay amount and paydays. Write them down and put them in your calendar.
3. Add up your personal monthly costs. Compare. If there is a gap, write down which side of the gap you will fix and by when.
4. Confirm with your CPA how owner pay should be treated under your business structure.

**Outcome:** You are paid regularly, on purpose, at an amount the business can sustain — and your household budget is built on a number you can trust.

---

# Module 5 — Bookkeeping: The Two-Hour Monthly Close

**Time: about 45 minutes of teaching. Action time: two hours for your first close, then two hours a month.**

## The problem this module solves

Bookkeeping has a reputation problem. Owners imagine hours of data entry and a shoebox of receipts. In practice, a small business with separated accounts and a simple routine can close its books in about two hours a month. The cost of not doing it is much higher: a tax return built on guesses, a loan application with no records, and a business you cannot value, sell, or even understand.

Bookkeeping is not about perfection. It is about a record that is complete, categorized, and current enough that you can answer questions from it.

## Lesson 5.1 — What bookkeeping actually is

Three things, nothing more:

1. **Record.** Every business transaction is captured: money in, money out, who it was with, and what it was for.
2. **Categorize.** Each transaction gets a category: Revenue (by type if useful), Rent, Contractor Costs, Software, Materials, Insurance, Marketing, Travel, Meals (business), Professional Fees, Owner Pay, Tax, Other.
3. **Reconcile.** Once a month, you check that your records match the bank's records. If the bank says $14,620 and your books say $14,620, you are done. If they differ, you find the missing or duplicated item.

That is it. You do not need double-entry accounting knowledge to do this well. You need consistency.

## Lesson 5.2 — Choose your tool (and keep it simple)

Pick one and stick with it for a year:

- **A spreadsheet.** The templates in this course include a monthly bookkeeping tracker. It is enough for a business with under about 100 transactions a month, and it forces you to understand your numbers.
- **Accounting software.** A simple cloud accounting package automates bank feeds and categorization. It costs a monthly subscription and saves time once set up. If you choose software, set aside an afternoon to connect your business accounts and set up your categories — and do not connect personal accounts to it.
- **A bookkeeper.** If you hate this work, hire it out — but hire it as a monthly service with a fixed close date, not as a once-a-year rescue. A bookkeeper who closes your books monthly costs far less than a CPA untangling a year of chaos, and you still need to review the reports (Module 8). Outsourcing the data entry does not outsource the understanding.

Whichever you choose, the discipline is the same: business transactions only, categorized, reconciled monthly.

## Lesson 5.3 — The monthly close, step by step

Do this in the first five working days of each month, for the month just ended. Put it in your calendar as a recurring appointment. The checklist in your workbook walks through it; here is the flow:

1. **Gather.** Download the bank and card statements for all business accounts. Collect receipts for any cash spending. Note any invoices issued or received.
2. **Record income.** List every payment received, by client and invoice. Mark any invoice that is overdue.
3. **Record expenses.** Go through each account statement line by line. Categorize each transaction. If a transaction is unclear, look it up now — not in six months, when you will not remember it.
4. **File receipts.** For any expense over a small threshold you set (say, $75), keep the receipt — digital is fine. Name the file by date and vendor (2026-03-04_OfficeDepot.jpg). Keep business receipts separate from personal ones.
5. **Reconcile.** Compare your records to the bank statement. Every transaction on the statement must be in your books, and every transaction in your books must be on the statement (or be a timing difference, like a cheque not yet cleared — note it).
6. **Check the allocations.** Confirm the tax, owner pay, and reserve transfers happened as planned. If revenue was unusually high or low, adjust the amounts — by the percentage, not by feel.
7. **Produce the one-page summary.** Revenue, expenses by category, net, owner pay, tax set aside, closing balances. This one page is the input to the Monthly Money Meeting (Module 10).
8. **File and back up.** Save the month's records where you can find them. Back them up — a cloud copy as well as a local one.

Dana's first close took four hours, because she was also cleaning up three months of backlog. Her second took two hours. Her fourth took ninety minutes. The time falls as the habit forms, because there is less detective work each month.

## Lesson 5.4 — Receipts, mileage, and the audit folder

You do not need to keep every coffee receipt. You do need a system that would survive a question about a deduction. Keep:

- Receipts or invoices for business purchases, especially anything over your $75 threshold and anything you will deduct.
- A mileage log for business driving: date, destination, purpose, miles. A simple notebook or an app is fine; a memory is not a log.
- Contracts, engagement letters, and loan documents.
- Tax returns and supporting documents, for at least the period your tax authority requires (ask your CPA how long to keep them — in the United States the common guidance is at least three years from filing, longer in some situations).

Keep the audit folder in one place, digital or physical, organized by year and month. The tax-prep organizer in your templates (Module 6) is built around this folder — if the folder is in order, tax prep is an afternoon, not a month.

## Lesson 5.5 — Common bookkeeping mistakes

- **Recording the transfer as an expense.** Moving money from Income to Tax is not an expense. It is a transfer between your own accounts. Only the eventual tax payment is an expense (or, more precisely, a tax payment). The same applies to owner pay transfers: the pay is a draw, not a business expense in the usual sense for a sole proprietor — your CPA will confirm the treatment for your structure.
- **Recording the invoice instead of the payment.** Revenue for cash-flow purposes is money received. An invoice sent in March and paid in May is May income for your cash forecast, even if your accounting method records it differently. Know which view you are looking at (Module 8 covers cash vs. accrual briefly).
- **Forgetting the small recurring charges.** The $19-a-month tool, the $9 domain renewal, the annual insurance premium. They add up to thousands a year. The monthly close catches them.
- **Doing it all in December.** A year of bookkeeping done in one panicked month is the most expensive way to do it. Monthly is cheaper in time, money, and stress.

## Module 5 action steps

1. Choose your bookkeeping tool and set up your categories.
2. Do a close for last month, even if it is messy. A messy close you finish beats a perfect close you never start.
3. Set up your receipt folder and your mileage log.
4. Put the monthly close in your calendar for the first five working days of every month.

**Outcome:** Your books are closed monthly, reconciled to the bank, and ready to answer questions — from you, your CPA, or a lender — at any time.

---

# Module 6 — Taxes: The Set-Aside Habit and the Quarterly Rhythm

**Time: about 60 minutes of teaching. Action time: one hour to set your percentage and organizer.**

## The problem this module solves

Tax is the most common "surprise" in small business, and it is the most preventable. The bill is not a surprise because tax is unpredictable. It is a surprise because the money was spent during the year and the bill arrives later. The set-aside habit fixes that: every time money arrives, the tax portion goes into the Tax account before you can spend it. The bill, when it comes, is already funded.

This module is general education about how small business tax usually works. It is not tax advice for your situation. Tax law depends on your country, state, business structure, and income, and it changes. Use this module to understand the shape of the system and to have a useful conversation with your CPA. Do not use it as a substitute for one.

## Lesson 6.1 — Why small business tax feels different

If you used to be an employee, tax was invisible: your employer withheld it from each paycheck. As a business owner, nobody withholds it for you. The income arrives in full, you spend it, and the tax bill arrives months later. That timing gap is the whole problem.

Most small business owners in the United States, for example, pay income tax on business profit and, depending on structure, self-employment tax. Many pay estimated tax quarterly — four payments a year — rather than one annual bill. Other countries have their own equivalents: instalments, provisional tax, or payments on account. The name changes; the discipline does not: set money aside when it arrives, and pay on schedule.

Ask your CPA three questions at your next conversation: (1) What is my estimated total tax rate on business profit, including income tax and any self-employment or equivalent tax? (2) Am I required to pay estimated or instalment tax, and on what dates? (3) What records do you need from me, and by when? Write the answers down. They set your set-aside percentage and your calendar for the year.

## Lesson 6.2 — The tax set-aside: a worked example

Dana's CPA estimated her combined effective rate at roughly 25% of profit (a simplified teaching figure — her real rate depends on deductions, credits, and her full tax picture). Her set-aside rule is therefore 25% of revenue received, transferred to the Tax account the day the money arrives, because for her business, profit runs close enough to revenue minus the costs she already funds from the Operating account that a revenue-based percentage is simple and safe. She would rather over-save slightly and get a refund than under-save and owe a balance.

**Juniper Studio — tax set-aside on a $22,000 month:**

| Line | Amount |
|---|---|
| Revenue received in the month | $22,000 |
| Tax set-aside (25%) transferred to Tax account | $5,500 |
| Owner pay transfer (40%) | $8,800 |
| Operating transfer (30%) | $6,600 |
| Profit/reserve transfer (5%) | $1,100 |
| **Total allocated** | **$22,000** |

Over a year at $264,000 of revenue, the Tax account receives $66,000. Dana's actual annual tax bill, after deductions, comes to about $58,000. The $8,000 surplus stays in the Tax account as a buffer for the next year or moves to reserves at the annual review. She would much rather explain an $8,000 surplus to herself than find an $8,000 shortfall in April.

**Rivera Home Repair — tax set-aside on a $9,500 month:** Rivera's CPA estimated his combined rate at about 20% of profit. His revenue-based set-aside is 18% of revenue ($1,710), because his materials costs are high and his profit margin is lower than Dana's — his CPA helped him calibrate the revenue percentage so it approximates his profit-based liability. The lesson is not the number. The lesson is that the number comes from a conversation with a professional, is written down, and is applied automatically.

**Calibrating your percentage.** A revenue-based percentage is a shortcut. The accurate way is profit-based: estimate your annual profit (revenue minus deductible expenses), apply your estimated combined tax rate, divide by 12 for the monthly amount, and express that as a percentage of monthly revenue for automatic transfers. Revisit the percentage at each quarterly review, and whenever revenue or costs change materially. If you consistently over-save by a lot, lower the percentage and free the cash for owner pay or reserves. If you under-save, raise it immediately — do not wait for April.

## Lesson 6.3 — Quarterly estimated payments

If your tax system requires quarterly payments, the rhythm is:

1. At each quarter end, your bookkeeper or CPA (or you, using your closed books) estimates the profit so far and the tax due for the quarter.
2. You pay the estimated amount from the Tax account — never from Operating, and never from your personal account without recording it.
3. You record the payment: date, amount, period covered, confirmation number.
4. At year end, the estimates are reconciled against the actual return. Overpayment comes back as a refund or a credit. Underpayment is due with the return — and should be small, because the set-aside was running all year.

Put the quarterly due dates in your calendar at the start of the year, with a reminder two weeks before each one. A missed estimated payment can attract interest or penalties in some systems, and it is an entirely avoidable cost.

## Lesson 6.4 — Deductions: what to track all year (and what not to invent)

Common deductible categories for small businesses (availability and rules vary — confirm with your CPA):

- Home office (the business portion, by a method your CPA approves)
- Business use of a vehicle (mileage or actual expenses, business percentage only)
- Business insurance, licences, and professional fees
- Software, tools, equipment, and supplies
- Advertising and marketing
- Business travel, and business meals (with limits and documentation rules in many systems)
- Contractor payments (which may require information returns, such as a 1099 in the United States, above a threshold — ask your CPA)
- Retirement contributions for the owner, where the structure and plan allow them
- Health insurance premiums for the owner, in some structures and systems

What not to do: do not claim personal expenses as business expenses, do not estimate deductions from memory at tax time, and do not buy things in December "for the tax deduction" unless the business genuinely needs them. A deduction saves you your tax rate on the purchase — at a 25% rate, a $1,000 purchase "saves" $250 in tax and still costs you $750. Buy what the business needs. Let the deduction follow.

## Lesson 6.5 — The tax-prep organizer

The tax-prep organizer template in this course is a checklist and a file list. Starting in January (or your tax year's equivalent), work through it:

- Last year's return and any carry-forward items
- Full-year profit and loss, by month
- Bank and card statements for all business accounts
- Receipts folder, organized by category
- Mileage log total
- Contractor payment totals and their details
- Home-office measurement and costs
- Records of estimated tax payments made, with confirmations
- Any new asset purchases (equipment, vehicle) with invoices
- Loan statements, if any
- A list of questions for your CPA

If your monthly close (Module 5) is current, gathering this takes an afternoon. If it is not, this is the moment the year of skipped closes becomes expensive — in your time, your CPA's fees, or both.

## Lesson 6.6 — Choosing and using a CPA

A good CPA for a small business does three things: keeps you compliant, helps you plan (estimated payments, structure, timing of big purchases), and answers questions before you act, not after. When choosing one, ask: Do you work with businesses my size and in my line of work? What do you need from me monthly or quarterly? What is your fee, and what does it include? How do we communicate, and how quickly do you reply?

Meet your CPA at least twice a year: once for planning (mid-year is ideal — there is still time to change the outcome), and once for filing. Bring your closed books, your forecast, and your questions. The planning meeting is where the money is saved. The filing meeting is where the paperwork is done.

## Module 6 action steps

1. Ask your CPA for your estimated combined tax rate and your estimated payment dates. Write them down.
2. Set your tax set-aside percentage and set up the automatic transfer.
3. Put the quarterly payment dates in your calendar with two-week reminders.
4. Start the tax-prep organizer now, not in January: file this month's documents into it as you go.

**Outcome:** Tax is funded as you earn, paid on schedule from a dedicated account, and filed from records that are already in order.

---

# Module 7 — Reserves, Debt, and Growth Decisions

**Time: about 45 minutes of teaching. Action time: one hour to set reserve targets and review debt.**

## The problem this module solves

A business with no reserve is one bad month away from a crisis, and a business with no plan for debt pays for its past with its future. Reserves and debt are two sides of the same question: how much safety do you have, and how much is your past borrowing costing you now? Growth decisions — hiring, a new service, a bigger space — are the third side: they are bets, and this module teaches you to size the bet before you place it.

## Lesson 7.1 — The reserve: your business's shock absorber

Your reserve (the Profit/Reserve account from Module 1) has one job: to let the business survive a bad month, a late-paying client, or a broken essential tool without panic borrowing or skipped owner pay.

**Target:** Three months of operating expenses, as a first goal. Six months if your income is seasonal or lumpy. Juniper Studio's monthly operating expenses are about $7,000, so Dana's first reserve target is $21,000. She builds it at 5% of revenue — about $1,100 a month at current revenue — so it takes roughly 19 months to fill from zero. That is fine. A reserve built slowly is still a reserve, and every month it grows, the business gets safer.

**Rules for the reserve:**

- It is not a savings account for a holiday. It is business money with a job.
- Using it is allowed — that is what it is for. But every use is recorded, with a plan to rebuild it.
- It is not to be used for routine overspending. If you dip into it every month, the problem is pricing or costs, not luck.
- When it reaches its target, the monthly contribution can shrink, and the freed money can go to owner pay, a bonus, or a planned investment — decided at the quarterly review, not on impulse.

**Rivera Home Repair** has a seasonal twist: his slow months are January and February, when revenue can fall by 40%. His reserve target is four months of operating expenses ($11,200 at $2,800 a month), built during the spring and summer peak. His reserve is not a luxury. It is how January gets paid for.

## Lesson 7.2 — Debt: know what it costs

List every business debt: who it is owed to, the balance, the interest rate, the monthly payment, and the payoff date. Then sort them:

- **Productive debt** funded something that earns money: a vehicle you use for jobs, equipment that lets you take on work you could not otherwise do. It still needs a payoff plan, but it was a business decision.
- **Survival debt** covered a gap: a credit card that paid rent in a slow month, a loan that covered a tax bill. It needs a payoff plan and a fix for the gap that created it, or it will recur.

**The payoff order.** Generally, pay the highest-interest debt first while making minimum payments on the rest (the "avalanche" method), because it costs the least in total interest. If a small balance is demoralizing you and paying it off would free your attention, paying the smallest first (the "snowball" method) is acceptable — the best payoff plan is the one you will actually follow. Either way, stop adding new debt while you pay the old debt down, and put the payoff in the monthly forecast so it is a line item, not a hope.

**Worked example.** Rivera has a $6,000 credit-card balance at 24% annual interest, used for truck repairs and materials during a slow winter. Minimum payment $180 a month. At that pace, paying mostly interest, the balance takes years to clear and costs thousands in interest. His plan: pay $500 a month from the Operating account (funded by the pricing rise in Module 3), clear it in about 14 months, and never use the card for operating costs again. The card stays for emergencies only, and emergencies are what the reserve is for — so as the reserve grows, the card's role shrinks.

**Before borrowing again, ask:** What exactly will this money earn or save? When will it be repaid, from what income? What happens if that income is late? If you cannot answer in one paragraph, do not borrow yet.

## Lesson 7.3 — Growth decisions: the pre-mortem

Growth feels good and can be expensive. Before hiring, renting a bigger space, launching a new service, or buying equipment, run a pre-mortem: imagine it is a year later and the decision failed. Write down the three most likely reasons it failed. Then check whether you can prevent each one, and what the decision costs if it fails.

**The numbers for a growth decision:**

1. **The full cost.** Not just the purchase price — the monthly cost for a year, including the time it takes from you.
2. **The breakeven.** How much extra revenue, or how much cost saved, does it need to produce to pay for itself? Over what period?
3. **The funding.** Reserve, current cash flow, or borrowing? If borrowing, what is the repayment, and what happens if the extra revenue is 50% lower than expected?
4. **The exit.** Can you undo it? A month-to-month hire or a short lease is a different bet from a five-year lease or a large equipment loan.

**Juniper Studio example — hiring a part-time designer.** Dana considers hiring a designer for 15 hours a week at $35 an hour: $2,100 a month, plus about $200 in tools and admin — $2,300 a month, $27,600 a year. Breakeven: at her $135 hourly rate, the designer must free up or produce about 17 billable hours a month of Dana's time, or bring in equivalent new work. Dana's pre-mortem: the hire fails if (a) Dana does not actually hand over work and keeps doing it herself, (b) the new work does not arrive, or (c) the designer's quality needs so much rework that Dana's hours do not fall. Her prevention: a written list of tasks to hand over in week one, a three-month trial with a review date, and two projects already sold that need the capacity. With that, she hires — on a trial, with a date to decide.

**The rule:** Never fund a growth bet from the tax account. Tax money is not yours. Never fund it from next month's rent. If the bet needs money the business does not have, the answer is to shrink the bet or delay it — not to raid the accounts that keep the business safe.

## Lesson 7.4 — When to say no

Saying no is a money skill. Say no to: a client whose price is below your floor (Module 3); a project that needs skills you do not have and cannot hire in time; a discount that erases your margin (Module 3); an expense that is a want dressed as a need; a loan that funds an ongoing loss rather than a dated, repayable gap. Each no protects the reserve, the owner pay, and the tax account — the three things that keep the business alive.

## Module 7 action steps

1. Set your reserve target (three months of operating expenses) and your monthly contribution.
2. List every business debt with balance, rate, payment, and payoff date. Choose a payoff order and put the payments in the forecast.
3. For your next growth idea, write the one-paragraph pre-mortem and the breakeven before you spend anything.

**Outcome:** The business has a growing cushion, a debt payoff plan with a date, and a test for every growth decision before money moves.

---

# Module 8 — Reading Your Numbers: Profit and Loss, Balance Sheet, and the Five Ratios That Matter

**Time: about 60 minutes of teaching. Action time: two hours to read your own statements.**

## The problem this module solves

Many owners have financial statements — their software or bookkeeper produces them — and never read them. The statements sit in a folder, unread, while the owner runs the business on the bank balance. That is like driving by looking at the fuel gauge and never at the road. This module teaches you to read the two core statements and five simple ratios, so the monthly close becomes a conversation with your business instead of a filing exercise.

## Lesson 8.1 — The profit and loss statement (P&L)

The P&L answers one question: did the business make money over a period? Its structure:

Revenue
− Direct costs (cost of goods sold: materials, contractor costs tied to jobs)
= **Gross profit**
− Operating expenses (rent, software, insurance, marketing, admin)
= **Net profit** (before tax and before owner pay, depending on structure)

**Juniper Studio — annual P&L (simplified, teaching figures):**

| Line | Amount | % of revenue |
|---|---|---|
| Revenue | $240,000 | 100% |
| Direct costs (contractor, materials) | $48,000 | 20% |
| Gross profit | $192,000 | 80% |
| Operating expenses (rent, software, insurance, marketing, admin) | $34,000 | 14% |
| **Net profit before tax and owner pay** | **$158,000** | **66%** |

Read it in layers. Gross profit tells you whether the work itself is profitable before overhead. Net profit tells you what is left for owner pay, tax, and reserves. If gross profit is thin, the problem is pricing or direct costs. If gross profit is healthy but net profit is thin, the problem is overhead. Dana's gross margin of 80% is healthy for a service business; her overhead at 14% is modest. The P&L confirms what Modules 3 and 4 already showed: the studio's problem was never that the work was unprofitable. It was that the money was unmanaged.

**Rivera Home Repair — annual P&L:** Revenue $118,000. Direct costs (materials, subcontracted help) $34,000 (29%). Gross profit $84,000 (71%). Operating expenses $14,000 (12%). Net profit before tax and owner pay $70,000 (59%). His gross margin is lower than Dana's because materials are a bigger share of a trades business — that is normal, and it is why his pricing build-up (Module 3) includes a materials markup.

**Cash vs. accrual — a short note.** Under cash accounting, you record income when money arrives and expenses when money leaves. Under accrual accounting, you record income when you earn it and expenses when you incur them, regardless of payment timing. Most small businesses use cash accounting for tax and for the cash-flow forecast in this course. If your CPA uses accrual for your tax return, your P&L and your cash forecast will differ in timing — that is expected, not an error. Know which basis each document uses before comparing them.

## Lesson 8.2 — The balance sheet

The balance sheet answers a different question: what does the business own, what does it owe, and what is left? Its structure:

Assets (cash, money owed to you, equipment)
= Liabilities (money you owe: bills, loans, tax payable)
+ Owner's equity (what is left for the owner)

**Juniper Studio — balance sheet at year end (simplified):**

| | Amount |
|---|---|
| **Assets** | |
| Cash (all business accounts) | $31,000 |
| Money owed by clients (receivables) | $18,000 |
| Equipment (computers, net of depreciation) | $6,000 |
| **Total assets** | **$55,000** |
| **Liabilities** | |
| Bills owed to suppliers/contractors | $4,000 |
| Tax payable | $9,000 |
| **Total liabilities** | **$13,000** |
| **Owner's equity** | **$42,000** |

The most useful line for an owner is often the receivables: $18,000 owed by clients. That is money you have earned and not yet received. If it grows month after month, your collection process (Module 2) needs attention, not your sales. The second most useful is cash by account — which the balance sheet may show as one total, so keep your five-account split (Module 1) alongside it.

## Lesson 8.3 — Five ratios that matter (and none that do not)

You do not need twenty ratios. You need five, checked monthly or quarterly:

1. **Gross margin** = gross profit ÷ revenue. Dana: 80%. Rivera: 71%. Watch the trend. A falling gross margin means costs are rising faster than prices — act on it in Module 3 before it becomes a loss.
2. **Net margin** = net profit ÷ revenue (before tax and owner pay, for comparison). Dana: 66%. Rivera: 59%. This is the pool that funds owner pay, tax, and reserves.
3. **Operating expense ratio** = operating expenses ÷ revenue. Dana: 14%. If this creeps up year over year without revenue growing faster, overhead is eating the business.
4. **Receivables days** = (money owed by clients ÷ annual revenue) × 365. Juniper Studio: ($18,000 ÷ $240,000) × 365 = 27 days. That means, on average, clients take 27 days to pay. If it rises to 45 days, cash flow tightens even though sales look fine — chase invoices (Module 2).
5. **Reserve coverage** = reserve balance ÷ monthly operating expenses. Dana's reserve $12,000 ÷ $7,000 = 1.7 months. Her target is 3 months. This one number tells her how safe the business is, at a glance.

Write these five on your one-page monthly summary (Module 10). If a ratio moves the wrong way for two months in a row, it earns a decision in the Monthly Money Meeting.

## Lesson 8.4 — Comparing: this month, last month, last year

A single month's numbers tell you little. The pattern tells you everything. Each month, compare: this month vs. last month, this month vs. the same month last year, and year-to-date vs. the annual plan (Module 9). Look for three things: a trend (revenue drifting down for three months), a step change (a cost that jumped and stayed up — a new subscription, a rent rise), and a seasonal pattern you can now plan for instead of being surprised by.

## Module 8 action steps

1. Get your last 12 months of P&L and a current balance sheet from your software or bookkeeper — or build them from your closed books.
2. Calculate the five ratios. Write them on one page with the trend (up, down, flat) for each.
3. Circle the one ratio that worries you most. That is the first topic of your next Monthly Money Meeting.

**Outcome:** You can read your own financial statements, you know your five key ratios and their trends, and you can tell the difference between a business that is busy and a business that is healthy.

---

# Module 9 — The Annual Plan: A Budget You Can Actually Keep

**Time: about 60 minutes of teaching. Action time: three hours to build your first annual plan.**

## The problem this module solves

Most small business budgets fail the same way diets fail: they are written in January with great intentions, they are too detailed to maintain, and by March nobody has looked at them. A budget you can keep is a budget with twelve numbers you actually use — one page, reviewed monthly, adjusted quarterly.

The annual plan is not a prediction. It is a set of targets and a way to notice early when reality differs from the target, while there is still time to act.

## Lesson 9.1 — Build the plan from last year, not from wishes

Start with last year's actuals, month by month, from your closed books. That is your base. Then adjust, line by line, for what you know will change:

- Revenue: which clients are returning, which projects are already sold, what is realistic — not hopeful. If last year was $240,000 and you have $180,000 already committed or highly likely, plan $260,000 only if you can name where the extra $80,000 comes from.
- Direct costs: tied to revenue. If revenue rises 10%, direct costs usually rise too.
- Operating expenses: the known changes — a rent rise, a subscription you will cancel, a tool you will add.
- Owner pay: the amount from Module 4.
- Tax: the set-aside percentage from Module 6.
- Reserves: the contribution from Module 7.

**Juniper Studio — annual plan (summary):**

| Line | Last year (actual) | This year (plan) | Change and why |
|---|---|---|---|
| Revenue | $240,000 | $264,000 | +10%: retainer renewed, two projects already sold |
| Direct costs | $48,000 | $55,000 | Rises with revenue; contractor rate up 5% |
| Gross profit | $192,000 | $209,000 | |
| Operating expenses | $34,000 | $36,000 | Rent rise $150/mo; one subscription cancelled |
| Net profit before tax & owner pay | $158,000 | $173,000 | |
| Tax set-aside (25% of revenue) | $60,000* | $66,000 | Applied to revenue as a safe simplification |
| Owner pay | $104,000* | $96,000 | Regular $8,000/mo instead of irregular drips |
| Reserve contribution | — | $13,200 | 5% of revenue; new discipline |

*Last year's tax and owner pay figures are what actually happened, shown for comparison — the plan replaces irregular reality with a system.

Note that the plan's owner pay is lower than last year's actual take. That is deliberate: last year's $104,000 included months when Dana took money the business needed later. The plan's $96,000 is sustainable, and the reserve finally gets funded. If revenue beats the plan, the quarterly review can add a bonus. The plan is a floor you can stand on, not a ceiling you are trapped under.

## Lesson 9.2 — Seasonality: plan the year in months, not in one number

An annual total hides the shape of the year. Spread the plan month by month, using last year's monthly pattern. If December is always slow, plan December as slow — do not plan twelve equal months and then be surprised in December. The monthly plan feeds directly into the cash-flow forecast (Module 2): the forecast is the plan, updated with actuals as the year goes on.

## Lesson 9.3 — The three scenarios

Write three versions of the year, each one page:

- **Expected:** the plan above. This is the version you manage to.
- **Downside:** revenue 20% lower, costs the same. What breaks first? What do you cut, and in what order? Knowing the answer in advance means a bad quarter is a plan you execute, not a panic you improvise.
- **Upside:** revenue 20% higher. Where does the extra money go — owner bonus, reserve, a hire, a tax top-up? Decide the split now, while you are calm, so a good quarter does not evaporate into unplanned spending.

Dana's downside plan: at $211,000 of revenue, owner pay holds at $8,000 a month (the household depends on it), the reserve contribution drops to zero, and the contractor budget is cut first — she takes on more of the work herself for a quarter. Her upside plan: at $317,000, the extra funds a $10,000 bonus, tops the reserve to its $21,000 target, and funds the part-time designer trial from Module 7. Writing those two paragraphs took twenty minutes. They are worth more than most of the spreadsheet.

## Lesson 9.4 — The annual price review

Once a year, in the same month you build the annual plan, review every price (Module 3). Costs rise every year — rent, software, contractor rates — and a price that was right two years ago is wrong now. A 5% annual rise, applied calmly and announced in advance, keeps your margin intact without a dramatic jump. Put the review in the calendar now, for the same month every year, and treat it as part of the plan, not an optional extra.

## Module 9 action steps

1. Build your one-page annual plan from last year's actuals, adjusted for known changes.
2. Spread it month by month, using last year's seasonal pattern.
3. Write the downside and upside scenarios — one paragraph each, with the decisions already made.
4. Put the annual price review in your calendar.

**Outcome:** You have a plan for the year, a monthly version of it, and two pre-decided responses for a year that goes better or worse than expected.

---

# Module 10 — The Monthly Money Meeting: Running the System for Good

**Time: about 45 minutes of teaching. Action time: one hour, every month, forever.**

## The problem this module solves

Systems fail not because they are wrong, but because nobody runs them. The Monthly Money Meeting is the habit that keeps the other nine modules alive. One hour, once a month, same day, same agenda, five decisions. If you do nothing else in this course after finishing it, do this meeting.

## Lesson 10.1 — The meeting: when, who, and how long

- **When:** The same day each month — the first Monday, or the 5th, whatever you will keep. Put it in the calendar as a recurring appointment and protect it like a client meeting.
- **Who:** You. If you have a bookkeeper or a business partner, they attend. If you have a CPA, they attend quarterly. Nobody else needs to be there. This is not a performance. It is maintenance.
- **How long:** One hour. Set a timer. A meeting that sprawls to three hours will be skipped next month. A meeting that takes one hour will happen.

Bring to the meeting: the one-page monthly summary (from the monthly close, Module 5), the updated cash-flow forecast (Module 2), the five ratios (Module 8), and the annual plan with year-to-date actuals (Module 9).

## Lesson 10.2 — The one-page monthly summary

Every month, one page:

- Revenue this month / year to date / vs. plan
- Expenses by category this month, with anything unusual noted
- Net profit this month
- Owner pay paid / tax set aside / reserve balance
- Cash balances by account
- The five ratios, with their trends
- Overdue invoices and their ages
- One line: the biggest money surprise this month, and what it teaches

If it does not fit on one page, it is too long. The meeting reads the page, not the ledger.

## Lesson 10.3 — The agenda: five decisions

1. **Is the cash forecast still right?** Update it with actuals, roll it forward, and check the next three months for gaps. If a gap appears, pick a lever (Module 2).
2. **Is pricing still right?** Any job this month that lost money or felt underpriced? Any offer whose costs have risen? If so, note it for repricing — do not reprice in the meeting, but do put a date on it.
3. **Is owner pay still right?** Is the pay still sustainable at current revenue? If revenue has changed materially for two months, decide whether pay changes — at the quarterly review, not mid-panic.
4. **Is the tax account on track?** Compare the Tax account balance with the expected liability so far. If it is short, raise the percentage now.
5. **What is the one action for next month?** Every meeting ends with exactly one priority action, a name, and a date. One action, done, beats five actions, forgotten.

## Lesson 10.4 — The quarterly review (a longer meeting, four times a year)

Once a quarter, the meeting runs for two hours and adds:

- Review the allocation percentages (Module 1). Do they still match reality?
- Review the reserve against its target (Module 7). Is the contribution right?
- Review the annual plan against year-to-date actuals (Module 9). Is the plan still realistic, or does it need revising?
- Pay the quarterly estimated tax (Module 6) and record it.
- Decide on bonuses, if the quarter earned one (Module 4).
- Review subscriptions and recurring costs: cancel what you are not using.

## Lesson 10.5 — Keeping the system alive

Systems die quietly. The warning signs: you skip the monthly close twice, the forecast is two months out of date, you pay yourself from the wrong account "just this once," the Tax account is short and you tell yourself next month will be better. When you notice a warning sign, do not rebuild the whole system. Do the smallest next step: one close, one forecast update, one allocation. Small and current beats grand and abandoned.

If you fall off the system for a month, return without guilt and without a big catch-up project. Do this month's close. Update this month's forecast. Hold this month's meeting. The system is a habit, not a test. It works when you use it, and it waits patiently when you do not.

---

## Your 90-Day Implementation Plan

**Days 1–7: Separate and see.**
Open the five accounts. Move income to the Income account. Choose your allocation percentages. Do the Friday 15-minute check. (Module 1.)

**Days 8–21: Forecast and price.**
Build the 12-month cash-flow forecast. Calculate your real hourly rate. Price your top three offers with the build-up method. Raise, re-scope, or retire any offer that loses money. (Modules 2 and 3.)

**Days 22–45: Pay and record.**
Set your owner pay amount and paydays. Do your first monthly close. Set up the receipt folder and mileage log. Ask your CPA for your tax rate and estimated payment dates, and set your tax set-aside percentage. (Modules 4, 5, and 6.)

**Days 46–75: Protect and understand.**
Set your reserve target and contribution. List your debts and start the payoff plan. Read your P&L and balance sheet and calculate your five ratios. (Modules 7 and 8.)

**Days 76–90: Plan and meet.**
Build your annual plan and your downside and upside scenarios. Hold your first Monthly Money Meeting on the full agenda. Put the next eleven meetings in your calendar. (Modules 9 and 10.)

At day 90, you will not have a perfect system. You will have a working one — and a working system you use every month is worth more than a perfect system you never start.

---

## Final Word

You did not start your business to become an accountant. You started it to do work you care about, for people you want to serve, on terms you choose. The money system exists so the work can continue: so a slow month is a forecast you planned for, not a crisis; so a price is a decision you made, not a guess you hope about; so tax time is a filing, not a fear; and so you get paid, regularly, for the work you do.

Run the meeting. Update the forecast. Pay yourself on purpose. The system will do the rest.

---

*This course is general financial education, not individualized financial, tax, or accounting advice. Tax rules vary by jurisdiction and change over time. Consult a qualified CPA or tax professional about your specific situation before acting on tax, structure, or payroll decisions. No results are guaranteed.*
