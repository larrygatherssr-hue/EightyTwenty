# FIN-09 — The Small Business Money System

**Price:** $397 one-time · **Category:** Finance & Wealth · **SKU:** FIN-09

A financial management system for small business owners covering cash flow, pricing, bookkeeping, taxes, and owner pay. Headline: "Stop guessing at your business money — cash flow, pricing, and taxes in one monthly system."

## Files in this folder

| File | What it is |
|---|---|
| `content.md` | The full course text — all 10 modules fully written, with worked examples using real numbers (cash-flow forecast, pricing build-up, owner-pay calculation, tax set-aside) and a 90-day implementation plan. |
| `workbook.md` | Companion workbook — exercises, worksheets, and checklists for every module, including the monthly bookkeeping checklist and tax-prep organizer. |
| `templates/cash-flow-forecast.csv` | 12-month cash-flow forecast spreadsheet (pre-filled with the Juniper Studio worked example from Module 2). |
| `templates/pricing-calculator.csv` | Pricing build-up calculator, hourly-rate calculator, and discount check (pre-filled with the Module 3 worked example). |
| `templates/monthly-bookkeeping-checklist.md` | Step-by-step monthly close checklist. |
| `templates/tax-prep-organizer.md` | Tax set-aside tracker, quarterly estimated payment log, and tax-prep document checklist. |
| `templates/owner-pay-planner.md` | Sustainable owner-pay calculation, pay plan, personal budget check, and pay log. |
| `sales-page.md` | Full sales page: headline, problem, solution, module list, who it is for / not for, $397 price + 14-day guarantee, 9-question FAQ, and disclaimers. |
| `listing.json` | Marketplace listing data for EightyTwenty (SKU FIN-09, $397.00, one-time). |
| `cover.md` | Cover design brief (black-and-gold luxury branding). |
| `cover.png` | The generated cover image (1280 × 1920 px, portrait). |
| `onboarding.md` | Customer onboarding guide: what to do first, how to use the materials, suggested schedule, how to get support. |
| `README.md` | This file. |

## Notes

- All content is original. No testimonials, sales figures, certifications, or reviews are claimed.
- Education only: not individualized financial, tax, or accounting advice; no guaranteed results. Disclaimers are included in content.md, workbook.md, and sales-page.md. Tax content is framed as general education with a note to consult a CPA/tax professional.
