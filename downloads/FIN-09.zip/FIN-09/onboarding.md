# Customer Onboarding — The Small Business Money System

Welcome. This guide tells you what to do first, how to use the materials, and how to get help.

## What you received

- **content.md** — The full course text: all 10 modules, fully written, with worked examples. This is the teaching. Start here.
- **workbook.md** — The companion workbook: exercises, worksheets, and checklists for every module. Fill it in with your real numbers as you read.
- **templates/** — Five ready-to-use files:
  - `cash-flow-forecast.csv` — 12-month cash-flow forecast spreadsheet
  - `pricing-calculator.csv` — Pricing build-up, hourly-rate calculator, and discount check
  - `monthly-bookkeeping-checklist.md` — The monthly close, step by step
  - `tax-prep-organizer.md` — Set-aside tracker, quarterly payment log, and tax-prep checklist
  - `owner-pay-planner.md` — Sustainable pay calculation, pay plan, personal budget check, and pay log
- **sales-page.md** — The full sales page for this product (for the seller's reference).
- **cover.png** — The product cover image.

## What to do first (Day 1)

1. Read the disclaimer at the top of content.md. This course is general financial education, not individualized financial, tax, or accounting advice. Tax decisions should be confirmed with a CPA or tax professional who knows your situation.
2. Gather three things: your last 12 months of bank and card statements (business and, if mixed, personal), last year's tax return if you have one, and a list of your current prices and your biggest recurring costs.
3. Read the introduction and Module 1, then open (or rename) your business accounts and choose your allocation percentages. Do the first allocation on the next money that arrives.
4. Put two recurring appointments in your calendar now: the Friday 15-minute money check, and the Monthly Money Meeting (first five working days of each month, one hour).

## How to use the materials

- **Work through the modules in order the first time.** Each module ends with action steps. Do them before moving on — the system is built by doing, not by reading.
- **Use the workbook alongside the course text.** Every module in the course has a matching section in the workbook. Write your real numbers in; the workbook is only useful when it holds your business.
- **Use the templates as working files.** Make a copy of each template before you fill it in, so the blank original stays clean for next year. The CSV files open in any spreadsheet application.
- **Do not try to do everything in a weekend.** Follow the 90-day plan at the end of Module 10: Days 1–7 separate and see; Days 8–21 forecast and price; Days 22–45 pay and record; Days 46–75 protect and understand; Days 76–90 plan and meet.

## Suggested schedule

| When | What |
|---|---|
| Week 1 | Modules 1–2: accounts, allocations, cash-flow forecast |
| Weeks 2–3 | Module 3: hourly rate and repricing your top three offers |
| Weeks 4–6 | Modules 4–6: owner pay, first monthly close, tax set-aside |
| Weeks 7–10 | Modules 7–8: reserve, debt plan, reading your statements |
| Weeks 11–13 | Modules 9–10: annual plan and first Monthly Money Meeting |

After that, the ongoing rhythm is: 15 minutes weekly, about two hours for the monthly close, one hour for the Monthly Money Meeting, and a two-hour quarterly review four times a year.

## How to get support

- **Downloads and access:** Email the marketplace support address with your order number and a description of the problem. Support can help with downloads and access to the course files.
- **Questions about the material:** Support can help with how to use the files. Support cannot provide individualized financial, tax, or accounting advice.
- **Tax, structure, or payroll decisions:** Consult a qualified CPA or tax professional who knows your specific situation. The course tells you which questions to ask; your CPA gives you the answers for your business.

## A note on the examples

The course follows one fictional business, Juniper Studio (a two-person brand-design studio, $240,000 revenue), with a second example, Rivera Home Repair (a one-person trades business, $118,000 revenue). All names, businesses, and figures are invented for teaching. Replace the example numbers with your own as you work through the workbook.
