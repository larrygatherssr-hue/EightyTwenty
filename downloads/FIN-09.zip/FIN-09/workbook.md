# Workbook — The Small Business Money System

Companion workbook to the course text. Work through it module by module, in order, as you read the course. Write your real numbers in — the workbook is only useful when it holds your business, not the examples.

## Disclaimer

This workbook is general financial education, not individualized financial, tax, or accounting advice. Tax content is general education only; consult a CPA or tax professional about your specific situation before acting on tax, structure, or payroll decisions. No results are guaranteed.

---

## Module 1 — Your Money Map

### Exercise 1.1: Your five accounts

List your accounts. If an account does not exist yet, write the date you will open it.

| Account | Bank | Account (last 4 digits) | Opened / to open by |
|---|---|---|---|
| Income (operating checking) | | | |
| Operating expenses (checking) | | | |
| Tax (savings) | | | |
| Owner pay (checking/savings) | | | |
| Profit / reserve (savings) | | | |

### Exercise 1.2: Your allocation percentages

Fill in your starting split. The percentages must add to 100%.

| Account | % | On $10,000 received |
|---|---|---|
| Tax | ___% | $______ |
| Owner pay | ___% | $______ |
| Operating expenses | ___% | $______ |
| Profit / reserve | ___% | $______ |
| **Total** | **100%** | **$10,000** |

My allocation day: ________________ (e.g., every Friday, or the day money arrives)

### Exercise 1.3: Business vs. personal

List five expenses you have been unsure about. Decide: business, personal, or mixed (and the business percentage). If you cannot explain in one sentence why the business needed it, it is personal.

1. _________________________________ → ________________
2. _________________________________ → ________________
3. _________________________________ → ________________
4. _________________________________ → ________________
5. _________________________________ → ________________

### Checklist: Module 1 done when…

- [ ] Five (or at least three) business accounts are open and named for their job.
- [ ] All business income lands in the Income account.
- [ ] Allocation percentages are written down.
- [ ] First allocation has been made.
- [ ] Friday 15-minute money check is in the calendar.

---

## Module 2 — Your Cash-Flow Forecast

### Exercise 2.1: Your next three months

Use the cash-flow-forecast.csv template. For each of the next three months, write the expected money in (payments you realistically expect to receive, not invoices sent), the expected money out, and the closing balance.

| | Month 1: ________ | Month 2: ________ | Month 3: ________ |
|---|---|---|---|
| Opening balance | $ | $ | $ |
| Money in | $ | $ | $ |
| Money out | $ | $ | $ |
| Net cash flow | $ | $ | $ |
| **Closing balance** | **$** | **$** | **$** |

### Exercise 2.2: Your watch months

Which months does the closing balance fall below one month of operating costs? List them and, for the nearest one, the lever you will use (speed up money in, slow money out, cut a cost, use the reserve, or borrow deliberately).

Watch month: ______________ Lever: ___________________________________________

Watch month: ______________ Lever: ___________________________________________

### Exercise 2.3: Your overdue invoices

List every invoice that is past its due date, with its age and the next action.

| Client | Invoice | Amount | Days overdue | Next action + date |
|---|---|---|---|---|
| | | $ | | |
| | | $ | | |
| | | $ | | |

### Checklist: Module 2 done when…

- [ ] 12-month forecast is filled in (first three months in detail).
- [ ] Watch months are circled.
- [ ] One lever is in action for the nearest watch month.
- [ ] Monthly forecast update is in the calendar.

---

## Module 3 — Your Pricing Worksheet

### Exercise 3.1: Your real hourly rate

Target owner pay per year: $__________
Annual business overhead: $__________
Billable hours per year: __________
Required hourly rate = (owner pay + overhead) ÷ billable hours = $__________ per hour
My working rate (rounded up): $__________ per hour

### Exercise 3.2: Price one offer from the costs up

Offer: _______________________________________________

| Line | Calculation | Amount |
|---|---|---|
| Direct costs | | $ |
| Your time (____ hours × $____) | | $ |
| Overhead share | | $ |
| Subtotal (true cost) | | $ |
| Profit margin (____% of subtotal) | | $ |
| **Price** | | **$** |

Current price: $__________ Built-up price: $__________ Difference: $__________

Decision (raise / reduce scope or cost / retire): ___________________________________________

### Exercise 3.3: Price your top three offers

| Offer | Current price | Built-up price | Decision |
|---|---|---|---|
| 1. | $ | $ | |
| 2. | $ | $ | |
| 3. | $ | $ | |

### Exercise 3.4: Discount check

Take one job you discounted. Price: $__________ Costs: $__________ Profit before discount: $__________
Discount given: ____% Profit after discount: $__________ Profit lost: $__________
Was the discount worth it? ___________________________________________

### Checklist: Module 3 done when…

- [ ] Real hourly rate is calculated and written down.
- [ ] Top three offers are priced from the costs up.
- [ ] A decision is made on every offer priced below its floor.
- [ ] Annual price review is in the calendar.

---

## Module 4 — Your Owner-Pay Plan

### Exercise 4.1: Sustainable owner pay

| Line | Annual |
|---|---|
| Revenue (last 12 months) | $ |
| Business expenses | − $ |
| Tax paid / owed | − $ |
| Reserve target contribution | − $ |
| **Available for owner pay** | **$** |
| **Sustainable monthly owner pay** | **$** |

### Exercise 4.2: My pay plan

Monthly owner pay: $__________ Paydays: __________ and __________ of each month
Transfer from: Owner Pay account → personal checking.
Structure note (confirmed with my CPA on __________): ___________________________________________

### Exercise 4.3: Personal budget check

My household needs per month: $__________
My owner pay per month: $__________
Gap (if any): $__________ My plan to close it: ___________________________________________

### Checklist: Module 4 done when…

- [ ] Sustainable monthly owner pay is calculated.
- [ ] Pay amount and paydays are set and calendared.
- [ ] Personal monthly costs are totalled and compared with pay.
- [ ] CPA has confirmed how owner pay is treated under my structure.

---

## Module 5 — Monthly Bookkeeping Checklist

Use this checklist for every monthly close, in the first five working days of the month. Photocopy it or copy it into your task list each month.

**Month: _______________ Close completed on: _______________**

- [ ] Downloaded bank and card statements for all business accounts.
- [ ] Collected receipts for cash spending; filed receipts over $75.
- [ ] Listed all income received, by client and invoice.
- [ ] Listed all overdue invoices and chased the oldest one.
- [ ] Categorized every expense transaction.
- [ ] Reconciled records to bank statements (balances match: yes / no — difference: $______).
- [ ] Confirmed tax, owner pay, and reserve transfers happened as planned.
- [ ] Produced the one-page monthly summary.
- [ ] Filed the month's records and backed them up.
- [ ] Mileage log updated for the month (total business miles: __________).

Notes / anything unusual this month: ___________________________________________

---

## Module 6 — Tax-Prep Organizer

### Your tax facts (fill in with your CPA)

My estimated combined tax rate on business profit: ____%
My revenue-based set-aside percentage: ____%
Estimated / instalment tax payment dates: ___________________________________________
My CPA / tax preparer: ______________________ Contact: ______________________

### Tax set-aside tracker

| Month | Revenue received | Set-aside % | Amount to Tax account | Date transferred |
|---|---|---|---|---|
| | $ | % | $ | |
| | $ | % | $ | |
| | $ | % | $ | |
| | $ | % | $ | |

### Quarterly estimated payments

| Quarter | Due date | Amount paid | Date paid | Confirmation # |
|---|---|---|---|---|
| Q1 | | $ | | |
| Q2 | | $ | | |
| Q3 | | $ | | |
| Q4 | | $ | | |

### Tax-prep checklist (work through in January, or your tax year's equivalent)

- [ ] Last year's tax return and any carry-forward items gathered.
- [ ] Full-year profit and loss, by month, printed or saved.
- [ ] Bank and card statements for all business accounts, full year.
- [ ] Receipts folder organized by category.
- [ ] Mileage log totalled for the year: __________ miles.
- [ ] Contractor payment totals and details gathered.
- [ ] Home-office measurement and costs documented.
- [ ] Estimated tax payments made, with confirmations, listed above.
- [ ] New asset purchases (equipment, vehicle) with invoices gathered.
- [ ] Loan statements gathered, if any.
- [ ] Questions for my CPA written down: ___________________________________________

---

## Module 7 — Reserves, Debt, and Growth

### Exercise 7.1: Reserve target

Monthly operating expenses: $__________
Reserve target (3 months): $__________
Current reserve balance: $__________
Monthly contribution: $__________ Months to reach target: __________

### Exercise 7.2: Debt list

| Debt | Balance | Interest rate | Monthly payment | Payoff date |
|---|---|---|---|---|
| | $ | % | $ | |
| | $ | % | $ | |
| | $ | % | $ | |

Payoff order (highest interest first, or smallest first — and why): ___________________________________________

### Exercise 7.3: Growth pre-mortem

Growth idea: ___________________________________________
Full cost for a year (including my time): $__________
Breakeven (extra revenue or savings needed): $__________
Funding source: __________________ What if revenue is 50% lower than expected? __________________
If it failed in a year, the three most likely reasons: 1) ______________ 2) ______________ 3) ______________
Decision (go / shrink / delay): __________________ Review date: ______________

---

## Module 8 — Your Five Ratios

Calculate these monthly or quarterly from your P&L and balance sheet.

| Ratio | Formula | This period | Last period | Trend |
|---|---|---|---|---|
| Gross margin | Gross profit ÷ revenue | % | % | |
| Net margin | Net profit ÷ revenue | % | % | |
| Operating expense ratio | Operating expenses ÷ revenue | % | % | |
| Receivables days | (Money owed by clients ÷ annual revenue) × 365 | days | days | |
| Reserve coverage | Reserve balance ÷ monthly operating expenses | months | months | |

The ratio that worries me most: __________________ What I will do about it: __________________

---

## Module 9 — Your Annual Plan (one page)

| Line | Last year (actual) | This year (plan) |
|---|---|---|
| Revenue | $ | $ |
| Direct costs | $ | $ |
| Gross profit | $ | $ |
| Operating expenses | $ | $ |
| Net profit before tax & owner pay | $ | $ |
| Tax set-aside | $ | $ |
| Owner pay | $ | $ |
| Reserve contribution | $ | $ |

Downside scenario (revenue 20% lower): what breaks first, and what do I cut, in what order?
_______________________________________________________________________________

Upside scenario (revenue 20% higher): where does the extra money go?
_______________________________________________________________________________

Annual price review date: ______________

---

## Module 10 — Monthly Money Meeting Agenda

**Meeting date: ______________**

Bring: one-page monthly summary, updated cash-flow forecast, five ratios, annual plan vs. year-to-date.

1. Cash forecast: still right? Gaps in the next three months? Lever chosen: __________________
2. Pricing: any job this month that lost money or felt underpriced? __________________
3. Owner pay: still sustainable? Change needed? __________________
4. Tax account: on track? Shortfall? Percentage change needed? __________________
5. One action for next month: __________________ Owner: __________ Due: __________

---

## 90-Day Implementation Tracker

| Days | Focus | Done? |
|---|---|---|
| 1–7 | Separate and see (Module 1) | [ ] |
| 8–21 | Forecast and price (Modules 2–3) | [ ] |
| 22–45 | Pay and record (Modules 4–6) | [ ] |
| 46–75 | Protect and understand (Modules 7–8) | [ ] |
| 76–90 | Plan and meet (Modules 9–10) | [ ] |

*This workbook is general financial education, not individualized financial, tax, or accounting advice. Consult a qualified CPA or tax professional about your specific situation. No results are guaranteed.*
