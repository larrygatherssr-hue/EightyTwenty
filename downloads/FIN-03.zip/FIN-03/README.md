# The 90-Day Credit Reset System — FIN-03

**Price:** $197 one-time · **Category:** Finance & Wealth Building

## Files in this product

| File | What it is |
|------|-----------|
| `content.md` | The full course — table of contents plus all 12 modules in full prose, with worked examples, a before/after report walkthrough, and a glossary. The core deliverable. |
| `workbook.md` | Companion workbook — report-reading worksheets, error log, utilization tracker, 90-day action checklist, and score-improvement checklist. |
| `templates/credit-tracker.csv` | Credit tracker spreadsheet — bureau, account, balance, limit, utilization %, status, dispute date, outcome. |
| `templates/dispute-letter-templates.md` | Dispute-letter pack — inaccurate account, incorrect balance, account not mine, duplicate account, outdated negative item, plus a debt validation request. FCRA-grounded, with blanks. |
| `templates/90-day-action-plan.md` | The dated week-by-week 90-day plan. |
| `templates/error-log.md` | Standalone error log (account, bureau, error type, dispute date, status). |
| `sales-page.md` | Full sales page — headline, problem, solution, 12-module list, who it is/is not for, price + 14-day guarantee, FAQ, disclaimer. |
| `listing.json` | EightyTwenty marketplace listing data (SKU FIN-03, $197.00, one-time). |
| `cover.md` | Cover design brief — black-and-gold luxury branding. |
| `cover.webp` | Generated cover image. |
| `onboarding.md` | Customer onboarding guide — what to do first, how to use each file, 12-week schedule, support. |

## Key facts

- **SKU:** FIN-03
- **Price:** $197 one-time (19700 cents)
- **Guarantee:** 14-day money-back, full refund, no questions asked
- **Disclaimer:** Financial education only — not individualized financial, legal, or credit advice. No score increase, deletion, or approval is guaranteed.
