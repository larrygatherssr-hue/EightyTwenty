# The 90-Day Credit Reset System

## Reset your credit in 90 days — read your reports, dispute errors lawfully, and rebuild.

---

**IMPORTANT DISCLAIMER — PLEASE READ FIRST**

This course is financial education only. It is not individualized financial, legal, or credit advice, and it is not a substitute for advice from a qualified financial advisor, attorney, or credit counselor about your specific situation. Nothing in this course guarantees a score increase, the deletion of any item from your credit reports, or approval for any loan, credit card, mortgage, or other credit product. Results depend entirely on your individual reports, your creditors, the bureaus, and the actions you take. Credit scores change for many reasons, and lawful disputes succeed only when information on a report is actually inaccurate, incomplete, or unverifiable. Never dispute accurate information, never misrepresent anything to a bureau or creditor, and never pay anyone who promises a specific score by a specific date. If you are facing a lawsuit, a garnishment, or a complex debt situation, consult a licensed attorney or a nonprofit credit counselor before acting.

You are in control of this process. Every step in this course is something you can do yourself, for free or for the cost of postage. You do not need to pay a credit repair agency $100–$180 a month to do what this course teaches you to do.

---

## Table of Contents

- Module 1 — How Credit Scores Actually Work: The Five FICO Factors and Their Weights
- Module 2 — Getting Your Three Reports Free and Reading Them Line by Line
- Module 3 — Spotting Errors: The Most Common Report Mistakes and How to Document Them
- Module 4 — Your Rights Under the FCRA and FDCPA in Plain English
- Module 5 — Writing an Effective Dispute Letter: What to Include and What to Avoid
- Module 6 — Disputing with the Bureaus Step by Step
- Module 7 — Disputing with the Furnisher (the Creditor)
- Module 8 — Paying Down Balances: Utilization and the Fastest Score Levers
- Module 9 — Rebuilding: Secured Cards, Authorized Users, and Credit-Builder Loans — What Helps and What Hurts
- Module 10 — Dealing with Collections and Charge-Offs
- Module 11 — Protecting Your Credit: Freezes, Fraud Alerts, and Monitoring
- Module 12 — Your 90-Day Action Plan: Week by Week
- Appendix A — Before/After Report Walkthrough
- Appendix B — Glossary

---

## Module 1 — How Credit Scores Actually Work: The Five FICO Factors and Their Weights

If credit scores feel like a mystery, that is because nobody hands you the rulebook when you turn eighteen. A credit score is not a grade on your character. It is a prediction: based on the information in your credit reports, how likely are you to pay a bill 90 days late or worse in the next two years? Lenders use that prediction to decide whether to lend to you and what interest rate to charge. A lower score does not mean you are a bad person. It means the data says the risk is higher — and data can be corrected, and behavior can change the data over time.

### The score most lenders actually use

There are many scoring models, but the one that matters most is the FICO Score. About 90% of top lenders use FICO scores in their decisions. FICO scores range from 300 to 850. The commonly used bands are:

- **300–579:** Poor
- **580–669:** Fair
- **670–739:** Good
- **740–799:** Very Good
- **800–850:** Exceptional

This course is written for people below 670 — the Fair and Poor bands — because that is where a denied application, a high interest rate, or a large security deposit is most likely. Moving from 620 to 680 can change a car loan from a 12% interest rate to a 7% rate. On a $25,000 car loan over 60 months, that difference is roughly $3,600 in interest. That is real money, and it is why this work is worth 90 days of your attention.

Your score is not the same at all three bureaus. Equifax, Experian, and TransUnion each hold a slightly different file on you, and each generates its own score. A lender may pull only one. That is why this course works with all three reports, not one.

### The five FICO factors

FICO scores are built from five categories of information in your reports. The weights below are the standard published weights for the general population. Your personal mix may differ slightly, but these proportions are the map:

**1. Payment history — 35% of your score.** This is the biggest factor. It asks one question: do you pay on time? A single payment reported 30 days late can drop a score by 60 to 110 points, and the higher your score was, the harder it falls. Late payments stay on your report for seven years from the date of the missed payment, though their impact fades with time — a two-year-old late payment hurts far less than a two-month-old one. The lesson is simple and non-negotiable: from today forward, nothing matters more than paying every account on time, every month. Set up autopay for at least the minimum payment on every account, even if you plan to pay more manually. Autopay is your safety net.

**2. Amounts owed (credit utilization) — 30% of your score.** This is the second-biggest factor, and it is the fastest one you can change. It has two parts: how much you owe in total, and — more importantly — what percentage of your available credit you are using. This percentage is called utilization, and Module 8 is devoted to it. The headline rule: lower utilization is better, and the effect shows up fast, often within one billing cycle after a lower balance is reported. Unlike a late payment, utilization has no memory — last month's high utilization stops hurting you once a lower balance is reported.

**3. Length of credit history — 15% of your score.** This looks at how long your accounts have been open, the age of your oldest account, the age of your newest account, and the average age of all your accounts. Longer is better. The practical rule: do not close your oldest credit card, even if you rarely use it. Closing it can shorten your average account age and reduce your total available credit, which raises your utilization — a double hit.

**4. Credit mix — 10% of your score.** Lenders like to see that you can handle different kinds of credit responsibly: revolving credit (credit cards) and installment credit (a car loan, a student loan, a mortgage). You do not need to take out a loan just to improve your mix — that would be spending money to chase 10% of your score. If you already have a mix, good. If not, it will develop naturally as you rebuild.

**5. New credit — 10% of your score.** Opening several new accounts in a short period signals risk. Each application usually creates a "hard inquiry" on your report, which can lower your score by a few points for a short time. One inquiry is not a disaster. Five in a month looks desperate. During your 90 days, do not apply for new credit unless the plan in Module 9 calls for it — one secured card, applied for once, on purpose.

### A worked example: two borrowers, same income

Consider two borrowers, each earning $52,000 a year:

- **Maria** has one credit card with a $500 limit, maxed out at $480, and one late payment 14 months ago. Her score is 598.
- **James** has two credit cards with a combined $6,000 limit, balances totaling $900 (15% utilization), no late payments, and a 6-year-old card he still keeps open. His score is 712.

Same income, same city, same age. The difference is entirely in the five factors: Maria's utilization is 96% and she has a late payment; James's utilization is 15% and his payment history is clean. Nothing about Maria's character explains the 114-point gap. The data does — and the data can change.

### What a score is NOT

A credit score does not consider your income, your savings, your employment history, your age, your race, your gender, or your marital status. It does not know whether you are a good person or a careful budgeter. It only reads the file. That is both the frustration and the opportunity: you cannot argue with a score, but you can change the file it reads.

### Action steps — Module 1

1. Write down your best guess at your current score, and why you think it is what it is. You will compare this guess to the real number in Module 2.
2. List every credit account you have — cards, loans, store cards — with the creditor name and your best memory of the balance and limit.
3. Turn on autopay for at least the minimum payment on every open account today. This one action protects the 35% factor starting now.
4. Do not close any credit card this week, especially not your oldest one.

---

## Module 2 — Getting Your Three Reports Free and Reading Them Line by Line

You cannot fix what you cannot see. Before you dispute anything, change anything, or pay anything, you need all three of your credit reports in front of you. Not a summary. Not a score from an app. The full reports.

### Where to get them free

Under federal law, you are entitled to a free copy of your credit report from each of the three nationwide bureaus — Equifax, Experian, and TransUnion — every week, through the official site **AnnualCreditReport.com**. That is the only site authorized by federal law for this purpose. Other sites with similar names may try to sell you monitoring or a trial subscription. Use AnnualCreditReport.com, or call 1-877-322-8228.

You do not need to pay for your reports, and you do not need to pay for your FICO scores to do this work. The reports are the raw material; scores are derived from them. Many banks and card issuers also show you a free credit score each month — useful for tracking, but the report itself is what you will be working from.

A note on identity verification: the site will ask questions drawn from your credit file to confirm you are who you say you are — a previous address, a lender's name, a loan amount range. If you cannot pass online verification, you can request reports by mail using the form on the site. It takes longer, but it works.

### Reading a report line by line

A credit report has five sections. Go through each slowly, with a pen, on paper or in the workbook's report-reading worksheet.

**Section 1: Personal information.** Your name, current and previous addresses, date of birth, Social Security number (usually partially masked), and employers. Errors here are common — a misspelled name, an address you never lived at, an employer you never had. These errors alone rarely hurt your score, but an unfamiliar address can be a sign of mixed files or identity theft, so flag anything you do not recognize.

**Section 2: Accounts (tradelines).** This is the heart of the report. Each account is a "tradeline" — one line per credit card, loan, mortgage, or collection account. For each tradeline, check:
- The creditor's name — is it a company you actually did business with?
- The account type — revolving (credit card) or installment (loan)?
- The date opened — does it match when you opened it?
- The credit limit or original loan amount.
- The current balance.
- The payment history grid — a month-by-month record, often shown as "OK" or "30/60/90" for late payments.
- The account status — open, closed, paid, charged off, in collections.
- The date of last activity.

**Section 3: Public records.** Bankruptcies appear here. (Civil judgments and tax liens no longer appear on most reports, but check anyway.) A Chapter 7 bankruptcy stays on your report for 10 years; a Chapter 13 for 7 years.

**Section 4: Inquiries.** Two kinds. "Hard" inquiries — when you applied for credit — stay for two years and can affect your score for about one year. "Soft" inquiries — when you check your own report, or a lender pre-screens you — do not affect your score at all. If you see a hard inquiry you never authorized, flag it.

**Section 5: Collections.** Collection accounts may appear as separate tradelines or in their own section, depending on the bureau. Note the original creditor, the collection agency, the amount, and the date.

### Worked example: reading one tradeline

Here is a tradeline the way it might appear, with what to check:

> **CAPITAL ONE — PLATINUM MASTERCARD**
> Account type: Revolving. Date opened: March 2019. Credit limit: $1,500. Balance: $1,120. Status: Open, pays as agreed. Payment history: OK for every month shown except June 2024, marked "30" (30 days late). Date of last activity: January 2026.

What you would note: utilization on this card is $1,120 ÷ $1,500 = 75% — high, and a priority for Module 8. One 30-day late payment from June 2024 — real, if you remember missing that payment; an error to dispute if you paid on time and can prove it. The account is 7 years old — valuable for your length of history. Do not close it.

### Your first pass: three reports, three colors

Pull all three reports in the same week. Go through each with a different-colored pen, or one worksheet per bureau (the workbook has one for each). Expect differences: one bureau may show an account the others do not, or a different balance for the same account, because creditors do not always report to all three bureaus on the same schedule. Differences are normal. Contradictions — the same account shown as current at one bureau and charged off at another — are worth flagging.

### Action steps — Module 2

1. Go to AnnualCreditReport.com and pull all three reports this week. Save or print them.
2. Complete one report-reading worksheet per bureau (workbook, pages 1–3).
3. Highlight every line you do not recognize or that looks wrong. Do not dispute anything yet — Module 3 teaches you to verify first.
4. Write down your three FICO scores if you have free access to them through a bank or card issuer, with the date. You will measure progress against these numbers.

---

## Module 3 — Spotting Errors: The Most Common Report Mistakes and How to Document Them

Credit reports are assembled by machines matching imperfect data. Errors are not rare. A Federal Trade Commission study found that about one in five consumers had an error on at least one of their three reports, and about one in twenty had an error serious enough that it could lower their score. You may be one of them — and if you are, correcting the error is the highest-return work in this entire course, because it costs you a stamp and can move your score without you spending a dollar.

### The most common errors

**1. Accounts that are not yours.** An account you never opened, sometimes because of a mixed file — your file blended with someone who has a similar name — or because of identity theft. This is the most serious category. Flag it immediately.

**2. Incorrect balances or credit limits.** A balance that is higher than what you actually owe, or a credit limit reported lower than your real limit. Both inflate your utilization. A $500 limit reported as $300 on a $250 balance turns 50% utilization into 83% on paper.

**3. Wrong payment history.** A payment marked 30 days late when you paid on time. A late payment shown in the wrong month. A current account shown as delinquent. This is the most damaging common error, because payment history is 35% of your score.

**4. Duplicate accounts.** The same debt listed twice — for example, once by the original creditor and once by a collector, both shown as separate active balances. A debt should be listed once as the original account and, if it is in collections, once as the collection account with a $0 balance on the original tradeline after charge-off. Two active balances for one debt is a red flag.

**5. Outdated negative information.** Most negative items must come off after seven years (bankruptcies: 7 or 10 years depending on chapter). A late payment from 2017 still showing in 2026 is outdated. The seven-year clock generally runs from the date of the first delinquency that led to the negative item, not from the last payment or the last time the account was updated.

**6. Re-aged accounts.** A creditor or collector updates the "date of last activity" to make an old debt look new, restarting the seven-year clock on paper. The date of first delinquency is the date that matters, and it does not move because someone made a payment or updated a record.

**7. Wrong account status.** An account you paid off shown as still having a balance. A closed account shown as open (or an open account shown as closed). A settled account shown as still owing the full amount.

**8. Incorrect personal information.** A wrong name spelling, an address you never lived at, a Social Security number variation. These rarely affect your score directly, but they can indicate a mixed file, and correcting them sharpens your file.

### How to document an error before you dispute it

A dispute is only as strong as its evidence. For every suspected error, build a small file — a folder, physical or digital — with:

- A copy of the report page showing the error, with the error circled and dated.
- Whatever proof you have: bank statements showing the payment was made on time, a payoff letter, the cardholder agreement showing your real credit limit, a letter from the creditor.
- A one-paragraph written summary in your own words: what the report says, what the truth is, and what document proves it.
- The date you first noticed it.

Use the error log in the workbook for this. Each error gets one row: account name, bureau, error type, the date you found it, the date you disputed it, and the outcome. This log becomes your command center for Modules 6 and 7, and it is also your paper trail if anything goes wrong later.

### What is NOT an error

Be honest with yourself here, because disputing accurate information is a waste of your time and the bureau's, and this course will not teach you to do it:

- A late payment you actually made late is accurate, even if it feels unfair.
- A balance you actually owe is accurate, even if you wish it were lower.
- An account you opened and forgot about is yours.
- A hard inquiry from an application you submitted is accurate.

If you are unsure whether something is an error, check your records first. Bank and card statements going back two years are usually available free from your bank's website or app. If the statement says you paid on the 12th and the report says you were 30 days late, you have a dispute. If the statement says you paid on the 45th day, you do not — and your energy is better spent on Modules 8 and 9.

### Worked example: the $40 late fee that was not late

Daniel's Experian report showed his store card 30 days late in September 2025. He checked his bank statement: the payment had cleared on September 8, four days before the due date. He printed the statement, circled the payment, and printed the report page with the "30" circled. In his error log he wrote: "Store card, Experian, incorrect late payment, Sept 2025, proof: bank statement 9/8/2025." That one folder — two pages and one log line — was everything he needed for a dispute that, if successful, would remove a 35%-factor hit from his file. No agency, no fee, no phone calls.

### Action steps — Module 3

1. Finish your line-by-line read of all three reports and list every suspected error in the workbook error log.
2. For each error, gather the proof document. If you cannot prove it is wrong, mark it "unverified" and keep looking — do not dispute on a hunch.
3. Rank your errors: accounts that are not yours first, then wrong late payments, then wrong balances and limits, then duplicates and outdated items.
4. Make a copy of everything. Never send an original document to a bureau or creditor.

---

## Module 4 — Your Rights Under the FCRA and FDCPA in Plain English

You have more rights here than most people realize, and they are written into federal law. You do not need to be a lawyer to use them. You need to know what they say, in plain English, and to act in writing.

### The Fair Credit Reporting Act (FCRA)

The FCRA is the federal law that governs credit reports. Its core promises to you:

**You have the right to see your reports.** As covered in Module 2, you can get a free copy from each bureau every week at AnnualCreditReport.com.

**You have the right to dispute inaccurate information.** If you believe your file contains incomplete or inaccurate information, you can dispute it with the bureau, and the bureau must investigate — generally within 30 days (45 in some cases). This right is the engine of Modules 5 through 7.

**The bureau must investigate reasonably.** When you dispute, the bureau must forward your dispute and your supporting documents to the creditor or other furnisher that supplied the information, and that furnisher must investigate and report back. The bureau cannot simply rubber-stamp the creditor's answer.

**You have the right to a free copy after an adverse action.** If a lender denies you credit, or charges you more, because of information in your report, they must tell you which bureau they used and that you can get a free copy of that report within 60 days.

**You have the right to add a statement.** If a dispute does not go your way, you can add a brief consumer statement (usually up to 100 words) to your file explaining your side. Future readers of your report will see it.

**There are time limits on negative information.** Most negative information must be removed after seven years; Chapter 7 bankruptcy after ten years. The clock runs from the date of first delinquency, not from when the debt was sold or updated.

**You have the right to a security freeze.** You can freeze your credit files at all three bureaus for free, and unfreeze them when you need to apply for credit. Module 11 covers this in detail.

**Inaccurate information must be corrected or deleted.** If the furnisher cannot verify the information, or the investigation finds it inaccurate or incomplete, the bureau must delete or correct it and send you the results in writing.

### The Fair Debt Collection Practices Act (FDCPA)

The FDCPA governs third-party debt collectors — companies collecting a debt on behalf of someone else. (It generally does not cover the original creditor collecting its own debt, though many states have laws that do.) Its core protections:

**Collectors must identify themselves and the debt.** Within five days of first contacting you, a collector must send a written validation notice stating the amount, the creditor's name, and your right to dispute the debt within 30 days.

**You can demand validation.** If you dispute the debt in writing within 30 days of that notice, the collector must stop collecting until it provides verification of the debt.

**Collectors may not harass, lie, or threaten you.** No repeated calls meant to annoy, no threats of arrest or legal action they do not intend to take, no false statements about the amount owed or the consequences of not paying, no calls before 8 a.m. or after 9 p.m. your time, and no contact at work if you tell them your employer does not allow it.

**You can tell them to stop contacting you.** A written request to cease communication generally requires the collector to stop contacting you except to say they are stopping or that they intend to take a specific legal action.

**Collectors may not discuss your debt with other people.** They may contact others only to find your address or phone number, and they may not say you owe a debt.

### What these laws do NOT do

- They do not erase debts you legitimately owe. A validated, accurate debt stays on your report until the time limit expires or you resolve it.
- They do not guarantee any particular outcome from a dispute. A lawful, verified item will survive investigation.
- They do not make you judgment-proof. A creditor can still sue for a debt within the statute of limitations in your state — a separate clock from the seven-year reporting clock.
- They do not require the bureau to accept a dispute that is frivolous or irrelevant, such as the same dispute sent repeatedly without new information.

### Action steps — Module 4

1. Write the two law names — FCRA and FDCPA — on the inside cover of your workbook. You will cite the FCRA in every dispute letter.
2. If any collector is currently contacting you, check whether you received a written validation notice. If not, that is your first letter to write (see the template pack).
3. Remember the two clocks: the 7-year reporting clock (federal, from first delinquency) and your state's statute of limitations for lawsuits (varies — look it up for your state before discussing old debts with anyone).
4. Never admit a debt is yours, agree to a payment, or restart a conversation about an old debt with a collector until you have received validation in writing. A partial payment can restart the statute of limitations clock in some states.

---

## Module 5 — Writing an Effective Dispute Letter: What to Include and What to Avoid

Dispute letters are not essays. They are short, factual, specific documents that make an investigator's job easy. An investigator at a bureau processes many disputes a day. The letter that gets results is the one that says, in one page: here is who I am, here is the exact item, here is what is wrong, here is the proof, here is what I am asking you to do.

### What to include

1. **Your identification.** Full legal name, date of birth, current address, and the last four digits of your Social Security number. If you have a report confirmation number, include it.
2. **The item, identified precisely.** Creditor name, account number (partial is fine — never send your full account number if you can avoid it; the last four digits plus the creditor name is usually enough), the bureau's name, and the date of the report.
3. **The error, stated plainly.** One or two sentences. "My report states this account was 30 days late in September 2025. I paid on time on September 8, 2025."
4. **The correction you are requesting.** "Please correct the payment history to show this account as current and paid as agreed for September 2025," or "Please delete this account from my file because it is not mine."
5. **Your evidence, enclosed.** Copies — never originals — of the documents that prove your claim, listed by name in the letter.
6. **A clear legal anchor.** A sentence such as: "Under the Fair Credit Reporting Act, 15 U.S.C. § 1681e(b), you are required to follow reasonable procedures to assure maximum possible accuracy, and under § 1681i you must investigate this dispute." You do not need to quote the law at length. One sentence is enough.
7. **Your signature, the date, and a request for written results.** Ask that the bureau send you the results of the investigation and a free corrected copy of your report.

### What to avoid

- **Do not dispute accurate information.** Disputing a genuinely late payment as "not mine" is dishonest, it wastes the investigation window, and it can cause the bureau to label future disputes from you as frivolous.
- **Do not use a form letter copied word for word from the internet.** Bureaus see thousands of identical letters. Write in your own words, about your specific item, with your specific evidence. The templates in this course are starting points — customize every one.
- **Do not be vague.** "All of this is wrong, fix my credit" gets you nowhere. One error, one letter section, one piece of proof.
- **Do not include irrelevant personal details or emotional appeals.** The investigator is not your judge. Facts and documents are what move a file.
- **Do not threaten legal action you do not intend to take.** It does not speed anything up, and it can make a later, genuine complaint look less credible.
- **Do not send originals.** Copies only. Keep the originals in your folder.
- **Do not dispute everything at once in one giant letter.** One dispute per item, or a short list of clearly separated items with separate evidence for each. If you have five errors, send five focused disputes — or one letter with five numbered sections, each with its own proof.

### Sample dispute letter — incorrect late payment

> [Your full name]
> [Your address]
> [City, State ZIP]
> [Date]
>
> [Bureau name — Equifax / Experian / TransUnion]
> [Bureau dispute address — check the bureau's website for the current mailing address]
>
> Re: Dispute of inaccurate information — [Creditor name], account ending in [last 4 digits]
>
> Dear Sir or Madam:
>
> I am writing to dispute inaccurate information in my credit file. My date of birth is [DOB] and the last four digits of my Social Security number are [last 4].
>
> My report dated [date] states that my [creditor name] account was 30 days late in [month, year]. This is incorrect. I made the payment on time on [date], as shown by the enclosed copy of my bank statement, which shows the payment clearing on that date.
>
> Under the Fair Credit Reporting Act, please investigate this item and correct my payment history to show this account as current and paid as agreed for [month, year]. Please send me written notice of the results of your investigation and a free corrected copy of my report.
>
> Enclosed: (1) copy of my credit report page showing the disputed item, circled; (2) copy of my bank statement showing the on-time payment.
>
> Sincerely,
> [Your signature]
> [Your printed name]

That is the whole letter. Short, specific, documented, and lawful. The template pack in this course includes versions for the five most common disputes: inaccurate account, incorrect balance, account not mine, duplicate account, and outdated negative item.

### Action steps — Module 5

1. Pick your single strongest, best-documented error from Module 3.
2. Draft its dispute letter using the matching template, customized with your real facts and evidence.
3. Read the draft aloud. If any sentence is vague, emotional, or about a different error, rewrite it.
4. Do not send it yet — Module 6 covers how and where to send it for the best paper trail.

---

## Module 6 — Disputing with the Bureaus Step by Step

There are three ways to dispute: online, by phone, and by mail. For this course, mail is the recommended method for your first round of disputes, and here is why: it creates a paper trail. You keep a copy of exactly what you sent, the post office gives you proof of delivery, and the bureau's written response becomes part of your file. Online disputes are faster and are fine for simple corrections once you are comfortable, but an online form gives you limited space and no room for your evidence to be seen the way you intend. If you do dispute online, save screenshots of everything you submit.

### The step-by-step process

**Step 1 — Prepare one dispute per bureau per item.** An error on your Experian report does not automatically fix your Equifax report. If the same error appears at two bureaus, you dispute it at both, with a separate letter to each. Check the current dispute mailing address on each bureau's website before you send anything — addresses change.

**Step 2 — Assemble the packet.** For each dispute: your letter, a copy of the report page with the error circled, and copies of your proof documents. Also include a copy of a government-issued ID and a proof of address (a utility bill or bank statement) if the bureau asks for identity verification — most do for mailed disputes.

**Step 3 — Send by certified mail, return receipt requested.** Go to the post office. Certified mail costs a few dollars and gives you a tracking number and a signed green card back proving the bureau received your letter. Keep the receipt, the tracking number, and the green card in your folder. This is your proof of the date the 30-day investigation clock started.

**Step 4 — Calendar the deadline.** The bureau generally has 30 days from receipt to complete its investigation (45 days in some circumstances, for example if you send additional information during the investigation). Mark the deadline on your calendar the day you mail the letter. If you have not received results by then, you follow up in writing, citing the receipt date.

**Step 5 — Read the results carefully.** The bureau will send you the results in writing, plus a free corrected copy of your report if anything changed. Read every line. There are three possible outcomes:
- **Deleted or corrected** — the item is fixed. Verify it on the new report and log the outcome in your error log.
- **Verified as accurate** — the bureau says the furnisher confirmed the information. If you believe it is still wrong, do not just re-send the same dispute. Go to Module 7 and dispute directly with the furnisher, with stronger evidence, or add a consumer statement to your file.
- **"Frivolous"** — the bureau says it will not investigate because the dispute lacks enough information. This usually means your letter was too vague or had no evidence. Rewrite it with specifics and proof and send it again.

**Step 6 — Check the other bureaus.** If one bureau corrects an item, check whether the same error exists at the other two. If it does, dispute it there too — bureaus do not automatically share corrections with each other.

### A realistic timeline

- **Week 1:** Mail disputes for your top 2–3 errors.
- **Weeks 2–5:** Investigation period. Use this time for Module 8 work — paying down balances — which does not depend on dispute outcomes.
- **Week 5–6:** Results arrive. Log outcomes, verify corrections on fresh reports, and start round two for anything unresolved.

Do not expect every dispute to succeed, and do not take a "verified" result as the final word. Investigators sometimes accept a furnisher's electronic confirmation without real review. If your evidence is solid, the furnisher dispute in Module 7 is your next step, and it often works precisely because you are now dealing with the company that holds the records, not a bureau processing a form.

### Action steps — Module 6

1. Mail your first round of disputes by certified mail this week — your top 2–3 best-documented errors only.
2. Record the certified mail tracking number, the date sent, and the 30-day deadline for each dispute in your error log.
3. While you wait, do not send the same dispute again. Duplicate disputes during an open investigation slow the process down.
4. When results arrive, verify every correction on a fresh copy of the report and update your error log with the outcome.

---

## Module 7 — Disputing with the Furnisher (the Creditor)

The bureau is the middleman. The furnisher — the bank, card issuer, lender, or collector that supplied the information — is the source. When a bureau dispute comes back "verified," or when you want to attack an error at its root, you dispute directly with the furnisher. Under the FCRA, furnishers have their own duties: they must investigate disputes sent directly to them, they must not report information they know or have reasonable cause to believe is inaccurate, and they must correct information they discover is wrong.

### When to go to the furnisher

- A bureau dispute came back "verified" but your evidence says the information is still wrong.
- The error is clearly the creditor's mistake — a payment posted to the wrong account, a limit reported wrong, an account that was paid off but still shows a balance.
- You want the correction to reach all three bureaus at once. When a furnisher corrects information, it generally updates the data it sends to every bureau it reports to, so one successful furnisher dispute can fix the item everywhere.

### How to dispute with a furnisher

**Step 1 — Find the right address.** Do not send your dispute to the payment address on your statement. Look for the creditor's dispute or credit-reporting disputes address — it is often listed on the creditor's website under "credit reporting disputes," on the back of your statement, or in your cardholder agreement. Many large creditors also list a specific address for FCRA disputes. Sending to the wrong address can delay or lose your dispute.

**Step 2 — Write the same kind of letter.** The structure from Module 5 works here too: who you are, the exact account and item, what is wrong, what the truth is, the enclosed proof, and the correction you are requesting. Add one sentence: "Under the Fair Credit Reporting Act, 15 U.S.C. § 1681s-2, you have a duty to investigate this dispute and to report the results to me."

**Step 3 — Send by certified mail, return receipt requested.** Same paper-trail rule as Module 6. Keep copies of everything.

**Step 4 — Calendar 30 days.** The furnisher must generally complete its investigation within the same time frame that applies to bureau disputes, and it must notify the bureaus of the results.

**Step 5 — Follow up on the results.** If the furnisher corrects the information, pull fresh reports from all three bureaus after 30–45 days and confirm the correction appears everywhere. If the furnisher says the information is accurate and you disagree, your options are: send a stronger dispute with additional evidence you did not include the first time, add a consumer statement to your file, file a complaint with the Consumer Financial Protection Bureau (consumerfinance.gov), or consult a consumer attorney — many offer free consultations for FCRA cases.

### Worked example: the limit that was wrong

Priya's card had a $2,000 limit, but her report showed a $1,000 limit. Her balance was $650. On paper, her utilization was 65%. In reality, it was 32.5%. Her bureau dispute came back "verified" — the bureau had simply asked the creditor's computer, which repeated the same wrong number. Priya then wrote directly to the card issuer's credit-reporting disputes address, enclosing a copy of her cardholder agreement showing the $2,000 limit and a statement showing it. The issuer corrected its records, updated all three bureaus, and her reported utilization on that card fell from 65% to 32.5% — a change that, combined with her other work, was reflected in her score within two billing cycles. The bureau could not fix it. The source could.

### A caution

Disputing with a furnisher while an account is in active collections, or while you are negotiating a settlement, needs care. Do not put anything in writing that admits you owe a disputed amount or agrees to a payment plan you cannot keep. Keep every furnisher dispute factual and limited to the accuracy of the reported information. If a debt is genuinely yours and you want to settle it, Module 10 covers how to negotiate — separately, and on your terms.

### Action steps — Module 7

1. List any bureau disputes that came back "verified" despite your evidence, and any error that is plainly the creditor's mistake.
2. Find each furnisher's credit-reporting disputes address (not the payment address).
3. Send one furnisher dispute per item by certified mail, with copies of your evidence.
4. Calendar the deadline, and check all three bureaus 30–45 days later to confirm any correction appears everywhere.

---

## Module 8 — Paying Down Balances: Utilization and the Fastest Score Levers

If Modules 3 through 7 are about correcting the record, this module is about changing the record — and it contains the fastest score lever most people have. Utilization is 30% of your FICO score, and unlike a late payment, it has no memory. Pay a balance down this month, and next month's report can reflect the improvement. That is why this module comes in the middle of your 90 days, while your disputes are being investigated.

### How utilization is calculated

Utilization = (total balances on revolving accounts) ÷ (total credit limits on revolving accounts) × 100.

It is calculated both per card and overall. Both matter. A single maxed-out card hurts even if your overall utilization looks fine, because scoring models look at the individual card too.

**Worked example — the numbers that matter:**

You have three credit cards:

| Card | Balance | Limit | Utilization |
|------|---------|-------|-------------|
| Card A | $2,800 | $4,000 | 70% |
| Card B | $900 | $1,000 | 90% |
| Card C | $150 | $2,000 | 7.5% |
| **Total** | **$3,850** | **$7,000** | **55%** |

Your overall utilization is 55% — high. Card B at 90% is the worst single problem, and Card A at 70% is the biggest dollar problem. A scoring model sees both.

Now suppose you have $1,000 to put toward balances. Where does it do the most good?

- **Option 1: Pay Card B in full ($900) and put $100 on Card A.** New balances: A $2,700 (67.5%), B $0 (0%), C $150 (7.5%). Overall: $2,850 ÷ $7,000 = 41%. You eliminated a 90% card entirely and dropped overall utilization by 14 points.
- **Option 2: Put the whole $1,000 on Card A.** New balances: A $1,800 (45%), B $900 (90%), C $150 (7.5%). Overall: $2,850 ÷ $7,000 = 41%. Same overall number — but Card B is still at 90%, and scoring models penalize individual maxed-out cards.

Option 1 is better. The general rule: **first, get every card below 90%, then get every card below 50%, then work the overall number below 30%, then below 10%.** Eliminating the worst single card usually beats spreading money thinly.

### The thresholds

There is no official FICO rule that says "below 30% is good and above is bad," but the pattern in how scores respond is well documented by consumer experience and by FICO's own guidance that lower utilization is better, with the biggest improvements typically seen at these rough bands:

- **Below 30% overall:** a meaningful improvement zone for most people rebuilding. In our example, getting from 55% to under 30% means balances of $2,100 or less on $7,000 of limits — a $1,750 paydown from $3,850.
- **Below 10% overall:** the strongest zone. Balances of $700 or less on $7,000 of limits. People in the highest score bands typically have utilization in the single digits.
- **0% is not ideal.** Having all cards at $0 can actually score slightly lower than having one card show a small balance, because the model wants to see that you use credit and pay it. The sweet spot is usually one card reporting a small balance — say 1–9% — and the rest at zero. Do not carry a balance to chase this: paying interest to improve your score is bad math. Use the card, let a small balance report, then pay it in full.

**A second worked example — the $2,800 card:**

A single card: $2,800 balance on a $4,000 limit = 70% utilization. Pay it to $1,200 and utilization is 30%. Pay it to $400 and utilization is 10%. On a $4,000 limit, every $400 you pay down moves utilization by 10 percentage points. That is the kind of concrete arithmetic to run for each of your cards in the workbook's utilization tracker.

### When balances are reported — and how to use the timing

Creditors usually report your balance to the bureaus once a month, on or shortly after your statement closing date — not on your payment due date. This creates a timing opportunity: if you pay your balance down *before* the statement closing date, the lower balance is the one that gets reported. Paying after the closing date but before the due date still avoids interest and late fees, but the higher balance is the one the bureau sees that month.

Practical steps:
- Find each card's statement closing date (it is on your statement, usually a few days after the due date of the previous cycle — ask the issuer if you cannot find it).
- Make your payment a few days before the closing date.
- If you use a card heavily during the month, make two payments a month: one mid-cycle and one before the closing date.

### How to find the money

- **Stop using the cards you are paying down.** New charges undo your progress. Use cash or a debit card for daily spending while you work through this module.
- **Pay more than the minimum.** Minimum payments are designed to keep you in debt for years. On a $3,850 balance at 24% APR, paying only the minimum can take over a decade and cost more in interest than the original balance.
- **Attack in order.** List your cards by utilization, highest first. Pay the minimum on all of them, then put every spare dollar on the highest-utilization card until it drops below the next card's level, then move on. This is the fastest route to lower utilization across the board.
- **Do not move balances to a new card to "fix" utilization.** A balance transfer can help if it lowers your interest rate and you have a plan to pay it off — but opening a new card creates a hard inquiry and a new account, and a transfer fee of 3–5% is common. Do not open new accounts during your 90 days unless Module 9 calls for it.

### Action steps — Module 8

1. Fill in the utilization tracker in the workbook for every revolving account: balance, limit, per-card utilization, and overall utilization.
2. Find each card's statement closing date and write it next to the card in the tracker.
3. Decide your paydown order: highest utilization first, then work the overall number below 30%.
4. Pay every card down before its statement closing date this month, and set a calendar reminder to repeat it next month.
5. Stop charging new purchases to any card you are paying down until its utilization is below 30%.

---

## Module 9 — Rebuilding: Secured Cards, Authorized Users, and Credit-Builder Loans — What Helps and What Hurts

Correcting errors and paying down balances removes the negatives. Rebuilding adds positives. A thin or damaged file needs fresh, on-time payment history — and this module is about adding it carefully, without falling into the traps that keep people at low scores.

### Secured credit cards — the single best rebuilding tool

A secured card works like a regular credit card, except you put down a refundable security deposit — usually $200 to $500 — and that deposit becomes your credit limit. You use the card, you pay it on time, and the issuer reports your payments to all three bureaus. After 6–12 months of on-time payments, many issuers return your deposit and upgrade you to an unsecured card.

**How to use one correctly:**
- Choose a card from a major bank or credit union that reports to all three bureaus and has no annual fee, or a low one. Avoid cards with monthly maintenance fees, high application fees, or "processing" charges — those eat your deposit.
- Put down the largest deposit you can comfortably afford, because a bigger limit makes low utilization easier. A $500 limit with a $50 monthly charge is 10% utilization. A $200 limit with the same $50 charge is 25%.
- Use it for one small, recurring charge — a streaming subscription, a tank of gas — and set up autopay for the full statement balance. Never carry a balance on a secured card: the interest rates are high, and carrying a balance does not help your score.
- Keep it open. After it graduates to unsecured, it becomes one of your oldest accounts. Closing it would shorten your history.

**What hurts:** applying for three secured cards at once (three hard inquiries, three new accounts), maxing out a $200-limit card, or missing a payment on the very account meant to prove you pay on time.

### Authorized user status — powerful, but only if the account is clean

Being added as an authorized user on someone else's credit card can add their account's history to your file: its age, its limit, and its payment record. If the primary cardholder has a 10-year-old card with a $10,000 limit, a $300 balance, and a perfect payment history, that can help your score significantly.

**The rules:**
- The primary cardholder must have a genuinely clean record on that account — no late payments, low utilization. If their history is messy, their mess becomes yours.
- You do not need to use the card, and in most cases you should not even take a physical card. The benefit comes from the account appearing on your report.
- The primary cardholder should be someone you trust completely — a spouse, a parent, a close family member — because their behavior affects your file, and your spending on their card would affect theirs.
- Some scoring models discount authorized-user accounts, and some lenders ignore them when they underwrite a mortgage. Treat authorized-user status as a boost, not a foundation. Your own secured card is the foundation.

### Credit-builder loans — useful in the right situation

A credit-builder loan works in reverse: the lender holds the loan amount (say $500 or $1,000) in a locked savings account, you make monthly payments for 6–24 months, and at the end you receive the money. The payments are reported to the bureaus, adding an installment tradeline and a record of on-time payments. Some credit unions and community banks offer them, and some online providers do as well.

**When it helps:** your file has no installment loan at all, and you want to diversify your credit mix while building payment history — and you can afford the monthly payment without strain.
**When it hurts:** the monthly payment stretches your budget, the provider charges high fees, or you take one out before your utilization is under control. A credit-builder loan is a supplement, never a substitute for paying down cards.

### What does NOT help — the traps

- **"Tradeline" rental services** that sell you authorized-user slots on strangers' cards. These are expensive, the accounts can be removed without warning, and some lenders treat them as misrepresentation.
- **Applying for a store card at every checkout.** Each application is a hard inquiry, and store cards tend to have low limits and high rates.
- **Paying a "credit repair" company a monthly fee to send the same dispute letters you can send yourself.** You now know how to do this. Keep the $100–$180 a month.
- **Taking out a loan you do not need** just to add an installment account. The 10% credit-mix factor is not worth paying interest for.
- **Co-signing a loan for someone else.** Their late payments become your late payments. During your rebuilding period, do not co-sign anything.

### A rebuilding sequence that works

1. One secured card, used lightly, paid in full, on autopay.
2. Authorized-user status on one clean account, if a trusted family member offers.
3. A credit-builder loan only after your utilization is below 30% and your budget is stable.
4. No other new applications for at least six months.

### Action steps — Module 9

1. Research one no-annual-fee secured card from a major bank or credit union that reports to all three bureaus. Apply for exactly one.
2. Set up autopay for the full statement balance and one small recurring charge.
3. Ask a trusted family member with a clean, old card whether they will add you as an authorized user. If the answer is no, or the account is not clean, skip this step — it is optional.
4. Do not apply for any other new credit for the rest of the 90 days.

---

## Module 10 — Dealing with Collections and Charge-Offs

Collections and charge-offs are the heaviest items on a damaged report, and they are also the most misunderstood. People either ignore them (and watch them linger for seven years) or panic-pay them (and discover the score barely moved, or that they restarted a legal clock). This module teaches the middle path: verify first, then negotiate from knowledge.

### The vocabulary

- **Charge-off:** when a creditor writes off an unpaid debt as a loss, usually after about 180 days of non-payment. The debt still exists, and the creditor can still collect it or sell it. A charge-off stays on your report for seven years from the date of first delinquency.
- **Collection account:** when the debt is sold to, or placed with, a collection agency, which reports it as a separate tradeline. The original account typically shows a $0 balance after charge-off, and the collection account shows the amount owed.
- **Date of first delinquency:** the date you first became 30 days late and never caught up. This is the date the seven-year reporting clock runs from. It does not move when the debt is sold, when you make a payment, or when a collector updates the file.

### Step 1: Validate before you pay anything

If a collector contacts you, you have the right to written validation under the FDCPA: the amount of the debt, the name of the creditor, and your right to dispute it within 30 days. Send a written debt validation request within that 30-day window (a template is in the template pack). Until the collector provides validation, it must stop collecting.

Check three things in the validation response:
1. Is the debt actually yours?
2. Is the amount correct?
3. Is the date of first delinquency correct — and is the debt still within the reporting period and your state's statute of limitations?

If the debt is not yours, dispute it as an error under Modules 5–7. If the collector cannot validate it, dispute it with the bureaus.

### Step 2: Understand "pay for delete" — and its limits

"Pay for delete" is an agreement in which a collector agrees to remove the collection tradeline from your reports in exchange for payment. Some collectors agree; many do not; and no collector is legally required to. Important truths:

- A paid collection still shows on your report as "paid collection" until the seven-year period expires — but newer FICO models (FICO 9 and VantageScore 3.0 and later) ignore paid collections, while older FICO models still count them. Whether paying helps your score depends on which model the lender uses.
- **Get any pay-for-delete agreement in writing before you pay a dollar.** A verbal promise is worth nothing. The written agreement should state the exact amount, the date, and that the collector will delete the tradeline from all three bureaus (or, at minimum, update it to $0 and "paid").
- Never give a collector electronic access to your bank account. Pay by cashier's check or money order, or a debit card you can cancel — never a direct bank draft.
- Keep the agreement, the proof of payment, and the confirmation letter forever. If the item reappears or the collector sells the "paid" debt to another agency, your paper trail is your defense.

### Step 3: Negotiate a settlement if you cannot pay in full

Collectors often buy debts for pennies on the dollar, so they have room to settle for less than the full balance. A common range is 30–60% of the balance, though it varies widely. Rules:

- Offer a lump sum you can actually pay. A settlement you default on is worse than no settlement.
- Negotiate the amount *and* the reporting: ask for deletion, or at minimum for the account to be reported as "settled in full" or "paid in full" with a $0 balance.
- Get the agreement in writing before paying.
- **Watch the tax consequence:** forgiven debt of $600 or more can be reported to the IRS as income on a Form 1099-C. Ask a tax professional how this applies to you.
- **Watch the statute of limitations:** in some states, making a payment or acknowledging the debt in writing can restart the clock on a creditor's right to sue. Know your state's rule before you negotiate on an old debt.

### Step 4: What to do about charge-offs you cannot pay yet

If you cannot pay a charge-off right now, that is a fact, not a failure. Your priorities:
- Keep every other account current. New on-time payments dilute the damage of old ones over time.
- Do not ignore a lawsuit. If a creditor sues, respond — a default judgment can lead to wage garnishment in many states. If you are sued, consult a licensed attorney or a legal aid office promptly.
- Revisit the debt when your budget allows. A charge-off's damage fades with age, and a settled charge-off is better than an unpaid one in the eyes of many lenders, even if the score effect is modest.

### Worked example: the $1,200 medical collection

Sofia had a $1,200 collection from a medical bill she never received — she had moved, and the bill went to her old address. She sent a validation request. The collector verified the debt and the amount. Sofia offered $500 as a lump-sum settlement in exchange for deletion, in writing. The collector countered at $700 with deletion. Sofia paid $700 by money order, kept the written agreement and the receipt, and 45 days later the collection was gone from all three reports. Her score rose 41 points over the following two months — partly from the deletion, partly from the utilization work she was doing at the same time. The result is not guaranteed for anyone; it is an illustration of the process working as designed.

### Action steps — Module 10

1. List every collection and charge-off in your error log, with the original creditor, the collector, the amount, and the date of first delinquency.
2. Send a written validation request to any collector currently contacting you, within 30 days of their first contact.
3. Do not pay anything until you have validation and, if you are settling, a written agreement.
4. If you settle, get the agreement in writing first, pay by a traceable method that does not give access to your bank account, and keep every document.

---

## Module 11 — Protecting Your Credit: Freezes, Fraud Alerts, and Monitoring

Fixing your credit is pointless if someone else can damage it again. Protection is not an afterthought; it is the lock on the door after you have cleaned the house.

### The security freeze — your strongest tool, and it is free

A security freeze (also called a credit freeze) restricts access to your credit file. With a freeze in place, a lender generally cannot pull your report, which means an identity thief cannot open a new account in your name. Freezing is free at all three bureaus under federal law, and you must freeze each bureau separately.

**How to do it:** Visit each bureau's website or call them — Equifax, Experian, and TransUnion each have a freeze page. You will create a PIN or password. Keep it somewhere safe; you will need it to unfreeze.

**How it works day to day:** A freeze does not affect your existing accounts, your credit score, or your ability to use your own cards. It only blocks new inquiries. When you want to apply for credit yourself, you temporarily lift the freeze (a "thaw") for a specific bureau and a specific time window — often a few days — then it goes back on automatically. A thaw can be instant online.

**Who should freeze:** Everyone doing this course. If you are not applying for new credit in the next few weeks, freeze all three files now and thaw only when you need to. If you are about to apply for a mortgage or car loan, freeze after the application is complete, or coordinate the thaw with your lender.

### Fraud alerts — a lighter layer

A fraud alert tells lenders to take extra steps to verify your identity before opening an account. An initial fraud alert lasts one year; an extended alert lasts seven years and requires a police report or identity-theft report. You place an alert with one bureau, and it must notify the other two. A fraud alert is useful if you have been a victim of identity theft or you suspect your information is exposed, but a freeze is stronger. You can have both.

### Monitoring — useful, but not a substitute

Free monitoring is available from several sources: the bureaus themselves, your bank or card issuer, and nonprofit services. Monitoring tells you when something changes — a new account, a new inquiry, a balance change. It is an alarm, not a lock. Use it to catch problems early, but do not pay a monthly fee for monitoring you can get free. If a service offers a free trial that converts to a paid plan, set a calendar reminder to cancel before the trial ends — or skip it entirely.

### If you discover identity theft

1. Go to IdentityTheft.gov (run by the Federal Trade Commission) and complete an identity-theft report. It will generate a recovery plan and an affidavit you can use.
2. Place a fraud alert and a freeze at all three bureaus.
3. Dispute the fraudulent accounts with the bureaus as "not mine," enclosing the identity-theft report.
4. File a report with your local police if the bureau or creditor asks for one.
5. Keep copies of everything, and check your reports again in 30–60 days.

### Action steps — Module 11

1. Place a security freeze at Equifax, Experian, and TransUnion this week. Store each PIN or password in a safe place — not in a note on your phone's home screen.
2. Set up free monitoring through your bank or card issuer, or directly with a bureau.
3. If you find an account that is not yours, start the identity-theft process at IdentityTheft.gov and dispute the account as "not mine."
4. Review your reports again in 30 days for any new activity you do not recognize.

---

## Module 12 — Your 90-Day Action Plan: Week by Week

Everything in this course comes together here. Ninety days is twelve weeks plus a buffer — long enough for a dispute investigation to complete, for two or three billing cycles of lower balances to report, and for new on-time payments to appear. It is not long enough to erase years of history, and anyone who promises that is selling you something. What 90 days can do is put you on a measurably better footing: errors corrected, utilization down, new positive history started, and your file protected.

**Weeks 1–2 — See the whole picture.**
Pull all three reports at AnnualCreditReport.com. Complete the report-reading worksheets. Turn on autopay (minimum payment) on every open account. List every suspected error in the error log and gather the proof for each. Write down your starting scores and the date.

**Weeks 3–4 — Dispute round one.**
Mail certified disputes for your top 2–3 best-documented errors. Research and apply for one secured card (if you do not already have a usable card). Place security freezes at all three bureaus. Send debt validation requests to any collector currently contacting you.

**Weeks 5–6 — Pay down balances.**
Run the utilization tracker. Pay each card down before its statement closing date, highest utilization first. Stop charging new purchases to cards you are paying down. Check on your dispute results as they arrive and log the outcomes.

**Weeks 7–8 — Dispute round two.**
For anything that came back "verified" despite your evidence, dispute directly with the furnisher (Module 7). For anything corrected, verify it on a fresh report. If your secured card has arrived, set up the small recurring charge and autopay in full.

**Weeks 9–10 — Rebuild and negotiate.**
If a collection is validated and you can settle, negotiate — in writing, before paying. Consider authorized-user status if a trusted family member offers a clean account. Keep utilization below 30% overall and keep every payment on time.

**Weeks 11–12 — Protect and measure.**
Confirm your freezes are in place. Pull fresh reports and compare them, line by line, to your Week 1 reports. Record your new scores and the date. List what changed, what is still in progress, and what your next 90 days should focus on.

**After Day 90 — Keep going.**
Credit repair does not end at 90 days. Keep paying on time, keep utilization low, keep your oldest card open, and check your reports every few months. A late payment from two years ago matters less every month that passes. The habits you build in these 90 days are the system that carries your score upward for years.

### A final word

Your credit file is not a verdict on your life. It is a record — and records can be corrected, balances can be paid, and new history can be written one on-time payment at a time. You now know what most people never learn: how the score is built, where to get the truth about your file, what the law requires of the bureaus and collectors, and how to fix what is wrong and build what is missing. Do the work in order, keep your paper trail, and measure honestly. No score increase, deletion, or approval is guaranteed — but you are no longer guessing, and you are no longer paying someone else to do what you can now do yourself.

---

## Appendix A — Before/After Report Walkthrough

**Before (Week 1) — Jordan, age 34, preparing for a mortgage application.**

- Experian score: 612.
- Card A: $2,800 balance on a $4,000 limit = 70% utilization.
- Card B: $900 balance on a $1,000 limit = 90% utilization.
- One 30-day late payment on Card A, June 2025 — Jordan paid on time and has the bank statement to prove it.
- One collection account for $850 from a utility bill Jordan had already paid; the collector's records are wrong.
- Overall utilization: 55%.

**Actions taken:** Jordan disputed the late payment with proof, disputed the collection as inaccurate, paid Card B to $0 and Card A to $1,100 before the statement closing dates, opened one secured card with a $500 deposit for a small recurring charge on autopay, and froze all three files.

**After (Week 12) — what changed on paper:**

- The late payment was corrected to "paid as agreed." The collection was deleted after the collector could not validate it.
- Card A: $1,100 on $4,000 = 27.5% utilization. Card B: $0 on $1,000 = 0%. Secured card: $45 on $500 = 9%.
- Overall utilization: $1,145 ÷ $5,500 = 21%.
- Experian score: 668.

Jordan's score rose 56 points in 90 days. That result is an illustration, not a promise — your reports, your creditors, and your starting point are different. What the example shows is the mechanics: correction plus paydown plus new positive history, measured honestly, over a realistic time frame.

---

## Appendix B — Glossary

- **Bureau (credit reporting agency):** Equifax, Experian, or TransUnion — the companies that compile your credit reports.
- **Charge-off:** A debt a creditor has written off as a loss, usually after about 180 days of non-payment. It remains collectible and reportable for seven years from first delinquency.
- **Date of first delinquency:** The date an account first became 30 days late and never became current. The seven-year reporting clock runs from this date.
- **FICO Score:** The credit scoring model used by about 90% of top lenders, ranging from 300 to 850.
- **Fraud alert:** A notice on your file telling lenders to take extra steps to verify your identity before opening an account.
- **Furnisher:** A creditor or other company that supplies information to the bureaus.
- **Hard inquiry:** A credit check made when you apply for credit. It can lower your score slightly and stays on your report for two years.
- **Security freeze:** A free restriction that blocks access to your credit file, preventing most new accounts from being opened in your name.
- **Tradeline:** One account entry on a credit report.
- **Utilization:** The percentage of your available revolving credit that you are using. Balance divided by limit, times 100.
- **Validation:** A collector's legal obligation to provide proof of a debt when you dispute it in writing within 30 days of first contact.

---

*The 90-Day Credit Reset System — FIN-03. This course is financial education only, not individualized financial, legal, or credit advice. No score increase, deletion, or approval is guaranteed. Consult a qualified professional for your individual situation.*
