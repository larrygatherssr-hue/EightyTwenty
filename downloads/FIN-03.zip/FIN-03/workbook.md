# The 90-Day Credit Reset System — Companion Workbook

**FIN-03 | Workbook**

> **Disclaimer:** This workbook is financial education only. It is not individualized financial, legal, or credit advice. No score increase, deletion, or approval is guaranteed. Consult a qualified professional for your individual situation. Do not dispute accurate information or misrepresent anything to a bureau or creditor.

Use this workbook alongside the course text (content.md). Print it, or copy the tables into a notebook or spreadsheet. Fill it in as you work through the modules.

---

## 1. Report-Reading Worksheet

Complete one worksheet per bureau. Pull all three reports at AnnualCreditReport.com.

### Bureau: ______________________ (Equifax / Experian / TransUnion)
### Report date: ______________________

**Personal information — check every line:**
- Full name as shown: ______________________ Correct? (Y / N) Notes: ______________________
- Current address: ______________________ Correct? (Y / N) Notes: ______________________
- Previous addresses: ______________________ Any you do not recognize? ______________________
- Date of birth: ______________________ Correct? (Y / N)
- Employer(s) listed: ______________________ Correct? (Y / N)

**Accounts (tradelines) — one row per account:**

| Creditor | Account type | Date opened | Limit / amount | Balance | Status | Late payments shown? | Looks right? |
|----------|--------------|-------------|----------------|---------|--------|----------------------|--------------|
|          |              |             |                |         |        |                      |              |
|          |              |             |                |         |        |                      |              |
|          |              |             |                |         |        |                      |              |
|          |              |             |                |         |        |                      |              |
|          |              |             |                |         |        |                      |              |
|          |              |             |                |         |        |                      |              |

**Inquiries:**
- Hard inquiries listed: ______________________ Any you did not authorize? ______________________

**Collections / public records:**
- Items listed: ______________________ Notes: ______________________

**My starting score (if known):** __________ **Date recorded:** __________

*(Repeat this worksheet for the other two bureaus.)*

---

## 2. Error Log

One row per suspected error. Do not dispute an item until you have proof it is wrong.

| # | Account / creditor | Bureau | Error type (not mine / wrong late payment / wrong balance / wrong limit / duplicate / outdated / wrong status) | What the report says | What the truth is | Proof document | Dispute date | Method (certified mail / online) | Tracking # | 30-day deadline | Outcome |
|---|--------------------|--------|-------------------------------------------------------------------------------------------------------------|----------------------|-------------------|----------------|--------------|----------------------------------|------------|-----------------|---------|
| 1 |                    |        |                                                                                                             |                      |                   |                |              |                                  |            |                 |         |
| 2 |                    |        |                                                                                                             |                      |                   |                |              |                                  |            |                 |         |
| 3 |                    |        |                                                                                                             |                      |                   |                |              |                                  |            |                 |         |
| 4 |                    |        |                                                                                                             |                      |                   |                |              |                                  |            |                 |         |
| 5 |                    |        |                                                                                                             |                      |                   |                |              |                                  |            |                 |         |
| 6 |                    |        |                                                                                                             |                      |                   |                |              |                                  |            |                 |         |

**Priority order (tackle in this order):** 1) accounts that are not yours, 2) wrong late payments, 3) wrong balances and limits, 4) duplicates and outdated items.

---

## 3. Utilization Tracker

Update this on the 1st of each month, and again after every paydown.

| Card / account | Balance | Credit limit | Utilization % (balance ÷ limit × 100) | Statement closing date | Target balance for <30% | Target balance for <10% |
|----------------|---------|--------------|---------------------------------------|------------------------|--------------------------|--------------------------|
|                |         |              |                                       |                        |                          |                          |
|                |         |              |                                       |                        |                          |                          |
|                |         |              |                                       |                        |                          |                          |
|                |         |              |                                       |                        |                          |                          |
| **TOTALS**     |         |              | **Overall utilization: ______%**      |                        |                          |                          |

**Worked example:** $2,800 balance on a $4,000 limit = 70% utilization. To get below 30% on that card, the balance must be under $1,200. To get below 10%, under $400.

**My paydown order (highest utilization first):**
1. ______________________
2. ______________________
3. ______________________

**This month I will pay:** $__________ toward ______________________ before its closing date of __________.

---

## 4. 90-Day Action Checklist (Week by Week)

Check each item off as you complete it.

**Weeks 1–2 — See the whole picture**
- [ ] Pulled all three reports at AnnualCreditReport.com
- [ ] Completed one report-reading worksheet per bureau
- [ ] Turned on autopay (minimum payment) on every open account
- [ ] Listed every suspected error in the error log and gathered proof
- [ ] Recorded starting scores and date: __________

**Weeks 3–4 — Dispute round one**
- [ ] Mailed certified disputes for top 2–3 best-documented errors
- [ ] Recorded tracking numbers and 30-day deadlines in the error log
- [ ] Researched and applied for one secured card (if needed)
- [ ] Placed security freezes at all three bureaus; stored PINs safely
- [ ] Sent debt validation requests to any collector currently contacting me

**Weeks 5–6 — Pay down balances**
- [ ] Filled in the utilization tracker
- [ ] Paid each card down before its statement closing date, highest utilization first
- [ ] Stopped charging new purchases to cards being paid down
- [ ] Logged dispute results as they arrived

**Weeks 7–8 — Dispute round two**
- [ ] Disputed "verified" items directly with the furnisher (Module 7)
- [ ] Verified corrections on fresh reports
- [ ] Secured card set up: small recurring charge + autopay in full

**Weeks 9–10 — Rebuild and negotiate**
- [ ] Negotiated any validated collection settlement — in writing, before paying
- [ ] Considered authorized-user status (only on a clean account, trusted person)
- [ ] Kept overall utilization below 30%

**Weeks 11–12 — Protect and measure**
- [ ] Confirmed freezes are in place at all three bureaus
- [ ] Pulled fresh reports and compared them line by line to Week 1
- [ ] Recorded ending scores and date: __________
- [ ] Wrote down what changed, what is still in progress, and the next 90-day focus

---

## 5. Score-Improvement Checklist

Use this as an ongoing checklist, not a one-time task. Every item here protects or improves your score over time.

- [ ] Every account paid on time, every month (autopay minimum as a safety net)
- [ ] Overall utilization below 30% — working toward below 10%
- [ ] No single card above 30% utilization
- [ ] Oldest credit card still open
- [ ] No new credit applications except the one planned secured card
- [ ] All errors disputed with proof; outcomes logged
- [ ] Collections validated before any payment; settlements in writing first
- [ ] Security freezes in place at all three bureaus
- [ ] Free credit monitoring active
- [ ] Reports re-checked every 2–3 months
- [ ] No co-signing for anyone during the rebuild
- [ ] No dispute of accurate information; nothing misrepresented

**Score log:**

| Date | Equifax | Experian | TransUnion | Notes (what changed) |
|------|---------|----------|------------|----------------------|
|      |         |          |            | Starting point       |
|      |         |          |            |                      |
|      |         |          |            |                      |
|      |         |          |            | Day 90               |

---

*The 90-Day Credit Reset System — FIN-03 Workbook. Financial education only; not individualized financial, legal, or credit advice. No score increase, deletion, or approval is guaranteed.*
