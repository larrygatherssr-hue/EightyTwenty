# Customer Onboarding Guide — The 90-Day Credit Reset System (FIN-03)

Welcome. This guide tells you exactly what to do first, how to use each file, and how your 12 weeks are structured.

## What to do first (Day 1–2)

1. **Read the disclaimer in content.md.** This course is financial education only — not individualized financial, legal, or credit advice. No score increase, deletion, or approval is guaranteed.
2. **Pull all three of your credit reports free** at AnnualCreditReport.com (Equifax, Experian, and TransUnion). Save or print them.
3. **Complete the report-reading worksheet** in workbook.md — one worksheet per bureau. Highlight every line you do not recognize or that looks wrong.
4. **Turn on autopay for at least the minimum payment** on every open account. This protects the biggest factor in your score starting today.

## How to use each file

| File | What it is | How to use it |
|------|-----------|---------------|
| `content.md` | The full course — all 12 modules, worked examples, appendices | Read it in order, one or two modules at a time. It is the manual; everything else supports it. |
| `workbook.md` | Companion workbook | Your working notebook. Fill in the report-reading worksheets, the error log, the utilization tracker, the 90-day checklist, and the score log as you go. |
| `templates/dispute-letter-templates.md` | Five dispute letters + a debt validation request | Customize one letter per error with your real facts and evidence. Send by certified mail; keep copies. Never send a form letter unchanged. |
| `templates/credit-tracker.csv` | Credit tracker spreadsheet | Open in any spreadsheet app. One row per account per bureau: balance, limit, utilization %, status, dispute date, outcome. Update monthly. |
| `templates/90-day-action-plan.md` | The week-by-week plan | Your schedule. Follow it week by week; if a week slips, pick up where you left off. |
| `templates/error-log.md` | Standalone error log | A clean copy of the error log if you prefer to keep it separate from the workbook. |
| `sales-page.md` | The product sales page | Reference copy of how the product is presented. Not needed for the course itself. |
| `cover.webp` | Product cover image | The cover art for the course. |
| `listing.json` | Marketplace listing data | Marketplace record for this product. Not needed for the course itself. |

## Suggested 12-week schedule

- **Weeks 1–2:** See the whole picture — pull reports, complete worksheets, turn on autopay, log errors, gather proof.
- **Weeks 3–4:** Dispute round one — mail certified disputes for your top 2–3 errors; apply for one secured card; place security freezes.
- **Weeks 5–6:** Pay down balances — run the utilization tracker, pay before statement closing dates, highest utilization first.
- **Weeks 7–8:** Dispute round two — dispute "verified" items directly with the furnisher; verify corrections on fresh reports.
- **Weeks 9–10:** Rebuild and negotiate — settle validated collections in writing first; keep utilization below 30%.
- **Weeks 11–12:** Protect and measure — confirm freezes, pull fresh reports, record ending scores, plan the next 90 days.

The full detail for every week is in Module 12 of content.md and in templates/90-day-action-plan.md.

## How to get support

Email the marketplace support address with your order number and the product name (The 90-Day Credit Reset System, SKU FIN-03) and a description of the issue. For questions about your individual financial or legal situation, consult a qualified professional — support cannot give individualized financial, legal, or credit advice.
