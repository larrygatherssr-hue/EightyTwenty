# Dispute-Letter Template Pack

**The 90-Day Credit Reset System — FIN-03**

> **Important:** These templates are starting points for your own letters, not form letters to send word for word. Customize every letter with your real facts, your real account details, and your real evidence. Send copies only — never originals. Send by certified mail, return receipt requested, and keep the receipt, the tracking number, and the green card. Dispute only information you believe is inaccurate, incomplete, or unverifiable. Do not dispute accurate information and do not misrepresent anything. This pack is financial education, not legal advice; consult a qualified professional for your situation.

**Before you send any letter, check the bureau's or furnisher's website for its current dispute mailing address. Addresses change — do not rely on an old address.**

**Your header for every letter:**

> [Your full legal name]
> [Your mailing address]
> [City, State ZIP]
> [Date]
>
> [Bureau name — Equifax / Experian / TransUnion — or furnisher name]
> [Dispute mailing address]
>
> Re: Dispute of inaccurate information — [Creditor name], account ending in [last 4 digits]

**Your identification line (include in every letter):** "My date of birth is [DOB] and the last four digits of my Social Security number are [last 4]. My report is dated [date]."

**Your closing for bureau letters:** "Under the Fair Credit Reporting Act, 15 U.S.C. § 1681e(b), you are required to follow reasonable procedures to assure maximum possible accuracy, and under § 1681i you must investigate this dispute. Please send me written notice of the results of your investigation and a free corrected copy of my report."

**Your closing for furnisher letters:** "Under the Fair Credit Reporting Act, 15 U.S.C. § 1681s-2, you have a duty to investigate this dispute and to report the results to me and to the credit reporting agencies."

---

## Template A — Inaccurate Account (wrong information on an account that is yours)

> Dear Sir or Madam:
>
> I am writing to dispute inaccurate information in my credit file.
>
> My report dated [date] states that my [creditor name] account, ending in [last 4 digits], [describe the error — for example: "was 30 days late in September 2025" / "has a balance of $1,450" / "has a credit limit of $1,000"]. This is incorrect. [State the truth — for example: "I made the payment on time on September 8, 2025" / "My balance on that date was $650" / "My credit limit is $2,000"].
>
> Please investigate this item and correct it to [state the exact correction you are requesting]. Enclosed are: (1) a copy of the report page showing the disputed item, circled; (2) [your proof document — e.g., a copy of your bank statement / cardholder agreement / creditor letter].
>
> [Bureau or furnisher closing paragraph — see above.]
>
> Sincerely,
> [Your signature and printed name]

---

## Template B — Incorrect Balance

> Dear Sir or Madam:
>
> I am writing to dispute an incorrect balance in my credit file.
>
> My report dated [date] states that my [creditor name] account, ending in [last 4 digits], has a balance of $[amount shown]. The correct balance is $[correct amount], as shown by the enclosed copy of [my statement dated (date) / the creditor's letter dated (date) / my payoff confirmation].
>
> Please investigate this item and correct the balance to $[correct amount]. [Bureau or furnisher closing paragraph — see above.]
>
> Enclosed: (1) copy of the report page showing the disputed item, circled; (2) copy of [proof document].
>
> Sincerely,
> [Your signature and printed name]

---

## Template C — Account Not Mine

> Dear Sir or Madam:
>
> I am writing to dispute an account in my credit file that does not belong to me.
>
> My report dated [date] lists a [creditor name] account, ending in [last 4 digits], opened on [date], with a balance of $[amount]. I did not open this account, I have never used it, and I do not recognize this creditor.
>
> Please investigate this item and delete it from my file. [Bureau or furnisher closing paragraph — see above.]
>
> Enclosed: (1) copy of the report page showing the disputed item, circled; (2) copy of my government-issued identification; (3) copy of a proof of address (utility bill or bank statement).
>
> Sincerely,
> [Your signature and printed name]

*If you believe the account is the result of identity theft, also complete a report at IdentityTheft.gov and enclose a copy of it. See Module 11 of the course.*

---

## Template D — Duplicate Account

> Dear Sir or Madam:
>
> I am writing to dispute a duplicate account in my credit file.
>
> My report dated [date] lists the same debt twice: [creditor / collector name], account ending in [last 4 digits], balance $[amount]; and [second creditor / collector name], account ending in [last 4 digits], balance $[amount]. These entries refer to a single debt, [describe it briefly — e.g., "originally owed to (original creditor)"]. The debt should be listed once, not twice.
>
> Please investigate and remove the duplicate entry so that this debt appears only once in my file. [Bureau or furnisher closing paragraph — see above.]
>
> Enclosed: (1) copy of the report pages showing both entries, circled; (2) [any proof you have, e.g., the original creditor's statement or a collection notice].
>
> Sincerely,
> [Your signature and printed name]

---

## Template E — Outdated Negative Item

> Dear Sir or Madam:
>
> I am writing to dispute an outdated negative item in my credit file.
>
> My report dated [date] lists [describe the item — e.g., "a 30-day late payment on my (creditor) account in March 2018" / "a collection account for (creditor), date of first delinquency March 2018"]. More than seven years have passed since the date of first delinquency, and this item is past the reporting period under the Fair Credit Reporting Act, 15 U.S.C. § 1681c.
>
> Please investigate and delete this outdated item from my file. [Bureau or furnisher closing paragraph — see above.]
>
> Enclosed: (1) copy of the report page showing the disputed item, circled.
>
> Sincerely,
> [Your signature and printed name]

---

## Bonus Template — Debt Validation Request (to a collection agency)

Send this within 30 days of a collector's first contact with you, by certified mail.

> [Your full legal name]
> [Your mailing address]
> [City, State ZIP]
> [Date]
>
> [Collection agency name and address]
>
> Re: [Account or reference number from the collector's letter, if any]
>
> Dear Sir or Madam:
>
> I am writing in response to your [letter / call] dated [date] regarding an alleged debt of $[amount] owed to [creditor name, if stated].
>
> Under the Fair Debt Collection Practices Act, 15 U.S.C. § 1692g, I dispute this debt and request validation. Please provide: (1) the amount of the debt and the name of the original creditor; (2) verification of the debt, including the date of first delinquency; (3) proof that you are authorized to collect this debt; and (4) a copy of the original agreement, if available.
>
> Until you provide this validation, please cease all collection activity on this account.
>
> Sincerely,
> [Your signature and printed name]

*Do not admit the debt is yours, agree to a payment, or discuss payment terms in this letter. See Module 10 of the course.*

---

## Sending checklist (use for every dispute)

- [ ] Letter customized with my real facts — no copied form language left in
- [ ] Copies of proof enclosed (never originals)
- [ ] Copy of the report page with the error circled enclosed
- [ ] Copy of ID and proof of address enclosed (for mailed bureau disputes)
- [ ] Address checked on the bureau's or furnisher's website today
- [ ] Sent by certified mail, return receipt requested
- [ ] Tracking number and date sent recorded in the error log
- [ ] 30-day deadline calendared
- [ ] A complete copy of everything sent kept in my folder
