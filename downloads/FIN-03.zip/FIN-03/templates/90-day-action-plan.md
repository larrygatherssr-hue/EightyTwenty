# The 90-Day Action Plan — Week by Week

**The 90-Day Credit Reset System — FIN-03**

> This plan is financial education only, not individualized financial, legal, or credit advice. No score increase, deletion, or approval is guaranteed. Work at your own pace; if a week slips, pick up where you left off rather than starting over.

## How to use this plan

Start on any Monday. Each week has one focus and a short list of actions. The full detail for every step is in content.md — this plan is the schedule, not a substitute for the course.

---

## Weeks 1–2 — See the Whole Picture

**Focus:** Get the truth about your file, on paper.

- Day 1: Go to AnnualCreditReport.com and pull all three reports (Equifax, Experian, TransUnion). Save or print them.
- Day 2–3: Complete one report-reading worksheet per bureau (workbook, section 1). Highlight every line you do not recognize or that looks wrong.
- Day 4: Turn on autopay for at least the minimum payment on every open account.
- Day 5: List every suspected error in the error log (workbook, section 2). For each one, note the proof you need.
- Day 6–7: Gather proof documents — bank statements, payoff letters, cardholder agreements. Make copies; keep originals.
- End of Week 2: Write down your starting scores and the date in the score log.

## Weeks 3–4 — Dispute Round One

**Focus:** Get your strongest disputes into the mail.

- Mail certified disputes for your top 2–3 best-documented errors (content.md, Modules 5–6). Record each tracking number and 30-day deadline in the error log.
- Research one no-annual-fee secured card from a major bank or credit union that reports to all three bureaus. Apply for exactly one.
- Place a security freeze at Equifax, Experian, and TransUnion. Store each PIN or password safely.
- If a collector is contacting you, send a written debt validation request within 30 days of their first contact (template pack, bonus template).

## Weeks 5–6 — Pay Down Balances

**Focus:** Utilization — the fastest lever you control.

- Fill in the utilization tracker (workbook, section 3) for every revolving account.
- Find each card's statement closing date and write it in the tracker.
- Pay each card down before its statement closing date, highest utilization first. Work toward every card below 30%, then overall below 30%.
- Stop charging new purchases to any card you are paying down.
- As dispute results arrive, read them carefully and log the outcome for each error.

## Weeks 7–8 — Dispute Round Two

**Focus:** Follow through where round one did not finish the job.

- For any dispute that came back "verified" despite your evidence, dispute directly with the furnisher (content.md, Module 7). Find the furnisher's credit-reporting disputes address — not the payment address.
- For anything corrected, verify the correction on a fresh copy of the report.
- If your secured card has arrived, set up one small recurring charge and autopay for the full statement balance.

## Weeks 9–10 — Rebuild and Negotiate

**Focus:** Add positive history; resolve collections on your terms.

- If a collection has been validated and you can settle, negotiate the amount and the reporting in writing before you pay anything (content.md, Module 10). Never give a collector electronic access to your bank account.
- Consider authorized-user status only if a trusted family member offers a clean, old account — optional, never required.
- Keep overall utilization below 30% and every payment on time. No new credit applications.

## Weeks 11–12 — Protect and Measure

**Focus:** Lock in the gains and measure honestly.

- Confirm your security freezes are in place at all three bureaus.
- Pull fresh reports and compare them line by line to your Week 1 reports.
- Record your ending scores and the date in the score log.
- Write down: what changed, what is still in progress, and what your next 90 days should focus on.

## After Day 90 — Keep Going

- Keep paying on time, keep utilization low, keep your oldest card open.
- Check your reports every 2–3 months.
- Re-run the error log and utilization tracker whenever something changes.
- Remember: a late payment from two years ago matters less every month that passes. The habits from these 90 days are the system that carries your score upward.
