# Money Smart Teens — Companion Workbook

**Education only — not financial or investment advice:** This workbook is general financial education for teens, young adults, and their parents. It is not individualized financial advice, investment advice, tax advice, or legal advice, and it does not recommend any specific bank, account, card, stock, fund, or investment product. Before opening any account, applying for any card, or investing any money, talk with a parent or guardian and, where appropriate, a qualified professional. Minors need a parent or guardian to open accounts. Investing concepts here are introductory education only, and investing involves risk, including the risk of losing money. Nothing in this workbook guarantees any financial result.

**How to use this workbook:** Work through one worksheet per course module, in order. You can print these pages or copy them into a notebook. Use your real numbers wherever you have them. If you do not earn money yet, use pretend numbers first and redo the exercise when real money arrives — the skill is the same either way.

---

## Worksheet 1 — Earning Money

1. List every source of money you had last month. For each one, write the amount and whether it repeats every month (yes / no / sometimes).

| Source | Amount | Repeats? |
|---|---|---|
| | | |
| | | |
| | | |
| | | |
| **Total money in** | | |

2. My main way of earning is: _______________________________________________
3. Hours it takes, including travel and preparation, per week: _______________
4. Pay per week: _______________  My real hourly rate (pay divided by hours, including travel): _______________
5. One job or task I will agree the price for in writing before I start it: _______________________________________________
6. A way of earning I would like to try in the next three months: _______________________________________________

---

## Worksheet 2 — Your First Bank Account

1. Bank 1: ____________________  Monthly fee: __________  Minimum balance: __________  Free ATMs: __________  Savings interest rate: __________
2. Bank 2: ____________________  Monthly fee: __________  Minimum balance: __________  Free ATMs: __________  Savings interest rate: __________
3. Bank 3: ____________________  Monthly fee: __________  Minimum balance: __________  Free ATMs: __________  Savings interest rate: __________
4. The bank I choose, and why: _______________________________________________
5. My pay or allowance will land in:  [ ] Checking  [ ] Savings  [ ] Other: __________
6. My saving transfer will happen:  [ ] Automatically on payday  [ ] By hand on payday  Amount or percentage: __________
7. Overdrafts are:  [ ] Turned off  [ ] On — I have asked for them to be turned off  [ ] Not sure — I will ask
8. My weekly account check-in day and time: _______________________________________________
9. Complete the first bank account checklist in the templates folder and tick off each step as you finish it.

---

## Worksheet 3 — Budgeting

Build your starter budget on your real take-home pay (not your gross pay). If you do not earn money yet, build it on your allowance.

My take-home income per month: _______________

| Bucket | Percentage | Amount per month | What it covers |
|---|---|---|---|
| Needs | 50% | | |
| Wants | 30% | | |
| Saving | 20% | | |
| **Total** | **100%** | | |

My three biggest needs this month: _______________________________________________
My three biggest wants this month: _______________________________________________
One want I will wait for, and how many months until I can buy it: _______________________________________________
My ten-minute weekly check-in day and time: _______________________________________________
After one month of tracking, my real spending was: Needs __________  Wants __________  Saving __________
What I will change next month: _______________________________________________

---

## Worksheet 4 — Saving Goals

**My emergency fund:** Target amount: __________ (first target: $200)  Amount saved so far: __________  Amount to set aside each month: __________

**Short-term goal (under 3 months):** _______________________________________________  Amount needed: __________  Date needed: __________  Amount to set aside each week: __________

**Medium-term goal (3 months to 2 years):** _______________________________________________  Amount needed: __________  Date needed: __________  Amount to set aside each month: __________

**Long-term goal (over 2 years):** _______________________________________________  Amount needed: __________  Date needed: __________  Amount to set aside each month: __________

Total I will save each month across all goals: __________
What I will give up to reach my short-term goal: _______________________________________________

---

## Worksheet 5 — Your First Paycheck

Use your most recent pay stub. If you do not have a job yet, use the worked example in Module 5 and then redo this worksheet when your first real paycheck arrives.

Employer: _______________________________________________  Pay period: _______________________________________________
Hourly rate: __________  Hours worked: __________  Gross pay: __________
Deductions (list each one): _______________________________________________
Total deductions: __________  Net pay: __________
My gross-to-net percentage (total deductions divided by gross pay, multiplied by 100): __________%
Does the amount in my bank account match the net pay on the stub?  [ ] Yes  [ ] No — I have asked about it
Does the number of hours match the hours I actually worked?  [ ] Yes  [ ] No — I have raised it
My tax withholding this period: __________  My social insurance contribution: __________
Use the first-paycheck tracker in the templates folder to record each paycheck for the next three months.

---

## Worksheet 6 — Credit Basics

1. In my own words, credit is: _______________________________________________
2. The difference between a debit card and a credit card is: _______________________________________________
3. The five factors that build a credit score, in my own words:
   - Payment history: _______________________________________________
   - Amounts owed: _______________________________________________
   - Length of history: _______________________________________________
   - New credit: _______________________________________________
   - Mix of credit: _______________________________________________
4. Accounts in my name (phone contract, store account, card): _______________________________________________
5. Is every payment on those accounts up to date?  [ ] Yes  [ ] No — action needed: _______________________________________________
6. My rule for any credit card I have now or in the future: _______________________________________________
7. One buy now, pay later plan I have running (or "none"): _______________________________________________  Payment dates: _______________________________________________

---

## Worksheet 7 — First Investing Concepts

**Reminder:** This worksheet is education only. It does not recommend any investment, and investing involves risk, including the risk of losing money. These numbers use a stated assumed rate of return for illustration only — real returns are never guaranteed.

1. If I invest $50 a month for 10 years and then leave it alone, my total contribution is: __________
2. Using the assumed 7% annual return from Module 7, what would that be worth at age 58 if I start at 18? __________ (Hint: the module's worked example gives the answer — about $49,000. Write it here, then change the numbers below.)
3. My own numbers: monthly amount I could invest one day: __________  Assumed annual return: __________%  Years until I am 58: __________
4. Using the compound growth calculator in the templates folder (or the formula in Module 7), my estimated balance at 58 is: __________
5. Now change the start date to 10 years later and recalculate. My estimated balance is: __________  The difference is: __________
6. Money I need in the next year (must stay in savings, not invested): __________
7. Money I will not need for 10 years or more (long-term money): __________
8. With a parent or guardian, I have researched how a custodial account works in my area:  [ ] Yes  [ ] Not yet
9. The fees I found for the account or fund I researched: _______________________________________________

---

## Worksheet 8 — Avoiding Money Mistakes

1. The scam-stopping sentence, in my own words: _______________________________________________
2. If a stranger online asked me for money or a code, I would: _______________________________________________
3. The adult I would tell first if I thought I had been scammed: _______________________________________________
4. Buy now, pay later plans I have running right now: _______________________________________________  Every payment date: _______________________________________________
5. My lifestyle-creep rule — when my income rises, half of the increase goes to: _______________________________________________
6. A money mistake I have made, and what I learned from it: _______________________________________________
7. My five protective habits — write each one in your own words and tick it when it is part of your routine:
   - [ ] Save first
   - [ ] Check weekly
   - [ ] Pay in full, on time
   - [ ] Slow down before sending money
   - [ ] Keep records

---

## My 30-Day Money Smart Start Tracker

| Week | What I did | Done? |
|---|---|---|
| 1 | Read Modules 1–2; listed my money sources; reviewed or opened my accounts | [ ] |
| 2 | Read Modules 3–4; built my budget; set my three goals and emergency fund target | [ ] |
| 3 | Read Modules 5–6; read my pay stub; checked accounts in my name | [ ] |
| 4 | Read Modules 7–8; ran my compound growth numbers; wrote my scam-stopping sentence | [ ] |

**My weekly check-in day and time:** _______________________________________________
**My emergency fund target and current balance:** _______________________________________________
**One thing I will do this week:** _______________________________________________
