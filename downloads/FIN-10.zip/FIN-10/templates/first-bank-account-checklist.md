# First Bank Account Checklist

Use this checklist with a parent or guardian when opening your first bank account. Tick each step as you finish it.

## Before You Choose

- [ ] I have compared at least two banks using the five questions in Module 2 (monthly fee, minimum balance, ATM fees, savings interest rate, mobile app and parent access).
- [ ] I know whether the account has a monthly fee, and what waives it if there is one.
- [ ] I know the minimum balance, if any.
- [ ] I know which cash machines are free for this account.
- [ ] I know the interest rate on the savings account.

## Opening the Account

- [ ] A parent or guardian is with me, because minors generally need a parent or guardian to open an account.
- [ ] I have the identification the bank asked for (and my parent or guardian has theirs).
- [ ] I understand whether the account is a joint account or a custodial account.
- [ ] I know my account number and where to find it.
- [ ] I have set up online or mobile banking, and I know my username.
- [ ] I have chosen a strong password that I have not shared with anyone.
- [ ] I have received my debit card, or I know when it will arrive.
- [ ] I have set a PIN that I have memorised and not written down or shared with anyone.

## Setting It Up Right

- [ ] Overdrafts are turned off, or I have confirmed they already are.
- [ ] My pay or allowance is set to land in my checking account (direct deposit arranged, if applicable).
- [ ] My saving transfer is set up: the saving part moves to savings on the day money arrives.
- [ ] My parent or guardian can see the account.
- [ ] I have agreed a weekly ten-minute check-in day and time with my parent or guardian.
- [ ] I know the bank's phone number (on the back of my card) and what to do if I lose my card.

## Staying Safe

- [ ] I will never share my PIN or my online banking password with anyone.
- [ ] I will never click a link in a text or email about my account; I will open the banking app myself instead.
- [ ] I will check my account at least once a week for transactions I do not recognise.
- [ ] I know to tell a parent and call the bank immediately if I see a transaction I do not recognise or if I lose my card.
