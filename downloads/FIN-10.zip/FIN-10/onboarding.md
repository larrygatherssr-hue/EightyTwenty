# Customer Onboarding — Money Smart Teens: Financial Literacy for Teens & Young Adults

Welcome. This guide tells you what to do first, how to use the materials, and how to get support.

## What You Received

After purchase you received these downloadable files:

- **content.md** — the complete written course manual (8 modules, 12,000+ words), including the parent discussion guide, the 30-day Money Smart Start plan, and a glossary. This is a written course, not a video course. There are no videos included.
- **workbook.md** — the companion workbook, with one worksheet per module and a 30-day start tracker.
- **templates/starter-budget-template.csv** — a starter budget template you can open in any spreadsheet app.
- **templates/first-paycheck-tracker.csv** — a tracker for recording each paycheck, line by line.
- **templates/first-bank-account-checklist.md** — a step-by-step checklist for opening a first bank account with a parent or guardian.
- **cover.png** — the product cover image.

## What to Do First

1. **Read the disclaimer at the top of the course manual.** This is general financial education only, not individualized financial or investment advice. Minors need a parent or guardian to open accounts.
2. **Decide who is reading with whom.** If the buyer is a parent, read the "How to Use This Course" section and the parent discussion guide first. If the reader is a young adult, start at Module 1 and work through in order.
3. **Print or save the workbook.** You will need it beside you as you read — every module has a worksheet.
4. **Pick your pace.** Two modules a week finishes the course in a month. One module a week finishes it in two months. Either pace works.

## How to Use the Materials

- **Read the modules in order.** Each one builds on the one before it: earning, then banking, then budgeting, then saving, then the first paycheck, then credit, then investing concepts, then avoiding mistakes.
- **Do the workbook exercise after each module, not later.** The exercises turn reading into habit.
- **Use the templates as you reach them.** The bank account checklist goes with Module 2, the starter budget template goes with Module 3, and the first-paycheck tracker goes with Module 5.
- **Use the parent discussion guide together.** One fifteen-minute conversation per module, after reading it, is the fastest way to make the lessons stick.
- **Follow the 30-day Money Smart Start plan** at the end of the course manual if you want a week-by-week schedule: weeks 1–4 cover modules 1–2, 3–4, 5–6, and 7–8 in turn.

## Suggested Schedule

| Week | Read | Do |
|---|---|---|
| 1 | Modules 1–2 | List your money sources; compare banks; review or open accounts with a parent or guardian |
| 2 | Modules 3–4 | Build your starter budget; set three saving goals and your emergency fund target |
| 3 | Modules 5–6 | Read your next pay stub line by line; check accounts in your name |
| 4 | Modules 7–8 | Run your compound growth numbers; write your scam-stopping sentence; start your weekly check-in |

After the first month, keep the weekly ten-minute check-in going: same day, same time, every week.

## How to Get Support

Email the marketplace support address with your order number and a description of your question. Support can help with downloads and access to the course files. Support cannot provide individualized financial, investment, tax, or legal advice. For questions about a specific bank, card, or investment, talk with a parent or guardian and, where appropriate, a qualified professional.

## Refunds

This product is covered by a 14-day money-back guarantee. Full refund, no questions asked, if requested within 14 days of purchase. To request a refund, contact support by email with your order number.
