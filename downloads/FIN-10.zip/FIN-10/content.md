# Money Smart Teens: Financial Literacy for Teens & Young Adults

## A Complete Written Course Manual

**Important — please read this first:** This is a complete written course manual, **not a video course**. There are no videos included. Everything the course teaches is written out in full in the chapters below, with worked examples, scripts, checklists, and exercises you can do on paper or on a screen. If you were expecting video lessons, this manual is the course itself — read it in order, do the workbook exercises as you go, and you will have covered the full course, at your own pace.

**Education only — not financial or investment advice:** This course is general financial education for teens, young adults, and their parents. It is not individualized financial advice, investment advice, tax advice, or legal advice, and it does not recommend any specific bank, account, card, stock, fund, or investment product. Every family's situation is different. Before opening any account, applying for any card, or putting money into any investment, talk with a parent or guardian and, where appropriate, a qualified professional. Nothing in this course guarantees any financial result. The numbers in the worked examples are illustrations chosen to make the arithmetic easy to follow; real interest rates, fees, wages, and tax rules change over time and vary by place, so always check the current terms before acting.

**A note for parents and guardians:** Minors generally need a parent or guardian to open a bank account, and most investing accounts for minors are custodial accounts owned by an adult for the minor's benefit. Nothing in this course should be read as permission to open an account without a parent or guardian. The parent discussion guide at the end of this manual is designed to be read together.

---

## Table of Contents

- How to Use This Course
- Module 1 — Earning Money: Where a Teen's First Dollars Come From
- Module 2 — Your First Bank Account: Checking, Savings, and Staying Safe
- Module 3 — Budgeting: Giving Every Dollar a Job Before It Arrives
- Module 4 — Saving Goals: Short, Medium, and Long
- Module 5 — Your First Paycheck: Reading It, Understanding It, and Keeping More of It
- Module 6 — Credit Basics: What Credit Is, How Scores Work, and Why It Matters Later
- Module 7 — First Investing Concepts: Compound Growth, Risk, and Starting Small
- Module 8 — Avoiding Money Mistakes: Scams, Debt Traps, and Habits That Protect You
- Parent Discussion Guide
- Your 30-Day Money Smart Start
- Glossary
- Closing: What You Can Do This Week

---

## How to Use This Course

This course has eight modules. Each one takes roughly thirty to forty-five minutes to read, plus the workbook exercise that goes with it. You can finish the whole course in a month by doing two modules a week, or in a single focused weekend if you prefer. Either pace works. What matters is doing the exercises, not just reading.

Each module follows the same shape: a plain explanation of the idea, a worked example with real numbers, the common mistakes people make, and a short action list at the end. The workbook that comes with this course has a worksheet for every module. Keep a notebook or a printed copy of the workbook beside you as you read.

A note on language: when this course says "money in," it means any money you receive — allowance, birthday money, pay from a job, money from selling something. When it says "money out," it means anything you spend. When it says "net," it means what is left after something is taken away — for example, your pay after tax is your net pay.

You do not need any money to start this course. Several modules ask you to practice with pretend numbers first, and the workbook lets you run the exercises with whatever amounts fit your real life, including zero. The habits matter more than the amounts. A teen who learns to split ten dollars wisely will handle a first paycheck wisely, because the skill is the same and only the numbers change.

---

## Module 1 — Earning Money: Where a Teen's First Dollars Come From

Money has to come from somewhere before you can budget it, save it, or spend it. For most teens, the first dollars come from a small set of sources, and understanding each one — what it pays, what it costs you in time, and what rules apply — is the first money skill of all.

### The main ways teens earn

**Allowance.** Some families pay a regular allowance. Some pay for chores, and some do not pay for chores at all, treating household work as a shared family responsibility. None of these arrangements is right or wrong. What matters is that the arrangement is clear: how much, how often, and what it is expected to cover. If your allowance is twenty dollars a week and it is meant to cover your snacks, your streaming share, and your fun money, that is a different budget from twenty dollars a week with no expenses attached. Sit down with your parent and write down what the allowance is supposed to cover. That one conversation prevents most allowance arguments.

**Gifts.** Birthday money, holiday money, graduation money. Gift money is real money, and the easiest mistake is treating it as if it does not count. It counts. A good rule for gift money is the same rule you will use for a paycheck later: decide the split before you spend any of it. The course recommends the 50/30/20 split you will meet in Module 3 — half for needs or planned spending, thirty percent for wants, twenty percent for saving — but the exact percentages matter less than deciding before the money touches your hands. Money that arrives without a plan disappears fastest.

**Work for neighbours and family.** Babysitting, lawn care, dog walking, tutoring a younger student, helping a neighbour move boxes. This kind of work is often a teen's first experience of being paid for a skill, and it teaches something a regular job does not: you have to find the work, agree the price, do the work well, and ask to be paid. That is a complete business in miniature. Agree the price before you start, in writing if the amount is large — even a text message counts. "I will mow your lawn every Saturday for twenty-five dollars" is a contract a text message can hold.

**A part-time job.** Retail, food service, lifeguarding, camp counselling, grocery work. A first job is where most teens meet the ideas in Module 5 — gross pay, tax withholding, a pay stub — for the first time. Before you take a job, check the rules in your area: most places set a minimum age for work, limit the hours a minor can work during the school term, and require a work permit or parental consent. Your school office or a parent can help you find the local rules. They exist to protect you, and a legitimate employer will know them and follow them.

**Selling things.** Old clothes, old games, things you made. Selling teaches pricing: something is worth what someone will pay for it, not what you paid for it. If you sell online, do it with a parent's help and a parent's account, and never meet a stranger alone to hand over an item. Meet in a public place, in daylight, with an adult present.

**Creating something.** Some teens earn from a small online shop, a channel, or freelance design or writing. This can be real income, but it is also the most uneven kind: some months pay well and some pay nothing. If you earn this way, the budgeting and saving modules matter even more, because you have to plan for the dry months during the good ones. You also need to keep records, because income from this kind of work is still income, and tax rules still apply. Keep every payment record in one place from the very first dollar.

### What an hour of your time is worth

Before you agree to any work, do a simple calculation: the pay divided by the hours it takes, including travel and preparation. A babysitting job that pays forty dollars for four hours, with an hour of travel each way, is forty dollars for six hours — about six dollars and sixty-seven cents an hour. A different job paying thirty dollars for two hours, five minutes from home, is worth more per hour and leaves you more time. The highest hourly rate is not always the best choice — a job that teaches you something, or that you enjoy, can be worth a lower rate — but you should know the rate before you decide, not after.

### Worked example: Maya's first month of earning

Maya is sixteen. She babysits two Friday evenings a month at forty dollars an evening, and she mows one neighbour's lawn twice a month at twenty-five dollars a time. Her grandmother sends her twenty dollars for her birthday in the same month. Her total money in for the month is eighty plus fifty plus twenty, which is one hundred and fifty dollars.

But look closer. The babysitting takes four hours an evening, plus thirty minutes of travel each way, so five hours per evening, ten hours for the month. The lawn takes ninety minutes each time, three hours for the month. Maya worked thirteen hours for one hundred and thirty dollars of earned money, which is ten dollars an hour. The birthday money is a gift, not earnings, and it will not arrive next month. If Maya builds a budget that assumes one hundred and fifty dollars every month, she will be twenty dollars short in an ordinary month. That is why the course separates earned income, which repeats, from gift income, which does not. In the workbook you will do this same calculation for your own month.

### The five earning mistakes to avoid

First, agreeing to work without agreeing the price. Second, forgetting the hidden hours — travel, setup, waiting — when you judge whether a job is worth it. Third, spending gift money as if it will come again next month. Fourth, taking a job that breaks your local rules on hours or age, or an employer who asks you to. Fifth, doing work for someone who will not pay, and then doing more work for the same person. One unpaid job is a lesson; two is a pattern.

### Module 1 action list

1. List every source of money you had last month, with the amount and whether it repeats.
2. Calculate your real hourly rate for your main way of earning, including travel time.
3. Agree, in writing, the price for the next job you take before you start it.
4. Open the workbook and complete Worksheet 1.

---

## Module 2 — Your First Bank Account: Checking, Savings, and Staying Safe

A bank account is a tool, and like any tool it works well when you pick the right one and use it properly. This module explains the two accounts most teens need, how to open one with a parent or guardian, and how to keep the money in it safe.

### Checking and savings: what each one is for

A **checking account** is your spending account. Money goes in from a job or an allowance, and money goes out when you pay for things, usually with a debit card. It is built for movement. A **savings account** is your holding account. Money goes in and mostly stays there, earning a small amount of interest — the bank pays you a little for letting it hold your money. It is built for waiting.

The habit this course teaches is simple: money lands in checking, and on the day it lands, the saving part moves to savings automatically or by hand. If you leave the saving part in checking, you will spend it, because checking is where spending happens. Separating the two accounts is not about the bank. It is about your own behaviour.

### How a teen account actually works

In most places, a person under eighteen cannot open a bank account alone. A parent or guardian opens a joint account or a custodial account with you. That means an adult's name is on the account too, and the adult can see the activity. That is normal, and it is a good thing: it means you have a built-in second pair of eyes while you learn.

When you open the account, you will usually receive a debit card. A debit card spends money that is already in your account. That is the crucial difference from a credit card, which spends the bank's money and which you must pay back — credit is covered in Module 6. With a debit card, you cannot spend money you do not have unless your account allows overdrafts, which is a feature you should ask to have turned off. An overdraft fee can be thirty dollars or more for a single small purchase, which is an expensive way to buy a snack.

### Choosing an account: the five questions to ask

Before choosing a bank, ask these five questions, and write down the answers for two or three banks so you can compare them side by side.

1. **Is there a monthly fee, and can it be waived?** Many teen and student accounts have no monthly fee. If there is a fee, ask what waives it — sometimes a minimum balance or a direct deposit does.
2. **Is there a minimum balance?** Some accounts require you to keep a certain amount in them at all times. For a teen account, a zero or very low minimum is best.
3. **What are the ATM fees?** Using another bank's cash machine can cost several dollars per withdrawal. Find out which machines are free for your account, and how many free withdrawals you get.
4. **What is the interest rate on savings?** It will be small — often well under one percent a year at a traditional bank, sometimes more at an online bank. The rate matters less than the habit at this stage, but you should know it, and the worked example below shows why even a small rate adds up.
5. **Does the bank have a good mobile app, and can a parent see the account?** You will manage this account from your phone, and your parent will want to see it too. Both matter.

Do not choose a bank because a friend uses it, or because the branch is closest, or because it gave away a free gift. Choose it because the answers to those five questions are the best for you.

### Interest: the worked example

Suppose you put two hundred dollars in a savings account that pays two percent interest a year. After one year, the bank adds four dollars — two percent of two hundred. Your balance is two hundred and four dollars. That is not exciting. But the habit is the point, and Module 7 will show what happens when that interest itself starts earning interest over many years. For now, the lesson is that savings accounts grow slowly and safely, which is exactly what you want from a place that holds money you may need.

Now suppose you keep that same two hundred dollars in a checking account instead, and you spend it a little at a time on things you had not planned. At the end of the year you have nothing, and nothing to show for it. The difference between the two outcomes is not the four dollars of interest. It is the decision to move the money somewhere it is harder to spend on impulse.

### Staying safe: the rules that protect your money

Your debit card number, your PIN, and your online banking password are the keys to your money. Treat them the way you would treat the keys to your house.

- Never share your PIN with anyone, including a friend. A bank will never ask you for your PIN by phone, text, or email.
- Never share your online banking password. Not with a friend, not with a website that promises free money.
- If a text or email says your account is locked and asks you to click a link, do not click it. Open your banking app yourself, or call the bank on the number on the back of your card.
- Check your account at least once a week. Look for transactions you do not recognise. If you see one, tell a parent and call the bank immediately. The sooner a problem is reported, the more likely it is to be fixed.
- Keep your card in a safe place. If you lose it, report it the same day. A lost card that is reported quickly is a small problem; a lost card that is not reported is a large one.
- Be careful with payment apps. They are convenient, but money sent on most payment apps cannot be taken back. Only send money to people you know and trust, and never send money to someone who contacted you first asking for it.

### Worked example: setting up Jordan's accounts

Jordan is seventeen and just got his first part-time job at a grocery store. He and his mother open a checking account and a savings account at a bank with no monthly fee for student accounts, no minimum balance, and free use of the bank's own cash machines. Jordan's pay will be deposited directly into checking. On payday, Jordan will move twenty percent of his pay to savings the same day, before he spends anything. His debit card is set so that overdrafts are not allowed — if he tries to spend more than is in checking, the purchase is declined instead of going through with a fee. His mother can see the account, and they agree to look at it together every Sunday evening for ten minutes. That ten-minute weekly habit is the most valuable thing Jordan set up on opening day, more valuable than the accounts themselves.

### Module 2 action list

1. With a parent or guardian, compare two or three banks using the five questions above.
2. Decide which account your pay or allowance will land in, and how the saving part will move to savings.
3. Ask for overdrafts to be turned off, or confirm they already are.
4. Complete Worksheet 2 in the workbook, including the first bank account checklist in the templates folder.

---

## Module 3 — Budgeting: Giving Every Dollar a Job Before It Arrives

A budget is not a punishment. It is a plan you make before the money arrives, so that when it arrives you already know where it goes. People who do not budget do not usually overspend on one big thing. They overspend on twenty small things, each of which felt harmless at the time, and then they wonder where the money went. A budget answers that question in advance.

### The 50/30/20 split

This course teaches one simple split, and it works at any income level, from twenty dollars a week to a first full-time salary. Divide your money into three buckets.

- **50 percent for needs.** Things you must pay for: food you buy yourself, transport, phone, school supplies, basic clothing. If you live at home and your parents cover most needs, your needs bucket will be small, and that is fine — the percentages are a starting point, not a law.
- **30 percent for wants.** Things you enjoy but could live without: eating out with friends, games, streaming, concert tickets, new trainers when the old ones still work.
- **20 percent for saving.** Money that moves to savings before you spend anything else. This is the bucket most people skip, which is why this course puts it first in practice even though it is listed last: pay yourself first.

The reason the split works is that it is a decision made once, and then repeated. You do not have to renegotiate with yourself every time you see something you want. You look at the wants bucket and ask one question: is there enough in this bucket? If yes, you can buy it without guilt. If no, you wait. That is the whole system.

### A budget is a plan, not a prediction

Your first budget will be wrong. That is normal. A budget is a guess about the future, and guesses improve with practice. The way to improve it is to track what actually happened for one month, compare it with the plan, and adjust the plan. If you planned thirty dollars for food and spent fifty, the lesson is not that you failed. The lesson is that your real food spending is fifty dollars, and next month's plan should say fifty. Or you decide to pack lunch twice a week and keep the plan at thirty. Either adjustment is correct. What is not correct is writing the same plan again next month and being surprised by the same result.

### Worked example: a starter budget on $150 a month

Maya from Module 1 earns about one hundred and thirty dollars a month from work and receives about twenty dollars in gifts in an average month, but gifts do not repeat reliably, so her budget is built on the one hundred and thirty dollars she can count on. Gift money, when it arrives, is split the same way and added on top.

Using the 50/30/20 split on one hundred and thirty dollars:

- Needs, 50 percent: sixty-five dollars. Maya's needs are lunch at school three days a week, about twelve dollars a week, which is forty-eight dollars a month, plus a phone contribution of fifteen dollars. That is sixty-three dollars, which fits inside her sixty-five dollar bucket with two dollars to spare.
- Wants, 30 percent: thirty-nine dollars. Maya wants a new game that costs forty dollars. She does not have forty dollars in this month's wants bucket, so she saves the thirty-nine dollars and adds next month's wants money to it. She buys the game in month two, having spent nothing from the wants bucket in month one except a five-dollar snack with friends. The delay cost her nothing. The game is the same game.
- Saving, 20 percent: twenty-six dollars. This moves to savings on the day the money arrives, before anything else is spent. After six months, Maya has one hundred and fifty-six dollars in savings, plus a small amount of interest. She has not missed the twenty-six dollars a month, because she never had the chance to spend it — it was gone before the spending started.

Notice what happened: Maya did not need willpower every day. She needed one decision, made once, and repeated. That is what a budget is.

### Worked example: a starter budget on a first job

Now take a seventeen-year-old working fifteen hours a week at twelve dollars an hour. Gross pay is one hundred and eighty dollars a week, about seven hundred and twenty dollars a month. After tax withholding — the details are in Module 5 — the take-home pay is about six hundred and thirty dollars a month. Building the budget on the take-home pay, not the gross pay, is essential, and it is the most common first-job budgeting mistake.

- Needs, 50 percent of six hundred and thirty dollars: three hundred and fifteen dollars. Transport, food, phone, and a share of household costs, if the family arrangement includes one.
- Wants, 30 percent: one hundred and eighty-nine dollars.
- Saving, 20 percent: one hundred and twenty-six dollars a month. In a year, that is one thousand five hundred and twelve dollars, before interest, from a part-time job — enough for a first car fund, a college fund contribution, or a real emergency cushion.

The percentages bend to fit real life. A teen living at home with few needs might save thirty or forty percent. A young adult paying rent may only be able to save ten percent at first. Both are doing it correctly. The wrong answer is saving nothing because the percentage did not look perfect.

### Tracking: the ten-minute weekly habit

A budget that is never checked is a wish. The habit this course recommends is ten minutes, once a week, same day, same time. Open your banking app. Write down money in and money out for the week. Compare each bucket with the plan. Move the saving part if you have not moved it yet. That is all. Ten minutes a week prevents the end-of-month surprise, because you catch a problem when it is small — a wants bucket that is empty on the fifteenth — instead of discovering it when it is large.

### The three budgeting mistakes to avoid

First, budgeting on gross pay instead of take-home pay. You cannot spend money that was withheld for tax. Second, making a budget so strict that it lasts three days. A budget you cannot keep is worse than no budget, because it teaches you that budgeting does not work. Make it realistic, keep it for a month, then tighten it by a small amount. Third, forgetting irregular expenses. A birthday gift for a friend, a school trip, new shoes — these are not surprises if you know they are coming. Put a small amount aside each month for irregular costs, even five or ten dollars, and those months stop hurting.

### Module 3 action list

1. Build your starter budget using the template in the templates folder, based on your real take-home income.
2. Set up the saving transfer to happen on the day money arrives.
3. Pick your ten-minute weekly check-in day and time, and put it in your calendar.
4. Complete Worksheet 3 in the workbook.

---

## Module 4 — Saving Goals: Short, Medium, and Long

Saving without a goal is hard, because there is no reason to say no to the thing in front of you. Saving with a goal is easier, because every no has a yes behind it: no to this snack, yes to the concert ticket in two months. This module is about setting goals that are specific enough to work.

### Three kinds of goals

**Short-term goals** take less than three months: a new game, concert tickets, a pair of trainers, a birthday present for a friend. These are the goals that teach the habit, because the reward arrives quickly.

**Medium-term goals** take three months to two years: a first car, a laptop for college, a holiday with friends, a driving course. These are the goals that teach patience, because the reward is far enough away that you have to keep going after the excitement fades.

**Long-term goals** take more than two years: a college fund, a first flat deposit, a fund for starting a small business. These are the goals that teach the most important money lesson of all, which is compound growth — covered in Module 7. At your age, time is the most valuable thing you own, because money saved early has the longest time to grow.

You should have one goal of each kind at any time. One short-term goal keeps saving fun. One medium-term goal keeps it meaningful. One long-term goal keeps it powerful.

### Making a goal specific

A goal that says "save money" is not a goal. A goal that says "save one hundred and twenty dollars for concert tickets by June 1st" is a goal, because it has an amount, a purpose, and a date. From those three facts you can work out the weekly amount: one hundred and twenty dollars divided by the number of weeks until June 1st. If there are twelve weeks, you need ten dollars a week. Ten dollars a week is a plan. "Save money" is a wish.

Use the same formula for every goal: the total amount, divided by the number of weeks or months until the date, equals the amount to set aside each week or month. If the weekly amount is more than you can afford, you have three honest choices: pick a later date, pick a smaller goal, or find a way to earn a little more. What you must not do is keep the same goal and the same date and simply hope. Hope is not a savings plan.

### Worked example: three goals at once

Eighteen-year-old Sam works part-time and takes home five hundred dollars a month. He saves one hundred dollars a month, which is twenty percent. He splits it across three goals:

- Short-term: eighty dollars for a friend's birthday present in one month. He sets aside eighty dollars this month, buys the present, and the goal is done.
- Medium-term: six hundred dollars for a laptop in ten months. He sets aside sixty dollars a month. After ten months, he has six hundred dollars.
- Long-term: the remaining forty dollars a month goes into a long-term fund he does not touch. After a year, that fund holds four hundred and eighty dollars. After three years, one thousand four hundred and forty dollars, before interest.

Notice that the long-term fund is the smallest monthly amount, and it is also the most important, because it is the one with the longest time to grow. Sam does not feel the forty dollars a month. He will feel the one thousand four hundred and forty dollars in three years.

### The emergency fund: the goal before the goals

Before you save for anything fun, save a small emergency fund. For a teen, this does not need to be thousands of dollars. Two hundred dollars is a good first target, and five hundred dollars is a strong one. An emergency fund is money for the unexpected: a broken phone, a bike repair, a school trip fee that arrives without warning. Its job is to stop a small problem from becoming a debt. If you have no emergency fund and your phone breaks, you borrow money or put it on a card. If you have an emergency fund, you pay for the repair and carry on. The fund is not for concert tickets. It is not for a sale. It is for emergencies, and the discipline of leaving it alone is the skill.

Build the emergency fund first, even if it means pausing other goals for a month or two. Once it is funded, you can direct the full saving amount to your goals, knowing that a surprise will not knock the plan over.

### Where to keep goal money

Keep goal money in savings, not in checking, and if your bank allows it, use separate savings accounts or labelled pots for each goal. When all the money sits in one place, it is easy to spend the laptop money on a game and tell yourself you will replace it later. When the money is separated and labelled, spending it feels like what it is: taking money from one goal to give to another. That is sometimes the right choice, but it should be a conscious choice, not an accident.

### The two saving mistakes to avoid

First, saving what is left over at the end of the month. There is never anything left over, because spending expands to fill the money available. Save first, on the day the money arrives, and spend what remains. Second, setting a goal and then raiding it for something else every month. If you raid a goal three times, you have not saved for the goal. You have saved for the things you raided it for. Be honest about which one you actually wanted.

### Module 4 action list

1. Write down one short-term, one medium-term, and one long-term goal, each with an amount and a date.
2. Calculate the weekly or monthly amount for each one.
3. Set your first emergency fund target: two hundred dollars.
4. Complete Worksheet 4 in the workbook.

---

## Module 5 — Your First Paycheck: Reading It, Understanding It, and Keeping More of It

Your first paycheck is exciting, and then it is confusing, because the number on the pay stub is not the number you expected. This module explains why, line by line, so that the surprise never happens twice.

### Gross pay and net pay

**Gross pay** is the total amount you earned before anything is taken out. **Net pay**, also called take-home pay, is what actually lands in your bank account. The difference is made up of deductions, and the largest of those for most people is tax withholding.

Gross pay is simple arithmetic: your hourly wage multiplied by the hours you worked. If you earn twelve dollars an hour and work fifteen hours in a week, your gross pay for the week is one hundred and eighty dollars. If you work four weeks like that in a month, your gross pay for the month is seven hundred and twenty dollars.

Net pay is gross pay minus deductions. The deductions on a first paycheck usually include income tax withholding and, in many places, contributions to a national social insurance or retirement system. The exact names and rates depend on where you live, and they change over time, so this course does not give you a rate to memorise. It gives you the method: read the pay stub, find each deduction, and check that you understand what it is for. If you do not understand a line, ask your employer or a parent. A legitimate employer will explain every line.

### Worked example: a teen's first paycheck, line by line

Alex is seventeen and works at a café. He earns thirteen dollars an hour and works twelve hours a week. His pay period is two weeks, so he works twenty-four hours per pay period.

- Gross pay: twenty-four hours multiplied by thirteen dollars equals three hundred and twelve dollars.
- Income tax withheld: thirty-one dollars and twenty cents. This is money the employer sends to the tax authority on Alex's behalf. It is not lost — it counts toward the tax Alex owes for the year, and if too much was withheld, some of it may come back as a refund when he files a tax return.
- Social insurance contribution: twenty-three dollars and forty cents. This goes toward the national system that pays for things like retirement and health coverage, depending on the country.
- Total deductions: fifty-four dollars and sixty cents.
- Net pay: three hundred and twelve dollars minus fifty-four dollars and sixty cents equals two hundred and fifty-seven dollars and forty cents. That is what lands in Alex's bank account.

Alex expected three hundred and twelve dollars. He received two hundred and fifty-seven dollars and forty cents. The difference is fifty-four dollars and sixty cents, or about seventeen and a half percent of his gross pay. That percentage will be different for different people and different places, but the lesson is the same: always budget on net pay, never on gross pay. Alex's budget in Module 3 was built on his real take-home amount for exactly this reason.

### The pay stub: what to check every time

A pay stub is the record of a pay period. Check these five things every time you are paid:

1. **Hours.** Does the number of hours match the hours you actually worked? Check your own record — keep a note of your shifts in your phone. If the hours are wrong, raise it the same day.
2. **Hourly rate.** Is it the rate you agreed when you were hired? If you were promised a raise, check that it has taken effect.
3. **Gross pay.** Does the rate multiplied by the hours equal the gross pay shown? If it does not, ask why.
4. **Deductions.** Is each deduction one you recognise? Is the tax withholding roughly in line with previous pay periods for the same hours? A sudden jump deserves a question.
5. **Net pay.** Does the amount deposited in your bank account match the net pay on the stub? If it does not, ask immediately.

Keep your pay stubs. Keep them in a folder, physical or digital, for at least a year. If there is ever a dispute about your pay, the pay stubs are your evidence. If you need to prove your income — for a bank account, a rental application, a college form — the pay stubs are your proof.

### What happens to the tax that was withheld

In most tax systems, the tax withheld from each paycheck is an estimate. At the end of the tax year, you file a tax return that works out the tax you actually owed. If you paid too much through withholding, you get a refund. If you paid too little, you owe the difference. Many teens who work part-time earn little enough that they owe very little tax, or none at all, and they receive most or all of their withheld tax back as a refund. That refund is not free money. It is your own money coming back to you. When it arrives, split it using the same 50/30/20 rule, and send the saving part to savings the same day.

Filing a tax return sounds complicated, and the first time you do it, ask a parent to sit with you, or use the free filing help that many tax authorities and community organisations offer. The skill is worth learning once, because you will use it every year of your working life.

### Overtime, tips, and the things that change your pay

Some jobs pay extra for overtime hours, for working late, or for working on public holidays. Some jobs include tips. Tips are income, and in most places they are taxable income, even when they are paid in cash. Keep a record of tips you receive, in the same place you keep your pay stubs. If your employer adds tips to your paycheck, they will appear on the pay stub. If you receive cash tips, write them down yourself, with the date and the amount.

Do not let a job pay you "off the books" — in cash, with no pay stub and no record. That may sound convenient, but it means you have no proof of your income, no tax record, and no protection if the employer underpays you or lets you go without warning. A legitimate employer gives you a pay stub. If yours does not, talk to a parent about it.

### The first paycheck mistake to avoid

The most expensive first-paycheck mistake is spending the whole first paycheck as if every paycheck will feel like that. It will not. The first paycheck feels large because there was no budget waiting for it. The second paycheck feels smaller, because by then the budget exists. The fix is to set up the budget and the saving transfer before the first paycheck arrives, so that the saving part is already gone by the time you start spending. Alex did this: on the day his two hundred and fifty-seven dollars and forty cents landed, fifty-one dollars and forty-eight cents — twenty percent — moved to savings automatically. He never saw it in his spending account, so he never missed it. After a year of working the same hours, that automatic transfer has put more than six hundred dollars into his savings, without a single act of willpower.

### Module 5 action list

1. The next time you are paid, read every line of your pay stub using the five-point check above.
2. Work out your own gross-to-net percentage, and write it down.
3. If you do not have a pay stub, ask your employer for one.
4. Complete Worksheet 5 in the workbook, including the first-paycheck tracker in the templates folder.

---

## Module 6 — Credit Basics: What Credit Is, How Scores Work, and Why It Matters Later

Credit is one of the most misunderstood words in money. It sounds complicated, and the industry does not help, because it uses the same word to mean several different things. This module separates them, explains the one idea that matters most — that borrowing is renting money, and rent has a price — and shows how the credit history you start building in your late teens will follow you into adult life.

### What credit actually is

Credit is the ability to borrow money and pay it back later. When a bank gives you a credit card with a limit of five hundred dollars, it is saying: you may borrow up to five hundred dollars from us, and you must pay it back. When you buy something for forty dollars with that card, you have borrowed forty dollars. The bank will send you a statement, and you must pay at least a minimum amount by a due date. If you pay the full forty dollars by the due date, you usually pay no interest. If you pay only part of it, the bank charges interest on the rest, and that interest is the price of borrowing.

Interest on a credit card is expensive. Annual rates of twenty percent or more are common. To understand what that means, imagine you borrow one hundred dollars at twenty percent a year and pay nothing back for a year. At the end of the year you owe one hundred and twenty dollars. The twenty dollars is the cost of borrowing the hundred. Now imagine you pay only the minimum each month while continuing to spend. The balance barely moves, because most of your payment goes to interest and only a little goes to the amount you borrowed. That is how a small debt becomes a large one, slowly, month by month, without any single big purchase.

The rule this course teaches is the only credit card rule you will ever need: if you use a credit card, pay the full balance every month, on time, every time. A credit card used this way is a convenient payment tool that costs you nothing. A credit card used any other way is an expensive loan.

### Debit is not credit

This matters, and people confuse it constantly. A debit card spends money that is already in your bank account. A credit card spends the bank's money. A debit card cannot put you in debt, because you cannot spend money that is not there, unless overdrafts are allowed. A credit card can put you in debt, because you can spend money you do not have. They look the same in your hand. They are opposites in what they do. If you are not sure which card you are holding, check with a parent before you use it.

### What a credit score is

A credit score is a number, usually between three hundred and eight hundred and fifty, that summarises how a person has handled borrowing in the past. Lenders use it to decide whether to lend to you and at what interest rate. Landlords may check it before renting to you. Some employers check it. A higher score means a lender sees you as lower risk, and lower risk usually means a lower interest rate — which means borrowing costs you less.

You do not have a credit score the day you turn eighteen. A score is built over time, from a record of borrowing and repaying. That record is called a credit history. Here is the part that surprises most teens: the record starts being written whether you are paying attention or not. A missed payment on a small account, a phone contract in your name that goes unpaid, a student loan payment that is late — each of these can be recorded. The good news is the same: on-time payments, even small ones, build a good record.

### How a score is built: the five factors

Different scoring systems weigh things slightly differently, but the five factors below are the standard ones, and they are worth knowing in plain language.

1. **Payment history.** Did you pay on time? This is the largest factor. One late payment matters. Several matter a great deal.
2. **Amounts owed.** How much do you owe compared with how much you are allowed to borrow? Using a small share of your available credit — say, less than thirty percent — is viewed more favourably than using all of it.
3. **Length of history.** How long have your accounts been open? Longer is generally better, which is one reason to keep your oldest account open and in good standing.
4. **New credit.** How many new accounts have you opened recently? Opening several at once can lower a score temporarily.
5. **Mix of credit.** Having more than one kind of account — for example, a card and a small loan — can help, but this is the smallest factor, and you should never open an account just to improve your mix.

The practical lesson is simple: pay on time, borrow little, and do not open accounts you do not need.

### Worked example: two ways to use a five-hundred-dollar card

Priya is nineteen and has a credit card with a five-hundred-dollar limit. She uses it for petrol and groceries, spending about one hundred and fifty dollars a month.

In the first version of the story, Priya pays the full one hundred and fifty dollars every month, on time, by automatic payment. After a year, she has paid no interest at all. Her credit utilisation — the share of her limit she uses — is thirty percent, which is at the edge of what is considered healthy, and her payment history is perfect. Her record is building well.

In the second version, Priya pays only the minimum, which is twenty-five dollars, and keeps spending one hundred and fifty dollars a month. After three months she owes more than three hundred and fifty dollars, and a growing share of each payment is going to interest. Her utilisation is over seventy percent. Her score is falling, and the debt is growing faster than she expected. The difference between the two stories is not the card, and it is not the amount she spent. It is the decision to pay in full, on time, every month.

### When should a teen have a credit card?

Most teens should not have a credit card of their own. In many places, a person under eighteen cannot have one, and a person under twenty-one needs an adult co-signer or proof of income. That is a protection, not an obstacle. The right time for a first card is when you have a steady income, a budget you already follow, and a parent or guardian who can help you set it up with a low limit, automatic full payment, and a rule that the card is never used for anything that is not already in the budget. Some families use a card with a small limit — one hundred or two hundred dollars — as a training tool, with the parent monitoring it. That can work well. What does not work well is a high-limit card, no automatic payment, and no one watching.

### Buy now, pay later: credit in a friendly costume

"Buy now, pay later" services let you split a purchase into several payments, often with no interest if you pay on time. They feel different from a credit card, but they are the same idea: you are borrowing money and promising to pay it back. The danger is the same too. A single purchase split into four payments feels affordable. Four purchases, each split into four payments, means sixteen payments coming out of your account over the next few weeks, and the total is easy to lose track of. Missed payments can attract fees, and in some places they are reported to credit agencies, which means they can affect your credit history. If you use a buy now, pay later service, use it for one purchase at a time, write down every payment date, and never stack several plans at once.

### Module 6 action list

1. Find out whether you have any accounts in your name — a phone contract, a store account — and check that every payment is up to date.
2. If you have a card, set up automatic payment of the full balance, or ask a parent to help you do it.
3. Write down the five credit-score factors in your own words in Worksheet 6.
4. Complete Worksheet 6 in the workbook.

---

## Module 7 — First Investing Concepts: Compound Growth, Risk, and Starting Small

Investing is the module people are most curious about and most likely to misunderstand. The misunderstanding is that investing is a way to get rich quickly. It is not. Investing is a way to let money you do not need right now grow slowly over a long time, by owning a small piece of businesses or other assets that produce value. The key phrase is "over a long time." At sixteen, eighteen, or twenty, time is the greatest advantage you have, and this module explains why, in numbers you can check yourself.

### Education only

This module is introductory education only. It does not recommend any specific investment, fund, stock, or account, and it is not investment advice. Investing involves risk, including the risk of losing money. Before investing any real money, talk with a parent or guardian and, where appropriate, a qualified professional. In most places, a minor cannot open an investing account alone; a parent or guardian opens a custodial account on the minor's behalf. Never invest money you need for rent, food, or an emergency. Never invest borrowed money. The examples below use round, stated assumptions so the arithmetic is easy to follow — real returns are never guaranteed and never smooth.

### What investing is, in one paragraph

When you save money in a bank, the bank pays you interest, and your money is safe but grows slowly. When you invest, you use your money to buy something — a share in a company, a fund that holds shares in many companies, a bond — and your money grows, or shrinks, depending on how that thing performs. Over long periods, investments in broad collections of companies have historically grown faster than bank savings, but they have also fallen in value for months or years at a time. That fall is called volatility, and it is the price of the higher long-term growth. If you cannot bear the thought of your money being worth less next year than it is today, you are not ready to invest that money yet, and that is a perfectly good answer.

### Compound growth: the idea that changes everything

Compound growth means that your earnings earn earnings of their own. Here is the simplest version. You put one hundred dollars in an account that grows by ten percent a year. After one year you have one hundred and ten dollars. In the second year, the ten percent applies to one hundred and ten dollars, not to the original hundred, so you earn eleven dollars, and you have one hundred and twenty-one dollars. In the third year you earn twelve dollars and ten cents. Each year the amount you earn grows, because the amount it is calculated on grows. That is compounding, and it is the single most powerful idea in this whole course.

### Worked example: starting at eighteen versus starting at twenty-eight

This is the example to show any young person who asks why starting early matters. The assumption is stated clearly: a seven percent average annual return, compounded yearly. Seven percent is an assumption for illustration, not a promise. Real returns vary, and some years are negative.

Amara starts at eighteen. She invests one thousand dollars once, and then invests one hundred dollars a month — one thousand two hundred dollars a year — for ten years, until she is twenty-eight. After ten years she stops adding money entirely. She has contributed one thousand dollars plus twelve thousand dollars, which is thirteen thousand dollars in total.

Ben starts at twenty-eight. He invests one hundred dollars a month — one thousand two hundred dollars a year — for thirty years, until he is fifty-eight. He has contributed thirty-six thousand dollars in total, nearly three times as much as Amara.

At age fifty-eight, using the same seven percent assumption for both, Amara's money — which had forty years to grow — is worth roughly one hundred and six thousand dollars. Ben's money — which had thirty years to grow — is worth roughly one hundred and twenty-one thousand dollars. Ben ends up ahead, but only slightly, despite contributing nearly three times as much money. Amara's ten-year head start did most of the work. If Amara had continued investing one hundred dollars a month for the full forty years, she would have contributed forty-nine thousand dollars and her balance would be roughly two hundred and sixty-two thousand dollars — more than double Ben's, for a contribution only a third larger.

The lesson is not that seven percent is guaranteed. It is not. The lesson is that time in the market matters more than timing the market, and that the money you invest in your teens and twenties has decades to compound, which is an advantage you will never have again. Starting small and starting early beats starting large and starting late, in almost every version of this calculation.

### Worked example: fifty dollars a month from age eighteen

Take a simpler case. You invest fifty dollars a month from age eighteen to age twenty-eight — ten years, six thousand dollars contributed. Then you stop adding money and leave it alone until age fifty-eight. At a seven percent average annual return, that six thousand dollars grows to roughly forty-nine thousand dollars by age fifty-eight. The six thousand dollars you contributed became forty-nine thousand dollars, because it had forty years to compound. If you waited until twenty-eight and invested the same fifty dollars a month for ten years, you would contribute the same six thousand dollars, but at age fifty-eight it would be worth roughly twenty-four thousand dollars — half as much — because it had ten fewer years to grow. Same money, same monthly amount, half the result, purely because of when you started.

Again: seven percent is an assumption, not a promise. The real return could be higher or lower, and in some years the balance will fall. But the shape of the lesson holds at any reasonable rate of return: earlier is worth more than later, and the gap grows with time.

### Risk: the other half of the idea

If investing always went up, everyone would do it with all their money. It does not. The value of investments falls as well as rises, and the fall can be large. A broad fund can fall twenty percent in a bad year. An individual company's shares can fall far more, or become worthless. That is risk, and it is real.

Three ideas help you think about risk sensibly. First, diversification: spreading your money across many different companies, industries, and countries, usually through a fund that holds hundreds of companies, so that the failure of any one company does not ruin you. Second, time horizon: money you need next year should not be invested in anything that can fall, because you may be forced to sell when it is down. Money you will not need for ten years or more can afford to ride out the falls. Third, never invest money you cannot afford to lose, and never borrow money to invest. If losing the money would change your life, the amount is too large.

### What a first investing account looks like

For most young people, the first step is not buying individual shares. It is opening a custodial investing account with a parent or guardian, or, for a young adult, a basic brokerage or retirement account, and investing small, regular amounts in a broad, low-cost fund that holds many companies. Regular small amounts have a name: dollar-cost averaging. It means you invest the same amount every month, whatever the market is doing. When prices are high, your money buys fewer shares. When prices are low, the same money buys more shares. Over time, you pay an average price, and you never have to guess the right moment to buy, because there is no right moment that anyone can predict reliably.

Fees matter. A fund that charges one percent a year keeps one percent of your money every year, which over forty years is an enormous amount. A fund that charges a tenth of one percent keeps a tenth as much. Before choosing any fund or account, ask what the fees are, in plain numbers, and compare them. Low fees are one of the few things in investing you can control, so control them.

### The investing mistakes to avoid

First, investing money you need soon. Second, putting all your money in one company because someone online said it would double. Third, buying and selling constantly in response to news. Fourth, investing money you borrowed. Fifth, assuming that because something went up last year it will go up next year. Past performance is not a promise. And sixth — the most common mistake of all — waiting until you have a large amount before you start. Start with the small amount you have, learn the habit, and let time do the work.

### Module 7 action list

1. Run the compound growth numbers yourself, using the workbook's calculator page, with your own monthly amount and your own assumed rate.
2. With a parent or guardian, research how a custodial account works in your area, and what the fees are.
3. Decide, in writing, how much of your money is long-term money that could be invested one day, and how much is short-term money that must stay in savings.
4. Complete Worksheet 7 in the workbook.

---

## Module 8 — Avoiding Money Mistakes: Scams, Debt Traps, and Habits That Protect You

You now know how to earn, bank, budget, save, read a paycheck, understand credit, and think about investing. This last module is about protecting all of it, because a single mistake — a scam, a bad debt, a habit that quietly drains your money — can undo months of good work. The mistakes in this module are not rare. They happen to smart people every day, and the protection is almost always the same: slow down, check, and ask someone you trust.

### Scams: how they work, and the sentence that stops them

Almost every scam aimed at a young person follows the same shape. Someone you do not know contacts you first — by text, by social media, by email — with an offer that is urgent and too good to be true: free money, a guaranteed investment return, a job that pays far more than any real job, a prize you never entered. Then they ask you to do one of three things: send money, share a password or a code, or click a link. The moment any of those three things is requested, the conversation is over. A real employer does not ask you to pay for a job. A real bank does not ask for your password. A real prize does not require a fee to claim it.

Learn the sentence that stops a scam: "I do not send money or share codes with people who contact me first." Say it, and then stop replying. Tell a parent. Report the message in the app. Then delete it. You do not owe a stranger a polite conversation, and you do not need to be sure it is a scam before you stop replying. If it is genuine, the person will have another way to reach you. They never do, because it is never genuine.

The most common scams targeting teens are worth naming: fake job offers that ask for a fee or for bank details before you have started; fake giveaways on social media that ask you to click a link and log in; "investment" schemes that promise a guaranteed return — there is no guaranteed return in investing, and anyone who promises one is lying; romance or friendship scams, where someone you met online asks for money or for gift cards; and account-takeover scams, where a message pretends to be from your bank and asks you to log in through a link. The link goes to a fake page that steals your password. The protection is always the same: never click a link in a message about your money. Open the app yourself.

### Debt traps: the four to recognise

**High-interest credit card debt.** Covered in Module 6. Paying only the minimum while continuing to spend is the trap. The escape is to stop spending on the card, pay more than the minimum every month, and ask a parent for help making a payoff plan.

**Buy now, pay later stacking.** One plan is manageable. Four plans at once is a debt trap wearing a friendly face. The escape is to finish one plan before starting another, and to write down every payment date.

**Payday loans and cash advances.** These are short-term loans with extremely high fees, aimed at people who need money urgently. The cost of borrowing a small amount for a short time can be several times the amount borrowed. The escape is an emergency fund, even a small one, and asking a parent or a trusted adult for help before borrowing this way.

**Borrowing to invest or to gamble.** Borrowing money to buy an investment or to place a bet is borrowing to take a risk with someone else's money, and the debt remains even if the investment or the bet loses. Never do this. If someone suggests it, that person is not giving you financial advice. They are selling you something.

### Lifestyle creep: the quiet mistake

Lifestyle creep is what happens when your income rises and your spending rises with it, so you never feel richer. You get a raise, and you start eating out more, and buying more, and at the end of the month you have saved the same amount as before — nothing. The protection is a rule you set in advance: when your income rises, half of the increase goes to saving, and half goes to spending. You still enjoy the raise, and your savings rise with your income. Without the rule, the raise disappears into spending so gradually that you never notice it leaving.

### The habits that protect you

The whole course can be reduced to five habits, and if you keep these, the rest will largely take care of itself.

1. **Save first.** Move the saving part on the day money arrives, before you spend anything.
2. **Check weekly.** Ten minutes, once a week, looking at your accounts. Problems caught early are small. Problems caught late are large.
3. **Pay in full, on time.** Any time you borrow, pay the full amount by the due date.
4. **Slow down before you send money.** Any request for money, a password, or a code from someone who contacted you first gets a pause, a check with a parent, and usually a no.
5. **Keep records.** Pay stubs, account statements, receipts for large purchases, and a note of every goal. Records are boring until the day they save you money, and then they are the most valuable thing you own.

### A note on comparison

Social media shows you other people's spending, not their saving. The person posting an expensive holiday may have paid for it with a credit card they cannot afford. The person posting a new car may have borrowed the whole price. You cannot see anyone's bank balance from their photos. Do not build a budget to match someone else's highlight reel. Build it to match your own goals, and let the comparison go. The quietest person in the room is often the one with the emergency fund.

### Module 8 action list

1. Write down the scam-stopping sentence in your own words, and tell a parent what you would do if a stranger asked you for money or a code.
2. Check whether you have any buy now, pay later plans running, and write down every payment date.
3. Set your lifestyle-creep rule now, before your next pay rise: half of any increase goes to saving.
4. Complete Worksheet 8 in the workbook.

---

## Parent Discussion Guide

This section is for parents and guardians to read with their teen. It is not a test, and there are no right answers. It is a set of conversations — one per module — that turn the reading into a shared habit. Each conversation takes about fifteen minutes. Do one a week, in order, and by the end of two months you will have covered the whole course together.

**Before you start:** agree on two ground rules. First, there are no stupid questions about money, from either side. Second, the teen's money is the teen's money to learn with, within the boundaries you agree together. A teen who is allowed to make a twenty-dollar mistake at sixteen is a young adult who does not make a two-thousand-dollar mistake at twenty-two.

**Module 1 — Earning.** Talk about how money entered your household when you were a teen, and what your first job paid. Ask your teen which way of earning interests them most, and what they would charge for it. Agree together what an allowance, if you pay one, is meant to cover, and write it down.

**Module 2 — Banking.** If your teen does not have an account yet, use the five questions in Module 2 to choose one together, and open it together. If they already have one, look at it together for ten minutes: what came in, what went out, and is there anything neither of you recognises? Agree whether overdrafts are on or off, and who can see the account.

**Module 3 — Budgeting.** Build the starter budget together, using your teen's real numbers. Do not build it for them. Sit beside them while they build it, and ask questions rather than giving answers: "What do you think lunch costs in a week?" If the budget is unrealistic, let them discover it in the first month of tracking, and then help them adjust it. A budget they built themselves is a budget they will keep.

**Module 4 — Saving goals.** Ask your teen to name their three goals — one short, one medium, one long — and then ask the question that makes the goal real: "What will you give up to reach it?" If they cannot name anything, the goal is not yet real. Help them set the emergency fund target of two hundred dollars first, before the fun goals.

**Module 5 — The first paycheck.** When the first paycheck arrives, sit down together and read the pay stub line by line. Explain each deduction in your own words, and be honest about the ones you find confusing yourself. If your teen's employer does not provide a pay stub, help them ask for one. This conversation is worth more than any single chapter in the course.

**Module 6 — Credit.** Talk honestly about your own experience with credit, including any mistake you made and what it cost you. A parent who admits a mistake teaches more than a parent who pretends to have been perfect. Agree together whether your teen should have a card, and if so, what the limit is, what it may be used for, and who watches it.

**Module 7 — Investing.** This is the conversation most parents put off, because they feel they do not know enough. You do not need to know a great deal to have it. The two questions that matter are: what is a custodial account, and what are the fees? Research those two questions together, with your teen, using the same sources a professional would use — the account provider's own fee page, not a social media post. If you decide your teen is not ready to invest real money, say so, and let them practise with the workbook's calculator instead. The habit of thinking long-term matters more than the account.

**Module 8 — Mistakes and scams.** Tell your teen the scam-stopping sentence in your own words, and agree on what they should do if they are ever unsure: pause, tell you, and do not send anything. Make sure they know that telling you about a mistake — a scam they fell for, a payment they missed — will never be met with anger. The day a teen hides a money mistake from a parent is the day a small problem starts becoming a large one.

**A final note for parents:** your teen will learn more from watching how you handle money than from anything in this course. If you budget, they will budget. If you check your accounts, they will check theirs. If you talk about money calmly and openly, they will too. The course gives you the words. Your example gives them the weight.

---

## Your 30-Day Money Smart Start

Do not try to do everything in this course at once. Do this instead.

**Week 1:** Read Modules 1 and 2. List your sources of money. With a parent or guardian, compare banks and open or review your accounts. Turn off overdrafts if they are on.

**Week 2:** Read Modules 3 and 4. Build your starter budget using the template. Set your three saving goals and your emergency fund target. Set up the saving transfer for the day money arrives.

**Week 3:** Read Modules 5 and 6. Read your next pay stub line by line. Check whether any accounts exist in your name and that every payment is up to date. Write down the five credit-score factors in your own words.

**Week 4:** Read Modules 7 and 8. Run the compound growth numbers for your own monthly amount. Write down the scam-stopping sentence. Pick your weekly ten-minute check-in day, and do the first one.

At the end of thirty days you will have an account, a budget, three goals, an emergency fund started, a pay stub you understand, and a weekly habit. That is the whole course, in practice. Keep the habit going, and the numbers will take care of themselves.

---

## Glossary

**Allowance:** Money given regularly by a parent or guardian, often weekly or monthly.

**Budget:** A plan for how money coming in will be divided between needs, wants, and saving, made before the money arrives.

**Checking account:** A bank account for everyday spending, usually accessed with a debit card.

**Compound growth:** Growth in which earnings themselves earn further earnings, so the amount earned grows over time.

**Credit:** The ability to borrow money and pay it back later. A credit card spends the lender's money, not yours.

**Credit history:** A record of how a person has handled borrowing and repayment over time.

**Credit score:** A number summarising a person's credit history, used by lenders and sometimes landlords and employers.

**Credit utilisation:** The share of available credit that is currently being used. Using a small share is generally viewed more favourably than using all of it.

**Custodial account:** An investing or bank account opened by an adult for a minor, controlled by the adult until the minor reaches adulthood.

**Debit card:** A card that spends money already in your bank account.

**Deduction:** An amount taken from gross pay before net pay is calculated, such as tax withholding.

**Diversification:** Spreading money across many different investments so that the failure of any one of them does not ruin the whole.

**Emergency fund:** Money set aside for unexpected expenses, kept separate from spending money and from goal savings.

**Gross pay:** Total pay earned before any deductions are taken out.

**Interest:** Money paid by a bank for holding your savings, or money charged by a lender for borrowing.

**Net pay (take-home pay):** Pay remaining after deductions, which is the amount that actually lands in your bank account.

**Overdraft:** Spending more than is in a bank account, which usually attracts a fee if the account allows it.

**Pay stub:** The record of a pay period, showing hours, rate, gross pay, deductions, and net pay.

**Tax withholding:** Tax taken from each paycheck by the employer and sent to the tax authority on the employee's behalf.

**Volatility:** The extent to which the value of an investment rises and falls over time.

---

## Closing: What You Can Do This Week

You do not need to remember every number in this course. You need to remember five things, and do them.

First, decide where your money goes before it arrives. Second, move the saving part on the day it arrives. Third, check your accounts for ten minutes every week. Fourth, pay any borrowing in full and on time. Fifth, slow down before you send money to anyone, and ask a parent if you are unsure.

Do those five things for a year, and you will be ahead of most adults. Do them for ten years, starting now, and the compound growth example in Module 7 will not be a story about someone else. It will be a story about you.

This course is general financial education only. It is not individualized financial, investment, tax, or legal advice, and it guarantees no financial result. Before opening any account, applying for any card, or investing any money, talk with a parent or guardian and, where appropriate, a qualified professional. Minors need a parent or guardian to open accounts. Investing concepts in this course are introductory education only, and investing involves risk, including the risk of losing money.
