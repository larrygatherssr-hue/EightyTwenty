# FIN-10 — Money Smart Teens: Financial Literacy for Teens & Young Adults

**Price:** $97 (one-time) · **Category:** Finance & Wealth Building · **SKU:** FIN-10

A complete written course manual (not a video course) — a parent-guided financial literacy course for teens covering earning, banking, budgeting, credit basics, and first investing concepts. Education only; not financial or investment advice.

## Files

- **content.md** — The full written course: 8 modules (12,271 words), table of contents, worked examples with real numbers, parent discussion guide, 30-day Money Smart Start plan, and glossary.
- **workbook.md** — Companion workbook with exercises and worksheets for every module, plus a 30-day start tracker.
- **templates/starter-budget-template.csv** — Starter budget template (50/30/20 split) for a spreadsheet app.
- **templates/first-paycheck-tracker.csv** — First-paycheck tracker for recording pay stubs line by line.
- **templates/first-bank-account-checklist.md** — First bank account checklist for opening an account with a parent or guardian.
- **sales-page.md** — Full sales page: headline, problem, solution, module list, who it is for / not for, price and guarantee, FAQ, and disclaimers.
- **listing.json** — Marketplace listing data (SKU, name, category, price_cents 9700, billing, headline, description, delivery note, SEO keywords, refund policy, support).
- **cover.md** — Cover design brief (black-and-gold luxury, 2:3 portrait).
- **cover.png** — Cover image, 1280 x 1920 portrait, black-and-gold.
- **onboarding.md** — Customer onboarding guide: what to do first, how to use the materials, suggested schedule, and how to get support.
