# The Eco Home Product Workshop: Formulate, Package, and Sell Natural Household Products

## A Complete Written Course Manual

**Price:** $197 — one-time purchase
**Format:** This is a complete written course manual. It is not a video course. Everything in the course — all eight modules, all thirty formulations, every worksheet reference, and every worked example — is delivered in writing so you can read it at your own pace, print the pages you need at your workbench, and search it whenever a question comes up.

---

## Important Disclaimers — Please Read First

This manual is general education for makers who want to turn natural household products into a small business. It is not legal advice, medical advice, or financial advice.

**Safety first.** Every formulation in this manual is for external household use only — cleaning surfaces, washing hands, doing laundry, and similar household tasks. Nothing in this manual is food, medicine, or a product for internal use. Never ingest a cleaning product, and never apply a household cleaner to skin except where a recipe is explicitly a hand soap or body wash designed for skin contact.

**Essential oils and children and pets.** Essential oils are concentrated plant extracts. Some are unsafe for babies and young children, and some are toxic to cats and dogs. This manual flags the main risks in the safety notes for each formulation, but it cannot cover every household situation. Keep essential oils and finished products out of reach of children. Never diffuse essential oils in a closed room with a baby, a pregnant person, or a pet that cannot leave the room. If a child or pet ingests or is exposed to a product, contact your local poison control center or a veterinarian immediately.

**Patch testing and ventilation.** Before selling any product meant for skin contact, patch-test it on yourself and test it on a small, hidden surface before using a cleaner on a new material. Work in a ventilated area when mixing products that contain vinegar, alcohol, or essential oils. Wear gloves and eye protection when handling washing soda, lye (sodium hydroxide), or concentrated castile soap. Lye is caustic and causes serious burns; cold-process soap making with lye is an advanced skill and this manual's soap recipes use the safer melt-and-pour method unless a recipe says otherwise.

**Labeling and legal compliance.** The labeling guidance in Module 6 is general education about how labeling commonly works in the United States. Rules differ by product type (cosmetic, soap, household cleaner, or pesticide claim), by state, and by sales channel, and they change over time. You must verify the current rules for your products and your location before you sell anything. When in doubt, consult a local attorney or your state or local small-business development center. Nothing in this manual guarantees that a label following its guidance is compliant.

**Income and results.** The pricing examples in this manual use realistic ingredient costs and typical market prices. They are examples, not promises. Your actual costs, prices, and sales will depend on your suppliers, your location, your market, your effort, and factors outside your control. No income level is guaranteed. Start small, track every dollar, and grow only when the numbers support it.

---

## How to Use This Manual

Work through the modules in order the first time. Module 1 sets up your workspace and your safety habits. Module 2 teaches the formulation principles everything else depends on. Module 3 is the recipe library — thirty tested formulations with a cost per unit for each one. Module 4 teaches you to cost any product of your own. Module 5 turns cost into price and profit. Module 6 covers labels. Module 7 covers packaging. Module 8 covers selling.

The companion workbook (`workbook.md`) has an exercise for every module. Do the exercises as you go rather than saving them for the end; a maker who has costed three products understands pricing far better than a maker who has only read about it.

Keep a dedicated notebook — paper or digital — as your formulation log. Record every batch: date, recipe, supplier, batch size, cost, and what you observed. Your log is your quality record, your costing source, and your defense if a customer ever asks a question about a batch.

---

## Table of Contents

- Module 1: The Maker Business — Foundations, Safety, and Your Workspace
- Module 2: Formulation Science — Ingredients, pH, Preservation, and Scent
- Module 3: The Formulation Library — 30 Tested Natural Household Products
  - 3A. Soaps and Hand Care (Formulations 1–5)
  - 3B. All-Purpose and Kitchen Cleaners (Formulations 6–12)
  - 3C. Laundry Care (Formulations 13–18)
  - 3D. Bathroom and Disinfecting Cleaners (Formulations 19–24)
  - 3E. Glass, Floors, and Specialty Products (Formulations 25–30)
- Module 4: Costing — Know What Every Product Really Costs
- Module 5: Pricing for Profit — Margins, Channels, and Real Numbers
- Module 6: Labeling and Compliance — What Goes on the Bottle
- Module 7: Packaging — Containers, Suppliers, and Sustainability
- Module 8: Selling — Etsy, Markets, Your Own Shop, and Your First 90 Days

---

## Module 1: The Maker Business — Foundations, Safety, and Your Workspace

### 1.1 Why natural household products sell

People buy natural household products for three reasons, and a successful maker speaks to all three. First, health: many buyers want fewer synthetic fragrances and harsh chemicals around their children, their pets, and their own skin. Second, scent and experience: a lemon-and-rosemary dish soap or a lavender linen spray feels better to use than a generic bottle, and that feeling is worth paying for. Third, values: buyers who care about plastic waste, biodegradable ingredients, and local makers will choose a small producer over a supermarket brand when the product works and the price is fair.

Your advantage as a small maker is not price. You will never beat a supermarket on price per ounce. Your advantage is trust, scent, story, and service: a product made in small batches by a named person, with ingredients the buyer can pronounce, sold by someone who answers questions. Price accordingly, and never apologize for it.

### 1.2 What this business actually looks like

A realistic first year for a part-time maker looks like this. You start with five to eight products, not thirty. You make them in your kitchen or a spare room, in batches of ten to twenty units. You sell at one local market a month and on one online channel. A typical market day might bring in $150 to $400 in sales; a quiet online week might bring in $40 to $120. Some makers grow from there into wholesale or a full-time income; many stay happily part-time. Both outcomes are fine. The goal of this manual is to make sure that whichever path you take, every product you sell is safe, honestly labeled, and genuinely profitable — not a hobby subsidized by your day job.

Set your expectations with a simple rule: if a product cannot earn at least a 50 percent gross margin after all costs (ingredients, container, label, and your market or platform fees), it does not belong in your line yet. Module 5 will show you exactly how to test that.

### 1.3 Your workspace

You do not need a commercial kitchen to start, but you do need a dedicated, clean, organized making space. Choose a counter or table that can be wiped down completely. Keep making supplies separate from food preparation: use separate cutting boards, measuring cups, funnels, and mixing bowls for products, and label them "MAKING ONLY" so nobody uses them for food.

Your starter kit:

- A digital kitchen scale that measures in grams (accuracy matters far more than volume cups).
- Stainless steel or glass mixing bowls in two sizes; a whisk, a silicone spatula, and a funnel.
- Measuring cups and spoons reserved for making.
- Spray bottles, jars, and pump bottles for test batches.
- Nitrile gloves, safety glasses, and an apron.
- A thermometer (useful for melt-and-pour soap).
- White vinegar, baking soda, washing soda, citric acid, and castile soap as your base pantry.
- A spray bottle of diluted white vinegar and a roll of paper towels for cleanup.
- A notebook or printed formulation log sheets (see the workbook).

Store ingredients in a cool, dry place, away from direct sunlight, in labeled containers with the purchase date written on them. Essential oils belong in dark amber glass bottles with the caps on tight. Keep everything out of reach of children and pets.

### 1.4 Safety habits that protect you and your customers

Safety is not a chapter you read once; it is a habit you practice every batch. Adopt these rules now:

1. **Read the whole recipe before you start.** Know every ingredient, every step, and every hazard before you open a bottle.
2. **Weigh, do not guess.** Kitchen scales are cheap and errors compound. A formulation that is 10 percent off on washing soda can irritate skin or damage a surface.
3. **Wear gloves and eye protection** when handling washing soda, citric acid in bulk, alcohol, or any concentrated soap. Wash your hands after making, even with gloves on.
4. **Ventilate.** Open a window or run a fan when mixing anything with vinegar, alcohol, or essential oils. Never lean over a steaming pot and breathe deeply.
5. **Never mix bleach with vinegar, ammonia, or acids.** This manual contains no bleach recipes, and that is deliberate. Mixing bleach with an acid creates chlorine gas, which can cause serious injury. If a customer asks you to make a bleach product, decline.
6. **Label every batch.** Every container you make gets a label with the product name, the date, and the batch number — even test batches for your own use. Unlabeled bottles are how accidents happen.
7. **Patch-test skin products.** Before you sell a hand soap or body wash, test it on a small patch of your own inner forearm for 24 hours. If redness or itching appears, reformulate. Do not sell a product you have not used yourself for at least a week.
8. **Test cleaners on a hidden spot.** A cleaner that is safe on ceramic tile may etch marble or strip a wood finish. Test on an inconspicuous area and wait 24 hours before using it broadly.
9. **Keep a first-aid note on the wall.** Poison control, your doctor, and your veterinarian's numbers should be visible in your workspace, not buried in your phone.

### 1.5 The five product families

Every product in this manual belongs to one of five families, and each family has different rules:

- **True soaps** (hand soap, body wash, dish soap bars) clean by surfactant action and are regulated differently from cosmetics in the United States when they meet the legal definition of soap.
- **Cosmetics** (anything applied to skin for cleansing or beautifying, including liquid hand soap that makes a cosmetic claim) fall under cosmetic labeling rules.
- **Household cleaners** (all-purpose spray, glass cleaner, floor cleaner) are general household products, but any claim to kill germs moves a product into pesticide regulation.
- **Laundry products** (detergent, softener, stain treatment) are household products with their own labeling conventions and strong customer expectations about performance.
- **Air and fabric fresheners** (linen spray, room spray) are household products; scent claims are fine, but health claims are not.

You do not need to memorize the regulations today. You need to know that the category matters, that claims matter, and that Module 6 will walk you through the label for each family.

### 1.6 Your first week — action steps

1. Set up your workspace and buy your starter kit and base pantry.
2. Read Modules 1 and 2 in full.
3. Make three formulations from Module 3 for your own household — one soap, one all-purpose cleaner, and one laundry product — and log each batch in your formulation log.
4. Use each product yourself for a week before you even think about selling it.
5. Open your costing worksheet (workbook Module 4) and cost all three products.

If you complete those five steps, you have done more real business preparation than most makers do in their first month.

---

## Module 2: Formulation Science — Ingredients, pH, Preservation, and Scent

### 2.1 What a cleaner actually does

Cleaning is the removal of dirt, grease, and microbes from a surface. Every effective cleaner does four things: it wets the surface, it loosens soil, it holds soil in suspension so it can be wiped or rinsed away, and it leaves the surface in a condition that resists immediate re-soiling. Natural formulations achieve this with a small set of workhorse ingredients rather than the long chemical lists on supermarket bottles.

The main cleaning mechanisms are:

- **Surfactants** reduce the surface tension of water so it can wet and lift grease. Castile soap, soap nuts (soapberries), and plant-derived surfactants such as coco glucoside are the natural maker's surfactants.
- **Alkalis** (baking soda, washing soda) cut grease and neutralize acids. Washing soda is stronger than baking soda and is the backbone of laundry and heavy-duty cleaning.
- **Acids** (white vinegar, citric acid) dissolve mineral deposits, soap scum, and limescale, and they cut through hard-water film.
- **Solvents** (rubbing alcohol, vodka, or witch hazel) dissolve sticky residues and help glass cleaners dry streak-free.
- **Abrasives** (baking soda paste, fine salt) provide gentle scouring power for sinks and tubs.
- **Essential oils** provide scent and, in some cases, mild antimicrobial properties — but scent is their reliable job, and germ-killing is not a claim you should make without regulatory backing.

### 2.2 The ingredient pantry — what each ingredient does

**Castile soap (liquid).** A plant-oil-based soap, usually olive, coconut, or a blend. It is your primary surfactant. Use it diluted — a little goes a long way — and never mix it directly with vinegar in the same bottle, because the acid reacts with the soap and creates a white, oily precipitate that clogs sprayers and reduces cleaning power. Use castile soap and vinegar in separate steps instead.

**Baking soda (sodium bicarbonate).** A mild alkali and gentle abrasive. It deodorizes, scours softly, and boosts laundry. It is safe on most surfaces and cheap — typically under $1.50 per pound in bulk.

**Washing soda (sodium carbonate).** Baking soda's stronger cousin. It cuts grease powerfully and softens hard water, which makes it a laundry staple. It is more irritating to skin than baking soda, so wear gloves when handling it dry, and never use it undiluted on skin.

**White vinegar (5% acidity).** Dissolves limescale, soap scum, and mineral deposits, and cuts through hard-water film. It is not a disinfectant in the regulatory sense, and it should never be used on natural stone such as marble or granite, because acid etches stone. Never mix vinegar with bleach.

**Citric acid.** A powdered acid derived from citrus fruit. It is excellent for descaling kettles and dishwashers, for toilet bowl cleaning, and for adjusting the pH of a formulation. It stores well and is easy to weigh accurately.

**Rubbing alcohol (isopropyl, 70%) or vodka.** Helps glass cleaners evaporate cleanly, dissolves sticky residue, and gives a light disinfecting action on hard surfaces. Keep it away from open flame and store it sealed.

**Vegetable glycerin.** A humectant that keeps hand soaps from drying skin and helps liquid soaps feel smooth. A little goes a long way — 1 to 2 percent of a formulation is usually enough.

**Plant oils (olive, coconut, sweet almond, jojoba).** Used in melt-and-pour soap bases and in hand-care products. Coconut oil adds lather; olive oil adds mildness; sweet almond and jojoba add skin feel. Buy food-grade or cosmetic-grade oils from a reputable supplier and check the shelf life.

**Melt-and-pour soap base.** A pre-made soap base (goat milk, shea butter, or clear glycerin) that you melt, scent, color, and pour into molds. This is the safest way to make bar soap without handling lye, and it is what this manual's soap recipes use. If you later move to cold-process soap with lye, treat that as a separate, advanced skill with its own safety training.

**Essential oils.** Concentrated scent from plants. Common choices for household products: lavender, lemon, tea tree, eucalyptus, peppermint, sweet orange, rosemary, and lemongrass. Typical use is 0.5 to 2 percent of a formulation by weight. Some essential oils are not safe for young children (eucalyptus and rosemary are generally avoided for children under 6, and peppermint for children under 3), and several are toxic to cats (tea tree, citrus oils, lavender, and eucalyptus among them). Always research the specific oil, use the lowest effective amount, and note the risk on your label when a product contains essential oils.

**Distilled water.** Tap water contains minerals that feed bacteria and shorten shelf life. Use distilled water in every water-based formulation you intend to sell. It costs little and it is one of the cheapest quality upgrades you can make.

### 2.3 pH — the number that decides what a product can clean

pH measures acidity and alkalinity on a scale from 0 (very acidic) to 14 (very alkaline), with 7 neutral. Alkaline products (pH 9–11) cut grease; acidic products (pH 2–4) dissolve mineral deposits; near-neutral products (pH 6–8) are gentle on skin and most surfaces. A simple pack of pH test strips costs a few dollars and lets you check every batch. Record the pH in your formulation log. If a batch's pH is far from the recipe's target, do not sell it — find out why first. As a rule of thumb: hand soaps should sit near pH 8–10 for true soap or pH 5.5–7 for a syndet (synthetic detergent) hand wash; all-purpose cleaners work well around pH 9–10; glass cleaners around pH 7–8; and descalers around pH 2–3.

### 2.4 Preservation and shelf life

Water-based products can grow bacteria and mold. Commercial products use preservatives; natural makers manage the risk differently:

- Make small batches and sell them fresh. A two-to-four-week batch cycle is normal for a small maker.
- Use distilled water, clean equipment, and sealed containers.
- Keep the pH outside the range where most microbes thrive where the recipe allows it.
- Store products in a cool, dark place and print a "best used by" date on the label — three months from the making date is a reasonable default for most water-based cleaners in this manual, six months for oil-based or dry products such as laundry powder.
- If a product changes color, smell, or texture, or if you see mold, throw it away. Never sell a product you would not use yourself.

If you want a longer shelf life or you plan to wholesale, research broad-spectrum cosmetic preservatives and their safe use levels, or consult a cosmetic chemist. That is beyond the scope of this manual, and you should not improvise preservatives.

### 2.5 Scent — your signature

Scent is the single most powerful reason a customer repurchases a natural product. Develop two or three signature scent blends and use them consistently across your line so customers recognize your brand. A good starter set:

- **Fresh Kitchen:** lemon, rosemary, and a touch of peppermint.
- **Calm Home:** lavender, sweet orange, and cedarwood.
- **Clean Forest:** eucalyptus, tea tree, and pine or fir.

Blend essential oils in small test batches (10 drops total is enough to test a blend) and let the blend sit for 24 hours before judging it — scents change as they meld. Record the exact drops in your log so you can reproduce the blend. Never exceed 2 percent essential oil in a skin-contact product, and keep total essential oil at or below 1 percent in products for households with small children or pets unless you have verified the specific oils are safe.

### 2.6 Formulation method — the habit that prevents mistakes

Every formulation in Module 3 follows the same method:

1. Read the recipe and check you have every ingredient.
2. Weigh or measure everything before mixing.
3. Mix in the order given — order matters, especially when combining soap and acid.
4. Test pH where the recipe calls for it, and record it.
5. Pour into a clean, labeled container.
6. Use it yourself for at least a week before selling it.
7. Log the batch, the cost, and your observations.

If a batch fails — it separates, it smells wrong, it clogs a sprayer — write down what happened and what you changed. Failed batches are tuition; undocumented failures are wasted money.


---

## Module 3: The Formulation Library — 30 Tested Natural Household Products

Every formulation below follows the same layout: what it is, ingredients with amounts, method, yield, cost per unit, and safety notes. Costs are worked from typical 2026 US retail and bulk-supplier prices for small makers — for example, liquid castile soap around $0.35 per fluid ounce in a gallon jug, white vinegar around $0.04 per fluid ounce, baking soda around $0.08 per ounce, washing soda around $0.10 per ounce, and essential oils averaging $0.15 to $0.40 per drop depending on the oil. Your costs will differ by supplier and order size; Module 4 teaches you to replace these figures with your own. Always weigh ingredients on your scale. "Drops" are given for essential oils because makers measure them that way at small scale; 20 drops is roughly 1 milliliter.

A note on testing: these formulations were developed and refined through repeated small-batch making and household use. They are starting points, not guarantees. Your water, your suppliers, and your climate will change results slightly. Test every formulation yourself, adjust in small steps, and log what you change.

### 3A. Soaps and Hand Care (Formulations 1–5)

#### Formulation 1 — Gentle Lavender Hand Soap (liquid)

A mild, everyday liquid hand soap with a soft lavender scent. This is the product most makers sell first, because every household uses hand soap and customers repurchase it.

**Ingredients:** 1 cup (240 ml) distilled water; 1/4 cup (60 ml) liquid castile soap, unscented; 1 teaspoon (5 ml) vegetable glycerin; 1 teaspoon (5 ml) sweet almond oil; 15 drops lavender essential oil; 5 drops sweet orange essential oil.

**Method:** Warm the distilled water to lukewarm, not hot. Stir in the castile soap gently — do not shake or whisk hard, or you will create foam that takes hours to settle. Add the glycerin and sweet almond oil and stir. Add the essential oils, stir again, and pour into a clean pump bottle using a funnel. Let it rest for 24 hours before use so the scent melds.

**Yield:** About 10 fluid ounces (300 ml), one pump bottle. **Cost per unit:** about $1.15 (castile soap $0.55, glycerin $0.10, almond oil $0.15, essential oils $0.25, distilled water $0.10), plus bottle and label at about $0.85, for a total product cost near $2.00. A typical retail price is $8 to $10.

**Safety notes:** For external use on hands only. Patch-test before selling. Keep essential oil content at or below 1 percent for households with small children. If the soap thickens in cold weather, warm the bottle in warm water and shake gently.

#### Formulation 2 — Citrus Kitchen Hand Soap

A stronger hand soap for cooks, with lemon and rosemary to cut food smells such as garlic and onion from hands.

**Ingredients:** 1 cup (240 ml) distilled water; 1/3 cup (80 ml) liquid castile soap, unscented; 1 tablespoon (15 ml) vegetable glycerin; 12 drops lemon essential oil; 8 drops rosemary essential oil.

**Method:** Combine the water and castile soap gently in a bowl. Stir in the glycerin, then the essential oils. Pour into a pump bottle and rest for 24 hours.

**Yield:** About 11 fluid ounces (330 ml). **Cost per unit:** about $1.30 in ingredients, about $2.15 including bottle and label. Typical retail price $8 to $10.

**Safety notes:** Lemon essential oil can increase sun sensitivity on skin; this is a hand wash that is rinsed off, but do not leave it on skin in sunlight. Avoid rosemary oil in products for children under 6. Do not use on broken skin.

#### Formulation 3 — Oatmeal and Honey Melt-and-Pour Soap Bars

A gentle exfoliating bar made with a goat-milk melt-and-pour base — no lye handling required.

**Ingredients:** 1 pound (450 g) goat-milk melt-and-pour soap base; 2 tablespoons (30 ml) raw honey; 1/4 cup (25 g) finely ground oatmeal; 1 tablespoon (15 ml) sweet almond oil; 15 drops lavender essential oil; 5 drops cedarwood essential oil.

**Method:** Cut the soap base into cubes and melt in a double boiler or in short microwave bursts, stirring between each. Do not let it boil. Stir in the honey and almond oil, then the oatmeal, then the essential oils. Pour into silicone molds, spritz the surface lightly with rubbing alcohol to remove bubbles, and let the bars set for 4 to 6 hours. Unmold and cure on a rack for 48 hours before wrapping.

**Yield:** Four 4-ounce bars. **Cost per unit:** about $2.10 per bar (base $1.50, honey $0.20, oatmeal $0.10, oil and essential oils $0.30), plus wrap and label at about $0.60, for a total near $2.70 per bar. Typical retail price $7 to $9 per bar.

**Safety notes:** Honey can trigger allergies in rare cases; list it clearly on the label. Oatmeal provides gentle exfoliation — do not use on broken or irritated skin. Keep bars dry between uses so they last longer.

#### Formulation 4 — Charcoal Detox Bar Soap

A dark, striking bar with activated charcoal, popular at markets because it looks different from every other soap on the table.

**Ingredients:** 1 pound (450 g) clear glycerin melt-and-pour base; 1 tablespoon (7 g) activated charcoal powder; 1 tablespoon (15 ml) jojoba oil; 12 drops tea tree essential oil; 8 drops eucalyptus essential oil.

**Method:** Melt the base as in Formulation 3. Stir in the charcoal powder a little at a time until evenly black with no streaks. Add the jojoba oil and essential oils, pour into molds, spritz with rubbing alcohol, and set for 4 to 6 hours. Cure 48 hours before wrapping.

**Yield:** Four 4-ounce bars. **Cost per unit:** about $2.30 per bar in ingredients, about $2.90 including wrap and label. Typical retail price $8 to $10 per bar.

**Safety notes:** Charcoal stains light-colored washcloths and grout if the bar is left sitting in water — note this on the label. Avoid tea tree and eucalyptus oils in products for children under 6 and in households with cats. Wear gloves while handling charcoal powder; it stains hands and surfaces.

#### Formulation 5 — Foaming Hand Soap (refill-friendly)

A light foaming soap that uses less product per wash, which makes it a good refill product and a good first wholesale item.

**Ingredients:** 1 cup (240 ml) distilled water; 2 tablespoons (30 ml) liquid castile soap, unscented; 1 teaspoon (5 ml) vegetable glycerin; 10 drops sweet orange essential oil; 5 drops lemon essential oil.

**Method:** Combine the water and castile soap gently. Add the glycerin and essential oils. Pour into a foaming pump bottle — a regular pump bottle will not foam. Rest 24 hours before use.

**Yield:** About 9 fluid ounces (270 ml). **Cost per unit:** about $0.70 in ingredients, about $1.70 including the foaming bottle and label. Typical retail price $7 to $9.

**Safety notes:** Only use a foaming dispenser; the recipe is too thin for a standard pump. Label clearly as a foaming soap so customers do not think it is defective. Patch-test before selling.

### 3B. All-Purpose and Kitchen Cleaners (Formulations 6–12)

#### Formulation 6 — Everyday All-Purpose Spray

The workhorse of the line. Cleans counters, sinks, stovetops, and tables. The single most useful cleaner a maker can sell.

**Ingredients:** 2 cups (480 ml) distilled water; 1/4 cup (60 ml) white vinegar; 1 tablespoon (15 ml) liquid castile soap; 10 drops lemon essential oil; 5 drops tea tree essential oil.

**Method:** Add the water to a spray bottle first, then the vinegar, then the castile soap, then the essential oils. Shake gently. Note: this small amount of soap with vinegar will cloud slightly — that is normal and does not reduce cleaning power at this dilution. Label and date the bottle.

**Yield:** 16 fluid ounces (480 ml). **Cost per unit:** about $0.55 in ingredients, about $1.40 including spray bottle and label. Typical retail price $7 to $9.

**Safety notes:** Do not use on marble, granite, or other natural stone — vinegar etches stone. Do not use on waxed wood. Keep away from children and pets; tea tree oil is toxic to cats if ingested. Ventilate the room while cleaning.

#### Formulation 7 — Grease-Cutting Kitchen Degreaser

A stronger alkaline spray for stovetops, range hoods, and greasy backsplashes.

**Ingredients:** 2 cups (480 ml) hot distilled water; 2 tablespoons (30 g) washing soda; 1 tablespoon (15 ml) liquid castile soap; 10 drops lemon essential oil; 5 drops grapefruit essential oil.

**Method:** Dissolve the washing soda in the hot water, stirring until fully dissolved. Let it cool to lukewarm, then add the castile soap and essential oils. Pour into a spray bottle. Shake before each use.

**Yield:** 16 fluid ounces. **Cost per unit:** about $0.60 in ingredients, about $1.45 including bottle and label. Typical retail price $8 to $10.

**Safety notes:** Wear gloves — washing soda irritates skin. Do not use on aluminum surfaces, which washing soda can discolor. Do not use on natural stone. Label as a degreaser and keep out of reach of children.

#### Formulation 8 — Lemon Vinegar Cleaning Concentrate

A concentrate customers dilute at home. It ships light, costs little, and gives you a higher-margin product with a refill story.

**Ingredients:** 2 cups (480 ml) white vinegar; peels of 3 lemons; 10 drops lemon essential oil.

**Method:** Place the lemon peels in a clean glass jar and cover with vinegar. Seal and leave in a cool, dark place for two weeks, shaking every few days. Strain out the peels, add the essential oil, and bottle as concentrate. Label with dilution instructions: mix 1 part concentrate with 1 part water in a spray bottle.

**Yield:** About 16 fluid ounces of concentrate, which makes 32 fluid ounces of ready-to-use cleaner. **Cost per unit:** about $0.70 in ingredients (vinegar $0.60, lemon peels free if saved from cooking, essential oil $0.10), about $1.50 including bottle and label. Typical retail price $9 to $11 for the concentrate.

**Safety notes:** Do not use on natural stone. The concentrate is acidic; keep out of reach of children. Include dilution instructions on the label — selling a concentrate without instructions is a customer-service problem waiting to happen.

#### Formulation 9 — Baking Soda Scouring Paste

A gentle abrasive paste for sinks, tubs, and stovetops. One of the cheapest products in the line and one of the most satisfying to use.

**Ingredients:** 1 cup (220 g) baking soda; 1/4 cup (60 ml) liquid castile soap; 1 tablespoon (15 ml) water; 10 drops lemon essential oil.

**Method:** Mix the baking soda and castile soap in a bowl, adding water a teaspoon at a time until a thick paste forms. Stir in the essential oil. Spoon into a wide-mouth jar with a tight lid.

**Yield:** About 10 ounces (280 g). **Cost per unit:** about $0.65 in ingredients, about $1.35 including jar and label. Typical retail price $7 to $9.

**Safety notes:** Test on a hidden spot before use on fiberglass or acrylic tubs. Do not use on non-stick coatings. Keep the lid closed between uses so the paste does not dry out.

#### Formulation 10 — Dish Soap (liquid)

A liquid dish soap for hand-washing dishes. It will not foam as much as a commercial dish soap, and honest makers say so on the label — customers who know what to expect are happy customers.

**Ingredients:** 1 cup (240 ml) distilled water; 1/2 cup (120 ml) liquid castile soap; 1 tablespoon (15 ml) vegetable glycerin; 1 tablespoon (15 ml) white vinegar; 10 drops lemon essential oil; 5 drops sweet orange essential oil.

**Method:** Warm the water slightly. Stir in the castile soap gently, then the glycerin, then the vinegar, then the essential oils. Pour into a squeeze or pump bottle. Rest 24 hours before use. The mixture may cloud slightly; shake before use.

**Yield:** About 13 fluid ounces (390 ml). **Cost per unit:** about $1.35 in ingredients, about $2.20 including bottle and label. Typical retail price $9 to $11.

**Safety notes:** For dishes only, not for dishwashers. Rinse dishes thoroughly. Keep out of reach of children. Note on the label that it is low-foaming by design.

#### Formulation 11 — Dishwasher Powder

A dry powder for automatic dishwashers. Dry products have a long shelf life and low shipping weight, which makes them good online sellers.

**Ingredients:** 1 cup (220 g) washing soda; 1 cup (200 g) baking soda; 1/2 cup (100 g) citric acid; 1/2 cup (90 g) fine sea salt; 10 drops lemon essential oil (optional).

**Method:** Mix all dry ingredients in a large bowl, breaking up any lumps. Add essential oil if using and mix thoroughly. Store in a sealed jar with a scoop. Use 1 tablespoon per load.

**Yield:** About 3 cups (620 g), roughly 24 loads. **Cost per unit:** about $1.60 per jar in ingredients, about $2.30 including jar and label. Typical retail price $12 to $14 per jar.

**Safety notes:** Wear gloves and a mask when mixing dry powders — washing soda dust irritates lungs and skin. Do not use on aluminum or hand-painted dishes. Keep out of reach of children; the powder looks like food to a small child.

#### Formulation 12 — Stainless Steel and Appliance Polish

A spray-and-wipe polish for stainless steel appliances, faucets, and chrome.

**Ingredients:** 1 cup (240 ml) distilled water; 1/4 cup (60 ml) white vinegar; 1 tablespoon (15 ml) olive oil; 5 drops lemon essential oil.

**Method:** Combine all ingredients in a spray bottle and shake well before each use. Spray lightly onto a microfiber cloth, not directly onto the appliance, and wipe with the grain of the steel. Buff with a dry cloth.

**Yield:** About 9 fluid ounces (270 ml). **Cost per unit:** about $0.55 in ingredients, about $1.40 including bottle and label. Typical retail price $7 to $9.

**Safety notes:** Test on a hidden spot first. Do not use on natural stone. Olive oil can go rancid over time — give this product a three-month best-used-by date and store it away from heat.

### 3C. Laundry Care (Formulations 13–18)

#### Formulation 13 — Powder Laundry Detergent

The classic natural laundry powder. Cheap to make, easy to ship, and the product most likely to earn a repeat customer, because laundry is a weekly habit.

**Ingredients:** 2 cups (440 g) washing soda; 2 cups (440 g) baking soda; 1 cup (170 g) grated castile soap bar (grate a plain unscented bar finely); 1/2 cup (100 g) citric acid.

**Method:** Grate the soap bar with a fine cheese grater reserved for making. Mix all ingredients in a large bowl, breaking up lumps. Store in a sealed jar with a scoop. Use 2 tablespoons per standard load, 3 tablespoons for heavily soiled loads.

**Yield:** About 5 cups (1,050 g), roughly 40 loads. **Cost per unit:** about $2.60 per jar in ingredients, about $3.40 including jar and label. Typical retail price $14 to $16 per jar.

**Safety notes:** Wear gloves and a mask while mixing dry powders. Do not use on silk or wool — use a dedicated gentle wash for delicates. Keep out of reach of children. Note on the label that the detergent is low-sudsing, which is normal and safe for high-efficiency machines.

#### Formulation 14 — Liquid Laundry Detergent

A liquid option for customers who prefer pouring to scooping. It takes more work to make, so price it higher than the powder.

**Ingredients:** 4 cups (960 ml) hot distilled water; 1 cup (220 g) washing soda; 1/2 cup (100 g) baking soda; 1/3 cup (80 ml) liquid castile soap; 10 drops lavender essential oil.

**Method:** Dissolve the washing soda and baking soda in the hot water, stirring until fully dissolved. Let it cool, then stir in the castile soap and essential oil. Pour into a jug or large pump bottle. The liquid may thicken into a gel as it cools — shake or stir before each use.

**Yield:** About 32 fluid ounces (960 ml), roughly 16 loads at 2 fluid ounces per load. **Cost per unit:** about $1.90 in ingredients, about $2.90 including jug and label. Typical retail price $12 to $14.

**Safety notes:** Wear gloves when handling washing soda. Shake before use and use within three months. Keep out of reach of children. Label with the dose per load.

#### Formulation 15 — Fabric Softener (vinegar-based)

A simple rinse-cycle softener that also reduces static and softens hard water.

**Ingredients:** 2 cups (480 ml) white vinegar; 1 cup (240 ml) distilled water; 15 drops lavender essential oil; 5 drops sweet orange essential oil.

**Method:** Combine all ingredients in a bottle and shake. Use 1/2 cup per load in the rinse cycle or in the fabric-softener dispenser.

**Yield:** 24 fluid ounces (720 ml), roughly 6 loads per bottle at the rinse dose. **Cost per unit:** about $0.85 in ingredients, about $1.70 including bottle and label. Typical retail price $7 to $9.

**Safety notes:** Do not use on silk. The vinegar smell disappears as clothes dry — say so on the label, because first-time buyers worry about it. Keep out of reach of children.

#### Formulation 16 — Wool Dryer Balls (scented set of three)

Dryer balls reduce drying time and static without disposable sheets. They are a high-margin product because the material cost is low and the perceived value is high.

**Ingredients:** 100 percent wool roving or wool yarn, enough to make three balls about the size of a tennis ball; a pair of old tights or stockings; 5 drops lavender essential oil per ball (added by the customer at use, or pre-scented and sealed).

**Method:** Wind the wool into tight balls, tucking the end under. Place each ball in a section of the tights and tie off between balls. Wash in hot water and dry on high heat twice to felt the wool so it holds its shape. Remove from the tights, let the balls dry fully, and package in a set of three with a card explaining use: add 3 to 5 drops of essential oil to each ball, let it absorb, and toss in the dryer.

**Yield:** One set of three balls. **Cost per unit:** about $1.80 in materials (wool $1.50, packaging $0.30), about $2.60 including label, card, and bag. Typical retail price $12 to $15 per set.

**Safety notes:** Wool dryer balls are not for use with wool garments that require special care. Do not use essential oils on the balls if the household has a baby under 3 months or a cat that chews laundry items. Include the instructions on the card — the product fails without them.

#### Formulation 17 — Stain Treatment Stick

A solid stain stick for pre-treating collars, cuffs, and food stains before washing.

**Ingredients:** 1/2 cup (110 g) washing soda; 1/4 cup (60 ml) liquid castile soap; 2 tablespoons (30 ml) distilled water; 1 tablespoon (15 ml) vegetable glycerin; 10 drops lemon essential oil.

**Method:** Mix the washing soda and water into a paste. Stir in the castile soap, glycerin, and essential oil. Spoon into a push-up tube or a small jar. Let it set for 24 hours. To use, wet the stain, rub the stick over it, let it sit 15 minutes, and wash as normal.

**Yield:** About 6 ounces (170 g), one stick. **Cost per unit:** about $0.90 in ingredients, about $1.90 including tube and label. Typical retail price $7 to $9.

**Safety notes:** Wear gloves while making. Test on a hidden spot for delicate or brightly colored fabrics. Do not use on silk or wool. Keep out of reach of children.

#### Formulation 18 — Linen and Fabric Freshener Spray

A spray for bedding, curtains, upholstery, and clothes between washes. A strong seller at markets because customers can smell it immediately.

**Ingredients:** 2 cups (480 ml) distilled water; 2 tablespoons (30 ml) vodka or witch hazel; 15 drops lavender essential oil; 10 drops sweet orange essential oil; 5 drops cedarwood essential oil.

**Method:** Combine the water and vodka in a spray bottle, add the essential oils, and shake. Mist lightly over fabric from a distance of about 12 inches. Let it dry before use.

**Yield:** 16 fluid ounces. **Cost per unit:** about $0.95 in ingredients, about $1.80 including bottle and label. Typical retail price $8 to $10.

**Safety notes:** Test on a hidden spot for delicate fabrics. Do not spray on silk. Keep away from open flame — the product contains alcohol. Avoid use in a room with a baby under 3 months, and do not spray near cats, who are sensitive to essential oils.

### 3D. Bathroom and Disinfecting Cleaners (Formulations 19–24)

#### Formulation 19 — Toilet Bowl Cleaner

A thick, clinging cleaner that uses citric acid to dissolve mineral rings and hard-water stains.

**Ingredients:** 1 cup (200 g) baking soda; 1/2 cup (100 g) citric acid; 1/4 cup (60 ml) liquid castile soap; 15 drops tea tree essential oil; 10 drops lemon essential oil.

**Method:** Mix the dry ingredients in a bowl. Stir in the castile soap and essential oils to form a thick gel. Pour into a squeeze bottle with a narrow tip. To use, squeeze around the bowl, let it sit 15 minutes, scrub, and flush.

**Yield:** About 12 fluid ounces (350 ml). **Cost per unit:** about $1.15 in ingredients, about $2.00 including bottle and label. Typical retail price $8 to $10.

**Safety notes:** Wear gloves. Do not mix with bleach or any other cleaner. Ventilate the bathroom while cleaning. Keep out of reach of children. Do not claim on the label that the product kills germs or disinfects unless you have the regulatory approval to make that claim — describe it as a cleaner.

#### Formulation 20 — Tub and Tile Scrub

A paste scrub for soap scum, tub rings, and tile grout.

**Ingredients:** 1 cup (220 g) baking soda; 1/4 cup (60 ml) liquid castile soap; 2 tablespoons (30 ml) white vinegar; 10 drops eucalyptus essential oil; 5 drops tea tree essential oil.

**Method:** Mix the baking soda and castile soap into a paste. Add the vinegar slowly — it will fizz — and stir until the fizzing stops. Add the essential oils. Spoon into a wide-mouth jar. Apply with a sponge or old toothbrush, let it sit 10 minutes, scrub, and rinse.

**Yield:** About 10 ounces (280 g). **Cost per unit:** about $0.85 in ingredients, about $1.55 including jar and label. Typical retail price $8 to $10.

**Safety notes:** Wear gloves. Test on a hidden spot for acrylic or fiberglass tubs. Do not use on natural stone. Ventilate the bathroom. Keep away from children and pets; tea tree and eucalyptus oils are toxic to cats.

#### Formulation 21 — Daily Shower Spray

A light spray used after each shower to prevent soap scum and mildew buildup. It sells well as a companion to the tub scrub.

**Ingredients:** 2 cups (480 ml) distilled water; 1/2 cup (120 ml) white vinegar; 1 tablespoon (15 ml) rubbing alcohol; 10 drops tea tree essential oil; 5 drops eucalyptus essential oil.

**Method:** Combine all ingredients in a spray bottle and shake. Spray the shower walls and door after each use. No rinsing needed.

**Yield:** 16 fluid ounces. **Cost per unit:** about $0.70 in ingredients, about $1.55 including bottle and label. Typical retail price $7 to $9.

**Safety notes:** Do not use on natural stone. Ventilate the bathroom. Keep out of reach of children. Do not describe the product as preventing mold or killing mildew on the label unless you have the regulatory basis for that claim — say it "helps reduce soap scum buildup between deep cleans."

#### Formulation 22 — Mirror and Chrome Polish

A streak-free polish for mirrors, chrome fixtures, and glass shower doors.

**Ingredients:** 1 cup (240 ml) distilled water; 1/4 cup (60 ml) rubbing alcohol; 1 tablespoon (15 ml) white vinegar; 5 drops lemon essential oil.

**Method:** Combine all ingredients in a spray bottle and shake. Spray onto a microfiber cloth and wipe. Buff with a second dry cloth for a streak-free finish.

**Yield:** About 9 fluid ounces (270 ml). **Cost per unit:** about $0.50 in ingredients, about $1.35 including bottle and label. Typical retail price $7 to $9.

**Safety notes:** Keep away from open flame. Do not use on natural stone. Test on a hidden spot for specialty finishes such as oil-rubbed bronze.

#### Formulation 23 — Hand and Surface Wipes (reusable cloth kit)

A kit of reusable cloth wipes and a spray, sold together as a zero-waste cleaning kit.

**Ingredients:** Six cotton cloths, about 8 inches square, pre-washed; 1 spray bottle of Everyday All-Purpose Spray (Formulation 6).

**Method:** Cut or buy cotton cloths and hem the edges or use pinking shears to prevent fraying. Fold the cloths and package them with a full bottle of all-purpose spray and a card explaining the system: spray the surface, wipe with a cloth, rinse the cloth, and launder the cloths weekly. The kit replaces disposable wipes.

**Yield:** One kit (six cloths plus one spray bottle). **Cost per unit:** about $2.60 in materials (cloths $1.50, spray $1.10), about $3.40 including packaging and label. Typical retail price $16 to $18.

**Safety notes:** Tell customers to launder the cloths regularly and to use separate cloths for the kitchen and the bathroom. Include that instruction on the card — it is a hygiene issue, not just a tip.

#### Formulation 24 — Grout Cleaner (oxygen-based paste)

A paste for stained grout lines, using hydrogen peroxide as the active ingredient.

**Ingredients:** 1/2 cup (110 g) baking soda; 1/4 cup (60 ml) hydrogen peroxide, 3 percent solution (the standard drugstore strength); 1 tablespoon (15 ml) liquid castile soap.

**Method:** Mix the baking soda and hydrogen peroxide into a paste, then stir in the castile soap. Apply to grout with an old toothbrush, let it sit 15 minutes, scrub, and rinse thoroughly. Store in a dark, opaque bottle — hydrogen peroxide breaks down in light.

**Yield:** About 6 ounces (170 g). **Cost per unit:** about $0.70 in ingredients, about $1.50 including bottle and label. Typical retail price $8 to $10.

**Safety notes:** Wear gloves. Do not mix with vinegar or any other cleaner. Do not use on colored grout without testing on a hidden spot — hydrogen peroxide can lighten some grout colors. Keep out of reach of children. Give this product a three-month best-used-by date, because hydrogen peroxide loses strength over time.

### 3E. Glass, Floors, and Specialty Products (Formulations 25–30)

#### Formulation 25 — Streak-Free Glass Cleaner

The classic vinegar-and-alcohol glass cleaner. Simple, cheap, and effective — and a good demonstration product at markets, because customers can see the result in seconds.

**Ingredients:** 2 cups (480 ml) distilled water; 1/4 cup (60 ml) white vinegar; 1/4 cup (60 ml) rubbing alcohol; 1 tablespoon (15 ml) cornstarch; 5 drops lemon essential oil.

**Method:** Combine all ingredients in a spray bottle and shake well — the cornstarch settles, so shake before each use. Spray lightly onto glass and wipe with newspaper or a microfiber cloth. Buff with a dry cloth.

**Yield:** 16 fluid ounces. **Cost per unit:** about $0.60 in ingredients, about $1.45 including bottle and label. Typical retail price $7 to $9.

**Safety notes:** Keep away from open flame. Do not use on natural stone or tinted windows without testing first. The cornstarch helps prevent streaks but can leave a faint residue if over-applied — say so in the instructions.

#### Formulation 26 — Hardwood Floor Cleaner

A gentle, low-moisture cleaner for sealed hardwood floors.

**Ingredients:** 2 cups (480 ml) distilled water; 1/4 cup (60 ml) white vinegar; 1 tablespoon (15 ml) liquid castile soap; 5 drops sweet orange essential oil.

**Method:** Combine all ingredients in a spray bottle. Spray lightly onto a microfiber mop or cloth — never pour water directly onto a wood floor — and mop with the grain. Work in small sections and dry as you go.

**Yield:** 16 fluid ounces. **Cost per unit:** about $0.55 in ingredients, about $1.40 including bottle and label. Typical retail price $8 to $10.

**Safety notes:** Only for sealed hardwood floors. Never use on unsealed wood, waxed floors, or laminate without checking the manufacturer's guidance. Excess water damages wood — the instructions on the label must say to spray the mop, not the floor.

#### Formulation 27 — Carpet and Upholstery Deodorizer (dry powder)

A dry powder that is sprinkled on carpet, left to sit, and vacuumed up. It freshens without wetting the carpet.

**Ingredients:** 2 cups (440 g) baking soda; 1/2 cup (100 g) cornstarch; 15 drops lavender essential oil; 10 drops sweet orange essential oil.

**Method:** Mix the baking soda and cornstarch in a bowl. Add the essential oils a few drops at a time, breaking up clumps with a fork. Pour into a shaker jar with holes in the lid. To use, sprinkle lightly, wait 15 to 30 minutes, and vacuum thoroughly.

**Yield:** About 2.5 cups (540 g). **Cost per unit:** about $1.00 in ingredients, about $1.80 including shaker jar and label. Typical retail price $9 to $11.

**Safety notes:** Vacuum thoroughly — leftover powder can clog vacuum filters. Keep pets and children out of the room until the powder is vacuumed up, because essential oils in the powder are not safe for cats to walk through and lick off their paws. Do not use on wet carpet.

#### Formulation 28 — Room and Linen Spray (calm blend)

A water-based room spray with the "Calm Home" scent blend from Module 2.

**Ingredients:** 2 cups (480 ml) distilled water; 2 tablespoons (30 ml) vodka or witch hazel; 15 drops lavender essential oil; 10 drops sweet orange essential oil; 5 drops cedarwood essential oil.

**Method:** Combine the water and vodka in a spray bottle, add the essential oils, and shake. Mist into the air away from faces, or onto linens from a distance of about 12 inches.

**Yield:** 16 fluid ounces. **Cost per unit:** about $0.95 in ingredients, about $1.80 including bottle and label. Typical retail price $8 to $10.

**Safety notes:** Do not spray toward faces or in a room with a baby under 3 months. Keep away from open flame. Do not spray on silk. Note the essential oil content on the label for pet owners.

#### Formulation 29 — Wood Furniture Polish

A simple oil-and-vinegar polish for finished wood furniture.

**Ingredients:** 1/2 cup (120 ml) olive oil; 1/4 cup (60 ml) white vinegar; 10 drops lemon essential oil.

**Method:** Combine all ingredients in a small bottle and shake well before each use. Apply a small amount to a soft cloth and rub into the wood with the grain. Buff with a clean, dry cloth. A little goes a long way — one bottle lasts a household months.

**Yield:** About 6 fluid ounces (180 ml). **Cost per unit:** about $0.85 in ingredients, about $1.65 including bottle and label. Typical retail price $9 to $11.

**Safety notes:** Test on a hidden spot first. Do not use on unfinished wood. Olive oil can go rancid — give this product a three-month best-used-by date and store it away from heat and light.

#### Formulation 30 — Pet-Safe Floor Cleaner (no essential oils)

A floor cleaner made without essential oils, for households with cats, dogs, or small children. This is the product to recommend whenever a customer says they have pets.

**Ingredients:** 2 cups (480 ml) distilled water; 1/4 cup (60 ml) white vinegar; 1 tablespoon (15 ml) liquid castile soap, unscented.

**Method:** Combine all ingredients in a spray bottle or jug. For mopping, add 1/4 cup of the mixture to a bucket of warm water. Mop and let the floor dry before pets walk on it.

**Yield:** 16 fluid ounces of concentrate, enough for about 8 mop buckets. **Cost per unit:** about $0.45 in ingredients, about $1.30 including bottle and label. Typical retail price $7 to $9.

**Safety notes:** This formulation contains no essential oils by design — that is the selling point, and it should be stated clearly on the label. Do not use on natural stone or unsealed wood. Even without essential oils, keep pets off wet floors until they are dry.

---

## Module 4: Costing — Know What Every Product Really Costs

### 4.1 Why makers lose money without costing

Most makers price by feeling: they look at a competitor's bottle, pick a number that seems fair, and hope. That is how a maker sells $400 of product at a market and discovers, weeks later, that the ingredients, bottles, labels, market fee, and platform fees ate $380 of it. Costing is the cure. It takes fifteen minutes per product, and it turns hope into arithmetic.

### 4.2 The five cost buckets

Every product has five cost buckets. Miss one and your margin is fiction.

1. **Ingredients.** Everything that goes into the product, weighed and priced per batch. Use your actual supplier prices, not the prices in this manual.
2. **Container and packaging.** Bottle, jar, pump, cap, shrink wrap, and the box or bag it goes home in.
3. **Label.** The printed label, including ink and paper if you print at home, or the per-label price from your printer.
4. **Fees.** The market stall fee divided by the number of units you expect to sell, or the online platform fee per sale (Etsy charges a listing fee, a transaction fee, and a payment-processing fee — see Module 5).
5. **Your time.** Your time is a real cost even if you do not pay yourself yet. Track it, value it, and build toward paying it. A product that takes an hour to make and earns $3 of profit is a hobby, not a business.

### 4.3 How to cost a batch — worked example

Take Formulation 6, the Everyday All-Purpose Spray. Suppose you make a batch of 10 bottles.

- Ingredients per bottle: $0.55, so $5.50 for the batch.
- Spray bottles: $0.65 each, so $6.50.
- Labels: $0.20 each, so $2.00.
- Total product cost for the batch: $14.00, or $1.40 per bottle.
- Market fee: a $50 stall fee, and you expect to sell 40 units across your line that day. Allocate $1.25 of the stall fee to each unit sold.
- Full cost per bottle at the market: $1.40 plus $1.25, or $2.65.

If you sell that bottle for $8.00, your gross profit is $5.35 per bottle, a gross margin of about 67 percent. That is a healthy product. If you sell it for $5.00, your profit is $2.35, a margin of 47 percent — thin, and it leaves no room for a discount or a slow day. The costing worksheet in the workbook walks you through this for each of your products, and the product-costing calculator in the templates folder does the arithmetic for you.

### 4.4 Buying ingredients well

Buy the ingredients you use most in the largest size you can store and use before they expire. A gallon of liquid castile soap costs roughly half as much per ounce as a 16-ounce bottle. White vinegar, baking soda, and washing soda are cheapest in bulk from warehouse or restaurant-supply stores. Essential oils are the exception: buy small bottles from a reputable supplier, because they lose potency and can go rancid, and a large bottle of a rarely used oil is wasted money.

Compare suppliers on the delivered cost per unit, not the sticker price. A supplier with a $4.00 bottle and $9.00 shipping is more expensive than a supplier with a $5.00 bottle and free shipping on orders over $35. Keep a supplier sheet with the delivered cost per ounce or per gram for each ingredient, and update it when prices change.

### 4.5 Waste and shrinkage

Not every batch sells. Some bottles leak, some labels smudge, some products expire before they sell. Build a waste allowance of 5 percent into your costing — add 5 percent to your total cost per unit. If your waste is lower than 5 percent, that is profit. If you ignore waste, your first spoiled batch will erase the profit of the next three good ones.

---

## Module 5: Pricing for Profit — Margins, Channels, and Real Numbers

### 5.1 The pricing formula

Start with your full cost per unit from Module 4. Then choose a target gross margin. For handmade household products sold direct to customers, a gross margin of 55 to 70 percent is realistic and necessary. The formula is:

**Price = Full cost per unit ÷ (1 − target margin)**

Worked example: the all-purpose spray costs $2.65 per unit at a market, and you want a 65 percent margin. Price = $2.65 ÷ (1 − 0.65) = $2.65 ÷ 0.35 = $7.57. Round to $8.00. That is your market price.

For the oatmeal and honey soap bar, the full cost is about $2.70 per bar plus $1.25 of allocated market fee, or $3.95. At a 60 percent margin: $3.95 ÷ 0.40 = $9.88, so price it at $10.00.

### 5.2 Pricing by channel

The same product has a different price on Etsy than at a market, because the fees differ. Etsy charges a $0.20 listing fee per listing, a transaction fee of 6.5 percent of the sale price including shipping charged to the buyer, and a payment-processing fee of 3 percent plus $0.25 per transaction. On an $8.00 sale with $4.00 shipping charged to the buyer, Etsy takes roughly $1.03 in transaction and processing fees plus the $0.20 listing fee — about $1.23, or about 15 percent of the sale. Your $8.00 market bottle needs to sell for about $9.50 on Etsy to earn the same profit. Build the fee into the price; do not absorb it and hope volume makes up the difference.

Wholesale is a different calculation again. A shop that stocks your product will typically pay 50 percent of your retail price. If your retail price is $8.00, wholesale is $4.00. Your full cost must be well under $4.00 for wholesale to work — and for the all-purpose spray at $1.40 product cost, it does, leaving $2.60 per unit before your time. But wholesale also means larger batches, consistent supply, and professional packaging. Do not offer wholesale until your costing is solid and your production is reliable.

### 5.3 Bundles and sets

Bundles raise the average order value and move slower products. A "Kitchen Starter Set" — all-purpose spray, dish soap, and a scouring paste — costs about $4.60 in product and packaging and sells for $22 to $24, where the three items bought separately would cost $25 to $27. The customer saves a little, you sell three products in one transaction, and your margin stays above 60 percent. A "Laundry Set" — powder detergent, fabric softener, and dryer balls — works the same way. Price the bundle so the discount is real but small: 8 to 12 percent off the separate prices is enough.

### 5.4 Discounts and sales — the rules

Never discount a single product below your break-even price, and never run a sale so often that customers learn to wait for it. Two safe discount rules: first, a bundle discount of 10 percent is safe when your margin is above 60 percent. Second, a market-day "buy three, get the cheapest free" offer works when your cheapest product still earns its margin on the other two sales. A 20 percent store-wide sale is not safe on a product with a 55 percent margin — it cuts your margin to 44 percent and teaches customers that your real price is the sale price.

### 5.5 What not to do

Do not price below your cost to "get your name out." A customer who buys because you are cheap will leave when you raise the price, and you will have trained your market to expect unsustainable prices. Do not copy a competitor's price without knowing their costs — a large maker buying in bulk has costs you do not, and a hobbyist selling at a loss is not a competitor. And do not raise prices silently and often; raise them once, clearly, when your costs rise or your line improves, and tell your customers why.

### 5.6 A realistic first-season profit picture

Suppose you sell at one market a month and online in between, and you average 60 units a month at an average price of $9.00. That is $540 in monthly revenue. If your average full cost per unit is $3.00, your gross profit is $360 a month before your market fees, packaging extras, and your own time. That is a solid start for a part-time maker. It is not a full-time income, and anyone who tells you it will be in the first season is not being honest with you. Growth comes from repeat customers, from adding a second market, and from a product that earns its own word of mouth — usually the hand soap or the laundry powder, because those are the products people use every day.

---

## Module 6: Labeling and Compliance — What Goes on the Bottle

### 6.1 Why labels matter more than makers think

A label is three things at once: a legal document, a safety tool, and your best salesperson. It tells a customer what the product is, what is in it, how to use it, and who made it. It tells a regulator that you are a serious maker. And it tells a buyer at a crowded market table, in three seconds, whether your product is worth picking up. Spend real time on your labels. They are not an afterthought.

**This module is general education about how labeling commonly works in the United States. It is not legal advice. Rules differ by product type, by state, and by sales channel, and they change. Verify the current rules for your products and your location before you sell, and consult a local attorney or your small-business development center when you are unsure.**

### 6.2 What every label needs

Whatever the product type, every label you sell should carry:

- **Product identity.** What the product is, in plain language: "All-Purpose Cleaner," "Lavender Hand Soap," "Powder Laundry Detergent."
- **Net quantity.** How much is in the container — fluid ounces and milliliters for liquids, ounces and grams for solids. Put it on the front, in the lower third of the label.
- **Your business name and address.** Your business name and a way to reach you — a city and state at minimum, and a website or email address. Customers need to find you, and regulators need to know who made the product.
- **Directions for use.** How much to use, how to apply it, and what to use it on.
- **Ingredient list.** List ingredients in descending order of predominance (most to least). Use common names a customer can understand, with the scientific name in parentheses where it helps.
- **Warnings and cautions.** Keep out of reach of children. For external use only. Any surface or material the product should not be used on.
- **Batch number and best-used-by date.** So you can trace a product if a customer reports a problem, and so customers know when to use it.
- **Allergen and essential-oil notes.** If a product contains a common allergen (honey, nut oils, wheat) or essential oils, say so plainly.

### 6.3 The categories, in plain language

**True soap.** In the United States, a product is legally a "soap" only if it is made mostly from an alkali salt of a fatty acid (the traditional definition of soap), it cleans, and it makes no cosmetic or drug claim beyond cleansing. A true soap bar is regulated as a soap, not a cosmetic, and its labeling is simpler. But the moment you claim your soap "moisturizes," "soothes eczema," or "heals skin," it becomes a cosmetic or a drug in the eyes of the regulator, and the rules change. Keep your claims to cleansing.

**Cosmetics.** Liquid hand soap, body wash, and anything you describe as beautifying or cleansing the skin is generally a cosmetic. Cosmetic labels in the United States must carry the product identity, net quantity, ingredient list in descending order, and the name and address of the manufacturer or distributor. Cosmetics do not need pre-market approval, but they must be safe, honestly labeled, and made in sanitary conditions.

**Household cleaners.** All-purpose sprays, glass cleaners, and floor cleaners are household products. Their labels need identity, quantity, directions, ingredients or a way to find them, and warnings. The critical line is the germ-killing claim: any claim that a product kills germs, disinfects, sanitizes, or prevents mold makes it a pesticide under US law, regulated by the Environmental Protection Agency, and it requires registration and specific testing. Do not make those claims unless you have gone through that process. Say "cleans," "degreases," "removes soap scum," and "freshens" instead.

**Laundry products.** Laundry detergent and fabric softener are household products. List the ingredients, give the dose per load, and warn that the product is not for use on silk or wool where that applies. If you sell a product for a septic system, do not claim it is septic-safe unless you have a basis for the claim.

### 6.4 Claims — the words that get makers in trouble

The safest claims are the ones that describe what the product does, not what it does to the body:

- Safe: "Cleans kitchen counters." "Cuts grease." "Leaves glass streak-free." "Gentle on hands." "Lightly scented with lavender essential oil."
- Risky: "Kills 99.9 percent of germs." "Disinfects." "Antibacterial." "Heals dry skin." "Treats eczema." "Allergy-free." "Chemical-free" (everything is made of chemicals, including water — this claim is meaningless and invites a complaint).
- Never: "Cures," "treats," "prevents disease," or any claim that a product will change the structure or function of the body.

When a customer asks whether your product will help their eczema or their child's rash, the honest answer is: "This is a gentle soap made with simple ingredients, and many customers with sensitive skin like it — but I cannot make health claims, and you should check with your doctor." That answer protects you and builds trust.

### 6.5 A label template that works

Front of the bottle: your brand name, the product name, the scent, and the net quantity. Back of the bottle: directions for use, the full ingredient list, warnings, your business name and contact, the batch number, and the best-used-by date. Use a readable font — at least 1/16 inch tall for required information — and a color contrast that can be read in a dim market hall. Print a test label, stick it on a bottle, and read it from arm's length. If you cannot read it, your customer cannot either.

### 6.6 Record-keeping

Keep a file for every product: the formulation, the supplier and lot number for each ingredient, the batch numbers and dates, and a copy of the label. Keep it for at least two years after the last sale of that batch. If a customer reports a reaction or a problem, you will be able to answer exactly what was in the product and when it was made. That record is also the first thing a regulator or an insurer will ask for. Good records are the cheapest insurance a maker can buy.

---

## Module 7: Packaging — Containers, Suppliers, and Sustainability

### 7.1 Choose the container for the product, not the other way around

Each formulation needs a container that suits it:

- **Spray cleaners:** a sturdy PET plastic or glass spray bottle with a fine-mist trigger. Cheap triggers clog and leak; spend the extra $0.20 on a good one.
- **Hand soap:** a pump bottle, or a foaming pump for Formulation 5. Test the pump with your actual soap before ordering in bulk — thick soaps jam cheap pumps.
- **Powders:** a wide-mouth jar with a tight lid and a scoop. Moisture is the enemy; a jar that seals properly is worth more than a pretty jar that does not.
- **Bars:** a paper wrap or a small box that lets the bar breathe. Shrink wrap traps moisture and can make a bar sweat.
- **Oils and polishes:** amber glass, which protects the contents from light.

### 7.2 What packaging costs

Budget roughly $0.60 to $1.00 per unit for a spray bottle, $0.80 to $1.20 for a pump bottle, $0.50 to $0.90 for a jar, and $0.15 to $0.25 for a label. Buying in cases of 50 or 100 typically cuts the per-unit price by 20 to 40 percent compared with buying ten at a time. Do not order a thousand bottles of a product you have not sold yet. Order for the next two months, not the next two years.

### 7.3 Finding suppliers

Good sources for small makers include packaging wholesalers that sell in cases, soap-making suppliers that carry bottles and jars alongside ingredients, and restaurant-supply stores for bulk vinegar, baking soda, and washing soda. Compare the delivered cost per unit, including shipping, and order a sample before committing. Ask suppliers for their minimum order quantities, their shipping times, and whether they offer a discount for a first order. Keep a supplier sheet with at least two sources for every critical item, so a stockout at one supplier does not stop your production.

### 7.4 Sustainability — honest, not performative

Customers buy natural products partly because they care about waste. Make packaging choices you can honestly describe:

- Offer refills. A customer who brings back a bottle gets a discount of $1.00 or 10 percent, and you save the cost of a new bottle. Refills are the single most effective sustainability step a small maker can take, and they bring customers back to your table.
- Use glass where it makes sense, and say why. Glass is reusable and recyclable, but it is heavy to ship and it breaks. PET plastic is lighter and safer for a product used around a bathtub. Explain your choice on your website or market sign; customers respect a reasoned choice more than a slogan.
- Keep packaging minimal. One label, one bottle, no extra box. A small kraft tag tied with string is enough for a soap bar.
- Never claim a product is "zero waste" or "100 percent biodegradable" unless you can prove it. Say what is true: "Bottle is refillable," "Label is printed on recycled paper," "Ingredients are plant-based." Specific claims are credible; grand claims invite skepticism.

### 7.5 The unboxing and the market table

If you sell online, the package is the first thing a customer touches. Use a sturdy box, paper padding rather than plastic, a hand-written thank-you note, and a small sample of another product. The sample costs you under $1.00 and is the cheapest way to sell a second product. At a market, your table is your packaging: a clean cloth, products at eye level, one open bottle of each product for smelling and testing, a clear price sign, and a small sign that says what your products are free from and what they contain. Keep the table simple — a crowded table confuses buyers.

---

## Module 8: Selling — Etsy, Markets, Your Own Shop, and Your First 90 Days

### 8.1 Start with one channel, not three

New makers try to be everywhere at once and end up nowhere. Pick one channel for your first month — either one local market or one online shop — and learn it properly before adding a second. Your first channel teaches you which products sell, what customers ask, and what your real costs are. Those lessons are worth more than being listed in three places with no sales in any of them.

### 8.2 Selling on Etsy

Etsy is the natural first online home for handmade household products, because its buyers already expect handmade goods and are willing to pay for them.

- **Your shop.** Choose a shop name that matches your brand and is easy to spell. Write a shop description that says who you are, what you make, and why it is natural. Use a clear photo of yourself or your workspace — buyers on Etsy buy from people.
- **Listings.** Each listing needs a clear title that a buyer would actually search for ("Lavender Liquid Hand Soap, Natural, 10 oz" beats "Lovely Lavender Soap!!!"), at least five photos, and a description that answers the buyer's questions: what it is, what is in it, how to use it, how big it is, and how it ships. Use all 13 tags Etsy allows, with search terms buyers use.
- **Photos.** Photograph products in natural daylight, on a plain background, with the label readable. Include a photo of the product in use — hands washing, a clean counter — because buyers imagine themselves using it.
- **Pricing and fees.** Remember Module 5: Etsy takes a $0.20 listing fee, 6.5 percent transaction fee, and 3 percent plus $0.25 payment processing. Price your Etsy listings higher than your market prices to cover those fees, and be transparent about shipping costs.
- **Customer service.** Answer messages within 24 hours. Ship within the processing time you promised, with tracking. If something arrives damaged, replace it without argument — one replacement costs less than one bad review.

### 8.3 Selling at markets

A market stall is the fastest way to learn what sells, because you watch customers pick products up and put them down.

- **Choose the right market.** A farmers market or a handmade-goods market is a better fit than a general flea market. Visit first as a customer and watch who buys cleaning products.
- **Your stall.** A clean tablecloth, a simple sign with your brand name, products arranged by family (soaps together, cleaners together), a test bottle of each product, and a clear price list. Bring a card reader — most customers pay by card now.
- **Talking to customers.** Let people smell and touch the products. Ask what they are looking for rather than reciting your whole line. When someone buys hand soap, mention the matching dish soap. When someone buys laundry powder, mention the dryer balls. That is not pushy; it is helpful, and it raises your average sale.
- **The numbers.** A $50 stall fee means you need to sell about $150 of product at a 65 percent margin just to cover the fee and your product costs. Track every market day: revenue, units sold, best seller, and what customers asked for. After three markets, the pattern will tell you what to make more of and what to drop.

### 8.4 Selling from your own website or social media

Once you have repeat customers, a simple shop of your own — through a platform such as Shopify, Square, or a marketplace storefront — lets you keep the fees you were paying Etsy and build an email list. Start an email list early: a simple signup sheet at your market table and a signup form on your shop. An email list of 200 customers who have bought from you is worth more than 2,000 social media followers who have not. Send one email a month: what is new, what is back in stock, and one useful tip. Do not email weekly; you will be unsubscribed.

### 8.5 Your first 90 days

**Days 1–30: Make and test.** Set up your workspace, make five products for your own household, cost all five, and design your labels. Pick your first sales channel and set a launch date.

**Days 31–60: Launch small.** List five products on your chosen channel or book your first market. Sell, listen, and record everything. Fix the label that confuses people. Fix the pump that jams. Adjust the price of the product that sells out in an hour — it is priced too low.

**Days 61–90: Learn and decide.** Look at your numbers: which three products earn the most profit, which product gets the most questions, and which product never sells. Drop the product that never sells. Make more of the product that earns the most. Decide whether to add a second channel, and set a goal for the next 90 days — a realistic one, such as adding one new product or booking a second monthly market.

### 8.6 Growing without losing quality

Growth in a maker business usually means one of three things: more products, more sales channels, or wholesale. Each one has a cost. More products means more ingredients to stock and more labels to manage. More channels means more fees and more customer service. Wholesale means larger batches and thinner margins per unit. Grow one step at a time, and only when your costing shows the step is profitable. The maker who sells 200 units a month at a 65 percent margin is in a stronger business than the maker who sells 1,000 units a month at a 20 percent margin and cannot keep up.

### 8.7 A final word

You now have thirty formulations, a costing method, a pricing formula, a labeling framework, a packaging plan, and a selling plan. None of it works without the part only you can do: making the first batch, using it yourself, and putting it in front of a customer. Start with one product, one batch, one sale. Then do it again. That is how a maker business is built — one honest product at a time.

---

## Appendix: Quick-Reference Cost and Price Table

| Product | Ingredients | Bottle/label | Total cost | Typical price |
|---|---|---|---|---|
| 1. Lavender Hand Soap | $1.15 | $0.85 | $2.00 | $8–$10 |
| 2. Citrus Kitchen Hand Soap | $1.30 | $0.85 | $2.15 | $8–$10 |
| 3. Oatmeal & Honey Soap Bar | $2.10 | $0.60 | $2.70 | $7–$9 |
| 4. Charcoal Detox Bar | $2.30 | $0.60 | $2.90 | $8–$10 |
| 5. Foaming Hand Soap | $0.70 | $1.00 | $1.70 | $7–$9 |
| 6. All-Purpose Spray | $0.55 | $0.85 | $1.40 | $7–$9 |
| 7. Kitchen Degreaser | $0.60 | $0.85 | $1.45 | $8–$10 |
| 8. Lemon Vinegar Concentrate | $0.70 | $0.80 | $1.50 | $9–$11 |
| 9. Baking Soda Scouring Paste | $0.65 | $0.70 | $1.35 | $7–$9 |
| 10. Dish Soap | $1.35 | $0.85 | $2.20 | $9–$11 |
| 11. Dishwasher Powder | $1.60 | $0.70 | $2.30 | $12–$14 |
| 12. Stainless Steel Polish | $0.55 | $0.85 | $1.40 | $7–$9 |
| 13. Powder Laundry Detergent | $2.60 | $0.80 | $3.40 | $14–$16 |
| 14. Liquid Laundry Detergent | $1.90 | $1.00 | $2.90 | $12–$14 |
| 15. Fabric Softener | $0.85 | $0.85 | $1.70 | $7–$9 |
| 16. Wool Dryer Balls (set of 3) | $1.80 | $0.80 | $2.60 | $12–$15 |
| 17. Stain Treatment Stick | $0.90 | $1.00 | $1.90 | $7–$9 |
| 18. Linen & Fabric Freshener | $0.95 | $0.85 | $1.80 | $8–$10 |
| 19. Toilet Bowl Cleaner | $1.15 | $0.85 | $2.00 | $8–$10 |
| 20. Tub & Tile Scrub | $0.85 | $0.70 | $1.55 | $8–$10 |
| 21. Daily Shower Spray | $0.70 | $0.85 | $1.55 | $7–$9 |
| 22. Mirror & Chrome Polish | $0.50 | $0.85 | $1.35 | $7–$9 |
| 23. Reusable Wipes Kit | $2.60 | $0.80 | $3.40 | $16–$18 |
| 24. Grout Cleaner Paste | $0.70 | $0.80 | $1.50 | $8–$10 |
| 25. Glass Cleaner | $0.60 | $0.85 | $1.45 | $7–$9 |
| 26. Hardwood Floor Cleaner | $0.55 | $0.85 | $1.40 | $8–$10 |
| 27. Carpet Deodorizer | $1.00 | $0.80 | $1.80 | $9–$11 |
| 28. Room & Linen Spray | $0.95 | $0.85 | $1.80 | $8–$10 |
| 29. Wood Furniture Polish | $0.85 | $0.80 | $1.65 | $9–$11 |
| 30. Pet-Safe Floor Cleaner | $0.45 | $0.85 | $1.30 | $7–$9 |

Costs in this table are ingredient and packaging costs per unit before market or platform fees. Your costs will differ by supplier and order size. Use the costing worksheet in the workbook and the calculator in the templates folder to work out your own numbers.

---

*The Eco Home Product Workshop — GRN-05. This manual is general education, not legal, medical, or financial advice. Verify your local labeling and safety rules before selling. Results depend on your market, your location, and your effort.*
