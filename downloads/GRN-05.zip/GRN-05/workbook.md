# The Eco Home Product Workshop — Companion Workbook

## How to Use This Workbook

Work through one module at a time, alongside the course manual (`content.md`). Print the worksheets you need at your workbench, or copy them into a notebook or spreadsheet. The goal is not to fill in blanks — it is to make real decisions about real products, with your own numbers.

**Safety reminder:** The formulations in the course are for external household use only. Wear gloves and eye protection when handling washing soda, citric acid in bulk, alcohol, or concentrated soap. Work in a ventilated area. Keep essential oils and finished products out of reach of children, and remember that several essential oils are unsafe for young children and toxic to cats and dogs. Patch-test any product meant for skin contact before selling it. The labeling guidance in the course is general education, not legal advice — verify your local rules before you sell.

---

## Module 1 Exercises — Foundations and Workspace

### Exercise 1.1 — Your "why" and your first five products

Write one sentence for each:

- Why I want to sell natural household products: ______________________________
- The customers I most want to serve: ______________________________
- What success looks like in 90 days: ______________________________

Now choose the five products you will start with (pick from the thirty formulations in Module 3). Write them here, with one reason each:

1. Product: ______________ Reason: ______________
2. Product: ______________ Reason: ______________
3. Product: ______________ Reason: ______________
4. Product: ______________ Reason: ______________
5. Product: ______________ Reason: ______________

### Exercise 1.2 — Workspace and safety checklist

Check off each item as you complete it:

- [ ] Dedicated making surface, cleaned and cleared
- [ ] Making-only measuring cups, bowls, funnel, and whisk, labeled "MAKING ONLY"
- [ ] Digital kitchen scale (grams)
- [ ] Nitrile gloves, safety glasses, apron
- [ ] Thermometer
- [ ] Base pantry stocked (castile soap, baking soda, washing soda, citric acid, white vinegar, distilled water)
- [ ] Ingredients stored in labeled containers with purchase dates
- [ ] Essential oils in dark amber glass, caps tight, out of reach of children and pets
- [ ] Poison control number posted in the workspace: ______________
- [ ] Doctor's number posted: ______________
- [ ] Veterinarian's number posted: ______________
- [ ] First batch of three test products made and logged (see Exercise 3.1)

---

## Module 2 Exercises — Formulation Science

### Exercise 2.1 — Your signature scent blends

Blend and test three scent combinations (10 drops total each). Let each blend sit 24 hours, then rate it and note where you would use it.

| Blend name | Oils and drops | Smell after 24h (1–5) | Best use |
|---|---|---|---|
| | | | |
| | | | |
| | | | |

### Exercise 2.2 — pH testing practice

Test the pH of three products you made. Record the result and whether it matches the expected range from Module 2.

| Product | Expected pH | Measured pH | Action if off-target |
|---|---|---|---|
| | | | |
| | | | |
| | | | |

---

## Module 3 Exercises — Formulation Log

### Exercise 3.1 — Formulation log (copy this sheet for every batch)

- Product name and formulation number: ______________________________
- Date made: ______________ Batch number: ______________
- Batch size (units): ______________
- Ingredients used (with supplier and lot number):
  - ______________________________
  - ______________________________
  - ______________________________
- pH measured: ______________
- Observations (texture, scent, color, problems): ______________________________
- Changes for next time: ______________________________
- Patch test / surface test result: ______________________________
- Cost per unit (from Module 4 worksheet): $______________
- Best-used-by date: ______________

### Exercise 3.2 — Your test week

Use each of your first five products yourself for one week. Record one honest sentence per product: what worked, what did not, and what you changed.

1. ______________________________
2. ______________________________
3. ______________________________
4. ______________________________
5. ______________________________

---

## Module 4 Exercises — Costing Worksheet

### Exercise 4.1 — Costing worksheet (copy for each product)

Product: ______________________________ Batch size: ______________ units

| Cost item | Per batch | Per unit |
|---|---|---|
| Ingredients (list each below) | $ | $ |
| Container / bottle / jar | $ | $ |
| Pump, cap, or trigger | $ | $ |
| Label | $ | $ |
| Box, bag, or wrap | $ | $ |
| **Product cost subtotal** | **$** | **$** |
| Waste allowance (5%) | $ | $ |
| Market or platform fee allocated per unit | $ | $ |
| **FULL COST PER UNIT** | | **$** |

Ingredient detail:

| Ingredient | Amount per batch | Supplier price | Cost per batch |
|---|---|---|---|
| | | | $ |
| | | | $ |
| | | | $ |
| | | | $ |

My time: ______ minutes per batch. At $______ per hour, that is $______ per batch, or $______ per unit. (Track it now; build toward paying it.)

---

## Module 5 Exercises — Pricing Worksheet

### Exercise 5.1 — Pricing worksheet (copy for each product)

Product: ______________________________ Full cost per unit: $______________

| Channel | Fee per unit | Target margin | Price = cost ÷ (1 − margin) | Rounded price |
|---|---|---|---|---|
| Local market | $ | % | $ | $ |
| Etsy | $ | % | $ | $ |
| Own website | $ | % | $ | $ |
| Wholesale (50% of retail) | — | % | $ | $ |

Is wholesale viable for this product? (Wholesale price must be comfortably above full cost.) Yes / No — why: ______________________________

### Exercise 5.2 — Bundle planner

Bundle name: ______________________________

| Product in bundle | Separate price | Cost |
|---|---|---|
| | $ | $ |
| | $ | $ |
| | $ | $ |
| **Totals** | **$** | **$** |

Bundle price: $______________ Discount vs. separate prices: ______________% Margin on bundle: ______________%

---

## Module 6 Exercises — Label Checklist

### Exercise 6.1 — Label checklist (complete for each product before selling)

Use the full labeling compliance checklist in `templates/labeling-compliance-checklist.md`. Summarize the result here:

Product: ______________________________

- [ ] Product identity on front
- [ ] Net quantity (front, lower third)
- [ ] Business name and address/contact
- [ ] Directions for use
- [ ] Full ingredient list, descending order
- [ ] Warnings (children, external use, surfaces to avoid)
- [ ] Allergen / essential-oil note
- [ ] Batch number and best-used-by date
- [ ] No germ-killing, disinfecting, or health claims unless approved
- [ ] Label read from arm's length and understood

Claims I removed or reworded, and why: ______________________________

---

## Module 7 Exercises — Packaging Decision Worksheet

### Exercise 7.1 — Packaging decision worksheet (one per product)

Product: ______________________________

| Option | Cost per unit | Pros | Cons | Decision |
|---|---|---|---|---|
| Glass bottle/jar | $ | | | |
| PET plastic bottle/jar | $ | | | |
| Paper wrap / box (bars) | $ | | | |

- Refill option offered? Yes / No — discount: ______________
- Supplier 1: ______________ Delivered cost per unit: $______________
- Supplier 2: ______________ Delivered cost per unit: $______________
- Sample ordered and tested with the actual product? Yes / No
- Sustainability claim I can honestly make: ______________________________

---

## Module 8 Exercises — Launch Checklist and 90-Day Plan

### Exercise 8.1 — Launch checklist

- [ ] Five products made, tested for a week, costed, and priced
- [ ] Labels printed and checked (Module 6 checklist complete for each)
- [ ] Packaging ordered and tested
- [ ] First sales channel chosen: ______________
- [ ] Etsy shop created OR first market booked (date: ______________)
- [ ] Product photos taken in natural daylight (5+ per listing)
- [ ] Price list printed
- [ ] Card reader ready
- [ ] Email signup sheet printed
- [ ] First batch of thank-you notes and samples ready

### Exercise 8.2 — 90-day plan

**Days 1–30 (Make and test)**
- Goal: ______________________________
- Products to make: ______________________________
- Milestone: ______________________________

**Days 31–60 (Launch small)**
- Goal: ______________________________
- Channel: ______________________________
- Milestone: ______________________________

**Days 61–90 (Learn and decide)**
- Goal: ______________________________
- Decision to make at day 90: ______________________________
- Metric I will judge by: ______________________________

### Exercise 8.3 — First-season review (complete at day 90)

- Total revenue: $______________
- Total units sold: ______________
- Best-selling product: ______________ Units: ______
- Highest-profit product: ______________ Margin: ______%
- Product that never sold: ______________ Action: ______________
- Most common customer question: ______________________________
- What I will change next season: ______________________________

---

*This workbook is general education, not legal, medical, or financial advice. Verify your local labeling and safety rules before selling. Results depend on your market, your location, and your effort.*
