# Labeling Compliance Checklist

Use this checklist for every product before you sell it. Check each box only when you have verified it for that specific product.

**Important:** This checklist is general education about how labeling commonly works in the United States. It is not legal advice. Rules differ by product type, by state, and by sales channel, and they change over time. Verify the current rules for your products and your location before you sell, and consult a local attorney or your small-business development center when you are unsure.

## Product

- Product name: ______________________________
- Formulation number: ______________
- Product category (true soap / cosmetic / household cleaner / laundry): ______________

## Front of Label

- [ ] Brand name is present and readable
- [ ] Product identity is in plain language (for example, "All-Purpose Cleaner")
- [ ] Scent or variant is named (if applicable)
- [ ] Net quantity is shown in the lower third of the front (fluid ounces and ml for liquids; ounces and grams for solids)
- [ ] Font is large enough to read at arm's length

## Back of Label

- [ ] Directions for use are complete (how much, how to apply, what surfaces or fabrics)
- [ ] Dilution instructions are included (for concentrates)
- [ ] Surfaces or materials to avoid are named (for example, "Do not use on marble or granite")
- [ ] Full ingredient list, in descending order of predominance
- [ ] Common names used, with scientific names in parentheses where helpful
- [ ] Allergens named plainly (honey, nut oils, wheat, and similar)
- [ ] Essential oils named, with a note for households with children or pets where relevant
- [ ] Business name and address (city and state minimum) and a contact method (website or email)
- [ ] Batch number printed
- [ ] Best-used-by date printed

## Warnings

- [ ] "Keep out of reach of children" is present
- [ ] "For external household use only" or equivalent is present (for cleaners)
- [ ] "Do not ingest" is present where applicable
- [ ] Skin-contact warning present where applicable (for example, "Do not use on broken skin")
- [ ] Ventilation note present where applicable
- [ ] No bleach-mixing warning needed, or included if the product could be confused with a bleach product

## Claims Review

- [ ] No claim that the product kills germs, disinfects, sanitizes, or prevents mold (unless you hold the regulatory approval to make that claim)
- [ ] No health claim (no "cures," "treats," "heals," or disease claims)
- [ ] No "chemical-free," "allergy-free," or "100% biodegradable" claim unless you can prove it
- [ ] Every claim on the label describes what the product does ("cleans," "cuts grease," "freshens"), not what it does to the body
- [ ] Scent claims match the actual essential oils used

## Final Checks

- [ ] A test label was printed, stuck on the actual bottle or jar, and read from arm's length
- [ ] Spelling checked, including ingredient names
- [ ] Label survives a wet hand and a wipe (test it — a label that smears in a bathroom is a bad label)
- [ ] A copy of the label is filed with the formulation record and batch log
- [ ] Label reviewed against current rules for this product type and state

## Notes

- Claims I removed or reworded, and why: ______________________________
- Questions to check with a local attorney or small-business development center: ______________________________
- Date completed: ______________ Reviewed by: ______________
