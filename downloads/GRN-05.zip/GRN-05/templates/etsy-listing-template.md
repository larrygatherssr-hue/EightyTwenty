# Etsy Listing Template

Copy this template for each product listing. Fill in every section before publishing.

## Title

Formula: [Scent/Variant] + [Product type] + [Key benefit] + [Size] + [Natural/Handmade]

Example: `Lavender Liquid Hand Soap, Natural Castile Hand Wash, Gentle on Skin, 10 oz`

Your title: ______________________________

(Keep it under 140 characters. Use words a buyer would actually type into search — avoid filler words and excessive punctuation.)

## Photos (at least 5)

1. Front of product on a plain background, label readable
2. Back of product showing the ingredient list
3. Product in use (hands washing, clean counter, fresh laundry)
4. Size reference (next to a common object, or held in a hand)
5. Ingredients flat-lay or workspace photo

Photo checklist:

- [ ] Natural daylight, no flash
- [ ] Label readable in at least one photo
- [ ] Background clean and uncluttered
- [ ] Product in use shown

## Description

**Opening line (what it is and who it is for):**

Example: "A gentle liquid hand soap made with plant-based castile soap, vegetable glycerin, and lavender essential oil — for households that want a cleaner that smells good and treats hands kindly."

Your opening line: ______________________________

**What is in it:**

(List every ingredient, in descending order, exactly as on the label.)

______________________________

**How to use it:**

______________________________

**Size and quantity:**

______________________________

**What makes it different:**

(One or two honest sentences — small batch, refillable bottle, no synthetic fragrance, and so on. No health claims and no germ-killing claims.)

______________________________

**Care and storage:**

(For example: "Store in a cool, dry place. Best used within 3 months of the date on the bottle. Shake gently before use.")

______________________________

## Tags (13 allowed — use all 13)

1. ______________________________
2. ______________________________
3. ______________________________
4. ______________________________
5. ______________________________
6. ______________________________
7. ______________________________
8. ______________________________
9. ______________________________
10. ______________________________
11. ______________________________
12. ______________________________
13. ______________________________

(Tag ideas: natural hand soap, castile soap, lavender hand soap, eco friendly cleaner, handmade soap, zero waste home, natural laundry, all purpose cleaner, plastic free, refillable, small batch, gift for her, housewarming gift.)

## Materials

(List the materials honestly, for example: "Liquid castile soap, vegetable glycerin, sweet almond oil, lavender essential oil, distilled water.")

______________________________

## Pricing

- Full cost per unit: $______________
- Etsy fees per sale (listing $0.20 + 6.5% transaction + 3% + $0.25 processing): $______________
- Target margin: ______%
- Etsy price: $______________
- Shipping charged to buyer: $______________

## Processing Time and Shipping

- Processing time: ______ business days
- Ships from: ______________
- Packaging note for the buyer: ______________________________

## Shop Policies Reminder

- Answer messages within 24 hours.
- Ship within the promised processing time, with tracking.
- If a product arrives damaged, replace it without argument.
