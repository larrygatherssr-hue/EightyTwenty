# Formulation Sheet

Copy this sheet for every batch you make. One sheet per batch. File it with your batch log.

## Product

- Product name: ______________________________
- Formulation number (from the course manual): ______________
- Date made: ______________
- Batch number: ______________
- Maker: ______________

## Batch Size

- Number of units: ______________
- Size per unit: ______________ (fl oz / oz / ml / g)

## Ingredients

| Ingredient | Amount | Supplier | Lot / batch no. | Cost |
|---|---|---|---|---|
| | | | | $ |
| | | | | $ |
| | | | | $ |
| | | | | $ |
| | | | | $ |
| | | | | $ |
| | | | | $ |
| | | | | $ |

Total ingredient cost for batch: $______________

## Method

1. ______________________________
2. ______________________________
3. ______________________________
4. ______________________________
5. ______________________________

## Quality Checks

- pH measured: ______________ Expected pH: ______________
- Appearance: ______________________________
- Scent: ______________________________
- Texture: ______________________________
- Container and closure checked (no leaks): Yes / No
- Label applied and correct: Yes / No

## Safety Checks

- [ ] Gloves and eye protection worn during making
- [ ] Area ventilated
- [ ] Patch test done (skin products) or hidden-spot test done (cleaners)
- [ ] No bleach mixed with vinegar, ammonia, or acids
- [ ] Essential-oil content checked against safe levels for children and pets
- [ ] Best-used-by date set: ______________

## Costing

- Ingredient cost per unit: $______________
- Container and label cost per unit: $______________
- Total product cost per unit: $______________
- Notes: ______________________________

## Observations and Changes

- What worked: ______________________________
- What did not work: ______________________________
- Change for next batch: ______________________________
