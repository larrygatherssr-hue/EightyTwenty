# Packaging Guide

## Choosing a Container

Match the container to the product, not the other way around.

| Product type | Best container | Notes |
|---|---|---|
| Spray cleaners | PET or glass spray bottle, 16 oz, fine-mist trigger | Spend extra on a good trigger — cheap triggers clog and leak |
| Liquid hand soap | Pump bottle, 8–10 oz | Test the pump with your actual soap before ordering in bulk |
| Foaming hand soap | Foaming pump bottle only | A standard pump will not foam this recipe |
| Powders (laundry, dishwasher, carpet) | Wide-mouth jar with tight lid + scoop | Moisture is the enemy; the seal matters more than the look |
| Soap bars | Paper wrap or small box | Let the bar breathe; shrink wrap traps moisture |
| Oils and polishes | Amber glass bottle | Protects contents from light; 3-month best-used-by date |
| Pastes and scrubs | Wide-mouth jar | Easy to scoop; label must survive wet hands |

## Typical Packaging Costs (small-maker quantities)

- Spray bottle, 16 oz: $0.60–$1.00 each
- Pump bottle, 8–10 oz: $0.80–$1.20 each
- Foaming pump bottle: $0.90–$1.30 each
- Wide-mouth jar: $0.50–$0.90 each
- Amber glass bottle, 6–8 oz: $0.70–$1.10 each
- Printed label: $0.15–$0.25 each
- Kraft tag and string (soap bars): $0.10–$0.20 each

Buying in cases of 50 or 100 typically cuts the per-unit price by 20–40% compared with buying ten at a time. Do not order 1,000 bottles of a product you have not sold yet — order for the next two months.

## Supplier Checklist

Before ordering in bulk from a new supplier, confirm:

- [ ] Minimum order quantity: ______________
- [ ] Delivered cost per unit (price + shipping): $______________
- [ ] Shipping time: ______________
- [ ] Sample ordered and tested with the actual product: Yes / No
- [ ] Second supplier identified for this item: ______________

Keep at least two sources for every critical item, so a stockout at one supplier does not stop production.

## Sustainability Choices You Can Honestly Make

- **Offer refills.** A customer who brings back a bottle gets $1.00 or 10% off, and you save the cost of a new bottle. Refills bring customers back to your table.
- **Use glass where it makes sense, plastic where it is safer.** Glass is reusable and recyclable but heavy to ship and breakable. PET plastic is lighter and safer around a bathtub. Explain your choice; customers respect a reasoned choice more than a slogan.
- **Keep packaging minimal.** One label, one bottle, no extra box. A small kraft tag tied with string is enough for a soap bar.
- **Say what is true, specifically.** "Bottle is refillable." "Label printed on recycled paper." "Ingredients are plant-based." Do not claim "zero waste" or "100% biodegradable" unless you can prove it.

## Label Durability

- Test every label with a wet hand and a wipe. A label that smears in a bathroom is a bad label.
- Waterproof or water-resistant labels are worth the extra cost for products used near sinks, showers, and laundry.
- Print a test label, stick it on the actual bottle, and read it from arm's length. If you cannot read it, your customer cannot either.

## Market Table and Shipping

- Market table: clean cloth, products at eye level, one open bottle of each product for smelling and testing, clear price list, card reader ready.
- Online shipping: sturdy box, paper padding rather than plastic, hand-written thank-you note, and a small sample of another product (under $1.00 cost, and the cheapest way to sell a second product).
