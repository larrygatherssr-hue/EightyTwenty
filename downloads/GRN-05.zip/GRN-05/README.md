# GRN-05 — The Eco Home Product Workshop: Formulate, Package, and Sell Natural Household Products

**Price:** $197 (one-time) · **Category:** Green Living & Sustainability · **SKU:** GRN-05

**Format note:** This is a complete written course manual. It is not a video course. The sales page states this plainly.

## Files

| File | What it is |
|---|---|
| `content.md` | The full written course: 8 modules, 30 tested formulations with costing, labeling, packaging, and selling guidance (13,314 words) |
| `workbook.md` | Companion workbook: exercises and worksheets for each module, including formulation log, costing worksheet, pricing worksheet, label checklist, packaging decision worksheet, launch checklist, and 90-day plan |
| `templates/product-costing-calculator.csv` | Costing calculator with worked examples for three products |
| `templates/labeling-compliance-checklist.md` | Labeling compliance checklist to complete for every product before selling |
| `templates/etsy-listing-template.md` | Complete Etsy listing template (title, photos, description, tags, pricing) |
| `templates/formulation-sheet.md` | One-page sheet to copy for every batch made |
| `templates/packaging-guide.md` | Container choices, costs, suppliers, and sustainability guidance |
| `sales-page.md` | Full sales page: headline, problem, solution, module list, who it is for / not for, $197 price, 14-day guarantee, 12-question FAQ, disclaimers |
| `listing.json` | Marketplace listing data (sku GRN-05, price_cents 19700, one-time billing) |
| `cover.md` | Cover design brief (black-and-gold luxury palette, typography, imagery, layout) |
| `cover.png` | Generated cover image, 1280 × 1920 px, premium black-and-gold branding |
| `onboarding.md` | Customer onboarding guide: what to do first, how to use the materials, suggested 4-week schedule, support |
| `README.md` | This file |
