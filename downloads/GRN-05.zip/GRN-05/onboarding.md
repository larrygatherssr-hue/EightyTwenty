# Welcome — Getting Started with The Eco Home Product Workshop

Welcome, and thank you for purchasing The Eco Home Product Workshop. This guide will help you get the most from your purchase in your first week.

**Important:** This is a complete written course manual, not a video course. Everything is in writing so you can read at your own pace, print the pages you need at your workbench, and search the text whenever a question comes up.

## What You Received

- `content.md` — the complete written course manual: 8 modules, 30 tested formulations, costing and pricing worked examples, labeling and packaging guidance, and selling guidance.
- `workbook.md` — the companion workbook with exercises and worksheets for every module.
- `templates/product-costing-calculator.csv` — costing calculator with worked examples for three products.
- `templates/labeling-compliance-checklist.md` — the checklist to complete for every product before selling it.
- `templates/etsy-listing-template.md` — a complete Etsy listing template.
- `templates/formulation-sheet.md` — a one-page sheet to copy for every batch you make.
- `templates/packaging-guide.md` — container choices, costs, suppliers, and sustainability guidance.
- `cover.md` — the cover design brief.
- `sales-page.md` — the full sales page for this product.
- `listing.json` — the marketplace listing data.
- `README.md` — the index of all files in this product.

## What to Do First

1. **Read the disclaimers at the top of `content.md`.** They cover safety, essential-oil risks around children and pets, and the limits of the labeling guidance. Read them before you make anything.
2. **Read Modules 1 and 2.** Module 1 sets up your workspace and safety habits. Module 2 teaches the formulation principles everything else depends on.
3. **Set up your workspace** using the checklist in workbook Module 1: a clean making surface, making-only tools, a digital scale, gloves, safety glasses, and your base pantry.
4. **Make three test products for your own household** — one soap, one all-purpose cleaner, and one laundry product from Module 3 — and log each batch on a copy of the formulation sheet.
5. **Use each product yourself for a week** before you think about selling it. Patch-test skin products and test cleaners on a hidden surface first.

## Suggested Schedule

- **Week 1:** Read Modules 1–3. Set up your workspace. Make and test your first three products.
- **Week 2:** Read Modules 4–5. Cost all three products with the costing calculator and set your prices with the pricing worksheet.
- **Week 3:** Read Modules 6–7. Complete the labeling checklist for each product, design your labels, and order packaging.
- **Week 4:** Read Module 8. Choose your first sales channel, build your listings or book your first market, and launch with five products.

## How to Use the Materials

- **At the workbench:** print the formulation sheet for the batch you are making and the formulation pages from Module 3.
- **At your desk:** use the costing calculator and the pricing worksheet whenever you cost a new product or change a supplier.
- **Before every sale:** run the labeling compliance checklist for that product. Do not skip it.
- **Keep a formulation log:** one sheet per batch, filed by product. It is your quality record, your costing source, and your answer if a customer ever asks about a batch.

## Safety Reminders

- Formulations are for external household use only. Never ingest a cleaning product.
- Wear gloves and eye protection when handling washing soda, citric acid in bulk, alcohol, or concentrated soap. Work in a ventilated area.
- Keep essential oils and finished products out of reach of children. Several essential oils are unsafe for young children and toxic to cats and dogs — check the safety notes on every formulation.
- Never mix bleach with vinegar, ammonia, or acids. This manual contains no bleach recipes.
- If a product changes color, smell, or texture, or you see mold, throw it away. Never sell a product you would not use yourself.

## How to Get Support

If you have a problem with your order or the course files, email the marketplace support address with your order number and a description of the issue, and the support team will respond. Your purchase includes a 14-day money-back guarantee — contact support with your order number within 14 days of purchase for a full refund.

For labeling and legal questions about your specific products and location, consult a local attorney or your state or local small-business development center. The labeling guidance in this course is general education, not legal advice.

## One Last Thing

Start with one product, one batch, one sale. Then do it again. That is how a maker business is built.
