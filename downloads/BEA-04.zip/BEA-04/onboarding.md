# Customer Onboarding Guide — Salon Profit System

Welcome, and thank you for buying the Salon Profit System. This guide tells you what to do first, how to use the materials, and how to work through the system over eight weeks. Keep it with the course — it is your map for the first two months.

**A note before you start:** This product is education only. It is not legal, tax, accounting, medical, or financial advice, and it does not guarantee any profit or business result. Employment law, licensing, tax, and consumer rules vary by state and country — check the rules where you operate and get qualified local advice where a decision matters.

---

## What You Received

| File | What it is |
|---|---|
| `content.md` | The full written course — 10 modules, with worked examples and appendices |
| `workbook.md` | Companion workbook — ten worksheets matching the course modules |
| `templates/salon-pl-calculator.csv` | Salon P&L calculator spreadsheet with formulas |
| `templates/chair-utilisation-tracker.csv` | Chair-utilisation tracker, weekly and by stylist |
| `templates/monthly-kpi-tracker.csv` | Monthly KPI tracker for the five key numbers |
| `templates/staff-handbook-template.md` | Staff handbook template — adapt it, then have it checked locally |
| `templates/commission-models.md` | Commission models guide with worked examples |
| `templates/rebooking-scripts.md` | Word-for-word rebooking scripts |
| `templates/retail-display-and-upsell-guide.md` | Retail display and upsell guide |
| `cover.png` | The product cover image |
| `sales-page.md` | The sales page copy for this product (reference) |
| `listing.json` | The marketplace listing data (reference) |

---

## What to Do First (Day 1)

1. **Read Module 1 and complete Worksheet 1 in the workbook.** Build your profit map for last month using your real books, and score the five leaks. This takes about an hour, and everything else follows from it.
2. **Pick your single biggest leak.** Write it down. That is your priority for the next 30 days.
3. **Start the chair-utilisation tracker.** Record this week's bookings by day. You cannot fix what you do not measure, and one week of data will already show you your quiet days.
4. **Book your monthly review.** Put a one-hour meeting in your diary for the fifth working day of next month — with yourself, and with your team if you have one. That meeting is the rhythm that makes the system stick.

---

## How to Use the Materials

- **Read the course in order the first time.** Each module ends with actions — do them before you move on.
- **Keep the workbook open beside the course.** Every worked example has a matching worksheet. Use your real figures, not the example figures.
- **Use the spreadsheets monthly.** The P&L calculator and the KPI tracker are filled in on the fifth working day of each month, next to your books. Five numbers, one page, every month.
- **Use the scripts at the chair, not in a drawer.** Print the rebooking scripts, practise them in pairs at a team meeting, and keep a copy at reception.
- **Adapt the handbook, do not issue it as-is.** Fill in every bracket, have it checked by a qualified local employment adviser, and give every team member a copy with time to read it.

---

## Suggested 8-Week Schedule

**Week 1 — Measure.** Read Modules 1 and 2. Complete Worksheets 1 and 2. Calculate your utilisation by day and by stylist, and the value of ten extra points. Pick two utilisation methods and start them.

**Week 2 — Price.** Read Module 3. Complete Worksheet 3. Cost your five most-booked services. Plan one price rise, with a date and a client notice.

**Week 3 — Profit.** Read Module 4. Complete Worksheet 4. Build your P&L, calculate the four ratios, and write your three sentences. Identify one cost line to investigate.

**Week 4 — People.** Read Modules 5 and 6. Complete Worksheets 5 and 6. Write down your ideal staff mix, publish the rota two weeks ahead, and test your pay model against a good month and a bad month.

**Week 5 — Rebooking.** Read Module 7. Complete Worksheet 7. Teach the rebooking script at a team meeting, practise it in pairs, and measure your rebooking rate for the week.

**Week 6 — Retail.** Read Module 8. Complete Worksheet 8. Cut your retail range to fifteen products, tidy and re-price the display, and start recommending one product per client during the service.

**Week 7 — Retention.** Read Module 9. Complete Worksheet 9. Run your gap list, contact lapsed clients personally, and hold your first stay interview.

**Week 8 — Rhythm.** Read Module 10. Complete Worksheet 10. Fill in the KPI tracker, write your 90-day plan, and hold your first monthly review. Set one target for next month.

After week 8, the system runs on the monthly rhythm: P&L and KPI tracker on the fifth working day of each month, one target per month, and a review of what worked.

---

## How to Get Support

For help with your order or the course files, email the marketplace support address with your order number and a description of the issue, and the support team will respond. For questions about your salon's specific legal, tax, or employment position, contact a qualified local professional — support cannot give legal or tax advice.

**14-day money-back guarantee:** If you are not satisfied within 14 days of purchase, contact support with your order number for a full refund.
