# BEA-04 — Salon Profit System: Management, Staff & Retention

**Price:** $497 (one-time) | **Category:** Beauty & Health | **SKU:** BEA-04

**Headline:** Fill every chair and keep every client — salon profit, staffing, and retention in one system.

An operations system for owners and managers of existing hair salons, nail salons, and beauty studios with 2–15 staff who are busy but not reliably profitable.

## Files in This Folder

| File | What it is |
|---|---|
| `content.md` | The full written course — 10 modules plus appendices (11,000+ words) |
| `workbook.md` | Companion workbook — 10 worksheets matching the course modules |
| `templates/salon-pl-calculator.csv` | Salon P&L calculator spreadsheet with formulas |
| `templates/chair-utilisation-tracker.csv` | Chair-utilisation tracker, weekly and by stylist |
| `templates/monthly-kpi-tracker.csv` | Monthly KPI tracker for the five key numbers |
| `templates/staff-handbook-template.md` | Staff handbook template |
| `templates/commission-models.md` | Commission models guide with worked examples |
| `templates/rebooking-scripts.md` | Word-for-word rebooking scripts |
| `templates/retail-display-and-upsell-guide.md` | Retail display and upsell guide |
| `sales-page.md` | Full sales page: headline, problem, solution, module list, who it is for / not for, price, guarantee, FAQ, disclaimers |
| `listing.json` | Marketplace listing data (price_cents 49700, billing one_time) |
| `cover.md` | Cover design brief (black-and-gold luxury) |
| `cover.png` | The generated cover image (1280 × 1920 PNG) |
| `onboarding.md` | Customer onboarding guide with an 8-week schedule |
| `README.md` | This file |
