# Salon Profit System: Management, Staff & Retention

## The Complete Written Course — 10 Modules

**Headline:** Fill every chair and keep every client — salon profit, staffing, and retention in one system.

**Price:** $497 | **Format:** Written course manual (10 modules) + spreadsheets, handbook and commission templates, rebooking scripts, retail guides, and monthly KPI tracker. This document is the full written text of the course — every lesson, script, worked example, and exercise in prose, so you can read it, print it, and work through it at your own pace.

---

## Important Disclaimers — Please Read First

This course is education only. It teaches general business, management, pricing, and marketing principles for salon owners. It is not legal, tax, accounting, medical, or financial advice, and it does not guarantee any level of profit, income, or business result. Results depend on your market, your prices, your costs, your team, and how consistently you apply the system.

Employment law, worker classification, licensing, health and safety rules, tax obligations, and consumer-protection rules vary by state and country, and they change over time. Before you change how staff are paid, classified, contracted, or scheduled; before you change prices, refund policies, or client terms; and before you open, expand, or restructure your salon, check the rules that apply where you operate and get advice from a qualified local professional — an employment lawyer, an accountant, and your licensing authority — where the decision matters. Nothing in this course replaces that advice.

All worked examples use invented salons and invented numbers. They are teaching examples, not market data, not industry averages, and not promises about what your salon will earn. Where a template asks you to enter your own figures, use your real books, not the example figures.

No client, staff member, or salon in this course is a real person or a real business. Any resemblance to a real salon is coincidence.

---

## Table of Contents

- Module 1 — The Salon Profit Map: Where Your Money Actually Goes
- Module 2 — Chair Utilisation: Filling Every Chair, Every Hour
- Module 3 — Pricing That Pays: Building Prices From Costs, Not From Competitors
- Module 4 — The Salon P&L: Reading Your Numbers Like an Owner
- Module 5 — Staffing: Hiring, Scheduling, and the Right Mix of Roles
- Module 6 — Commission and Pay Models That Keep Good People
- Module 7 — The Rebooking System: Never Let a Client Leave Without a Next Visit
- Module 8 — Retail: The Quiet Profit Centre on Your Shelf
- Module 9 — Retention: Keeping Clients and Keeping Staff
- Module 10 — The Monthly Rhythm: KPIs, Reviews, and the 90-Day Profit Plan

---

## How to Use This Course

Work through the modules in order the first time. Each module ends with actions to complete before you move on. Keep the companion workbook open beside you: every worked example in this course has a matching worksheet there, and the templates folder holds the spreadsheets and scripts you will actually use in the salon. Do not try to change everything in one week. Module 10 gives you an eight-week implementation schedule — follow it.

You will meet one running example throughout the course: **Glow & Co.**, an invented six-chair hair salon with five stylists, open six days a week. Its numbers are invented for teaching. Use them to learn the maths; then replace them with your own.

---

## Module 1 — The Salon Profit Map: Where Your Money Actually Goes

### Lesson 1.1 — Busy is not profitable

Most salon owners can tell you how busy they were last Saturday. Very few can tell you how much profit last Saturday made. That gap is the whole problem this course solves. A salon can be fully booked, fully staffed, and still lose money — because the wrong services were booked, at the wrong prices, with too much product, too much idle time between clients, and too few clients rebooked.

Profit in a salon comes from five levers, and only five: how many chairs are filled, how much each client spends, how often each client returns, how much each service costs you to deliver, and how much of the money is left after fixed costs. Everything in this course is one of those five levers, worked properly.

Write this down and keep it where you do your books:

**Profit = (Clients × Average spend per visit × Visits per year) − (Product and direct costs + Staff costs + Fixed costs)**

If any part of that equation is unknown, you are guessing. This course removes the guessing.

### Lesson 1.2 — Meet Glow & Co.

Glow & Co. is a six-chair salon. It opens Tuesday to Saturday, 9 a.m. to 6 p.m., and Sunday 10 a.m. to 4 p.m. — six days, 54 trading hours a week. It has five stylists: two senior, two mid-level, one junior. One receptionist works part-time. The owner, Maya (an invented person), also works three days a week behind the chair.

Last month Glow & Co. took $38,400 in service revenue and $4,100 in retail revenue — $42,500 in total. Rent is $4,800 a month. Wages, including Maya's own drawings treated as a wage for this exercise, are $21,000. Product costs are $4,900. Utilities, insurance, software, laundry, and sundries come to $3,100. Total costs: $33,800. Profit before tax: $8,700. That is a profit margin of about 20 percent on $42,500 — healthy on paper, but Maya has no idea which chairs, which stylists, or which services produced it, and she cannot tell whether next month will be better or worse. That is the position most owners are in, and it is fixable.

### Lesson 1.3 — The five leaks

Walk your salon against these five leaks and score each one honestly from 1 (no leak) to 5 (serious leak):

1. **Empty chairs.** Chairs that sit empty during open hours. Every empty chair-hour is revenue that can never be recovered — you cannot sell yesterday's 10 a.m. slot tomorrow.
2. **Low rebooking.** Clients who leave without a next appointment. If they do not rebook, you must spend time and money winning them back, or replace them entirely.
3. **Weak retail.** Clients who buy their shampoo somewhere else. Retail is the highest-margin sale in most salons and the one most often left to chance.
4. **Wrong pricing.** Prices set by looking at the salon down the road instead of by your own costs. A price that does not cover product, labour, and overhead is a loss disguised as a booking.
5. **Staff churn.** Good people leaving, taking clients with them, and leaving you to recruit and train again. Replacing a stylist costs far more than keeping one.

Most salons leak in at least three of the five. Your job in this course is to measure each leak, fix the biggest one first, and then move to the next.

### Lesson 1.4 — The profit map exercise

Draw your own profit map on one page. Across the top, write your total revenue last month, split into services and retail. Down the left, list every cost, grouped into three buckets: **direct costs** (product used in services, and the cost of retail goods sold), **staff costs** (wages, commission, payroll taxes, and benefits), and **fixed costs** (rent, utilities, insurance, software, marketing, and everything else that does not change much month to month). Subtract, and you have your profit. Now ask three questions: which bucket grew fastest in the last six months? Which service brings in the most revenue per hour? Which stylist has the highest rebooking rate? If you cannot answer the second and third questions, Modules 2 and 7 will teach you how to get the data in under a week.

### Module 1 Actions

1. Complete the profit map for last month using your real figures.
2. Score the five leaks from 1 to 5.
3. Pick the single biggest leak. That is your priority for the next 30 days.

---

## Module 2 — Chair Utilisation: Filling Every Chair, Every Hour

### Lesson 2.1 — What chair utilisation really means

Chair utilisation is the percentage of your available chair-hours that are actually booked with a paying client. It is the single most useful number in a salon, because it turns "we were busy" into a number you can manage.

**Chair utilisation = Booked chair-hours ÷ Available chair-hours × 100**

Available chair-hours are the hours a chair could have been booked: number of chairs × hours open. Booked chair-hours are the hours actually filled. A chair booked for a three-hour colour counts as three booked chair-hours. A chair with a stylist on holiday still counts as available unless you close it — which is why closing a chair deliberately, or filling it with a freelancer, is sometimes better than leaving it empty.

### Lesson 2.2 — The worked example

Glow & Co. has 6 chairs and is open 54 hours a week, so it has 324 available chair-hours a week. Last week it booked 211 chair-hours. Utilisation was 211 ÷ 324 = 65 percent.

Now look closer. Tuesday to Thursday utilisation was 52 percent. Friday and Saturday were 94 percent. The salon is not short of demand — it is short of demand at the right times. That changes the fix completely. A salon at 65 percent overall with a dead Tuesday does not need more advertising. It needs Tuesday demand: off-peak pricing, a Tuesday-only offer, or moving a popular stylist's day off from Tuesday to Monday, when the salon is closed anyway.

Do the same split for your salon: utilisation by day, and then by stylist. You will almost always find that two or three stylists are at 90 percent while one is at 40 percent — and the fix for the 40 percent stylist is usually training, mentoring, or a different column, not more marketing.

### Lesson 2.3 — The money in ten points

Here is why ten points of utilisation matter so much. Glow & Co. averages $68 of service revenue per booked chair-hour. At 65 percent utilisation it books 211 hours a week and takes about $14,348 a week in services. At 75 percent it would book 243 hours and take about $16,524 — an extra $2,176 a week, or roughly $9,400 a month, with almost no extra fixed cost. Rent does not rise. The extra cost is product and a little extra labour. That is why utilisation, not new clients, is usually the fastest route to profit: the chair, the light, and the heating are already paid for.

Work it for your salon: your average revenue per booked chair-hour × your available chair-hours × 10 percent. That is the monthly value of ten points of utilisation. Write it on the wall. It is the number that justifies spending time on off-peak offers and rebooking.

### Lesson 2.4 — Seven ways to lift utilisation without discounting your way to nothing

1. **Stagger start times.** If every stylist starts at 9 a.m., you have a rush at 9 and a gap at 4. Stagger by 30 to 60 minutes so the column fills evenly.
2. **Fill the gaps, not the peaks.** Offer the quiet slots first when a client calls. Train reception to say, "I have Tuesday at 11 or Thursday at 2 — which suits you?" before offering Saturday.
3. **Shorten the service, not the quality.** A 15-minute reduction in a colour service, achieved by better timing and preparation, frees a slot a day per stylist. That is five extra slots a week.
4. **Standby and cancellation lists.** Every cancellation should trigger a call to the standby list within the hour. A cancelled Saturday slot filled on Friday evening is worth the same as a new booking.
5. **Pre-book the next visit at the chair.** This is Module 7 in full, but it starts here: a client who leaves with a booking is a filled chair in six weeks' time.
6. **Use quiet hours for retail and consultation.** A free 15-minute consultation in a quiet slot often becomes a paying service next week.
7. **Close a chair deliberately.** If you have six chairs and five stylists, the sixth chair is not an asset — it is an empty chair dragging your utilisation down. Either staff it, rent it to a freelancer, or remove it from the count and stop judging yourself against it.

### Lesson 2.5 — What not to do

Do not fill chairs with deep discounts that train clients to wait for a deal. A 50 percent off Tuesday fills Tuesday once and empties full-price Tuesday forever. If you use an off-peak offer, make it a value-add — a free treatment, a free blow-dry with colour, a loyalty stamp — not a price cut. And do not confuse utilisation with overbooking. A stylist double-booked into mistakes, late finishes, and unhappy clients is not utilisation; it is damage.

### Module 2 Actions

1. Calculate your utilisation for last week, overall and by day, using the tracker in the templates folder.
2. Calculate the monthly value of ten extra points of utilisation.
3. Pick two of the seven methods above and try them for four weeks.

---

## Module 3 — Pricing That Pays: Building Prices From Costs, Not From Competitors

### Lesson 3.1 — Why competitor pricing fails

If your competitor charges $55 for a cut and blow-dry, that tells you nothing about your costs. Their rent may be half yours. Their stylists may be juniors. Their product may be cheaper. Copying their price is copying a business you do not run. Prices must be built from your costs, your time, and the profit you need — and then checked against what your clients will pay, not the other way around.

### Lesson 3.2 — The pricing build-up

Every service price has four layers:

1. **Product cost** — the colour, the shampoo, the treatment, the foils, the gloves. Measure it, do not guess it.
2. **Labour cost** — the stylist's hourly cost to you, including payroll taxes and benefits, multiplied by the service time.
3. **Overhead share** — your fixed costs spread across your booked hours.
4. **Profit margin** — the amount left for you, the owner, after everything else.

**Price = Product + Labour + Overhead share + Profit**

### Lesson 3.3 — The worked example: a cut and blow-dry

Glow & Co. works it like this for a senior cut and blow-dry that takes 60 minutes:

- Product cost: $4.50 (shampoo, conditioner, styling product, measured by weighing bottles over a month).
- Labour cost: the senior stylist costs $32 an hour including payroll taxes and benefits, so one hour is $32.00.
- Overhead share: Glow & Co.'s fixed costs are $7,900 a month (rent $4,800 plus utilities, insurance, software, laundry, and sundries of $3,100). It books about 844 chair-hours a month. Overhead per booked hour is $7,900 ÷ 844 = $9.36.
- Cost before profit: $4.50 + $32.00 + $9.36 = $45.86.
- The salon wants a 20 percent profit margin on price, so price = $45.86 ÷ 0.80 = $57.33, rounded to $58.

Glow & Co. was charging $52. Every cut and blow-dry was losing about $6 against its true cost once overhead was counted — and it was doing 180 of them a month. That is over $1,000 a month of quiet loss on its most popular service. The fix was a price rise to $58, explained to clients in advance, with no change in quality. Most clients stayed. The ones who left were the ones the salon was losing money on anyway.

### Lesson 3.4 — Pricing colour and long services

Colour is where salons lose the most money, because product cost varies wildly and time overruns are common. Price colour in two parts: a base price that covers the standard application and time, plus a clear charge for extra product — extra bowls, extra length, extra thickness. Write the rule down and apply it every time: "Colour prices include one bowl of colour. Additional bowls are $12 each." Clients accept a clear rule. They resent a surprise.

For long services, price by time, not by hope. If a balayage takes three hours, its labour and overhead alone are three times the hourly cost. A three-hour service priced like a two-hour service is a loss with a smile.

### Lesson 3.5 — How to raise prices without losing the room

Raise prices once or twice a year, not in small panicked jumps. Give four weeks' notice in the salon, by email, and at the chair. Explain it once, briefly, in terms of costs and quality — never apologise repeatedly, and never blame staff. Raise your most popular services first, because that is where the money is. And raise prices for new clients first if you are nervous: new clients have no old price to compare against, and their acceptance tells you the market will bear the new level.

A useful test: if fewer than one client in twenty leaves after a rise, your prices were too low. If more than one in ten leaves, you raised too much, too fast, or without explaining it.

### Lesson 3.6 — Junior, mid, and senior pricing

Tiered pricing is fair and profitable. A junior at $38, a mid-level at $48, and a senior at $58 for the same cut gives clients a real choice, gives juniors a full column while they learn, and gives seniors a reason to stay — their higher price is recognised. The mistake is to let clients book a senior at a junior price because "they have been coming for years." Grandfather the price for a set period — say, three months — then move them to the correct tier, or move them to a mid-level stylist they like.

### Module 3 Actions

1. Cost out your five most-booked services using the build-up above.
2. Compare the built price with your current price. List every service priced below its true cost.
3. Plan one price rise, with a date and a client notice, within the next 30 days.


---

## Module 4 — The Salon P&L: Reading Your Numbers Like an Owner

### Lesson 4.1 — What a P&L is, in plain language

A profit and loss statement — a P&L — is a one-page summary of a period: money in, money out, and what is left. It is not accounting for its own sake. It is the only document that tells you whether the salon is a business or an expensive hobby. You need one every month, within ten days of the month ending, and you need to compare it with the month before and with the same month last year.

The structure is simple:

**Revenue (services + retail) − Direct costs = Gross profit. Gross profit − Staff costs − Fixed costs = Net profit.**

### Lesson 4.2 — The worked example: Glow & Co., one month

| Line | Amount |
|---|---|
| Service revenue | $38,400 |
| Retail revenue | $4,100 |
| **Total revenue** | **$42,500** |
| Product used in services | $3,400 |
| Cost of retail goods sold | $1,500 |
| **Total direct costs** | **$4,900** |
| **Gross profit** | **$37,600 (88.5%)** |
| Stylist wages and commission | $17,500 |
| Reception and support wages | $2,200 |
| Payroll taxes and benefits | $1,300 |
| **Total staff costs** | **$21,000** |
| Rent | $4,800 |
| Utilities, insurance, software, laundry, sundries | $3,100 |
| **Total fixed costs** | **$7,900** |
| **Net profit before tax** | **$8,700 (20.5%)** |

Read it in three passes. First, gross profit: 88.5 percent is healthy for a service business — product is under control. Second, staff costs: $21,000 is 49.4 percent of revenue. That is the number to watch; in most salons staff costs are the largest cost and the one that drifts upward unnoticed. Third, net profit: 20.5 percent is good, but it depends on Maya working three days a week behind the chair without paying herself a proper wage. If Maya paid herself a market-rate senior stylist wage for those three days — about $3,800 a month — true profit would be closer to $4,900, or 11.5 percent. That is the honest number, and it is the one to manage against. Always count your own time. A business that only profits because the owner works for free is not profitable.

### Lesson 4.3 — The four ratios that matter

Memorise these. Check them monthly.

1. **Gross profit margin** = Gross profit ÷ Revenue. Aim for 80 percent or higher in a service-led salon. Below 75 percent, product cost or retail cost is leaking.
2. **Staff cost ratio** = Staff costs ÷ Revenue. Many healthy salons sit between 45 and 55 percent. Above 60 percent, you are overstaffed for your revenue, or under-priced, or both.
3. **Retail share** = Retail revenue ÷ Total revenue. Below 5 percent, retail is being ignored. Ten to 15 percent is a strong retail salon.
4. **Net profit margin** = Net profit ÷ Revenue. Below 5 percent, the salon is fragile — one quiet month or one broken piece of equipment wipes it out. Ten to 20 percent is a solid, sustainable range. Above 25 percent, check that you are not underpaying staff or under-investing in the salon.

Ratios beat raw numbers because they survive growth. Revenue doubling means nothing if staff costs tripled to get there.

### Lesson 4.4 — Cash is not profit

A busy December can leave the bank account full and the P&L weak, because clients paid for gift vouchers not yet redeemed, or because you bought three months of product in one order. Conversely, a quiet January can look terrible in the bank while the P&L is fine, because rent and wages went out before the month's revenue arrived. Keep two views: the P&L for profit, and a simple cash check — bank balance at the start of the month, money in, money out, bank balance at the end. If cash is falling while profit is rising, find out why before it becomes a crisis: usually stock, vouchers, or late-paying corporate accounts.

### Lesson 4.5 — Finding the leak in your P&L

Compare this month with last month, line by line, and ask "why?" three times for any line that moved more than 10 percent. Product cost up 18 percent? Why — more clients, or more waste, or a price rise from your supplier? More clients — why, and did revenue rise in step? If revenue rose 5 percent and product rose 18 percent, you have waste or theft or over-use, and you need to weigh product and set a per-service allowance. This is not suspicion; it is management. Product is the easiest cost to lose track of and the easiest to fix with measurement.

### Lesson 4.6 — Your monthly P&L routine

On the fifth working day of each month: close the books, run the P&L from your accounting software or the spreadsheet in the templates folder, calculate the four ratios, and write three sentences — what went well, what went badly, and what you will change this month. Three sentences, every month, will teach you more about your business than a yearly meeting with an accountant. Keep the accountant for tax and compliance; run the business yourself, monthly.

### Module 4 Actions

1. Build your P&L for last month in the salon P&L calculator spreadsheet.
2. Calculate the four ratios and write your three sentences.
3. Identify one cost line to investigate this month.

---

## Module 5 — Staffing: Hiring, Scheduling, and the Right Mix of Roles

### Lesson 5.1 — The right mix before the right people

A salon with six chairs does not need six senior stylists. It needs a mix: seniors who bring in the highest revenue per hour and mentor others, mid-level stylists who carry the bulk of the column, and juniors who learn, assist, and fill the lower-priced column. A common healthy mix for a six-chair salon is two seniors, two mid-levels, and one or two juniors, plus part-time reception cover at peak times. Too many seniors and your wage bill crushes your margin. Too many juniors and clients wait, quality slips, and seniors spend their time fixing rather than earning.

Work out your mix from demand, not from who happens to apply. List your services by volume: how many cuts, colours, and treatments a week, and at which level clients ask for them. Hire to fill the gap in that list.

### Lesson 5.2 — Hiring well, slowly

Hire slowly and deliberately. A bad hire in a small salon costs far more than a slow hire: lost clients, low morale, and the cost of doing it all again in three months. Write the role down before you advertise — the services, the hours, the pay model, and what good looks like in the first 90 days. Interview for attitude and reliability as much as skill: you can teach a technique, you cannot teach showing up on time and being kind to clients. Always do a paid trial day behind the chair with real clients, and always take up references. Ask the referee one question that matters more than the rest: "Would you hire this person again?" The pause before the answer tells you everything.

Be honest in the advert about pay, hours, and expectations. The stylists you want are the ones who read an honest advert and still apply.

### Lesson 5.3 — Scheduling that serves clients and staff

Build the rota two weeks ahead and publish it. A rota published late is a rota that creates childcare problems, resentment, and sick days. Cover the peaks — Friday, Saturday, and the weekday evenings your clients actually want — with your strongest team, and give your strongest people their preferred day off in exchange. Keep one rule: no stylist works more than five days in a row without a break, and no one works every Saturday forever. Burnout is a staffing cost, not a personal failing.

Plan holidays a quarter ahead. Every stylist should have their holidays in the diary before the quarter starts, so you can arrange cover instead of discovering a gap the week before. And keep a small bench of trusted freelancers or part-timers you can call — not as a panic measure, but as a planned part of the rota.

### Lesson 5.4 — The junior pipeline

Juniors are your future seniors and your cheapest source of good staff. A junior who trains with you, learns your standards, and grows into a mid-level stylist is worth far more than an experienced hire who brings someone else's habits. Give juniors a real training plan: what they will learn each month, who mentors them, and when they will be assessed for promotion. Pay for their training time, review their progress monthly, and promote on skill, not on time served. A junior who can see the path to senior will stay. A junior who cannot will leave — and take the training you paid for with them.

### Lesson 5.5 — When someone is not working out

Address poor performance early, kindly, and in writing. Start with a private conversation: what you have observed, what you expect, and what support you will give. Agree a review date, usually two to four weeks ahead. If nothing changes, follow your local employment rules and your written procedures — which is why Module 6's handbook matters. Never let a struggling stylist drift for six months while clients quietly leave. That is unfair to the stylist, who deserves to know, and unfair to the clients, who deserve good work. Document every step. If you ever need formal advice, an employment lawyer will ask for that record first.

### Module 5 Actions

1. Write down your ideal staff mix and compare it with what you have.
2. Publish the rota two weeks ahead for the next month.
3. Give every junior a written training plan, or start one this week.

---

## Module 6 — Commission and Pay Models That Keep Good People

### Lesson 6.1 — The three common models

There are three pay models you will meet in salons, and each has a trade-off:

1. **Salary or hourly wage.** Predictable for the stylist, predictable for you. Best for juniors, reception, and part-timers. The risk is that a quiet stylist costs the same as a busy one, so you must manage utilisation.
2. **Commission only.** The stylist earns a percentage of what they take. Common percentages for employed stylists are 40 to 50 percent of service revenue, with the salon keeping the rest to cover product, rent, and overhead. It rewards hustle, but income swings with quiet weeks, and it can discourage teamwork — why help a colleague when it earns you nothing?
3. **Base plus commission.** A guaranteed base wage plus commission above a threshold, or a percentage on everything above the base. This is the model most growing salons settle on: security for the stylist, upside for performance, and protection for the owner.

There is also chair rental, where a stylist pays you a fixed rent for the chair and keeps what they earn. That is a different business — you become a landlord, not an employer — and it changes your legal duties, your tax position, and your control over the client experience. Do not drift into chair rental by accident. If you use it, get local legal and tax advice first, put it in writing, and be clear about who supplies product, who owns the client, and who is responsible when something goes wrong.

### Lesson 6.2 — The worked example: base plus commission

Glow & Co. pays its mid-level stylists a base of $2,600 a month plus 10 percent commission on service revenue above $6,500 a month. One mid-level stylist, Ana (an invented person), took $8,400 in services last month. Her pay is $2,600 base plus 10 percent of ($8,400 − $6,500) = $2,600 + $190 = $2,790. The salon keeps $8,400 − $2,790 = $5,610 from her column before product and overhead.

Check the maths from the salon's side before you promise it: Ana's column must cover her base, her commission, her product (about $600), and her share of overhead (about $1,300). Total cost: $2,790 + $600 + $1,300 = $4,690 against $8,400 taken. The column contributes $3,710. That works. Now test the bad month: if Ana takes only $5,200, she earns her $2,600 base and no commission, and her column costs $2,600 + $380 + $1,300 = $4,280 against $5,200 — a contribution of $920. Still positive, but thin. That tells Maya the threshold is set about right: the base is affordable in a bad month, and the commission only pays when the stylist is genuinely performing.

### Lesson 6.3 — Retail commission

Pay retail commission separately, and pay it well enough to matter — commonly 10 to 15 percent of retail sales. If a stylist sells $400 of retail in a month at 10 percent, that is $40. It is not life-changing, but it is a visible reward for a behaviour you want, and it is cheap for you: retail margin is usually 50 percent or more, so the salon still keeps most of it. Do not pay retail commission on discounted or clearance stock at the full rate — say so in writing, in advance.

### Lesson 6.4 — What kills a pay model

Four things: changing the model without notice, making the threshold unreachable, paying late, and paying different people different rates for the same work without a clear, written reason. Any one of these destroys trust faster than a low rate does. Publish the model in the staff handbook, show every stylist their own numbers monthly, and never change commission terms mid-month. If a change is needed, give a full month's notice and explain why.

### Lesson 6.5 — Non-pay retention

Pay is not the only reason people stay. Stylists stay for a full column, for good product, for training, for a fair rota, for being listened to, and for a salon they are proud to work in. A $200 pay rise will not keep a stylist whose column is empty and whose ideas are ignored. Spend as much time on the rota, the training, and the culture as you do on the pay scale — Modules 5 and 9 cover both.

### Module 6 Actions

1. Write down your current pay model for every role, in one page.
2. Test it against a good month and a bad month, as in Lesson 6.2.
3. Put the model in the staff handbook and show each stylist their numbers this month.

---

## Module 7 — The Rebooking System: Never Let a Client Leave Without a Next Visit

### Lesson 7.1 — Why rebooking is the cheapest growth you will ever buy

Winning a new client costs time, advertising, and often a first-visit offer. Keeping a client costs a 30-second conversation at the chair. A client who rebooks before they leave is a client you do not have to win back. A client who does not rebook is a client you will probably lose: life gets busy, another salon opens, and three months later they have a new regular.

**Rebooking rate = Clients who book their next visit before leaving ÷ Clients seen × 100**

Most salons that measure this for the first time find a rate between 30 and 50 percent. A strong salon runs at 70 percent or higher. The gap between 40 and 70 percent, on a salon seeing 400 clients a month, is 120 extra future bookings a month — without a dollar of advertising.

### Lesson 7.2 — The worked example

Glow & Co. saw 420 clients last month. 176 booked their next visit before leaving. Rebooking rate: 176 ÷ 420 = 42 percent. Its best stylist rebooks at 68 percent. Its weakest rebooks at 24 percent. The gap is not talent — it is habit. The best stylist asks every client, every time. The weakest asks only when they remember.

If Glow & Co. lifted its overall rate from 42 to 65 percent, that would be 97 extra bookings a month. At an average service of $86, that is about $8,340 of future revenue secured at the chair, for the cost of a conversation. That is the single highest-return change in this whole course, and it costs nothing.

### Lesson 7.3 — The rebooking conversation, word for word

Rebooking fails because stylists feel awkward asking. Remove the awkwardness with a script, and practise it until it sounds natural. The conversation happens while the client is still in the chair, happy with the result — not at reception, while they are reaching for their coat.

**Stylist:** "Your colour will need a refresh in about six weeks to keep this tone. Shall we get you in for the week of the 12th? I have Tuesday morning or Thursday afternoon — which suits you better?"

Three rules in that script: give a reason tied to the client's hair, give a time frame, and offer two choices — never ask "Do you want to rebook?" as a yes-or-no question, because "no" is the easy answer. If the client genuinely cannot commit, book a reminder instead: "No problem — shall I send you a reminder in five weeks so you can choose then?" A reminder is a second chance. Silence is not.

At reception, the booking is confirmed, the date is written on the card or sent by text, and the client is told the cancellation policy in one friendly sentence. That is the whole system. It takes 30 seconds.

### Lesson 7.4 — The rebooking audit

Once a month, audit rebooking by stylist. The workbook has the audit sheet. Look for patterns: a stylist who rebooks colour clients well but never rebooks cut clients, or who rebooks on Saturdays but not on Tuesdays. Share the numbers with the team — not as a punishment, but as a team target: "We are at 42 percent. Our target is 60 percent by the end of next month. Here is the script, here is the practice, and here is the reward when we hit it." Celebrate the improvement publicly. Coach the gap privately.

### Lesson 7.5 — Reminders, no-shows, and the gap list

Rebooking is the first line of defence. Reminders are the second: a text or message 48 hours before, and a short confirmation the day before, cut no-shows sharply. Keep the message short and warm, with the date, time, and stylist's name, and a simple way to reschedule. Never charge a no-show fee you have not told the client about in advance, in writing, and never apply it to a first offence without a conversation.

Every month, run the gap list: clients who have not visited in twice their usual interval — a six-week colour client who has not been in for twelve weeks. Call or message them personally, not with a generic blast: "Hi Sarah, it's Ana from Glow & Co. — we haven't seen you for a while and I wanted to check your colour is still looking good. I have a slot on Thursday if you'd like it." A personal message wins back clients a mass message never will. Aim to contact the whole gap list every month, a few each day, so it never becomes a mountain.

### Module 7 Actions

1. Measure your rebooking rate for last week, overall and by stylist.
2. Teach the script in Lesson 7.3 at your next team meeting and practise it in pairs.
3. Run your gap list this week and contact ten lapsed clients personally.


---

## Module 8 — Retail: The Quiet Profit Centre on Your Shelf

### Lesson 8.1 — Why retail matters more than you think

Retail is the only sale in the salon where the client takes the product home and uses your recommendation every day. It is also, in most salons, the most under-used profit lever. A salon that sells nothing at retail is handing its clients to the shop down the road — and handing over the margin with them.

**Retail attach rate = Clients who buy a retail product ÷ Clients seen × 100**

**Average retail spend = Retail revenue ÷ Number of retail buyers**

If Glow & Co. sees 420 clients a month and 63 buy retail, its attach rate is 15 percent. If retail revenue is $4,100, average retail spend is $65. A strong salon runs an attach rate of 25 to 35 percent. Lifting Glow & Co. from 15 to 25 percent would mean 42 extra buyers a month — about $2,730 extra retail revenue, of which roughly half is gross profit after the cost of goods.

### Lesson 8.2 — The worked example: the retail attach-rate model

Take your numbers and run the same model:

- Clients per month: 420
- Current attach rate: 15% → 63 buyers
- Average retail spend: $65 → $4,095 retail revenue
- Cost of goods at 50%: $2,048 → gross profit $2,047

Now at a 25 percent attach rate:

- Buyers: 105
- Retail revenue: 105 × $65 = $6,825
- Gross profit at 50% margin: $3,413

That is $1,366 extra gross profit a month — about $16,400 a year — from recommending a product the client already needs, to a client who already trusts you. No new clients, no new chairs, no extra rent. The only cost is the habit of recommending.

Now test a second lever: average spend. If the same 105 buyers spend $75 instead of $65 because stylists recommend a second product — a treatment to go with the shampoo — revenue becomes $7,875 and gross profit $3,938. Attach rate and average spend multiply. Work on both, one at a time.

### Lesson 8.3 — Recommending without selling

Clients do not dislike being recommended a product. They dislike being sold to. The difference is timing, honesty, and specificity. Recommend during the service, when the product is in your hands and the client can feel the result — not at the till, when it feels like an add-on.

**Stylist (during the service):** "Your hair is quite dry at the ends, so I'm using the repair mask today. If you use it once a week at home, this softness will last until your next visit. It's the one on the shelf by the mirror — I can put one aside for you if you'd like."

Three rules: recommend one product, not three. Give a reason tied to what you can see in the client's hair or skin. And make it easy to say yes — put it aside, carry it to reception, and have it ready. Never recommend a product you have not used or do not believe in. Clients can tell, and one dishonest recommendation costs more trust than ten honest ones earn.

### Lesson 8.4 — Display, stock, and the shelf that sells

A dusty shelf in the corner sells nothing. Retail sells when it is visible, tidy, well-lit, and priced clearly. Put your best sellers at eye level near the mirror and near reception, where clients wait. Keep the range small — ten to fifteen products you genuinely recommend, not forty you cannot explain. Every product on the shelf should have a price on it, a tester where hygiene rules allow it, and a stylist who can say in one sentence what it does and who it is for.

Stock is cash on a shelf. Count it monthly. Know your best sellers, your slow movers, and your dead stock. A product that has not sold in three months is not a product — it is money you cannot spend. Clear it honestly, replace it with something your clients actually ask for, and do not reorder it because a supplier offered a deal.

### Lesson 8.5 — Retail targets that work

Set a team target, not an individual punishment. A team attach rate of 25 percent, reviewed weekly, with the whole team sharing a small reward when it is hit — a team lunch, an extra training session, a product allowance — works better than ranking stylists against each other. Share the numbers: "This week we were at 22 percent. Three more buyers a day gets us to 25." Make the target visible, make it small, and make it shared.

### Module 8 Actions

1. Calculate your attach rate and average retail spend for last month.
2. Cut your retail range to the fifteen products you can genuinely recommend.
3. Tidy and re-price the display this week, and start recommending one product per client, during the service.

---

## Module 9 — Retention: Keeping Clients and Keeping Staff

### Lesson 9.1 — Retention is two businesses, not one

Client retention and staff retention are usually treated as separate problems. They are the same problem, seen from two sides: people stay where they feel known, valued, and well looked after. A salon that loses staff loses clients, because clients follow the stylist they trust. A salon that loses clients loses staff, because empty columns mean low pay and low morale. Fix them together.

**Client retention rate = Clients who returned within their normal interval ÷ Clients due to return × 100**

If 300 clients were due back in the last three months and 210 returned, retention is 70 percent. Below 60 percent, you are losing clients faster than most salons can replace them. Above 80 percent, you have a loyal base that will carry you through quiet months.

### Lesson 9.2 — Why clients really leave

Clients rarely leave because of one bad haircut. They leave because of a slow accumulation: a rushed appointment, a stylist who forgot their name, a price rise with no explanation, a long wait, a dirty station, or a feeling that nobody noticed they had been away for three months. The fix is not a loyalty card. The fix is noticing.

Keep a simple client record: name, usual service, usual interval, allergies and sensitivities, preferences, and the date of the last visit. Use it. A stylist who says, "Same as usual, and you said last time the fringe was a little long — shall we take it a touch shorter today?" is doing retention work that no discount can match.

### Lesson 9.3 — The loyalty system that actually works

A good loyalty system is simple, generous enough to matter, and easy to understand. One workable model: every tenth service of the same type is free, or a free treatment with every sixth colour. Whatever you choose, write the rules down, apply them the same way to everyone, and do not make the reward so hard to reach that nobody ever gets there. A reward nobody reaches is not a reward — it is a disappointment.

Do not build loyalty on discounts alone. Discount loyalty trains clients to value the price, not the salon. Build it on recognition, consistency, and small thoughtful touches: a birthday message, a reminder that their usual stylist is back from holiday, a first booking with a new stylist offered at the usual price with a senior consultation included.

### Lesson 9.4 — Handling complaints before they become departures

A client who complains is giving you a second chance. A client who says nothing and never returns is not. Make complaining easy: ask at the end of every service, "Are you happy with that?" — and mean it. If the answer is no, fix it on the spot if you can, or book the correction free of charge within a few days. Never argue, never blame the client, and never make them feel awkward for speaking up. After a correction, follow up personally. A complaint handled well creates a more loyal client than one who never had a problem — because they now know you will look after them when it matters.

Keep a short written record of complaints and what was done. Patterns matter: three complaints about waiting times in a month is a scheduling problem, not three difficult clients.

### Lesson 9.5 — Staff retention: the stay interview

Once a year — or better, twice — sit down with each team member and ask the questions most owners only ask in an exit interview, when it is too late: What do you enjoy most here? What frustrates you? What would make you stay for another year? What would you change if you could? Then act on at least one thing each person said, and tell them you did. People do not leave jobs where they feel heard. They leave jobs where they told someone, nothing changed, and they stopped bothering.

Pair the stay interview with a clear path: what the next level looks like, what they need to learn to get there, and when you will review it. A stylist with a path stays. A stylist without one starts looking.

### Lesson 9.6 — When a stylist leaves

People will leave, even in a good salon. When they do, handle it well. Thank them, wish them well, and agree together how their clients will be looked after. Offer every affected client a handover appointment with a stylist who has been briefed on their history, and a senior consultation free of charge. Do not bad-mouth the person who left, do not panic-discount to keep their clients, and do not pretend nothing happened. Clients respect honesty. And check your records: if one stylist's departure takes a large share of your revenue with it, that is a warning that your salon's client relationships live with individuals, not with the business — which is exactly what rebooking, client records, and team-based service are meant to fix.

### Module 9 Actions

1. Calculate your client retention rate for the last three months.
2. Hold a stay interview with one team member this week, and book the rest.
3. Write down your complaint-handling steps and share them with the team.

---

## Module 10 — The Monthly Rhythm: KPIs, Reviews, and the 90-Day Profit Plan

### Lesson 10.1 — The five numbers, every month

You do not need twenty KPIs. You need five, checked every month, without fail:

1. **Chair utilisation** — booked chair-hours ÷ available chair-hours.
2. **Rebooking rate** — clients who booked their next visit before leaving.
3. **Retail attach rate** — clients who bought retail ÷ clients seen.
4. **Average service spend** — service revenue ÷ clients seen.
5. **Net profit margin** — net profit ÷ total revenue.

The monthly KPI tracker in the templates folder holds all five, with space for the month, the target, and the actual figure. Fill it in on the fifth working day of each month, next to your P&L. Five numbers, one page, every month. That is the whole reporting system.

### Lesson 10.2 — The monthly review meeting

Once a month, for one hour, sit down with your numbers and ask four questions: What improved? What got worse? Why? What will I change this month? If you have a team, share the headline numbers with them — utilisation, rebooking, retail — and celebrate the wins before you discuss the gaps. A team that sees the numbers will help you improve them. A team that never sees them will assume everything is fine until it is not.

Set one target per month, not five. One target, named, dated, and owned: "Rebooking from 42 to 55 percent by the end of next month, owned by me, reviewed at the next meeting." A single clear target beats a long list that nobody remembers.

### Lesson 10.3 — The 90-day profit plan

Here is the whole course, turned into a 90-day plan. Glow & Co. used this exact sequence, and you can too.

**Days 1–30: Measure and fix the biggest leak.** Build your P&L, calculate utilisation by day and by stylist, measure your rebooking rate, cost your top five services, and calculate your retail attach rate. Fix the single biggest leak: if rebooking is below 50 percent, teach the script and practise it daily. If a service is priced below cost, raise it with four weeks' notice.

**Days 31–60: Systematise.** Put the pay model in the handbook, publish the rota two weeks ahead, tidy the retail display and cut the range, start the gap list, and hold your first stay interviews. Introduce the monthly KPI tracker and hold your first monthly review.

**Days 61–90: Grow from strength.** Review the numbers: utilisation, rebooking, retail, and profit margin against where you started. Keep what worked, drop what did not, and set the next 90-day target — usually the second-biggest leak from Module 1. If utilisation is now above 75 percent and rebooking above 60 percent, you have a salon that can grow without discounting: consider a new service, a new stylist, or extended hours on your strongest day.

### Lesson 10.4 — The worked example: Glow & Co. after 90 days

After 90 days, Glow & Co.'s numbers moved like this (invented example, for teaching only):

- Chair utilisation: 65% → 76%
- Rebooking rate: 42% → 61%
- Retail attach rate: 15% → 24%
- Average service spend: $86 → $91 (after the price rise in Module 3)
- Monthly service revenue: $38,400 → $44,900
- Monthly retail revenue: $4,100 → $6,200
- Monthly total revenue: $42,500 → $51,100
- Net profit margin: 20.5% → 23.1% (on the owner's unadjusted figures; the honest margin, counting Maya's wage properly, rose from 11.5% to about 15%)

No new chairs, no new advertising campaign, no discounting. The same salon, the same team, run on a system instead of on hope. Your numbers will be different. The method is the same: measure, fix the biggest leak, systematise, review monthly, and repeat.

### Lesson 10.5 — What to do when the numbers go backwards

They will, some months. A stylist leaves, a road closes, a quiet January arrives. Do not panic and do not discount everything in sight. Go back to the five numbers and find which one moved. If utilisation fell, look at the rota and the gap list. If rebooking fell, listen to the script being used at the chair. If retail fell, check the display and the stock. Fix the one number, not the whole business. And keep the monthly review going even in a bad month — especially in a bad month. The review is the system that stops one bad month becoming a bad year.

### Lesson 10.6 — Your salon, your system

This course gave you a system, not a set of rules carved in stone. Your salon, your clients, and your market are different from Glow & Co.'s. Keep what works, adapt what does not, and throw away anything that does not fit — but keep the rhythm: measure monthly, fix the biggest leak, look after your people, and never let a client leave without a next visit. Do that for a year, and you will know your salon in a way most owners never do: not as a busy place that might be profitable, but as a business whose numbers you understand and can improve on purpose.

### Module 10 Actions

1. Fill in the monthly KPI tracker for this month and set a target for each of the five numbers.
2. Write your 90-day plan using the structure in Lesson 10.3.
3. Book your first monthly review meeting — with yourself, and with your team — for the fifth working day of next month.

---

## Final Checklist — Before You Call the System "Live"

- [ ] Profit map completed for last month
- [ ] Chair utilisation calculated by day and by stylist
- [ ] Top five services costed, and any below-cost price raised or scheduled to rise
- [ ] P&L built and the four ratios calculated
- [ ] Staff mix written down; rota published two weeks ahead
- [ ] Pay model written in the handbook and shared with every stylist
- [ ] Rebooking script taught and practised
- [ ] Retail range cut to fifteen products; display tidied and priced
- [ ] Gap list run and lapsed clients contacted
- [ ] Monthly KPI tracker started; first monthly review booked

---

## A Final Note on Law, Licensing, and Local Rules

Salon licensing, health and safety, employment, tax, and consumer rules differ by state and country and change over time. This course gives you general business education, not advice about your specific legal position. Before you change pay, contracts, worker classification, prices, refunds, or client terms, check the rules where you operate and get qualified local advice where the decision matters. Keep your licences current, keep your records, and keep your insurance in force. A profitable salon is built on a compliant one.

*End of course.*

---

## Appendix A — Worked Case Study: A Full Month at Glow & Co., Step by Step

This appendix walks through one complete month at Glow & Co., the invented example salon used throughout this course, so you can see every calculation in this course applied to a single set of books. All figures are invented for teaching. Use the method, not the numbers.

### A.1 The month in brief

It is a four-week month. Glow & Co. is open six days a week, 54 hours a week, with six chairs. Available chair-hours for the month: 6 chairs × 54 hours × 4 weeks = 1,296 hours. The salon booked 985 chair-hours. Utilisation was 985 ÷ 1,296 = 76 percent, up from 65 percent three months earlier, after the changes in Modules 2 and 7.

The salon saw 468 clients in the month. Service revenue was $44,900, so average service spend was $44,900 ÷ 468 = $95.94 per client visit. That figure is higher than the $86 from three months earlier, partly because of the price rise in Module 3 and partly because more clients added a treatment or a blow-dry to their booking. Retail revenue was $6,200 from 112 buyers, so the attach rate was 112 ÷ 468 = 24 percent and average retail spend was $6,200 ÷ 112 = $55.36. Rebooking: 286 of the 468 clients booked their next visit before leaving, a rate of 61 percent.

### A.2 The P&L, line by line

Service revenue $44,900 plus retail revenue $6,200 gives total revenue of $51,100. Product used in services was $3,900 — the salon weighed and measured product for a month and found it was spending about 8.7 percent of service revenue on product, down from 8.9 percent before, because stylists were measuring colour instead of mixing by eye. Cost of retail goods sold was $3,100, exactly half of retail revenue, because the salon buys retail at roughly 50 percent of its selling price. Total direct costs were $7,000. Gross profit was $51,100 − $7,000 = $44,100, a gross margin of 86.3 percent.

Staff costs were $23,400: stylist wages and commission $19,600, reception $2,300, payroll taxes and benefits $1,500. That is 45.8 percent of revenue, down from 49.4 percent, because revenue grew faster than the wage bill — the point of the utilisation work. Fixed costs were $7,900: rent $4,800, utilities $1,100, insurance $320, software $180, laundry $600, sundries and marketing $900. Net profit before tax was $44,100 − $23,400 − $7,900 = $12,800, a margin of 25.0 percent.

Now the honest adjustment from Module 4. Maya, the owner, worked three days a week behind the chair. If she paid herself a market-rate senior wage for those days — about $3,800 a month — true profit would be $12,800 − $3,800 = $9,000, a margin of 17.6 percent. That is the number Maya manages against. It is still a strong result, and it is honest: the salon pays for its owner's time and still makes money.

### A.3 Where the improvement came from

Compare this month with the month three months earlier. Revenue rose from $42,500 to $51,100, an increase of $8,600. Where did it come from? Break it down so you can see which lever did the work.

First, utilisation: booked hours rose from 844 to 985 a month, an extra 141 hours. At the salon's average revenue per booked hour — $44,900 ÷ 985 = $45.58 — those extra hours are worth about $6,427. Second, price: the average service spend rose from $86 to $95.94, and part of that rise is price, part is mix. On the original 420 clients, a $9.94 rise in average spend is worth about $4,175 — but be careful, because some of that overlaps with the utilisation gain: the extra 48 clients also spent at the new average. The honest way to say it is that utilisation and pricing together added roughly $8,000 of service revenue, and retail added the rest: retail revenue rose from $4,100 to $6,200, an increase of $2,100, from the attach rate rising from 15 to 24 percent. The point of the breakdown is not precision to the dollar. It is to show that no single lever did the work alone, and that the two cheapest levers — filling chairs and rebooking clients — did most of it.

### A.4 One stylist, in full

Take Ana, the mid-level stylist from Module 6. In this month Ana worked 148 hours behind the chair and was booked for 118 of them — utilisation of 80 percent. She saw 96 clients and took $8,900 in services. Her average service spend was $8,900 ÷ 96 = $92.71. She rebooked 62 of her 96 clients, a rate of 65 percent. She sold $720 of retail to 28 buyers, an attach rate of 29 percent.

Her pay: a base of $2,600 plus 10 percent commission on service revenue above $6,500. That is $2,600 + 10 percent of $2,400 = $2,600 + $240 = $2,840. Her retail commission at 10 percent is $72. Total pay: $2,912. Her column's costs: pay $2,912, product about $780 (8.7 percent of $8,900, rounded), and her share of fixed overhead — the salon's $7,900 spread across 985 booked hours is $8.02 an hour, and Ana booked 118 hours, so $946. Total cost of Ana's column: $2,912 + $780 + $946 = $4,638 against $8,900 taken, plus her retail gross profit of $360 (half of $720). Her column contributes about $4,622 to the salon. That is a healthy column, and Ana can see exactly why: her utilisation is high, her rebooking is high, and her retail is above the salon average. When Maya shows Ana these numbers, Ana can see the link between her habits and her pay — and Maya can see that Ana is worth investing in.

Contrast that with a weaker column in the same month. A junior stylist, Ben (an invented person), was booked for 84 of 132 available hours — 64 percent utilisation — saw 71 clients, took $3,900, rebooked 34 clients (48 percent), and sold $210 of retail. Ben is paid an hourly wage of $2,100 a month with no commission yet. His column costs $2,100 plus product $340 plus overhead $674 (84 hours × $8.02), a total of $3,114 against $3,900 taken, plus $105 of retail gross profit. His contribution is about $891. That is positive, but thin — and it tells Maya exactly what to coach: Ben's rebooking and his utilisation, not his technical skill, which clients rate highly. The numbers turn a vague worry about a junior into a specific coaching plan.

### A.5 What Maya changed next

At the monthly review, Maya set one target for the next month: lift the salon's rebooking rate from 61 to 65 percent, by coaching the two stylists below 55 percent and by making the gap list a daily habit rather than a monthly one. She also noted two things to watch: product cost had crept up by $200 on the month before, so she asked the team to weigh colour for one more week; and Saturday utilisation was at 98 percent, which meant the salon was turning clients away on its busiest day — the case for adding a Saturday part-timer, which she costed using the same column maths as Ana's above before deciding. That is the monthly rhythm in action: one target, two things to watch, and every decision tested against the numbers first.

## Appendix B — Reference Tables

### B.1 Chair utilisation: what the numbers mean

- Below 50 percent: the salon is significantly under-used. Look at opening hours, the rota, and whether the salon is open on days with no demand. Do not add marketing spend until you know which days and which stylists are empty.
- 50 to 65 percent: typical for a salon that has never measured utilisation. The gains here are usually the easiest — off-peak filling, rebooking, and staggering start times.
- 65 to 80 percent: a well-run salon. The work now is holding the level and lifting the weakest day and the weakest stylist, not the average.
- Above 85 percent: the salon is effectively full. Further growth needs more chairs, more hours, or higher prices — not more bookings, because there is nowhere to put them. Watch for overbooking, late finishes, and tired staff.

### B.2 Rebooking rate: what the numbers mean

- Below 40 percent: most clients are leaving without a next visit. Teach the script in Module 7 and practise it daily. This is the first fix.
- 40 to 55 percent: improving, but still leaving money on the table. Audit by stylist and coach the gap.
- 55 to 70 percent: strong. Keep the habit, and turn attention to the gap list for the clients who still slip through.
- Above 70 percent: excellent. Protect it — it is the most valuable asset in the salon — and make sure new stylists are taught the script from their first week.

### B.3 Retail attach rate: what the numbers mean

- Below 10 percent: retail is effectively not happening. Check the display, the range, and whether anyone is recommending at all.
- 10 to 20 percent: a start. One recommendation per client, during the service, will usually lift this band.
- 20 to 30 percent: a strong retail salon. Work on average spend next — a second product for the clients who already buy.
- Above 30 percent: excellent, and worth protecting. Make sure recommendations stay honest and specific, and that the shelf stays stocked with the products clients actually ask for.

### B.4 Staff cost ratio: what the numbers mean

- Below 40 percent: either very efficient, or underpaying, understaffed, or with the owner working unpaid. Check all four before celebrating.
- 40 to 55 percent: a normal, healthy range for most salons.
- 55 to 65 percent: tight. Look at utilisation and pricing before cutting pay — the problem is usually revenue, not wages.
- Above 65 percent: unsustainable for long. Either revenue must rise, hours must be restructured, or the staff mix must change. Get advice from an accountant before making structural changes.

### B.5 A simple price-check table

Use this to test any service price quickly. Fill in your own figures.

- Product cost per service: $____
- Labour cost per service (hourly cost × hours): $____
- Overhead per booked hour × hours: $____
- Total cost: $____
- Current price: $____
- Price minus total cost: $____ (if negative, the service loses money at the current price)
- Price needed for a 20 percent margin (total cost ÷ 0.80): $____

Run this table for your five most-booked services every six months, and every time a supplier raises prices or a wage changes. Prices that were right a year ago are often wrong today, and the table is the fastest way to find out.

## Appendix C — Glossary

- **Attach rate:** the percentage of clients who buy a retail product.
- **Available chair-hours:** chairs multiplied by hours open — the maximum the salon could book.
- **Booked chair-hours:** the hours actually filled with a paying client.
- **Chair utilisation:** booked chair-hours divided by available chair-hours.
- **Commission:** pay calculated as a percentage of the revenue a stylist takes.
- **Direct costs:** costs tied directly to delivering a service — product used, and the cost of retail goods sold.
- **Fixed costs:** costs that do not change much month to month — rent, insurance, software.
- **Gap list:** clients who have not visited in twice their usual interval.
- **Gross profit:** revenue minus direct costs.
- **Net profit:** gross profit minus staff costs and fixed costs.
- **P&L:** profit and loss statement — revenue, costs, and profit for a period.
- **Rebooking rate:** the percentage of clients who book their next visit before leaving.
- **Retention rate:** the percentage of clients due to return who actually return.
- **Staff cost ratio:** staff costs divided by revenue.

## Appendix D — A Note to the Owner Who Is Doing Everything

Many salon owners are also the best stylist, the receptionist, the cleaner, the bookkeeper, and the marketer. If that is you, the system in this course is not another job to add to the list. It is the way the list gets shorter. Start with one number — rebooking rate is the best first number for most salons — and one habit, the thirty-second conversation at the chair. When that habit holds for a month, add the next number. A salon is not fixed in a weekend. It is fixed one measured habit at a time, by an owner who knows the numbers and looks after the people. That owner is you, and this course is your reference for the year ahead. Keep it on the shelf, use the tracker every month, and come back to the module you need when the numbers tell you where to look next.
