# Retail Display and Upsell Guide

*Education only. No medical claims: never present a cosmetic product as a treatment or cure for a medical condition. Follow local rules on product claims, labelling, and hygiene, including testers.*

---

## Part 1 — The Display

### The rules

1. **Visible from the chair and from reception.** Clients buy what they can see while they wait and while they are being served. A shelf in a back room sells nothing.
2. **Eye level sells.** Put your best sellers at eye level. Put slower lines higher or lower.
3. **Small range, well explained.** Ten to fifteen products you can genuinely recommend will outsell forty you cannot explain. Cut the range, and know every product left on it.
4. **Priced clearly.** Every product has a price on it, visible without asking. Clients who have to ask the price usually do not buy.
5. **Tidy, clean, and well-lit.** Dust the shelf daily. Face products forward. Replace empty or damaged packaging immediately. A messy shelf tells clients the products are not cared for.
6. **Testers where hygiene rules allow.** A client who has felt a product on their own hair is far more likely to buy it. Keep testers clean, labelled, and replaced regularly.

### A simple display layout

- **Top shelf:** Treatments and masks — the products stylists recommend most during services.
- **Middle shelf (eye level):** Shampoo and conditioner, grouped by hair type, with your best seller in the centre.
- **Lower shelf:** Styling products and finishing products.
- **Reception:** Three best sellers only, with prices, where clients wait to pay. Rotate them monthly.

### The monthly display check (five minutes)

- [ ] Shelf dusted and products faced forward
- [ ] Every product priced
- [ ] Testers clean and in date
- [ ] No empty or damaged packaging on display
- [ ] Best sellers in stock — nothing on display that you cannot sell today

---

## Part 2 — The Upsell: Recommending During the Service

### The principle

Recommend one product, during the service, for a reason the client can see and feel — not three products at the till.

### The pattern

1. **Notice:** While you work, notice what the client's hair or skin needs — dryness at the ends, frizz, fading colour, a sensitive scalp.
2. **Use:** Use the product in the service, so the client feels the result.
3. **Name:** Name the product and the reason in one sentence.
4. **Offer:** Offer to put one aside. Carry it to reception so the client does not have to ask for it.

### Word-for-word examples

**Dry ends:**

"Your hair is quite dry at the ends, so I'm using the repair mask today. If you use it once a week at home, this softness will last until your next visit. It's the one on the shelf by the mirror — I can put one aside for you if you'd like."

**Colour care:**

"To keep this colour from fading, use the colour-safe shampoo — the one I'm using now. It will stretch the time between colours by a week or two."

**Frizz:**

"This smoothing cream is what I'm using to finish your hair today. A small amount on damp hair will keep the frizz down between visits."

**Second product (only when the first is accepted):**

"And if you like the mask, the leave-in spray from the same range works well with it — but start with the mask, and tell me how you get on with it next time."

### What not to do

- Do not recommend a product you have not used or do not believe in.
- Do not recommend three products at once. One honest recommendation beats three hurried ones.
- Do not pitch at the till. By then the client is reaching for their coat, and it feels like an add-on.
- Do not discount retail to make a sale. If a product is right for the client, its price is part of the recommendation.
- Do not make health or treatment claims about a cosmetic product. Describe what it does for the hair's appearance and feel, in ordinary language.

---

## Part 3 — Stock and Reordering

- Count retail stock monthly, on the same day you do the P&L.
- Know your best sellers, your slow movers, and your dead stock. A product that has not sold in three months is money on a shelf — clear it honestly and do not reorder it.
- Reorder best sellers before they run out. A client who is told "we're out of stock" usually buys it somewhere else.
- Keep a simple reorder list: product, supplier, cost price, selling price, and the stock level that triggers a reorder.
- Do not over-order because a supplier offers a deal. A deal on stock you cannot sell is not a deal.

---

## Part 4 — Team Targets

Set a team attach-rate target — for example 25 percent — and review it weekly. Share the number with the whole team: "This week we were at 22 percent. Three more buyers a day gets us to 25." Celebrate the team hitting the target together, rather than ranking stylists against each other. A shared reward — a team lunch, an extra training session, a product allowance — works better than an individual league table.
