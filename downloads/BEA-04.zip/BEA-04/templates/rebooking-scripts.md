# Rebooking Scripts — Word-for-Word, Ready to Practise

*Practise these in pairs at your next team meeting until they sound natural in your own words. The words matter less than the habit: ask every client, every time, while they are still in the chair and happy with the result. Adapt the time frames to your services — the examples below use common intervals; your salon's intervals may differ.*

---

## The Core Script — Colour (Six-Week Interval)

**Stylist, while the client is still in the chair:**

"Your colour will need a refresh in about six weeks to keep this tone. Shall we get you in for the week of the 12th? I have Tuesday morning or Thursday afternoon — which suits you better?"

**Why it works:** It gives a reason tied to the client's hair, a time frame, and two choices. It never asks "Do you want to rebook?" as a yes-or-no question.

---

## The Core Script — Cut (Four to Five Weeks)

**Stylist:**

"Your cut will start to lose its shape in about four weeks. Shall I book you in for the week of the 5th? I have Wednesday at 11 or Friday at 3 — which is better for you?"

---

## The Core Script — Treatment or Blow-Dry (Two to Three Weeks)

**Stylist:**

"This treatment will keep your hair feeling like this for about three weeks. Shall we book the next one in now, so you keep the result? I have next Tuesday or the Saturday after — which suits you?"

---

## When the Client Cannot Commit

**Stylist:**

"No problem at all — shall I send you a reminder in five weeks so you can choose a time then?"

Then make sure the reminder is actually set. A reminder is a second chance. Silence is not.

---

## When the Client Says They Will Book Online Later

**Stylist:**

"Of course — I'll pop a reminder in for five weeks, and the link is on your receipt. If your usual time is taken, just message us and we'll find you something."

---

## At Reception — Confirming the Booking

**Receptionist:**

"You're booked in with Ana on Thursday the 14th at 2 p.m. for colour and cut. I'll send you a confirmation by text, and a reminder two days before. If anything changes, just let us know — you can move it up to 48 hours before without any charge."

One friendly sentence about the cancellation policy, given in advance, prevents most disputes later.

---

## The Reminder Message (48 Hours Before)

"Hi Sarah, it's Glow & Co. — a reminder that you're booked in with Ana on Thursday at 2 p.m. for colour and cut. Reply YES to confirm, or let us know if you need to move it. We look forward to seeing you!"

Keep it short, warm, and easy to answer. Include the date, time, and stylist's name.

---

## The Gap List — Winning Back a Lapsed Client

For clients who have not visited in twice their usual interval. Personal, not a mass message.

**By text or message:**

"Hi Sarah, it's Ana from Glow & Co. — we haven't seen you for a while and I wanted to check your colour is still looking good. I have a slot on Thursday at 11 if you'd like it, or I can find another time that suits you."

**If they reply that they went elsewhere:**

"No problem at all — thank you for letting me know. If you ever fancy coming back, we'd love to see you. Take care!"

Never argue, never guilt-trip, and never offer a discount to win them back on the first message. A warm, personal note is worth more than a voucher.

---

## The Handover — When a Client's Usual Stylist Has Left

**Receptionist or owner, by phone:**

"Hi Sarah, it's Maya from Glow & Co. I wanted to let you know that Ana has moved on, and I wanted to make sure you're looked after. I'd like to offer you a handover appointment with Jess, who I've briefed on your colour history, with a senior consultation included. Would Thursday at 11 suit you?"

Offer the handover, brief the new stylist properly, and follow up after the appointment.

---

## What Not to Say

- "Do you want to rebook?" — a yes-or-no question invites a no.
- "Shall I book you in for next time?" with no date or reason — it sounds like a chore, not a service.
- "You should come back in six weeks." — a suggestion, not a booking. Offer the booking.
- Anything that pressures a client who has said no. Ask once, offer a reminder, and move on gracefully.

---

## Practise This Week

1. Pair up. One person is the stylist, one is the client. Run the colour script three times until it sounds like you, not like a script.
2. Swap roles and run the cut script.
3. Practise the "cannot commit" answer — it is the one most stylists forget, and it is where the reminder system starts.
4. At the end of the week, share one rebooking that worked well and one that did not, and talk about what made the difference.
