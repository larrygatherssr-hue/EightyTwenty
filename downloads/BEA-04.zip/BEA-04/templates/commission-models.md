# Commission Models — Templates and Worked Examples

*Education only, not legal or financial advice. Pay structures must comply with minimum wage, overtime, worker-classification, and other local employment rules where you operate. Have any pay model checked by a qualified local adviser before you use it, and put the agreed terms in writing in the staff handbook.*

All worked examples use invented figures for teaching. Replace them with your own numbers and test every model against a good month and a bad month before you promise it.

---

## Model 1 — Salary or Hourly Wage

**How it works:** A fixed wage, paid regardless of how busy the month is.

**Best for:** Juniors, reception staff, part-timers, and any role where the work is steady rather than sales-led.

**Example:** A junior stylist is paid $18 an hour for 35 hours a week — about $2,730 a month before tax and deductions. The salon's cost is the wage plus payroll taxes and benefits.

**Watch out for:** A quiet stylist costs the same as a busy one, so you must manage utilisation. Pair a wage with clear expectations — hours, services, rebooking, and training — and review it regularly.

---

## Model 2 — Commission Only

**How it works:** The stylist earns a percentage of the service revenue they take, with no guaranteed base. Common percentages for employed stylists are 40 to 50 percent of service revenue.

**Worked example:** A stylist takes $7,000 in services in a month at 45 percent commission. Pay is 45 percent of $7,000 = $3,150. The salon keeps $3,850 to cover product, rent, and overhead.

**Test the bad month:** If the same stylist takes only $4,000, pay is $1,800. Check whether that meets local minimum wage rules for the hours worked — if it does not, this model is not lawful for those hours in your area, and you need a guaranteed base.

**Best for:** Experienced stylists with a full, loyal column who want their pay to reflect their takings.

**Watch out for:** Income swings with quiet weeks, which makes it hard for staff to plan; it can discourage teamwork, because helping a colleague earns nothing; and it can create disputes about who owns a client. Use it only with clear written rules about client ownership, holiday pay, and what happens in a quiet month.

---

## Model 3 — Base Plus Commission (Recommended Starting Point)

**How it works:** A guaranteed base wage plus commission on revenue above a threshold, or a percentage on everything above the base.

**Worked example — Glow & Co. mid-level stylist:** Base $2,600 a month, plus 10 percent commission on service revenue above $6,500 a month.

- Good month: stylist takes $8,400. Commission is 10 percent of ($8,400 − $6,500) = $190. Total pay: $2,790.
- Bad month: stylist takes $5,200. No commission — below the threshold. Total pay: $2,600.
- Strong month: stylist takes $10,000. Commission is 10 percent of $3,500 = $350. Total pay: $2,950.

**Check it from the salon's side (good month):** Revenue $8,400. Costs: pay $2,790, product about $730 (8.7 percent of revenue), overhead share about $1,300. Total cost $4,820. Column contribution: $3,580. The model works.

**Check it from the salon's side (bad month):** Revenue $5,200. Costs: pay $2,600, product about $450, overhead share about $1,300. Total cost $4,350. Column contribution: $850. Still positive, but thin — which tells you the base is set about right and the threshold is reachable.

**Why it works:** Security for the stylist, upside for performance, and protection for the owner. Set the threshold so a competent stylist reaches it in a normal month — if nobody ever reaches it, it is not a bonus, it is a broken promise.

---

## Model 4 — Tiered Commission

**How it works:** The commission percentage rises as revenue rises, so the reward grows with performance.

**Worked example:** Base $2,400 a month, plus 5 percent on service revenue between $6,000 and $8,000, and 12 percent on revenue above $8,000.

- Stylist takes $9,000: commission is 5 percent of $2,000 = $100, plus 12 percent of $1,000 = $120. Total commission $220. Total pay: $2,620.
- Stylist takes $7,000: commission is 5 percent of $1,000 = $50. Total pay: $2,450.

**Best for:** Salons that want to reward their top performers without raising the base for everyone.

**Watch out for:** Tiered models are harder to explain and easier to get wrong on a payslip. Write the tiers down, show the calculation on the payslip, and walk each stylist through their own numbers once.

---

## Model 5 — Retail Commission (Use Alongside Any Model Above)

**How it works:** A separate percentage on retail sales, commonly 10 to 15 percent.

**Worked example:** A stylist sells $600 of retail in a month at 10 percent. Retail commission is $60. The salon's retail margin is usually around 50 percent, so on $600 of sales the salon's gross profit is about $300 before the $60 commission — it still keeps about $240.

**Rules to set in writing:** Pay retail commission on full-price sales at the full rate; pay a lower rate, or no commission, on discounted or clearance stock; and pay it in the same month as the sale so the reward is visible.

---

## Model 6 — Chair Rental (A Different Business — Read Carefully)

**How it works:** A stylist pays you a fixed rent for the chair — for example $800 a month — and keeps what they earn from their clients, supplying their own product or buying it from you under a written agreement.

**Why it is different:** A chair renter is usually not your employee. That changes your legal duties, your tax position, your insurance, and your control over the client experience. You become, in effect, a landlord. Do not drift into chair rental by accident, and do not call someone self-employed while treating them as an employee — worker classification rules vary by state and country, and getting it wrong can be expensive.

**If you use it:** Get local legal and tax advice first. Put it in writing: the rent, what it includes, who supplies product, who owns the client and the client records, who is responsible if something goes wrong, notice periods, and what happens to the chair when the renter is away. Review the agreement every year.

---

## Choosing and Changing a Model

1. Write down the model for every role on one page.
2. Test it against a good month and a bad month for a real stylist, using their actual takings.
3. Check it against local minimum wage and employment rules.
4. Put it in the staff handbook and show each stylist their own numbers.
5. Never change commission terms mid-month. Give at least one month's written notice and explain why.
6. Review the model once a year, or whenever wages, prices, or rent change materially.

## Common Mistakes

- A threshold nobody can reach.
- Different rates for the same work with no clear, written reason.
- Changing the model without notice.
- Paying late, or paying commission without showing the calculation.
- Forgetting to count the owner's own time when testing whether a model is affordable.
