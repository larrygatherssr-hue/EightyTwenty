# Staff Handbook Template — [Salon Name]

*Adapt this template to your salon. It is a starting point, not legal advice. Employment law, worker classification, licensing, and health and safety rules vary by state and country — have your handbook checked by a qualified local employment adviser before you issue it, and keep it updated when the law or your policies change. Fill in every bracketed item; do not issue a handbook with blanks in it.*

---

## 1. Welcome

Welcome to [Salon Name]. This handbook tells you how we work, what we expect from each other, and what you can expect from us. If anything in it is unclear, ask [Owner / Manager name]. We would rather answer a question than have you guess.

Our standards are simple: be on time, be kind to clients and to each other, keep your station clean, and do good work you are proud of.

## 2. About the Salon

[Salon Name] is a [hair salon / nail salon / beauty studio] at [address]. We are open [days and hours]. Our services are [brief description]. Our clients expect [e.g. a warm welcome, a consultation before every service, and a station that is clean and ready].

## 3. Your Role

Your role is [job title]. Your main duties are:

- [Duty 1 — e.g. delivering cut and colour services to the standard in our service guide]
- [Duty 2 — e.g. consulting every client before a service and recording allergies and preferences]
- [Duty 3 — e.g. rebooking clients before they leave and recommending suitable home-care products]
- [Duty 4 — e.g. keeping your station, tools, and the shared areas clean and tidy]
- [Duty 5 — e.g. helping colleagues when your column is quiet]

Your normal working hours are [days and hours]. Your place of work is [salon address]. Any change to your hours or duties will be discussed with you first.

## 4. Pay

You are paid [hourly / salary / base plus commission — delete as applicable] as follows:

- Base pay: [amount and frequency, e.g. $2,600 per month, paid on the last working day of the month]
- Commission: [full terms, e.g. 10% of service revenue above $6,500 in a month, paid with the following month's pay]
- Retail commission: [e.g. 10% of retail sales, paid monthly]
- Overtime: [policy, e.g. overtime is paid at (rate) / time off in lieu, and must be agreed in advance]

Commission terms will not be changed mid-month. If a change is needed, you will receive at least one month's written notice and an explanation. Your payslip will show your base pay, commission, and any deductions separately. If you think your pay is wrong, tell [Owner / Manager name] straight away and we will check it together.

*Note: pay and commission structures must comply with minimum wage, overtime, and other local employment rules where you operate. Check the rules that apply to you before setting or changing pay.*

## 5. Working Hours, Rota, and Holidays

The rota is published at least two weeks in advance. If you need to swap a shift, agree it with [Owner / Manager name] first. Holidays must be requested [how, e.g. in writing at least four weeks in advance] and will be agreed subject to cover. We plan holidays a quarter ahead so everyone gets fair access to popular dates. You are entitled to [number] days of paid holiday per year, plus [public holidays / as required by local law].

If you are unwell and cannot work, tell [Owner / Manager name] by [time, e.g. 8 a.m.] on the day, by phone — not by message alone. We will arrange cover for your clients and let them know.

## 6. Attendance and Timekeeping

Please arrive in time to set up your station before your first client. If you are running late, call the salon as soon as you know. Repeated lateness will be discussed with you privately, and we will agree what needs to change.

## 7. Appearance and Hygiene

- Wear [salon uniform / smart black clothing — as applicable].
- Hair and nails should be clean and tidy. [Any specific standards, e.g. long hair tied back when working with colour.]
- Wash and sanitise hands between clients. Clean and disinfect tools after every client, following the salon's hygiene procedure and local health rules.
- Do not work if you have a contagious illness that could affect clients or colleagues — tell us and we will rearrange your column.

## 8. Client Care Standards

- Greet every client by name when you can, and offer them a drink on arrival.
- Consult before every service: what the client wants, what their hair or skin needs, any allergies or sensitivities, and the price. Record it on the client card.
- Explain the price before you start, including any extra charge for additional product or time.
- Before the client leaves, recommend their next visit date and offer to book it. Recommend one home-care product that suits what you have seen today, and only one you genuinely believe in.
- If a client is unhappy, listen, apologise for the experience, and offer to fix it. Do not argue. Tell [Owner / Manager name] the same day so we can follow up.

## 9. Retail

Retail products are [list where they are kept and how they are priced]. When you recommend a product, use the product yourself where you can, explain in one sentence what it does and who it is for, and offer to put one aside. Record every retail sale on [system]. Retail commission is paid as set out in Section 4.

## 10. Product Use and Stock

Use product as measured — weigh colour, follow the mixing guide, and do not over-pour. If stock is running low, tell [name] so it can be ordered in time. Do not take salon product home without permission. Report any damaged or faulty product straight away.

## 11. Health, Safety, and Licensing

- Follow the salon's health and safety procedures, including safe use and storage of chemicals, patch testing where required, and the use of gloves and protective equipment.
- Keep your professional licence current and give the salon a copy when it is renewed. Tell us immediately if your licence is suspended or restricted.
- Report any accident, injury, or near-miss to [Owner / Manager name] the same day, and record it in the accident book.
- Know where the first aid kit, fire exits, and fire extinguishers are. [Location details.]

## 12. Confidentiality and Client Records

Client records, including contact details, service history, and health information, are confidential. Do not share them outside the salon, do not photograph them, and do not take them with you if you leave. Client records belong to the salon. If a client asks for their records, refer them to [Owner / Manager name].

## 13. Phones, Social Media, and Photos

- Keep personal phone use to breaks, unless it is an emergency.
- Do not photograph clients without their clear permission, and do not post client photos on personal social media. Salon posts are made by [name / the salon account] with the client's written consent.
- Do not post anything online that identifies the salon or its clients in a negative way. If you are unsure, ask first.

## 14. Conduct, Performance, and Reviews

We review performance regularly — a short check-in each month and a fuller review every [six / twelve] months. Reviews cover your work, your rebooking and retail, your reliability, and your training. If something is not working, we will talk to you privately, agree what needs to change, and set a review date. We follow local employment rules and our written procedures for any formal process. If you have a concern, raise it with [Owner / Manager name] first; if that is not appropriate, raise it with [alternative contact].

## 15. Leaving

If you decide to leave, your notice period is [length, e.g. four weeks]. We will agree together how your clients will be looked after, and we will offer them a handover appointment with a colleague who has been briefed on their history. Please return all salon property, keys, and product on your last day. We wish you well, and we will give a fair reference for the work you did here.

## 16. Acknowledgement

I have received, read, and understood this handbook. I understand that it does not form part of my contract of employment unless stated, and that the salon may update it with reasonable notice.

Name: ______________________________ Signature: ______________________________ Date: ______________

Owner / Manager: ______________________ Signature: ______________________________ Date: ______________

*Review this handbook at least once a year, and whenever the law or your policies change.*
