# Salon Profit System — Companion Workbook

Use this workbook alongside the course. Every worksheet matches a module and a template file. Work in pencil or in a copy of the file first — your first pass is a draft, and the numbers get better as your records get better.

**Disclaimer:** This workbook is education only. It is not legal, tax, accounting, medical, or financial advice, and it does not guarantee any profit or business result. Employment law, licensing, tax, and consumer rules vary by state and country — check the rules where you operate and get qualified local advice where a decision matters. All example figures in this workbook are invented for teaching; always use your real figures.

---

## Worksheet 1 — The Profit Map (Module 1)

Complete for last month, using your real books.

| Item | Amount |
|---|---|
| Service revenue | $ |
| Retail revenue | $ |
| **Total revenue** | **$** |
| Product used in services | $ |
| Cost of retail goods sold | $ |
| **Total direct costs** | **$** |
| **Gross profit** | **$** |
| Stylist wages and commission | $ |
| Reception and support wages | $ |
| Payroll taxes and benefits | $ |
| **Total staff costs** | **$** |
| Rent | $ |
| Utilities | $ |
| Insurance | $ |
| Software and bookings | $ |
| Laundry and sundries | $ |
| Marketing | $ |
| Other fixed costs | $ |
| **Total fixed costs** | **$** |
| **Net profit before tax** | **$** |
| Net profit margin (net profit ÷ revenue) | % |

**The five leaks — score each from 1 (no leak) to 5 (serious leak):**

1. Empty chairs: ___
2. Low rebooking: ___
3. Weak retail: ___
4. Wrong pricing: ___
5. Staff churn: ___

**My single biggest leak, and why:** _______________________________________________

---

## Worksheet 2 — Chair Utilisation Tracker (Module 2)

Use the chair-utilisation-tracker.csv template for the weekly detail. Summarise here.

| Day | Hours open | Chairs | Available chair-hours | Booked chair-hours | Utilisation % |
|---|---|---|---|---|---|
| Monday | | | | | |
| Tuesday | | | | | |
| Wednesday | | | | | |
| Thursday | | | | | |
| Friday | | | | | |
| Saturday | | | | | |
| Sunday | | | | | |
| **Week total** | | | | | |

**Average revenue per booked chair-hour:** $______ (service revenue ÷ booked chair-hours)

**Value of ten extra points of utilisation per month:** $______ (average revenue per booked hour × available chair-hours per month × 10%)

**My quietest day:** __________ **My busiest day:** __________

**Two methods I will try for four weeks:**
1. ________________________________________________________________________
2. ________________________________________________________________________

**Utilisation by stylist:**

| Stylist | Available hours | Booked hours | Utilisation % |
|---|---|---|---|
| | | | |
| | | | |
| | | | |
| | | | |
| | | | |

---

## Worksheet 3 — Service Pricing Build-Up (Module 3)

Complete for your five most-booked services.

| Service | Time (hrs) | Product cost | Labour cost | Overhead share | Total cost | Price for 20% margin (cost ÷ 0.80) | Current price | Difference |
|---|---|---|---|---|---|---|---|---|
| 1. | | $ | $ | $ | $ | $ | $ | $ |
| 2. | | $ | $ | $ | $ | $ | $ | $ |
| 3. | | $ | $ | $ | $ | $ | $ | $ |
| 4. | | $ | $ | $ | $ | $ | $ | $ |
| 5. | | $ | $ | $ | $ | $ | $ | $ |

**My overhead per booked hour:** $______ (monthly fixed costs ÷ monthly booked chair-hours)

**Services priced below their true cost:** __________________________________________

**Price rise planned:** Service __________ from $______ to $______ on (date) __________

**How I will tell clients (four weeks' notice):** ______________________________________

---

## Worksheet 4 — Monthly P&L and Ratios (Module 4)

Copy your figures from the salon P&L calculator spreadsheet.

| Line | This month | Last month | Change |
|---|---|---|---|
| Total revenue | $ | $ | % |
| Direct costs | $ | $ | % |
| Gross profit | $ | $ | % |
| Staff costs | $ | $ | % |
| Fixed costs | $ | $ | % |
| Net profit before tax | $ | $ | % |

**The four ratios:**

| Ratio | This month | Target |
|---|---|---|
| Gross profit margin (gross profit ÷ revenue) | % | 80%+ |
| Staff cost ratio (staff costs ÷ revenue) | % | 45–55% |
| Retail share (retail revenue ÷ total revenue) | % | 10–15% |
| Net profit margin (net profit ÷ revenue) | % | 10–20% |

**Three sentences:**

- What went well: ____________________________________________________________
- What went badly: ___________________________________________________________
- What I will change this month: ________________________________________________

**One cost line to investigate:** __________________ **Why it moved:** __________________

**My own time:** Hours I worked behind the chair this month: ______ At a market-rate wage of $______/hour, that time is worth $______. My honest profit after counting my time: $______.

---

## Worksheet 5 — Staffing and the Rota (Module 5)

**My ideal staff mix:**

| Role | Number needed | Number I have | Gap |
|---|---|---|---|
| Senior stylist | | | |
| Mid-level stylist | | | |
| Junior stylist | | | |
| Reception / support | | | |
| Other: | | | |

**Rota published two weeks ahead?** Yes / No — **Next rota publish date:** __________

**Holidays booked for next quarter?** Yes / No — **Missing:** _________________________

**Freelancers / part-timers I can call for cover:** ______________________________________

**Junior training plans:**

| Junior | Mentor | Skill to learn this month | Review date |
|---|---|---|---|
| | | | |
| | | | |

---

## Worksheet 6 — Commission-Model Worksheet (Module 6)

**My current pay model, per role:**

| Role | Base / hourly | Commission | Threshold | Retail commission |
|---|---|---|---|---|
| | $ | % | $ | % |
| | $ | % | $ | % |
| | $ | % | $ | % |

**Test one stylist — good month:**

- Service revenue taken: $______
- Base pay: $______ + commission $______ = total pay $______
- Product cost: $______ + overhead share: $______ = total column cost $______
- Column contribution (revenue − total cost): $______

**Test the same stylist — bad month:**

- Service revenue taken: $______
- Base pay: $______ + commission $______ = total pay $______
- Product cost: $______ + overhead share: $______ = total column cost $______
- Column contribution (revenue − total cost): $______

**Is the model affordable in a bad month?** Yes / No — **What needs to change:** ____________

**Have I shown every stylist their own numbers this month?** Yes / No

---

## Worksheet 7 — Rebooking Audit (Module 7)

**Week of:** __________

| Stylist | Clients seen | Clients rebooked before leaving | Rebooking rate % |
|---|---|---|---|
| | | | |
| | | | |
| | | | |
| | | | |
| | | | |
| **Salon total** | | | |

**Salon rebooking rate this week:** ______% **Target:** ______%

**If we lift rebooking from ______% to ______%, that is ______ extra future bookings a month. At an average service of $______, that is about $______ of future revenue secured at the chair.**

**What I observed at the chair this week (who asks, who forgets, when it works best):**

________________________________________________________________________________

**Gap list — clients who have not visited in twice their usual interval:**

| Client | Usual service | Usual interval | Last visit | Contacted? | Rebooked? |
|---|---|---|---|---|---|
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |

---

## Worksheet 8 — Retail Plan (Module 8)

**Last month:**

- Clients seen: ______ Retail buyers: ______ **Attach rate:** ______%
- Retail revenue: $______ **Average retail spend:** $______ (revenue ÷ buyers)
- Cost of goods: $______ **Retail gross profit:** $______

**Target attach rate:** ______% **Target average spend:** $______

**At my target attach rate, extra buyers per month:** ______ **Extra gross profit per month:** $______

**My retail range — the fifteen products I genuinely recommend:**

| # | Product | Price | Who it is for (one sentence) |
|---|---|---|---|
| 1 | | $ | |
| 2 | | $ | |
| 3 | | $ | |
| 4 | | $ | |
| 5 | | $ | |
| 6 | | $ | |
| 7 | | $ | |
| 8 | | $ | |
| 9 | | $ | |
| 10 | | $ | |
| 11 | | $ | |
| 12 | | $ | |
| 13 | | $ | |
| 14 | | $ | |
| 15 | | $ | |

**Products to stop stocking (not sold in three months):** ________________________________

**Display check:** Visible from the chair? ___ Priced clearly? ___ Tidy and well-lit? ___

---

## Worksheet 9 — Retention Review (Module 9)

**Client retention — last three months:**

- Clients due to return: ______ Clients who returned: ______ **Retention rate:** ______%

**Why clients leave — what I have heard or observed:**

________________________________________________________________________________

**Complaints this month:**

| Date | What happened | What I did | Followed up? |
|---|---|---|---|
| | | | |
| | | | |
| | | | |

**Stay interviews:**

| Team member | Date | What they enjoy most | What frustrates them | One thing I will act on |
|---|---|---|---|---|
| | | | | |
| | | | | |
| | | | | |

**My loyalty offer (simple, written, same for everyone):** _______________________________

---

## Worksheet 10 — Monthly KPI Worksheet (Module 10)

Use the monthly-kpi-tracker.csv template for the running record. Summarise each month here.

| KPI | This month — actual | This month — target | Last month | Trend |
|---|---|---|---|---|
| Chair utilisation % | | | | |
| Rebooking rate % | | | | |
| Retail attach rate % | | | | |
| Average service spend $ | | | | |
| Net profit margin % | | | | |

**Monthly review — four questions:**

1. What improved? ________________________________________________________________
2. What got worse? ________________________________________________________________
3. Why? _________________________________________________________________________
4. What will I change this month? ___________________________________________________

**My one target for next month:** ____________________________________________________

**90-day plan:**

| Period | Focus | Target | Done? |
|---|---|---|---|
| Days 1–30 | Measure and fix the biggest leak | | |
| Days 31–60 | Systematise: handbook, rota, retail, gap list | | |
| Days 61–90 | Grow from strength; set the next target | | |

---

*End of workbook. Keep your completed worksheets with your monthly P&L — together they are the record of how your salon improved.*
