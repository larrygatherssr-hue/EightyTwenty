# The Profitable Pet Sitter — Launch Workbook

Use this workbook alongside the course. Print it, fill it in by hand, and keep it with your business records. Every exercise here matches a lesson in the course text.

**Health and safety note:** This workbook supports a business-operations course. It teaches routine pet care only. It does not provide veterinary advice, diagnosis, or treatment. Any health concern, injury, illness, or behavioural issue must be referred to a veterinarian or other qualified professional. If a pet shows any sign of illness, injury, or distress, contact the owner and their veterinarian immediately.

---

## 1. Your 7-Day Launch Checklist

Tick each item as you complete it. Do not skip ahead — each day builds on the last.

### Day 1 — Foundations and Legal Setup
- [ ] Business structure chosen (sole trader / LLC / company)
- [ ] Business name chosen and checked (no clash, handle available)
- [ ] Separate business bank account opened
- [ ] Local licence and permit checks completed
- [ ] Record-keeping spreadsheet or notebook started
- [ ] Startup budget written down (see Section 5)

### Day 2 — Services, Pricing, and Packages
- [ ] Four-service menu written
- [ ] Pricing built from costs (Section 2)
- [ ] Full price list written
- [ ] One package designed (weekly walks or ten-visit bundle)
- [ ] Discount rules written down
- [ ] Month-one income model completed (Section 3)

### Day 3 — Insurance, Safety, and Pet-Care Protocols
- [ ] Insurance quotes compared and policy bought
- [ ] Insurance certificate saved on phone and booking page
- [ ] Personal safety rules written (group size, off-lead, heat, keys)
- [ ] Pet care record template ready
- [ ] Emergency plan written (vet, emergency vet, owner contact)

### Day 4 — Branding and Booking Page
- [ ] Two brand colours chosen
- [ ] One-sentence brand message written
- [ ] Booking page live (services, prices, trust proof, FAQ, booking form)
- [ ] Five real photos ready
- [ ] Business social profile created

### Day 5 — Finding Clients
- [ ] Platform strategy decided
- [ ] Flyers and cards printed and placed in five local spots
- [ ] Two local online groups joined
- [ ] Launch offer defined
- [ ] Three local partners contacted
- [ ] Referral thank-you offer written down
- [ ] Marketing tracker started (Section 6)

### Day 6 — Meet-and-Greets, Booking, and Onboarding
- [ ] Meet-and-greet script practised
- [ ] Deposit and cancellation terms written
- [ ] Contract adapted and ready to send
- [ ] Onboarding checklist printed
- [ ] Booking calendar set up

### Day 7 — Launch Day
- [ ] Launch announcement posted
- [ ] Flyers placed and partners followed up
- [ ] First meet-and-greet or booking confirmed
- [ ] Thank-you and review-request messages written
- [ ] First-30-days planner filled in (Section 7)
- [ ] Weekly review date set for the next four weeks

---

## 2. Pricing Worksheet

Work through this before you set your prices. Use your own real costs.

**Step 1 — Your costs per 30-minute walk**

| Cost item | Your amount |
|---|---|
| Travel (fuel or public transport) | $______ |
| Waste bags, treats, consumables | $______ |
| Insurance (annual premium ÷ expected walks) | $______ |
| Phone, booking software, admin share | $______ |
| Wear and tear, kit replacement share | $______ |
| **Total direct cost per walk** | **$______** |

**Step 2 — Your target hourly rate**

My target hourly rate after costs: $______ per hour.
Value of my time in a 30-minute walk (half my hourly rate): $______.
My break-even-plus-earnings price (cost + time value): $______.
My final rounded price for a 30-minute walk: $______.

**Step 3 — Market check**

List three local competitors or platform sitters and their 30-minute walk price:

1. _________________________ — $______
2. _________________________ — $______
3. _________________________ — $______

Local price range: $______ to $______. My price sits: below / within / above the range (circle one). Reason: _________________________.

**Step 4 — My full price list**

| Service | Duration | My price |
|---|---|---|
| 30-minute dog walk (solo) | 30 min | $______ |
| 60-minute dog walk (solo) | 60 min | $______ |
| 30-minute group walk (max 4 dogs) | 30 min | $______ per dog |
| Drop-in visit (cats / small pets) | 30 min | $______ |
| Puppy visit | 30 min | $______ |
| Evening pet sit (owner's home) | 3 hours | $______ |
| Overnight stay (owner's home) | 12 hours | $______ |
| Extra dog, same household (walk) | — | +$______ |
| Holiday / peak surcharge | — | +______% |
| Last-minute booking (under 24 hours) | — | +$______ |

**Step 5 — My package**

Package name: _________________________.
What it includes: _________________________.
Single-service total value: $______. Package price: $______. Discount: ______%.

**My discount rules (write them and stick to them):**
1. Package discount: _________________________.
2. Multi-pet rule: _________________________.
3. Introductory offer: _________________________ (new clients only, once, end date: __________).

---

## 3. Month-One Income Model

Fill in your own numbers using your price list.

| Income | Calculation | Amount |
|---|---|---|
| Regular walks | ___ clients × ___ walks/week × $___ × 4 weeks | $______ |
| Drop-in visits | ___ visits × $___ | $______ |
| Overnight sits | ___ nights × $___ | $______ |
| Other (specify: __________) | | $______ |
| **Gross month-one income** | | **$______** |

| Costs | Amount |
|---|---|
| Insurance (monthly share) | $______ |
| Travel / fuel | $______ |
| Consumables, treats, waste bags | $______ |
| Marketing (flyers, cards) | $______ |
| Booking software / phone share | $______ |
| Tax set-aside (25% of gross) | $______ |
| **Total month-one costs** | **$______** |

**Month-one profit after costs and tax set-aside: $__________.**

Is this enough for Month 1? If not, what changes — more clients, more walks per client, or a higher-value service? Write your answer: _________________________.

---

## 4. Client Avatar Worksheet

Describe your ideal client. Be specific — a clear avatar makes your marketing ten times easier.

- Owner's name (invented, for focus): _________________________
- Age range and household: _________________________
- Area / neighbourhood: _________________________
- Pet(s): breed, age, temperament: _________________________
- Owner's situation: (works full-time / travels often / elderly / busy family — circle or write)
- What they worry about most: _________________________
- What a perfect sitter does for them: _________________________
- Where they look for a sitter: (vet board / Facebook group / Google / friend — circle)
- What would make them book with me instead of a platform: _________________________
- What would make them book again every week: _________________________

**My top three client types to target first:**
1. _________________________
2. _________________________
3. _________________________

---

## 5. Startup Budget

| Item | Estimated cost | Actual cost |
|---|---|---|
| Business registration / licence | $______ | $______ |
| Pet business insurance (first month) | $______ | $______ |
| Booking page / website | $______ | $______ |
| Business cards and flyers | $______ | $______ |
| Leashes, treat pouch, waste bags, kit | $______ | $______ |
| Accounting spreadsheet or app | $______ | $______ |
| **Total** | **$______** | **$______** |

---

## 6. Marketing Tracker

Log every enquiry. After 30 days, count which channel brought the most bookings and spend your time there.

| Date | Enquiry from (name) | Service wanted | Source (flyer / vet / group / referral / platform / other) | Became a booking? | Fee |
|---|---|---|---|---|---|
| | | | | | $ |
| | | | | | $ |
| | | | | | $ |
| | | | | | $ |
| | | | | | $ |
| | | | | | $ |
| | | | | | $ |
| | | | | | $ |
| | | | | | $ |
| | | | | | $ |

**30-day review:** Total enquiries: ______. Total bookings: ______. Best channel: _________________________. Worst channel: _________________________. What I will do more of: _________________________.

---

## 7. First-30-Days Planner

**Week 1 (Days 1–7): Launch**
- Goal: ______ clients. Marketing actions (one per day): _________________________.
- Meet-and-greets booked: ______.

**Week 2 (Days 8–14): Serve and Ask**
- Bookings delivered: ______. Reviews collected: ______. Referrals asked for: ______.
- What took longer than planned? _________________________.
- What I will change: _________________________.

**Week 3 (Days 15–21): Build Regularity**
- Regular weekly clients: ______. Packages sold: ______.
- Partners contacted again: ______. Social posts made: ______.

**Week 4 (Days 22–30): Review and Plan**
- Total enquiries: ______. Total bookings: ______. Gross income: $______.
- Costs: $______. Profit: $______.
- Best-earning service per hour: _________________________.
- Month 2 target: ______ new regular clients, ______ new partnership.

**Weekly review dates (set all four now):** __________ / __________ / __________ / __________.

---

## 8. Pet Care Record (copy one per client)

- Owner name: _________________________ Phone: _________________________
- Emergency contact: _________________________ Phone: _________________________
- Pet name: _________________________ Breed: _________________________ Age: ______
- Vet name and phone: _________________________
- Emergency vet and phone: _________________________
- Feeding (food, amount, times): _________________________
- Medication (vet-prescribed only, dose, time, method): _________________________
- Allergies / foods to avoid: _________________________
- Walk routine and off-lead permission: _________________________
- Behaviour notes (fears, reactivity, escape attempts): _________________________
- House rules, alarm code, key arrangements: _________________________
- Photo permission (social media): Yes / No (circle one)

**Remember:** record every dose of medication given, with the time. Report any change in eating, drinking, toileting, movement, or behaviour to the owner promptly. Any health concern goes to the veterinarian — never diagnose or treat yourself.

---

*Workbook complete. Keep your filled-in copy with your business records and update the trackers weekly.*
