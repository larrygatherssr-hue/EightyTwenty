# Booking Template — The Profitable Pet Sitter

Copy this form for every booking. A booking is confirmed only when the signed service agreement and the deposit have both been received.

---

## Booking Details

| Field | Details |
|---|---|
| Booking reference | [e.g. 2026-11-001] |
| Date booking taken | |
| Owner name | |
| Owner phone | |
| Owner email | |
| Owner address | |
| Emergency contact (name + phone) | |
| Pet name(s) | |
| Pet species / breed / age | |
| Vet name + phone | |
| Emergency vet + phone | |

## Services Booked

| Date | Service | Time | Fee |
|---|---|---|---|
| e.g. Mon 10 Nov 2026 | 30-minute dog walk | 12:00 | $22.00 |
| | | | $ |
| | | | $ |
| | | | $ |
| | | | $ |
| | | | $ |
| | | | $ |
| | | | $ |
| **Total fee** | | | **$** |
| Deposit paid (25–50%) | Date: ______ Method: ______ | | $ |
| Balance due | Date: ______ | | $ |
| Balance paid | Date: ______ Method: ______ | | $ |

## Care Summary (from the Pet Care Record)

- Feeding (food, amount, times): _______________________________________________
- Medication (vet-prescribed only — name, dose, time, method): _______________________________________________
- Allergies / foods to avoid: _______________________________________________
- Walk routine and off-lead permission: _______________________________________________
- Behaviour notes (fears, reactivity, escape attempts): _______________________________________________
- House rules, alarm code, key arrangements: _______________________________________________
- Photo permission (social media): Yes / No

## Checklist

- [ ] Meet-and-greet completed on: __________
- [ ] Pet Care Record completed and attached
- [ ] Service agreement signed on: __________
- [ ] Deposit received on: __________
- [ ] Booking confirmed in writing to owner on: __________
- [ ] Key / access collected on: __________ (method: __________)
- [ ] Pre-visit reminder sent on: __________
- [ ] Balance received on: __________
- [ ] Booking completed on: __________
- [ ] Photo updates sent: __________
- [ ] Key returned on: __________ (method: __________)
- [ ] Thank-you message sent on: __________
- [ ] Review requested on: __________

## Visit Log (one row per visit — complete during the booking)

| Date + time | Service | Pet ate? | Pet drank? | Toileting normal? | Behaviour / mood | Photo sent? | Notes / anything unusual |
|---|---|---|---|---|---|---|---|
| | | Yes / No | Yes / No | Yes / No | | Yes / No | |
| | | Yes / No | Yes / No | Yes / No | | Yes / No | |
| | | Yes / No | Yes / No | Yes / No | | Yes / No | |
| | | Yes / No | Yes / No | Yes / No | | Yes / No | |
| | | Yes / No | Yes / No | Yes / No | | Yes / No | |

**Health reminder:** This log records routine observations only. Any health concern, injury, illness, or behavioural issue must be reported to the owner and referred to a veterinarian or other qualified professional. Do not diagnose or treat. If a pet shows any sign of illness, injury, or distress, contact the owner and the vet immediately and record what happened, with times.

## Cancellation Terms (as in the service agreement)

- More than 14 days before the first service date: full refund of the deposit.
- 7–14 days before: 50% refund of the deposit.
- Within 7 days: no refund of the deposit.
- Peak periods (Christmas, New Year, public holidays, school holidays): full-refund window 30 days, 50% window 14–30 days.
