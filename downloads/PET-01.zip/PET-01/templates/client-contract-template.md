# Pet Sitting Service Agreement

**IMPORTANT:** This is a general template for a pet sitting and dog walking business. It is not legal advice. Laws, licensing, and consumer-protection rules vary by location. Have this agreement reviewed by a qualified local adviser or attorney before using it, and adapt it to your local requirements.

---

**Between:**

- **The Sitter:** [Your business name], [your full name], of [your address], phone [your phone], email [your email] ("the Sitter")
- **The Owner:** [Owner's full name], of [owner's address], phone [owner's phone], email [owner's email] ("the Owner")

**The Pet(s):**

| Pet name | Species / breed | Age | Colour / markings |
|---|---|---|---|
| | | | |
| | | | |

Veterinarian: [Name, practice, address, phone]
Emergency veterinarian: [Name, address, phone]
Emergency contact (if Owner unreachable): [Name, relationship, phone]

## 1. Services and Dates

The Sitter agrees to provide the following services:

- Service type: [e.g. 30-minute dog walk / drop-in visit / overnight stay in Owner's home]
- Dates: from [start date] to [end date]
- Times: [e.g. weekdays at 12:00 midday]
- Location: [Owner's home address / agreed walking area]
- Agreed fee: $[amount] in total, made up of [e.g. 10 × 30-minute walks at $22 = $220]

The full service details, feeding instructions, medication instructions, exercise routine, and house rules are set out in the Pet Care Record attached to this agreement, which forms part of it.

## 2. Payment

A deposit of $[amount] ([25–50]% of the total fee) is due on signing this agreement to confirm the booking. The balance of $[amount] is due by [date — e.g. 7 days before the first service date, or 14 days before for holiday periods]. Payment is by [bank transfer / card payment link]. The booking is not confirmed until the signed agreement and the deposit have both been received.

## 3. Cancellation

- Cancellation more than 14 days before the first service date: full refund of the deposit.
- Cancellation 7–14 days before: 50% refund of the deposit.
- Cancellation within 7 days: no refund of the deposit.
- For peak periods (Christmas, New Year, public holidays, school holidays), the full-refund window is 30 days instead of 14, and the 50% window is 14–30 days.
- If the Sitter must cancel, the full amount paid will be refunded and the Sitter will, where possible, recommend an alternative sitter.

## 4. The Owner's Responsibilities

The Owner confirms that:

- (a) They are the legal owner of the pet(s) or are authorised to arrange care for them.
- (b) The pet(s) are up to date with vaccinations and flea and worm treatment where applicable, and the Owner will provide proof if asked.
- (c) They have disclosed, in writing in the Pet Care Record, any medical condition, medication, allergy, behavioural issue, bite history, aggression, fear, or escape tendency affecting the pet(s). Failure to disclose a known bite history or aggression may end this agreement immediately.
- (d) They will provide enough food, medication, and supplies for the full booking, plus clear written instructions.
- (e) They will make sure the Sitter has lawful access to the home (keys, codes, or lockbox) as agreed, and that the home is safe for the Sitter to enter.

## 5. Veterinary Care — Authorisation and Costs

The Sitter provides routine care only: feeding, walking, play, company, and reminders for medication a veterinarian has already prescribed, given exactly as the Owner has instructed in writing. The Sitter does not diagnose, treat, or advise on any health condition.

If a pet shows signs of illness, injury, or distress, the Sitter will contact the Owner immediately and, where needed, the pet's veterinarian. If the Owner cannot be reached and the veterinarian advises treatment, the Owner authorises the Sitter to seek veterinary care and agrees to pay all veterinary costs incurred, including emergency treatment. The Sitter will keep receipts and records of any treatment and inform the Owner as soon as possible.

**Health disclaimer:** Nothing in this agreement or in any course, workbook, or material provided by the Sitter is veterinary advice. Any health concern, injury, illness, or behavioural issue must be referred to a veterinarian or other qualified professional.

## 6. Keys and Home Access

The Owner will provide [number] set(s) of keys / access codes on [date, method — e.g. in person at the meet-and-greet]. Keys will be tagged with a code, not with the Owner's name or address, and will be returned on [date, method] or stored securely as agreed. The Sitter will lock up as instructed and will confirm by message when leaving the home secure. The Sitter will not give keys or access codes to any other person without the Owner's written permission, and will not enter the home outside the agreed times except in an emergency.

## 7. Liability

The Sitter holds pet business insurance, details of which are available on request, and will take reasonable care of the pet(s) and the Owner's home. The Sitter's liability for any loss or damage is limited to the total fee paid under this agreement, except where the law does not allow such a limit. The Owner is responsible for any damage or injury caused by their pet where the Sitter was not negligent and the pet's behaviour had not been disclosed under Clause 4(c). Nothing in this agreement limits liability for death or personal injury caused by negligence, or any other liability that cannot legally be limited.

## 8. Photos and Social Media

The Sitter may take photos of the pet(s) for the Owner's own updates during the booking. The Sitter will only post photos of the pet(s) on social media, a website, or marketing material if the Owner has ticked "Yes" below. The Owner's name, address, and home will never be shown.

Photo permission for social media / marketing: Yes [ ] / No [ ] (Owner to tick one)

## 9. Changes, Emergencies, and Early Return

If the Owner returns early or changes the booking, they will tell the Sitter as soon as possible; fees for services already provided or for dates within the cancellation window in Clause 3 remain payable. If an emergency affects the home (for example, a leak or break-in), the Sitter will make the home safe where it is reasonable to do so, contact the Owner immediately, and contact the emergency services if needed.

## 10. Governing Law

This agreement is governed by the laws of [your state / country]. Any dispute will first be addressed by discussion between the parties.

---

**Signed:**

Owner: _________________________ Date: __________

Sitter: _________________________ Date: __________

**Attached:** Pet Care Record (one per pet or per household, completed at the meet-and-greet).
