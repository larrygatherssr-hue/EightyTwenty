# Meet-and-Greet Script — The Profitable Pet Sitter

Use this script at every first visit with a new client. It takes 30–45 minutes. Bring a printed copy, the Pet Care Record from the workbook, and a pen. Tick each item as you cover it.

## Before You Arrive

- [ ] Confirm the time, address, and phone number by message the day before.
- [ ] Ask for the basics in advance: pet's name, breed, age, temperament, medical conditions, medication, feeding routine, exercise needs, behaviour concerns.
- [ ] Check the route and allow travel time. Arrive 5 minutes early, not 20 minutes early.
- [ ] Charge your phone. Bring treats (ask first before feeding), waste bags, and your kit.

## Opening (2 minutes)

"Hello, thank you for inviting me. I am [your name] from [business name]. I would love to meet [pet's name] and hear all about their routine, so I can look after them exactly the way you do. I will take some notes as we go — that becomes their care record, so nothing gets missed. Shall we start with [pet's name]?"

Let the pet approach you. Do not rush to pick up a cat or lean over a nervous dog. Offer a calm greeting and let the owner guide the introduction.

## Part 1 — The Pet (10 minutes)

Ask, and write the answers on the Pet Care Record:

1. What is [pet's name]'s daily routine — feeding times, amounts, and food brand?
2. Any allergies, foods to avoid, or sensitive stomach?
3. Any medical conditions, medication, or recent vet visits? (Medication: name, dose, time, method — and confirm it was prescribed by a vet.)
4. When was [pet's name] last at the vet, and is everything up to date with vaccinations and flea/worm treatment?
5. How much exercise do they need, and what do they enjoy — walks, play, garden time?
6. Are they good with other dogs, children, and strangers? Any fears (thunder, fireworks, traffic, men, hats)?
7. Any behaviour I should know about — barking, chewing, digging, escaping, guarding food or toys?
8. Has [pet's name] ever bitten anyone or another animal? (Ask directly and kindly. If the answer is yes, ask for the full circumstances.)
9. How do they behave when left alone — any separation anxiety, howling, or destructive behaviour?
10. What does a happy, normal day look like for them — and what would tell me something is wrong?

**Watch and note:** How does the pet behave with you? Relaxed, curious, shy, fearful, reactive? Does the owner seem to know the pet well, or are they vague about routine and health? Vague answers are a reason to ask more, not a reason to rush.

## Part 2 — The Home and the Practical Details (10 minutes)

11. Walk me through a typical visit: where is the food, the lead, the litter tray, the garden door?
12. Where does [pet's name] sleep, and are there rooms they should not enter?
13. How do I get in — key, code, lockbox? Who else has a key?
14. Alarm system? Show me how to set and unset it, and the code.
15. Where is the fuse box, water stopcock, and any instructions for heating or appliances I might need?
16. Rubbish and recycling — anything I need to put out while you are away?
17. Any repairs, hazards, or things I should be careful with in the home or garden (loose gate, broken fence, steep stairs)?
18. Vet details: name, address, phone — and the nearest emergency vet, if different.
19. Emergency contact: who can make decisions if I cannot reach you?
20. How do you want me to contact you while you are away — text, WhatsApp, call — and how often?

## Part 3 — Services, Prices, and Expectations (5 minutes)

21. Confirm the service, dates, times, and fee. State the price clearly and confirm the deposit and balance dates.
22. Explain your cancellation policy in one sentence.
23. Explain photo updates: "I send a photo and a short update after every visit, so you can see how [pet's name] is doing."
24. Confirm key return: when and how the key comes back.
25. Confirm the contract: "I will send the booking form and service agreement today. Once it is signed and the deposit is paid, your dates are confirmed."
26. Photo permission: "May I share photos of [pet's name] on my business page, or would you prefer I keep them just for you?"

## Closing (2 minutes)

"Thank you — I have everything I need. I will send the agreement and booking confirmation today, and a reminder message the day before I start. If anything changes about [pet's name]'s routine before then, just message me. It was lovely to meet you both."

Send a thank-you message the same day, and send the contract and booking form within 24 hours.

## Red Flags — Pause, Ask More, or Decline

Take any of these seriously. One red flag is a reason to ask more questions; two or more is a reason to decline politely.

- [ ] Owner will not give vet details, or says the pet has not seen a vet in years.
- [ ] Owner minimises a bite history ("it was only a nip") or will not answer the question.
- [ ] Dog shows sustained aggression, fear-biting, or uncontrollable reactivity that is beyond your experience.
- [ ] Owner pressures you to skip the contract, skip insurance, or work without a meet-and-greet.
- [ ] Home feels unsafe, or you are asked to enter at night for a first visit with no one else present.
- [ ] Pet's needs exceed your skill (specialist medical care, complex behavioural work) — refer to a vet or qualified professional instead.
- [ ] Owner asks you to do something you know is unsafe or unlawful (off-lead on a busy road, leaving a dog in a car, giving unprescribed medicine).
- [ ] Payment terms are refused, or the owner insists on paying only in cash with no record.

**How to decline politely:** "Thank you for your time. Having met [pet's name], I do not think I am the right sitter for their needs, and I would rather be honest about that than let you down. Your vet may be able to recommend a sitter or behaviourist who specialises in this. I wish you and [pet's name] all the best."

## After the Visit

- [ ] Complete the Pet Care Record the same day while it is fresh.
- [ ] Send the thank-you message and the contract within 24 hours.
- [ ] File your notes with the client's record. Note anything to follow up on.
