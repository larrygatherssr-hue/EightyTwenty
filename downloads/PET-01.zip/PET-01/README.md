# PET-01 — The Profitable Pet Sitter: Launch Your Dog Walking & Pet Sitting Business in 7 Days

**Price:** $297 (one-time) · **Category:** Pet Products & Pet Business · **Tier:** Professional

## Files

| File | What it is |
|---|---|
| `content.md` | Full course text — 26 lessons organised as a 7-day launch plan (10,333 words) |
| `workbook.md` | 107-page launch workbook — checklists, pricing worksheet, client avatar worksheet, marketing tracker, first-30-days planner, startup budget, pet care records |
| `templates/pricing-calculator.csv` | Pricing calculator — cost build-up, price list with margins, package pricing, month-one income model, break-even check |
| `templates/client-contract-template.md` | Pet sitting service agreement (general template — review locally before use) |
| `templates/meet-and-greet-script.md` | Meet-and-greet script — 26 questions, visit plan, red-flags list |
| `templates/booking-template.md` | Booking form — payment tracking, visit log, checklist from meet-and-greet to key return |
| `sales-page.md` | Sales page — headline, problem, solution, what's inside, who it's for / not for, price, FAQ, disclaimers |
| `listing.json` | Marketplace listing data (SKU PET-01, price_cents 29700, one-time billing) |
| `cover.md` | Cover design brief (black-and-gold luxury branding) |
| `cover.png` | Generated product cover image |
| `onboarding.md` | Buyer onboarding — what to do first, how to use the materials, 7-day schedule, support |
| `README.md` | This file — index of the product's files |

## Notes

- All content is original. No testimonials, sales figures, certifications, or reviews are fabricated.
- Pet health/safety disclaimer appears in content.md, workbook.md, and sales-page.md: the course teaches business operations and routine care only — any health concern, injury, or behavioural issue must be referred to a veterinarian or qualified professional.
- The contract template is a general template, not legal advice; buyers are told to have it reviewed locally before use.
