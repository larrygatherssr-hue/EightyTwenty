# The Profitable Pet Sitter
## Launch Your Dog Walking & Pet Sitting Business in 7 Days

### Welcome

You love animals. You have probably already walked a neighbour's dog, fed a friend's cat while they were away, or looked after a puppy for a weekend — and you may have done it for free, or for far less than it was worth. This course turns that skill into a real business: a pet sitting and dog walking service that pays you properly, on your own schedule, from your own home, with no premises and no large startup capital.

Over the next seven days you will build the whole business, one day at a time. Day 1 covers foundations and legal setup. Day 2 covers services, pricing, and packages. Day 3 covers insurance, safety, and pet-care protocols. Day 4 covers branding and your booking page. Day 5 covers finding clients beyond the big platforms. Day 6 covers meet-and-greets, booking, and client onboarding. Day 7 is launch day — your first client, and your plan for the first 30 days.

There are 26 lessons in total. Each lesson is short, practical, and ends with something to do. By the end of Day 7 you will have a named business, a price list, insurance in place, a booking page, a way for clients to find you, and a plan to win your first paying client. The companion workbook gives you the checklists and worksheets to match; the templates give you a pricing calculator, a client contract, a meet-and-greet script, and a booking form you can use from your very first client.

A note on honesty: this course teaches you how to run a pet sitting and dog walking business. It does not make you a veterinarian, a veterinary nurse, a dog trainer, or a behaviourist, and nothing in it should be treated as veterinary advice. You will learn routine care — feeding, walking, play, medication reminders for medicines a vet has already prescribed, and recognising when something is wrong — but you will never diagnose, treat, or advise on a health condition. Any health concern, injury, illness, or behavioural issue must be referred to a veterinarian or other qualified professional, and you must contact the pet's owner and, where needed, their vet immediately. That rule protects the pet, the owner, and you. It appears again in the safety lessons and in the client contract, because it is the single most important professional boundary in this business.

You do not need experience running a business. You do not need a van, a shop, or a team. You need reliability, warmth, common sense, and a willingness to follow the plan day by day. Let us begin.

---

# DAY 1 — Business Foundations and Legal Setup

## Lesson 1: The Business You Are Actually Building

A pet sitting and dog walking business is a service business, which means your product is trust. Owners hand you their house keys and the animal they love most in the world. They are not buying a walk; they are buying the confidence that their dog will come home safe, their cat will be fed on time, and their home will be exactly as they left it. Every decision in this course — pricing, insurance, contracts, communication — exists to build and protect that trust.

There are three main ways people earn in this field, and most successful sitters combine all three. Dog walking is regular, repeatable work: the same dogs, the same times, every weekday. A midday walk for a working owner is the backbone of most pet businesses because it repeats five times a week and rarely cancels. Pet sitting is visit-based care in the owner's home: feeding, letting out, play, and company while the owner is at work or away. House sitting and overnight care is the highest-value service: you stay in the owner's home, or the pet stays with you, and you charge a full day rate rather than an hourly one.

The economics are straightforward. Imagine you charge $20 for a 30-minute walk. Four walks a day, five days a week, is $400 a week, or about $1,600 a month from walking alone. Add two weekend overnight sits a month at $75 a night and that is another $300. Add a handful of drop-in visits at $25 each and you are comfortably past $2,000 a month working part-time hours, before you have hired anyone or rented anything. Full-time sitters who build a regular client base of 20 to 30 households commonly earn far more, but the point of this course is not a fantasy income figure. It is a real, repeatable first month: a small number of regular clients, priced properly, served well, who book again.

Your first decision is how much time you genuinely have. Be honest with yourself now, because overpromising is the fastest way to lose a client. If you have two free hours at midday, you can walk four dogs. If you have evenings and weekends, overnight sits and weekend walks are your market. If you are free all day, you can build a full walking round. Write your real availability down in the workbook before you go further, because your services, your prices, and your marketing all follow from it.

**Your action:** Write down your weekly availability in hours, and circle the three time slots you can reliably offer every week.

## Lesson 2: Choosing Your Business Structure and Name

In most places you can start as a sole trader (also called a sole proprietor), which means you and the business are the same legal entity: simple to set up, simple to keep records for, and the right choice for most people starting out. The alternative is forming a limited company or LLC, which separates your personal assets from the business. That separation can be valuable once you are earning regularly or hiring help, but it adds paperwork and cost. For your first 30 days, sole trader status is usually enough; you can incorporate later when the income justifies it. Whatever you choose, check the rules where you live — registration, tax, and licensing requirements vary by city, state, and country, and a quick check with your local authority or a small-business adviser is time well spent.

Your business name matters more than most beginners think. It will appear on your booking page, your insurance, your contracts, and every message you send. A good name is short, warm, local, and clear about what you do. "Happy Tails Pet Care — Springfield" tells an owner everything in five words. Avoid names that are hard to spell, hard to pronounce, or that promise something you cannot deliver. Before you settle on a name, check three things: that no other pet business in your area already uses it, that the social media handle and a simple web address are available, and that it does not clash with a registered trademark. A ten-minute search now saves a painful rename later.

You will also need a separate business bank account, or at minimum a separate account you use only for business money. Mixing business and personal spending is the single most common bookkeeping mistake new sitters make, and it turns a simple tax return into a miserable weekend. Open the account on Day 1, even before your first client. From today, every payment in and every expense out goes through it.

Finally, set up a simple record-keeping habit: a spreadsheet or notebook where you log every booking (date, client, service, fee), every expense (fuel, treats, insurance, advertising), and every payment received. Your future self, and your tax return, will thank you.

**Your action:** Choose your business name, check it is free to use, and open a separate business bank account.

## Lesson 3: Licences, Local Rules, and What You Must Check Before You Take a Booking

Pet sitting is lightly regulated in many places and tightly regulated in others, and the rules are local. Before you accept a single paying client, check the following for your area: whether your city or county requires a business licence for pet services; whether boarding animals in your own home requires a separate licence or home-boarding permit (in many places it does, and it is different from sitting in the owner's home); whether there are limits on the number of dogs you may walk at once; and whether your home insurance or tenancy agreement restricts running a business or keeping animals at your address.

The home-boarding point deserves emphasis. Sitting in the owner's home and boarding a pet in your home are different services with different rules. Many beginners start with owner's-home sitting and dog walking precisely because those services usually need no special premises licence. If you want to board pets at your house later, check the local requirements first and add it as a second phase, not a Day 1 promise.

You should also check whether your area has rules about dogs in public spaces: leash laws, restricted breeds, and limits on group walks. A group walk of six dogs sounds efficient until you learn your local park caps group walks at four. Know the limit before you sell the service.

None of this is meant to frighten you. The checks take an afternoon, and in most areas the answer is simply "register your business, get insurance, and go." But a sitter who has done the checks can answer an owner's question — "Are you licensed and insured?" — with a confident yes, and that confidence wins bookings.

**Your action:** Contact your local authority (or check its website) and write down exactly which licences or permits apply to dog walking and in-owner's-home pet sitting in your area.

## Lesson 4: Setting Up Your Business Basics — Money, Records, and Your First Week Budget

Let us put real numbers on the startup. A pet sitting business is one of the cheapest businesses you can start, but "cheap" is not "free," and knowing the costs in advance stops surprises. Here is a realistic first-month startup list for a solo sitter:

| Startup item | Estimated cost |
|---|---|
| Business registration / licence (if required) | $0–$100 |
| Pet business insurance (annual, paid monthly) | $30–$60 per month |
| Basic website or booking page | $0–$20 per month |
| Business cards and flyers (first print run) | $40–$80 |
| Leashes, treat pouch, waste bags, basic kit | $50–$100 |
| Phone and messaging apps | $0 (use what you have) |
| Accounting spreadsheet or app | $0–$15 per month |
| **Total first-month startup** | **$120–$375** |

Compare that with the income model from Lesson 1. Even at the top of that range, a single weekend of overnight sits can cover your entire startup cost. That is why this business works: low cost in, steady repeat income out.

Set two financial rules now. First, pay yourself a simple way: transfer a fixed amount to your personal account each week once money starts coming in, and leave the rest in the business account for expenses and tax. Second, set aside tax from the start. A simple rule is to move 20 to 25 percent of every payment into a separate savings pot labelled "tax" the day it arrives. Tax rates vary by location and income, so confirm the right percentage for your situation, but the habit matters more than the exact number: money set aside is never money you have already spent.

Your pricing must cover more than your time. Every walk has costs: fuel or travel, waste bags, treats, wear on your shoes and phone, insurance spread across each booking, and the unpaid time spent messaging owners, planning routes, and doing meet-and-greets. Lesson 6 will build your prices from these costs up, so that your rates are profitable rather than guessed.

**Day 1 checklist:**
- [ ] Business structure chosen and registered if required
- [ ] Business name chosen and checked
- [ ] Separate business bank account opened
- [ ] Local licence and rule checks completed and noted
- [ ] Record-keeping spreadsheet or notebook started
- [ ] Startup budget written down and funded

---

# DAY 2 — Services, Pricing, and Packages

## Lesson 5: Designing Your Service Menu

A confused owner does not book. Your service menu should fit on one page and answer three questions in seconds: what do you do, how long does it take, and what does it cost? Offer four core services to start, and resist the urge to list everything you could possibly do. You can add services later; a short, clear menu wins more bookings than a long, confusing one.

Your four core services are: (1) dog walking — 30-minute and 60-minute walks, solo or small group; (2) drop-in visits — 20 to 30 minutes in the owner's home for feeding, letting out, play, and litter or garden care, ideal for cats and small animals; (3) pet sitting in the owner's home — longer daytime or evening sits; and (4) overnight care — staying in the owner's home overnight, or boarding in your home if you are licensed for it. To these you can add simple extras: extra dog from the same household, puppy visits, medication reminders for vet-prescribed medicine, and photo updates.

Define the boundaries of each service in writing. A 30-minute walk is 30 minutes of walking, not 30 minutes including ten minutes of driving each way. A drop-in visit includes feeding, fresh water, a garden break, play, and a quick tidy of food bowls and litter trays. Overnight care includes an evening walk, a morning walk, feeding, and company through the night. When the boundaries are written down, owners know what they are buying and you know what you are delivering — and neither side is disappointed.

Think about which services fit your availability from Lesson 1. Midday walkers should lead with dog walking. Evening-and-weekend sitters should lead with overnight care. Cat owners are an underserved market: many sitters focus on dogs, so a sitter who genuinely likes cats and offers reliable drop-in visits can win loyal clients quickly.

**Your action:** Write your four-service menu with a one-sentence description and a time length for each service.

## Lesson 6: Pricing — Building Your Rates from Costs Up (Full Pricing Build-Up)

This is the lesson that makes or breaks your income. Most beginners copy a competitor's price or pick a number that "sounds fair." Do it properly instead: build your price from your costs, add your target hourly earnings, and then check the result against local market rates.

**Step 1 — Work out your true cost per service.** Take a 30-minute dog walk. Your costs might look like this:

| Cost item (per 30-minute walk) | Amount |
|---|---|
| Travel (fuel or public transport) | $2.50 |
| Waste bags, treats, consumables | $0.75 |
| Insurance (annual premium divided by expected walks) | $1.25 |
| Phone, booking software, admin share | $1.00 |
| Wear and tear, kit replacement share | $0.50 |
| **Total direct cost per walk** | **$6.00** |

**Step 2 — Decide your target hourly rate.** This is what your time is worth after costs. A realistic starting target for a new sitter is $25 to $35 per hour of active service time. A 30-minute walk is half an hour, so at $30 an hour your time is worth $15. Add your $6.00 of costs and your break-even-plus-earnings price is $21. Round it to a clean, marketable number: $20 or $22.

**Step 3 — Check the local market.** Search dog walking prices in your town or city. If most sitters charge $18 to $25 for a 30-minute walk, $22 sits comfortably in the range. If the local range is $15 to $18, you need to decide whether to match it while you build reviews, or price slightly higher and justify it with solo walks, photo updates, and a professional contract. Never price far below the market to "win" clients — you will fill your diary with work that does not pay, and raising prices later with those same clients is painful.

Here is a complete example price list built the same way, for a sitter in a mid-sized town. Adjust every number to your own costs and local market:

| Service | Duration | Price | Notes |
|---|---|---|---|
| 30-minute dog walk (solo) | 30 min | $22 | One dog; additional dog from same home +$8 |
| 60-minute dog walk (solo) | 60 min | $35 | Additional dog from same home +$12 |
| 30-minute group walk (max 4 dogs) | 30 min | $18 per dog | Only for social, well-behaved dogs |
| Drop-in visit (cats / small pets) | 30 min | $25 | Feeding, water, litter, play, photos |
| Puppy visit | 30 min | $25 | Toilet breaks, feeding, play, socialisation |
| Evening pet sit (owner's home) | 3 hours | $55 | Includes walk, feeding, company |
| Overnight stay (owner's home) | 12 hours | $85 | Evening + morning walk, feeding, overnight |
| Overnight stay (second night onward) | 12 hours | $75 | Discounted rate for multi-night bookings |
| Holiday / peak surcharge | — | +20% | Christmas, New Year, public holidays |
| Last-minute booking (under 24 hours) | — | +$10 | If you can fit it in |

**Step 4 — Build packages.** Packages turn one-off bookings into regular income. A weekly walking package — five 30-minute walks for $95 instead of $110 — saves the owner money and guarantees you five bookings a week. A ten-visit drop-in bundle for cat owners works the same way. Price packages at a 10 to 15 percent discount on the single-service rate: enough to reward commitment, small enough that your margin survives.

**Step 5 — Review quarterly.** Your costs will rise and your experience will grow. Review your prices every three months, and raise them modestly (5 to 10 percent) with at least 30 days' notice to regular clients. Clients accept a small, well-explained rise from a sitter they trust; they do not accept a sudden jump.

**Your action:** Complete the pricing worksheet in the workbook using your own costs, and write your final price list.

## Lesson 7: Packages, Discounts, and the Art of Not Undercharging

Discounts are a tool, not a habit. A discount that wins a regular weekly client is an investment. A discount given because you felt awkward naming your price is a leak. Decide your discount rules now, write them down, and stick to them.

Good discounts: a package discount for weekly or monthly commitment (10 to 15 percent); a small discount for a second pet from the same household (your travel cost does not double, so you can afford it); an introductory offer for a first booking — for example, 20 percent off the first walk — used once, for new clients only, to lower the barrier to trying you. Bad discounts: open-ended "friends and family" rates that quietly become your real price; matching a competitor's low price without knowing their costs; and discounting because an owner haggled. A polite answer to haggling is: "My rates reflect insured, professional care with photo updates and a written agreement. I do keep a weekly package that works out cheaper per walk — would that help?"

Never work for free beyond one short introductory meet-and-greet (Lesson 20). Free walks to "get exposure" are the pet-care version of working for exposure in any other trade: the exposure does not pay, and the client who got it free will expect it free forever.

One more rule: charge for your time, including the time owners do not see. A meet-and-greet takes 30 to 45 minutes plus travel. Replying to messages, updating your booking calendar, and sending photo updates are real work. Your prices already account for some of this through the admin share in Lesson 6 — trust the maths, and do not apologise for it.

**Your action:** Write your discount rules: one package discount, one multi-pet rule, one introductory offer, and nothing else.

## Lesson 8: Your Month-One Income Model — Real Numbers

Let us model a realistic first month, so you know what "success" looks like and can plan around it. This is an illustration using the price list from Lesson 6, not a promise — your numbers will depend on your area, your availability, and how hard you market in Week 1.

**Assumptions:** You are available weekday middays and some weekends. You win 4 regular walking clients in Week 1, each booking 3 walks a week, and 2 overnight sits over the month.

| Income | Calculation | Amount |
|---|---|---|
| Regular walks | 4 clients × 3 walks × $22 × 4 weeks | $1,056 |
| Drop-in visits (cats, ad hoc) | 8 visits × $25 | $200 |
| Overnight sits | 2 nights × $85 | $170 |
| **Gross month-one income** | | **$1,426** |

| Costs | Amount |
|---|---|
| Insurance (monthly share) | $45 |
| Travel / fuel | $120 |
| Consumables, treats, waste bags | $30 |
| Marketing (flyers, cards) | $60 |
| Booking software / phone share | $20 |
| Tax set-aside (25% of gross) | $357 |
| **Total month-one costs** | **$632** |

**Month-one profit after costs and tax set-aside: $794.** That is a realistic first month from a standing start with four regular clients. Month two grows because regular clients repeat and refer friends; a sitter who reaches 10 regular weekly clients and a steady flow of sits is looking at $2,500 to $3,500 a month gross. The model is in the pricing calculator so you can change every number and see your own version.

**Day 2 checklist:**
- [ ] Four-service menu written with descriptions and durations
- [ ] Pricing built from costs, not copied from competitors
- [ ] Full price list written, including extras and peak rates
- [ ] One package designed (weekly walks or ten-visit bundle)
- [ ] Discount rules written down
- [ ] Month-one income model completed with your own numbers

---

# DAY 3 — Insurance, Safety, and Pet-Care Protocols

## Lesson 9: Insurance — The Non-Negotiable

If you take one lesson from this whole course, take this one: do not take a paying client without insurance. Pet business insurance typically covers public liability (a dog pulls away and knocks someone over, or damages property), care, custody and control (injury to a pet in your care), and loss of keys. It is the difference between an accident and a financial disaster, and it is also a selling point: "fully insured" is often the first thing an owner looks for.

Shop for a policy designed for pet sitters and dog walkers, not a generic business policy. Check the following before you buy: the public liability limit (commonly $1 million or more); whether it covers all the services you offer, including overnight care and group walks; whether it covers the number of dogs you walk at once; the excess (deductible) you would pay on a claim; and whether it covers key loss and lock replacement. Read the exclusions. Some policies exclude certain breeds, unvaccinated animals, or off-leash work — know what yours says before you promise a service it does not cover.

Keep your certificate of insurance where you can send it in seconds: saved on your phone and attached to your booking page. When an owner asks "are you insured?" — and good owners will — you send the certificate, not a paragraph of reassurance.

Cost is modest: most solo sitters pay the equivalent of $30 to $60 a month. It is already built into your pricing from Lesson 6, so it costs you nothing out of pocket once you are booking. If money is tight in Week 1, buy the policy before you print flyers. Insurance first, marketing second.

**Your action:** Get at least two quotes for pet sitter insurance today, compare cover and exclusions, and buy the policy that covers all your planned services.

## Lesson 10: Safety First — Dogs, Homes, and You

Safety has three parts: the pet's safety, the owner's home safety, and your own safety. Get all three right and most problems never happen.

**Pet safety.** Walk dogs on a lead unless the owner has given written permission for off-lead exercise in a specified secure area, and you have assessed the dog as reliable off-lead. Never let a dog off-lead on a first walk. Keep dogs from different households apart unless you know they are social and the owners have agreed. Carry water on warm days, avoid walking in the hottest part of the day in summer, and watch for signs of overheating: heavy panting, drooling, wobbling, or a dog that stops and refuses to move. If a dog shows these signs, move to shade, offer water, cool the paws and belly with damp cloths, and call the owner and the vet. Never leave a dog in a parked car. Never leave a pet unattended in a garden with a gate you have not checked. Count pets at the start and end of every visit — a missing cat is an emergency, not a mystery to solve later.

**Home safety.** Treat every key like it is worth the contents of the house, because it is. Use a coded key tag, never a tag with the owner's name and address. Never label keys with addresses in your phone. Lock up exactly as the owner showed you, check windows, and send a short message when you leave confirming the home is secure. If an alarm goes off, follow the owner's written instructions and call them immediately. If you notice a leak, a broken window, or anything wrong in the home, photograph it, tell the owner at once, and do not try to fix anything beyond making it safe.

**Your safety.** Always tell someone where you are going and when you expect to be back, especially for first visits and evening sits. Meet new clients in daylight for the first visit where possible. Trust your instincts: if a home, a dog, or a situation feels unsafe, you are allowed to decline the booking. A professional sitter who declines an unsafe job is not losing a client; they are protecting their business.

**Your action:** Write your personal safety rules — maximum dogs per walk, off-lead policy, heat policy, and key-handling rules — and put them in your contract.

## Lesson 11: Routine Pet Care — Feeding, Medication, and Daily Observation

Your job is routine care done reliably, not veterinary care. That distinction must be clear in your head, your contract, and your conversations with owners.

**Feeding.** Follow the owner's written instructions exactly: the food, the amount, the times, and the location. Measure food rather than guessing. Keep fresh water available at all times and wash bowls between visits for overnight care. Note any food the pet must not have, and any allergies, on the client record. Never feed a pet food or treats the owner has not approved — a well-meant treat can trigger an allergy or an upset stomach that ruins a holiday and costs you a client.

**Medication reminders.** You may remind and assist with medication a veterinarian has already prescribed, following the owner's written instructions — for example, giving a tablet hidden in food at the time stated on the label. You must never decide a dose, start a new medicine, or give a medicine prescribed for a different animal. If a pet refuses medication, or you are unsure, stop and call the owner and the vet. Record every dose you give, with the time, so there is a clear record.

**Daily observation.** You are the owner's eyes while they are away, and noticing change early is one of the most valuable things you do. At every visit, note: is the pet eating and drinking normally? Is it toileting normally? Is it moving, playing, and behaving as usual? Is there vomiting, diarrhoea, coughing, limping, swelling, discharge, or any wound? Any change from normal should be reported to the owner promptly, with a photo if appropriate. If the change is serious — collapse, seizure, heavy bleeding, difficulty breathing, suspected poisoning, or a dog that cannot stand — treat it as an emergency: call the vet immediately, then the owner, and follow the vet's instructions.

**Health disclaimer (read this carefully).** This course teaches business operations and routine pet care only. It does not teach diagnosis, treatment, or veterinary medicine, and nothing in this course is veterinary advice. Any health concern, injury, illness, or behavioural problem must be referred to a veterinarian or other qualified professional. If you are ever unsure whether something is a health concern, treat it as one and seek professional advice. Do not search the internet and guess; call the vet.

**Your action:** Create a one-page pet care record template (feeding, medication, vet details, emergency contact) and use it at every meet-and-greet.

## Lesson 12: Emergency Protocols — What to Do When Things Go Wrong

Emergencies are rare, but a sitter with a plan looks calm and professional while a sitter without one panics. Write your emergency plan now, keep a copy on your phone, and give the key parts to every client.

Your emergency plan needs: the pet's vet name, address, and phone number; the nearest emergency vet clinic and its hours; the owner's phone number and an emergency contact who can make decisions if the owner is unreachable; your own phone and your insurance company's claim line; and written authorisation from the owner, in the contract, for you to seek veterinary care and incur reasonable costs if the owner cannot be reached.

If an emergency happens, the order is: (1) make the pet safe — stop bleeding with clean pressure, keep the pet warm and still, do not move an injured animal more than necessary; (2) call the vet and follow their instructions exactly; (3) call the owner; (4) if you need to transport the pet, use your car with a secure carrier or a restrained dog, and drive calmly; (5) write down everything that happened, with times, as soon as you can; (6) tell your insurer if there may be a claim, and do not admit fault or promise payment to anyone at the scene.

Common situations to be ready for: a dog that escapes (stay calm, do not chase, call the dog, alert the owner, and use a squeaky toy or treats to lure it back); a dog fight (never put your hands between fighting dogs — use a loud noise, water, or a barrier, and check both animals for bites afterwards, calling the vet if there are any); a pet that eats something dangerous (call the vet immediately with the product name if you know it — do not try to make the pet vomit unless the vet tells you to); and a lost key or lockout (call the owner, do not force entry, and use the spare-key plan you agreed at the meet-and-greet).

After any incident, review what happened and update your procedures. Professionals learn from near-misses; amateurs repeat them.

**Day 3 checklist:**
- [ ] Insurance bought, certificate saved and ready to share
- [ ] Personal safety rules written (group size, off-lead, heat, keys)
- [ ] Pet care record template created
- [ ] Emergency plan written, with vet and emergency vet details
- [ ] Health disclaimer understood: routine care only, vet for everything else

---

# DAY 4 — Branding and Your Booking Page

## Lesson 13: Branding That Builds Trust in Ten Seconds

Your brand is what an owner feels in the first ten seconds of seeing your page: safe, warm, professional. You do not need a logo designer or an expensive brand package. You need three consistent things: a name, two colours, and one clear message.

Choose two colours and use them everywhere — your booking page, your flyers, your social profiles, your message templates. A calm, trustworthy combination (for example, a deep green with a warm cream, or navy with gold) works better than five bright colours competing for attention. Use the same profile photo or logo image everywhere so owners recognise you instantly.

Your one clear message is a single sentence that says who you help and what changes for them. For example: "Reliable, insured dog walking and pet sitting in Springfield — so you can leave home knowing your pet is happy and safe." Put that sentence at the top of your booking page, on your flyers, and in your social bios. Everything else on the page supports it.

Photography matters more than design. Use real photos of you with animals (with the owner's permission), real photos of happy dogs on walks, and real photos of the neighbourhoods you serve. Owners trust a real person with a real dog far more than a stock photo. Never use another sitter's photos, and never post a photo of a client's pet publicly without their permission.

**Your action:** Pick your two brand colours, write your one-sentence message, and gather five real photos of you with animals for your booking page.

## Lesson 14: Your Booking Page — The One Page That Sells While You Sleep

You do not need a full website on Day 4. You need one good page that does five jobs: it says what you do, it shows your prices, it proves you are trustworthy, it answers common questions, and it makes booking easy. That page can live on a free website builder, a booking platform profile, or a simple link page — the format matters less than the content.

Your booking page needs: your business name and one-sentence message at the top; a short "about me" paragraph (who you are, why you love animals, your experience — honest, not exaggerated); your service menu with prices; proof of trust (insured badge or certificate, any relevant training, a note that references are available); a simple "how it works" section in three steps (meet-and-greet, booking, photo updates); answers to the five questions every owner asks (are you insured? what happens in an emergency? will you send photos? what if my dog does not like you? how do I pay?); and a clear next step: a button or link to message you, a booking form, or your phone number.

Make booking easy. Every extra step loses clients. A booking form that asks for the owner's name, pet's name, service needed, dates, and phone number is enough to start the conversation. You can collect the details at the meet-and-greet. Reply to every enquiry within a few hours — speed of reply is one of the biggest factors in winning a booking, because owners often message three sitters and book the first one who replies helpfully.

**Your action:** Build your one-page booking page today, with services, prices, trust proof, and a simple booking form or contact button.

## Lesson 15: Photos, Reviews, and Social Proof — Honest Only

Reviews are the most powerful marketing you will ever have, and the rule is simple: only real reviews, from real clients, with their permission. Never write fake reviews, never ask a friend to pretend to be a client, and never copy a testimonial from another business. One honest review from a real first client is worth more than ten invented ones, and fake reviews can destroy a new business if they are discovered.

Your first reviews will come from your first clients. After a successful booking, send a short message: "Thank you for trusting me with [pet's name]. If you were happy with the care, a short review on my booking page would mean a great deal — it helps other owners find me." Most happy clients will say yes. Ask once, politely, and never offer a discount in exchange for a review, which can breach platform rules and looks unprofessional.

Before you have paying clients, you can still show proof: a short video of you walking a friend's dog (with permission), photos of pets you have cared for, and a clear statement of your insurance and any training you have completed. Honesty about being new is fine — "I am a new business, fully insured, and I would love to earn your trust" — is far more appealing than pretending to be established.

Set up one social profile for the business (Instagram or Facebook, whichever your local owners use most) and post two or three times a week: a photo from a walk, a pet-care tip, a behind-the-scenes look at your kit. Keep it real, keep it regular, and always get permission before posting a client's pet.

**Day 4 checklist:**
- [ ] Two brand colours chosen and used consistently
- [ ] One-sentence brand message written
- [ ] Booking page live with services, prices, trust proof, FAQ, and booking form
- [ ] Five real photos ready for the page
- [ ] Business social profile created
- [ ] Plan for asking real clients for honest reviews

---

# DAY 5 — Finding Clients Beyond Rover and Wag

## Lesson 16: Why You Need Clients Outside the Big Platforms

Platforms such as Rover and Wag can bring your first bookings, and there is nothing wrong with listing on them. But a business that depends entirely on a platform does not own its clients: the platform sets the fees (often 15 to 20 percent or more of every booking), controls the messaging, and can change its rules or suspend an account without warning. Your goal is to use platforms as one channel, not your only channel, and to build a direct client base that books with you, pays you directly, and refers their friends to you.

Think of it as three buckets. Bucket one is platforms — useful for early bookings and reviews. Bucket two is local marketing — flyers, vet clinics, pet shops, community boards, and word of mouth in your own neighbourhood. Bucket three is partnerships and referrals — the highest-value bucket, because a referred client already trusts you before you meet. By Day 30, aim for no more than a third of your bookings to come from any single bucket.

If you do list on a platform, follow its rules honestly: do not try to move platform clients off the platform in ways that breach its terms. Build your direct base separately, from your own marketing, so the two never conflict.

**Your action:** Decide which platforms, if any, you will list on, and set a target: at least half your clients from direct and local channels by Day 30.

## Lesson 17: Local Marketing That Actually Works

Pet sitting is a local business, and local marketing is where beginners beat big companies. Owners choose the sitter they have seen, heard of, or been recommended — not the one with the biggest advertising budget. Your local plan has five parts, and you can do all five this week.

First, flyers and business cards. Print 100 flyers and 100 cards. The flyer needs your name, your one-sentence message, your four services with starting prices, and a clear next step (your phone number or booking page link). Put them where pet owners go: vet waiting rooms (ask permission first), pet shops, grooming salons, community noticeboards, coffee shops, and letterboxes in streets where you want to walk. A flyer on a vet's board is worth ten posted through random doors.

Second, your neighbourhood. Walk the same routes at the same times, be friendly, learn dogs' names, and carry cards. Dog owners talk to each other at the park every single day. Being a familiar, friendly face with a professional card is marketing that costs nothing.

Third, local online groups. Join your town's community and pet-owner groups on Facebook and neighbourhood apps. Answer questions helpfully, share a genuine pet-care tip, and mention your service only when it is relevant and the group rules allow it. A sitter who is helpful in a group gets recommended; a sitter who only advertises gets ignored or removed.

Fourth, a simple launch offer. For your first two weeks, offer 20 percent off a first booking for new clients who find you locally. It lowers the barrier to trying you, and it gives you a reason to mention the offer on every flyer and post. Remember Lesson 7: introductory offers are for new clients, once only, and they end.

Fifth, track everything. Write down where every enquiry came from — flyer, vet board, Facebook group, referral, platform — in the marketing tracker in the workbook. After 30 days you will know exactly which channel earns you money, and you can spend your time there instead of guessing.

**Your action:** Print flyers and cards, place them in five local spots, and join two local pet-owner or community groups online.

## Lesson 18: Partnerships — Vets, Groomers, Trainers, and Pet Shops

One good partnership can fill your diary faster than a hundred flyers. Vets, groomers, trainers, and pet shops meet your ideal clients every day, and they are asked constantly: "Do you know a good pet sitter?" Your job is to become the name they give.

Approach partnerships as a relationship, not a transaction. Visit in person, introduce yourself briefly, leave a small stack of cards and a one-page sheet about your services, insurance, and service area. Offer something useful in return: you can refer your clients to them, share their posts, or offer their clients a small first-booking discount. Never offer a cash kickback for referrals unless you have checked that it is lawful and appropriate in your area — most professionals prefer a simple, honest mutual referral.

Start with three targets this week: your own vet, one groomer, and one pet shop. Follow up once, politely, a week later. If they start recommending you, thank them, keep them updated, and send them a card or a small thank-you note at Christmas. Partnerships are like clients: they grow when they are looked after.

Other useful partners: dog trainers (their clients often need walks between sessions), estate agents and letting agents (new residents with pets need a sitter), and house-cleaning or home-care services (their clients travel and need pet care). Keep the list short to start — three good partners beat ten forgotten ones.

**Your action:** Visit or contact three local partners this week with cards and your one-page service sheet.

## Lesson 19: Referrals and Word of Mouth — Your Cheapest Marketing

A referred client is the best client: they arrive trusting you, they book faster, and they stay longer. Build referrals deliberately from Day 1.

First, be referable. That means: reply fast, arrive on time, send a photo update after every visit, leave the home tidy, and follow up after the booking with a short thank-you message. Owners recommend sitters who make them feel their pet was loved, not just looked after. The photo update is the single highest-impact habit in this business — a happy dog photo in the middle of a working day is worth more than any advertisement, and owners share those photos with friends.

Second, ask. After a successful first booking, say: "I am building my business locally, and most of my new clients come from recommendations. If you know anyone who might need a sitter or walker, I would be grateful if you passed on my card." Most owners are happy to help. Ask once per client, warmly, and never push.

Third, reward referrals simply and honestly. A common approach is a thank-you credit — for example, $10 off the referrer's next booking when a referred friend completes their first booking. Keep it modest, keep it in writing, and apply it consistently.

Fourth, stay in touch lightly. A short message every couple of months — a seasonal reminder ("Holiday season is booking up — let me know your dates early"), a pet's birthday note, or a useful tip — keeps you in mind without being a nuisance. Never message a client about marketing more than once a month.

**Day 5 checklist:**
- [ ] Platform strategy decided (one channel, not the only channel)
- [ ] Flyers and cards printed and placed in five local spots
- [ ] Two local online groups joined
- [ ] Launch offer defined (20% off first booking, new clients, two weeks)
- [ ] Three local partners contacted
- [ ] Referral thank-you offer written down
- [ ] Marketing tracker started

---

# DAY 6 — Meet-and-Greets, Booking, and Client Onboarding

## Lesson 20: The Meet-and-Greet — Your Most Important 30 Minutes

Never take a booking without a meet-and-greet. This free, 30 to 45 minute visit is where you meet the pet, see the home, check the fit, and decide — honestly — whether you can care for this animal safely. It protects you from bad bookings, and it is where owners decide to trust you. Treat it as professionally as any job interview, because that is what it is.

Before the visit, ask for the basics by message: the pet's name, breed, age, temperament, any medical conditions or medication, feeding routine, exercise needs, and any behaviour concerns (anxiety, aggression, escape attempts). If anything in the answers worries you, ask more questions before you go — or decline politely.

At the visit, use the meet-and-greet script (in your templates) and cover: the pet's routine in detail; feeding amounts and times; walking routes and off-lead permission; house rules (rooms the pet may not enter, alarm codes, key arrangements); the vet's details and an emergency contact; medication instructions in writing; and anything the pet is afraid of or reactive to. Watch how the pet behaves with you. A dog that growls, snaps, or shows sustained fear may need a more experienced handler, a different service, or a vet or behaviourist referral — and saying so honestly is professional, not a failure.

End the visit by summarising what you will do, confirming the price, and explaining the next step: you will send the booking form and contract, and once it is signed and the deposit is paid, the booking is confirmed. Send a thank-you message the same day.

Red flags to take seriously: an owner who will not give vet details; a dog with a bite history the owner minimises; a home you feel unsafe in; an owner who pressures you to skip the contract or insurance; or a pet whose needs are beyond your skill (for example, a dog that needs specialist behavioural work). Any one of these is a reason to pause, ask more, or decline. A declined booking costs you nothing. A bad booking can cost you your reputation.

**Your action:** Practise the meet-and-greet script out loud, and book your first meet-and-greet with a friend's pet if you have no client yet.

## Lesson 21: Booking, Deposits, and Cancellation Policies

A booking is not confirmed until three things have happened: the contract is signed, the deposit is paid, and you have confirmed the dates in writing. Until then, the dates are a hold, not a booking — and you should say so clearly, so nobody is surprised.

Take a deposit of 25 to 50 percent at booking, with the balance due a set number of days before the service (commonly 7 days for regular bookings, 14 days for holiday periods). Deposits protect you from last-minute cancellations, and they make the owner committed too. Accept payment by bank transfer or a card payment link; avoid cash where possible, because bank records keep your bookkeeping clean.

Write your cancellation policy into the contract and repeat it at booking: for example, full refund of the deposit if cancelled more than 14 days ahead; 50 percent refund if cancelled 7 to 14 days ahead; no refund if cancelled within 7 days. For peak periods (Christmas, school holidays), make the window longer — 30 days — because a cancelled Christmas booking is very hard to replace. Be firm and kind: "I hold dates exclusively for your pet, so I do need to charge for late cancellations" is a professional statement, not an apology.

Keep a booking calendar — paper diary or digital — and update it the moment a booking is confirmed. Double bookings are the most embarrassing mistake a new sitter can make, and they are entirely preventable. Block out travel time between bookings, and never book two sits that overlap unless you have a trusted helper confirmed.

**Your action:** Write your deposit and cancellation terms, and put them in your contract and on your booking page.

## Lesson 22: The Client Contract — What It Must Cover

Your contract is not legal decoration; it is the document that prevents misunderstandings. Use the template in this course (adapted to your local law and checked by a local adviser if you can), and make sure every client signs one before the first paid visit.

A complete pet sitting agreement covers: the parties and the pet's details; the services, dates, times, and fees; the deposit and payment terms; the cancellation policy; feeding, exercise, and medication instructions (attached as the pet care record); veterinary authorisation — the owner's permission for you to seek vet care if they cannot be reached, and who pays the vet bill; key handling and home access; photo and social media permission (or refusal); liability limits and the statement that the owner is responsible for disclosing the pet's behaviour history, medical conditions, and vaccination status; and the health disclaimer: that you provide routine care and business services, not veterinary care, and that any health concern will be referred to a veterinarian.

Ask the owner to confirm in writing that the pet is up to date with vaccinations and flea and worm treatment where applicable, and that they have told you about any bite history or aggression. If an owner will not sign, do not take the booking. A client who refuses a contract is telling you something important about how the relationship will go.

Keep signed contracts safely — digitally, backed up — and keep them for at least as long as your local record-keeping rules require. You will rarely need them, and when you do, you will be very glad you have them.

**Your action:** Adapt the contract template to your business name, prices, and local details, and use it for every client without exception.

## Lesson 23: Onboarding — Making the First Booking Effortless

Onboarding is everything that happens between "yes" and the first visit, and its job is to make the owner feel calm and the sitter feel prepared. A good onboarding sequence has five steps.

Step 1 — Confirm in writing: service, dates, times, fee, deposit received, balance due date. One message, all the facts, no ambiguity. Step 2 — Collect the details: completed pet care record, vet details, emergency contact, key arrangements, alarm codes, feeding and medication instructions in writing. Step 3 — Arrange key collection: in person at the meet-and-greet is best; a lockbox or a trusted neighbour are the usual alternatives. Never ask an owner to leave a key in an obvious hiding place. Step 4 — Send a pre-visit message the day before: "Looking forward to seeing [pet's name] tomorrow at [time]. Just confirming [key/feeding/walk details]." Step 5 — After the first visit, send a photo update and a short note the same day. This is the moment a one-off client becomes a regular.

Build a simple onboarding checklist and use it for every client, every time. Consistency is what makes a one-person business feel like a professional service. The checklist is in the workbook — print it and keep a copy with your kit.

**Day 6 checklist:**
- [ ] Meet-and-greet script practised and ready
- [ ] Deposit and cancellation terms written
- [ ] Contract adapted and ready to send
- [ ] Onboarding checklist printed
- [ ] Booking calendar set up and in use
- [ ] Pet care record template ready for every client

---

# DAY 7 — Launch Day, First Client, and Your First 30 Days

## Lesson 24: Launch Day — Going Live

Today is the day your business opens. You have a name, a price list, insurance, a booking page, a contract, and a marketing plan. Launch is not a single dramatic event; it is a checklist of small public steps, done in one day.

Morning: check your booking page once more — prices correct, phone number correct, booking form working. Post your launch announcement on your business social profile and in the local groups that allow it: a friendly photo, your one-sentence message, your launch offer, and a clear next step. Text or message five people you know who have pets, or who know pet owners, and ask them to share your page. Drop your remaining flyers at the last two or three spots on your list.

Afternoon: follow up with your three partners — a quick message confirming you are now open for bookings and that you have cards ready if they need more. Reply to every enquiry the same day, even if it is only to arrange a meet-and-greet time. Speed matters more than polish.

Evening: write down every enquiry, every meet-and-greet booked, and every booking confirmed. This is your first page of business records, and in a month's time you will look back at it and see how far you have come.

If launch day brings no enquiries, do not panic. Most local businesses win their first client in the first week, not the first hour. Keep marketing every day — one flyer run, one group post, one partner visit, one conversation at the park — and the enquiries will come. Consistency beats intensity.

**Your action:** Complete the launch-day checklist in the workbook, and make your launch announcement today.

## Lesson 25: Winning and Serving Your First Paying Client

Your first paying client deserves your best work, because they are also your first review, your first referral, and your first proof that the business works. Here is how to make their experience excellent.

Before the booking, confirm everything in writing (Lesson 23), arrive five minutes early, and bring your kit: lead, treats, waste bags, water, your phone charged, and the pet care record. During the booking, follow the owner's instructions exactly, send a photo update after the first visit, and note anything worth reporting — appetite, toileting, mood, any change from normal. If anything is even slightly off, tell the owner promptly; owners would far rather hear "she ate a little less than usual today, but she is bright and drinking well" than hear nothing and worry.

After the booking, send a thank-you message the same day, confirm the home is secure and the key returned or stored as agreed, and ask — once, politely — for a review. If the client books again, you have your first regular. If they do not, ask yourself honestly what could have been better, and improve it for the next client.

Pricing your first client: do not undercharge "because they are the first." Use your real price list, apply your launch offer if you promised one, and deliver service that justifies the price. A first client who pays your real rate and is delighted is the foundation of a profitable business. A first client who pays a token rate teaches you to work for token rates.

**Your action:** Write your post-booking thank-you message template now, so you can send it within an hour of finishing your first booking.

## Lesson 26: Your First 30 Days — The Plan That Turns a Launch into a Business

The first 30 days are about three things: serving every client brilliantly, marketing every single day, and reviewing your numbers weekly. Here is the plan.

**Week 1 (Days 1–7): Launch.** Finish this course, go live, and aim for your first 2 to 3 clients. Marketing daily: flyers, groups, partners, park conversations. Track every enquiry and its source.

**Week 2 (Days 8–14): Serve and ask.** Deliver your first bookings, send photo updates, collect your first reviews, and ask every happy client for a referral. Review your prices and your time: are walks taking longer than planned? Is travel eating your margin? Adjust your schedule, not your prices, in Week 2.

**Week 3 (Days 15–21): Build regularity.** Turn one-off clients into regulars: offer the weekly walking package, suggest a recurring schedule, and confirm holiday dates early. Contact your partners again with an update and fresh cards. Post your first client photos (with permission) on social media.

**Week 4 (Days 22–30): Review and plan.** Sit down with your records and answer five questions: How many enquiries did I get, and from where? How many became bookings? What was my gross income, my costs, and my profit? Which service earned the most per hour? What will I do differently next month? Then set a Month 2 target: for most sitters, that is 2 to 3 more regular clients and one more partnership. Raise nothing, change little — repeat what worked, fix what did not.

**A note on growth.** When demand exceeds your time, you have three options: raise your prices, limit your service area or hours, or bring in help. Hiring help — even a trusted part-time walker — changes your insurance, your contracts, and your legal responsibilities, so treat it as a second phase, not a Month 1 decision. Grow steadily, protect your reputation, and let the business earn the right to expand.

You started this course with a love of animals and no business. You finish it with a named, insured, priced, and marketed service, a contract, a booking page, and a plan. The next step is the simplest and the hardest: go and do it. Your first client is out there, looking for exactly what you now offer.

**Day 7 checklist:**
- [ ] Launch announcement posted
- [ ] Flyers placed and partners followed up
- [ ] First meet-and-greet or booking confirmed
- [ ] Thank-you and review-request messages written
- [ ] First-30-days planner filled in (workbook)
- [ ] Weekly review date set for the next four weeks

---

## Appendix A: Startup Cost List (Summary)

| Item | Estimated cost |
|---|---|
| Business registration / licence (if required) | $0–$100 |
| Pet business insurance (first month) | $30–$60 |
| Booking page / website | $0–$20 per month |
| Business cards and flyers (first print run) | $40–$80 |
| Leashes, treat pouch, waste bags, basic kit | $50–$100 |
| Accounting spreadsheet or app | $0–$15 per month |
| **Total first-month startup** | **$120–$375** |

## Appendix B: Example Price List (Summary)

| Service | Duration | Price |
|---|---|---|
| 30-minute dog walk (solo) | 30 min | $22 |
| 60-minute dog walk (solo) | 60 min | $35 |
| 30-minute group walk (max 4 dogs) | 30 min | $18 per dog |
| Drop-in visit (cats / small pets) | 30 min | $25 |
| Puppy visit | 30 min | $25 |
| Evening pet sit (owner's home) | 3 hours | $55 |
| Overnight stay (owner's home) | 12 hours | $85 |
| Holiday / peak surcharge | — | +20% |
| Last-minute booking (under 24 hours) | — | +$10 |

## Appendix C: Your Sitter's Kit — What to Carry on Every Visit

A professional sitter arrives prepared. Keep a small kit bag packed and ready so you never have to improvise at a client's door. Your kit should contain: a spare lead and a slip lead; a treat pouch with small, plain treats approved for general use (never feed a client's pet treats the owner has not approved — carry them for your own use in training and recall, and ask the owner first); waste bags, more than you think you need; a collapsible water bowl and a bottle of water; a towel for muddy paws; a basic pet first-aid kit (clean gauze, bandages, saline wound wash, blunt-tipped scissors, tweezers for ticks, and your vet's phone number printed on a card); a phone charger or power bank; your pet care records for the day's visits; and a copy of your insurance certificate on your phone. Check the kit every Sunday evening and restock it before Monday. A sitter who arrives with the right kit looks professional; a sitter who has to borrow the owner's supplies does not.

## Appendix D: Seven Mistakes New Sitters Make (and How to Avoid Them)

First, undercharging. The maths in Lesson 6 exists for a reason — trust it. Second, skipping the contract for "a friend of a friend." The clients who need a contract most are the ones you know personally, because those are the relationships a misunderstanding damages most. Third, taking on too many dogs at once. A full diary feels like success until a walk runs late, a dog gets loose, or you are too tired to give the last client your best. Build up gradually. Fourth, saying yes to a dog you cannot handle. A polite refusal protects the dog, the owner, and your reputation. Fifth, going quiet. Owners worry when they hear nothing. A short photo update after every visit is the cheapest trust-builder in this business. Sixth, mixing business and personal money. Open the separate account on Day 1 and keep it separate from then on. Seventh, stopping marketing once you have a few clients. Clients go on holiday, move house, and change routines. A sitter who markets only when the diary is empty spends half the year with an empty diary. Market a little every week, even when you are busy.

## Appendix E: Health and Safety Disclaimer

This course teaches business operations and routine pet care only. It does not provide veterinary advice, diagnosis, or treatment, and it does not qualify you to practise veterinary medicine, animal behaviour therapy, or any regulated animal-health profession. Any health concern, injury, illness, or behavioural issue must be referred to a veterinarian or other qualified professional. Always contact the pet's owner and, where needed, their veterinarian immediately if a pet shows any sign of illness, injury, or distress. You are responsible for checking the laws, licences, insurance requirements, and professional standards that apply in your area before taking paying clients.

---

*The Profitable Pet Sitter — Launch Your Dog Walking & Pet Sitting Business in 7 Days. Course text complete: 26 lessons across 7 days.*
