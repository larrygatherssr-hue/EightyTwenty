# Onboarding — The Profitable Pet Sitter

Welcome, and congratulations on starting your pet sitting and dog walking business. This guide tells you what to do first, how to use the materials, and how to follow the 7-day plan.

## What You Have Received

Your purchase includes six files:

1. **content.md** — the complete course text: 26 lessons organised as a 7-day launch plan.
2. **workbook.md** — the 107-page launch workbook: checklists, pricing worksheet, client avatar worksheet, marketing tracker, first-30-days planner, startup budget, and pet care records.
3. **templates/pricing-calculator.csv** — a spreadsheet that builds your prices from costs, models your month-one income, and checks your break-even point.
4. **templates/client-contract-template.md** — a pet sitting service agreement to adapt and use with every client.
5. **templates/meet-and-greet-script.md** — 26 questions, a visit plan, and a red-flags list for every first visit.
6. **templates/booking-template.md** — a booking form with payment tracking, a visit log, and a checklist from meet-and-greet to key return.

Read the cover brief (cover.md) only if you want to see how the product cover was designed — it is not part of the course.

## What to Do First

Do these three things before anything else:

1. **Read the welcome and the health disclaimer at the start of the course text.** The course teaches business operations and routine pet care only. It does not provide veterinary advice, diagnosis, or treatment. Any health concern, injury, illness, or behavioural issue must be referred to a veterinarian or other qualified professional.
2. **Print the workbook.** You will fill it in by hand as you work through the course — it is designed to be used, not just read.
3. **Open the pricing calculator.** It is the fastest way to see your own numbers: change the example costs to your real costs and watch your prices and month-one income model update.

## Suggested 7-Day Schedule

Follow the course in order. Each day is a half-day of focused work plus action steps — most people finish a day in 2 to 3 hours.

- **Day 1 — Business foundations and legal setup.** Choose your structure and name, check local licences, open a separate business bank account, and write your startup budget.
- **Day 2 — Services, pricing, and packages.** Build your service menu and price list from your costs using the pricing worksheet and calculator, then complete your month-one income model.
- **Day 3 — Insurance, safety, and pet-care protocols.** Buy insurance, write your safety rules and emergency plan, and prepare your pet care record template.
- **Day 4 — Branding and your booking page.** Choose your colours and message, build your one-page booking page, and set up your business social profile.
- **Day 5 — Finding clients beyond Rover and Wag.** Print flyers and cards, contact three local partners, join two local groups, and start your marketing tracker.
- **Day 6 — Meet-and-greets, booking, and client onboarding.** Practise the meet-and-greet script, adapt the contract, and set up your booking calendar and onboarding checklist.
- **Day 7 — Launch day.** Post your launch announcement, follow up with partners, and fill in your first-30-days planner.

If you can only spare an hour a day, spread each day over two days — the plan still works. What matters is finishing each day's checklist before moving on, because every day builds on the last.

## How to Use the Templates

- **Pricing calculator:** change the example values to your own costs and prices. The worked example in the course uses a $22 thirty-minute walk — your numbers will differ by area, and that is expected.
- **Client contract:** adapt it to your business name, prices, and local details, and have it reviewed by a qualified local adviser before use. It is a general template, not legal advice. Use it for every client, without exception.
- **Meet-and-greet script:** print it and take it to every first visit. Tick each item as you cover it, and complete the pet care record the same day.
- **Booking template:** copy it for every booking. A booking is confirmed only when the signed agreement and the deposit have both been received.

## Your First 30 Days

After launch day, the workbook's first-30-days planner takes over: serve every client brilliantly, market a little every day, collect honest reviews, and review your numbers weekly. Set your four weekly review dates now, before you launch, so they do not slip.

## Getting Support

If you have a problem with your order or the course files — a file that will not open, a missing download, or a question about what is included — email the marketplace support address with your order number and a description of the issue, and the support team will respond.

For questions about your own business — licences, insurance, tax, or local rules — contact the relevant local authority, insurer, or a qualified local adviser. Support cannot give legal, veterinary, or financial advice.

## A Final Word

You do not need to be perfect to launch. You need a name, a price list, insurance, a contract, and a way for clients to find you — and this course gives you all five in seven days. Work the plan, serve your first client well, and let the business grow from there.
