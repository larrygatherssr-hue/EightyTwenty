# Healthy Hair Academy: Care, Repair & Treatment Routines

**A complete hair-care education programme — hair science, scalp health, damage repair, and treatment routines for every hair type.**

---

## Important Disclaimer — Please Read First

This programme is for **education only**. It is not medical advice, and it does not diagnose, treat, or cure any hair-loss condition, scalp disorder, or medical condition. The information here describes general hair-care principles, cosmetic routines, and widely used at-home practices. It is not a substitute for advice from a qualified healthcare professional, dermatologist, or trichologist.

If you are experiencing sudden or patchy hair loss, bald spots, severe shedding, scalp pain, sores, blistering, swelling, heavy flaking that does not improve with gentle care, signs of infection, or hair loss connected to an illness, medication, or medical treatment, please consult a qualified professional promptly. The same applies if you are pregnant, breastfeeding, taking medication, or managing a medical condition and are considering a new product, chemical service, or supplement.

Patch-test any new product before full use, follow the manufacturer's instructions, and stop using anything that causes irritation, itching, burning, redness, or unusual shedding. Results vary from person to person. No routine in this programme guarantees a specific outcome, such as a particular rate of hair growth, thickness, or curl pattern.

---

## How to Use This Programme

This course has eight modules. Work through them in order the first time: each module builds on the one before it. You do not need any prior knowledge, and you do not need expensive products to follow it.

You will get the most from the programme if you:

1. **Complete the assessments first.** Module 2 and Module 3 walk you through identifying your hair type and porosity. Do the hands-on tests before buying anything new — they determine which routines in later modules apply to you.
2. **Keep a hair journal for the first four weeks.** Note what you used, how your hair felt on wash day and on day three, and any changes. The workbook includes a routine tracker for this.
3. **Change one thing at a time.** If you change your shampoo, your conditioner, your styling method, and your treatment all in the same week, you will not know which change helped. Introduce one change, use it for two to three weeks, then judge it.
4. **Use the 12-week plan in Module 8.** Repair is gradual. Hair that is already grown cannot be "healed" back to its original state — damaged lengths can be improved in feel and appearance, protected from further damage, and gradually replaced by healthier new growth. The 12-week plan is built around that honest timeline.
5. **Revisit the modules.** Once you know your hair type and porosity, Modules 6 and 7 become reference chapters you can return to whenever you change seasons, move to a different climate, or consider a new chemical service.

**What you will need:** your current hair products, a wide-tooth comb, a spray bottle, a few hair clips, a towel or old cotton T-shirt, and the workbook that accompanies this course. Everything else is optional.

---

## Table of Contents

- Module 1 — Hair Science: What Hair Is and How It Grows
- Module 2 — Know Your Hair: Type, Texture, Density, and Curl Pattern
- Module 3 — Porosity: The Key That Changes Everything
- Module 4 — Scalp Health: The Foundation of Healthy Hair
- Module 5 — Damage: How Hair Breaks, and What Repair Really Means
- Module 6 — The Core Routine: Cleansing, Conditioning, and Daily Care
- Module 7 — Treatments: Masks, Protein, Moisture, Oils, Heat, and Chemical Care
- Module 8 — Your 12-Week Repair Plan and Long-Term Maintenance
- Appendix A — Worked Examples: Three Complete Cases
- Appendix B — Glossary
- Appendix C — Product-Label Reading Guide

---

# Module 1 — Hair Science: What Hair Is and How It Grows

## 1.1 Hair is not alive — and that changes everything

The hair you can see, touch, and style is not living tissue. Each strand is made mostly of keratin, a tough protein, and the visible shaft has no blood supply and no nerves. That is why cutting your hair does not hurt. The living part of hair sits below the surface of the skin, in the follicle, where new cells are made and pushed upward. As those cells move up the follicle they fill with keratin, harden, and die. What emerges is the shaft you see in the mirror.

This single fact explains most of what this course teaches. Because the shaft is not alive, it cannot repair itself the way skin does. A cut on your skin closes; a split end does not rejoin. Once the outer layer of a strand is worn away, no product can rebuild the strand to its original condition from the inside. Products can coat it, fill small gaps temporarily, reduce friction, add moisture to the surface, and protect it from further wear — and those things matter a great deal — but they do not bring dead protein back to life. Honest hair care is therefore mostly prevention and protection: keep the new growth healthy, slow down the wear on the lengths, and trim away damage that has gone too far.

It also explains why the scalp matters so much. The follicle is living tissue, fed by blood vessels, influenced by hormones, nutrition, illness, and stress. Healthy-looking hair starts with a healthy scalp environment and a body that is well enough to grow hair. No shampoo can compensate for a scalp that is inflamed, or for a body under severe strain — and that is why this course spends a full module on the scalp and why it repeatedly tells you to seek professional help for medical symptoms rather than trying to treat them with cosmetics.

## 1.2 The structure of a strand

A single hair strand has three layers, and each one does a different job.

**The cuticle** is the outermost layer: a series of thin, overlapping scales, like shingles on a roof or scales on a fish. When the cuticle lies flat and smooth, hair looks shiny, feels smooth, and holds moisture well, because light reflects evenly and water does not escape easily. When the cuticle is lifted, roughened, or missing in places — through heat, friction, brushing, chemical services, or sun — hair looks dull, feels rough, tangles easily, and loses moisture quickly. Almost all cosmetic hair care is, in one way or another, about the cuticle: keeping it smooth, closing it after washing, and protecting it from being lifted.

**The cortex** is the middle layer and the thickest part of the strand. It contains long bundles of keratin fibres and the pigment (melanin) that gives hair its colour. The cortex gives hair its strength and elasticity — its ability to stretch a little and spring back. Chemical services such as colouring, lightening, relaxing, and perming work by getting into the cortex and changing its structure. That is why they can change hair permanently and why they carry a real risk of damage: anything strong enough to change the cortex is strong enough to weaken it.

**The medulla** is the innermost core, a soft, spongy channel that is present in thicker hairs and often absent in fine hair. It contributes little to strength or appearance, and you do not need to think about it when choosing products or routines. It is mentioned here only so that you recognise the term if you meet it elsewhere.

Around the base of each strand, below the skin, sits the **follicle**: a small pocket of living cells. At its base is the bulb, where cells divide rapidly, and the **dermal papilla**, a small cluster of tissue supplied with blood vessels. Attached to the follicle is a tiny muscle (which makes hair stand on end when you are cold) and a **sebaceous gland**, which produces sebum — the skin's own oil. Sebum travels up the shaft and conditions it naturally. Straight hair lets sebum travel easily, which is why straight hair can look oily quickly; curly and coily hair has bends that slow sebum down, which is why the ends of curly hair are often drier than the roots.

## 1.3 The growth cycle

Every follicle cycles through three main phases, and understanding them prevents a great deal of unnecessary worry.

**Anagen — the growth phase.** This is the long phase, lasting roughly two to seven years on the scalp, depending on the person. During anagen, cells in the bulb divide rapidly and the strand grows — on average about one centimetre (roughly half an inch) per month, though this varies. At any given time, about 85 to 90 percent of the hairs on a healthy scalp are in anagen. The length of your anagen phase largely determines how long your hair can grow: if your anagen lasts two years, your hair will reach a certain maximum length and then shed, however well you care for it. That maximum is set mostly by genetics, not by products.

**Catagen — the transition phase.** Lasting about two to three weeks, the follicle shrinks, growth stops, and the strand detaches from its blood supply. Only a small percentage of hairs are in this phase at any time.

**Telogen — the resting phase.** The strand rests in the follicle for about two to four months, and then it is shed — often pushed out as a new anagen hair begins to grow beneath it. Losing roughly 50 to 100 hairs a day is within the normal range for most people, and shedding increases on wash days because loose hairs that were already in telogen are dislodged together. Seeing hair in the shower drain does not, on its own, mean something is wrong.

Two practical consequences follow. First, because growth is slow — about a centimetre a month — any routine needs at least eight to twelve weeks before you can fairly judge whether it is helping new growth. That is why this programme is built around a 12-week plan. Second, because the cycle is long, sudden increases in shedding often reflect something that happened two to three months earlier — an illness, a period of high stress, a change in medication, a crash diet — rather than the shampoo you used last week. If shedding changes suddenly or dramatically, that is a reason to speak to a qualified professional, not to buy a new product.

## 1.4 What determines how your hair behaves

Four factors, all largely set by genetics, decide most of what you will notice about your hair:

- **The shape of the follicle.** A round follicle tends to produce straight hair; an oval follicle produces wavy or curly hair; a flatter, more ribbon-shaped follicle produces tight coils. You cannot change the shape of your follicles, and heat or chemical straightening only changes the shaft temporarily or by altering its internal bonds.
- **The size of the follicle.** Larger follicles produce thicker individual strands; smaller follicles produce finer strands. This is strand thickness, which is different from how much hair you have overall.
- **The number of follicles.** People are born with roughly 100,000 follicles on the scalp. How many are active, and how densely they are packed, decides whether your hair looks thick or thin overall — a property called density.
- **The amount and type of melanin in the cortex.** This sets your natural colour, and it also affects how hair responds to lightening: darker hair contains more pigment to remove, which is why lightening dark hair is a more demanding chemical process.

Age, hormones, and health change these factors over time. Hair often becomes finer with age; hormonal shifts can change texture; illness and some medications can shift large numbers of follicles into telogen at once. None of this is your fault, and none of it is fixed by a single product. What you can control — and what this course teaches — is how you treat the hair you have: how you cleanse, condition, detangle, protect, and style it, and how you look after the scalp it grows from.

## 1.5 The vocabulary of hair care, briefly

A few words are used constantly in hair care, and they are often used loosely. Here is what they mean in this course:

- **Moisture** means water in the hair, and the products and routines that help hair hold on to water. Dry hair is hair that has lost water; oiling dry hair without adding water first does not moisturise it — it seals in whatever dryness is already there.
- **Protein** refers to treatments and ingredients that add protein-like material to the surface of the hair, temporarily filling small gaps in the cuticle and making the strand feel stronger and stiffer. Hair is made of protein, but adding protein to the outside is a cosmetic patch, not a rebuild.
- **Elasticity** is how far a strand can stretch when wet and still return to its original length. Healthy hair stretches a little and springs back. Hair that snaps immediately is often lacking moisture or is severely damaged; hair that stretches a long way and does not spring back is often over-softened or over-processed.
- **Breakage** is hair snapping along the shaft, as opposed to shedding from the root. Breakage leaves short, uneven pieces and a frayed or white-tipped end; shedding leaves a whole strand with a tiny bulb at the root end. Knowing the difference matters, because breakage is usually a care problem you can improve, while increased shedding from the root is more often a reason to seek professional advice.
- **Porosity** is how easily hair absorbs and loses water. It is so important that it gets its own module — Module 3.

## 1.6 Module 1 — Key takeaways

1. The visible shaft is not alive and cannot repair itself; care is mostly protection and prevention.
2. The cuticle is the protective outer layer. Smooth cuticle means shine and moisture retention; lifted cuticle means dullness, tangling, and dryness.
3. Hair grows in a cycle (anagen, catagen, telogen) at roughly a centimetre a month. Judge any routine over eight to twelve weeks, not eight to twelve days.
4. Losing 50 to 100 hairs a day is within the normal range. Sudden, patchy, or severe shedding is a reason to consult a qualified professional.
5. Your follicle shape, strand thickness, density, and growth-cycle length are largely genetic. Good care works with them; it does not override them.

---

# Module 2 — Know Your Hair: Type, Texture, Density, and Curl Pattern

## 2.1 Why identification comes before products

Most disappointing hair purchases are not bad products — they are good products for somebody else's hair. A heavy butter that transforms thick, coily hair will weigh fine, straight hair flat and greasy. A lightweight spray that suits fine hair will vanish without trace on dense, coarse curls. The industry sells products by broad labels — "for dry hair", "for curly hair", "repair" — but those labels hide at least four separate properties that matter more than the label. This module teaches you to identify your own hair across those four properties so that every later recommendation in this course can be filtered through what is true for you.

The four properties are: **curl pattern** (the shape the hair makes), **strand thickness** (how thick each individual strand is), **density** (how many strands you have per area), and **porosity** (how your hair absorbs water — covered in Module 3). Keep them separate in your mind. A person can have fine strands and high density — many thin hairs, giving full-looking hair that is easily weighed down. Another person can have coarse strands and low density — few thick hairs, giving hair that feels strong but looks sparse. The routines for those two people are almost opposite.

## 2.2 Curl pattern

Curl pattern describes the shape of the hair as it grows. The most widely used system groups hair into four families, numbered 1 to 4, with sub-letters a to c for increasing curl tightness. Use it as a rough map, not a precise identity. Most people have more than one pattern on their head — tighter at the nape, looser at the crown, for example — and pattern can change with length, weight, hormones, and damage.

- **Type 1 — Straight.** The hair falls straight from root to tip, with no wave or curl. Sub-types 1a (very fine and flat), 1b (a little body), and 1c (coarse, with a slight bend) are all straight. Straight hair reflects light well and looks shiny, sebum travels easily so roots can become oily, and it is the pattern most easily weighed down by heavy products.
- **Type 2 — Wavy.** The hair forms loose S-shaped waves. 2a is a gentle, barely-there wave; 2b has more defined waves that can frizz; 2c has strong waves that may begin to form loose curls at the ends. Wavy hair often sits between straight and curly routines: it needs more moisture than straight hair, but less weight than curly hair, and it is the pattern most often mistaken for "straight hair that will not behave".
- **Type 3 — Curly.** The hair forms clear curls or ringlets. 3a curls are large and loose; 3b curls are tighter, springy ringlets; 3c curls are tight corkscrews. Curly hair is prone to dryness because sebum struggles to travel around the bends, and to frizz when the cuticle is disturbed. It usually needs more moisture, gentle handling, and styling methods that preserve the curl shape rather than pulling it apart.
- **Type 4 — Coily.** The hair forms tight coils or zig-zag patterns. 4a coils are small, defined, and springy; 4b has a zig-zag shape with less defined curls; 4c is very tight, with a pattern that may be hard to see and significant shrinkage — the hair can look far shorter than it is when stretched. Coily hair is the most fragile of the patterns because each bend is a point of weakness, and it is typically the driest, because sebum has the longest, most winding journey. It needs the most moisture, the most protection, and the gentlest detangling.

**How to check your pattern.** Wash your hair with a gentle shampoo, apply a light conditioner, rinse, and then let it air-dry with no product and no touching. Look at the shape it takes on its own. That is your pattern. Do this once, note it in the workbook, and do not chase a different pattern: the goal is to care for the hair you have.

A note on texture words: in everyday speech, "texture" is sometimes used to mean curl pattern and sometimes to mean how thick or coarse a strand feels. In this course, curl pattern and strand thickness are treated separately, so that you can describe your hair precisely — for example, "type 3b curls, fine strands, high density".

## 2.3 Strand thickness: fine, medium, or coarse

Strand thickness is about one hair, not your whole head. Take a single shed strand and compare it with a sewing thread, or roll it between your fingers.

- **Fine hair** is thin, soft, and often hard to feel between your fingers. It is easily weighed down, can look limp with heavy products, and is more vulnerable to breakage from rough handling because each strand is thinner. Fine hair usually needs lightweight products, smaller amounts, and careful rinsing.
- **Medium hair** is the most common thickness. It is easy to feel between your fingers, holds styles reasonably well, and tolerates a wider range of products.
- **Coarse hair** is thick, wiry, and easy to feel — sometimes thicker than a sewing thread. It can feel rough, resists bending, holds a lot of volume, and usually needs richer products and more moisture to feel soft. Coarse hair is strong per strand but can still break if it is dry and handled roughly.

**The thread test.** Hold a single strand next to a standard sewing thread. If the hair is clearly thinner than the thread, it is fine. If it is about the same, it is medium. If it is clearly thicker, it is coarse. Do this with three or four strands from different parts of your head and note the most common result.

## 2.4 Density: low, medium, or high

Density is how much hair you have — how closely the strands are packed together. Part your hair in the middle and look at your scalp in a mirror in good light.

- **Low density:** you can see your scalp easily through the part, even without pulling the hair apart.
- **Medium density:** you can see some scalp in the part, but it is partly covered.
- **High density:** you can barely see your scalp in the part; the hair covers it densely.

Density changes the amount of product you need and how your hair behaves in styles. High-density hair needs more product per application and more time to wash and dry, and it can hide damage and dryness underneath the top layer. Low-density hair needs lighter products and less of them, and styles that add volume at the root will be more visible. Density also matters for expectations: a person with low density and fine strands will not get the same visual fullness as a person with high density and coarse strands, however good the routine — and that is normal, not a failure.

## 2.5 Length, shrinkage, and the ends

Two more things are worth recording, because they shape your routine. First, your **length**: short hair (above the shoulders) needs less product and less time, and damage shows quickly because there is little length to hide it; long hair has older ends that have survived years of washing, brushing, sun, and styling, and those ends need the most protection. Second, **shrinkage**: curly and coily hair can shrink by 30 to 75 percent of its stretched length. Shrinkage is a sign of healthy elasticity, not a problem, but it means length checks should be done on stretched hair, and styles should be chosen with shrinkage in mind.

## 2.6 Putting it together: your hair profile

By the end of this module you should be able to write a one-line profile of your hair, for example:

- "Type 2c waves, medium strands, high density, low porosity."
- "Type 4b coils, fine strands, medium density, high porosity."
- "Type 1b straight, fine strands, low density, normal porosity."

That line is the filter for the rest of the course. When Module 6 suggests a routine, check it against your profile: if you have fine, low-density, straight hair, choose the lightest version; if you have coarse, high-density, coily hair, choose the richest version. The workbook's hair-type assessment (Worksheet 1) walks you through each test step by step and gives you a place to record the result.

## 2.7 Module 2 — Key takeaways

1. Curl pattern, strand thickness, density, and porosity are four separate properties. Know all four before choosing products.
2. Most people have more than one curl pattern on their head. Record the most common one.
3. Fine hair is easily weighed down; coarse hair usually needs richer products; density decides how much product you need.
4. Shrinkage in curly and coily hair is normal and a sign of elasticity.
5. Write your one-line hair profile and use it as the filter for every later module.

---

# Module 3 — Porosity: The Key That Changes Everything

## 3.1 What porosity is

Porosity is a measure of how easily your hair absorbs water and other substances, and how easily it lets them go again. It is decided by the state of the cuticle: when the cuticle scales lie flat and tight, water has trouble getting in — and trouble getting out. When the scales are lifted, chipped, or missing, water rushes in quickly — and escapes just as quickly. Porosity is the single most useful property for choosing products, because it predicts whether your hair will feel moisturised after a treatment or dry again within hours.

Porosity is usually described in three bands — low, normal (sometimes called medium), and high — and your porosity can differ along the length of a strand. The ends of long hair are almost always more porous than the roots, because they are older and have been through more washing, sun, and styling. Chemical services, heat, and physical wear all raise porosity. Porosity can improve over time as damaged lengths are trimmed away and new growth is protected, but it cannot be changed overnight.

## 3.2 Low porosity

**What it is.** The cuticle is tight and flat. Water beads on the surface and takes a long time to soak in. Products tend to sit on top of the hair rather than being absorbed.

**What it feels like.** Hair takes a long time to get fully wet in the shower. It takes a long time to dry. Products can build up and leave a coated, greasy, or stiff feeling, especially heavy butters and thick oils. Conditioner seems to "sit" on the hair. Treatments can feel as though they do nothing.

**What helps.** Use warmth to help the cuticle open slightly: warm (not hot) water when washing, and gentle heat — a warm towel, a shower cap worn for 15 to 20 minutes, or a few minutes under a hooded dryer on a low setting — when deep conditioning. Apply products to damp, warm hair rather than soaking wet or dry hair. Choose lighter, water-based products: leave-in sprays, light lotions, and thin oils rather than heavy butters. Use less product than you think you need, and clarify regularly (see Module 6) so that build-up does not block moisture from getting in. Avoid layering many heavy products at once.

**Common mistake.** Adding more and more heavy product because the hair still feels dry. With low porosity, the problem is usually not a lack of product — it is that the product cannot get in. More product makes the coating thicker and the problem worse.

## 3.3 Normal (medium) porosity

**What it is.** The cuticle is in good condition — slightly open enough to let moisture in, tight enough to hold it. This is the easiest porosity to care for.

**What it feels like.** Hair gets wet without a long wait, dries in a reasonable time, holds styles well, and responds predictably to most products. It is not especially prone to frizz or to build-up, and it rarely needs intensive repair unless it has been chemically treated or heat-damaged.

**What helps.** A balanced routine is enough: gentle cleansing, regular conditioning, occasional deep conditioning (every two to four weeks), and heat protection when styling. Normal-porosity hair is the best candidate for experimenting with new products, because it forgives mistakes more readily than low- or high-porosity hair. The main risk is complacency — over time, heat and chemical services can push normal porosity into high porosity, so the protective habits in Modules 5 and 7 still matter.

## 3.4 High porosity

**What it is.** The cuticle is lifted, chipped, or partly missing, often because of chemical services, frequent heat styling, sun exposure, rough brushing, or a long history of wear. Water enters very fast — and leaves very fast.

**What it feels like.** Hair gets soaking wet almost immediately and can feel heavy with water, then dries very quickly. It tangles easily, feels rough or straw-like, frizzes in humidity, and can look dull even after conditioning. Colour fades faster, because pigment escapes through the open cuticle. Treatments seem to work for a day and then the dryness returns.

**What helps.** High-porosity hair needs a "layer and seal" approach: water or a water-based leave-in first, then a cream to add softness, then a thin layer of oil or butter to slow moisture loss — the method often called LOC (liquid, oil, cream) or LCO (liquid, cream, oil), described in detail in Module 7. Protein treatments help temporarily by filling gaps in the cuticle, but they must be balanced with moisture, or hair can feel stiff and brittle. Rinse with cool water at the end of washing to help the cuticle lie flatter. Avoid over-washing, avoid hot water, and protect the hair from sun and friction. Regular trims matter more for high-porosity hair, because the most porous part is usually the oldest, most damaged ends.

**Common mistake.** Using only oil on dry hair and expecting it to moisturise. Oil does not add water; it slows water loss. On high-porosity hair that is already dry, oil alone seals in the dryness. Water (or a water-based product) must come first.

## 3.5 How to test your porosity

No single test is definitive. Use three tests together and look for agreement between at least two of them. Test clean hair — product residue changes the result — and test strands from more than one part of your head.

**Test 1 — The float test.** Take a clean, shed strand and drop it into a glass of room-temperature water. Wait two to four minutes. If it floats on the surface, that suggests low porosity. If it sinks slowly to the middle, that suggests normal porosity. If it sinks quickly to the bottom, that suggests high porosity. Note the limits of this test: surface tension, the shape of the strand, and any residue can affect the result, so never rely on it alone.

**Test 2 — The spray test.** On clean, dry hair, mist a small section with water from a spray bottle. If the water sits as visible beads on the surface for a minute or more, that suggests low porosity. If the water soaks in within a few seconds, that suggests high porosity. If it soaks in over 30 seconds or so, that suggests normal porosity.

**Test 3 — The slide test.** Take a single strand between your thumb and forefinger and slide your fingers up the strand, from tip toward root — against the direction of the cuticle. If it feels smooth, the cuticle is probably flat (low or normal porosity). If it feels bumpy, rough, or catches, the cuticle is probably lifted (high porosity). This test is subtle and takes practice; compare strands from your roots and your ends and notice the difference.

**Test 4 — The drying test.** After washing, note how long your hair takes to dry without heat or products. Low-porosity hair often takes several hours; high-porosity hair can be substantially dry within an hour or two; normal porosity falls in between. This test is affected by density and thickness, so use it as supporting evidence, not as a verdict on its own.

Record your results in Worksheet 1 of the workbook. If two tests agree, go with that result. If all three disagree, repeat the tests on a different wash day and, in the meantime, follow the normal-porosity routine — it is the safest middle ground.

## 3.6 Worked example: three porosity results, three routines

**Example A — Low porosity, type 2b waves, fine strands.** Maya mists her hair and the water beads for over a minute. Her hair takes four hours to air-dry. Heavy masks leave it limp and coated. Her routine: wash with warm water and a lightweight shampoo; condition with a light, water-based conditioner; deep-condition once a month with gentle heat (a shower cap and a warm towel for 20 minutes); use a pea-sized amount of leave-in spray and a single drop of light oil on the ends only; clarify once a month. Within three weeks, her waves hold better and the coated feeling is gone — because she stopped adding product her hair could not absorb.

**Example B — Normal porosity, type 3a curls, medium strands.** Jordan's strand sinks slowly in the float test and absorbs a mist in about 30 seconds. Her routine: wash two to three times a week, condition every wash, deep-condition every three weeks, use a leave-in cream and a gel to define curls, and protect from heat with a heat protectant on the rare occasions she diffuses. Her main job is consistency and protection, not repair.

**Example C — High porosity, type 4c coils, coarse strands, colour-treated.** Amara's hair soaks up a mist instantly, dries within an hour, tangles easily, and her colour fades quickly. Her routine: pre-wash detangling with conditioner and a wide-tooth comb; wash once a week with a moisturising shampoo; deep-condition weekly with a balance of moisture and protein (alternating weeks); apply leave-in, then cream, then a thin layer of oil to seal; sleep in a satin bonnet; rinse with cool water. Her colour is refreshed less often, and she trims a small amount every eight weeks. After six weeks, her hair stays moisturised for two to three days after wash day instead of a few hours.

## 3.7 Module 3 — Key takeaways

1. Porosity is about the cuticle: flat cuticle means slow absorption and slow loss; lifted cuticle means fast absorption and fast loss.
2. Low porosity needs warmth, lighter products, and less product — not more.
3. High porosity needs water first, then cream, then a sealant, plus regular trims and cool rinses.
4. Test porosity with at least two methods on clean hair, and test more than one part of your head.
5. Porosity changes over time. Re-test every three to six months, especially after chemical services or a change in heat habits.

---

# Module 4 — Scalp Health: The Foundation of Healthy Hair

## 4.1 Why the scalp comes before the strands

Hair grows from the scalp, and the scalp is skin — living skin, with oil glands, sweat glands, blood vessels, and its own population of micro-organisms. A scalp that is clean, calm, and comfortable grows hair better than a scalp that is clogged with build-up, irritated by harsh products, or inflamed. Many hair complaints that people try to solve with conditioners and masks are actually scalp complaints: itching, flaking, tenderness, or an oily, heavy feeling at the roots. Treating the lengths will not fix a scalp problem.

This module covers normal scalp care and the everyday problems that gentle care can improve. It does not cover diagnosis or treatment of scalp conditions. Dandruff that is severe, persistent, or accompanied by redness, pain, sores, or hair loss is a reason to consult a qualified professional — as are any scalp symptoms that do not improve with a few weeks of gentle care.

## 4.2 What a healthy scalp looks and feels like

A healthy scalp is comfortable: no persistent itching, no tenderness when you press it, no visible redness, no large flakes, and no sore spots. It produces enough sebum to keep the hair supple but not so much that the roots look greasy within a day of washing. You should be able to run your fingers over your scalp without finding thick, waxy build-up or tender bumps. Some flaking of tiny, dry skin cells is normal; large, oily, yellowish flakes or flakes that stick to the scalp are not typical and deserve attention.

## 4.3 Cleansing the scalp

The scalp needs to be cleaned regularly, and the right frequency depends on your hair type, your activity, and your climate.

- **Straight and wavy hair** usually needs washing every one to three days, because sebum travels easily and roots become visibly oily.
- **Curly hair** often does well with washing two to three times a week.
- **Coily hair** often does well with washing once a week, or once every one to two weeks, depending on build-up — but "less often" does not mean "never". The scalp still needs cleaning, and stretching wash day too far can lead to itching, odour, and build-up that blocks follicles.

When you wash, focus the shampoo on the scalp, not the lengths. Use your fingertips — not your nails — to massage the scalp gently for 30 to 60 seconds. This helps lift dirt, sweat, and product residue, and it stimulates blood flow to the area. The lengths will be cleaned enough by the shampoo running down them as you rinse. Scrubbing the lengths together, piling hair on top of the head and rubbing vigorously, or scratching with nails all cause tangling and breakage without cleaning the scalp any better.

Rinse thoroughly. Residue left on the scalp is one of the most common causes of itching and dullness, and it is also one of the easiest to fix: spend at least as long rinsing as you did lathering, and check that the water runs clear.

## 4.4 Common scalp concerns — and what gentle care can do

**Dryness and itching.** A dry, itchy scalp is often caused by infrequent washing, harsh shampoos, hot water, or a build-up of products. Try washing a little more often with a gentle shampoo, using lukewarm water, and avoiding products with heavy fragrance applied directly to the scalp. A light scalp oil massaged in before washing — then washed out — can help some people, but oil left on the scalp for days can worsen build-up and itching for others. If itching persists, worsens, or comes with visible changes to the skin, seek professional advice.

**Flaking.** Small, dry, white flakes that fall easily are often simply dry skin or residue, and they commonly improve with regular gentle washing and thorough rinsing. Oily, yellowish flakes that stick to the scalp or the hair, redness, or flakes accompanied by itching that does not improve are different, and they are a reason to consult a qualified professional rather than trying stronger products at home. Do not try to treat a scalp condition with cosmetic products.

**Oiliness.** Some scalps produce more sebum than others, and production increases in hot, humid weather and after exercise. Washing more often with a gentle shampoo is the simplest response. Dry shampoo can help between washes by absorbing oil at the roots, but it should not replace washing: the powder itself becomes build-up if it is layered day after day. Avoid applying conditioner or heavy styling products directly to the scalp, because they add to the oily feeling and can clog follicles.

**Build-up.** Styling products, oils, and butters accumulate on the scalp over time, especially when washing is infrequent or when products are applied directly to the roots. The signs are a waxy or gritty feeling on the scalp, hair that looks dull even after washing, itching, and styles that do not hold. A clarifying wash (see Module 6) once every few weeks removes this residue. A soft-bristle brush used gently on a dry scalp before washing can also help lift residue — but be gentle, and stop if it causes tenderness.

**Tenderness and tight styles.** If your scalp hurts, is tender to the touch, or you notice small bumps along the hairline, a tight style is a likely cause. Braids, ponytails, and extensions that pull on the follicles cause a type of hair loss called traction alopecia, which can become permanent if the pulling continues for years. Loosen the style, give the scalp a break, and avoid styles that cause pain. Pain is not a sign that a style is "working" — it is a warning. If you already have thinning along the hairline or in the areas where styles pull, consult a qualified professional.

## 4.5 Scalp massage, blood flow, and what is realistic

Gentle scalp massage — with the fingertips, for a few minutes, a few times a week — is a reasonable, low-risk habit. It feels pleasant, it helps distribute sebum, and it can help you notice changes in your scalp early. Some small studies suggest that regular massage may be associated with fuller-feeling hair over time, but the evidence is limited, and massage will not reverse hair loss or create new follicles. Treat it as a supportive habit, not as a treatment, and do not buy expensive devices or oils on the promise of regrowth.

## 4.6 What does not help the scalp

- **Scratching with nails or hard tools.** It damages the skin and can cause infection.
- **Leaving heavy oils and butters on the scalp for days.** They trap sweat, dirt, and dead skin, and they can worsen itching and flaking.
- **Very hot water.** It strips natural oils, dries the scalp, and can worsen irritation.
- **Harsh, frequent clarifying.** A clarifying wash is a reset, not a daily routine. Used too often, it dries the scalp and encourages it to produce more oil.
- **Ignoring symptoms.** A scalp problem that persists for weeks despite gentle care, or that comes with pain, sores, swelling, or hair loss, needs professional assessment — not a new product.

## 4.7 A simple weekly scalp routine

For most people, this is enough:

1. Before washing, gently detangle and check the scalp with your fingertips for tenderness, bumps, or heavy build-up.
2. Wash with a gentle shampoo, massaging the scalp with fingertips for 30 to 60 seconds.
3. Rinse thoroughly with lukewarm water.
4. If you use a scalp oil or treatment, apply it before washing and wash it out, rather than leaving it on for days.
5. Once a month, or sooner if you use many styling products, use a clarifying wash and check how the scalp feels afterwards.
6. Once a week, take a minute to look at your scalp in a mirror and note any change — new tenderness, new flaking, or new thinning — in your hair journal.

## 4.8 Module 4 — Key takeaways

1. The scalp is living skin. Healthy hair starts there.
2. Shampoo the scalp with your fingertips; let the rinse clean the lengths.
3. Wash often enough for your hair type and lifestyle — infrequent washing is not the same as gentle care.
4. Itching, flaking, oiliness, and build-up often improve with regular gentle washing and thorough rinsing.
5. Persistent, painful, or worsening scalp symptoms, or hair loss along with them, are reasons to consult a qualified professional. Do not try to treat them with cosmetics.

---

# Module 5 — Damage: How Hair Breaks, and What Repair Really Means

## 5.1 What "damage" actually means

Hair damage is physical change to the strand: the cuticle is lifted, chipped, or missing; the cortex is weakened; or the strand is broken, split, or thinned. Because the shaft is not alive, damage is cumulative and largely irreversible in the affected length. A strand that has been lightened three times, straightened daily for a year, and brushed roughly when wet does not go back to its original condition, however good the mask. What good care does is three things: it improves how damaged hair looks and feels, it protects it from getting worse, and it protects the new growth so that, over time, the damaged lengths are replaced by healthier hair.

Anyone selling you a product that claims to "repair" or "heal" hair completely is using the word loosely. In cosmetic terms, "repair" means temporarily filling gaps, smoothing the cuticle, reducing friction, and making the hair easier to manage. That is genuinely useful — it can be the difference between hair that snaps when you comb it and hair that survives until your next trim — but it is not the same as rebuilding the strand.

## 5.2 The main causes of damage

**Heat.** Flat irons, curling irons, and high-heat blow-drying boil the water inside the hair shaft, creating tiny bubbles that weaken the cortex — a process sometimes called "bubble hair". Repeated heat above about 180°C (350°F) progressively damages the cuticle and the cortex. Heat damage is cumulative: the harm from a single session is small, but daily heat over months is large. Signs include straight pieces in otherwise curly hair that will not curl again, white dots along the shaft, and ends that feel dry no matter what you apply.

**Chemical services.** Colouring, lightening (bleach), relaxing, and perming all work by opening the cuticle and changing the cortex. Lightening is the most demanding, because it removes pigment and can dissolve part of the keratin structure. Relaxers break the bonds that make hair curly. Each service raises porosity and reduces strength, and overlapping a chemical service onto already-treated hair — applying relaxer or bleach to hair that has already been relaxed or bleached — is one of the fastest ways to cause severe breakage. Always tell a stylist what has already been done to your hair, and follow the recommended waiting time between services.

**Mechanical damage.** This is damage from handling: rough brushing, combing wet hair with a fine-tooth comb, tearing through tangles, tight elastics, rough towel-drying, and friction from pillowcases, collars, and hats. Wet hair is at its most vulnerable because it stretches more and the cuticle is swollen and soft. A single rough detangling session can cause more breakage than a week of gentle handling saves, so the handling habits in Module 6 matter more than most people expect.

**Sun and environment.** Ultraviolet light breaks down keratin and fades colour, especially in hair that is already chemically treated. Chlorine from swimming pools and salt water dry the hair and can change its colour. Wind tangles hair and increases friction. None of these is catastrophic on its own, but together over a summer they add up — which is why protective styles, hats, and a rinse after swimming are worth the small effort.

**Over-processing and over-treatment.** Using a strong protein treatment too often, clarifying too often, or layering many active products can make hair stiff, brittle, and prone to snapping. More is not better. The balance between protein and moisture (Module 7) is the safeguard here.

## 5.3 How to assess your own damage

Work through this assessment on clean, dry hair in good light. Record the results in Worksheet 2 of the workbook.

**1. The ends.** Look at the last five centimetres of your hair. Are the ends thin and wispy compared with the rest? Do you see split ends — strands that fork into two or more tips — or white dots along the shaft? Split ends and white dots are signs of damage that has already happened. The only way to remove a split end is to cut it; no product rejoins it. If you see many splits, a trim is the honest next step.

**2. The stretch test.** Take a single wet strand and stretch it gently. Healthy hair stretches a little (about 20 to 30 percent of its length) and springs back. If it snaps almost immediately with little stretch, it is likely dry or brittle. If it stretches a long way, feels gummy, and does not spring back, it is likely over-processed or lacking protein structure. Do this test on strands from different parts of your head; the ends will usually be weaker than the roots.

**3. The feel test.** Run your fingers down a strand from root to tip. Smooth means the cuticle is in reasonable condition. Rough, catching, or bumpy means the cuticle is lifted or missing. Compare the roots with the ends — a big difference tells you the damage is concentrated in the older lengths, which is the usual pattern.

**4. The tangle test.** Does your hair tangle easily, especially at the ends and at the nape? Hair that tangles constantly is usually hair with a roughened cuticle: the lifted scales catch on each other. Easier detangling after conditioning is a sign that your routine is helping.

**5. The shine and colour test.** Does your hair look dull even after washing and conditioning? Does colour fade within a few washes? Both suggest high porosity and a damaged cuticle (see Module 3).

**Damage levels — a simple scale:**

- **Level 1 — Minimal.** Ends in good condition, few or no splits, hair stretches and springs back, shines after conditioning. Focus: protection and maintenance.
- **Level 2 — Mild.** Some split ends, ends feel a little dry, occasional tangling, colour fades a little faster than expected. Focus: regular trims, weekly deep conditioning, heat protection.
- **Level 3 — Moderate.** Many splits, visible white dots, hair tangles easily, feels rough, stretches poorly or snaps. Focus: a structured repair routine (Module 8), a trim of the worst ends, reduced heat, protein-moisture balance.
- **Level 4 — Severe.** Hair breaks when combed, stretches like chewing gum or snaps immediately, feels straw-like, has lost its curl pattern in places, or breaks off in short pieces. Focus: stop heat and chemical services, cut back damaged length as advised by a stylist, follow a gentle repair routine, and consult a qualified professional if there is also scalp pain, shedding, or hair loss from the root.

## 5.4 Worked example: a damage-assessment case

**Case — Priya, 29, type 2c waves, medium strands, high density, colour-treated twice a year, flat-irons three times a week.**

Priya's complaint is that her ends feel "crunchy" and her waves have gone limp at the ends, although the roots still curl. Her assessment: many split ends in the last four centimetres; the stretch test on end strands snaps almost immediately; the feel test is rough from mid-length down; her colour fades within three weeks. Damage level: 3, moderate, concentrated in the older lengths.

Her plan: first, a trim of four centimetres to remove the worst splits — she keeps most of her length, but the frayed ends are gone. Second, heat is cut to once a week at most, always with a heat protectant, and never above 180°C. Third, she alternates a moisture mask one week and a light protein treatment the next (Module 7). Fourth, she switches to a wide-tooth comb on wet hair and a satin pillowcase. After eight weeks she repeats the assessment: the stretch test improves, tangling is less, and the new growth at the roots feels smooth. The damaged mid-lengths are not "healed" — they are improved and protected while new, healthier hair grows in.

## 5.5 What repair can and cannot do — the honest summary

| Claim | What is true |
|---|---|
| "This mask repairs damage." | It can temporarily fill gaps, smooth the cuticle, and make hair feel stronger and easier to comb. It does not rebuild the strand. |
| "Split ends can be sealed." | Some products can temporarily glue a split together so it looks sealed. The bond washes out, and the split returns. Cutting is the only permanent fix. |
| "Protein rebuilds hair." | Protein treatments add protein-like material to the surface and can make hair feel stronger for a while. They do not restore the original internal structure. |
| "This product makes hair grow faster." | No cosmetic product changes the rate at which follicles produce hair. A healthy scalp and gentle handling reduce breakage, so hair *keeps* more of its length — which looks like faster growth, but is actually less loss. |
| "Trimming makes hair grow faster." | Trimming does not change the growth rate at the root. It removes damaged ends so that hair does not break off — which, again, means you keep more length. |

## 5.6 Module 5 — Key takeaways

1. Damage is cumulative and largely irreversible in the affected length. Repair means improving, protecting, and gradually replacing — not rebuilding.
2. Heat, chemical services, rough handling, sun, and over-treatment are the main causes. Most of them are within your control.
3. Assess damage honestly with the ends, stretch, feel, tangle, and shine checks before choosing a routine.
4. Split ends can only be removed by cutting. Products can make them look better temporarily.
5. Reducing breakage is the real goal: hair that does not break keeps its length, which is what most people mean by "growth".

---

# Module 6 — The Core Routine: Cleansing, Conditioning, and Daily Care

## 6.1 The routine in one paragraph

A good core routine has four steps: cleanse the scalp, condition the lengths, detangle gently, and protect the hair between washes. Everything else — masks, oils, styling products — is an addition to this core, not a replacement for it. If your core routine is wrong, no treatment will save it; if your core routine is right, many people need very little else.

## 6.2 Cleansing: choosing and using shampoo

Shampoo exists to clean the scalp and remove dirt, sweat, oil, and product residue. It is not a treatment for the lengths, and it does not need to be expensive to work well.

**How often?** Let your scalp and your hair type decide (see Module 4). As a starting point: straight hair every one to three days; wavy hair every two to three days; curly hair two to three times a week; coily hair once a week. Adjust for exercise, climate, and how much product you use. If your scalp itches, smells, or feels coated, you are waiting too long. If your hair feels stripped, squeaky, and tangled after every wash, you may be washing too often or using too strong a shampoo.

**How to wash.** Wet the hair thoroughly with lukewarm water. Apply a small amount of shampoo to the scalp — about a coin-sized amount for short hair, more for dense or long hair — and massage with your fingertips for 30 to 60 seconds. Let the lather run down the lengths as you rinse; do not scrub the lengths. If your hair is very dirty or you have used heavy products, a second, lighter lather is fine. Rinse thoroughly until the water runs clear.

**Choosing a shampoo.** The label matters less than the behaviour: a good shampoo for you cleans the scalp without leaving the hair feeling stripped, tangled, or coated. People with dry or curly hair often prefer sulphate-free or gentler formulas; people with oily scalps or heavy build-up often need a stronger cleanser. If a shampoo leaves your hair feeling squeaky-clean and hard to comb, it is too strong for you, however "clarifying" the label says it is. If it leaves your scalp feeling coated after rinsing, it is too mild or you are not rinsing enough.

**Clarifying.** A clarifying shampoo is a stronger cleanser designed to remove build-up. Use it once every three to six weeks, or sooner if you use many styling products, swim regularly, or have hard water. It is a reset, not a daily shampoo: using it every wash will dry the hair and scalp. Always follow a clarifying wash with a good conditioner or a deep-conditioning treatment.

**Co-washing.** Washing with conditioner instead of shampoo (co-washing) can work for some people with dry, curly, or coily hair, because it cleans very gently and adds moisture. It does not clean the scalp as thoroughly as shampoo, so most people who co-wash still need a shampoo wash regularly — typically every one to two weeks — to remove build-up. If your scalp itches or your hair feels coated, co-washing alone is not enough for you.

## 6.3 Conditioning: the step that does the most visible work

Conditioner smooths the cuticle, reduces friction, makes detangling possible, and helps hair hold moisture. It is the single most important product in most routines.

**How to use it.** After shampooing, squeeze excess water from the hair — conditioner works better on damp hair than on dripping hair. Apply conditioner from mid-length to ends, where the hair is oldest and driest. Apply only a small amount near the roots, and none directly on the scalp, unless the product is specifically designed for scalp use. Leave it for two to five minutes, then detangle gently (see below) and rinse with lukewarm water. For high-porosity or very dry hair, a final rinse with cool water can help the cuticle lie flatter.

**Leave-in conditioner.** A leave-in is a lighter conditioner that is not rinsed out. It adds a layer of moisture and protection that lasts between washes, makes detangling easier, and helps styling products work better. Apply a small amount to damp hair, from mid-length to ends. Fine or straight hair usually needs a very small amount — a pea-sized amount or a few sprays — while thick or coily hair may need more. If your hair feels coated or limp, you are using too much.

**Deep conditioning.** A deep conditioner or hair mask is a richer treatment left on for 15 to 30 minutes, often with gentle heat. Use it once a week if your hair is damaged, dry, or high-porosity; every two to four weeks if your hair is in good condition. Apply to damp, clean hair, cover with a shower cap, and let body heat — or a warm towel — help it work. Rinse thoroughly. Deep conditioning is covered in detail in Module 7.

## 6.4 Detangling: the habit that prevents most breakage

Most breakage happens during detangling, not during styling. The rules are simple and worth following exactly:

1. **Detangle wet hair with conditioner in it, or damp hair with leave-in.** Dry detangling of curly or coily hair causes frizz and breakage; wet detangling without conditioner causes snapping. The slip from conditioner is what lets the comb pass through.
2. **Use a wide-tooth comb or your fingers.** Fine-tooth combs and brushes with stiff bristles catch and snap hair. A wide-tooth comb, used gently, is the safest tool for most hair. Finger-detangling is the gentlest method of all for very curly or coily hair, though it takes longer.
3. **Start at the ends and work upward.** Hold the section above the tangle so that you are not pulling on the roots, gently work out the ends first, then move a little higher, and repeat until the comb passes through the whole section.
4. **Work in sections.** Divide the hair into four to eight sections with clips. Detangling one section at a time is faster and gentler than trying to comb through all the hair at once.
5. **Never force it.** If the comb stops, stop. Add more conditioner or water, hold the hair above the tangle, and work it out slowly. Forcing a comb through a knot breaks hair.

## 6.5 Drying: how you dry matters as much as how you wash

**Towel-drying.** Do not rub the hair vigorously with a towel. Rubbing lifts the cuticle, causes frizz, and breaks hair. Instead, press or squeeze the hair gently with a towel, or wrap it in an old cotton T-shirt or a microfibre towel, which are smoother than a standard terry towel. Squeeze, do not rub.

**Air-drying.** Air-drying is the gentlest option. Let the hair dry naturally, and avoid touching it while it dries — touching disturbs the curl pattern and creates frizz. If you need to speed things up, use a diffuser on a low heat setting (see Module 7) rather than a high-heat blast.

**Blow-drying.** If you blow-dry, always use a heat protectant first, keep the dryer moving, hold it at least 15 centimetres from the hair, and use the lowest heat setting that gets the job done. Dry the roots first, then the lengths. Finish with a short blast of cool air to help the cuticle lie flat.

## 6.6 Daily and nightly care

**Between washes.** The goal is to protect the hair from friction and dryness. For curly and coily hair, a light refresh — a mist of water, a small amount of leave-in, and gentle reshaping with the hands — can revive a style on day two or three without a full wash. For straight hair, a light brush with a soft-bristle brush can distribute sebum from the roots to the ends. Avoid re-applying heavy products every day; layering product on product is how build-up forms.

**At night.** Hair rubs against the pillow for hours, and that friction causes breakage and frizz. The simplest protection is a satin or silk pillowcase, which is smoother than cotton. A satin bonnet, scarf, or a loose "pineapple" ponytail — hair gathered loosely at the very top of the head — protects curls overnight. Braiding the hair loosely before bed reduces tangling for wavy and straight hair. Avoid tight ponytails or elastics with metal parts overnight.

**Exercise and swimming.** Tie the hair up loosely for exercise, and wash or at least rinse it after heavy sweating. Before swimming, wet the hair with clean water and apply a little conditioner — hair that is already wet absorbs less chlorinated or salt water. Rinse thoroughly after swimming and condition as usual.

## 6.7 A note for junior stylists

If you are a junior stylist using this programme to advise clients, the core routine is the most valuable thing you can teach. Most clients do not need a new product; they need to be shown how to wash, condition, and detangle correctly. Walk them through the steps in this module on their own hair, ask them to show you how they detangle, and correct the handling gently. A client who leaves knowing how to detangle without breaking hair will come back — and will trust your advice on treatments in Module 7. Use the consultation script in the templates folder to structure that conversation.

## 6.8 Module 6 — Key takeaways

1. The core routine is: cleanse the scalp, condition the lengths, detangle gently, protect between washes.
2. Shampoo the scalp with fingertips; let the rinse clean the lengths. Rinse thoroughly.
3. Conditioner goes on the mid-lengths and ends, not the scalp. Leave-in conditioner protects between washes.
4. Detangle wet hair with conditioner in it, with a wide-tooth comb, starting at the ends and working upward, in sections.
5. Do not rub hair dry with a towel. Squeeze gently, air-dry when you can, and protect hair at night with satin or a loose protective style.

---

# Module 7 — Treatments: Masks, Protein, Moisture, Oils, Heat, and Chemical Care

## 7.1 Treatments are additions, not the routine

A treatment is anything beyond the core routine of Module 6: a mask, a protein treatment, an oil, a scalp treatment, or a styling aid. Treatments are useful, but they work only on top of a sound core routine. A weekly mask will not rescue hair that is washed with a harsh shampoo, detangled roughly, and flat-ironed daily. Fix the core first, then add one treatment at a time and judge it over two to three weeks.

## 7.2 Moisture treatments: masks and deep conditioning

Moisture treatments add water and water-attracting ingredients to the hair and help it hold on to that water. They are the right choice when hair feels dry, rough, or straw-like, tangles easily, or looks dull.

**What to look for.** A good moisture mask lists water as the first ingredient and includes conditioning agents and humectants — ingredients that attract water, such as glycerin, honey, or aloe — and emollients that smooth the cuticle, such as fatty alcohols (cetyl alcohol, stearyl alcohol) or light oils. Do not be put off by the word "alcohol" on a label: fatty alcohols are conditioning agents, not the drying kind of alcohol (see Appendix C).

**How to use a mask.** Apply to clean, damp hair, from mid-length to ends. Cover with a shower cap and leave for 15 to 30 minutes. Gentle heat — a warm towel over the cap, or a few minutes under a hooded dryer on low — helps the treatment penetrate, and is especially useful for low-porosity hair. Rinse thoroughly with lukewarm water, finishing with a short cool rinse.

**How often?** Once a week for dry, damaged, or high-porosity hair; every two to four weeks for hair in good condition. More often is not better: over-moisturised hair can feel limp, stretchy, and weak — a condition sometimes called "hygral fatigue" from repeated swelling and drying. If your hair starts to feel mushy or overly soft, cut back on moisture treatments and check the protein balance below.

**A simple at-home moisture mask.** If you prefer a homemade option, a basic recipe is: two tablespoons of plain yoghurt (or mashed avocado), one tablespoon of honey, and one teaspoon of a light oil such as olive oil, mixed and applied to damp hair for 20 minutes, then rinsed and washed as usual. Homemade recipes are not standardised and results vary; always patch-test, avoid leaving food-based mixtures on the scalp for long periods, and rinse thoroughly. They are an option, not a requirement — a well-chosen shop-bought mask works just as well and is more consistent.

## 7.3 Protein treatments: strength, in the right dose

Protein treatments add protein-like material — commonly hydrolysed keratin, wheat, silk, or soy protein — to the surface of the hair. They temporarily fill small gaps in the cuticle and make the strand feel stronger, firmer, and less stretchy. They are useful for hair that has been chemically treated, heat-damaged, or over-moisturised.

**Signs you may need protein.** Hair stretches a long way when wet and does not spring back; it feels limp, gummy, or mushy; it breaks easily despite being well moisturised; or it has recently been lightened, relaxed, or permed.

**Signs you have had too much protein.** Hair feels stiff, straw-like, and brittle; it snaps easily; it looks dull; it feels dry even after conditioning. This is sometimes called "protein overload". It is not permanent damage — it is a temporary imbalance that improves when you stop protein treatments and return to moisture-focused care for a few weeks.

**How to use protein.** Use a light protein conditioner or a protein treatment every two to four weeks for chemically treated or damaged hair, and less often — every six to eight weeks or not at all — for hair in good condition. Always follow a protein treatment with a moisture treatment or a moisturising conditioner: protein without moisture makes hair stiff. The balance matters more than either one alone. A useful rule of thumb: if your hair feels weak and stretchy, it needs protein; if it feels stiff and brittle, it needs moisture; if it feels good, leave the balance alone.

**The protein-moisture balance in practice.** Alternate the two. For example, in a four-week cycle for moderately damaged hair: week one, moisture mask; week two, light protein treatment followed by moisture conditioner; week three, moisture mask; week four, rest — core routine only. Adjust from there based on how your hair feels. Keep notes in the workbook tracker so that you can see the pattern over time rather than guessing.

## 7.4 Oils and butters: sealants, not moisturisers

Oils and butters are often misunderstood. They do not add water to hair. What they do is coat the strand, reduce friction, add shine, and — most importantly — slow down the loss of water from the hair. They are sealants. Used correctly, they are valuable; used on dry hair with no water underneath, they seal in dryness.

**How to use oil.** Apply oil to damp hair, after a water-based leave-in or cream, so that there is moisture to seal in. Use a small amount — a few drops for fine hair, a little more for thick or coily hair — and concentrate on the ends, where the hair is oldest and driest. A small amount of oil on the ends before bed, or before a protective style, can reduce friction and breakage.

**Choosing an oil.** Lighter oils — such as argan, jojoba, grapeseed, or sweet almond oil — suit fine and straight hair and are less likely to weigh it down. Heavier oils and butters — such as coconut oil, shea butter, or castor oil — suit thick, coarse, or coily hair, which needs more weight and sealing. Coconut oil is one of the few oils that can penetrate the hair shaft to some extent, which is why it works well as a pre-wash treatment for some people; for others it makes hair feel stiff or causes build-up, so test it on a small section first.

**Pre-wash oil treatments.** Applying oil to the hair 30 minutes to a few hours before washing — sometimes called "pre-poo" — can reduce the swelling that happens when hair absorbs water during washing, and can make detangling easier. Apply to dry hair, work through the lengths, detangle gently, then wash as usual. This is particularly useful for high-porosity or very tangled hair.

**Butters.** Shea butter, cocoa butter, and similar products are thicker than oils and are best used in small amounts on the ends, or as part of a cream, rather than applied heavily to the whole head. Too much butter leaves hair coated, dull, and weighed down, and it builds up on the scalp.

## 7.5 The LOC and LCO methods

For high-porosity, curly, or coily hair, layering products in a deliberate order helps moisture last between washes. Two orders are commonly used:

- **LOC — Liquid, Oil, Cream.** Apply a water-based liquid (water or a leave-in spray), then a thin layer of oil, then a cream to seal and soften.
- **LCO — Liquid, Cream, Oil.** Apply the liquid, then the cream, then the oil last to seal everything in.

Which works better depends on your hair: LCO often suits hair that needs the cream to absorb before the oil seals it; LOC often suits hair that needs the oil to lock in the liquid before the cream adds softness. Try each for two weeks and compare how your hair feels on day two and day three after wash day. Use small amounts — layering is about order, not quantity. Fine or low-porosity hair usually does not need all three layers; a liquid and a light cream are often enough.

## 7.6 Heat styling: how to do it with the least harm

Heat is not forbidden — it is a tool with a cost. The goal is to get the style you want at the lowest temperature, for the shortest time, with protection in place.

1. **Always use a heat protectant.** Apply it to damp hair before blow-drying and to dry hair before using a flat iron or curling iron. It does not make heat harmless, but it reduces the damage.
2. **Use the lowest effective temperature.** For fine or damaged hair, stay below 150°C (300°F). For medium hair, 150–180°C (300–350°F) is usually enough. Only very coarse, resistant hair needs temperatures above 180°C, and even then it should be used sparingly. If your iron has no temperature display, use its lowest or medium setting.
3. **Do not iron the same section repeatedly.** One slow, steady pass is less damaging than five quick passes. If the hair is not straight after one pass, the temperature is too low or the section is too thick — take a thinner section rather than repeating the pass.
4. **Do not use heat on soaking wet hair.** Blow-dry until the hair is about 80 percent dry, then style. Using a flat iron on wet hair boils the water inside the shaft.
5. **Limit frequency.** Daily heat styling is one of the fastest routes to cumulative damage. If you heat-style, aim for no more than once or twice a week, and give the hair heat-free days in between.
6. **Watch for warning signs.** Straight pieces that will not curl again, white dots on the shaft, a burning smell, or hair that breaks when you comb it after styling are all signs that the heat is too high or too frequent. Reduce the temperature, reduce the frequency, and let the hair recover.

## 7.7 Chemical services: colour, lightening, relaxing, and perming

Chemical services change the hair permanently, and they deserve respect and planning. This section describes what they involve and how to reduce the risk. It does not replace the advice of a qualified stylist, and chemical services should be carried out by, or under the guidance of, a trained professional — especially lightening and relaxing, which can cause serious damage or scalp injury if done incorrectly.

**Colour and lightening.** Permanent colour and bleach open the cuticle and change the cortex. Lightening is the most demanding service: it removes pigment and weakens the keratin structure, raises porosity, and makes hair more vulnerable to heat and breakage. If you lighten your hair, expect to need more conditioning, more frequent trims, and lower heat. Wait the recommended time between lightening sessions, never overlap bleach onto already-lightened hair, and always do a strand test and a patch test before a full application, following the product instructions.

**Relaxing.** Relaxers break the bonds that make hair curly, straightening it permanently until new growth appears. They are strong chemicals that can burn the scalp and break the hair if left on too long or applied to already-relaxed hair. Relaxers should be applied by a trained professional, with a scalp protectant, and never on a scalp that is irritated, scratched, or sore. The hair needs intensive conditioning and protein-moisture balance afterwards (see 7.3).

**Perming.** Perms use chemicals to create curl in straight hair, by breaking and reforming bonds. Like relaxing, they raise porosity and reduce strength, and they need the same aftercare: gentle handling, regular conditioning, and reduced heat.

**After any chemical service.** For the first week, be especially gentle: no heat styling, no tight styles, no further chemical services, and no vigorous brushing. Deep-condition once a week for the first month. Watch for signs of over-processing — hair that stretches like chewing gum, breaks easily, or feels mushy — and consult your stylist promptly if you see them. Keep a record of what was done, when, and with which products, so that the next stylist knows the hair's history.

**A note on "natural" and "organic" chemical products.** A product labelled natural or organic can still be a strong chemical that changes the hair's structure. Henna, for example, coats the hair and can react badly with later chemical services. Always tell your stylist about everything you have used, including henna and home treatments.

## 7.8 Choosing products: a practical approach

The product market is overwhelming, and marketing claims are not a reliable guide. Use this approach instead:

1. **Start from your hair profile** (Module 2) and your porosity (Module 3). A product that suits your profile is more likely to work than a product with an attractive claim.
2. **Read the ingredient list, not the front of the bottle.** The first five ingredients make up most of the product. Water first is a good sign for a moisturising product. See Appendix C for a label-reading guide.
3. **Buy one product at a time and test it for two to three weeks.** If you buy five new products at once, you will not know which one helped or hurt.
4. **Use the right amount.** Most people use too much product. Start with less than you think you need, add more only if the hair still feels dry or undefined, and rinse thoroughly.
5. **Keep a short list of products that work for you, and note the ones that did not — and why.** The workbook's product-selection worksheet is designed for this.
6. **Be sceptical of miracle claims.** No shampoo grows hair faster, no mask rebuilds a strand, and no oil cures hair loss. A product that promises a specific medical outcome is making a claim it cannot support.

## 7.9 Module 7 — Key takeaways

1. Treatments sit on top of a sound core routine. Fix the core first.
2. Moisture means water; protein means temporary surface strength. They must be balanced — too much of either causes problems.
3. Oils and butters seal moisture in; they do not add it. Apply them to damp hair, after a water-based product.
4. Use the lowest effective heat, always with a heat protectant, and limit heat styling to once or twice a week.
5. Chemical services change hair permanently. They should be done by a trained professional, with strand and patch tests, and with proper aftercare.

---

# Module 8 — Your 12-Week Repair Plan and Long-Term Maintenance

## 8.1 Why 12 weeks

Twelve weeks is long enough for three things to happen: the hair you grow during the plan is about three centimetres long, so you can see and feel new, healthier growth at the roots; the damaged lengths have had enough gentle handling and conditioning for the improvement to be visible; and you have had enough wash days to judge whether a routine is working, rather than reacting to a single good or bad day. Twelve weeks is also short enough to stay motivated. Think of it as one season of deliberate care.

## 8.2 Before you start: your baseline

In week zero — the week before the plan starts — do the following and record everything in the workbook:

1. Complete Worksheet 1 (hair type and porosity) and Worksheet 2 (damage assessment). Note your damage level (1 to 4).
2. Take a photograph of your hair in good light, from the front and the back, on wash day and on day three. Photographs are more reliable than memory.
3. Measure a section of hair if you wish to track length: mark a strand at the root with a small clip, or note where the ends fall against a fixed point, such as a shoulder seam.
4. List the products you currently use, and set aside any that you know do not work for you.
5. Book a trim if your damage level is 3 or 4, or if you have many split ends. A trim at the start makes the whole plan more effective, because you are not spending twelve weeks protecting ends that are already beyond help.

## 8.3 The plan, week by week

**Weeks 1–2 — Reset and learn.**
- Clarifying wash in week one, followed by a deep-conditioning mask.
- Start the core routine from Module 6: gentle scalp cleansing, conditioning the lengths, detangling with a wide-tooth comb in sections.
- Stop heat styling entirely for these two weeks, or reduce it to once a week at most with a heat protectant.
- Start the hair journal: after every wash, note how the hair felt, how long it took to dry, and how it looked on day two and day three.
- Switch to a satin pillowcase or bonnet at night.

**Weeks 3–4 — Establish the routine.**
- Settle into your regular wash frequency for your hair type.
- Introduce one treatment: a weekly moisture mask for dry or high-porosity hair, or a fortnightly mask for hair in good condition.
- If your hair is chemically treated or feels weak and stretchy, add a light protein treatment in week four, followed by a moisturising conditioner.
- Check your scalp: is the itching, flaking, or oiliness improving? If not, revisit Module 4.

**Weeks 5–8 — Repair and protect.**
- Continue the weekly mask (or fortnightly, as appropriate). Alternate moisture and protein if your hair needs both — never use a strong protein treatment two weeks in a row.
- Keep heat to once a week at most, at the lowest effective temperature, always with a protectant.
- Trim a small amount (about one centimetre) at week six if the ends still look thin or frayed — this is a dusting, not a cut, and it removes the worst of the remaining splits.
- Try the LOC or LCO method (Module 7) if you have high-porosity, curly, or coily hair and your moisture is not lasting to day three.
- Review your journal at the end of week eight: what has improved? What has not? Change one thing, not five.

**Weeks 9–12 — Consolidate and judge.**
- Continue the routine that is working. Do not introduce new products in these four weeks — you are testing what you have, not shopping.
- Take the same photographs again in week twelve, in the same light and from the same angles.
- Repeat the damage assessment (Worksheet 2) and the porosity tests (Module 3). Compare with your baseline.
- Decide what to keep, what to change, and what your long-term routine will be (see 8.5 below).

## 8.4 A worked example: a complete 12-week repair plan

**Case — Sofia, 34, type 3b curls, fine strands, high density, high porosity, damage level 3 after two years of daily flat-ironing and a lightening service six months ago.**

- **Baseline:** ends thin and frayed, many splits, stretch test snaps quickly at the ends, hair dries in under an hour, colour faded, curls limp at the ends.
- **Week 0:** trim of three centimetres; photographs taken; products listed — she keeps a gentle shampoo, a moisturising conditioner, and a leave-in, and sets aside a heavy butter that was weighing her fine hair down.
- **Weeks 1–2:** clarifying wash, then a moisture mask; core routine established; heat stopped entirely; satin bonnet at night; journal started.
- **Weeks 3–4:** wash three times a week; moisture mask weekly; in week four, a light protein treatment followed by a moisture conditioner — her hair feels firmer and less stretchy afterwards.
- **Weeks 5–8:** weekly moisture mask, protein treatment every three weeks; heat used once, for an event, at 160°C with a protectant; one-centimetre dusting at week six; LCO method tried from week six — her curls hold to day three for the first time.
- **Weeks 9–12:** no new products; routine continued; photographs repeated.
- **Week 12 result:** damage assessment improves from level 3 to level 2 — fewer splits, stretch test springs back at the mid-lengths, tangling is much less, curls are defined to the ends, and the new growth at the roots is smooth and shiny. The oldest lengths are still more porous than the roots, but they are protected and improving. Sofia's long-term routine is the one she used in weeks 9–12, with a trim every ten weeks and heat no more than twice a month.

## 8.5 After the 12 weeks: long-term maintenance

Once the plan is complete, your routine should be simpler, not more complicated. A good long-term routine has:

- **A wash frequency that suits your scalp and hair type**, and a shampoo that cleans without stripping.
- **Conditioning every wash**, with a mask weekly or fortnightly depending on your hair's condition.
- **A protein treatment only when your hair shows it needs one** — weak, stretchy, or recently chemically treated — not on a fixed schedule.
- **Heat kept to a minimum**, always with a protectant, at the lowest effective temperature.
- **A trim every eight to twelve weeks**, or sooner if splits return. Regular small trims prevent the need for large cuts later.
- **Night protection** — satin pillowcase or bonnet — as a permanent habit, not a twelve-week experiment.
- **A re-assessment every three to six months**: repeat the porosity tests and the damage assessment, and adjust the routine if your hair, your climate, or your styling habits have changed.

**Seasonal adjustments.** In winter, indoor heating and cold air dry the hair: you may need a richer conditioner and a little more oil on the ends. In summer, sun, swimming, and humidity matter more: protect the hair from sun, rinse after swimming, and expect more frizz in humidity — a leave-in and a light sealant help. If you move to a different climate, give your hair two to three weeks to adjust before changing products.

## 8.6 When to seek professional help

This programme is education, not medical care. Consult a qualified professional — a dermatologist, trichologist, or your doctor — if you notice any of the following, at any point during or after the plan:

- Sudden, patchy, or severe hair loss, or bald spots.
- Shedding that increases sharply and stays increased for more than a few weeks.
- Scalp pain, sores, blistering, swelling, or signs of infection.
- Heavy flaking, redness, or itching that does not improve with a few weeks of gentle care.
- Hair loss connected to an illness, a medication, or a medical treatment.
- A chemical service that has caused a burn, severe breakage, or an allergic reaction.

A good stylist can also help with the cosmetic side: a stylist can assess damage in person, recommend a trim, and advise on whether a chemical service is safe for your hair at its current condition. Bring your hair profile and your journal to the appointment — it will make the consultation far more useful.

## 8.7 Module 8 — Key takeaways

1. Twelve weeks is the honest minimum for judging a routine: hair grows about a centimetre a month.
2. Start with a baseline — assessments, photographs, and a product list — so that you can measure change.
3. Change one thing at a time, keep a journal, and review at week eight before changing anything else.
4. After the plan, keep the routine simple: wash, condition, protect, trim regularly, and re-assess every few months.
5. Know the limits of cosmetic care. Medical symptoms need a qualified professional.

---

# Appendix A — Worked Examples: Three Complete Cases

## Case 1 — Low porosity, straight hair, fine strands (Emma, 41)

Emma's hair is type 1b, fine, low density, low porosity. It looks greasy at the roots by day two and limp if she uses heavy products, but the ends feel dry. Her mistake was using a rich mask and a heavy oil, which coated her hair without moisturising it. Her routine: wash every two days with a lightweight shampoo; light conditioner on the mid-lengths and ends only; a pea-sized amount of leave-in spray; deep-condition once a month with gentle heat; clarify once a month. She stopped using the heavy oil entirely. After six weeks her hair holds volume at the roots and the ends feel soft without looking coated.

## Case 2 — High porosity, coily hair, colour-treated (Amara, 27)

Amara's hair is type 4c, coarse, medium density, high porosity, colour-treated. It dries within an hour, tangles easily, and her colour fades fast. Her routine: pre-wash detangling with conditioner; wash once a week with a moisturising shampoo; deep-condition weekly, alternating moisture and light protein; LCO method (leave-in, cream, oil) after every wash; satin bonnet at night; cool rinse; trim every eight weeks. She refreshes her colour less often and uses a colour-protecting conditioner. After twelve weeks her hair stays moisturised for three days after wash day, tangling is much reduced, and her colour lasts noticeably longer.

## Case 3 — Normal porosity, wavy hair, heat damage (Priya, 29)

Priya's case is described in full in Module 5, section 5.4. In summary: type 2c waves, medium strands, high density, damage level 3 from daily flat-ironing. Her plan centred on a trim, cutting heat to once a week at most, alternating moisture and protein masks, and gentle detangling. After eight weeks her stretch test improved, tangling reduced, and new growth felt smooth. Her long-term rule is simple: heat no more than twice a month, and a trim every ten weeks.

---

# Appendix B — Glossary

- **Anagen:** the growth phase of the hair cycle, lasting roughly two to seven years.
- **Catagen:** the short transition phase between growth and rest.
- **Telogen:** the resting phase, after which the hair is shed.
- **Cuticle:** the outer layer of the hair shaft, made of overlapping scales.
- **Cortex:** the middle layer of the hair shaft, containing keratin and pigment.
- **Medulla:** the soft inner core of thicker hairs.
- **Follicle:** the pocket of living cells below the skin from which hair grows.
- **Sebum:** the skin's own oil, produced by sebaceous glands.
- **Porosity:** how easily hair absorbs and loses water.
- **Density:** how many hairs grow per area of scalp.
- **Elasticity:** how far a strand can stretch and still spring back.
- **Breakage:** hair snapping along the shaft, as opposed to shedding from the root.
- **Clarifying:** a deeper cleanse that removes product build-up.
- **Co-washing:** washing with conditioner instead of shampoo.
- **LOC / LCO:** layering methods — liquid, oil, cream, or liquid, cream, oil.
- **Pre-poo:** a treatment applied before shampooing, often an oil.
- **Traction alopecia:** hair loss caused by prolonged pulling from tight styles.
- **Hygral fatigue:** weakening from repeated swelling and drying of the hair, often from over-moisturising.

---

# Appendix C — Product-Label Reading Guide

**Read the ingredient list, not the front of the bottle.** Ingredients are listed in order of concentration, from most to least. The first five ingredients make up most of the product.

- **Water (aqua) first** is a good sign for a moisturising product.
- **Fatty alcohols** (cetyl alcohol, stearyl alcohol, cetearyl alcohol) are conditioning agents, not drying alcohols. They make hair feel smooth.
- **Drying alcohols** (alcohol denat, ethanol, isopropyl alcohol) appear in some styling products and can dry the hair if used often. They are not automatically harmful in small amounts, but a product that lists one in the first three ingredients is likely to be drying.
- **Humectants** (glycerin, honey, aloe vera, propylene glycol) attract water. They work well in moderate humidity and can make hair feel dry in very dry air if used without a sealant.
- **Proteins** (hydrolysed keratin, hydrolysed wheat protein, hydrolysed silk, hydrolysed soy protein) indicate a protein product. "Hydrolysed" means the protein has been broken into smaller pieces that can coat the hair.
- **Silicones** (ingredients ending in "-cone", "-conol", or "-siloxane", such as dimethicone) coat the hair, add shine, and reduce frizz. They are not harmful in themselves, but some build up and need a clarifying wash to remove.
- **Sulphates** (sodium lauryl sulphate, sodium laureth sulphate) are strong cleansers. They clean well but can be drying for some hair types. Sulphate-free shampoos use gentler cleansers and suit dry or curly hair, but may not remove heavy build-up as effectively.
- **Fragrance (parfum)** is listed as a single ingredient even though it can contain many chemicals. If you have a sensitive scalp, choose fragrance-free products for anything applied near the scalp.

**Marketing words to treat with caution:** "repair", "rebuild", "miracle", "growth", "clinical" (without a named study), and "chemical-free" (everything is made of chemicals, including water). Judge a product by its ingredients, its behaviour on your hair over two to three weeks, and nothing else.

---

*End of course content. Use the companion workbook to complete your assessments, plan your 12-week repair routine, and track your progress.*
