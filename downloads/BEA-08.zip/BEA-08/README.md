# BEA-08 — Healthy Hair Academy: Care, Repair & Treatment Routines

**Price:** $347 (one-time) · **Category:** Beauty & Health · **SKU:** BEA-08

A hair-care education programme covering hair science, scalp health, damage repair, and treatment routines for all hair types, including textured and curly hair. Education only — not medical advice.

## Files in this folder

| File | Description |
|---|---|
| `content.md` | Full 8-module course text with worked examples and appendices (14,804 words) |
| `workbook.md` | Companion workbook: hair-type and porosity assessment, damage assessment, scalp check, 12-week repair planner, product-selection worksheet, routine tracker, consultation worksheet |
| `templates/porosity-assessment.csv` | Spreadsheet for recording porosity test results |
| `templates/repair-routine-planner.md` | 12-week repair routine planner |
| `templates/product-selection-guide.md` | Product-selection guide matched to hair profile |
| `templates/consultation-script.md` | Stylist consultation script for advising clients on at-home care |
| `sales-page.md` | Full sales page: headline, problem, solution, module list, who it is for / not for, price, guarantee, 10 FAQs, disclaimers |
| `listing.json` | Marketplace listing data (SKU BEA-08, $347.00, one-time) |
| `cover.md` | Cover design brief (black-and-gold luxury branding) |
| `cover.png` | Generated cover image, 1280 × 1920 px |
| `onboarding.md` | Customer onboarding guide: first steps, schedule, support |
| `README.md` | This index |
