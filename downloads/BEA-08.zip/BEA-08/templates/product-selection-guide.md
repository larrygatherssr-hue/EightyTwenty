# Product-Selection Guide

A practical guide to choosing hair products for your hair profile. Use it with Module 7, section 7.8, Appendix C of the course, and Worksheet 5 of the workbook.

## Step 1 — Start from your hair profile

Write your profile here before you shop:

- Curl pattern: Type ______ (1 / 2 / 3 / 4)
- Strand thickness: Fine / Medium / Coarse
- Density: Low / Medium / High
- Porosity: Low / Normal / High
- Damage level (1–4): ______

A product that suits your profile is more likely to work than a product with an attractive claim on the front of the bottle.

## Step 2 — Match the product type to your profile

| Your hair | Shampoo | Conditioner | Mask / treatment | Leave-in | Oil / butter |
|---|---|---|---|---|---|
| Fine, straight, low porosity | Lightweight, gentle; clarify monthly | Light, water-based; mid-lengths to ends only | Light mask, once a month, with gentle heat | Spray or pea-sized amount | A drop of light oil on ends only, or none |
| Medium, wavy, normal porosity | Gentle shampoo, 2–3 times a week | Regular conditioner every wash | Mask every 2–4 weeks | Light cream or spray | Light oil, small amount on ends |
| Curly, medium strands, normal to high porosity | Moisturising shampoo, 2–3 times a week | Rich conditioner every wash | Mask weekly or fortnightly; alternate moisture and light protein | Leave-in cream | Light to medium oil to seal after cream |
| Coily, coarse, high porosity | Moisturising shampoo, once a week | Rich conditioner; detangle with conditioner in | Mask weekly; alternate moisture and light protein | Leave-in cream, then oil (LCO) or oil then cream (LOC) | Medium to heavy oil or butter on ends to seal |
| Colour-treated or chemically treated | Colour-protecting or gentle shampoo; lukewarm water | Rich conditioner every wash | Weekly mask; protein only when hair feels weak and stretchy | Leave-in with heat protection if heat styling | Light oil to seal and add shine |

## Step 3 — Read the label

Read the ingredient list, not the front of the bottle. Ingredients are listed in order of concentration; the first five make up most of the product.

- **Water (aqua) first** is a good sign for a moisturising product.
- **Fatty alcohols** (cetyl alcohol, stearyl alcohol, cetearyl alcohol) are conditioning agents, not drying alcohols.
- **Drying alcohols** (alcohol denat, ethanol, isopropyl alcohol) in the first three ingredients usually mean a drying product.
- **Humectants** (glycerin, honey, aloe vera) attract water. They work well in moderate humidity and can make hair feel dry in very dry air if used without a sealant.
- **Proteins** (hydrolysed keratin, hydrolysed wheat protein, hydrolysed silk, hydrolysed soy protein) indicate a protein product. "Hydrolysed" means the protein has been broken into smaller pieces that can coat the hair.
- **Silicones** (ingredients ending in "-cone", "-conol", or "-siloxane", such as dimethicone) coat the hair, add shine, and reduce frizz. They are not harmful in themselves, but some build up and need a clarifying wash to remove.
- **Sulphates** (sodium lauryl sulphate, sodium laureth sulphate) are strong cleansers. Sulphate-free shampoos use gentler cleansers and suit dry or curly hair, but may not remove heavy build-up as effectively.
- **Fragrance (parfum)** is listed as a single ingredient. If you have a sensitive scalp, choose fragrance-free products for anything applied near the scalp.

## Step 4 — Test one product at a time

1. Buy one product at a time. If you buy five at once, you will not know which one helped or hurt.
2. Use it for two to three weeks before judging it. Hair needs time to respond, and a single wash is not a fair test.
3. Use the right amount. Start with less than you think you need and add more only if the hair still feels dry or undefined.
4. Record the result in Worksheet 5 of the workbook: keep or stop, and why.
5. Keep a short list of products that work for you. That list is worth more than any recommendation.

## Step 5 — Claims to treat with caution

Be sceptical of products that promise a specific medical outcome. No shampoo makes hair grow faster, no mask rebuilds a strand, and no oil cures hair loss. Marketing words such as "repair", "rebuild", "miracle", and "growth" describe cosmetic effects, not medical ones. Judge a product by its ingredients and by how your hair behaves over two to three weeks of use.

## Step 6 — When to stop using a product

Stop using a product and rinse it out thoroughly if you notice itching, burning, redness, swelling, unusual shedding, or a rash. If symptoms persist or are severe, consult a qualified professional. Patch-test any new product before full use, especially if you have sensitive skin or a history of reactions.
