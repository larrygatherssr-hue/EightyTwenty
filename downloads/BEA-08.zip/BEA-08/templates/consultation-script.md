# Stylist Consultation Script — At-Home Hair Care

Use this script when advising a client on at-home care between appointments. It is designed for junior stylists. Record the answers on Worksheet 7 of the workbook.

**Purpose:** help the client understand their own hair, correct the handling habits that cause the most breakage, and leave with a simple routine they can actually follow. Do not diagnose scalp or hair-loss conditions and do not recommend treatment for a medical condition. If a client reports sudden or patchy hair loss, bald spots, scalp pain, sores, blistering, swelling, or a scalp condition that has not improved with gentle care, advise them to consult a qualified professional.

---

## 1. Opening (1 minute)

"Before we talk about products, I'd like to understand your hair and how you look after it at home. That way anything I suggest will actually fit your hair, rather than being a generic recommendation. Is that all right?"

## 2. Discover their hair (3–4 minutes)

Ask, and listen before advising:

- "How would you describe your hair — straight, wavy, curly, or coily? Does it have more than one pattern?"
- "Does it get wet quickly in the shower, or does the water bead on it? How long does it take to dry?"
- "Does it tangle easily? Where does it tangle most?"
- "How do the ends feel compared with the roots — smooth, rough, dry?"
- "How often do you wash it, and what do you use?"
- "Do you use heat — a dryer, flat iron, or curling iron? How often, and at what temperature, if you know?"
- "Have you had colour, lightening, relaxing, or a perm? When was the last one?"
- "How does your scalp feel — comfortable, itchy, flaky, oily, tender?"

Record the answers. From them, note the client's likely hair type, porosity, and damage level — and say so plainly: "From what you've told me, your hair sounds like type 3b curls with high porosity, which means it absorbs moisture fast and loses it fast. That changes which routine will work for you."

## 3. Watch how they handle their hair (2–3 minutes)

Ask the client to show you how they detangle and dry their hair, using a wide-tooth comb if one is available.

- If they start at the roots and pull down through tangles, show them the correct method: start at the ends, hold the section above the tangle, work upward in sections, with conditioner in the hair.
- If they rub their hair vigorously with a towel, show them squeezing gently instead.
- Correct one habit at a time, kindly, and let them try it themselves. People remember what they do, not what they are told.

## 4. Give the routine (3–4 minutes)

Keep it to four steps. Use the client's own hair profile to choose the version:

1. **Cleanse:** "Wash [frequency for their hair type] with a gentle shampoo, massaging your scalp with your fingertips — not your nails — for about a minute. Let the rinse clean the lengths."
2. **Condition:** "Conditioner goes on the mid-lengths and ends, not the scalp. Leave it for a few minutes, detangle while it is in, then rinse."
3. **Treat:** "Once a [week / fortnight], use [a moisture mask / a light protein treatment followed by a moisturiser — choose one]. Leave it for 15 to 30 minutes with a shower cap."
4. **Protect:** "At night, [a satin pillowcase / a bonnet / a loose braid]. And if you use heat, always use a heat protectant, at the lowest temperature that works, no more than [once or twice] a week."

Recommend no more than three products, and explain why each one fits their hair. Write the routine down for them.

## 5. The trim conversation (1 minute)

If there are many split ends, say so honestly and plainly:

"I can see quite a few split ends. No product can rejoin those — the only way to remove them is a trim. If we take off [amount], you'll keep most of your length and the ends will stop tangling and breaking. Would you like me to do that today?"

Do not pressure a client who declines. Note the recommendation and revisit it at the next appointment.

## 6. Set expectations (1 minute)

"Hair grows about a centimetre a month, so give this routine eight to twelve weeks before you judge it. Change one thing at a time. If your scalp becomes painful, or you notice sudden or patchy hair loss, or anything that worries you, please speak to a qualified professional rather than trying a new product — some things need a clinician, not a cosmetic."

## 7. Close and follow up

- Summarise the routine in one sentence.
- Write down the products, the wash frequency, and the next appointment date.
- At the next appointment, ask: "How did the routine go? What worked, and what didn't?" Adjust from the answer, not from a new sales pitch.

---

## Quick reference — what to recommend by hair type

- **Fine, straight, low porosity:** lightweight shampoo, light conditioner, leave-in spray, monthly mask with gentle heat, clarify monthly.
- **Wavy, normal porosity:** gentle shampoo 2–3 times a week, conditioner every wash, mask every 2–4 weeks, light leave-in.
- **Curly, high porosity:** moisturising shampoo, rich conditioner, weekly mask alternating moisture and light protein, leave-in cream plus oil (LOC or LCO).
- **Coily, high porosity:** moisturising shampoo weekly, rich conditioner, weekly mask, leave-in, cream, and oil to seal, satin bonnet at night, trim every 8 weeks.
- **Chemically treated:** gentle or colour-protecting shampoo, rich conditioner, weekly mask, protein only when hair feels weak and stretchy, heat kept to a minimum.

## Things never to say

- Do not promise that a product will make hair grow faster, thicker, or curlier.
- Do not claim a product repairs, heals, or rebuilds hair.
- Do not diagnose hair loss, scalp conditions, or skin conditions.
- Do not recommend a treatment for a medical condition.
- Do not say a style that causes pain is normal or necessary.
