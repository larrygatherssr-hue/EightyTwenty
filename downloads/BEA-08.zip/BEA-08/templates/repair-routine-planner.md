# 12-Week Repair Routine Planner

Use this planner with Module 8 of the Healthy Hair Academy course and Worksheet 4 of the workbook. Fill in your baseline first, then plan each phase. Change one thing at a time and keep notes.

## My baseline (week 0)

- Hair profile (type / thickness / density / porosity): _________________________________________
- Damage level (1–4): ______
- Main concerns: ___________________________________________________________________________
- Wash frequency I will use: _________________________________________________________________
- Products I will keep: ______________________________________________________________________
- Products I will stop using (and why): ________________________________________________________
- Trim booked: Yes / No — Date: __________ — Amount: __________
- Photographs taken (front and back, wash day and day 3): Yes / No

## Phase 1 — Weeks 1–2: Reset and learn

- [ ] Clarifying wash in week 1, followed by a deep-conditioning mask
- [ ] Core routine from Module 6: gentle scalp cleansing, conditioning the lengths, detangling with a wide-tooth comb in sections
- [ ] Heat styling: stopped entirely, or once a week at most with a heat protectant
- [ ] Night protection: satin pillowcase or bonnet
- [ ] Hair journal started: note how hair feels after every wash and on day 2 and day 3

Notes: _____________________________________________________________________________________

## Phase 2 — Weeks 3–4: Establish the routine

- [ ] Regular wash frequency settled for my hair type
- [ ] Weekly moisture mask (dry / damaged / high-porosity hair) or fortnightly mask (hair in good condition)
- [ ] Light protein treatment in week 4 if hair feels weak and stretchy, followed by a moisturising conditioner
- [ ] Scalp check: is itching, flaking, or oiliness improving? If not, revisit Module 4

Notes: _____________________________________________________________________________________

## Phase 3 — Weeks 5–8: Repair and protect

- [ ] Continue weekly or fortnightly mask; alternate moisture and protein if both are needed
- [ ] No strong protein treatment two weeks in a row
- [ ] Heat kept to once a week at most, lowest effective temperature, always with a protectant
- [ ] Dusting trim of about 1 cm at week 6 if ends still look thin or frayed
- [ ] LOC or LCO method tried if high-porosity, curly, or coily hair and moisture is not lasting to day 3

### Week-8 review

- What has improved? _________________________________________________________________________
- What has not improved? ______________________________________________________________________
- One change I will make for weeks 9–12: ________________________________________________________
- One thing I will stop doing: __________________________________________________________________

## Phase 4 — Weeks 9–12: Consolidate and judge

- [ ] Continue the routine that is working; no new products in these four weeks
- [ ] Photographs repeated in week 12, same light and angles as baseline
- [ ] Damage assessment repeated (Workbook Worksheet 2)
- [ ] Porosity tests repeated (Course Module 3)
- [ ] Long-term routine decided (see below)

### Week-12 results

- Damage level now: ______ (was ______)
- Porosity re-test result: ______
- What I will keep: ____________________________________________________________________________
- What I will change: __________________________________________________________________________
- Next trim due: __________

## My long-term routine

- Wash frequency: ____________________________________________________________________________
- Shampoo: ___________________________________________________________________________________
- Conditioner: ________________________________________________________________________________
- Mask / treatment and frequency: _______________________________________________________________
- Leave-in / styling: ___________________________________________________________________________
- Heat rules: __________________________________________________________________________________
- Trim interval: ________________________________________________________________________________
- Night protection: ____________________________________________________________________________
- Re-assessment due (every 3–6 months): __________________________________________________________

## Safety reminder

This planner is for education only and is not medical advice. If you notice sudden or patchy hair loss, bald spots, scalp pain, sores, blistering, swelling, or a scalp condition that does not improve with a few weeks of gentle care, consult a qualified professional.
