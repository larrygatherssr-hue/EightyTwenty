# Healthy Hair Academy — Companion Workbook

**Healthy Hair Academy: Care, Repair & Treatment Routines**

Use this workbook alongside the course text (`content.md`). Work through the worksheets in order. There are no right or wrong answers — the purpose is to record what is true for your hair so that your routine is built on evidence, not guesswork.

---

## Disclaimer

This workbook is for education only. It is not medical advice, and it does not diagnose, treat, or cure any hair-loss condition, scalp disorder, or medical condition. If you are experiencing sudden or patchy hair loss, bald spots, severe shedding, scalp pain, sores, blistering, swelling, heavy flaking that does not improve with gentle care, or hair loss connected to an illness, medication, or medical treatment, please consult a qualified professional promptly. Patch-test any new product before full use, follow the manufacturer's instructions, and stop using anything that causes irritation, itching, burning, redness, or unusual shedding.

---

## Worksheet 1 — Hair-Type and Porosity Assessment

Complete this on clean hair with no product in it. See Modules 2 and 3 of the course for full instructions.

### 1A. Curl pattern

Wash, condition, rinse, and let your hair air-dry with no product and no touching. What shape does it take?

- My curl pattern is: Type ______ (1 / 2 / 3 / 4) Sub-type ______ (a / b / c)
- Notes (e.g., different patterns in different areas): _______________________________________________
- Shrinkage: when dry, my hair looks about ______% shorter than when stretched.

### 1B. Strand thickness — the thread test

Take a single shed strand and compare it with a sewing thread. Repeat with three or four strands.

- Strand 1: thinner / same / thicker than thread
- Strand 2: thinner / same / thicker than thread
- Strand 3: thinner / same / thicker than thread
- Strand 4: thinner / same / thicker than thread
- My strand thickness is: Fine / Medium / Coarse

### 1C. Density

Part your hair in the middle and look at your scalp in a mirror in good light.

- I can see my scalp: easily / partly / barely
- My density is: Low / Medium / High

### 1D. Porosity — use at least two tests

**Float test:** a clean shed strand in a glass of room-temperature water, after 2–4 minutes.

- Result: floats (low) / sinks slowly (normal) / sinks quickly (high)

**Spray test:** mist a small section of clean, dry hair with water.

- Result: beads for 1 minute or more (low) / soaks in within about 30 seconds (normal) / soaks in within a few seconds (high)

**Slide test:** slide your fingers up a strand, tip toward root.

- Result: smooth (low/normal) / bumpy or catching (high)

**Drying test:** time for my hair to dry without heat or products: ______ hours.

- My porosity is: Low / Normal / High
- Does porosity differ between roots and ends? Yes / No — Notes: _______________________________

### 1E. My hair profile (one line)

Fill this in and copy it to the front of your hair journal:

**Type ______, ______ strands, ______ density, ______ porosity.**

Example: "Type 3b curls, fine strands, high density, high porosity."

---

## Worksheet 2 — Damage Assessment

Complete this on clean, dry hair in good light. See Module 5 of the course.

### 2A. The ends

Look at the last five centimetres of your hair.

- Ends look: full and even / slightly thin / thin and wispy
- Split ends visible: none / a few / many
- White dots along the shaft: none / a few / many
- Ends feel: smooth / slightly rough / rough and straw-like

### 2B. The stretch test

Take a single wet strand and stretch it gently.

- It stretches a little and springs back / it snaps almost immediately / it stretches a long way and does not spring back
- Repeat on strands from different areas. Worst area: ___________________________________________

### 2C. The feel test

Run your fingers down a strand from root to tip.

- Roots feel: smooth / slightly rough / rough
- Ends feel: smooth / slightly rough / rough

### 2D. The tangle test

- My hair tangles: rarely / sometimes / constantly
- Worst tangling area: ends / nape / all over

### 2E. Shine and colour

- After washing and conditioning, my hair looks: shiny / fairly shiny / dull
- Colour fades: slowly / within a few weeks / within a few washes
- Chemical services in the last 12 months: ____________________________________________________
- Heat styling frequency: never / once a week / 2–3 times a week / daily

### 2F. My damage level

Circle one, using the scale in Module 5:

- **Level 1 — Minimal:** ends in good condition, few or no splits, hair stretches and springs back.
- **Level 2 — Mild:** some split ends, ends a little dry, occasional tangling.
- **Level 3 — Moderate:** many splits, white dots, tangles easily, feels rough, stretches poorly or snaps.
- **Level 4 — Severe:** breaks when combed, stretches like chewing gum or snaps immediately, feels straw-like, has lost curl pattern in places.

**My damage level: 1 / 2 / 3 / 4**

**What I will do first:** _____________________________________________________________________
(e.g., "Book a trim of 3 cm", "Stop daily flat-ironing", "Start weekly moisture masks")

---

## Worksheet 3 — Scalp Check

Complete weekly for the first month, then monthly. See Module 4.

| Date | Comfort (comfortable / itchy / tender / sore) | Flaking (none / small dry flakes / oily flakes) | Oiliness (roots oily after: 1 day / 2–3 days / a week) | Build-up (none / slight / heavy) | Notes |
|---|---|---|---|---|---|
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |

**If any of the following persist for more than a few weeks despite gentle care, or appear suddenly, consult a qualified professional:** severe or patchy hair loss, bald spots, scalp pain, sores, blistering, swelling, signs of infection, heavy flaking with redness.

---

## Worksheet 4 — 12-Week Repair Routine Planner

Use this planner with Module 8. Fill in your plan before week 1, then update it at the week-8 review.

### My baseline (week 0)

- Hair profile: _______________________________________________________________________________
- Damage level: ______
- Wash frequency I will use: ___________________________________________________________________
- Products I will keep: ________________________________________________________________________
- Products I will stop using (and why): __________________________________________________________
- Trim booked: Yes / No — Date: __________ Amount: __________
- Photographs taken (front and back, wash day and day 3): Yes / No

### Weekly plan

| Weeks | Wash frequency | Treatment this week | Heat styling | Trim / other | Notes |
|---|---|---|---|---|---|
| 1–2 | | Clarifying wash (week 1) + moisture mask | None, or once max with protectant | Satin pillowcase / bonnet | |
| 3–4 | | Weekly moisture mask; light protein in week 4 if needed | Once a week max | | |
| 5–6 | | Alternate moisture / protein | Once a week max | Dusting (~1 cm) at week 6 if needed | |
| 7–8 | | As above | Once a week max | **Week-8 review** (below) | |
| 9–10 | | Continue what works; no new products | Once a week max | | |
| 11–12 | | Continue what works; no new products | Once a week max | Repeat photos + damage assessment | |

### Week-8 review

- What has improved? _________________________________________________________________________
- What has not improved? ______________________________________________________________________
- One change I will make for weeks 9–12: ________________________________________________________
- One thing I will stop doing: __________________________________________________________________

### Week-12 results

- Damage level now: ______ (was ______)
- Porosity re-test result: ______
- What I will keep in my long-term routine: ______________________________________________________
- Next trim due: __________

---

## Worksheet 5 — Product-Selection Worksheet

Use one row per product. Test one new product at a time for two to three weeks before judging it. See Module 7, section 7.8, and Appendix C of the course.

| Product name | Type (shampoo / conditioner / mask / leave-in / oil / styler) | First 5 ingredients | Cost | Dates used | Result (keep / stop — and why) |
|---|---|---|---|---|---|
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |
| | | | | | |

**Products that work for me (my shortlist):**

1. ___________________________________________________________________________________________
2. ___________________________________________________________________________________________
3. ___________________________________________________________________________________________
4. ___________________________________________________________________________________________

**Products that did not work, and why:**

1. ___________________________________________________________________________________________
2. ___________________________________________________________________________________________
3. ___________________________________________________________________________________________

---

## Worksheet 6 — Routine Tracker

Photocopy or reproduce this table for each week. Fill it in after every wash day.

**Week of: __________**

| Day | Washed? (Y/N) | Shampoo / conditioner used | Treatment used | Detangling (easy / some tangles / difficult) | How hair felt (soft / dry / coated / limp / strong) | Day-2 / Day-3 look | Notes |
|---|---|---|---|---|---|---|---|
| Mon | | | | | | | |
| Tue | | | | | | | |
| Wed | | | | | | | |
| Thu | | | | | | | |
| Fri | | | | | | | |
| Sat | | | | | | | |
| Sun | | | | | | | |

**End-of-week reflection:** What worked this week? What will I change next week?

_______________________________________________________________________________________________
_______________________________________________________________________________________________

---

## Worksheet 7 — Consultation Worksheet (for junior stylists)

Use this when advising a client on at-home care between appointments. Ask the questions, listen, and record the answers before recommending anything. A full consultation script is provided in `templates/consultation-script.md`.

**Client name:** ______________________________ **Date:** ______________

- Hair profile (type / thickness / density / porosity): ____________________________________________
- Damage level (1–4) and main signs: ___________________________________________________________
- Scalp: comfortable / itchy / flaky / oily / tender / other: ______________________________________
- Current wash frequency and products: _________________________________________________________
- Heat styling frequency and temperature (if known): ____________________________________________
- Chemical services and dates: _________________________________________________________________
- Main concern in the client's own words: _______________________________________________________
- What the client already does well: ____________________________________________________________
- One handling habit to correct (e.g., detangling, towel-drying): _________________________________
- Routine recommended (wash / condition / treatment / protection): ________________________________
- Products recommended (no more than three): ____________________________________________________
- Trim recommended: Yes / No — Amount: __________
- Follow-up appointment: __________
- **Referral note:** If the client reports sudden or patchy hair loss, bald spots, scalp pain, sores, blistering, swelling, or a scalp condition that has not improved with gentle care, advise them to consult a qualified professional. Do not diagnose or recommend treatment for a medical condition.

---

## My Long-Term Routine (complete after week 12)

- Wash frequency: ____________________________________________________________________________
- Shampoo: ___________________________________________________________________________________
- Conditioner: ________________________________________________________________________________
- Mask / treatment and frequency: _______________________________________________________________
- Leave-in / styling: ___________________________________________________________________________
- Heat rules for myself: ________________________________________________________________________
- Trim interval: ________________________________________________________________________________
- Night protection: ____________________________________________________________________________
- Re-assessment due (every 3–6 months): __________________________________________________________

---

*Keep this workbook with your hair journal. Re-do Worksheets 1 and 2 every three to six months, especially after a chemical service or a change in heat habits.*
