# Customer Onboarding — Healthy Hair Academy

Welcome to Healthy Hair Academy. This guide tells you what to do first, how to use the materials, and how to get the most from the programme in your first two weeks.

## What you received

After purchase you should have these files:

| File | What it is |
|---|---|
| `content.md` | The full 8-module course text, with worked examples and appendices |
| `workbook.md` | The companion workbook: assessments, planner, tracker, and worksheets |
| `templates/porosity-assessment.csv` | Spreadsheet for recording your porosity test results |
| `templates/repair-routine-planner.md` | Your 12-week repair routine planner |
| `templates/product-selection-guide.md` | Guide to choosing products for your hair profile |
| `templates/consultation-script.md` | Stylist consultation script (for junior stylists advising clients) |
| `sales-page.md` | Programme summary, for your reference |
| `cover.png` | Programme cover image |
| `README.md` | Index of the files in this package |

If any file is missing, contact support with your order number (see "How to get support" below).

## What to do first (Day 1)

1. **Read the disclaimer** at the top of `content.md`. This programme is education only, not medical advice. If you have sudden or patchy hair loss, bald spots, severe shedding, scalp pain, sores, or a scalp condition, please consult a qualified professional.
2. **Read Module 1 and Module 2** of the course. They explain what hair is and how to identify your curl pattern, strand thickness, and density.
3. **Complete Worksheet 1 in the workbook** — the hair-type and porosity assessment. Do the hands-on tests on clean hair with no product in it (Module 3 explains the four porosity tests). Record your results in the workbook and in `templates/porosity-assessment.csv`.
4. **Complete Worksheet 2** — the damage assessment. Note your damage level (1–4).
5. **Write your one-line hair profile** (Worksheet 1E) and keep it where you can see it. It is the filter for every recommendation in the course.

Do not buy any new products yet. The assessments come first — they determine which routines apply to you.

## Suggested schedule

**Week 1 — Learn and assess.**
- Read Modules 1–4. Complete Worksheets 1, 2, and 3.
- Take baseline photographs of your hair in good light, front and back, on wash day and on day 3.
- Book a trim if your damage level is 3 or 4 or you have many split ends.
- Start the core routine from Module 6.

**Week 2 — Reset.**
- Do a clarifying wash followed by a deep-conditioning mask.
- Stop heat styling, or reduce it to once a week at most with a heat protectant.
- Set up night protection: a satin pillowcase or bonnet.
- Start the routine tracker (Worksheet 6) after every wash.

**Weeks 3–4 — Establish the routine.**
- Read Modules 5–7. Settle into your regular wash frequency.
- Introduce one treatment: a weekly moisture mask for dry or high-porosity hair, or a fortnightly mask for hair in good condition.

**Weeks 5–12 — Follow the 12-week plan.**
- Follow the week-by-week plan in Module 8 and the repair routine planner template.
- Review your progress at week 8 and make one change if needed.
- Repeat your photographs and damage assessment in week 12.

**After week 12 — Maintain.**
- Keep the routine that works. Re-assess your porosity and damage every three to six months, especially after a chemical service or a change in heat habits.

## How to use the materials

- **Course (`content.md`):** read it in order the first time. After that, use Modules 6 and 7 as reference chapters whenever you change products, seasons, or styling habits.
- **Workbook (`workbook.md`):** print it or copy the tables into a notebook. The routine tracker is designed to be reproduced weekly.
- **Templates:** the CSV opens in any spreadsheet app. The planner, product-selection guide, and consultation script are plain text documents you can print or edit.
- **One change at a time:** if you change your shampoo, conditioner, styling method, and treatment all in the same week, you will not know which change helped. Introduce one change, use it for two to three weeks, then judge it.

## How to get support

For help with your order or the course files, email the marketplace support address with your order number and a description of the issue, and the support team will respond.

For questions about the content of the programme, include the module number and the section you are asking about so support can point you to the right material.

## Guarantee

Every purchase is covered by a 14-day money-back guarantee. If you are not satisfied within 14 days of purchase, contact support with your order number for a full refund.

## A final note

Hair grows about a centimetre a month. Give the programme the full twelve weeks before you judge it — and be honest with yourself about damage: products can improve how damaged hair looks and feels and protect it from getting worse, but split ends can only be removed by cutting, and new, healthier growth replaces damaged lengths over time. That is the programme working as it should.
