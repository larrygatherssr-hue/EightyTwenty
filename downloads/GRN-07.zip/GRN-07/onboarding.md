# Customer Onboarding Guide

## Sustainable Packaging Playbook for E-Commerce Brands — GRN-07

Welcome. This guide tells you what to do first, how to use each file, and what a realistic schedule looks like. Read this page, then start Module 1.

---

## What You Have Bought

| File | What it is | Use it for |
|---|---|---|
| `content.md` | The full programme — 7 modules, over 11,000 words | Read in order; this is the core of the product |
| `workbook.md` | Companion workbook — 6 worksheets | Fill in as you work through each module |
| `templates/packaging-cost-calculator.csv` | Cost calculator spreadsheet | Run the money math in Module 5 with your real quotes |
| `templates/materials-comparison-matrix.md` | 14 materials compared | Choosing materials in Module 2 |
| `templates/supplier-directory.md` | Supplier record template | Vetting and tracking suppliers in Module 4 |
| `templates/compliance-checklist.md` | Regulatory checklist | Checking the rules that apply to you in Module 7 |
| `templates/dieline-spec-template.md` | Print specification template | Ordering custom-printed packaging in Module 3 |
| `sales-page.md` | The product's sales page copy | Reference only — not needed to use the programme |
| `cover.png` | Product cover image | Reference / your library copy |
| `README.md` | Index of this folder | Quick reference to what is here |

All documents are Markdown files (`.md`) except the calculator, which is a CSV spreadsheet. Markdown opens in any text editor, word processor, or notes app. The CSV opens in Excel, Google Sheets, LibreOffice Calc, or any spreadsheet app. No special software is required.

---

## What to Do First (Day 1)

1. **Save your files somewhere safe.** Download the files and keep a copy in a folder you will not lose. Make a working copy of the workbook and the templates so the originals stay clean.
2. **Read the Important Notice at the top of `content.md`.** It explains the limits of the programme: education only, not legal or financial advice, and rules and costs vary by location.
3. **Read the Introduction and Module 1.** Do not skip ahead to materials or suppliers yet — the audit in Module 1 is what makes the rest of the programme useful.
4. **Do Module 1's actions.** List your packaging items, weigh five real orders, calculate your true per-order cost, and choose your first switch. This takes about two to three hours, including the weighing.

## Suggested Schedule

| When | Do this |
|---|---|
| Day 1 | Read this guide, the Introduction, and Module 1. Complete Worksheet 1 (packaging audit). |
| Days 2–4 | Module 2 (materials) and Module 3 (design). Complete Worksheet 2. Drop-test your current pack. |
| Days 5–10 | Module 4 (suppliers). Complete Worksheet 3. Send the nine questions to your shortlist and order samples. |
| Days 10–14 | Module 5 (money math). Complete Worksheet 4 and the CSV calculator with real quotes. Make the go/no-go decision in writing. |
| Weeks 3–4 | Module 6 (rollout). Complete Worksheet 5. Run the pilot of 50–100 orders. Send the customer message. |
| Weeks 5–6 | Full rollout to the first product line. |
| Day 30 after rollout | 30-day review (Worksheet 5). Decide whether to extend to the next product line. |
| Module 7 (alongside rollout) | Complete Worksheet 6 and the compliance checklist. Write your website packaging page. |
| 12 months after rollout | Annual review (Module 7). Repeat a short version of the audit. |

The full 90-day plan is in Appendix B of `content.md`. If your timeline slips, let it slip rather than skipping the pilot or the drop test.

## How to Use the Materials

- **Work in order the first time.** Each module builds on the last. The costing in Module 5 only works if you did the audit in Module 1 and got real quotes in Module 4.
- **Fill in the workbook as you go.** The worksheets are the programme's working notes. A completed workbook plus your supplier quotes and certificates is your record of the switch.
- **Replace example numbers with your own.** The worked examples in the programme and the calculator use illustrative figures. Your costs will differ by supplier, volume, product, and location. Always use your own quotes.
- **Keep evidence for every claim.** When you decide what to print on your packaging, keep the supplier's written statement or certificate in the claims evidence file (Worksheet 6). Review it annually.
- **Reuse the templates.** Copy the relevant worksheet for each new product line you switch. The programme recommends one product line at a time.

## A Note on Regulations

Packaging regulations, recycling rules, EPR schemes, labelling requirements, and green-claims rules vary by country, state, and municipality, and they change over time. This programme explains the areas to check and gives you a checklist, but it cannot tell you exactly which rules apply to your business. Verify the current rules for where you sell and ship, and seek professional advice if you are unsure. That step is yours, and it matters.

## How to Get Support

Support is provided by email through the marketplace. Include your order number and the file you need help with.

Support can help with:
- Opening or using the files.
- Questions about how to apply the worksheets and templates.
- Reporting a problem with a file (for example, a file that will not open).

Support cannot provide legal advice on packaging regulation, certification advice, or supplier recommendations for a specific market. For those, verify current rules for your business and seek professional advice where needed.

## Quick Checklist Before You Start

- [ ] Files downloaded and saved.
- [ ] Important Notice in `content.md` read.
- [ ] Module 1 read.
- [ ] Worksheet 1 started.
- [ ] A date set for the 30-day review after rollout.

Welcome to the switch. Start with Module 1.
