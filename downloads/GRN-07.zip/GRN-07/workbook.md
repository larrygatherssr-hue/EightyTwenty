# Sustainable Packaging Playbook — Companion Workbook

## GRN-07

This workbook belongs with the programme in `content.md`. Work through the worksheets in order. Fill them in with your real numbers — estimates are fine where you do not yet have exact figures, but mark them as estimates and replace them with actuals when you can.

**Education-only notice:** This workbook is for education and general information only. It is not legal, financial, or environmental certification advice. Packaging regulations, costs, and recycling rules vary by location and product, and they change over time. Verify current rules for where you sell and ship, confirm supplier claims in writing, and test new packaging with your actual products before rolling it out.

---

## Worksheet 1: Current Packaging Audit

*Module 1. Complete one row per item for your top product line.*

| Item | Material | Size | Qty per order | Unit cost | Supplier | Notes |
|---|---|---|---|---|---|---|
| Outer box / mailer | | | | $ | | |
| Inner wrap | | | | $ | | |
| Void fill | | | | $ | | |
| Product bag / pouch | | | | $ | | |
| Tape | | | | $ | | |
| Label(s) | | | | $ | | |
| Insert / card | | | | $ | | |
| Sticker / seal | | | | $ | | |
| Other: | | | | $ | | |
| **Materials subtotal per order** | | | | **$** | | |

**Hidden costs (last 3 months):**

| Cost | Total over 3 months | Orders in period | Cost per order |
|---|---|---|---|
| Damage replacements and reshipping | $ | | $ |
| Returns caused by packaging failure | $ | | $ |
| Packing labour: ___ minutes/order x $___/hour | — | — | $ |
| Storage (if charged separately) | $ | | $ |
| **True cost per order (materials + hidden)** | | | **$** |

**Packing weight check (pack five real orders):**

| Order | Product | Product weight | Packaging weight | Total weight | Packaging share | Box volume vs product volume |
|---|---|---|---|---|---|---|
| 1 | | | | | % | |
| 2 | | | | | % | |
| 3 | | | | | % | |
| 4 | | | | | % | |
| 5 | | | | | % | |

**What I found in reviews and support messages about packaging:**

- Complaints: _________________________________________________________________
- Compliments: _________________________________________________________________
- Questions: __________________________________________________________________

**My most wasteful item is:** ____________________________________________________

**My first switch will be (product line + change):** __________________________________

---

## Worksheet 2: Materials Comparison Worksheet

*Module 2. Complete one block per material you are considering. Use the materials comparison matrix in the templates folder for reference prices.*

### Material 1: ________________________________

- What it replaces: ____________________________________________________________
- Supplier quoted unit cost: $__________ at __________ units
- Current material unit cost: $__________ — difference per order: $__________
- Weight per order: __________ g (current: __________ g)
- How the customer should dispose of it: ________________________________________
- Claim I would like to make: ___________________________________________________
- Evidence needed to make that claim: ___________________________________________
- Certificate or standard (if any): _______________________________________________
- Drop-test result: Pass / Fail — notes: __________________________________________
- Verdict: Use / Test further / Rule out — reason: _________________________________

### Material 2: ________________________________

- What it replaces: ____________________________________________________________
- Supplier quoted unit cost: $__________ at __________ units
- Current material unit cost: $__________ — difference per order: $__________
- Weight per order: __________ g (current: __________ g)
- How the customer should dispose of it: ________________________________________
- Claim I would like to make: ___________________________________________________
- Evidence needed to make that claim: ___________________________________________
- Certificate or standard (if any): _______________________________________________
- Drop-test result: Pass / Fail — notes: __________________________________________
- Verdict: Use / Test further / Rule out — reason: _________________________________

### Material 3: ________________________________

- What it replaces: ____________________________________________________________
- Supplier quoted unit cost: $__________ at __________ units
- Current material unit cost: $__________ — difference per order: $__________
- Weight per order: __________ g (current: __________ g)
- How the customer should dispose of it: ________________________________________
- Claim I would like to make: ___________________________________________________
- Evidence needed to make that claim: ___________________________________________
- Certificate or standard (if any): _______________________________________________
- Drop-test result: Pass / Fail — notes: __________________________________________
- Verdict: Use / Test further / Rule out — reason: _________________________________

**Materials I am ruling out, and why:**

1. ___________________________________________________________________________
2. ___________________________________________________________________________

---

## Worksheet 3: Supplier Outreach Tracker

*Module 4. One row per supplier contacted. Send every supplier the same nine questions from Module 4.*

| Supplier | Contact name / email | Material | MOQ | Unit price | Price at next tier | Lead time | Delivery cost | Samples (cost) | Certifications | Reply date | Verdict |
|---|---|---|---|---|---|---|---|---|---|---|---|
| | | | | $ | $ | | $ | $ | | | |
| | | | | $ | $ | | $ | $ | | | |
| | | | | $ | $ | | $ | $ | | | |
| | | | | $ | $ | | $ | $ | | | |
| | | | | $ | $ | | $ | $ | | | |

**Sample test log:**

| Supplier / material | Date received | Drop test | Fit check | Print / colour | Weight vs current | Notes |
|---|---|---|---|---|---|---|
| | | Pass / Fail | | | | |
| | | Pass / Fail | | | | |
| | | Pass / Fail | | | | |

**Primary supplier:** ________________________________________________________________

**Backup supplier:** _________________________________________________________________

**Red flags noted:** __________________________________________________________________

---

## Worksheet 4: Cost Calculator Worksheet

*Module 5. Fill in with real quotes. Also complete the spreadsheet version in `templates/packaging-cost-calculator.csv`.*

### Per-order comparison

| | Current pack | Proposed pack |
|---|---|---|
| Materials subtotal | $ | $ |
| Shipping (this product line) | $ | $ |
| Damage / replacements per order | $ | $ |
| Packing labour per order | $ | $ |
| **Total cost per order** | **$** | **$** |
| **Difference per order** | | **$** |

Orders per month: __________ — Monthly difference: $__________ — Annual difference: $__________

### One-off switching costs

| Item | Cost |
|---|---|
| Samples | $ |
| Dieline / design fee | $ |
| Print setup / plates | $ |
| New equipment (e.g. tape dispenser) | $ |
| Other: | $ |
| **Total one-off cost** | **$** |

Break-even (if the switch saves money): total one-off cost ÷ saving per order = __________ orders.
At __________ orders per month, break-even is reached in __________ months.

If the switch costs more per order, annual extra cost: $__________ — I will: absorb it / offset it / adjust pricing (circle one). Detail: _______________________________

### Margin check

| | Current | Proposed |
|---|---|---|
| Average order value | $ | $ |
| Product cost | $ | $ |
| Packaging total per order | $ | $ |
| Shipping | $ | $ |
| Platform and payment fees | $ | $ |
| **Margin per order** | **$** | **$** |

**Decision:** Go ahead / Go ahead with changes / Do not proceed yet (circle one).
Reason: ___________________________________________________________________________

---

## Worksheet 5: Switch Rollout Plan

*Module 6.*

- Product line: _________________________________________________________________
- Packaging change: ___________________________________________________________
- Primary supplier and order date: ______________________________________________
- Pilot size: __________ orders — Pilot start date: __________ — Pilot end date: __________
- Pilot success criteria (damage rate, packing time, customer feedback): _______________
  ___________________________________________________________________________
- Customer message drafted: Yes / No — Channels: email / website / social (circle)
- Old stock plan (how existing stock will be used up): _______________________________
  ___________________________________________________________________________
- Packing guide updated: Yes / No — Date: __________
- Fulfilment partner briefed (if applicable): Yes / No — Date: __________
- Full rollout date: __________
- 30-day review date: __________

**Pilot log:**

| Date | Orders shipped (new pack) | Damage reports | Packing time/order | Customer comments |
|---|---|---|---|---|
| | | | | |
| | | | | |
| | | | | |

**30-day review:**

| Measure | Predicted (Module 5) | Actual | Difference |
|---|---|---|---|
| Materials cost per order | $ | $ | $ |
| Packing time per order | min | min | min |
| Damage / return rate | % | % | % |
| Shipping cost per order | $ | $ | $ |
| Customer feedback summary | | | |

**Decision after 30 days:** Extend to next product line / Fix and re-test / Revert (circle one).
Next product line: _________________________________________________________________

---

## Worksheet 6: Compliance Checklist

*Module 7. Also see `templates/compliance-checklist.md`. Check the rules for each place you sell; note the date and the source you checked.*

| Area | Applies? | What I checked | Source / link | Date checked | Action needed |
|---|---|---|---|---|---|
| EPR registration / reporting | | | | | |
| Plastic tax or levy | | | | | |
| Single-use plastic bans | | | | | |
| Recycling / disposal labelling | | | | | |
| Green claims / advertising rules | | | | | |
| Product-specific packaging rules (food / cosmetics / children's) | | | | | |
| Marketplace packaging rules | | | | | |
| Carrier packaging requirements | | | | | |

**Claims evidence file:**

| Claim made (exact wording) | Where it appears | Evidence held | Supplier / certificate | Expiry / review date |
|---|---|---|---|---|
| | | | | |
| | | | | |
| | | | | |

**Website packaging page updated:** Yes / No — Date: __________

**Annual review date (12 months from rollout):** __________

**My second switch will be:** ______________________________________________________

---

*End of workbook. Keep the completed worksheets with your supplier quotes and certificates — together they are your record of the switch.*
