# Regulatory Compliance Checklist

## GRN-07 — Sustainable Packaging Playbook

**How to use this checklist:** Work through it for each place you sell and ship to. Tick an item only when you have checked the current rule from an official source and recorded the date and source. This checklist is a starting point for your own review — it is not legal advice, and it is not a substitute for professional advice. Packaging rules change; verify the current position before acting.

**Education-only notice:** This checklist is for general information only. It is not legal advice. Regulations vary by country, state, and municipality and change over time. If you are unsure whether a rule applies to you, speak to a local business adviser or a lawyer who works with small e-commerce brands.

---

## 1. Extended Producer Responsibility (EPR)

- [ ] I have identified whether EPR for packaging applies in each country/state where I sell.
- [ ] I have checked whether my business meets the registration threshold in each place (size, turnover, or packaging volume).
- [ ] I have registered where required, or confirmed registration is not required and recorded why.
- [ ] I have checked whether my marketplace or platform handles any part of the EPR obligation for sales made through it — and I have not assumed it does without confirmation.
- [ ] I have a system for recording the packaging I place on the market (type, material, weight) for reporting.
- [ ] I have noted the reporting deadlines and fee payment dates for each scheme.
- [ ] Date checked: __________ Source: ________________________________________

## 2. Plastic Taxes, Levies, and Bans

- [ ] I have checked whether a plastic packaging tax or levy applies in each place I sell (for example, taxes on plastic packaging below a recycled-content threshold).
- [ ] I have checked whether any single-use plastic items I use are banned or restricted.
- [ ] I have checked the recycled-content threshold for any tax that applies, and whether my packaging meets it.
- [ ] Date checked: __________ Source: ________________________________________

## 3. Recycling and Disposal Labelling

- [ ] I have checked the labelling rules for each of my main markets (what symbols and wording are permitted or required).
- [ ] I have checked whether the chasing-arrows symbol or the word "recyclable" is restricted in any market I sell to, and under what conditions it may be used.
- [ ] Every disposal instruction on my packaging matches what is actually accepted in the recycling systems where most of my customers live.
- [ ] I have not used a resin identification code as a promise that an item will be recycled.
- [ ] Date checked: __________ Source: ________________________________________

## 4. Green Claims and Advertising

- [ ] Every environmental claim on my packaging, website, and advertising is specific, not vague (no "eco-friendly," "green," or "planet-friendly" without explanation).
- [ ] Every claim is substantiated by written supplier evidence, held in my claims evidence file.
- [ ] Every claim includes any qualification needed to make it true (for example, "commercially compostable" rather than "compostable" where only commercial composting applies).
- [ ] I have not used a certification logo without a valid licence for that logo on that product.
- [ ] I have checked the relevant green-claims guidance for my main markets (for example, the FTC Green Guides in the US, the CMA Green Claims Code / ASA rules in the UK, EU rules on environmental claims).
- [ ] I have reviewed claims made by any fulfilment partner, marketplace listing, or advertiser on my behalf.
- [ ] Date checked: __________ Source: ________________________________________

## 5. Product-Specific Packaging Rules

- [ ] I have checked whether my product category has additional packaging rules (food-contact materials, cosmetics, children's products, electronics, hazardous goods).
- [ ] If I sell food, I have checked food-contact material rules for my markets.
- [ ] If I sell cosmetics, I have checked the packaging and labelling rules for cosmetics in my markets.
- [ ] If I ship liquids, aerosols, or batteries, I have checked carrier and dangerous-goods rules.
- [ ] Date checked: __________ Source: ________________________________________

## 6. Marketplace and Platform Rules

- [ ] I have checked the packaging requirements of each marketplace I sell through (for example, frustration-free or recyclable packaging programmes).
- [ ] I have checked whether any marketplace requires specific packaging materials or labelling.
- [ ] Date checked: __________ Source: ________________________________________

## 7. Carrier Requirements

- [ ] I have checked my carrier's packaging guidelines (minimum box strength, labelling, size and weight limits).
- [ ] My packaging meets the carrier's requirements for the services I use.
- [ ] Date checked: __________ Source: ________________________________________

## 8. Claims Evidence File

- [ ] I hold written evidence for every environmental claim I make (supplier statement or certificate, with date and product covered).
- [ ] The evidence file is reviewed at least once a year and whenever I change supplier, material, or printer.
- [ ] Expired certificates have been removed from use and any claim relying on them has been withdrawn.
- [ ] I can produce the evidence for any claim within days if asked by a customer or a regulator.

## 9. Review Schedule

- [ ] Next compliance review date: __________ (at least annually, and whenever entering a new market or changing packaging)
- [ ] Person responsible: ____________________________________________________

---

## Notes

Use this space to record anything specific to your business — thresholds that apply to you, registrations held, or advice received.

- ___________________________________________________________________________
- ___________________________________________________________________________
- ___________________________________________________________________________
- ___________________________________________________________________________
