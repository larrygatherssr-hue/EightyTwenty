# Supplier Directory

## GRN-07 — Sustainable Packaging Playbook

**How to use this directory:** Keep two to three suppliers per material. Fill in one entry per supplier from their written quote and your sample test. Update the entry every time you reorder or re-quote. This directory is a template — the supplier names below are placeholders showing the format. Add your real suppliers and delete the placeholder rows.

**Education-only notice:** This directory is a record-keeping template for general information only. Verify every supplier claim, certification, and price in writing before ordering.

## How to Vet a Supplier (summary from Module 4)

Ask every shortlisted supplier the same nine questions: (1) exact material composition and recycled/bio-based percentage; (2) certifications held, with copies; (3) minimum order quantity and unit price at your volume and the next tier; (4) lead time and delivery cost; (5) samples and their cost; (6) product weight and dimensions; (7) how the customer should dispose of it and what to print; (8) returns/replacement policy; (9) whether the price is fixed or variable.

Red flags: a price far below every other quote; no samples; environmental claims with no certificate; full upfront payment by an unprotected method on a first order; lead times that keep changing.

---

## Corrugated Boxes (Recycled Content)

### Supplier A — [Name]

- Contact: [Name, email, phone]
- Website: [URL]
- Products: [e.g. RSC boxes, sizes stocked]
- Minimum order: [ ] units
- Unit price at my volume: $[ ] at [ ] units — next tier: $[ ] at [ ] units
- Lead time: [ ] days — Delivery cost: $[ ]
- Samples: [free / $___]
- Certifications: [e.g. FSC chain-of-custody no. ___; recycled content ___%]
- Sample test result: [date, drop test, fit, print]
- Notes: [ ]

### Supplier B — [Name]

- Contact: [Name, email, phone]
- Website: [URL]
- Products: [ ]
- Minimum order: [ ] units
- Unit price at my volume: $[ ] at [ ] units — next tier: $[ ] at [ ] units
- Lead time: [ ] days — Delivery cost: $[ ]
- Samples: [free / $___]
- Certifications: [ ]
- Sample test result: [ ]
- Notes: [ ]

## Paper Mailers

### Supplier A — [Name]

- Contact: [Name, email, phone]
- Website: [URL]
- Products: [e.g. padded paper mailer, sizes]
- Minimum order: [ ] units
- Unit price at my volume: $[ ] at [ ] units — next tier: $[ ] at [ ] units
- Lead time: [ ] days — Delivery cost: $[ ]
- Samples: [free / $___]
- Certifications: [ ]
- Sample test result: [ ]
- Notes: [ ]

### Supplier B — [Name]

- Contact: [Name, email, phone]
- Website: [URL]
- Products: [ ]
- Minimum order: [ ] units
- Unit price at my volume: $[ ] at [ ] units — next tier: $[ ] at [ ] units
- Lead time: [ ] days — Delivery cost: $[ ]
- Samples: [free / $___]
- Certifications: [ ]
- Sample test result: [ ]
- Notes: [ ]

## Paper Wrap and Void Fill (Honeycomb / Kraft / Corrugated Wrap)

### Supplier A — [Name]

- Contact: [Name, email, phone]
- Website: [URL]
- Products: [ ]
- Minimum order: [ ] units
- Unit price at my volume: $[ ] at [ ] units — next tier: $[ ] at [ ] units
- Lead time: [ ] days — Delivery cost: $[ ]
- Samples: [free / $___]
- Certifications: [ ]
- Sample test result: [ ]
- Notes: [ ]

### Supplier B — [Name]

- Contact: [Name, email, phone]
- Website: [URL]
- Products: [ ]
- Minimum order: [ ] units
- Unit price at my volume: $[ ] at [ ] units — next tier: $[ ] at [ ] units
- Lead time: [ ] days — Delivery cost: $[ ]
- Samples: [free / $___]
- Certifications: [ ]
- Sample test result: [ ]
- Notes: [ ]

## Paper Tape

### Supplier A — [Name]

- Contact: [Name, email, phone]
- Website: [URL]
- Products: [e.g. water-activated kraft tape, widths]
- Minimum order: [ ] units
- Unit price at my volume: $[ ] at [ ] units — next tier: $[ ] at [ ] units
- Lead time: [ ] days — Delivery cost: $[ ]
- Samples: [free / $___]
- Certifications: [ ]
- Sample test result: [ ]
- Notes: [ ]

## Moulded Fibre Inserts

### Supplier A — [Name]

- Contact: [Name, email, phone]
- Website: [URL]
- Products: [ ]
- Minimum order: [ ] units
- Tooling cost: $[ ]
- Unit price at my volume: $[ ] at [ ] units — next tier: $[ ] at [ ] units
- Lead time: [ ] days — Delivery cost: $[ ]
- Samples: [free / $___]
- Certifications: [ ]
- Sample test result: [ ]
- Notes: [ ]

## Compostable Mailers / Bags

### Supplier A — [Name]

- Contact: [Name, email, phone]
- Website: [URL]
- Products: [ ]
- Minimum order: [ ] units
- Unit price at my volume: $[ ] at [ ] units — next tier: $[ ] at [ ] units
- Lead time: [ ] days — Delivery cost: $[ ]
- Samples: [free / $___]
- Certifications: [e.g. compostability standard and certifying body]
- Sample test result: [ ]
- Notes: [ ]

## Other / Custom Print

### Supplier A — [Name]

- Contact: [Name, email, phone]
- Website: [URL]
- Products: [ ]
- Minimum order: [ ] units
- Unit price at my volume: $[ ] at [ ] units — next tier: $[ ] at [ ] units
- Lead time: [ ] days — Delivery cost: $[ ]
- Samples: [free / $___]
- Certifications: [ ]
- Sample test result: [ ]
- Notes: [ ]

---

## Where to Find Suppliers (starting points)

- Your current packaging supplier — ask what sustainable options they carry first.
- Packaging trade directories and marketplaces in your country.
- Packaging trade shows — one visit can produce more useful contacts than a month of web searching.
- Recommendations from other small brands in your niche.
- General online marketplaces — use with care: check minimum orders, full landed cost (freight, duties, handling), and always order samples first.

## Reorder Checklist

- [ ] Re-quote before reordering if more than 6 months have passed or volume has changed.
- [ ] Confirm the material specification has not changed.
- [ ] Confirm certifications are still current.
- [ ] Confirm lead time in writing.
- [ ] Check stock on hand against the minimum order quantity (months of stock).
