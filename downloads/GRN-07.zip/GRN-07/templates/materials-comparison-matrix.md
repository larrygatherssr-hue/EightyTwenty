# Materials Comparison Matrix

## GRN-07 — Sustainable Packaging Playbook

**How to use this matrix:** Find the material you are considering, check its typical cost range, its disposal route, and the claim you can honestly make. Prices are indicative ranges for small-brand volumes (roughly 250–1,000 units) and will vary by supplier, size, print, and location. Always get a written quote for your exact specification. Verify disposal routes for your customers' locations — recyclability is local.

**Education-only notice:** This matrix is for general information only. It is not legal or certification advice. Confirm material composition and certifications with your supplier in writing before making any claim.

| Material | Typical unit cost (small volumes) | Conventional equivalent | Cost vs conventional | Best for | Not suitable for | Customer disposal (check locally) | Claim you can make (with evidence) | Evidence to hold |
|---|---|---|---|---|---|---|---|---|
| Corrugated cardboard box, recycled content (30–100% PCR) | $0.60–$1.50 | Virgin board box | Similar to +20% | Most products; outer pack | Very heavy items without double-wall board | Recycle with paper/cardboard | "Made from __% recycled cardboard" | Supplier statement of recycled % |
| Corrugated cardboard box, FSC-certified | $0.65–$1.70 | Standard box | +5–25% | Brands wanting certified fibre | — | Recycle with paper/cardboard | "FSC-certified cardboard" (with licence) | FSC chain-of-custody certificate no. |
| Paper mailer (padded, paper cushioning) | $0.35–$0.90 | Poly mailer $0.15–$0.40 | +50–150% | Soft goods: apparel, textiles, accessories | Heavy, sharp, or liquid-prone items | Recycle with paper (check locally) | "Paper mailer — please recycle with paper" | Supplier material specification |
| Poly mailer, recycled content (50–100% PCR) | $0.18–$0.45 | Virgin poly mailer $0.12–$0.30 | +20–50% | Light goods where water resistance matters | Brands aiming for plastic-free | Store drop-off for soft plastics, where available; not usually curbside | "Made from __% recycled plastic" | Supplier certificate of recycled % |
| Honeycomb paper wrap | $0.15–$0.40 per order | Bubble wrap $0.15–$0.35 | Similar to +30% | Wrapping jars, bottles, ceramics | Very heavy items; damp conditions | Recycle with paper | "Paper cushioning — please recycle with paper" | Supplier specification |
| Kraft paper wrap / crinkled paper void fill | $0.05–$0.25 per order | Air pillows $0.05–$0.20 | Similar | Void fill, wrapping | Fragile items needing high cushioning | Recycle with paper | "Paper void fill — please recycle with paper" | Supplier specification |
| Corrugated paper wrap (fluted) | $0.15–$0.40 per order | Bubble wrap | Similar to +30% | Bottles, jars, fragile goods | Heavy items | Recycle with paper/cardboard | "Paper wrap — please recycle with paper" | Supplier specification |
| Moulded fibre / pulp insert (custom) | $0.40–$1.50 | Foam insert $0.30–$1.00 | +20–100% at low volumes; falls with volume | Jars, bottles, electronics, stable high-volume products | Products that change shape often; low volumes (tooling cost) | Recycle with paper; compostable in some systems — check locally | "Moulded fibre insert made from recycled paper" | Supplier specification; tooling quote |
| Compostable mailer (commercially compostable, e.g. to ASTM D6400 / EN 13432) | $0.30–$0.80 | Poly mailer $0.12–$0.30 | +100–200% | Light goods, brands with access to commercial composting | Home composting claims; areas without commercial composting | Commercial composting only, where available — do NOT put in home compost unless certified home-compostable | "Commercially compostable to [standard]" — name the standard | Compostability certificate for this exact product |
| Compostable mailer (certified home-compostable, e.g. to AS 5810) | $0.40–$0.90 | Poly mailer $0.12–$0.30 | +150–250% | Light goods where customers home-compost | Customers without composting | Home compost, per certificate | "Certified home-compostable to [standard]" | Home-compostability certificate |
| Paper tape, water-activated (kraft) | $0.05–$0.12 per order | Plastic tape $0.03–$0.06 | +50–100% | Sealing cardboard boxes | Non-cardboard surfaces; very cold/damp packing areas (check adhesive) | Recycle with the box | "Sealed with paper tape — recycle box and tape together" | Supplier specification |
| Paper tape, pressure-sensitive | $0.05–$0.10 per order | Plastic tape $0.03–$0.06 | +30–80% | Sealing boxes and mailers | Heavy boxes (check adhesion) | Recycle with the box (check locally) | "Sealed with paper tape" | Supplier specification |
| Tissue paper, recycled or FSC | $0.03–$0.08 per sheet | Standard tissue $0.02–$0.06 | Similar to +30% | Presentation wrapping | — (use one sheet well, not three) | Recycle with paper; compost where accepted | "Recycled tissue paper" (if applicable) | Supplier statement |
| Paper shipping label (with paper liner) | $0.03–$0.08 | Standard label $0.02–$0.05 | Similar | All parcels | — | Recycle with the box (check adhesive) | — | Supplier specification |

## Reading the Matrix

1. **Start with the disposal column, not the price column.** A material your customers cannot dispose of easily creates a worse experience than a slightly more expensive material they can recycle at home.
2. **Cost is per unit, not per order.** A paper mailer costs more than a poly mailer, but a right-sized box with paper wrap can cost less per order than a large box with bubble wrap and air pillows. Always cost the whole pack (Module 5).
3. **"Compostable" is the most misused word in packaging.** Only use it with the certificate, the standard named, and the composting route stated. Never use "biodegradable" on its own — it has no agreed timeframe or conditions.
4. **Recycled content percentages must be evidenced.** "Made from recycled plastic" without a percentage is vague. Ask the supplier for the percentage and whether it is post-consumer or pre-consumer, and keep it in writing.
5. **Weight matters.** Paper alternatives are often heavier than plastic ones. Check the weight effect on your shipping band before switching a large volume.

## Materials to Approach with Caution

- **"Biodegradable" plastics with no standard named.** The word alone tells the customer nothing and may breach green-claims rules.
- **"Ocean plastic" or "plant-based" without a percentage or a certifier.** Ask what percentage, by what standard, and who certified it.
- **Mixed-material packs** (for example, a paper mailer with a plastic bubble lining, or a box with a plastic window). The customer cannot recycle the parts together, and the pack is harder to dispose of than a single-material pack.
- **Any material whose supplier will not confirm composition in writing.** If the supplier will not put it in writing, do not put it on your packaging.
