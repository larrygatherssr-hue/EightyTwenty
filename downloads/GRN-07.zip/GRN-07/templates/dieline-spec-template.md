# Dieline Specification Template

## GRN-07 — Sustainable Packaging Playbook

**How to use this template:** Complete it in full and send it to your printer or packaging supplier when requesting a quote for custom-printed packaging. An incomplete specification is the most common cause of a wrong quote, a delayed proof, or a print run that does not fit the product. Ask the supplier for their dieline for the size you need; if you need a custom size, ask for the dieline fee and lead time.

**Education-only notice:** This template is for general information only. Confirm all dimensions, materials, and print requirements with your supplier in writing before approving a print run.

---

## 1. Brand and Contact

- Brand name: ________________________________________________________________
- Contact name: ______________________________________________________________
- Email: _____________________________________________________________________
- Phone: ____________________________________________________________________
- Date: ______________________________________________________________________

## 2. Product to Be Packaged

- Product name: ______________________________________________________________
- Product dimensions (L x W x H): __________ x __________ x __________ cm / in
- Product weight: __________ g
- Number of units per pack: __________
- Fragility: Fragile / Moderately fragile / Non-fragile (circle one)
- Special requirements (moisture-sensitive, temperature-sensitive, etc.): ______________
  ___________________________________________________________________________

## 3. Pack Type and Dimensions

- Pack type: [ ] RSC box [ ] Mailer box [ ] Paper mailer [ ] Other: ________________
- Internal dimensions (L x W x H): __________ x __________ x __________ cm / in
- External dimensions (L x W x H): __________ x __________ x __________ cm / in
- Dieline required: [ ] Supplier's standard size [ ] Custom size — dieline fee quoted: $__________
- Supplier's dieline reference / file name: ________________________________________

## 4. Material

- Material: [ ] Corrugated cardboard [ ] Paperboard [ ] Paper mailer [ ] Other: __________
- Board grade / flute: __________ (e.g. B-flute single-wall, E-flute, double-wall)
- Recycled content: __________% (post-consumer / pre-consumer — circle)
- FSC-certified: Yes / No — certificate no.: ______________________________________
- Colour: [ ] Kraft (unbleached) [ ] White [ ] Other: ____________________________
- Coating: [ ] None [ ] Water-resistant coating (specify): ________________________

## 5. Print

- Print on: [ ] Outside only [ ] Inside only [ ] Outside and inside
- Number of colours (outside): __________ — (inside): __________
- Print method: [ ] Flexographic [ ] Lithographic [ ] Digital [ ] Other: ____________
- Artwork file(s) attached: [ ] Yes — file name(s): ________________________________
- Bleed: __________ mm
- Barcode / QR code area: [ ] Yes — position: ____________________________________
- Shipping label area (keep clear of print): [ ] Yes — position: ____________________
- Claims to be printed (exact wording — must match evidence held):
  1. ________________________________________________________________________
  2. ________________________________________________________________________
  3. ________________________________________________________________________
- Certification logos to be printed: _____________________________________________
  Licence / certificate number for each: ________________________________________

## 6. Construction and Finishing

- Closure: [ ] Tape [ ] Tear strip [ ] Tuck flap [ ] Glue [ ] Other: ________________
- Glue area: __________________________________________________________________
- Fold / score lines: per supplier dieline
- Handles / thumb notches: [ ] Yes — details: ____________________________________
- Window: [ ] No [ ] Yes — material: ___________________________________________
  (Note: a plastic window means the pack is not plastic-free — do not claim it is.)

## 7. Quantities and Delivery

- Quantity: __________ units
- Reorder quantity expected: __________ units
- Delivery address: ___________________________________________________________
- Required delivery date: __________
- Delivery cost quoted: $__________

## 8. Proof and Approval

- [ ] Digital proof received and checked against this specification
- [ ] Dimensions checked
- [ ] Spelling of every word checked
- [ ] Artwork position across fold lines checked
- [ ] Barcode / label area clear
- [ ] Physical sample requested: Yes / No
- [ ] Physical sample received and tested (drop test, fit, colour on actual material)
- [ ] Approved by: ________________________ Date: __________

## 9. Notes

- ___________________________________________________________________________
- ___________________________________________________________________________
- ___________________________________________________________________________
