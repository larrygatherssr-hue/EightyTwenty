# Sustainable Packaging Playbook for E-Commerce Brands

## GRN-07 — A Practical Programme for Small Brands

**Price:** $297 (one-time)
**Format:** Written programme in seven modules, plus templates, worksheets, a supplier directory, and a cost calculator.

---

## Important Notice — Please Read First

This programme is for education and general information only. It is not legal advice, environmental certification advice, or financial advice. Packaging regulations, recycling rules, extended producer responsibility (EPR) schemes, labelling requirements, and material claims vary by country, state, and municipality, and they change over time. Costs for materials, freight, and fulfilment vary by supplier, order volume, product weight, and location. Before you make a packaging change, verify the current rules that apply to where you sell and ship, confirm any environmental claim with your supplier in writing, and test the new packaging with your actual products. Nothing in this programme guarantees a particular cost saving, sales increase, or regulatory outcome.

---

## Table of Contents

- Introduction: Why Packaging Is a Business Decision, Not Just a Box
- Module 1: Audit What You Ship Today
- Module 2: Understand the Materials — What Works, What Does Not, and What It Costs
- Module 3: Design Packaging That Protects, Fits, and Sells
- Module 4: Find and Vet Suppliers Without Getting Burned
- Module 5: Do the Money Math — Cost, Break-Even, and Margin
- Module 6: Roll Out the Switch Without Disrupting Orders
- Module 7: Stay Compliant, Tell the Truth, and Keep Improving
- Appendix A: Glossary of Packaging Terms
- Appendix B: Your 90-Day Switch Plan at a Glance

---

## Introduction: Why Packaging Is a Business Decision, Not Just a Box

Packaging is the first physical thing your customer touches. Long before they use your product, they open a box, tear a mailer, or peel tape off a parcel. In that moment they form a judgement — not only about whether the product arrived safely, but about what kind of brand you are.

For a small e-commerce brand, packaging is also one of the few costs you can control directly. You cannot control ad prices, platform fees, or shipping rates. You can control what you put a product in, how much of it you use, how heavy it is, and how much of it ends up in the bin. That makes packaging a lever: pull it well and you protect your product, reduce waste, lower dimensional weight, and give customers a reason to come back. Pull it badly and you pay for damage claims, returns, oversized boxes, and packaging that contradicts everything your brand says about itself.

This programme is written for a brand doing roughly 50 to 2,000 orders a month — big enough that packaging costs matter, small enough that you do not have a packaging engineer on staff. It assumes you are currently using conventional materials — poly mailers, plastic bubble wrap, standard cardboard boxes, plastic tape — and you want to move toward more sustainable options without blowing your margins or breaking your fulfilment flow.

A word on honesty, because it matters more here than in almost any other part of your business. Sustainability claims are scrutinised. Customers, marketplaces, and regulators all pay attention to words like "compostable," "biodegradable," "recyclable," and "plastic-free." Each of those words has a specific meaning, and using one incorrectly can cost you trust and, in some jurisdictions, money in fines. This programme will teach you to make claims you can defend, with evidence from your supplier, rather than claims that sound good on a mailer.

You do not need to switch everything at once. In fact, you should not. The brands that succeed at this pick one product line, one packaging change, prove it works, and then expand. By the end of Module 7 you will have a costed plan, a vetted supplier shortlist, a rollout schedule, and packaging you can describe accurately to your customers.

### How to Use This Programme

Work through the modules in order the first time. Each module ends with actions. Do the actions before moving on — the programme builds on itself. The companion workbook (`workbook.md`) holds the worksheets referenced in each module. The templates folder holds the calculator, the materials matrix, the supplier directory, the compliance checklist, and a dieline specification template you can send to a printer or packaging supplier.

Set aside roughly two to three hours per module, including the actions. The full switch, from audit to rollout, typically takes six to twelve weeks for a small brand. The 90-day plan in Appendix B gives you a realistic timeline.

### What "Sustainable" Means in This Programme

There is no single definition of sustainable packaging that every authority agrees on. In this programme, the word is used in a practical sense: packaging that (1) uses less material overall, (2) uses materials that are renewable, recycled, or widely recyclable where your customers live, (3) avoids materials that are difficult to recycle or that contaminate recycling streams, and (4) protects the product well enough that damage and returns do not rise. A switch that looks greener on paper but doubles your damage rate is not a sustainable switch — it creates more waste, not less.

Keep that test in mind throughout: less material, better material, same or better protection.

---

## Module 1: Audit What You Ship Today

You cannot improve what you have not measured. Most small brands have never added up what their packaging actually costs per order, how much of it they use, or how much of it their customer has to throw away. This module fixes that. By the end of it you will know your current per-order packaging cost, your most wasteful item, and which product line to switch first.

### Step 1: List Every Packaging Item You Use

Walk your packing bench — or open your last three supplier invoices — and list every item that goes into a typical order. Include the things you forget: the tape, the thank-you card, the tissue paper, the sticker that seals the mailer, the label. A typical small brand's list looks like this:

- Outer mailer or box (one or two sizes)
- Inner wrap or void fill (bubble wrap, tissue, kraft paper, air pillows)
- Product bag or pouch (poly bag, paper bag, or none)
- Tape (plastic packing tape or paper tape)
- Label (shipping label, plus any branded label)
- Insert (thank-you card, care card, discount card, returns instructions)
- Seal or sticker

For each item, record: what it is made of, its size, how many you use per order on average, what one unit costs you, and where you buy it. The workbook's Current Packaging Audit worksheet is built for exactly this. If you buy in bulk, divide the pack price by the pack quantity to get the unit cost. If you are not sure of a unit cost, use your most recent invoice — do not guess from memory.

### Step 2: Pack Five Real Orders and Weigh Them

Take five recent orders that represent your typical range — your smallest product, your largest, your most common, a two-item order, and a fragile item if you sell one. Pack each exactly as you normally would, then weigh the complete parcel and the packaging alone. Weigh the packaging alone by weighing the empty packaging items before they go around the product.

Record three numbers for each order: total parcel weight, packaging weight, and the product weight. The packaging share — packaging weight divided by total weight — tells you how much of what you ship is not product. For a small cosmetics brand shipping a 120-gram jar, packaging of 180 grams means 60 percent of the parcel's weight is packaging. That is a red flag, and it is also an opportunity: every gram you remove is a gram you stop paying to ship.

Also measure the box or mailer against the product inside it. If the box is more than twice the volume of the product, you are shipping air. Oversized packaging costs you in material, in void fill, and in dimensional weight charges from carriers that price by size as well as weight.

### Step 3: Add Up Your True Per-Order Cost

Add the unit costs of everything in a typical order. Then add the costs most brands leave out:

- **Damage and returns:** Take your last three months of damage claims, replacements, and returns caused by packaging failure. Divide by the number of orders in the same period. If you replaced 12 orders out of 900 because items arrived broken, and each replacement cost you $18 in product and reshipping, that is $216 over 900 orders, or $0.24 per order. Add it.
- **Void fill and overpacking:** If you use two sheets of tissue where one would do, or a large box for a small item, that excess is a cost. Estimate it honestly.
- **Labour:** Time your packer (or yourself) packing ten orders. If packing takes four minutes per order and your effective labour cost is $18 an hour, packing labour is $1.20 per order. A packaging change that cuts packing time to two and a half minutes saves $0.45 per order — at 500 orders a month, that is $225 a month. Labour is often the largest hidden packaging cost, and the easiest to overlook.
- **Storage:** Bulky packaging takes shelf space. If you pay for storage by the pallet or the square foot, note it, even roughly.

### Worked Example: A Candle Brand's Audit

Consider a small candle brand shipping 400 orders a month. Its current pack is:

| Item | Unit cost |
|---|---|
| 8 x 8 x 8-inch corrugated box | $0.85 |
| Bubble wrap (one sheet) | $0.22 |
| Tissue paper (two sheets) | $0.08 |
| Poly bag around the candle | $0.06 |
| Plastic packing tape | $0.04 |
| Thank-you card | $0.12 |
| Shipping label | $0.03 |
| **Materials subtotal** | **$1.40** |
| Damage and replacements ($0.24/order) | $0.24 |
| Packing labour (4 minutes at $18/hour) | $1.20 |
| **True cost per order** | **$2.84** |

That is $1,136 a month in true packaging cost. The audit also found that the box was 40 percent empty by volume, the bubble wrap was used on a product that had already survived a drop test in a paper wrap, and the poly bag served no purpose once the candle was inside a lidded jar. Three easy wins were visible before any supplier was contacted: a smaller box, paper wrap instead of bubble wrap, and dropping the poly bag. Together those three changes, priced in Module 5, cut the materials subtotal by $0.31 per order — $124 a month — before any sustainability benefit was counted.

Your numbers will differ. The point of the exercise is the same: you now know where the money goes.

### Step 4: Ask Your Customers What They Actually Do With Your Packaging

You do not need a survey tool. Add one question to your next three order confirmation emails, or post it once on your social channels: "What do you do with our packaging when your order arrives — recycle it, reuse it, compost it, or bin it?" The answers will tell you more than any industry report. If most customers say they bin the poly mailer because their local recycling does not accept it, that mailer is a problem even if the supplier called it recyclable. Recyclability is local. A material is only recyclable for your customer if their local system accepts it.

Also check your reviews and support messages for packaging mentions. Search for words like "packaging," "box," "plastic," "waste," and "damaged." Five minutes of searching will show you whether packaging is already a complaint, a compliment, or invisible. If customers already praise your packaging, protect what they love. If they complain about excess plastic, you have a mandate to change.

### Step 5: Choose Your First Switch

Do not switch everything. Choose one product line — ideally your best seller or your simplest product — and one packaging change. Good first switches are: replacing a poly mailer with a paper mailer or a recycled-content box; replacing plastic bubble wrap with kraft paper wrap or corrugated wrap; replacing plastic tape with paper tape; or removing one unnecessary item entirely, such as a poly bag or a second insert.

Score each candidate change on three questions: How much will it cost per order (more, the same, or less)? How hard is it to implement (same supplier, same packing process, or a new process)? How much will the customer notice (a visible improvement, or invisible)? Pick the change that is low cost, easy to implement, and visible. Early wins build confidence and give you a story to tell.

### Module 1 Actions

1. Complete the Current Packaging Audit in the workbook for your top product line.
2. Pack and weigh five real orders; record packaging weight share and box-to-product volume.
3. Calculate your true per-order packaging cost, including damage and labour.
4. Read your last three months of reviews and support messages for packaging mentions.
5. Choose one product line and one packaging change as your first switch, and write it down.

---

## Module 2: Understand the Materials — What Works, What Does Not, and What It Costs

This module gives you a working knowledge of the materials a small brand is likely to use. You do not need a materials science degree. You need to know what each material is, when it is a good choice, when it is not, what it typically costs relative to the conventional option, and what you can honestly say about it. The full comparison lives in the templates folder as `materials-comparison-matrix.md`; this module explains how to read it and how to use it.

### The Materials You Will Meet

**Corrugated cardboard (boxes).** The workhorse of e-commerce. Made from kraft linerboard and a fluted middle layer. Available with recycled content — commonly 30 to 100 percent post-consumer recycled fibre. Widely recyclable in most areas, and customers know what to do with it. Cost depends on size, board grade, print, and volume. A standard single-wall RSC (regular slotted container) box in a common size might cost $0.60 to $1.50 each at volumes of 250 to 1,000 units, with custom printing adding $0.20 to $0.80 per unit at low volumes. Double-wall board costs more but protects heavier or fragile items. The main sustainability lever with boxes is not the board itself but the size: a right-sized box uses less board, less void fill, and less shipping volume.

**Paper mailers.** A padded or unpadded paper envelope, often with a paper cushioning layer inside. A good replacement for a poly mailer for soft, non-fragile goods such as apparel, textiles, and some accessories. Typically $0.35 to $0.90 each at small volumes, compared with $0.15 to $0.40 for a basic poly mailer — so a paper mailer usually costs more per unit. The trade-off is that customers can recycle it with paper in many areas, and it reads as a deliberate brand choice. Not suitable for heavy, sharp, or liquid-prone items without additional protection.

**Poly mailers (conventional and recycled-content).** Light, cheap, water-resistant, and widely used. A conventional virgin-plastic poly mailer might cost $0.12 to $0.30 each. Recycled-content versions (often 50 to 100 percent post-consumer recycled plastic) cost roughly 20 to 50 percent more. They are lighter than boxes, which saves on shipping, but they are difficult to recycle in many household systems — most curbside programmes do not accept soft plastics, and customers often have to take them to a store drop-off. If you keep using poly mailers, recycled content is a real improvement, but be honest in your claims: "made from 100% recycled plastic" is a claim you must be able to prove with a supplier certificate, and it does not make the mailer recyclable at the kerb.

**Kraft paper wrap and void fill.** Paper used to wrap products and fill empty space. Crinkled kraft paper, honeycomb paper wrap, and corrugated paper wrap are the common forms. Honeycomb paper wrap, which expands into a cushioning mesh, typically costs $0.15 to $0.40 per order's worth, against $0.15 to $0.35 for a sheet of bubble wrap — roughly comparable, sometimes slightly more. It is recyclable with paper in many areas, and customers generally prefer the look and feel. It is heavier than bubble wrap, so check the weight effect on shipping before switching a large volume.

**Moulded fibre (pulp) inserts.** Shaped trays and inserts made from recycled paper pulp, used to hold a product in place inside a box. Excellent protection for jars, bottles, and electronics. Cost varies widely by shape and volume — a custom moulded insert might cost $0.40 to $1.50 per unit at low volumes, falling sharply at higher volumes. The tooling cost for a custom shape can be several hundred to several thousand dollars, which is why moulded fibre suits a stable, high-volume product rather than a product that changes shape every season.

**Compostable mailers and bags.** Usually made from plant-based polymers such as PLA blended with PBAT. Marketed as home-compostable or commercially compostable. This is the material most often misunderstood. "Compostable" usually means commercially compostable under industrial conditions (high heat, controlled humidity) to a standard such as ASTM D6400 or EN 13432. Most home compost heaps do not reach those conditions. A certified home-compostable product (for example, to AS 5810 or NF T 51-800) is a different, rarer claim. A compostable mailer typically costs $0.30 to $0.80 each — two to three times a conventional poly mailer. Only use the word "compostable" on your packaging if you hold the certificate for that exact product, and say which kind of composting it needs. Never call a product "biodegradable" without a timeframe and conditions: almost everything biodegrades eventually, and the word on its own tells the customer nothing.

**Paper tape (kraft tape, water-activated tape).** Replaces plastic packing tape. Water-activated kraft tape bonds to cardboard and is recyclable with the box in many systems; pressure-sensitive paper tape is also available. Cost is typically $0.05 to $0.12 per order's worth, against $0.03 to $0.06 for plastic tape — a small increase. It also improves the unboxing look and, for water-activated tape, creates a tamper-evident seal. A tape dispenser for water-activated tape costs roughly $30 to $150, a one-off cost to budget for.

**Tissue paper.** Used for wrapping and presentation. Available in recycled content and in FSC-certified virgin fibre. Typically $0.03 to $0.08 per sheet. The sustainability question with tissue is usually not the tissue itself but how much of it you use: one sheet used well beats three sheets used carelessly.

**Bioplastics and other alternatives.** You will be offered materials described as "plant-based," "bio-based," or "ocean plastic." Treat each claim separately. Ask the supplier: What percentage is bio-based, and by what standard? Is it certified, and by whom? How should the customer dispose of it? If the supplier cannot answer in writing, do not put the claim on your packaging.

### Certifications and Labels Worth Knowing

You do not need to memorise certification schemes, but you should recognise the main ones and know what to ask for:

- **FSC (Forest Stewardship Council).** Certifies that paper and board come from responsibly managed forests or recycled sources. Ask for the supplier's FSC chain-of-custody certificate number if you want to use the FSC logo.
- **Recycled content claims.** Ask for the percentage and whether it is post-consumer or pre-consumer recycled content. Post-consumer content (material that was used by a consumer and recycled) is generally regarded as the stronger claim.
- **Compostability standards.** ASTM D6400 (North America), EN 13432 (Europe), AS 5810 (home compostable, Australia). A certificate should name the standard and the certifying body.
- **How2Recycle (North America).** A labelling system that tells customers how to dispose of each part of the pack. Useful if you sell mainly in the US or Canada.

Do not print a certification logo on your packaging unless you hold, or your supplier holds, a valid licence for that logo on that product. Using a logo without a licence is a fast way to lose a supplier relationship and invite a complaint.

### What a Material Costs — and What It Saves

A sustainable material almost always costs more per unit than the conventional material it replaces. That is the honest starting point. The question is not whether the unit cost rises, but whether the total cost per order rises — and whether the increase is worth it.

Three things can offset a higher unit cost:

1. **Less material.** A right-sized box and one sheet of honeycomb wrap can cost less in total than a large box, two sheets of bubble wrap, and a bag of air pillows.
2. **Lower shipping weight or volume.** A lighter mailer can move an order into a lower shipping band. Check your carrier's pricing bands before assuming this — the saving is real for some products and zero for others.
3. **Lower damage and returns.** Better-fitting protection reduces breakage. Even a small reduction in your damage rate can pay for a more expensive material.

Run the numbers in Module 5 before you decide. Do not decide on unit price alone.

### Worked Example: Poly Mailer to Paper Mailer

A small apparel brand ships 600 orders a month in poly mailers. Current mailer: $0.22 each. Paper mailer quoted: $0.55 each. The increase is $0.33 per order, or $198 a month. The brand also finds that the paper mailer is slightly heavier (28 grams against 18 grams) but the weight difference does not change its shipping band, so shipping cost is unchanged. The brand decides the $198 a month is worth it because customers have complained about plastic mailers and the brand's positioning is built on natural fibres — but it makes the decision with the number in front of it, not on a feeling. It also decides to absorb the cost rather than raise prices, because $0.33 on a $48 average order is 0.7 percent of revenue, and a price rise would cost more in lost conversions than it would gain. That is the kind of judgement this programme is teaching: a costed decision, made deliberately.

### Module 2 Actions

1. Read the materials comparison matrix in the templates folder and highlight the three materials most relevant to your products.
2. For each material you are considering, write down the claim you would like to make and the evidence you would need to make it.
3. List any certification logos you currently use or want to use, and check whether you hold a valid licence for each.
4. Note the materials you will rule out, and why — a short "not for us" list saves time later.

---

## Module 3: Design Packaging That Protects, Fits, and Sells

Good packaging design is not decoration. It is a system: the outer pack, the inner protection, the product's own container, and the information printed on the outside must work together. This module walks through that system in the order you should design it — protection first, fit second, brand third.

### Step 1: Design for Protection First

Start with the worst thing that can happen to your product in transit: a drop from waist height onto concrete, a heavy parcel stacked on top of it, a rainy loading dock, a hot delivery van. Your packaging must survive the normal handling of your carrier, not the careful handling of your packing bench.

Run a simple drop test. Pack your product exactly as you would ship it, then drop the sealed parcel from waist height onto a hard floor, once on a flat side and once on a corner. Open it and inspect the product. Then repeat with the parcel turned the other way up. If the product is damaged, your protection is inadequate — fix that before you change anything else for sustainability reasons. A sustainable pack that arrives broken is worse than a conventional pack that arrives intact, because the replacement shipment doubles the packaging and the shipping.

For fragile products, the rule of thumb is at least 5 centimetres (about 2 inches) of cushioning on all sides between the product and the outside of the box. For non-fragile products, the product should not be able to move freely inside the pack: if you can hear it rattling when you shake the sealed parcel gently, add fill or use a smaller pack.

Test with water too, if your product is damaged by moisture. Put a sealed parcel under a running tap for thirty seconds, or leave it outside in rain for ten minutes, then open it. Paper mailers and uncoated boxes will wet through; if your products are moisture-sensitive, you need a water-resistant inner layer or a different outer pack. Do not discover this from a customer complaint.

### Step 2: Right-Size the Pack

Right-sizing is the single highest-impact change most small brands can make, and it costs nothing in new materials — it often saves money immediately.

Measure your product, with its inner protection, and choose the smallest standard box or mailer that fits it with the cushioning it needs. If your product range needs three sizes, stock three sizes; if it needs one, stock one. Resist the temptation to stock one large size "to cover everything." That large size is where your void fill, your dimensional weight, and your waste all come from.

If you ship a range of order sizes, consider a simple size guide for your packer: a one-page sheet that says, for example, "One candle: small box. Two candles: medium box. Three or more: large box." Tape it to the packing bench. It removes guesswork and stops the habit of reaching for the biggest box by default.

For brands that ship a single hero product in high volume, a custom-sized box is worth pricing. At volumes of 500 to 1,000 units, a custom size often costs only 10 to 30 percent more than a stock size, and the saving in void fill and shipping volume can pay for the difference. Get a quote before dismissing it.

### Step 3: Design the Unboxing

Unboxing is marketing you have already paid for. The customer has the parcel in their hands; you have their full attention for about thirty seconds. Use it well, and use less to do it.

A good unboxing has three qualities: it is easy to open, it looks deliberate, and it leaves little waste. Easy to open means a tear strip, a thumb notch, or tape that peels cleanly — not a box sealed with three layers of tape that needs scissors and patience. Deliberate means the inside looks considered: the product is centred, the wrap is neat, the card is on top. Little waste means the customer is not left with a pile of fill to throw away.

You do not need tissue paper, a ribbon, a sticker, a card, and a sample to achieve this. Pick two branded touches and do them well. A printed box interior in one colour, plus a single well-written card, will beat a pile of extras that the customer bins. Every extra item is a cost, a weight, and a disposal decision for your customer. If an insert does not earn its place — if it does not inform, delight, or drive a repeat purchase — remove it.

Think about the card in particular. A thank-you card that says "Thank you for your order" and nothing else is a missed opportunity. A card that tells the customer how to dispose of each part of the packaging, how to care for the product, and where to get support earns its place. That disposal instruction is also a compliance and honesty step: it tells the customer what to do with the pack, which is exactly the information a vague "recyclable" claim fails to give.

### Step 4: Print Only What You Can Stand Behind

Everything printed on your packaging is a claim. Before you approve a print run, check every word against the evidence:

- If the box says "100% recycled," you need a supplier statement that the board is 100 percent recycled fibre.
- If the mailer says "compostable," you need the certificate, and you need to say where — home or commercial composting.
- If you print a recycling symbol, check that the material is actually accepted in the recycling systems where most of your customers live. A resin code on a plastic item is not a promise that it will be recycled; it is an identification code, and customers often misread it as a guarantee.
- If you say "plastic-free," make sure every part of the pack is plastic-free, including the tape, the label adhesive, and the window on the box. One plastic window invalidates the claim.

Keep the printed claims short and specific. "This box is made from 100% recycled cardboard. Please recycle it with paper." is a better claim than "Eco-friendly packaging!" — the first is verifiable and tells the customer what to do; the second is vague and means nothing under most advertising rules. Some jurisdictions, including the EU and several US states, have rules against vague environmental claims. Specificity protects you.

### Step 5: Use a Dieline, Not a Sketch

A dieline is the flat template a printer or box manufacturer uses to cut and fold your packaging. It shows the exact dimensions, fold lines, cut lines, glue areas, and bleed. If you are ordering custom-printed boxes or mailers, the supplier will usually provide a dieline template for their standard sizes, or create one for a custom size for a fee. Never approve a custom print job from a sketch or a description alone.

The templates folder includes a `dieline-spec-template.md` you can send to a supplier. It captures the product dimensions, the pack dimensions, the board or material grade, the print colours, the inside and outside artwork, and the quantities. Fill it in completely before you request a quote — an incomplete specification is the most common cause of a wrong quote, a delayed proof, and a print run that does not fit the product.

When you receive a proof, check it against the dieline, not against your memory of what you asked for. Check the dimensions, the spelling of every word, the placement of any barcode or label area, and whether the artwork sits correctly across the fold lines. Ask for a physical sample before approving a large run. A digital proof cannot show you how a colour looks on kraft board, or whether a fold line cuts through a line of text.

### Worked Example: Right-Sizing a Skincare Brand

A skincare brand ships a 50-millilitre jar in a 20 x 15 x 10-centimetre box, with the jar wrapped in bubble wrap and the empty space filled with air pillows. The jar itself is 7 x 7 x 6 centimetres. The box volume is 3,000 cubic centimetres; the jar occupies about 294 cubic centimetres — less than 10 percent of the box. The brand switches to a 12 x 10 x 8-centimetre box (960 cubic centimetres) with a moulded pulp insert that holds the jar in place. The smaller box costs $0.55 instead of $0.85, the pulp insert costs $0.35, and the air pillows and bubble wrap are removed ($0.28 saved). Materials per order move from $1.13 to $0.90 — a saving of $0.23 per order — and the parcel is smaller and lighter, which moves some orders into a lower shipping band. The damage rate, measured over the next 200 orders, stays at zero, the same as before. The lesson is not that every brand should use a pulp insert; it is that measuring the box against the product, rather than against habit, is where the money is.

### Module 3 Actions

1. Drop-test your current pack (flat side and corner) and record the result.
2. Measure your top three products and the boxes you ship them in; calculate the volume ratio.
3. Write a one-page size guide for your packing bench.
4. Rewrite the claims on your current packaging; strike out anything you cannot evidence.
5. If you are ordering custom print, complete the dieline specification template and request a physical sample before approving a run.

---

## Module 4: Find and Vet Suppliers Without Getting Burned

A good supplier is worth more than a cheap price. A supplier who delivers late, ships the wrong grade, or cannot provide a certificate will cost you more than the saving on the unit price. This module is a practical vetting process for small brands that cannot afford a bad supplier.

### Where to Find Suppliers

Start with the suppliers you already use. Ask your current packaging supplier what sustainable options they carry — many conventional suppliers now stock recycled-content board, paper tape, and paper mailers, and switching within an existing relationship is faster than starting a new one. If they have nothing suitable, ask them who they would recommend; suppliers often know their competitors' strengths.

Other routes: packaging trade directories and marketplaces in your country, trade shows (even a single visit to a packaging exhibition will give you more supplier contacts than a month of web searching), and recommendations from other small brands in your niche. Be cautious with general online marketplaces that list thousands of overseas suppliers: the prices look attractive, but minimum order quantities, shipping costs, import duties, and quality variation can erase the saving. If you do source overseas, budget for a sample order first and factor in the full landed cost — product, freight, duties, and any customs handling — before comparing prices.

Keep a shortlist of two to three suppliers per material, not ten. The supplier directory template in this programme is structured for that: one page per supplier, with contact details, products, minimum order, lead time, unit price at your volume, certifications held, and notes from your sample test.

### What to Ask Before You Order

Send every shortlisted supplier the same set of questions, so you can compare answers fairly. The questions that matter most:

1. What is the exact material composition, and what percentage is recycled or bio-based?
2. What certifications do you hold for this product, and can you send copies?
3. What is the minimum order quantity, and what is the unit price at my volume and at the next volume tier?
4. What is the lead time from order to delivery, and what is the delivery cost?
5. Can you send samples, and what do they cost?
6. What is the product's weight and dimensions, so I can calculate shipping?
7. How should the end customer dispose of this item, and what should I print on it?
8. What is your returns or replacement policy if the goods arrive damaged or off-specification?
9. Is the price fixed for a period, or does it change with raw material prices?

A supplier who answers these questions promptly and in writing is a supplier you can work with. A supplier who answers vaguely, or who will not put a claim in writing, is a supplier to avoid — whatever their price.

### How to Test Samples Properly

Always order samples before committing to a bulk order. When they arrive, test them the way your customer will experience them:

- Pack your actual product in the sample and run the drop test from Module 3.
- Check the fit: does the product sit securely, or does it move?
- Check the print quality and colour on the actual material, not on a screen.
- Check the weight of the sample pack against your current pack.
- If the material is a mailer, seal it, fill it, and try to tear it open the way a customer would. If it tears too easily, it will fail in transit; if it is hard to open, the customer will hate it.
- Store a sample in a damp place for a day if your products travel through humid conditions.

Record the results in the supplier directory, with the date and the name of the person you spoke to. Six months later, when you need to reorder, those notes are the difference between a confident reorder and starting the search again.

### Minimum Order Quantities and Cash Flow

Sustainable materials often carry higher minimum order quantities than conventional ones, especially for custom printing. A custom-printed box might require 500 or 1,000 units, against 100 units for a stock size. Before you commit, calculate how many months of stock that minimum represents. If you ship 200 orders a month and the minimum is 1,000 boxes, that is five months of stock and five months of cash tied up in boxes. That may be fine if the product is stable and the box size will not change — but if you are about to change your product range, it is a risk.

Negotiate where you can: ask whether the supplier will split a minimum across two sizes, whether a plain box with a printed label achieves the same effect as a fully printed box at a lower minimum, and whether the price improves at a higher volume you expect to reach in six months. A printed label on a plain recycled box is often the best compromise for a small brand: low minimum, professional look, easy to change.

### Red Flags

Walk away, or at least slow down, if you see any of these:

- A price that is far below every other quote for the same specification. It usually means a different material, a lower grade, or a hidden cost.
- A supplier who will not send samples, or who charges a large fee for them.
- Environmental claims with no certificate, no standard named, and no written confirmation.
- A supplier who asks for full payment upfront by a method that offers you no protection, particularly for a first order.
- Lead times that keep changing, or a supplier who cannot confirm a delivery date in writing.

None of these is proof of dishonesty on its own, but together they are a pattern. Your packaging is your brand in your customer's hands; the supplier who makes it deserves the same care you give to any other part of the business.

### Worked Example: Comparing Two Quotes Fairly

A brand needs 500 paper mailers. Supplier A quotes $0.48 each, delivery included, lead time 5 days, samples free. Supplier B quotes $0.39 each, delivery $28, lead time 14 days, samples $12. The headline prices suggest B is cheaper. The true comparison: A costs 500 × $0.48 = $240. B costs (500 × $0.39) + $28 = $223, plus $12 for samples already paid, so $235 for the first order. B is still slightly cheaper — by $5 — but takes nine days longer, and the brand needs stock within a week. The brand chooses A for the first order, keeps B on the shortlist, and re-quotes B when it has more time. Price is one factor; the decision is about total cost, timing, and risk together.

### Module 4 Actions

1. Ask your current supplier what sustainable options they carry.
2. Build a shortlist of two to three suppliers per material you need, using the supplier directory template.
3. Send the same nine questions to each shortlisted supplier.
4. Order samples and test them with your actual products using the drop test and the fit check.
5. Record the results, and choose a primary supplier and a backup for your first switch.

---

## Module 5: Do the Money Math — Cost, Break-Even, and Margin

This is the module that decides whether a switch happens. A packaging change is a business decision, and business decisions need numbers. This module gives you three calculations: the per-order cost comparison, the break-even on any one-off switching cost, and the margin effect. Use the packaging cost calculator in the templates folder (`packaging-cost-calculator.csv`) to run them with your own numbers.

### Calculation 1: Per-Order Cost, Current vs. New

For your chosen product line, list every packaging item in the current pack and in the proposed pack, with unit costs, and add shipping and damage costs for each.

The formula is:

**Total cost per order = materials + shipping + damage/replacement cost per order + packing labour per order**

Shipping is the part people get wrong. Do not use your average shipping cost across all orders; use the shipping cost for this product line at its actual weight and dimensions. If the new pack changes the weight or the size enough to move the parcel into a different carrier band, that changes the shipping cost — sometimes by more than the material cost changes. Check your carrier's rate card, or ship five test parcels with the new pack and record what you are actually charged.

Damage cost per order is calculated as in Module 1: total damage and replacement cost over three months divided by orders in the same period. For the new pack, you do not yet have three months of data. Use your drop-test result and your sample test as a guide: if the new pack protects as well as the old one, assume the same damage rate to start, and measure it for real after rollout. Do not assume the new pack will reduce damage until you have evidence. If the new pack is visibly weaker in testing, do not proceed — fix the protection first.

### Worked Example: The Candle Brand's Switch, Fully Costed

Return to the candle brand from Module 1, shipping 400 orders a month. Current true cost per order was $2.84. The proposed pack is:

| Item | Current | Proposed |
|---|---|---|
| Box (smaller, recycled-content) | $0.85 | $0.72 |
| Wrap (bubble wrap to honeycomb paper) | $0.22 | $0.28 |
| Tissue (two sheets to one) | $0.08 | $0.04 |
| Poly bag | $0.06 | $0.00 (removed) |
| Tape (plastic to paper) | $0.04 | $0.07 |
| Thank-you card | $0.12 | $0.12 |
| Shipping label | $0.03 | $0.03 |
| **Materials subtotal** | **$1.40** | **$1.26** |
| Damage/replacements per order | $0.24 | $0.24 (assumed unchanged) |
| Packing labour (4 min to 3.5 min) | $1.20 | $1.05 |
| **True cost per order** | **$2.84** | **$2.55** |

The switch saves $0.29 per order, or $116 a month at 400 orders. The saving comes from the smaller box and the removed poly bag outweighing the more expensive paper wrap and tape, plus a small labour saving because the honeycomb wrap is faster to use than cutting bubble wrap to size. Notice that the "sustainable" materials individually cost more — paper wrap at $0.28 against bubble wrap at $0.22, paper tape at $0.07 against plastic at $0.04 — but the pack as a system costs less. That is why you cost the whole pack, never a single item.

### Worked Example 2: A Switch That Costs More — and Is Still Worth Doing

Not every switch saves money. Consider an apparel brand shipping 600 orders a month, switching from a poly mailer to a paper mailer and from plastic tape to paper tape, with no other changes:

| | Current | Proposed |
|---|---|---|
| Mailer | $0.22 | $0.55 |
| Tape | $0.04 | $0.07 |
| Label, card | $0.15 | $0.15 |
| Materials subtotal | $0.41 | $0.77 |
| Damage per order | $0.05 | $0.05 |
| Packing labour | $0.60 | $0.60 |
| Shipping | $4.20 | $4.20 |
| **Total per order** | **$5.26** | **$5.62** |

The increase is $0.36 per order, or $216 a month. The brand's average order value is $52, so the increase is 0.7 percent of order value. The brand has three honest options: absorb it, raise prices by a small amount, or find a saving elsewhere in the pack (for example, removing a second insert worth $0.10, which would cut the increase to $0.26). What the brand should not do is pretend the increase does not exist, or raise prices by $2 "to cover eco packaging" when the real cost is $0.36. Customers notice inflated justifications, and they remember them.

### Calculation 2: Break-Even on One-Off Switching Costs

Some switches carry one-off costs: a custom dieline fee, a print plate or setup fee, a tape dispenser, new box sizes that require a first bulk order, or a designer's fee for new artwork. Add up all one-off costs, then divide by the saving per order (if the switch saves money) to find how many orders it takes to pay for itself:

**Break-even orders = one-off switching cost ÷ saving per order**

Worked example: the candle brand's switch needs a $180 custom dieline and print setup, a $45 tape dispenser, and $60 of samples — $285 in one-off costs. The saving is $0.29 per order. Break-even is $285 ÷ $0.29 = 983 orders. At 400 orders a month, that is about two and a half months. After that, the saving is pure margin improvement. If the saving per order were only $0.05, break-even would be 5,700 orders — over a year at the same volume — and the brand would need to think carefully about whether the switch is worth it on money alone, or whether the customer and brand reasons carry it.

If the switch costs more per order rather than saving money, there is no break-even in the usual sense. Instead, calculate the annual cost of the switch (extra cost per order × orders per year) and decide whether that amount is a marketing and brand investment you are willing to make. For the apparel brand above, $216 a month is $2,592 a year. Is that a reasonable amount to spend on packaging that matches your brand values and answers a known customer complaint? For some brands, yes. For others, the answer is to switch a cheaper item first and revisit the mailer when volumes rise and unit prices fall. Either answer is legitimate, as long as it is made with the number in front of you.

### Calculation 3: Margin Effect

Your packaging cost is part of your cost of goods sold for practical purposes, even if your accountant treats it separately. Check the effect of the switch on your margin per order:

**Margin per order = order value − product cost − packaging total per order − shipping − platform and payment fees**

Run this for your average order before and after the switch. A $0.29 saving on a $35 order with a $12 margin improves the margin by 2.4 percent. A $0.36 increase on a $52 order with a $20 margin reduces it by 1.8 percent. Small numbers, but they compound across hundreds of orders, and they are the numbers that tell you whether you need to adjust pricing.

### When to Raise Prices — and When Not To

Do not raise prices automatically because your packaging changed. Raise prices when the switch makes your per-order cost rise enough to matter to your margin and you cannot find an offsetting saving, or when you are raising prices anyway for other reasons and the packaging improvement is part of the value you are communicating. If you do raise prices, be honest about it in general terms — "we have invested in better packaging" — and do not claim the price rise is entirely caused by packaging if it is not. A $0.36 cost increase does not justify a $2 price rise, and customers who work that out will not trust the next claim you make.

### A Note on Volume Pricing

Unit prices for packaging fall as volume rises, sometimes sharply. A paper mailer that costs $0.55 at 500 units might cost $0.42 at 2,000 units. That means a switch that looks expensive at your current volume may become affordable as you grow. When you get quotes, always ask for the price at your current volume and at the next tier up, and note the tier in the supplier directory. Revisit the maths every six months or whenever your order volume changes significantly. A switch you rejected in January may be the right switch in September.

### Module 5 Actions

1. Complete the packaging cost calculator for your first switch, using real quotes and your real shipping rates.
2. Calculate the break-even on any one-off switching costs.
3. Run the margin effect on your average order, before and after.
4. Decide, in writing: absorb the cost, offset it with a saving elsewhere, or adjust pricing — and by how much.
5. File the calculator with the date and the quotes used, so you can revisit it in six months.

---

## Module 6: Roll Out the Switch Without Disrupting Orders

A good plan fails if the rollout is chaotic. This module is a practical rollout sequence: test with a small batch, tell your customers, manage the old stock, and measure what happens.

### Phase 1: Pilot (Weeks 1–2)

Ship the new packaging to a small group first — 50 to 100 orders, or one product line for two weeks. Choose orders you can follow up on: repeat customers, customers in your home market, or orders you can track closely. During the pilot:

- Pack the new way and time it. Is packing faster, slower, or the same? If it is slower, find out why before you scale — a packing step that takes an extra minute per order costs real money at volume.
- Check every pilot parcel on arrival if you can. Ask a few customers directly whether the parcel arrived in good condition and what they thought of the packaging. A short message — "We have changed our packaging and would love to know what you thought when it arrived" — will get you honest answers.
- Watch your damage and return rate for the pilot orders specifically. One damaged pilot parcel in 50 is a 2 percent rate; compare that with your normal rate before drawing conclusions, but do not ignore it.
- Keep the old packaging on hand. If the pilot reveals a problem, you need to be able to switch back the same day.

### Phase 2: Tell Your Customers Before They Notice

Customers notice packaging changes, and they will form their own explanation if you do not give them one. Tell them before the new packaging starts arriving, in the place they will see it: your order confirmation email, your website's shipping or sustainability page, and one social post.

Keep the message short and specific. Say what changed, what it is made of, and how to dispose of it. For example: "Your order now arrives in a paper mailer made from 100% recycled paper. Please recycle it with your paper recycling." That is a complete message. Do not write a long essay about your sustainability journey; customers want to know what to do with the box, not read your mission statement.

If you are phasing the change in — new packaging for one product line now, the rest later — say so: "We are switching our packaging product by product. Your order may arrive in our new paper packaging or our previous packaging while we use up existing stock." Customers accept a transition when you tell them about it. They are less forgiving when they receive something different from what the website promised with no explanation.

### Phase 3: Manage Old Stock Honestly

You will have old packaging left over. Do not throw it away to make the switch look cleaner — that creates the waste the switch was meant to reduce. Use up existing stock on the product lines you have not switched yet, or on orders where the old pack is still the right choice. If you have a large quantity of old stock that you cannot use, consider whether it can be reused, recycled, or donated to another small business. Only dispose of it as a last resort, and record what you did — it is part of your own honest account of the switch.

Similarly, do not order a huge quantity of the new packaging on the first order. Order enough for the pilot and the first month of full rollout. You may discover a sizing problem, a print error, or a customer reaction that changes your specification. A smaller first order costs slightly more per unit and saves you from being stuck with a thousand units of the wrong box.

### Phase 4: Full Rollout (Weeks 3–6)

Once the pilot has run for two weeks with no increase in damage and no packing problems, roll the new packaging out to the full product line. Update your packing guide, your size guide, and any instructions at the packing bench. If you use a fulfilment centre or a third-party logistics provider, send them the new specification in writing, with photos of a correctly packed parcel, and confirm they have the new materials in stock before the first order goes out under the new system. A fulfilment partner who is still using the old pack because nobody told them is a common and avoidable failure.

During rollout, keep a simple log: date, product line, number of orders shipped in new packaging, damage reports, and any customer comments about packaging. One line per week is enough. This log is your evidence base for Module 7, and it is what you will use to decide whether to extend the switch to the next product line.

### Phase 5: Measure for 30 Days, Then Decide

Thirty days after full rollout, compare the new reality with the numbers you calculated in Module 5:

- Actual materials cost per order (from invoices, not quotes).
- Actual packing time per order.
- Actual damage and return rate.
- Actual shipping cost per order.
- Customer feedback: complaints, compliments, and silence.

If the numbers match your calculation within a small margin, the switch is a success — extend it to the next product line. If damage has risen, stop and fix the protection before extending anything. If packing time has risen sharply, look for the cause: a fiddly fold, a tape that does not stick, a box that needs two people to close. If the cost is higher than expected, check whether you are using more material than the specification calls for — overpacking with a new material is a common habit in the first weeks.

### Worked Example: A Rollout Timeline

A homeware brand selling 300 orders a month plans a switch from plastic bubble wrap to honeycomb paper wrap and from plastic tape to paper tape:

- **Week 1:** Samples arrive; drop test and pack test completed; supplier chosen; first order of 500 units placed.
- **Week 2:** Pilot — 60 orders shipped in new packaging; packing time measured at 3 minutes per order against 3.5 minutes before; one customer mentions the new wrap positively; no damage.
- **Week 3:** Customer message sent (email and one social post); packing guide updated; full rollout to the hero product line.
- **Week 4:** Old bubble wrap stock used up on the remaining product lines; new wrap ordered for the second line.
- **Week 6:** 30-day review — materials cost per order up $0.09, packing time down, damage unchanged, three positive customer comments, no complaints. Decision: extend to all product lines.

Total elapsed time: six weeks. Total disruption: none, because the pilot caught the only problem (the first batch of paper tape did not stick well in a cold warehouse, and the brand switched to a different adhesive before full rollout).

### Module 6 Actions

1. Write your rollout plan using the Switch Rollout Plan worksheet in the workbook: pilot size, dates, who is responsible, and what success looks like.
2. Draft the customer message (email, website note, and one social post) before the first pilot parcel ships.
3. Plan how you will use up old stock.
4. Brief your packer or fulfilment partner in writing, with photos of a correctly packed parcel.
5. Set a date 30 days after full rollout for the review, and put it in your calendar now.


---

## Module 7: Stay Compliant, Tell the Truth, and Keep Improving

The switch is done, but the work is not. Packaging rules change, suppliers change their materials, and customers keep paying attention. This module covers the three ongoing jobs: staying compliant, communicating honestly, and improving over time.

### Know Which Rules Apply to You

Packaging regulation is genuinely local and genuinely changing. The rules that may apply to you depend on where your business is based, where your customers are, what you sell, and what your packaging is made of. This programme cannot list every rule, because the list would be out of date before you read it. Instead, here are the areas to check, and how to check them:

- **Extended producer responsibility (EPR).** In many countries and US states, producers of packaging must register, report the packaging they place on the market, and pay fees toward its collection and recycling. The EU's Packaging and Packaging Waste Regulation, the UK's EPR for packaging, and a growing number of US state EPR laws (including California, Oregon, Colorado, and Minnesota, among others) all work on this principle, but the thresholds, the registration process, and the fees differ. Check whether your business meets the threshold in each place you sell. If you sell through a marketplace, check whether the marketplace handles any part of the obligation for you — and do not assume it does.
- **Plastic taxes and bans.** Several jurisdictions tax certain plastic packaging or ban specific single-use plastic items. The UK's Plastic Packaging Tax, for example, applies to plastic packaging with less than 30 percent recycled content. The details, rates, and thresholds change, so verify the current position for your market before relying on this programme's summary.
- **Recycling and disposal labelling.** Some places require or standardise how you label packaging for disposal. The EU requires specific sorting information in some member states; US states have their own rules about the use of the chasing-arrows symbol and the word "recyclable." Check the rules in your main markets before printing a label claim.
- **Product-specific rules.** Food, cosmetics, and children's products have additional packaging rules — for example, around materials that contact food or skin, and around child-resistant or tamper-evident packaging. If you sell in one of these categories, check the product-specific rules as well as the general packaging rules.
- **Advertising and green claims.** Regulators in the US (the FTC's Green Guides), the UK (the ASA and the CMA's Green Claims Code), and the EU (the proposed Green Claims Directive and the existing Unfair Commercial Practices Directive) all restrict vague or unsubstantiated environmental claims. The common thread is simple: a claim must be true, specific, substantiated, and not misleading by omission. If a claim needs a qualification to be true, include the qualification.

Use the compliance checklist in the templates folder (`compliance-checklist.md`) as a starting point. It is a checklist for your own review, not a legal document. If you are unsure whether a rule applies to you, speak to a local business adviser or a lawyer who works with small e-commerce brands. A one-hour consultation is cheaper than a fine or a forced recall of printed packaging.

### Keep Evidence for Every Claim

For each environmental claim you make — on packaging, on your website, in advertising — keep a file with the evidence behind it. The file should contain: the supplier's written statement or certificate, the date it was issued, the product it covers, and any conditions (for example, "commercially compostable to EN 13432"). Review the file once a year, or whenever you change supplier, material, or printer. Certificates expire, suppliers change their sourcing, and a claim that was true last year may not be true this year.

If a customer or a regulator asks you to substantiate a claim, you should be able to produce the evidence within days, not weeks. Brands that cannot produce evidence quickly are the ones that get into trouble — even when the claim itself was true.

### Tell the Truth on Your Website

Your website's shipping or sustainability page is where interested customers will look. Write it in the same specific style as your packaging claims. A good page answers four questions:

1. What is your packaging made of?
2. How should the customer dispose of each part?
3. What are you still working on? (Honesty about the work in progress builds more trust than a claim of perfection.)
4. Where can the customer ask a question?

A page that says "We are working toward plastic-free packaging. Our boxes are 100% recycled cardboard and our mailers are paper. We still use a small amount of plastic tape on some orders while we complete the switch, and we will update this page when that changes." is far more credible than a page that says "100% eco-friendly packaging" while the tape is still plastic. Customers respect a brand that is honest about the gap between where it is and where it wants to be.

### Keep Improving: The Annual Review

Once a year, repeat a short version of the audit from Module 1: list your packaging items and costs, weigh five orders, check your damage rate, and read your customer feedback. Ask three questions:

- Is there a material we can now afford, because volumes have risen or prices have fallen, that we could not afford last year?
- Is there an item we can remove entirely?
- Is there a claim on our packaging that needs updating because the material, the supplier, or the rules have changed?

Small, regular improvements beat a single large switch followed by years of standing still. Packaging suppliers introduce new materials every year, prices move, and your product range changes. An annual review keeps your packaging current without a major project.

### What to Do When Something Goes Wrong

If a customer reports damage that your new packaging should have prevented, treat it as data, not as a complaint to be managed away. Ask for a photo of the damaged parcel, check whether the packing followed the specification, and check whether the damage pattern suggests a protection problem or a carrier handling problem. If two or three customers report the same failure, pause the rollout for that product and re-test. A quick, honest response — replacing the product and fixing the packaging — costs less than the reputation cost of shipping a known problem.

If you discover that a claim on your packaging is wrong — for example, a supplier tells you the recycled content is 70 percent, not the 100 percent you printed — stop using the claim immediately. Do not use up the printed stock "because it is already paid for." The cost of reprinting is small compared with the cost of a misleading claim. Tell your customers if the error was visible to them; a short correction is remembered far more kindly than a discovered deception.

### Your Outcome

If you have worked through all seven modules, you now have: a measured audit of what you shipped; a working knowledge of the materials that suit your products; a right-sized, protective pack design; a vetted supplier and a backup; a costed decision with a break-even; a rollout that your customers were told about; and a compliance file you can defend. That is the whole programme, and it is also the whole job: measure, choose, cost, test, tell, and keep checking.

The next step is the second switch. Use the same process, the same worksheets, and the same honesty. Each switch gets easier, because you already have the audit, the supplier relationships, and the customer trust from the first one.

### Module 7 Actions

1. Complete the compliance checklist for your main markets, and note the date and the sources you checked.
2. Create a claims evidence file — one folder, one file per claim, with the supplier's written evidence.
3. Write or update your website's packaging page, answering the four questions in this module.
4. Put the annual packaging review in your calendar, twelve months from your rollout date.
5. Choose your second switch, and start its audit.

---

## Appendix A: Glossary of Packaging Terms

- **Board grade:** The strength and weight of corrugated board, usually expressed as a flute type (for example, B-flute, C-flute, E-flute) and a bursting or edge-crush test value. Heavier grades protect more and cost more.
- **Dieline:** The flat cutting and folding template for a box or carton, showing dimensions, fold lines, cut lines, and glue areas.
- **Dimensional weight (dim weight):** A carrier pricing method based on the parcel's volume rather than its actual weight. A large, light parcel can be charged as if it were heavier.
- **Double-wall board:** Corrugated board with two fluted layers, used for heavier or more fragile items.
- **EPR (extended producer responsibility):** A policy approach that makes producers responsible for the collection, recycling, or disposal of the packaging they place on the market, usually through registration and fees.
- **FSC (Forest Stewardship Council):** A certification system for paper and board from responsibly managed forests or recycled sources.
- **Honeycomb paper wrap:** Paper that expands into a hexagonal mesh when stretched, used as a cushioning wrap in place of bubble wrap.
- **Landed cost:** The full cost of getting a product to you, including the product price, freight, duties, taxes, and handling.
- **Moulded fibre (moulded pulp):** Packaging shaped from recycled paper pulp, used as trays and inserts.
- **Post-consumer recycled content:** Material made from products that were used by consumers and then recycled, as distinct from pre-consumer (manufacturing) waste.
- **RSC (regular slotted container):** The standard box style with four flaps on the top and bottom.
- **Void fill:** Material used to fill empty space inside a parcel so the product does not move.
- **Water-activated tape:** Kraft paper tape with a starch-based adhesive that is activated with water. It bonds to cardboard and is recyclable with the box in many systems.

---

## Appendix B: Your 90-Day Switch Plan at a Glance

| Weeks | Focus | Key outputs |
|---|---|---|
| 1–2 | Audit (Module 1) | Packaging audit, true per-order cost, first switch chosen |
| 3–4 | Materials and design (Modules 2–3) | Materials shortlist, right-sized pack, drop test passed |
| 5–6 | Suppliers and money (Modules 4–5) | Supplier chosen, samples tested, costed decision, break-even |
| 7–8 | Pilot (Module 6) | 50–100 pilot orders shipped, customer message sent |
| 9–10 | Full rollout (Module 6) | Full product line switched, packing guide updated |
| 11–12 | Review (Modules 6–7) | 30-day review, compliance checklist, second switch chosen |

If your timeline slips, let it slip rather than skipping the pilot or the drop test. A switch that takes twelve weeks and works is better than a switch that takes four weeks and breaks products.

---

*End of programme. The companion workbook, templates, and calculator are in the same product folder. This programme is for education and general information only; verify current regulations and supplier claims for your own business before acting.*
