# The Wholesaling Fast-Start Academy

## Your First Real Estate Deal With Little or No Capital — Find Sellers, Contract Deals, Assign to Buyers

**By the EightyTwenty Marketplace — Real Estate Education Series**

---

## Important Disclaimer — Please Read First

This course is **real estate education only**. It is not individualized legal, investment, financial, or tax advice, and it does not create an attorney–client relationship or any other professional relationship. Real estate wholesaling is regulated differently from state to state, and several states changed their wholesaling rules in 2024, 2025, and 2026. Some states now require a real estate license to wholesale, some require specific disclosures, and some restrict how contracts may be assigned or marketed.

**You must verify the current law in your state — and in the state where any property is located — and consult a licensed local real estate attorney before you make an offer, sign a contract, market a property, or assign a contract.** Do not rely on this course, on a template, on a video, or on what another wholesaler told you as a substitute for that advice. Laws change, and this course cannot keep up with every change in every state in real time.

No income is guaranteed. The examples in this course use real arithmetic but hypothetical properties. Your results will depend on your market, your effort, your skills, your compliance with the law, and factors outside your control. Most beginners do not close a deal in their first 30 days. Some never close one. Treat every number in this course as an illustration of a method, not a promise.

All names of sellers, buyers, and properties in the worked examples are fictional. Any resemblance to a real person or property is coincidental.

---

## How to Use This Course

This is a complete course manual. It is written to be read in order the first time, because each module builds on the one before it. Modules 1–3 are the foundation: what wholesaling is, how the money works, and the legal landscape. Do not skip them. A beginner who skips the legal module and starts calling sellers is the beginner most likely to get into trouble.

After your first read-through, use this manual as a reference. Keep the workbook open beside it. Work the numbers on every deal with the deal-analysis worksheet before you make an offer. Use the scripts in the templates folder as a starting point — adapt them to your voice, your market, and your attorney's guidance, and never read a script word for word in a way that sounds like you are reading.

A suggested pace: one module a day for two weeks, with the action steps at the end of each module completed before you move on. Module 13 gives you a dated 30/60/90-day plan. Module 14 is the list of mistakes that cost beginners the most money and credibility — read it before your first call, and read it again after your first month.

You will need, in addition to this course: a phone, a way to take notes and track deals (the deal tracker spreadsheet is included), access to public property records or a comparable data source in your market, and a local real estate attorney you can call with questions. You do not need a real estate license to *learn* wholesaling, but you may need one — or a different structure entirely — to *do* it legally in your state. That is exactly what Module 3 and the state-rules research checklist in the workbook are for.

---

## Table of Contents

- Module 1 — What Wholesaling Really Is — and What It Is Not
- Module 2 — How the Money Is Made: Assignment Fees, Double Closings, and Realistic Fee Ranges
- Module 3 — The Legal Landscape: Licensing, State Rules That Changed in 2024–2026, and Why You Must Check Your State and Consult a Local Attorney
- Module 4 — Finding Motivated Sellers: Driving for Dollars, Lists, and Direct Mail
- Module 5 — Cold Calling and Texting Sellers: What to Say and What Not to Say
- Module 6 — Analyzing a Wholesale Deal: ARV, Repairs, MAO Formula with Worked Examples
- Module 7 — Making an Offer and Getting a Contract Signed
- Module 8 — Assignment Contracts and Disclosures Explained
- Module 9 — Building a Cash-Buyers List from Zero
- Module 10 — Showing the Deal and Closing the Assignment
- Module 11 — Double Closings When Assignment Is Not Allowed
- Module 12 — Tracking Deals and Following Up
- Module 13 — Your First 30/60/90 Days: A Dated Launch Plan
- Module 14 — Common Mistakes and How to Avoid Them
- Appendix A — State-by-State Legal Awareness Guide
- Appendix B — Glossary
- Appendix C — Resources and Next Steps

---

# Module 1 — What Wholesaling Really Is — and What It Is Not

Wholesaling real estate means finding a property owner who wants to sell quickly, putting that property under contract at a price below what an investor would pay for it, and then transferring your rights under that contract to an investor buyer for a fee — or, in some cases, buying and reselling the property yourself in a double closing. You do not renovate the property. You do not become the landlord. In an assignment, you never own the property at all. What you own, briefly, is a contract.

That distinction matters more than anything else in this course, because it is the source of both the opportunity and the legal risk. A wholesaler is not a real estate agent, not a buyer in the ordinary sense, and not a flipper. A wholesaler is a person who finds a deal, controls it by contract, and passes that control to someone else for a fee.

Here is the shape of a typical assignment deal, in plain language:

1. You find a homeowner who is motivated to sell — perhaps the house needs repairs they cannot afford, they inherited a property they do not want, they are behind on payments, they are relocating, or they are simply tired of owning it.
2. You agree on a price and sign a purchase contract with the seller. That contract gives you the right — and, in most forms, the obligation — to buy the property by a certain date, usually 30 to 45 days out.
3. You find an investor buyer who wants the property at a higher price than your contract price, because the buyer can renovate it and resell it, or rent it, at a profit.
4. You assign your contract to that buyer for a fee. The buyer steps into your place in the contract, closes with the seller, and pays you the assignment fee at closing.

The seller gets a fast, certain sale. The buyer gets a property at a discount. You get paid for finding the deal and putting it together. That is the model when it works well and legally.

Now, what wholesaling is not:

**It is not buying a house with no money and keeping it.** An assignment does not give you a house. It gives you a fee. If you want to own property, wholesaling is a way to build capital and experience toward that goal — it is not ownership itself.

**It is not a license to sell other people's houses.** In many states, marketing a property you do not own, for a fee, is the work of a licensed real estate agent. Wholesalers who advertise "3-bedroom house for sale, $150,000" when they do not own the house and have no license are the wholesalers who attract regulator attention. There is a legal difference — in many states, a decisive one — between marketing *your interest in a contract* and marketing *someone else's property*. Module 3 and Module 8 explain this distinction, and your attorney will tell you how your state draws the line. Do not assume the line is the same everywhere.

**It is not risk-free.** A contract is a legal commitment. If you sign a purchase contract and cannot find a buyer, you may be obligated to close, or you may lose an earnest-money deposit, or you may face a claim from the seller. Some contracts include an inspection or due-diligence period that lets you cancel within a defined window; some do not. You must understand the contract you are signing, clause by clause, before you sign it — and your attorney should review the form you plan to use.

**It is not a get-rich-quick scheme.** The honest version of wholesaling is a sales and marketing business. You will talk to many sellers to find one deal. You will make offers that are rejected. You will spend money on lists, mail, or phone time before you earn a fee. A realistic first-year goal for a part-time beginner who works consistently is one to three closed assignments, not ten. Anyone who promises you a specific income from wholesaling is selling you something, not teaching you.

**It is not the same as flipping.** A flipper buys a property, renovates it, and resells it. A wholesaler in an assignment never buys it. A double closing, covered in Module 11, is closer to flipping in form — you do briefly own the property — but the intent, the holding time, and the financing are different.

**It is not "no capital required" in the absolute sense.** You can start with very little money compared with buying a rental property, and that is the real appeal. But you will still need money for marketing, for gas, for a phone, for an earnest-money deposit on at least some deals, and possibly for a double closing. "Little or no capital" means you do not need a down payment and a mortgage. It does not mean the business is free to run.

### The three skills wholesaling actually rewards

Strip away the marketing language and wholesaling rewards three skills: finding motivated sellers, analyzing a deal accurately, and building trust with buyers. Finding sellers is a volume and consistency skill. Analyzing deals is an arithmetic and judgment skill — this course spends a full module on it, because getting the numbers wrong is how beginners lose money and credibility. Building trust with buyers is a reputation skill, and it is the slowest to build and the fastest to lose. One bad deal — a property whose repair estimate was half the real cost, a contract you could not close — can cost you a buyer relationship that took months to build.

### A realistic picture of the work

A working wholesaler's week looks ordinary: driving neighborhoods and noting distressed properties, pulling lists, sending mail, calling sellers, walking properties, running numbers, talking to buyers, following up on old leads, and tracking everything. The glamorous version — a single phone call and a $10,000 check — happens, but it happens after dozens of unglamorous hours. If you enjoy talking to people, solving problems, and working a pipeline, you may enjoy this business. If you are looking for passive income, this is not it. Wholesaling is active income, earned deal by deal.

### Action Steps — Module 1

1. Write down, in one paragraph, why you want to wholesale. Keep it somewhere you will see it when the work gets tedious.
2. Write down how many hours per week you can realistically commit for the next 90 days. Be honest — 5 real hours beats 20 imagined ones.
3. Decide your starting budget for marketing for the next 90 days, even if it is small. Write the number down.
4. Find and note the name and phone number of one local real estate attorney you can call. You do not need to hire them today; you need to know who to call before you sign anything.
5. Read Module 2 before you talk to any seller.

---

# Module 2 — How the Money Is Made: Assignment Fees, Double Closings, and Realistic Fee Ranges

There are two ways a wholesaler gets paid: an assignment fee, and the spread in a double closing. They are different mechanisms, they carry different costs and risks, and they are not interchangeable. Understand both before you need either.

## The assignment fee

In an assignment, you sell your *position* in the purchase contract to an investor buyer. The buyer pays you a fee for stepping into your place. The seller still sells at the price you agreed with them. The buyer still buys at the price you agreed with them, plus your fee. The fee is the difference between your contract price with the seller and the price the buyer pays in total — and it is documented in an assignment agreement.

### Worked example — a $10,000 assignment fee

- You contract to buy a house from the seller for **$115,000**.
- You assign the contract to an investor buyer for **$125,000** in total.
- Your assignment fee is **$125,000 − $115,000 = $10,000**.
- At closing, the seller receives $115,000 (less any liens, taxes, and closing costs they owe), the buyer pays $125,000 (plus their own closing costs), and you receive $10,000.

The buyer agrees to this because $125,000 is still a good price for them. That is the test that matters: the deal must work for the buyer *after* your fee. If the buyer's all-in cost leaves no profit after renovation and resale, there is no deal, no matter how good your fee looks on paper.

### Realistic fee ranges

Assignment fees vary widely by market, property price, and the size of the discount you negotiated. Honest ranges, based on the structure of the business rather than any promise:

- **Low-price markets / smaller discounts:** $3,000–$5,000 per deal is common. On a $60,000 contract, a $5,000 fee is a large percentage, and buyers will scrutinize it.
- **Mid-range deals:** $5,000–$15,000 per deal is the range most working wholesalers describe for ordinary single-family houses.
- **Larger discounts / higher-price markets:** $15,000–$30,000+ is possible when the discount is deep and the property is expensive — but these are less frequent, and they attract more scrutiny from buyers, sellers, and regulators.

A beginner should plan on the lower end. Your first fees will probably be $3,000–$7,000, if you close at all. Budget and expectations should be built on that, not on the largest fee you have heard about. One $5,000 fee you actually collect is worth more than a $25,000 fee on a deal that falls apart.

### What the fee has to cover

Your fee is gross revenue, not profit. From it, you have already spent — or will spend — money on marketing, driving, phone service, list data, and your time. If you spent $1,500 on direct mail over three months to get one $7,000 assignment, your net before taxes is $5,500, not $7,000. Track marketing spend per deal, not just fees. Module 12 covers this.

## The double closing

In a double closing, you actually buy the property from the seller and then immediately sell it to your end buyer — two closings, usually on the same day, at the same title company. You briefly own the property. Your profit is the difference between your purchase price and your sale price, less the closing costs of *both* transactions.

### Worked example — a double closing

- You contract to buy from the seller for **$115,000**.
- You contract to sell to the investor buyer for **$128,000**.
- Your gross spread is **$13,000**.
- Your closing costs on the purchase might be roughly $1,500–$2,500 (title, recording, and related fees vary by state). Your closing costs on the sale might be roughly $1,000–$2,000. Using $2,000 and $1,500 as illustrations: total closing costs $3,500.
- Your net before taxes is roughly **$13,000 − $3,500 = $9,500**.

Notice that the double closing cost you about $3,500 that an assignment would not have, and it required you to fund the purchase — usually with transactional funding, which is a short-term loan for the purchase that is repaid the same day from the sale proceeds. Transactional funding typically costs 1–3% of the purchase price plus fees, which on $115,000 is $1,150–$3,450. That cost comes out of your spread too.

Why would anyone choose a double closing, given the extra cost? Two main reasons: (1) assignment is restricted or not permitted in that state or under that contract, and (2) the fee is large enough that the wholesaler does not want the seller or the buyer to see it on a single settlement statement. A double closing keeps the two prices on separate statements. That privacy has a price — the second set of closing costs and the funding cost — and it does not make an unlawful deal lawful. If assignment is restricted in your state, a double closing is a *different structure* to discuss with your attorney, not a loophole to assume.

## How buyers judge whether your fee is fair

Investor buyers run their own numbers. They will pay your fee if the deal still works for them. The formula they use is essentially the same one you will learn in Module 6: the after-repair value (ARV), minus repair costs, minus their profit margin, minus holding and selling costs, equals the most they can pay. Your contract price plus your fee must come in under that number, with room to spare. If you bring a buyer a deal where their margin is $2,000 after your $15,000 fee, they will not buy it — and they will remember that you brought it.

A useful rule for beginners: leave the buyer at least as much profit as your fee, and preferably more. If your fee is $10,000, the buyer should be able to make $10,000 or more after all their costs. That is not a law; it is a reputation rule. Buyers who make money on your deals come back. Buyers who lose money on your deals do not.

## When you get paid — and when you do not

In an assignment, you are generally paid at closing, when the buyer closes with the seller. You do not get paid when the seller signs, when the buyer says yes, or when the assignment agreement is signed. Until closing, the fee is an expectation, not income. Deals fall apart between assignment and closing: the buyer's financing fails, the title search finds a lien, the inspection finds a foundation problem, the seller changes their mind. Budget as if every fee is uncertain until the money is in your account.

You should also understand earnest money. Many purchase contracts require the buyer — you — to put down an earnest-money deposit, often $500–$2,000 on a wholesale deal, sometimes more. If you cancel within a contractual inspection or due-diligence period, you may get it back. If you cancel after that period, or for a reason the contract does not allow, you may lose it. Never sign a contract without knowing the earnest-money terms and the cancellation terms, and never promise a seller a deposit you cannot afford to lose.

## A note on "no money down" claims

You will see wholesaling advertised as "no money down" and "no credit needed." The honest version is: you do not need a mortgage or a large down payment, and your credit score is generally not a factor in an assignment, because you are not borrowing to buy the house. But you do need money to operate — marketing, deposits, and possibly funding costs. Treat any claim that you can build this business with literally zero dollars as marketing, not fact.

### Action Steps — Module 2

1. Work the $115,000 / $125,000 assignment example by hand. Change the contract price to $100,000 and the buyer price to $108,000. What is the fee? (Answer: $8,000.)
2. Work the double-closing example with a $120,000 purchase and a $132,000 sale, with $3,000 in total closing costs. What is the net before funding and taxes? (Answer: $9,000.)
3. Write down the minimum fee that would make a deal worth your time, given your marketing costs. This is your personal floor — do not chase deals below it.
4. Decide, for now, that you will pursue assignments first and treat double closings as a structure to discuss with your attorney only when assignment is not available.

---

# Module 3 — The Legal Landscape: Licensing, State Rules That Changed in 2024–2026, and Why You Must Check Your State and Consult a Local Attorney

This is the most important module in the course. Read it twice. The difference between a legal wholesale deal and an unlawful one is often a single fact: your state, the words you used, or the form you signed. This module gives you awareness, not answers. The answers come from your state's current law and from a licensed attorney in your state.

## Why wholesaling is regulated at all

Real estate brokerage — helping someone buy or sell property for a fee — is a licensed activity in every state. The license exists to protect the public: agents are tested, background-checked, supervised, and subject to discipline. When an unlicensed person does the work of an agent, regulators see a risk to sellers, especially distressed sellers who may not understand what they are signing.

Wholesaling sits close to that line. You are not, in an assignment, selling the seller's house for them in the traditional sense — you are selling your own contractual interest. But from the seller's point of view, a stranger found their house, negotiated a price, and got paid when it sold. From a regulator's point of view, that can look like unlicensed brokerage, especially if you marketed the *property* rather than your *contract*, or if you did it repeatedly as a business.

Different states have resolved this tension differently, and several changed their answer in 2024, 2025, and 2026. That is why a course written even two years ago can be out of date on this point, and why you must verify current law.

## The three legal questions that matter most

Every wholesaler needs a clear, attorney-confirmed answer to three questions in each state where they operate:

**1. Do I need a real estate license to wholesale here?** In some states, the answer is effectively yes for most wholesaling activity — either because the statute now says so directly, or because the way wholesaling is usually done (marketing properties, negotiating for others) requires a license. In other states, an assignment of your own contract is treated as selling your own interest and does not require a license, as long as you stay within defined limits. In still others, the answer is genuinely unclear, which is itself a risk. Do not guess. Ask your attorney, in writing if possible, and keep the answer with your records.

**2. What disclosures must I make to the seller and the buyer?** Some states now require a wholesaler to disclose, in writing, that they are not the end buyer, that they intend to assign the contract for a fee, and what that fee is (or how it is calculated). Some require the disclosure before the seller signs. Some require it in a specific form or type size. A disclosure you make late, or verbally instead of in writing, may not satisfy the law. Your attorney should give you the exact disclosure language for your state, and you should use it verbatim.

**3. How may I market the deal?** In many states, the critical distinction is between marketing your *equitable interest in a contract* ("I have a property under contract and I am selling my interest in that contract") and marketing the *property itself* ("3-bed house for sale"). The first is, in many states, permissible for a contract holder; the second is, in many states, brokerage. Some states have gone further and restricted even marketing your contract interest unless you are licensed, or restricted advertising a property you do not own in any form. Your marketing — every flyer, post, text, and listing — must match what your state allows. When in doubt, market less, not more, and ask your attorney first.

## What changed in 2024–2026

Several states tightened their wholesaling rules in 2024, 2025, and 2026. The changes generally moved in the same direction: more disclosure, more licensing, and less room for unlicensed marketing of properties. The details differ by state — the exact statute, the effective date, the penalties, and the exemptions are all state-specific, and some rules are still being interpreted by courts and regulators. Appendix A lists the states that have notably stricter rules and describes the *kind* of restriction involved, so you know where to look. It does not state the current law of any state, because that can change and because only your attorney can apply the law to your situation.

What you should take from this section is a habit, not a list: before you operate in a state, check that state's current wholesaling statute and any regulator guidance, and confirm your understanding with a local attorney. Repeat that check at least once a year, and again before any deal in a state you have not worked in before. Treat "I read it in a course" as the beginning of your research, never the end of it.

## Other legal issues that catch beginners

**Contracts.** Your purchase contract and your assignment agreement are legal documents. The clauses that matter most — assignability, inspection and due-diligence periods, earnest money, closing date, and what happens if you cannot close — must be understood before you sign. A contract that says "this contract may not be assigned" and an assignment you sign anyway is a problem. A contract with no inspection period and a $2,000 deposit is a different risk than a contract with a 14-day inspection period and a $500 deposit. Have your attorney review the forms you plan to use, and do not use a form you found online without that review.

**Advertising and solicitation.** Cold calling and texting are regulated by federal law (including the Telephone Consumer Protection Act) and by state laws, and by the Do Not Call Registry. Calling a number on the Do Not Call list, or texting someone who has not consented, can result in fines that dwarf any assignment fee. Module 5 covers the practical rules; your attorney and a basic compliance check should come first. Never buy a list and start dialing without checking whether the numbers are scrubbed against the Do Not Call list and whether you have a lawful basis to contact them.

**Fair housing.** Federal and state fair housing laws prohibit discrimination in housing transactions on the basis of race, color, religion, sex, national origin, familial status, disability, and other protected classes that vary by state. Your marketing, your seller selection, and your buyer selection must not discriminate. Targeting or avoiding neighborhoods on the basis of who lives there is not a marketing strategy; it is a legal risk.

**Distressed sellers.** Many motivated sellers are in difficult circumstances — foreclosure, probate, divorce, illness, financial distress. The law in several states gives extra protection to sellers in foreclosure or similar situations, including rescission rights and restrictions on who may buy and on what terms. Your ethical obligation is at least as high as your legal one: be honest about who you are, what you intend to do, and what the seller is agreeing to. A seller who understands the deal and still wants it is a good client. A seller who was confused into signing is a future complaint.

**Taxes.** Assignment fees are income. Double-closing spreads are income. You will owe taxes on them, and the timing and character of that income depend on how you operate and how your business is structured. Keep records from day one, keep business money separate from personal money, and talk to a tax professional before your first closing, not after your first tax year.

**Entity and insurance.** Many wholesalers operate as a sole proprietor at first and later form an LLC. Whether and when to form an entity, and what insurance to carry, are questions for your attorney and your insurance advisor. Do not let an entity give you false confidence: an LLC does not make an unlawful act lawful, and it does not protect you from personal liability for your own conduct in every case.

## What to do before your first deal

1. Consult a licensed real estate attorney in your state. Bring this course, the contract forms you plan to use, and a written list of questions: Do I need a license to wholesale here? What disclosures are required? How may I market? What should my contract say about assignment?
2. Get the answers in writing, or take careful notes with the date, and keep them.
3. Use the state-rules research checklist in the workbook (Appendix A is your starting point for what to look for).
4. Do not sign a purchase contract, market a property, or assign a contract until you have done steps 1–3.

The cost of an attorney consultation — often a few hundred dollars — is small compared with the cost of a regulator investigation, a lawsuit from a seller, or a lost deposit on a deal you could not legally close. Treat it as a startup cost, not an optional extra.

### Action Steps — Module 3

1. Book a consultation with a local real estate attorney this week. Write down the date.
2. Complete the state-rules research checklist in the workbook for your state before you contact any seller.
3. Write down, in your own words, the three legal questions above and the answers your attorney gives you.
4. Decide now: if your state requires a license to do what you planned, you will either get licensed, partner with a licensed professional in a lawful way your attorney approves, or operate in a different structure your attorney approves — you will not proceed unlicensed and hope for the best.
5. Do not contact sellers until Modules 1–3 are complete and your state research is done.

---

# Module 4 — Finding Motivated Sellers: Driving for Dollars, Lists, and Direct Mail

A motivated seller is a property owner with a reason to sell quickly and a willingness to accept less than full retail value in exchange for speed, certainty, and convenience. Not every seller is motivated, and not every distressed-looking house has a motivated owner. Your job is to find the overlap: a property with a problem, and an owner with a reason to solve it now.

There are three main ways beginners find sellers: driving for dollars, working lists, and direct mail. Most working wholesalers use all three, because each finds sellers the others miss.

## Driving for dollars

Driving for dollars means driving through neighborhoods looking for properties that show signs of distress or vacancy, noting the addresses, and then finding the owners and contacting them. Signs include: overgrown lawns, boarded windows, peeling paint, a roof in visible disrepair, mail piling up, no car in the driveway for weeks, a "for sale by owner" sign that has been up for months, or a house that is clearly vacant.

This method is free except for gas and time, and it teaches you neighborhoods in a way no list can. You learn which streets have rentals, which have owner-occupied houses, where the older housing stock is, and where investors are already active (look for dumpsters, renovation crews, and "we buy houses" signs — those are signs of competition, not a reason to leave).

Work it systematically. Pick one or two neighborhoods to start — ideally areas with older single-family houses, a mix of owner-occupied and rental properties, and sale prices in a range your buyers can work with. Drive the same area more than once, at different times, and keep a log of every address with a note on what you saw and the date. A house that looks vacant in January may have a new tenant in March; a house that looks fine from the street may have an owner who is three months behind on taxes. Your log is an asset — it compounds.

Once you have an address, you need the owner's name and contact information. Public property records — usually available through the county assessor or tax office, often online — will show the owner of record and the mailing address for tax bills, which is often different from the property address when the owner does not live there. That difference is itself a signal: an owner who does not live at the property is more likely to be an absentee owner, and absentee owners are a classic motivated-seller group. Skip-tracing services can find phone numbers and email addresses for owners; they charge per search or per month, and their accuracy varies. Use them, but verify what they return before you call.

## Lists

A list is a set of property records filtered by a characteristic that correlates with motivation. Common lists beginners use:

- **Absentee owners:** owners whose tax-bill mailing address differs from the property address. Often landlords who are tired of managing, or owners who inherited a property elsewhere.
- **Pre-foreclosures:** owners who have received a notice of default or similar filing. These owners are under time pressure, and several states give them extra legal protections — be careful, be honest, and know your state's rules before you contact them.
- **Probate:** properties owned by someone who has died, where the heirs may want to sell. Probate is slow, emotional, and legally specific. Approach with patience and respect, and expect a longer timeline.
- **Tax-delinquent owners:** owners behind on property taxes. Public records usually show this. A small tax debt is a solvable problem for an investor buyer and a reason for the owner to sell.
- **Code violations:** properties with open code-enforcement cases. The city has already told the owner the property is a problem.
- **High-equity, older owners:** owners who have owned a property for many years and have substantial equity. They can afford to sell at a discount and still walk away with money, which matters more than it sounds — an owner with no equity cannot accept a discounted price even if they want to.
- **Divorce filings:** owners going through a divorce who may need to sell a shared property. Sensitive, and the timeline is set by the court, not by you.

You can build lists from public records yourself, or buy them from a list provider. If you buy, start small — a few hundred records in one neighborhood — and test the response before you buy thousands. A list is only as good as its accuracy: a list with 20% bad addresses or disconnected numbers wastes 20% of your marketing budget. Ask the provider when the data was last updated, and spot-check a sample against public records before you mail or call the whole list.

## Direct mail

Direct mail is the classic wholesaling channel: you send a letter or postcard to owners on your list, they call you, and you talk. It is slow, it is a numbers game, and it still works when it is done consistently.

What to send: a short, plain letter works better than a glossy flyer for most beginners. It should say who you are, that you are interested in buying their property, that you can close quickly and buy as-is, and how to reach you. It should not promise a price, and it should not pretend to be something it is not — no fake handwriting fonts that claim to be personal when they are mass-produced, no "final notice" language, no claim that you have a buyer lined up when you do not.

How much to send: response rates for direct mail to motivated-seller lists are typically low — 1% to 3% of recipients calling is a realistic expectation, and most callers will not become deals. That means 500 letters might produce 5 to 15 calls, and 5 to 15 calls might produce one signed contract, if the list and the message are good. Those are honest numbers, and they are why consistency matters more than any single mailing. One mailing is a test. Six mailings to the same list over six months is a campaign.

How often: mailing the same list every 30 to 45 days is a common rhythm. Owners who were not ready in January may be ready in April, after a roof leak or a tax bill. Do not mail once, get no calls, and conclude that direct mail does not work. And do not mail a list you have not scrubbed — remove duplicates, remove properties you already contacted recently, and remove anyone who asked not to be contacted.

Cost: a simple postcard or letter, including printing and postage, typically costs $0.50 to $1.50 per piece, depending on volume and format. Five hundred pieces is roughly $250 to $750 per mailing. That is the real startup cost of this channel, and it is why your budget from Module 1 matters. If your budget is $200 a month, you can mail 150 to 300 pieces a month — that is a real campaign, just a smaller one.

## Other channels worth knowing

- **Online advertising and "we buy houses" websites:** effective at scale, expensive per lead, and competitive. Not a beginner's first channel, but worth understanding.
- **Referrals:** real estate agents, property managers, contractors, and other investors see distressed properties before you do. A referral relationship with an agent — lawful in your state, with any referral fee handled as your attorney advises — can be a steady source of leads.
- **Auctions and REOs:** bank-owned properties sold at auction or by lenders. These are usually marketed to the public, the discounts are thinner, and the competition is professional. Learn them later.
- **Networking:** local real estate investor meetups, online investor groups, and title companies are where buyers and deals circulate. Go to meet people and learn, not to pitch on day one.

## Choosing your starting channel

If your budget is near zero, start with driving for dollars and free public records. If you have $200 to $500 a month, add direct mail to a small, well-chosen list. If you have more, test a second list or a second neighborhood — but test one change at a time, so you know what worked. Whatever you choose, commit to 90 days of consistent effort before you judge it. Module 13 gives you the schedule.

### Action Steps — Module 4

1. Choose one neighborhood to drive this week. Drive it, log at least 20 distressed or vacant properties, and look up the owners of at least 5 of them in public records.
2. Choose one list type from this module that fits your market. If you buy a list, start with 200–500 records.
3. Draft your first direct-mail letter (one page, plain language). Have your attorney review any claim in it before you send it.
4. Set a weekly target: number of properties driven, letters sent, and owners contacted. Write it in the workbook's 90-day tracker.

---

# Module 5 — Cold Calling and Texting Sellers: What to Say and What Not to Say

Most beginners fear the phone more than any other part of wholesaling. The fear is understandable — you are calling a stranger about their house. The cure is preparation, a simple structure, and enough repetitions that the call becomes routine. This module gives you the structure, the words, and the boundaries. The full scripts are in the templates folder; this module explains *why* they are written the way they are.

## Before you dial: compliance first

Cold calling and texting are regulated. The federal Telephone Consumer Protection Act (TCPA), the Do Not Call Registry, and state laws all apply, and violations can result in fines of hundreds or thousands of dollars per call or text — far more than any assignment fee. Before you call or text anyone:

- Scrub your list against the National Do Not Call Registry and any applicable state do-not-call list. Many list providers and dialer services offer scrubbing; use it.
- Understand that texting has stricter consent rules than calling in many interpretations — a text to someone who has not consented to receive texts from you is a particular risk. Many experienced wholesalers call first and text only after a conversation or an explicit invitation. Discuss the current rules with your attorney before you run a text campaign.
- Call at reasonable hours (generally 8 a.m. to 9 p.m. in the recipient's time zone, and narrower in some states), identify yourself honestly at the start of the call, and honor every request not to be called again immediately. Keep a do-not-contact list and check it before every session.
- Do not use misleading caller ID, do not pretend to be someone you are not, and do not claim an affiliation you do not have.

Compliance is not a footnote. It is the difference between a marketing channel and a liability.

## The structure of a good seller call

A cold call to a seller has five parts, and it should take five to ten minutes if the seller is interested, and under a minute if they are not.

**1. The opening (15 seconds).** Say who you are, why you are calling, and ask if they have a moment. Example: "Hi, this is [your name]. I'm a local homebuyer — I buy houses in [neighborhood] — and I'm calling about the property at [address]. Do you have a quick minute?" Honest, specific, and short. Do not say you are calling about "your house" as if you are a neighbor, and do not say "I'm interested in your property" in a way that hides that you want to buy it at a discount.

**2. The qualification (2–3 minutes).** Ask questions and listen. You need to learn: Do they own the property? Do they live there? Why might they sell? What is the condition of the house? What is their timeline? What do they think the house is worth, and what do they owe on it? You are not pitching yet. You are learning whether this is a motivated seller with a property that could work for an investor buyer.

Good questions include: "What has you thinking about selling?" "How long have you owned the home?" "What kind of condition is it in — does it need any work?" "If you sold, what would your timeline look like?" "Is there a mortgage on the property?" Listen more than you talk. The seller will tell you their motivation if you let them.

**3. The offer conversation (2–3 minutes).** If the seller is motivated and the property fits, you can discuss price — but frame it honestly. You are an investor buyer who buys as-is, closes quickly, and pays cash or its equivalent; the trade-off for speed and convenience is a price below retail. Do not promise a price you cannot pay, do not claim you will pay "full market value," and do not pressure a seller who says no. A useful line: "Based on the condition and the repairs it needs, I'd be in the range of [price]. I know that's below what a renovated house would sell for — the difference is the cost of the repairs and the risk I take on. Does that range work for you, or are we too far apart?" If you are too far apart, thank them, note the number, and follow up later. Many deals close on the third or fourth contact, not the first.

**4. The next step.** If there is interest, set a concrete next step: a time to walk the property, a time to call back, or a time to send a written offer. Get the best phone number and email, and confirm them. Vague endings — "I'll think about it" with no follow-up date — are where deals die.

**5. The close of the call.** Thank them, repeat the next step and the time, and end politely. Log the call immediately: what they said, what they wanted, what you promised, and when to follow up. The call log in the workbook exists for this reason.

## What not to say

- Do not say you are the end buyer if you intend to assign the contract — that is a disclosure issue in several states, and it is a trust issue everywhere. Be honest about your role in the way your attorney advises for your state.
- Do not say "I have a buyer lined up" unless you do, and do not say "I can close in seven days" unless you can.
- Do not make a low offer and then claim the house is worthless, or exaggerate repair costs to push the price down. Give your honest basis for the price, and let the seller decide.
- Do not argue with a seller. If they are angry, apologize for the interruption, remove them from your list, and move on.
- Do not discuss a seller's personal situation — a death, a divorce, a foreclosure — as a lever. Acknowledge it respectfully and move to the practical question: what would a sale look like for them?
- Do not promise legal or tax advice. If a seller asks whether they should sell, or what the tax consequences are, tell them to speak to their attorney or tax advisor.

## Texting sellers

If — and only if — your attorney confirms that texting is lawful for your list and your consent basis, keep texts short, honest, and human. Identify yourself, name the property, and ask if they would be open to a conversation. One text, then wait. Do not send a barrage, do not text late at night, and do not use deceptive language ("I tried to reach you about your warranty" or similar tricks). The scripts in the templates folder give you a compliant starting point; your attorney gives you the final word.

## Handling objections

You will hear the same objections repeatedly. Prepare calm, honest answers:

- **"How much will you pay?"** — "It depends on the condition and the repairs. If you can tell me a bit about the house, I can give you a realistic range, and if we walk the property I can give you a firm number."
- **"That's too low."** — "I understand. A renovated house in your neighborhood sells for more — the difference is the repair cost and the fact that I buy as-is and close quickly. If the number doesn't work for you, I respect that. Would it help if I explained how I got to it?"
- **"I need to think about it."** — "Of course. When would be a good time for me to check back — later this week, or next week?" Get a date.
- **"Are you a realtor?"** — "No, I'm not a realtor. I'm an investor buyer. I buy houses directly, and if it helps, you're welcome to have your own agent or attorney look at anything I send you."
- **"Stop calling me."** — "I'm sorry — I'll remove you right now and you won't hear from me again." Then do it, immediately, and log it.

## The numbers behind the phone

Cold calling is a volume business with a low conversion rate, and you should know the shape of it before you start so a slow day does not feel like failure. As a rough illustration — not a guarantee — a beginner might find that out of 100 calls, 60 to 70 go unanswered or to voicemail, 20 to 30 result in a brief conversation, 3 to 5 result in a longer conversation with a potentially motivated seller, and 1 results in a property walk or a written offer. Those ratios improve with list quality and skill, and they vary by market. The point is that you need a pipeline: a single afternoon of calling is not a business, and a single rejection is not a verdict on the business.

### Action Steps — Module 5

1. Read the seller scripts in the templates folder out loud, three times each, until they sound like you rather than a script.
2. Write your own one-sentence opening and practice it until you can say it without notes.
3. Before your first call session, confirm your list is scrubbed against the Do Not Call Registry and that you understand your state's texting rules.
4. Make your first 20 calls in one session. Log every call in the seller-call log. Do not judge the channel until you have made at least 100 calls.
5. After each session, note the one objection you heard most and write a better answer for next time.

---

# Module 6 — Analyzing a Wholesale Deal: ARV, Repairs, MAO Formula with Worked Examples

This is the module that determines whether you make money or lose credibility. A wholesaler who cannot analyze a deal accurately will overpay for contracts, bring buyers deals that do not work, and burn relationships. A wholesaler who can analyze a deal accurately is valuable to buyers before they ever close one.

There are three numbers that matter: the after-repair value (ARV), the repair cost, and the maximum allowable offer (MAO). Learn them in that order.

## After-repair value (ARV)

The ARV is what the property would sell for after it is fully renovated to the standard of comparable renovated houses in the neighborhood. It is not what the property is worth today, in its current condition. It is not what the seller thinks it is worth, or what an online estimate says. It is the resale price a renovated house like this one would command, based on comparable sales.

How to estimate ARV:

1. Find comparable sales — "comps" — of similar houses, in the same neighborhood, sold in the last 3 to 6 months. Similar means similar size (square footage within about 20%), similar age and style, similar number of bedrooms and bathrooms, and a similar lot.
2. Use renovated comps, not distressed comps. A house that sold as a fixer for $120,000 tells you about fixer prices, not about what a renovated house sells for. You want the renovated sales.
3. Adjust for differences. If your subject house is 200 square feet smaller than a comp that sold for $220,000, the ARV is lower than $220,000. If it has an extra bathroom, it is higher. Adjustments are judgment, and they are where experience helps — but even a beginner can avoid the largest error, which is using a comp from a different neighborhood or a different price tier.
4. Use at least three comps. One comp is an anecdote. Three comps that cluster around the same price are evidence.
5. Be conservative. If your comps suggest $195,000 to $215,000, use $195,000 or $200,000 for your analysis, not $215,000. Optimistic ARVs are how deals fall apart at the buyer's appraisal or resale.

Common ARV mistakes: using a comp from a nicer neighborhood across a major road; using a sale from 18 months ago in a rising or falling market; using the list price of an unsold house instead of a closed sale price; and trusting an automated online estimate without checking the comps behind it. Online estimates are a starting point for research, not an ARV.

## Repair costs

The repair cost is what it will take to bring the property to the condition reflected in the ARV. This is the number beginners get wrong most often, usually by underestimating it by 30% to 100%. The reason is simple: repairs you cannot see — roof, plumbing, electrical, foundation, HVAC — cost more than repairs you can see, and a walk-through without a contractor's eye misses them.

How to estimate repairs as a beginner:

- Walk the property with a checklist (the workbook has one) and note everything: roof age and condition, HVAC age, water heater, electrical panel, plumbing, foundation cracks, windows, flooring, kitchen, bathrooms, exterior, and any sign of water damage or mold.
- Price by category, using rough per-item ranges for your market, and add them up. Illustrative ranges — verify against local contractor pricing in your market, because labor and materials vary widely by region:
  - Light cosmetic (paint, flooring, fixtures, cleanup): $10,000–$20,000
  - Moderate (kitchen and bath refresh, plus cosmetic): $25,000–$45,000
  - Heavy (roof, HVAC, kitchen and bath gut, plus cosmetic): $50,000–$90,000+
  - Full gut / structural: $100,000+, and beyond the scope of a beginner's first deals.
- Get a contractor's opinion before you finalize an offer on any deal with more than cosmetic work. A contractor walk-through — even a paid one — is cheaper than a $15,000 repair you missed. Build a relationship with one or two local contractors who work with investors; they will teach you more about repair costs in a month than a course can.
- Add a contingency. For a beginner, add 10% to 20% to your repair estimate for the unknowns you cannot see. If you estimate $30,000 in repairs, analyze the deal at $33,000 to $36,000. If the deal still works, it is a real deal. If it only works at the optimistic number, it is not.

## The maximum allowable offer (MAO) formula

The MAO is the most you — or more precisely, your end buyer — can pay for the property and still make a profit. The standard formula investors use is:

**MAO = (ARV × 0.70) − Repair Costs**

The 0.70 (70%) is the "70% rule." It is a rule of thumb, not a law of nature. It exists because the 30% it leaves out has to cover the buyer's profit, holding costs (mortgage or loan interest, taxes, insurance, utilities while the property is renovated), selling costs (agent commissions, closing costs), and a margin for error. In some markets the right percentage is 65%; in others, 75%. Your buyers will tell you, by what they accept and what they reject, what percentage works in your market. Start with 70% and learn from your buyers.

Your contract price must be at or below the MAO *minus your fee*. That is the part beginners forget. The MAO is what the buyer can pay in total. If the MAO is $105,000 and your fee is $10,000, your contract price with the seller must be $95,000 or less. If you contract at $105,000 and then try to add a $10,000 fee, the buyer is paying $115,000 — above the MAO — and the deal does not work.

### Worked example 1 — the $200,000 ARV property

This is the example from the course introduction, worked in full:

- ARV: **$200,000** (based on three renovated comps in the neighborhood selling for $195,000, $202,000, and $208,000; you use $200,000 to be conservative)
- Repair costs: **$35,000** (moderate renovation: kitchen and bath refresh, flooring, paint, fixtures; you have added a 10% contingency inside this number)
- MAO: $200,000 × 0.70 = $140,000; $140,000 − $35,000 = **$105,000**
- Your target assignment fee: **$10,000**
- Your maximum contract price with the seller: $105,000 − $10,000 = **$95,000**

If you can contract at $95,000 and assign at $105,000, the buyer pays $105,000 total, renovates for $35,000, and has $140,000 in the property against a $200,000 resale — leaving $60,000 for profit, holding costs, selling costs, and margin. That is a deal a buyer will take seriously.

If the seller will only accept $115,000, the numbers change: $115,000 + $10,000 fee = $125,000 to the buyer, which is $20,000 above the MAO. That deal does not work at a $10,000 fee. You could reduce your fee to $0 and it still would not work — $115,000 is above the $105,000 MAO. The correct answer is to pass, or to renegotiate, not to force the deal.

### Worked example 2 — a lower-priced property

- ARV: **$130,000** (comps at $128,000, $131,000, $135,000)
- Repair costs: **$18,000** (light cosmetic: paint, flooring, fixtures, cleanup)
- MAO: $130,000 × 0.70 = $91,000; $91,000 − $18,000 = **$73,000**
- Your target fee: **$5,000**
- Your maximum contract price: $73,000 − $5,000 = **$68,000**

On a lower-priced property, the fee is smaller in dollars but the same discipline applies. A $5,000 fee on a $68,000 contract is about 7% of the price — buyers will look at it, and it is fair if the deal works for them.

### Worked example 3 — a deal that looks good but is not

- ARV: **$300,000** (comps at $295,000, $305,000, $310,000 — you use $300,000)
- Repair costs: **$60,000** (heavy: roof, HVAC, kitchen gut)
- MAO: $300,000 × 0.70 = $210,000; $210,000 − $60,000 = **$150,000**
- The seller owes **$165,000** on their mortgage and wants at least that much to walk away.

The seller cannot accept $150,000 or less without bringing cash to closing, and most sellers in this position cannot or will not. This deal does not work, no matter how motivated the seller is. Motivation does not create equity. Check what the seller owes — early, politely — before you spend hours on a property that cannot be discounted enough.

### Worked example 4 — the assignment fee on a $115,000 contract

- You contract at **$115,000**.
- You assign to a buyer for **$125,000** total.
- Assignment fee: **$10,000**.

For this to be a good deal for the buyer, the MAO must be at least $125,000. Working backward: if repairs are $35,000, the ARV must be at least ($125,000 + $35,000) ÷ 0.70 = $228,571. If the ARV is only $200,000, the MAO is $105,000 and a $125,000 buyer price is $20,000 too high. Always check the fee against the MAO from the buyer's side, not just from yours.

## Sensitivity: what happens when you are wrong

Run the numbers three ways on every deal: the base case, the optimistic case, and the pessimistic case. If the ARV is $10,000 lower than you thought and repairs are $5,000 higher, does the deal still work? If it only works in the optimistic case, it is not a deal — it is a hope. The workbook's deal-analysis worksheet has space for all three cases. Use it.

## Action Steps — Module 6

1. Pick a property for sale in your market (any listing will do for practice) and estimate its ARV from three comps. Write down the comps.
2. Estimate its repair costs by category. Add a 10% contingency.
3. Calculate the MAO and your maximum contract price at a $7,500 fee. Do it by hand, then check it in the workbook.
4. Work examples 1–4 above by hand until you can do the MAO calculation without looking at the formula.
5. Find one local contractor who works with investors and ask if they will walk a property with you on a future deal.

---

# Module 7 — Making an Offer and Getting a Contract Signed

You have found a motivated seller, you have run the numbers, and the deal works at a price the seller might accept. Now you have to make an offer and get it in writing. This module is about how to do that clearly, honestly, and in a way that protects both sides.

## Before you offer: confirm the facts

Before you put a number in writing, confirm the facts that change the number:

- **Who owns the property?** Check the deed or tax record. Is there one owner or several? Is there a spouse, an heir, or a co-owner who must also sign? An offer accepted by one of two owners is not a deal.
- **What is owed?** Ask the seller, politely, what they owe on the mortgage and whether there are liens, back taxes, or a home-equity loan. You do not need the exact payoff figure yet — that comes at closing — but you need to know whether the price you are offering can cover what they owe.
- **What is the condition, really?** Walk the property if you can. If you cannot walk it, be explicit in your offer that it is subject to an inspection or due-diligence period, and understand what that period allows you to do.
- **What is the seller's timeline?** A seller who needs to close in 14 days and a seller who can wait 60 days are different negotiations. Your contract's closing date should match what you promised and what you can deliver.
- **Is there anything that would prevent a sale?** A pending foreclosure date, a probate case, a divorce proceeding, a tenant with a lease, or a title problem — any of these can change the timeline or the structure. Ask, and note the answers.

## How to present an offer

Present the offer in person or by phone first, then in writing. The conversation matters more than the document: the seller should understand the price, the timeline, and the terms before they see a signature line.

A clear offer conversation covers:

1. **The price.** State it plainly, with a brief explanation of how you got there: "Based on the repairs it needs and what renovated houses sell for here, I can offer $95,000." Do not apologize for the price and do not inflate it to be liked.
2. **The terms.** Cash or equivalent, as-is, no repairs required from the seller, close by a specific date, and the earnest-money deposit. Explain each term in plain language.
3. **The process.** What happens after they sign: inspection, title search, closing at a title company or attorney's office, and how and when they get paid.
4. **Their right to review.** Tell the seller they can have an attorney or agent review the contract, and give them time to do it. A seller who signs under pressure is a seller who may try to cancel later — and in some states, may have a legal right to.

If the seller counters, listen. A counter is not a rejection; it is information about what matters to them. Sometimes the price is the issue, and sometimes it is the timeline, the deposit, or help with moving costs. Negotiate on the whole package, not just the price — but never agree to a price above your maximum contract price from Module 6 to "get the deal." A deal above your MAO is not a deal.

## The purchase contract — what to understand before you sign

Your purchase contract is the document that controls the deal. Have your attorney review the form you use, and understand these clauses before you sign any version of it:

- **Purchase price and earnest money.** The price, the deposit amount, who holds the deposit (usually the title company or an attorney escrow), and when it is refundable.
- **Closing date.** The date by which the sale must close. Wholesale contracts often use 30 to 45 days. Make sure the date is realistic for your buyer's financing and the title search.
- **Inspection / due-diligence period.** The window during which you may inspect the property and cancel the contract if it does not meet your standards. This is your main protection as a wholesaler. Know its length in days, when it starts, and what you must do to cancel within it.
- **Assignability.** Whether the contract may be assigned to another buyer, and whether the seller's consent is required. If the contract says it may not be assigned, you cannot assign it. If it is silent, your attorney should tell you what that means in your state.
- **Contingencies.** Any conditions that must be met for the sale to close — financing, title, inspection, or partner approval. Understand which contingencies protect you and which create obligations.
- **Seller disclosures.** What the seller must disclose about the property's condition, known defects, and any issues. Requirements vary by state.
- **Default and remedies.** What happens if either side fails to perform — who keeps the deposit, and whether the seller can sue for performance.

Do not sign a contract you do not understand. Do not let a seller sign a contract they do not understand. If either of you is confused, stop and get the clause explained by an attorney.

## Earnest money — practical guidance

Earnest money is a good-faith deposit that shows the seller you are serious. On wholesale deals it is often $500 to $2,000, and it is usually held by a neutral third party (title company or attorney), not given directly to the seller. The amount should be one you can afford to lose if the deal fails outside a protected cancellation window — because that is the risk you are taking. Never promise a deposit you do not have, and never hand a deposit directly to a seller without your attorney's advice.

## After the contract is signed

Once both sides have signed:

1. Give the seller a copy immediately.
2. Deliver the contract and the earnest money to the title company or attorney as the contract requires, on time.
3. Open title and order the title search right away — title problems take time to resolve, and you want to know early.
4. Start your buyer marketing (in the form your state allows) and your due diligence at the same time. Do not wait until the inspection period is almost over.
5. Stay in contact with the seller. A short update every few days — "title is in progress, we're on track for closing" — prevents the anxiety that makes sellers look for a reason to cancel.

### Action Steps — Module 7

1. Have your attorney review your purchase contract form before you use it. Write down the answers to: Is it assignable? How long is the inspection period? What is the earnest-money term?
2. Practice presenting an offer out loud, using the $95,000 example from Module 6. Time yourself — it should take under three minutes.
3. Write down your walk-away price for your next deal before you make the offer, and do not exceed it in the conversation.
4. Decide which title company or attorney you will use for closings, and introduce yourself before you have a deal under contract.

---

# Module 8 — Assignment Contracts and Disclosures Explained

The assignment is the step where a beginner is most likely to make a legal mistake, because it is the step where the most documents change hands and where the seller, the buyer, and the wholesaler all have different interests. This module explains the assignment agreement, the disclosures that go with it, and the marketing rules that surround it. The template in the templates folder is educational only — it must be reviewed by a licensed attorney in your state before you use it.

## What an assignment is

An assignment transfers your rights under the purchase contract to another buyer. After the assignment, the new buyer steps into your place: they are the buyer under the contract, they close with the seller, and they pay the seller the contract price. You step out, and you are paid the assignment fee you agreed with the new buyer.

The assignment agreement is a separate document from the purchase contract. It should state: who is assigning (you), who is receiving the assignment (the buyer), which purchase contract is being assigned (identified by property address, date, and parties), the assignment fee, when and how the fee is paid (usually at closing, through the settlement statement), and any warranties or disclaimers about the property and the contract.

## What an assignment is not

An assignment does not transfer the property. It transfers contract rights. It does not make the buyer the owner until closing. It does not relieve you of obligations under the purchase contract unless the assignment agreement and the purchase contract say so and the seller consents where required. In some states and under some contract forms, you remain liable if the assignee fails to close. Your attorney should tell you whether that is true for your form and your state, and your assignment agreement should address it explicitly.

## Disclosures — to the seller

Before or at the time the seller signs the purchase contract, the seller should understand — in writing, in plain language — who you are and what you intend to do. The exact disclosure required varies by state, and several states have added specific wholesaling disclosure requirements in 2024–2026. In general, a proper disclosure covers:

- That you are buying the property as an investor, not as someone who will live in it.
- That you may assign the contract to another buyer, and that you may be paid a fee for doing so.
- What that fee is, or how it will be calculated, if your state requires the amount to be disclosed.
- That the seller has the right to have an attorney or agent review the documents.
- That you are not a licensed real estate agent (if you are not), and that you are not acting as the seller's agent.

Get the disclosure signed and keep a copy. A disclosure made verbally and not documented is a disclosure you cannot prove.

## Disclosures — to the buyer

The buyer should understand what they are buying: your interest in a contract to purchase a specific property, at a specific price, with specific terms, and with whatever inspection and title information you have. You should share what you know about the property's condition — including problems you found — and you should not hide a repair issue to make the deal look better. A buyer who discovers a $10,000 problem you knew about will not buy from you again, and may have a claim against you.

Give the buyer a copy of the purchase contract (with the seller's private information handled as your attorney advises), the assignment agreement, and any inspection or title information you have. Let them do their own due diligence. A buyer who does their own inspection and still wants the deal is a buyer who will close.

## Marketing the deal — the rule that matters most

This is where the most wholesalers get into trouble, and it is worth stating plainly:

**In many states, you may market your interest in a contract. You may not market a property you do not own as if you are selling it.**

What that means in practice, in states that draw this line:

- You *may* say, to your buyers list: "I have a property under contract at [address]. I am selling my interest in that contract. The contract price is $95,000, and my assignment fee is $10,000."
- You *may not*, in those states, post a public listing that says "3-bed house for sale, $105,000" with photos of the seller's house and no mention that you do not own it and that you are selling a contract interest.

Some states restrict even the first kind of marketing unless you are licensed, or restrict advertising a property you do not own in any form. Your state may be one of them. That is why Module 3 comes before this module, and why your attorney's answer on marketing is not optional.

Practical rules that follow from this, in every state:

- Do not post a property on a public listing site as if it is for sale by you, unless your attorney has confirmed that is lawful in your state.
- Do not use the seller's photos or address in public advertising without understanding the rules and the seller's consent.
- Market to your own buyers list first. That list — built in Module 9 — is both your best sales channel and, in many states, your safest one.
- Keep a copy of every advertisement, post, and flyer you publish. If a regulator asks what you said, you want to be able to show them.

## The assignment fee on the settlement statement

In most assignments, the fee appears on the closing settlement statement, so the seller and the buyer can both see it. Some sellers are surprised by the size of the fee, even when they agreed to the price. That is why the disclosure in this module matters: a seller who knew from the beginning that you would assign the contract for a fee is far less likely to object at closing than a seller who learns it for the first time at the closing table. If your state requires the fee to be disclosed to the seller, disclose it early, in writing, and in the amount or calculation method the law requires.

## When assignment is not permitted

If your purchase contract says it may not be assigned, or your state restricts assignment, do not assign it anyway. Your options are to close on the property yourself (if you can fund it), to use a double closing (Module 11, with your attorney's guidance), or to cancel within a lawful cancellation window if one applies. "Assign it quietly" is not an option.

### Action Steps — Module 8

1. Read the assignment contract template in the templates folder. Highlight every blank and every clause you do not understand, and ask your attorney about them.
2. Write the disclosure you will give sellers, using your attorney's language for your state. Keep it to one page.
3. Decide now: you will market to your buyers list first, and you will not post a public listing for a property you do not own until your attorney confirms it is lawful in your state.
4. Create a folder — physical or digital — for each deal, and put the signed purchase contract, the signed disclosure, and the assignment agreement in it.

---

# Module 9 — Building a Cash-Buyers List from Zero

A wholesaler without buyers is a person with a contract and no one to sell it to. Your buyers list is your real business asset — more valuable than any single deal, because it is what lets you close the next deal. Build it before you need it, not after you have a property under contract and 30 days on the clock.

## Who is a cash buyer?

A cash buyer, for wholesaling purposes, is an investor who can close on a property without a traditional mortgage — either with their own cash, with a private lender, or with a hard-money loan that is already arranged. They buy properties to renovate and resell, or to renovate and rent. They are not retail homebuyers looking for a house to live in, and they are not agents looking for a listing.

A good buyer for you has four qualities: they have funds available now, they buy in your area and price range, they can decide quickly, and they close when they say they will. A buyer who has money but never decides, or who decides and then does not close, is worse than no buyer at all, because they waste the most valuable thing in a wholesale deal — time.

## Where to find buyers when you have none

Start with the places investors already gather, and be useful before you ask for anything:

- **Local real estate investor meetups and associations.** Go, listen, and learn who is active. Introduce yourself as a wholesaler who is learning the market. Ask what they buy, where, and in what price range. Do not pitch a deal you do not have.
- **Online investor groups.** Local Facebook groups, forums, and online communities for real estate investors in your city or county. Read first. Contribute something useful — a market observation, a contractor recommendation — before you ask for buyer information.
- **"We buy houses" signs and ads.** Call the numbers on bandit signs, billboards, and online ads in your market. These are active buyers. Ask what they buy and whether you can send them deals.
- **Public records.** Look up recent cash purchases of distressed properties in your target neighborhoods. The buyer on those deeds is an active investor. Their name and mailing address are public record. A short, professional letter or call — "I saw you bought a property on [street], I work with sellers in that area, may I send you deals?" — is a legitimate introduction.
- **Title companies and attorneys.** Title companies close investor transactions every day. A title officer who knows you are a wholesaler may introduce you to buyers, and will in any case be a useful contact when you close.
- **Real estate agents who work with investors.** Some agents specialize in investor clients. A lawful relationship with such an agent — with any compensation handled as your attorney advises — can put you in front of buyers who are already qualified.
- **Other wholesalers.** Wholesalers sometimes share buyers, co-wholesale a deal, or pass along a buyer they cannot serve. Be honest about what you have and what you need, and honor any split you agree to.

## What to ask every buyer

When you meet a potential buyer, learn and record:

- What areas and neighborhoods do they buy in?
- What price range? What property types — single-family only, or also multi-family, condos, land?
- What is their maximum repair budget, and do they do heavy renovation or only cosmetic work?
- How do they fund purchases — cash, private money, hard money? Do they need to see a property before they commit?
- How quickly can they close, and how quickly can they decide?
- What is the best way to reach them — phone, text, or email — and when are they available?
- Have they bought from a wholesaler before? What made a deal work for them, and what made one fail?

Record all of it in the buyers-list builder worksheet. A list of 50 names with no information about what each person buys is not a buyers list — it is a phone book. A list of 15 buyers whose criteria you know is a business.

## How to keep buyers engaged before you have a deal

A buyers list goes stale quickly. Stay in touch without being a nuisance:

- Send a short update once or twice a month: what you are seeing in the market, a neighborhood you are working in, or a question about what they are looking for.
- When you have a deal, send it to the buyers whose criteria it matches — not to the whole list. A buyer who gets three irrelevant deals will ignore the fourth, even if it is perfect for them.
- After a buyer passes on a deal, ask why. "Was it the price, the area, or the repairs?" That answer improves your next deal more than any course can.
- After a buyer closes on your deal, thank them, ask what they thought of the process, and ask what they want next. Then bring it to them first.

## A realistic timeline

Expect to spend your first month building a list of 20 to 50 buyers, with 5 to 10 who are genuinely active and responsive. That is enough to start. A list of 100 buyers sounds impressive and is mostly noise if you do not know what 80 of them buy. Depth beats breadth: know your best 10 buyers well, and your deals will close faster than a wholesaler with 200 names and no relationships.

## Action Steps — Module 9

1. Attend one local investor meetup or join one local online investor group this week. Introduce yourself and listen.
2. Find 10 recent cash purchases of distressed properties in your target neighborhood from public records. Note the buyers' names.
3. Contact 10 potential buyers this week. Ask the questions in this module and record the answers in the buyers-list builder worksheet.
4. Set a goal: 25 buyers with complete profiles by the end of your first 30 days.
5. Do not put a property under contract until you have at least 5 buyers who buy in that area and price range. If you cannot name 5, you are not ready for that deal.

---

# Module 10 — Showing the Deal and Closing the Assignment

You have a signed purchase contract, an assignment agreement ready, and a buyers list. Now you have to show the deal, get a buyer committed, and get to closing. This module is the sequence, step by step, and the problems that most often break it.

## Step 1: Prepare the deal package

Before you contact buyers, prepare a short, honest package for the deal:

- Property address, type, bedrooms, bathrooms, square footage, lot size, and year built.
- The ARV, with the comps behind it (at least three, with sale prices and dates).
- Repair estimate, by category, with photos of the property's condition — including the problems, not just the good angles.
- Your contract price, your assignment fee, and the total price to the buyer.
- The closing date and the inspection or due-diligence deadline.
- Any known title issues, liens, tenant situation, or access constraints.
- Photos and, if possible, a short video walk-through.

A buyer who receives a complete package can decide in an hour. A buyer who receives an address and a price has to do all the work themselves, and will often pass simply because the work is not worth it for a deal they have not yet vetted.

## Step 2: Show it to the right buyers first

Send the package to the buyers whose criteria it matches, in order of reliability: your most active, fastest-closing buyers first. Give them a clear deadline to respond — for example, "I need to know by Thursday at noon so I can hold the inspection window." A deadline is not pressure; it is information, because your contract has a real clock on it.

Let buyers walk the property. Arrange access with the seller in advance, be present if you can, and be honest about what you see. Do not hover over a buyer during their inspection, and do not argue with their contractor's repair estimate. If their estimate is higher than yours, that is information — either your estimate was low, or this buyer is more conservative than your next buyer. Note it and move on.

## Step 3: Get the commitment in writing

When a buyer says yes, get the assignment agreement signed promptly and collect any earnest money or deposit your agreement and your attorney require from the buyer. A verbal yes is not a commitment. Do not stop marketing the deal to other buyers until you have a signed assignment — but do not sign assignments with two buyers for the same contract. One contract, one assignee.

Confirm with the buyer, in writing: the total price they will pay, the closing date, how they are funding the purchase, and what inspection or due-diligence period they have. If they need financing, confirm that the financing is arranged or in process, and ask for proof of funds or a pre-approval that you can verify. A buyer who cannot show funds is a buyer who may not close.

## Step 4: Work the closing

Once the assignment is signed, your job is coordination:

- Confirm the title company or attorney has the purchase contract, the assignment agreement, and the buyer's information.
- Confirm the title search is in progress and ask about any issues early. Liens, unpaid taxes, and ownership disputes are common on distressed properties — they take time to resolve, and the earlier you know, the better.
- Stay in contact with the seller. Short, regular updates prevent anxiety and cancellations.
- Stay in contact with the buyer. Confirm they have completed their inspection, that their funds are ready, and that they are prepared to close on the scheduled date.
- Confirm the settlement statement before closing, and confirm that your assignment fee is shown correctly and will be paid at closing.

## Step 5: Close and collect

At closing, the buyer closes with the seller, the seller is paid the contract price (less what they owe), and you are paid your assignment fee. Confirm the funds have been received before you consider the deal closed. Then do three things the same day:

1. Thank the seller and the buyer, separately and sincerely.
2. Record the deal in your deal tracker: every number, every date, every cost, and the net fee.
3. Write down what you learned: what you would do differently next time, what the buyer cared about, and what the seller needed.

## When a deal falls apart

Deals fall apart, and a beginner should expect it. The most common reasons, in rough order:

- **The buyer's numbers do not work.** Their repair estimate is higher than yours, or their ARV is lower. This is the most common reason, and it is usually a sign that your analysis was optimistic.
- **Title problems.** A lien, an heir who will not sign, unpaid taxes, or a boundary issue. Some can be resolved with time; some cannot.
- **The buyer's financing fails.** A hard-money lender declines, or the buyer's funds are not available when promised.
- **The seller changes their mind.** Sometimes because they received a higher offer, sometimes because a family member intervened, sometimes because they were never truly ready to sell.
- **The inspection finds a major problem.** Foundation, mold, or structural damage that changes the repair cost beyond what the deal can bear.

When a deal falls apart, your obligations depend on your contract. If you are within an inspection or due-diligence period, you may be able to cancel and recover your earnest money. If you are outside that period, you may not. That is why the inspection period in Module 7 matters so much, and why you should never let it expire without a decision. If you cannot close and cannot cancel, call your attorney immediately — do not wait, and do not try to fix it by assigning a contract you no longer have time to assign.

If a deal falls apart for a reason that was your error — your ARV was wrong, your repair estimate was low — own it with the buyer and the seller. Apologize, learn, and do better next time. Your reputation is built as much by how you handle a failed deal as by how you handle a successful one.

## Action Steps — Module 10

1. Build a blank deal package template from the list in Step 1 and keep it ready before your next deal.
2. Decide your buyer-response deadline rule now: for example, 48 hours for a first response, and a signed assignment within 5 days of first showing.
3. Practice explaining a deal package to a buyer in under two minutes: address, ARV, repairs, price, fee, and closing date.
4. After your first closing — or your first failed deal — complete the deal review in the workbook within 24 hours, while the details are fresh.

---

# Module 11 — Double Closings When Assignment Is Not Allowed

A double closing is the alternative structure when assignment is not available — because the contract forbids it, because your state's rules restrict assignment, or because the parties prefer it. It is a legitimate structure, and it is also more expensive, more complex, and riskier than an assignment. Use it only with your attorney's guidance, and only when you understand the costs.

## How a double closing works

You buy the property from the seller, and then you sell it to your end buyer — two separate closings, usually on the same day, at the same title company. The first closing transfers the property from the seller to you. The second transfers it from you to the buyer. You own the property in between, even if only for an hour.

Because you are the buyer in the first closing, you need funds to buy the property. Most wholesalers use transactional funding: a short-term loan that covers the purchase price for a day, repaid from the proceeds of the second closing. Transactional funding is not a mortgage — it is a same-day bridge, and it is priced for that. Typical costs are 1% to 3% of the purchase price, plus fees, and the lender will usually require that both closings are scheduled, that the end buyer is confirmed, and that the title company is one they work with. You must arrange transactional funding *before* the closing day, not on it.

## The costs, worked through

Revisit the example from Module 2, with funding included:

- Purchase from the seller: **$115,000**
- Sale to the investor buyer: **$128,000**
- Gross spread: **$13,000**
- Closing costs on the purchase: ~$2,000 (illustrative; varies by state)
- Closing costs on the sale: ~$1,500 (illustrative; varies by state)
- Transactional funding at 2% of $115,000: **$2,300**, plus lender fees of perhaps $500
- Total costs: $2,000 + $1,500 + $2,300 + $500 = **$6,300**
- Net before taxes: $13,000 − $6,300 = **$6,700**

Compare that with the assignment of the same deal at a $10,000 fee, where your costs are close to zero. The double closing cost you roughly $6,300 to achieve a similar result — and it required you to fund a $115,000 purchase. That is the trade-off. A double closing only makes sense when the spread is large enough to absorb the costs, or when assignment is not available and the deal is still worth doing.

## When a double closing is the right choice

- **Assignment is restricted** in your state or under your contract, and your attorney confirms a double closing is a lawful alternative for your situation.
- **The fee is large** and the parties prefer the two prices to appear on separate settlement statements. This is a privacy preference, not a legal requirement, and it does not hide the transaction from anyone who needs to see it.
- **The seller's lender or the title company requires it** for a particular transaction — for example, some short-sale or bank-owned transactions do not permit assignment.

## Risks that are specific to double closings

- **Funding risk.** If your transactional funding falls through, or the second closing is delayed, you own a property you did not intend to own, with a loan due immediately. Have a backup plan and a backup funding source before you commit.
- **Timing risk.** Both closings must happen in sequence on the same day. If the end buyer is late, unprepared, or cannot fund, the first closing has already happened and you are holding the property.
- **Cost risk.** Closing costs and funding fees are higher than most beginners estimate. Get written quotes for both closings and for the funding before you commit, and run the numbers with the real figures.
- **Disclosure risk.** A double closing does not relieve you of disclosure obligations. The seller and the buyer should understand the structure — that you are buying and reselling, and what your profit is, to the extent your state's law requires disclosure. Hiding the structure from either party is a trust and legal risk, not a clever technique.

## How to prepare

1. Discuss the structure with your attorney before you sign a purchase contract that you intend to double-close.
2. Find a title company that has done double closings before and is comfortable with them. Not every title company is.
3. Line up transactional funding in advance, with written terms.
4. Confirm the end buyer is fully funded and ready to close on the scheduled date, with proof of funds you have verified.
5. Run the numbers with real closing-cost quotes, not estimates, and confirm the spread covers all costs with a margin you are comfortable with.

## Action Steps — Module 11

1. Ask your attorney whether a double closing is a lawful alternative to assignment in your state, and in what circumstances.
2. Ask a local title company whether they handle double closings and what they require.
3. Identify one transactional funding source in your market and learn their terms, rates, and requirements — before you need them.
4. Do not attempt a double closing on your first deal. Learn the assignment process first, and add this structure only when you have a deal that requires it and an attorney who has reviewed it.

---

# Module 12 — Tracking Deals and Following Up

Wholesaling is a pipeline business. A pipeline you do not track is a pipeline you do not have. Most beginners lose more money to poor follow-up than to bad analysis: the seller who was not ready in March and would have sold in June, the buyer who wanted a deal in a neighborhood you stopped marketing to, the lead you meant to call back and forgot. This module is the system that prevents those losses.

## What to track

Track every lead, every deal, and every dollar, from day one. The deal tracker spreadsheet in the templates folder is built for this. For each property, record:

- Property address, owner name, and contact information
- Source (driving, mail, list, referral, online)
- Date of first contact and date of last contact
- Seller's motivation, timeline, asking price, and amount owed (if known)
- ARV, repair estimate, MAO, offer price, contract price, and assignment fee
- Buyer assigned to, assignment date, and closing date
- Status (new lead, contacted, offer made, under contract, assigned, closed, dead, follow-up)
- Follow-up date and what to say next
- Marketing cost attributable to the lead, and the net result

Track your marketing spend separately by channel: how much you spent on mail, lists, driving, and phone service, and how many leads, offers, contracts, and closings each channel produced. After 90 days you will know which channel earns its cost and which does not. Without that record, you will keep spending on the channel that feels productive and starve the one that actually works.

## The follow-up system

Most wholesale deals do not close on the first contact. They close on the third, fifth, or tenth. A follow-up system is simply a disciplined way to stay in contact without being a nuisance.

- **Every lead gets a next action and a date.** When you finish a call, before you hang up or immediately after, decide the next step and the date. "Call back in two weeks" is a plan. "Follow up sometime" is not.
- **Follow up on a schedule.** A common rhythm: contact a new lead within 24 hours of their inquiry, then at 7 days, 30 days, 60 days, and 90 days, and then monthly. Adjust to the seller's timeline — a seller who said "call me in six months when my tenant leaves" should be called in six months, not in two weeks.
- **Vary the channel.** A call, then a text (where lawful), then a letter. Different sellers respond to different channels, and a seller who ignores calls may answer a letter.
- **Add value on each contact.** Do not call just to ask "have you decided yet?" Call with a reason: a market update, a question about the property, a change in your offer, or a check-in on their timeline. A follow-up that gives the seller something is welcome; a follow-up that only asks for something is not.
- **Know when to stop.** If a seller asks not to be contacted, stop immediately and record it. If a seller has said no three times and their circumstances have not changed, move them to a long-term list (contact in six months) rather than calling monthly. Persistence is a virtue; harassment is a liability.

## The weekly review

Once a week, for 30 minutes, review your pipeline:

1. How many new leads came in? From which channel?
2. How many calls, offers, and contracts this week?
3. Which leads need follow-up this week, and what will you say?
4. Which deals are under contract, and what is the next step and deadline for each?
5. How much did you spend on marketing, and what did it produce?
6. What is the one thing you will do differently next week?

Write the answers down. A weekly review that lives in your head is a review that does not happen. The 90-day tracker in the workbook has a weekly review section for this purpose.

## Measuring what matters

The numbers that tell you whether the business is working:

- **Cost per lead:** marketing spend divided by number of leads. If you spent $500 and got 10 leads, your cost per lead is $50.
- **Cost per contract:** marketing spend divided by number of signed contracts. If you spent $2,000 over three months and signed 2 contracts, your cost per contract is $1,000.
- **Cost per closing:** marketing spend divided by number of closings. This is the number that determines whether the business is profitable.
- **Conversion rates:** leads to offers, offers to contracts, contracts to closings. If your offers-to-contracts rate is very low, your offers are too high or your sellers are not motivated. If your contracts-to-closings rate is low, your analysis or your buyer list is the problem.

### Worked example — cost per closing

- Marketing spend over 90 days: **$1,800** (mail $1,200, lists $300, phone $150, gas $150)
- Leads: **36** → cost per lead: $1,800 ÷ 36 = **$50**
- Offers made: **9** → 25% of leads became offers
- Contracts signed: **3** → cost per contract: $1,800 ÷ 3 = **$600**
- Closings: **2** → cost per closing: $1,800 ÷ 2 = **$900**
- Assignment fees collected: **$6,000 + $8,000 = $14,000**
- Net before taxes: $14,000 − $1,800 = **$12,200** over 90 days

Those are illustrative numbers for a beginner working consistently for a quarter — not a promise, and not typical for everyone. The point is the method: if you know your cost per closing, you know whether your marketing is working, and you know what a fee has to be to make the business profitable.

## Action Steps — Module 12

1. Set up the deal tracker spreadsheet before your first lead. Enter every lead the day you get it.
2. Create your do-not-contact list and check it before every call or mail session.
3. Schedule a fixed 30-minute weekly review and put it on your calendar.
4. At the end of your first month, calculate your cost per lead and your conversion rates. Write them down and compare them to the example above — not to judge yourself, but to see where the pipeline is leaking.

---

# Module 13 — Your First 30/60/90 Days: A Dated Launch Plan

This module turns the course into a schedule. It assumes you are starting part-time, with 8 to 12 hours a week, and a modest marketing budget. Adjust the hours and the budget to your situation, but keep the sequence: learn and verify first, build the buyer list second, contact sellers third, and make offers only when the numbers and the law are clear.

## Days 1–30: Foundation

**Week 1 — Learn and verify.**
- Read Modules 1–3 in full. Complete the state-rules research checklist in the workbook for your state.
- Book a consultation with a local real estate attorney. Bring your questions from Module 3.
- Choose your target neighborhood and your starting marketing channel (Module 4).
- Set up your tracking: the deal tracker spreadsheet, the call log, and the 90-day tracker.

**Week 2 — Build the buyer list.**
- Attend one investor meetup or join one online investor group.
- Find 10 recent cash purchases in your target neighborhood from public records.
- Contact 10 potential buyers. Record their criteria in the buyers-list builder worksheet.
- Have your attorney review your purchase contract form and your disclosure language.
- Draft your direct-mail letter and your call scripts.

**Week 3 — Start finding sellers.**
- Drive your target neighborhood and log at least 20 distressed or vacant properties.
- Look up the owners of at least 10 of those properties.
- Send your first direct-mail batch (150–300 pieces if your budget allows) or begin your call list.
- Make your first 20 seller calls. Log every call.

**Week 4 — Analyze and review.**
- Practice deal analysis on 5 properties (real listings or properties from your driving log). Calculate ARV, repairs, and MAO for each.
- Review your first month: leads, calls, cost per lead, buyer list size, and what you learned.
- Complete the Week 4 review in the workbook. Decide what to change for Month 2.

**End of Day 30 — Checkpoint.** You should have: an attorney's guidance on your state's rules, a buyers list of 20 to 25 names with criteria for at least 10, a tracking system in use, at least 50 seller contacts (calls, letters, or both), and at least 5 practice deal analyses. You may not have a contract yet. That is normal.

## Days 31–60: Activity and first offers

**Weeks 5–6 — Increase volume.**
- Mail your list a second time (same list, 30–45 days after the first mailing).
- Drive a second neighborhood, or drive your first neighborhood again for new properties.
- Make 20 to 30 seller calls per week. Follow up on every lead from Month 1 on schedule.
- Grow your buyers list to 40 names, with criteria for at least 20.

**Weeks 7–8 — Make offers.**
- By now you should have had at least a few longer conversations with motivated sellers. For each one where the numbers work, make a written offer at or below your maximum contract price.
- Walk at least 2 properties with a seller. Bring your repair checklist and, if possible, a contractor.
- If you sign a contract, follow Module 10 step by step: prepare the deal package, show it to your best buyers first, and get the assignment in writing.
- If you do not sign a contract, review why: were your offers too high, were the sellers not motivated, or were the properties not discounted enough? Adjust one variable at a time.

**End of Day 60 — Checkpoint.** You should have: at least 150 seller contacts in total, at least 10 practice or real deal analyses, at least 3 written offers, and a buyers list of 40 names. You may have your first contract. If you do not, you should know exactly why, and what you will change.

## Days 61–90: Close or learn

**Weeks 9–10 — Push the pipeline.**
- Mail your list a third time.
- Follow up systematically on every lead from Months 1 and 2. Many sellers become ready in this window.
- Continue 20 to 30 calls per week. Keep your weekly review disciplined.
- If you have a contract, work it to closing. If you have a failed deal, complete the deal review and apply the lesson.

**Weeks 11–12 — Review and decide.**
- Calculate your 90-day numbers: total marketing spend, cost per lead, cost per contract, cost per closing, and net fees.
- Review your buyers list: who is active, who is not, and who needs to be replaced.
- Decide whether to continue, adjust, or pause. The honest criteria: Are you getting leads? Are you getting offers accepted? Are your costs sustainable? Are you learning and improving? If the answers are yes, continue and increase volume modestly. If the answers are no, identify the specific bottleneck — list quality, call volume, analysis, or buyer list — and fix that one thing before you spend more.

**End of Day 90 — Checkpoint.** A realistic outcome for a consistent part-time beginner: 200 to 400 seller contacts, 10 to 20 offers, 1 to 3 signed contracts, and 0 to 2 closings, with assignment fees in the $3,000 to $8,000 range per closing if you close. Some beginners will do better; many will do worse. Either way, you will have a real pipeline, real numbers, and a clear sense of whether this business fits you. That is a successful 90 days, even if the closing count is zero — because you will know why, and you will have the system to fix it.

## What to do if you get stuck

- **No leads:** your list is too small, too old, or the wrong type. Change the list, not the whole business.
- **Leads but no offers:** your sellers are not motivated, or you are not asking the qualification questions. Review Module 5.
- **Offers but no contracts:** your offers are too high for the numbers, or you are not following up. Review Module 6 and Module 12.
- **Contracts but no closings:** your analysis is optimistic, or your buyer list is too thin. Review Module 6 and Module 9.
- **Overwhelmed:** cut back to one neighborhood, one list, and one channel. Do less, consistently, rather than more, sporadically.

### Action Steps — Module 13

1. Copy this 30/60/90-day plan into the workbook's 90-day tracker and write in your actual start date for Day 1.
2. Put the Week 1 tasks on your calendar now — including the attorney consultation.
3. At each 30-day checkpoint, complete the review in the workbook before you plan the next 30 days.

---

# Module 14 — Common Mistakes and How to Avoid Them

This module is the course in miniature: the mistakes below are the ones that cost beginners the most money, the most credibility, and the most time. Read it before your first call, and read it again after your first month.

## 1. Skipping the legal research

**The mistake:** starting to call sellers and sign contracts before checking your state's wholesaling rules.
**The cost:** regulator action, a void contract, a lawsuit, or a fine.
**How to avoid it:** complete Modules 1–3 and the state-rules checklist, and consult an attorney, before you contact a seller. No deal is worth starting without this.

## 2. Overestimating the ARV

**The mistake:** using the highest comp, a comp from a better neighborhood, or an online estimate as your ARV.
**The cost:** you overpay for the contract, the buyer rejects the deal, and the contract falls apart — or worse, a buyer closes and loses money.
**How to avoid it:** use three renovated comps in the same neighborhood, and use the conservative end of the range. If the deal only works at the optimistic ARV, it is not a deal.

## 3. Underestimating repairs

**The mistake:** pricing a renovation by what you can see, and forgetting the roof, the HVAC, the plumbing, and the foundation.
**The cost:** the buyer's contractor finds $15,000 you missed, the buyer walks, and your reputation with that buyer is damaged.
**How to avoid it:** walk the property with a checklist, price by category, add a 10–20% contingency, and get a contractor's opinion on anything beyond cosmetic work.

## 4. Forgetting your fee in the MAO

**The mistake:** calculating the MAO and then contracting at the MAO, leaving no room for your fee.
**The cost:** you either work for free, or you try to add a fee on top and the buyer rejects the deal.
**How to avoid it:** your maximum contract price is MAO minus your fee. Always. Write it on every deal analysis.

## 5. Contracting at a price above your maximum

**The mistake:** agreeing to the seller's price to "get the deal" and hoping a buyer will pay more.
**The cost:** a contract you cannot assign, a deposit at risk, and a seller who is disappointed when you cannot close.
**How to avoid it:** write your walk-away price before you negotiate, and do not exceed it. A deal you walk away from costs you nothing. A deal you force costs you money and credibility.

## 6. Marketing a property you do not own as if you are selling it

**The mistake:** posting a public listing for a house you have under contract, with no mention that you are selling a contract interest and no license.
**The cost:** regulator attention, and in some states, a violation of the licensing law.
**How to avoid it:** market to your buyers list, describe your contract interest accurately, and get your attorney's guidance on marketing before you post anything publicly.

## 7. Being unclear with the seller about your role

**The mistake:** letting the seller believe you are the end buyer who will live in the house, or that you are their agent.
**The cost:** a seller who feels misled, a complaint, and a deal that unravels at closing when the fee appears.
**How to avoid it:** disclose your role and your intent to assign, in writing, early, using your attorney's language for your state.

## 8. Not having a buyers list before you have a contract

**The mistake:** signing a purchase contract with 30 days to close and no one to sell it to.
**The cost:** a frantic search for buyers, a low fee to the first person who says yes, or a contract you cannot close.
**How to avoid it:** build the list first (Module 9). Do not sign a contract until you can name at least 5 buyers who buy in that area and price range.

## 9. Letting the inspection period expire without a decision

**The mistake:** signing a contract, getting busy, and realizing on day 16 that your 14-day inspection period ended on day 14.
**The cost:** you have lost your contractual right to cancel, and you may lose your deposit if you cannot close.
**How to avoid it:** put every contract deadline on your calendar the day you sign, with a reminder two days before. Review deadlines in your weekly review.

## 10. Poor follow-up

**The mistake:** calling a seller once, hearing "not yet," and never calling again.
**The cost:** the seller sells to someone else in three months — often to a wholesaler who followed up.
**How to avoid it:** every lead gets a next action and a date. Use the tracker. Follow up on schedule.

## 11. Spending on marketing before you have a system

**The mistake:** buying a 5,000-record list and mailing it once, with no tracking, no follow-up, and no buyer list.
**The cost:** hundreds of dollars spent, no way to know what worked, and no pipeline to show for it.
**How to avoid it:** start small, track everything, and scale the channel that produces leads at a cost you can afford.

## 12. Believing guaranteed-income claims

**The mistake:** trusting a course, video, or advertisement that promises a specific income from wholesaling.
**The cost:** unrealistic expectations, overspending, and quitting when the promised income does not appear in 30 days.
**How to avoid it:** judge the business by your own numbers after 90 days of consistent work. No one can promise you an income from a business you have not yet built.

### Action Steps — Module 14

1. Read this module once a month for your first six months. The mistake you are most likely to make changes as you gain experience.
2. After your first deal — successful or not — write down which of these mistakes you came closest to making, and what you will do differently.
3. Keep this course and the workbook where you work. The goal is not to memorize it; the goal is to use it when the pressure of a live deal makes it tempting to skip a step.

---

# Appendix A — State-by-State Legal Awareness Guide

**Read this appendix as a starting point for research, not as a statement of current law.** Laws change, and this guide cannot keep up with every change in every state. The descriptions below are general, high-level characterizations of the *kind* of restriction that has been discussed or enacted in each state. They are not legal conclusions, and they may be out of date. **Verify the current law in any state where you operate, and consult a licensed local real estate attorney before you act.**

## How to use this guide

For each state, the guide notes whether wholesaling there has been the subject of notably stricter rules — for example, a licensing requirement, a mandatory disclosure, or a restriction on marketing or assignment. If a state is listed, treat that as a flag to research it carefully. If a state is not listed, do not assume there are no restrictions — it may mean the rules are less publicized, or that they are set by regulator guidance rather than a single statute, or that the law is unsettled. Every state requires the same step: check the current statute and regulator guidance, and ask a local attorney.

## States with notably stricter wholesaling rules (as of the course's writing)

The following states have, in recent years (including 2024–2026), adopted or debated rules that materially affect wholesaling — most commonly a requirement that a wholesaler be licensed, a mandatory written disclosure to the seller (and sometimes to the buyer), or a restriction on advertising a property the wholesaler does not own. This list is illustrative, not exhaustive, and the specific rule in each state must be verified:

- **Illinois** — has enacted wholesaling-specific requirements, including disclosure obligations for wholesalers. Verify the current statute and its effective provisions with a local attorney.
- **Ohio** — has adopted rules affecting how wholesalers may operate, including disclosure and licensing-related provisions. Verify the current law.
- **Oklahoma** — has adopted wholesaling legislation addressing disclosure and related requirements. Verify the current law.
- **Pennsylvania** — has seen legislative and regulatory attention to wholesaling, including disclosure proposals. Verify the current law and any regulator guidance.
- **Texas** — has adopted disclosure requirements for certain wholesale transactions. Verify the current statute and what it requires to be disclosed, to whom, and when.
- **Indiana, Georgia, Florida, and other states** — have seen bills, regulator guidance, or enforcement attention related to wholesaling in recent years. The status in each of these states should be checked individually; a bill that was pending when this course was written may have passed, failed, or been amended since.

## States where the law is commonly described as less restrictive — and why that still requires verification

Some states are commonly described by wholesalers as more permissive — for example, states where assigning a contract you hold is generally treated as selling your own interest and does not by itself require a license. That description is a generalization, not a guarantee. Even in those states, marketing a property you do not own, acting for a seller for a fee, or doing wholesaling repeatedly as a business may still raise licensing questions, and disclosure, advertising, and solicitation laws still apply. Do not operate in any state on the basis of a generalization. Verify.

## What to research for every state

Use the state-rules research checklist in the workbook. For each state, find and note:

1. Does the state require a real estate license to wholesale, or to market a property you do not own?
2. Is there a wholesaling-specific disclosure requirement? What must be disclosed, to whom, in what form, and by when?
3. Are there restrictions on assigning a purchase contract, or on advertising an assignment?
4. Are there special protections for sellers in foreclosure, probate, or other distressed situations?
5. What are the penalties for a violation?
6. Has the state's real estate commission or regulator issued guidance on wholesaling?
7. What does a local real estate attorney in that state advise for your planned activity?

Record the source, the date you checked it, and the attorney's name and advice. Re-check at least once a year.

---

# Appendix B — Glossary

- **ARV (After-Repair Value):** the estimated resale value of a property after it is fully renovated.
- **Assignment:** the transfer of a party's rights under a contract to another party.
- **Assignment fee:** the amount a wholesaler is paid for assigning a purchase contract to an end buyer.
- **Cash buyer:** an investor buyer who can close without a traditional mortgage.
- **Comps (comparable sales):** recently sold properties similar to a subject property, used to estimate value.
- **Double closing:** a transaction in which the wholesaler buys a property from the seller and then sells it to an end buyer, usually on the same day.
- **Driving for dollars:** searching for distressed properties by driving through neighborhoods.
- **Earnest money:** a good-faith deposit made by a buyer under a purchase contract.
- **Inspection / due-diligence period:** a contractual window during which a buyer may inspect a property and cancel the contract under the contract's terms.
- **MAO (Maximum Allowable Offer):** the most an investor can pay for a property and still make a profit, commonly calculated as (ARV × 0.70) − repair costs.
- **Motivated seller:** a property owner with a reason to sell quickly, often at a discount.
- **Skip tracing:** finding contact information for a property owner from public and other lawful data sources.
- **Transactional funding:** a short-term loan used to fund a purchase in a double closing, repaid the same day from the sale proceeds.
- **Wholesaling:** finding a property, putting it under contract at a discount, and transferring that contract (or the property, in a double closing) to an investor buyer for a fee or spread.

---

# Appendix C — Resources and Next Steps

- **Your attorney.** The most important resource in this course. Keep their contact information with your deal files.
- **Your title company or closing attorney.** Build the relationship before you need it. Ask them what they require for an assignment and for a double closing.
- **Your local real estate investor association or meetup.** The fastest way to meet buyers, contractors, and other wholesalers in your market.
- **Your county assessor / tax office and recorder's office.** The source for ownership, tax, and lien information. Most offer online access.
- **The National Do Not Call Registry (donotcall.gov).** Scrub your call lists before you dial.
- **Your state's real estate commission or regulator.** The source for licensing rules and any wholesaling guidance in your state.
- **A local contractor who works with investors.** Your best teacher on repair costs.

**Next steps after this course:** complete the 30/60/90-day plan in Module 13, work the workbook, and make your first 100 seller contacts. Then come back to this manual — Modules 6, 8, and 14 in particular — and read them again with real deals in mind. The second reading will teach you more than the first.

---

*This course is real estate education only, not individualized legal, investment, or financial advice. Verify current law in your state and consult a qualified local attorney and professional for your situation. No income is guaranteed.*
