# The Wholesaling Fast-Start Academy — Companion Workbook

> **Disclaimer:** This workbook is real estate education only, not individualized legal, investment, or financial advice. Verify current law in your state and consult a qualified local attorney and professional for your situation. No income is guaranteed.

Use this workbook alongside `content.md`. Print it, or copy it into a notebook or spreadsheet — the point is to write in it. A workbook you do not write in is a book you did not use.

---

## 1. Deal-Analysis Worksheet (MAO Formula — Blank)

Complete one worksheet for every property you consider. Do not make an offer until this page is complete.

**Property:** ________________________________________
**Address:** ________________________________________
**Seller:** ________________________________________ **Phone:** ____________________
**Date:** _______________ **Source of lead:** ____________________

### A. After-Repair Value (ARV)

| Comp | Address | Sale price | Sale date | Beds/Baths | Sq ft | Notes |
|------|---------|-----------|-----------|------------|-------|-------|
| 1 | | $ | | | | |
| 2 | | $ | | | | |
| 3 | | $ | | | | |

**ARV used (conservative end of the range): $ __________**

How I got the ARV (one sentence): ________________________________________

### B. Repair Costs

| Category | Estimate |
|----------|----------|
| Roof | $ |
| HVAC | $ |
| Plumbing | $ |
| Electrical | $ |
| Foundation / structural | $ |
| Kitchen | $ |
| Bathrooms | $ |
| Flooring | $ |
| Paint (interior / exterior) | $ |
| Windows / doors | $ |
| Exterior / landscaping / cleanup | $ |
| Other: ____________________ | $ |
| **Subtotal** | **$** |
| Contingency (10–20%) | $ |
| **Total repair cost** | **$** |

Did a contractor walk the property? ☐ Yes ☐ No — Contractor name: ____________________

### C. Maximum Allowable Offer (MAO)

- ARV × 0.70 = $ __________ × 0.70 = $ __________
- Minus total repair cost: $ __________ − $ __________ = **MAO: $ __________**
- Minus my target assignment fee: $ __________ − $ __________ = **Maximum contract price: $ __________**

### D. Sensitivity Check

| Scenario | ARV | Repairs | MAO | Max contract price |
|----------|-----|---------|-----|--------------------|
| Optimistic | $ | $ | $ | $ |
| Base case | $ | $ | $ | $ |
| Pessimistic | $ | $ | $ | $ |

Does the deal work in the pessimistic case? ☐ Yes ☐ No

### E. Seller Facts

- Asking price: $ __________  Amount owed (mortgage + liens): $ __________
- Seller's timeline: ____________________  Reason for selling: ____________________
- Other owners who must sign: ____________________
- Title issues known: ____________________  Tenant in place? ☐ Yes ☐ No

### F. Decision

☐ Make an offer at $ __________  ☐ Counter at $ __________  ☐ Pass — reason: ____________________
☐ Follow up on: _______________

---

## 2. Seller-Call Log

Log every call the day you make it. One row per call.

| Date | Seller / Address | Phone | Result (no answer / spoke / VM) | Motivation & timeline | Asking price | Next step & date | Do-not-contact? |
|------|------------------|-------|----------------------------------|------------------------|--------------|------------------|-----------------|
| | | | | | $ | | ☐ |
| | | | | | $ | | ☐ |
| | | | | | $ | | ☐ |
| | | | | | $ | | ☐ |
| | | | | | $ | | ☐ |
| | | | | | $ | | ☐ |
| | | | | | $ | | ☐ |
| | | | | | $ | | ☐ |
| | | | | | $ | | ☐ |
| | | | | | $ | | ☐ |

**Weekly totals:** Calls made: ______ Conversations: ______ Offers made: ______ Contracts signed: ______

**Most common objection this week:** ________________________________________
**My better answer for next week:** ________________________________________

---

## 3. Buyers-List Builder Worksheet

Add one row per buyer. A buyer without criteria recorded is not yet on your list.

| # | Buyer name | Phone / Email | Areas | Price range | Property types | Max repairs | Funding (cash / private / hard money) | Close speed | Best contact method | Active? |
|---|-----------|---------------|-------|-------------|----------------|-------------|----------------------------------------|-------------|---------------------|---------|
| 1 | | | | $ – $ | | $ | | | | ☐ |
| 2 | | | | $ – $ | | $ | | | | ☐ |
| 3 | | | | $ – $ | | $ | | | | ☐ |
| 4 | | | | $ – $ | | $ | | | | ☐ |
| 5 | | | | $ – $ | | $ | | | | ☐ |
| 6 | | | | $ – $ | | $ | | | | ☐ |
| 7 | | | | $ – $ | | $ | | | | ☐ |
| 8 | | | | $ – $ | | $ | | | | ☐ |
| 9 | | | | $ – $ | | $ | | | | ☐ |
| 10 | | | | $ – $ | | $ | | | | ☐ |

**My top 5 buyers (know these well):**
1. ____________________ — buys: ____________________
2. ____________________ — buys: ____________________
3. ____________________ — buys: ____________________
4. ____________________ — buys: ____________________
5. ____________________ — buys: ____________________

**Goal:** 25 buyers with complete profiles by Day 30. Current count: ______

---

## 4. 90-Day Launch Tracker

Start date (Day 1): _______________  Day 30: _______________  Day 60: _______________  Day 90: _______________

### Weekly tracker (one row per week)

| Week | Dates | Leads | Calls | Letters sent | Offers | Contracts | Closings | Marketing spend | Notes |
|------|-------|-------|-------|--------------|--------|-----------|----------|-----------------|-------|
| 1 | | | | | | | | $ | |
| 2 | | | | | | | | $ | |
| 3 | | | | | | | | $ | |
| 4 | | | | | | | | $ | |
| 5 | | | | | | | | $ | |
| 6 | | | | | | | | $ | |
| 7 | | | | | | | | $ | |
| 8 | | | | | | | | $ | |
| 9 | | | | | | | | $ | |
| 10 | | | | | | | | $ | |
| 11 | | | | | | | | $ | |
| 12 | | | | | | | | $ | |
| 13 | | | | | | | | $ | |

### 30-day checkpoints

**Day 30 review:** Leads: ______ Calls: ______ Buyers on list: ______ Practice analyses: ______
What worked: ________________________________________
What to change: ________________________________________

**Day 60 review:** Leads (total): ______ Offers: ______ Contracts: ______
What worked: ________________________________________
What to change: ________________________________________

**Day 90 review:**
- Total marketing spend: $ ______  Total fees collected: $ ______  Net before taxes: $ ______
- Cost per lead: $ ______  Cost per contract: $ ______  Cost per closing: $ ______
- Leads → offers: ______%  Offers → contracts: ______%  Contracts → closings: ______%
- Continue / adjust / pause — and why: ________________________________________

---

## 5. State-Rules Research Checklist

Complete this for your state **before** you contact any seller. Repeat at least once a year, and again before operating in a new state.

**State:** ____________________  **Date researched:** _______________

| # | Question | Answer | Source (statute / regulator / attorney) | Date checked |
|---|----------|--------|------------------------------------------|--------------|
| 1 | Do I need a real estate license to wholesale in this state? | | | |
| 2 | Is there a wholesaling-specific disclosure requirement? What must be disclosed, to whom, in what form, and by when? | | | |
| 3 | Are there restrictions on assigning a purchase contract? | | | |
| 4 | Are there restrictions on advertising / marketing a property I do not own, or on marketing my contract interest? | | | |
| 5 | Are there special protections for sellers in foreclosure, probate, or other distressed situations? | | | |
| 6 | What are the penalties for a violation? | | | |
| 7 | Has the state real estate commission or regulator issued guidance on wholesaling? What does it say? | | | |
| 8 | What does my local real estate attorney advise for my planned activity? | | | |

**Attorney consulted:** ____________________  **Date:** _______________  **Advice summary:** ________________________________________

**My state's rule in one sentence (in my own words):** ________________________________________

---

## 6. Deal Tracker Table

One row per deal, from first contact to closing (or to dead). Also use `templates/deal-tracker.csv` for the spreadsheet version.

| Address | Seller | ARV | Repairs | MAO | Offer | Contract price | Assignment fee | Buyer | Status | Follow-up date |
|---------|--------|-----|---------|-----|-------|----------------|----------------|-------|--------|----------------|
| | | $ | $ | $ | $ | $ | $ | | | |
| | | $ | $ | $ | $ | $ | $ | | | |
| | | $ | $ | $ | $ | $ | $ | | | |
| | | $ | $ | $ | $ | $ | $ | | | |
| | | $ | $ | $ | $ | $ | $ | | | |
| | | $ | $ | $ | $ | $ | $ | | | |
| | | $ | $ | $ | $ | $ | $ | | | |
| | | $ | $ | $ | $ | $ | $ | | | |

**Status key:** New lead / Contacted / Offer made / Under contract / Assigned / Closed / Dead / Follow-up

### Deal review (complete within 24 hours of closing — or of a deal falling apart)

**Address:** ________________________________________  **Outcome:** ☐ Closed ☐ Fell apart
**Fee collected (if closed):** $ __________  **Marketing cost on this deal:** $ __________
**What went well:** ________________________________________
**What went wrong / what I would do differently:** ________________________________________
**Lesson for the next deal:** ________________________________________

---

## 7. Property Walk-Through Checklist

Take this on every property walk. Check each item and note its condition.

- ☐ Roof — age, visible damage, leaks: ____________________
- ☐ HVAC — age, working? ____________________
- ☐ Water heater — age: ____________________
- ☐ Electrical panel — age, capacity: ____________________
- ☐ Plumbing — leaks, water pressure, sewer/septic: ____________________
- ☐ Foundation — cracks, settling, water in basement/crawlspace: ____________________
- ☐ Windows — condition, count needing replacement: ____________________
- ☐ Kitchen — cabinets, counters, appliances: ____________________
- ☐ Bathrooms — count, condition: ____________________
- ☐ Flooring — type, condition by room: ____________________
- ☐ Paint — interior / exterior: ____________________
- ☐ Exterior — siding, gutters, driveway, landscaping: ____________________
- ☐ Signs of water damage or mold: ____________________
- ☐ Signs of pests: ____________________
- ☐ Photos taken? ☐ Yes ☐ No — Video walk-through? ☐ Yes ☐ No

**Overall condition:** ☐ Light cosmetic ☐ Moderate ☐ Heavy ☐ Full gut
**My repair estimate:** $ __________  **Contractor's estimate (if any):** $ __________
