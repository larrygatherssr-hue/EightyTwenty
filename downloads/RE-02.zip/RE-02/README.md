# The Wholesaling Fast-Start Academy (RE-02)

**Price:** $697 one-time · **Category:** Real Estate · **SKU:** RE-02

Your first real estate deal with little or no capital — find sellers, contract deals, assign to buyers.

## Files in this product

| File | Description |
|------|-------------|
| `content.md` | The full course manual — 14 modules in full prose, with worked examples, a state-by-state legal awareness guide, glossary, and resources appendix |
| `workbook.md` | Companion workbook — MAO deal-analysis worksheet, seller-call log, buyers-list builder worksheet, 90-day launch tracker, state-rules research checklist, deal tracker table, property walk-through checklist |
| `templates/deal-tracker.csv` | Deal tracker spreadsheet (property address, seller, ARV, repairs, MAO, offer, contract price, assignment fee, buyer, status, follow-up date) |
| `templates/seller-scripts.md` | Cold-call, absentee-owner, follow-up, text, and door-knock scripts, plus objection handling and a direct-mail letter |
| `templates/assignment-contract-template.md` | Plain-English assignment contract template with blanks — educational only, must be reviewed by a licensed attorney in the buyer's state before use |
| `templates/buyers-list-builder.md` | Buyer profile template for building a cash-buyers list from zero |
| `sales-page.md` | Full sales page — headline, problem, solution, what's inside, who it is/is not for, price + 14-day guarantee, FAQ, disclaimer |
| `listing.json` | EightyTwenty marketplace listing data (valid JSON, price_cents 69700) |
| `cover.md` | Cover design brief — black-and-gold luxury branding |
| `cover.*` | Cover image (generated) |
| `onboarding.md` | Customer onboarding guide — what to do first, how to use each file, suggested 4-week schedule, support |
| `README.md` | This file — index of the product's files |

## Disclaimer

This product is real estate education only, not individualized legal, investment, or financial advice. The buyer should verify current law in their state and consult a qualified local attorney and professional for their situation. No income is guaranteed.
