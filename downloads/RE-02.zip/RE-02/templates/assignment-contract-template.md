# Assignment of Contract — Template (Educational Only)

> **IMPORTANT — READ THIS FIRST. This template is for education only. It is NOT legal advice, and it is NOT a substitute for a licensed attorney in your state. Do NOT use this template to assign a contract until a licensed real estate attorney in the state where the property is located has reviewed it, adapted it to that state's law, and confirmed that assignment is lawful for your transaction. Laws differ by state, several states changed their wholesaling rules in 2024–2026, and some states require specific disclosures or a license. Using an unreviewed template can result in a void assignment, a lawsuit, or regulator action. If any part of this template conflicts with your state's law or with your purchase contract, your state's law and your purchase contract control.**

---

## ASSIGNMENT OF REAL ESTATE PURCHASE CONTRACT

**Date:** ____________________

### Parties

**Assignor (the original buyer under the purchase contract):**
Name: ________________________________________
Address: ________________________________________
Phone / Email: ________________________________________

**Assignee (the new buyer):**
Name: ________________________________________
Address: ________________________________________
Phone / Email: ________________________________________

### The Purchase Contract

The Assignor and the Seller named below entered into a Real Estate Purchase Contract dated ____________________ (the "Purchase Contract") for the property described below (the "Property"):

**Property address:** ________________________________________
**Seller(s):** ________________________________________
**Purchase price under the Purchase Contract:** $ ____________________
**Closing date under the Purchase Contract:** ____________________

A copy of the Purchase Contract is attached to this Assignment as Exhibit A. [Note: attach the full purchase contract, and confirm with your attorney how the seller's private information should be handled.]

### Assignment

1. **Assignment.** The Assignor assigns to the Assignee all of the Assignor's rights, title, and interest in and under the Purchase Contract, including the right to purchase the Property on the terms stated in the Purchase Contract.
2. **Acceptance.** The Assignee accepts the assignment and agrees to perform the Assignor's obligations under the Purchase Contract, including payment of the purchase price at closing, subject to the terms of the Purchase Contract.
3. **Assignment fee.** In consideration for this assignment, the Assignee agrees to pay the Assignor an assignment fee of $ ____________________ (the "Assignment Fee"). [Your attorney should advise whether the fee should be stated here, on the settlement statement, or both — and whether your state requires the fee to be disclosed to the Seller.]
4. **Payment of the fee.** The Assignment Fee is payable at closing, through the settlement statement, at the same time the Assignee closes on the purchase of the Property under the Purchase Contract. If the closing does not occur, the Assignment Fee is not payable, unless the parties agree otherwise in writing. [Confirm this term with your attorney — do not assume it.]
5. **Representations by the Assignor.** The Assignor represents that: (a) the Purchase Contract is in full force and effect; (b) the Assignor has not previously assigned the Purchase Contract; (c) the Purchase Contract permits assignment [or: the Seller has consented to this assignment in writing — attach the consent if required]; and (d) the Assignor has disclosed to the Assignee all material information in the Assignor's possession about the condition of the Property and the status of the transaction. [Your attorney should review and adapt these representations to your state and your contract.]
6. **No representation about the Property.** The Assignor makes no warranty about the condition, value, title, or suitability of the Property. The Assignee has had, or has waived, the opportunity to inspect the Property and to conduct their own due diligence, and is relying on their own investigation, not on any statement by the Assignor.
7. **Seller consent / notice.** [Include this paragraph only as your attorney directs.] The Seller [has been notified of this assignment / has consented to this assignment in writing, a copy of which is attached as Exhibit B]. If the Purchase Contract requires the Seller's consent to an assignment, that consent must be obtained before this Assignment is effective.
8. **Assignor's remaining liability.** [Your attorney must advise on this point.] Unless the Purchase Contract and this Assignment expressly release the Assignor, the Assignor may remain liable under the Purchase Contract if the Assignee fails to perform. The parties should confirm with their attorneys whether this Assignment releases the Assignor, and state the answer here in plain language.
9. **Earnest money.** The earnest money deposit under the Purchase Contract is $ ____________________, held by ____________________. [State who holds it, whether the Assignee reimburses it, and what happens to it if the transaction does not close — as your attorney directs.]
10. **Governing law.** This Assignment is governed by the laws of the State of ____________________.
11. **Entire agreement.** This Assignment, together with the Purchase Contract, is the entire agreement between the Assignor and the Assignee with respect to the assignment of the Purchase Contract. Any change must be in writing and signed by both parties.
12. **Counterparts and signatures.** This Assignment may be signed in counterparts, each of which is an original.

### Signatures

**Assignor:**
Signature: ________________________________________ Date: _______________
Printed name: ________________________________________

**Assignee:**
Signature: ________________________________________ Date: _______________
Printed name: ________________________________________

---

## Seller Disclosure and Acknowledgment (Have Your Attorney Adapt This to Your State)

> Some states require a written disclosure to the Seller before or at the time the Seller signs the Purchase Contract. The wording, timing, and form of that disclosure are state-specific. Do not use the paragraph below as a substitute for your state's required disclosure. Ask your attorney for the exact disclosure language for your state and use it verbatim.

**Seller acknowledgment (example language only — adapt as your attorney directs):**

The Seller acknowledges that they have been informed that: (a) the Assignor is an investor buyer and is not purchasing the Property to live in it; (b) the Assignor may assign the Purchase Contract to another buyer and may be paid a fee for doing so; (c) the Seller has the right to have an attorney or real estate agent review the Purchase Contract and this Assignment before signing; and (d) the Assignor is not a licensed real estate agent [if true] and is not acting as the Seller's agent.

**Seller signature:** ________________________________________ Date: _______________
**Seller printed name:** ________________________________________

---

## Checklist Before You Use This Template

- ☐ A licensed real estate attorney in the property's state has reviewed and adapted this template.
- ☐ The Purchase Contract permits assignment, or the Seller has consented in writing.
- ☐ The disclosure required by your state has been given to the Seller, in the required form and at the required time.
- ☐ The Assignee has inspected the Property or waived inspection in writing, and has shown proof of funds.
- ☐ The title company or closing attorney has a copy of the Purchase Contract and this Assignment.
- ☐ The Assignment Fee is stated correctly and will appear on the settlement statement as your attorney directs.
- ☐ Every blank is filled in, every exhibit is attached, and every party has a signed copy.
