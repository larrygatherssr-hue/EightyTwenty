# Seller Scripts — Cold Call, Text, and Door Knock

> Adapt these scripts to your voice, your market, and your attorney's guidance. Never read a script word for word in a way that sounds like you are reading. Before you call or text anyone, scrub your list against the National Do Not Call Registry, honor every do-not-contact request immediately, and confirm with a local attorney that your calling and texting comply with federal and state law, including the Telephone Consumer Protection Act. Do not text anyone unless your attorney confirms you have a lawful basis to do so.

---

## 1. Cold-Call Script — Motivated Seller (First Call)

**Opening:**
"Hi, this is [your name]. I'm a local homebuyer — I buy houses in [neighborhood] — and I'm calling about the property at [address]. Do you have a quick minute?"

**If yes — qualify:**
- "Are you the owner of the property?"
- "Do you live there, or is it a rental / vacant?"
- "What has you thinking about selling?"
- "How long have you owned the home?"
- "What kind of condition is it in — does it need any work?"
- "If you sold, what would your timeline look like?"
- "Is there a mortgage on the property, and roughly what is owed?"

**If they are motivated — discuss price honestly:**
"Based on the condition and the repairs it needs, I'd be in the range of [price]. I know that's below what a renovated house would sell for — the difference is the cost of the repairs and the fact that I buy as-is and close quickly. Does that range work for you, or are we too far apart?"

**Next step:**
"Would it help if I came by to walk the property, so I can give you a firm number? I'm free [day/time] or [day/time] — which works better for you?"
Confirm their best phone number and email before you end the call.

**Close:**
"Thank you for your time. I'll [send the offer / call you back on (date) / see you on (date)]. Here's my number if anything comes up: [your number]."

**If no / not interested:**
"No problem at all — thank you for your time. I'll remove you from my list so you won't hear from me again." (Then do it, immediately, and log it.)

**If voicemail:**
"Hi, this is [your name], a local homebuyer in [neighborhood]. I'm interested in the property at [address] and wanted to see if you might be open to selling. My number is [your number]. No pressure at all — if you're not interested, just ignore this. Thank you."

---

## 2. Cold-Call Script — Absentee Owner

**Opening:**
"Hi, this is [your name]. I'm a local homebuyer, and I'm calling about the property you own at [address]. Do you have a quick minute?"

**Qualify:**
- "Are you still the owner of that property?"
- "Is it rented right now, or vacant?"
- "How is the rental going for you — are you happy keeping it, or have you thought about selling?"
- "What kind of condition is it in?"
- "If you did sell, what would your timeline look like?"

Then follow the price conversation and next step from Script 1.

---

## 3. Follow-Up Call Script

"Hi [name], this is [your name] — we spoke [last week / last month] about your property at [address]. You mentioned [their timeline / situation]. I wanted to check in — has anything changed on your end, or is the timing still [what they said]?"

If they are ready: move to the price conversation and set a property walk.
If they are not ready: "No problem. When would be a good time for me to check back — [suggested date]?" Log the date and keep the promise.

---

## 4. Text Script — First Text (Use Only Where Lawful — See Note Above)

"Hi [name], this is [your name], a local homebuyer in [neighborhood]. I'm interested in your property at [address] and wanted to see if you might be open to selling. Would you be open to a quick call? No pressure either way — my number is [your number]."

Send one text, then wait. Do not send a barrage. Do not text late at night. If they reply "stop" or "not interested," stop immediately and remove them from your list.

**Follow-up text (after a conversation, or where they invited a text):**
"Hi [name], it's [your name] — we spoke about [address]. Just checking in as promised. Are you still thinking about selling, or has the timing changed? Happy to walk the property whenever works for you."

---

## 5. Door-Knock Script

Knock, step back from the door, and smile. Be calm, brief, and respectful — you are a stranger at someone's home.

"Hi, I'm [your name] — I buy houses in this neighborhood. I noticed your property at [address] and wanted to see if you might be open to selling. I buy as-is and can close quickly. Do you have a minute to talk, or would you prefer I leave my card and you can call me if you're interested?"

If they are not interested: "No problem at all — thank you for your time." Leave a card only if they are willing to take one. Do not leave materials on a door where the owner has asked not to be contacted, and do not trespass on posted property.

If they are interested: ask the qualification questions from Script 1, briefly, and set a time to walk the property or to call back.

---

## 6. Handling Common Objections

**"How much will you pay?"**
"It depends on the condition and the repairs. If you can tell me a bit about the house, I can give you a realistic range, and if we walk the property I can give you a firm number."

**"That's too low."**
"I understand. A renovated house in your neighborhood sells for more — the difference is the repair cost and the fact that I buy as-is and close quickly. If the number doesn't work for you, I respect that. Would it help if I explained how I got to it?"

**"I need to think about it."**
"Of course. When would be a good time for me to check back — later this week, or next week?"

**"Are you a realtor?"**
"No, I'm not a realtor. I'm an investor buyer. I buy houses directly, and if it helps, you're welcome to have your own agent or attorney look at anything I send you."

**"Stop calling me."**
"I'm sorry — I'll remove you right now and you won't hear from me again." (Then do it immediately.)

---

## 7. Direct-Mail Letter (One Page — Adapt to Your Market)

> Dear [Owner Name],
>
> My name is [your name], and I buy houses in [neighborhood / city]. I'm writing because I'm interested in your property at [address].
>
> I buy houses as-is — no repairs, no cleaning, no showings — and I can close quickly, on a timeline that works for you. If you've thought about selling, I'd welcome a short, no-pressure conversation about what that could look like.
>
> You can reach me at [phone] or [email]. There is no obligation, and if you're not interested, please just disregard this letter.
>
> Thank you for your time,
>
> [Your name]
> [Phone] | [Email]

Have your attorney review this letter before you send it, and do not include any claim — about price, timing, or buyers — that you cannot honor.
