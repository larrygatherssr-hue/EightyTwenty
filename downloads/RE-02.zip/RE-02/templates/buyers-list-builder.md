# Buyers-List Builder

> Your buyers list is your real business asset. Build it before you need it. A list of 15 buyers whose criteria you know is worth more than a list of 200 names with no information. See Module 9 of the course and the buyers-list worksheet in `workbook.md`.

## How to use this file

1. Add one buyer per section below (copy the block as needed).
2. Fill in every field. If you do not know a field, that is your next question for that buyer.
3. Update the entry after every deal — what they liked, what they passed on, and why.
4. Review the list monthly. Remove buyers who never respond. Promote your most reliable buyers to the top of your call order.

---

## Buyer Profile (copy this block for each buyer)

**Name:** ________________________________________
**Phone:** ____________________ **Email:** ____________________
**How I found them:** ____________________ **Date added:** _______________

**What they buy:**
- Areas / neighborhoods: ________________________________________
- Price range: $ __________ – $ __________
- Property types: ☐ Single-family ☐ Multi-family ☐ Condo ☐ Land ☐ Other: __________
- Maximum repair budget: $ __________
- Renovation level: ☐ Cosmetic only ☐ Moderate ☐ Heavy / full gut

**How they fund purchases:** ☐ Cash ☐ Private money ☐ Hard money ☐ Other: __________
**Typical decision time:** ____________________ **Typical closing time:** ____________________
**Best way to reach them:** ☐ Phone ☐ Text ☐ Email — **Best time:** ____________________
**Has bought from a wholesaler before?** ☐ Yes ☐ No
**What makes a deal work for them:** ________________________________________
**What makes them pass:** ________________________________________

**Deals sent:** ______ **Deals closed:** ______ **Last contact:** _______________
**Notes:** ________________________________________

**Reliability:** ☐ Top buyer — call first ☐ Active ☐ Occasional ☐ Inactive — remove after 90 days of no response

---

## Where to find buyers (checklist)

- ☐ Local real estate investor meetup — date attended: _______________
- ☐ Local online investor group — group name: _______________
- ☐ "We buy houses" signs / ads called — count: ______
- ☐ Recent cash purchases from public records — count researched: ______
- ☐ Title company contact — name: _______________
- ☐ Investor-friendly real estate agent — name: _______________
- ☐ Other wholesalers — names: _______________

## Monthly buyers-list review

**Month:** _______________
- Total buyers on list: ______  Active (responded in last 30 days): ______
- Top 5 buyers this month: ________________________________________
- Buyers to remove: ________________________________________
- Buyers to add next month: ________________________________________
- One thing I learned about what my buyers want: ________________________________________
