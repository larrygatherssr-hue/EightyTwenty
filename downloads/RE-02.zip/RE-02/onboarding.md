# Customer Onboarding Guide — The Wholesaling Fast-Start Academy (RE-02)

Welcome. This guide tells you what to do first, how to use each file, and how to work through your first four weeks.

## What to do first

1. **Read Modules 1–3 of `content.md` before anything else.** Module 1 explains what wholesaling is and is not. Module 2 explains how the money is made. Module 3 explains the legal landscape — licensing, disclosure, marketing, and the state rule changes from 2024–2026. Do not contact a seller until you have read all three.
2. **Complete the state-rules research checklist** in `workbook.md` (Section 5) for your state. This is the single most important worksheet in the product.
3. **Book a consultation with a local real estate attorney.** Bring the questions from Module 3 and the contract forms you plan to use. Get the answers in writing if you can, and keep them with your deal files.
4. **Do not sign a purchase contract, market a property, or assign a contract until steps 1–3 are done.**

## How to use each file

| File | What it is | How to use it |
|------|-----------|---------------|
| `content.md` | The full course manual — 14 modules, appendices, worked examples | Read in order the first time; use as a reference after that |
| `workbook.md` | Companion workbook — worksheets, logs, trackers, checklists | Print it or copy it into a notebook/spreadsheet; write in it on every deal |
| `templates/deal-tracker.csv` | Deal tracker spreadsheet | Open in Excel / Google Sheets / LibreOffice; one row per deal; update it the day anything changes |
| `templates/seller-scripts.md` | Cold-call, text, and door-knock scripts + objection handling + direct-mail letter | Read out loud until they sound like you; adapt to your voice and your attorney's guidance |
| `templates/assignment-contract-template.md` | Plain-English assignment contract template with blanks | Educational only — must be reviewed by a licensed attorney in your state before use; do not use it unreviewed |
| `templates/buyers-list-builder.md` | Buyer profile template | One profile per buyer; fill in every field; review monthly |
| `sales-page.md` | The sales page copy for this product | Reference only — this is how the product is presented on the marketplace |
| `listing.json` | Marketplace listing data | Marketplace use — you do not need to do anything with this file |
| `cover.md` / `cover.png` (or `.jpg`) | Cover design brief and cover image | The product cover |

## Suggested 4-week schedule

**Week 1 — Foundation.**
Read Modules 1–3. Complete the state-rules checklist. Book the attorney consultation. Choose your target neighborhood. Set up the deal tracker and the 90-day tracker.

**Week 2 — Build the buyer list.**
Read Modules 4 and 9. Attend a local investor meetup or join an online investor group. Contact 10 potential buyers and record their criteria. Have your attorney review your contract form and disclosure language.

**Week 3 — Start finding sellers.**
Read Modules 5 and 6. Drive your target neighborhood and log distressed properties. Send your first direct-mail batch or begin your call list. Practice deal analysis on 5 properties.

**Week 4 — Analyze and review.**
Read Modules 7, 8, and 14. Complete 5 practice deal analyses. Review your first month in the workbook: leads, calls, cost per lead, buyer list size, and what you learned. Then follow the 30/60/90-day plan in Module 13 for Months 2 and 3.

## How to get support

If you have trouble accessing your downloads, or you want a refund within the 14-day money-back guarantee period, email the marketplace support address with your order number and a description of the issue. The support team will respond with help accessing your files or processing a refund.

Support cannot provide individualized legal, investment, or financial advice, and cannot review your contracts or your deals. For those questions, consult a qualified local attorney or professional in your state.

## A final note

Wholesaling rewards consistency more than speed. Read the foundation modules, verify the law in your state, build the buyer list, and work the pipeline for 90 days before you judge the business. The course is built to be used, not just read — the workbook, the tracker, and the scripts are where the learning becomes a deal.
