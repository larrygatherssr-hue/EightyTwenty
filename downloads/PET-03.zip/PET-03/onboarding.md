# Customer Onboarding Guide — The Professional Dog Trainer Academy (PET-03)

Welcome, and thank you for joining the academy. This guide tells you what to do first, how to use the materials, and how to get support.

## What you received

| File | What it is |
|---|---|
| `content.md` | The full course — 16 modules, 120 lessons |
| `workbook.md` | Companion workbook — 11 worksheets |
| `templates/` | 5 ready-to-use templates (2 CSV trackers, session plan, behaviour assessment form, client intake pack) |
| `certificate.md` | Certificate of completion template |
| `cover.png` | Product cover image |
| `sales-page.md` | The sales page copy for this product |
| `listing.json` | Marketplace listing data |
| `onboarding.md` | This guide |
| `README.md` | File index |

## Step 1 — Read the disclaimer (5 minutes)

Read the disclaimer at the top of `content.md` before you start training. In short: this programme uses humane, positive-reinforcement methods only. It is not a substitute for veterinary or veterinary-behaviourist care. If a dog shows illness, pain, sudden behaviour change, severe fear, or aggression that risks injury, stop the exercises for that behaviour and seek veterinary help first.

## Step 2 — Gather your equipment

You need: a dog to practise with (your own, or a friend's or family member's dog with the owner's permission), high-value treats cut small, a treat pouch, a flat collar or well-fitted harness, a 1.8 m (6 ft) lead, a long line (5–10 m), a clicker or a consistent marker word, and a mat or bed. No aversive equipment is used at any point in this programme.

## Step 3 — Set up your workbook

Print or copy the worksheets from `workbook.md`, or use the CSV templates in `templates/` on your computer:
- Start with Worksheet 1 (Dog Profile & Reward Ranking) — rank your dog's rewards before your first session.
- Open `templates/training-progress-tracker.csv` and `templates/skills-tracker.csv` and save copies for your dog.

## Step 4 — Start Module 1

Work through the modules in order — each one builds on the last. Read a lesson (10–20 minutes), then try its practical exercise with a dog the same day.

**Suggested schedule — 16 weeks, one module per week:**
- 3–5 training sessions per week, 5–15 minutes each.
- One rest day between hard sessions; always end a session while the dog is still succeeding.
- At the end of each week, complete the Module Check at the end of the module and update your Skills Tracker.

**If you already train dogs:** move faster through Modules 1–4 and spend longer on Modules 9–16 (behaviour cases and client work).

## Step 5 — Work the behaviour modules carefully

Modules 9–12 deal with behaviour problems. Always assess before acting (Module 9), work at the dog's pace, and refer to a veterinarian and a qualified behaviour professional for aggression, biting, severe fear, self-harm, or any sudden behaviour change. Knowing when to refer is a professional skill, not a failure.

## Step 6 — Complete your certificate project (Module 16)

To earn your certificate of completion, complete the three-part project: a training case study (at least 6 sessions over at least 3 weeks with one dog), a session demonstration with a reflective note, and a short written reflection (500–1,000 words). Use Worksheet 11 in the workbook as your checklist, then fill in your name and date on `certificate.md`.

## How to get support

- **Questions about the course, the files, or how to use the materials:** contact EightyTwenty marketplace support and quote SKU **PET-03**.
- **Questions about a specific dog's health or behaviour:** consult a licensed veterinarian or a qualified veterinary behaviourist. This programme does not provide individual veterinary or behaviour advice.
- **Refunds:** see the 14-day guarantee in the listing — contact marketplace support within 14 days of purchase.

## A final note

Train kindly, keep records, and be patient — with the dog and with yourself. Progress in dog training is measured in weeks, not days, and the trainers who last are the ones who never stop learning.
