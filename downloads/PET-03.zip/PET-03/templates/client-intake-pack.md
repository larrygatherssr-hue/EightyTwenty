# Client Intake Pack

Use this pack for every new client. Send the intake form before the first session, review it in advance, and bring the service agreement to the first consultation.

---

## Part 1 — Client Intake Form

Client name: ______________________ Phone: ______________________ Email: ______________________
Address: ______________________ How did you hear about us? ______________________
Dog's name: ______________________ Breed: ______________________ Age: ______ Sex: ______
Neuter status: __________ Weight: __________ Vet / practice: ______________________
Health (conditions, medication, allergies): __________________________________________
Goal (owner's words): __________________________________________________________
When did the problem start? __________________ What has changed? __________________
What have you tried? __________________________________________________________
Bite history: ☐ None ☐ Yes — details: ____________________________________________
Household: Adults ____ Children (ages) ____ Other animals ____
Daily routine: Exercise __________ Feeding __________ Alone time __________
What would success look like for you? __________________________________________

---

## Part 2 — Service Agreement (template — adapt to your local law and take advice before use)

**Services:** The trainer will provide the sessions or package described in the written plan agreed at the first consultation, using positive-reinforcement methods only. No aversive or punishment-based methods will be used.

**Fees & payment:** Fees are as agreed in writing before work begins. Payment is due as agreed (per session or per package). Cancellations with less than 24 hours' notice may be charged in full.

**Owner responsibilities:** The owner will follow the agreed homework, keep the dog's vaccinations and veterinary care up to date, disclose any bite history or health changes, and supervise the dog at all times outside sessions.

**Safety:** The owner understands that training involves live animals and some risk, and agrees to follow the trainer's safety instructions. The trainer will refer the owner to a veterinarian or qualified behaviour professional where a case is beyond foundation training.

**No guarantee:** No specific outcome is guaranteed. Results depend on the dog, the owner, consistency, environment, and health.

**Cancellation by the trainer:** The trainer may cancel or end the working relationship if safety is at risk or if the owner requests methods the trainer does not use. Fees for unused sessions will be refunded as agreed in writing.

Client signature: ______________________ Date: __________
Trainer signature: ______________________ Date: __________

---

## Part 3 — Referral Letter Template

Dear [Veterinarian / Behaviour Professional],

I am writing to refer [Owner name] and their dog [Dog name, age, breed] for [veterinary assessment / specialist behaviour support].

The presenting behaviour is: ____________________________________________________
It began on / around: __________________ and occurs: ______________________________
My assessment notes and ABC log are attached, with the owner's permission.
Bite history: ☐ None ☐ Yes — see attached notes.
I have advised the owner to seek your assessment before further training on this behaviour, and I am happy to support your plan with foundation training once it is in place.

Kind regards,
[Trainer name, contact details, date]

---

## Part 4 — Session Notes Template

Client: ______________________ Dog: ______________________ Date: __________
Session number: ______ / ______ Duration: __________ Location: ______________________
What we worked on: ____________________________________________________________
Dog's response: ____________________________________________________________
Owner's response / confidence: ____________________________________________________
Homework given (specific): ______________________________________________________
Next session date & focus: ______________________________________________________
Any safety or referral notes: ____________________________________________________
