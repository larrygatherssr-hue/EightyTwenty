# Training Session Plan Template

Dog: ______________________ Date: __________ Handler: ______________________
Session length: __________ minutes | Location: ______________________

## Goal for this session
(One specific, measurable behaviour — e.g. "Sit-stay for 10 seconds at 2 metres in the garden.")

## Starting point
(What the dog can do now, honestly measured.)

## Rewards
Marker: ______________________ Low-value reward: ______________________
High-value reward (for hard reps): ______________________

## Session structure

| Phase | Time | Activity | Reps planned |
|---|---|---|---|
| Warm-up | 0:00–2:00 | Easy known behaviours | |
| Set 1 | | New skill | |
| Break | | Play / sniff / rest | |
| Set 2 | | New skill, continued | |
| Cool-down | | Easy behaviour + fun ending | |

## Success criterion
Move on when the dog succeeds at least 8 times out of 10 at this step.

## Results
Successful reps: ______ / ______ ( ______% )
What went well: ____________________________________________________________
What to change next time: ____________________________________________________
Next step: ☐ Repeat this step ☐ Move to the next step ☐ Go back a step
