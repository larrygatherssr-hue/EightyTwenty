# Behaviour Assessment Form

Dog: ______________________ Owner: ______________________ Date: __________
Age / breed / sex: ______________________ Vet / practice: ______________________

## 1. Problem behaviour (owner's words)
______________________________________________________________________________

## 2. History
When did it start? __________________ What changed at that time? __________________
How often does it happen? __________________ How long does it last? __________________
Where does it happen? __________________ Who is usually present? __________________

## 3. What has been tried already, and what happened?
______________________________________________________________________________

## 4. Bite history
☐ None
☐ Yes — details (who, when, circumstances, injury): ______________________________

## 5. Medical
☐ Vet seen on __________ — findings: ____________________________________________
☐ Not yet seen — vet check recommended before training begins

## 6. Daily life
Exercise: __________________ Feeding: __________________ Alone time: __________________
Enrichment: __________________ Sleep: __________________
Household: Adults ____ Children (ages) ____ Other animals ____

## 7. ABC Log
Record at least 7 entries over a week before planning.

| Date / time | Antecedent | Behaviour | Consequence |
|---|---|---|---|
| | | | |
| | | | |
| | | | |
| | | | |
| | | | |
| | | | |
| | | | |

## 8. Likely function
☐ Attention ☐ Escape / avoidance ☐ Access to something ☐ Fear / anxiety relief
☐ Sensory / self-soothing ☐ Unclear — more observation needed

## 9. Baseline & goal
Baseline measurement: __________________________________________________________
Goal (specific & measurable): ____________________________________________________

## 10. Plan
Management steps: ____________________________________________________________
Training plan (brief): __________________________________________________________
Review date: __________ Referral needed? ☐ No ☐ Yes — to: ______________________

**Safety note:** If the behaviour involves aggression, biting, severe fear, self-harm, or a sudden change, seek veterinary advice first and refer to a qualified veterinary behaviourist or certified behaviour consultant. Do not attempt to work through a bite-risk behaviour alone.
