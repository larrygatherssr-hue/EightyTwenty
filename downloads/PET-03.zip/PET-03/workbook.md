# The Professional Dog Trainer Academy — Workbook

**PET-03 | Companion to content.md**

## Disclaimer

This workbook is part of an educational programme teaching humane, positive-reinforcement dog training only. It does not use or recommend aversive or punishment-based methods. It is not a substitute for veterinary care or veterinary-behaviourist care. If a dog shows signs of illness, pain, sudden behaviour change, severe fear, or aggression that risks injury, stop the exercises for that behaviour and seek help from a licensed veterinarian first, and a qualified veterinary behaviourist or certified behaviour consultant where appropriate. Never attempt to work through a bite-risk behaviour alone. This programme does not confer a regulated qualification or licence.

**How to use this workbook:** Print the worksheets you need, or copy them into a notebook or a digital document. Complete one worksheet per dog, per behaviour, per session. The workbook is designed to be used alongside content.md — each worksheet names the module and lesson it supports.

---

## Worksheet 1 — Dog Profile & Reward Ranking (Modules 1–3)

Dog's name: ______________________ Breed / mix: ______________________ Age: ________
Sex: ________ Neuter status: ________ Weight: ________ Vet / practice: ______________________
Health notes (conditions, medication, pain, allergies): ____________________________________
Owner / handler: ______________________ Household (adults, children, other animals): ______________

**Reward ranking test:** Offer two treats at a time and record which the dog chooses first. Repeat 5 times per pair.

| Treat / reward | Times chosen first (out of 5) | Value (Low / Medium / High) |
|---|---|---|
| Kibble | | |
| Commercial treats | | |
| Cheese pieces | | |
| Cooked chicken | | |
| Hot dog pieces | | |
| Toy / ball | | |
| Tug game | | |
| Sniffing / freedom | | |
| Other: __________ | | |

Low-value rewards are for: ______________________
High-value rewards are for: ______________________
Rewards this dog does NOT like or cannot have: ______________________

**Marker:** My marker is: ☐ Clicker ☐ Word: "__________" — Charged on (date): __________

---

## Worksheet 2 — Daily Routine & Enrichment Plan (Module 4)

Dog: ______________________ Week beginning: __________

| Time | Activity | Notes |
|---|---|---|
| Morning | Feed / toilet / walk | |
| Midday | Enrichment / training | |
| Afternoon | Walk / play / rest | |
| Evening | Feed / training / settle | |
| Night | Last toilet / sleep | |

**Enrichment this week (aim for at least 2 a day):**
- ☐ Kong / food puzzle — Day(s): __________
- ☐ Scatter feeding — Day(s): __________
- ☐ Snuffle mat — Day(s): __________
- ☐ Sniffy walk (dog chooses the route) — Day(s): __________
- ☐ Scent game / find it — Day(s): __________
- ☐ Digging pit — Day(s): __________
- ☐ Training game — Day(s): __________

**Management in place this week:**
1. Unwanted behaviour: __________________ Management: __________________
2. Unwanted behaviour: __________________ Management: __________________
3. Unwanted behaviour: __________________ Management: __________________

---

## Worksheet 3 — Training Session Plan (Modules 5–7, 13)

Dog: ______________________ Date: __________ Session length: __________ minutes
Behaviour / goal: ____________________________________________________________
Step in the progression: ______________________________________________________
Environment: ______________________ Distraction level (1–5): __________
Reward used & value: ______________________ Marker: ______________________

**Warm-up (2 min):** __________________________________________________________
**Set 1 (reps & result):** ______________________________________________________
**Break:** ____________________________________________________________________
**Set 2 (reps & result):** ______________________________________________________
**Cool-down:** ________________________________________________________________

**Results:** Successful repetitions: ______ out of ______ ( ______% )
**What went well:** __________________________________________________________
**What to change next time:** __________________________________________________
**Next step:** ☐ Repeat this step ☐ Move to the next step ☐ Go back a step

---

## Worksheet 4 — Behaviour Assessment Form (Module 9)

Dog: ______________________ Owner: ______________________ Date: __________
Age / breed / sex: ______________________ Vet: ______________________
**Problem behaviour (owner's words):** __________________________________________
**When did it start?** __________________ **What changed at that time?** __________________
**How often?** __________________ **How long does it last?** __________________
**Where does it happen?** __________________ **Who is present?** __________________
**What has been tried already, and what happened?** ____________________________________
**Bite history?** ☐ No ☐ Yes — details: ____________________________________________
**Medical check:** ☐ Vet seen on __________ ☐ Not yet seen — referral needed
**Daily routine / exercise / enrichment:** __________________________________________
**Household:** Adults ____ Children (ages) ____ Other animals ____

**ABC Log (complete at least 7 entries before planning):**

| Date / time | Antecedent (what happened before) | Behaviour (exactly what the dog did) | Consequence (what happened after) |
|---|---|---|---|
| | | | |
| | | | |
| | | | |
| | | | |
| | | | |
| | | | |
| | | | |

**Likely function:** ☐ Attention ☐ Escape / avoidance ☐ Access to something ☐ Fear / anxiety relief ☐ Sensory / self-soothing ☐ Unclear — more observation needed
**Baseline measurement:** ______________________________________________________
**Goal (specific & measurable):** ________________________________________________
**Management steps:** __________________________________________________________
**Training plan (brief):** ______________________________________________________
**Review date:** __________ **Referral needed?** ☐ No ☐ Yes — to: ______________________

---

## Worksheet 5 — Desensitisation & Counter-Conditioning Plan (Module 10)

Dog: ______________________ Trigger: ______________________ Date started: __________
**Distance / intensity hierarchy (easiest → hardest):**
1. ________________________________________________________________________
2. ________________________________________________________________________
3. ________________________________________________________________________
4. ________________________________________________________________________
5. ________________________________________________________________________
**High-value reward used only for this work:** ____________________________________
**Session record:**

| Date | Step | Distance / intensity | Dog's body language | Took treats? | Notes |
|---|---|---|---|---|---|
| | | | | ☐ Yes ☐ No | |
| | | | | ☐ Yes ☐ No | |
| | | | | ☐ Yes ☐ No | |
| | | | | ☐ Yes ☐ No | |
| | | | | ☐ Yes ☐ No | |

**Rule:** Move to the next step only after 3 consecutive relaxed sessions at the current step. If the dog shows fear, go back one step.

---

## Worksheet 6 — Puppy Socialisation Checklist (Module 8)

Puppy: ______________________ Age: __________ Week beginning: __________
For each item, record the response: R = Relaxed, C = Curious, U = Unsure, F = Frightened. If U or F, increase distance and pair with treats; do not force the puppy closer.

**People:** ☐ Adult men ☐ Adult women ☐ Children ☐ Elderly people ☐ Person in a hat ☐ Person in uniform ☐ Person with a walking stick / wheelchair
**Animals:** ☐ Calm adult dog ☐ Another puppy ☐ Cat (at a distance) ☐ Birds
**Sounds:** ☐ Traffic ☐ Vacuum (off, then on at a distance) ☐ Thunder recording (low volume) ☐ Fireworks recording (low volume) ☐ Doorbell ☐ Hair dryer
**Surfaces:** ☐ Grass ☐ Gravel ☐ Wood floor ☐ Metal grate ☐ Wet ground ☐ Stairs
**Places:** ☐ Vet waiting room (treat visit) ☐ Quiet café ☐ Pet shop ☐ Car (short ride) ☐ Park
**Handling:** ☐ Ears touched ☐ Paws held ☐ Mouth / teeth checked ☐ Collar touched ☐ Gentle hug / restraint ☐ Nail clipper shown

**Notes / items to repeat:** ______________________________________________________

---

## Worksheet 7 — Handling & Cooperative Care Checklist (Modules 2, 8)

Dog: ______________________ Date started: __________
For each item, record: ✓ = relaxed and taking treats, ~ = unsure, ✗ = uncomfortable — stop and go back a step.

| Handling item | Session 1 | Session 2 | Session 3 | Session 4 |
|---|---|---|---|---|
| Ears touched | | | | |
| Paws held | | | | |
| Each toe touched | | | | |
| Mouth / teeth checked | | | | |
| Collar put on / taken off | | | | |
| Body stroked all over | | | | |
| Tail touched | | | | |
| Nail clipper shown | | | | |
| Nail touched with clipper | | | | |
| Brushed | | | | |
| Held gently for 5 seconds | | | | |

---

## Worksheet 8 — Client Intake Form (Module 14)

Client name: ______________________ Phone: ______________________ Email: ______________________
Address: ______________________ How did you hear about us? ______________________
Dog's name: ______________________ Breed: ______________________ Age: ______ Sex: ______
Neuter status: __________ Weight: __________ Vet / practice: ______________________
**Health:** Conditions / medication / allergies: __________________________________________
**Goal (owner's words):** __________________________________________________________
**When did the problem start?** __________________ **What has changed?** __________________
**What have you tried?** __________________________________________________________
**Bite history:** ☐ None ☐ Yes — details (who, when, circumstances, injury): __________________
**Household:** Adults: ____ Children (ages): ____ Other animals: ____
**Daily routine:** Exercise: __________________ Feeding: __________________ Alone time: __________
**What does a typical day look like for your dog?** ____________________________________
**What would success look like for you?** __________________________________________
**Anything else we should know?** __________________________________________________
**Consent:** I confirm the information above is accurate. I understand that training uses positive-reinforcement methods only, that no outcome is guaranteed, and that I will be referred to a veterinarian or behaviour professional if needed.
Signature: ______________________ Date: __________

---

## Worksheet 9 — Skills Tracker (All Modules)

Dog / student: ______________________

| Skill | Module | Date introduced | Current level (1–5) | Reliable? (8/10) | Date achieved |
|---|---|---|---|---|---|
| Marker charged | 3 | | | ☐ | |
| Sit on cue | 5 | | | ☐ | |
| Down on cue | 5 | | | ☐ | |
| Stay 10 sec at 2 m | 5 | | | ☐ | |
| Release cue | 5 | | | ☐ | |
| Mat / place | 5 | | | ☐ | |
| Recall on long line | 6 | | | ☐ | |
| Leave it | 6 | | | ☐ | |
| Drop it | 6 | | | ☐ | |
| Loose-lead 20 steps | 7 | | | ☐ | |
| Four paws on floor greeting | 7 | | | ☐ | |
| Wait at door | 7 | | | ☐ | |
| Toilet routine (puppy) | 8 | | | ☐ | |
| Handling checklist complete | 8 | | | ☐ | |
| ABC log completed | 9 | | | ☐ | |
| DS/CC plan written | 10 | | | ☐ | |
| Look at That game | 10 | | | ☐ | |
| One-page training plan | 13 | | | ☐ | |
| 60-min session run | 13 | | | ☐ | |
| Client intake completed | 14 | | | ☐ | |
| Pricing worked out | 15 | | | ☐ | |
| Certificate project complete | 16 | | | ☐ | |

**Level key:** 1 = introduced, 2 = learning, 3 = mostly reliable at home, 4 = reliable in 3+ places, 5 = reliable with distractions.

---

## Worksheet 10 — Business Tracker (Module 15)

Month: __________

| Date | Client / service | Income | Expenses (travel, equipment, etc.) | Notes |
|---|---|---|---|---|
| | | | | |
| | | | | |
| | | | | |
| | | | | |
| | | | | |

**Monthly totals:** Income: $__________ Expenses: $__________ Net: $__________
**Clients this month:** __________ **Group class dogs:** __________ **Sessions delivered:** __________
**What worked:** ________________________________________________________________
**What to change next month:** ____________________________________________________

---

## Worksheet 11 — Certificate Project Checklist (Module 16)

Student name: ______________________ Start date: __________

**Part A — Training case study**
- ☐ Dog chosen and assessed (Behaviour Assessment Form completed)
- ☐ One-page training plan written
- ☐ 6+ sessions run over 3+ weeks
- ☐ Results recorded in the Training Progress Tracker
- ☐ Case study written up (dog, assessment, plan, results, reflection)

**Part B — Session demonstration**
- ☐ 30-minute session planned in writing
- ☐ Session run (one-to-one or with own dog)
- ☐ Reflective note written (what went well, what to change)

**Part C — Reflection (500–1,000 words)**
- ☐ What I learned
- ☐ My strengths
- ☐ What I will keep working on

**Completed on:** __________ **Certificate issued:** ☐ Yes — see certificate.md

---

## Weekly Review Prompts

Each week, answer these three questions in a few sentences:
1. What did the dog learn this week that it could not do last week?
2. What was the hardest moment, and what did it teach me?
3. What is the one thing I will focus on next week?
