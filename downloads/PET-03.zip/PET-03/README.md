# PET-03 — The Professional Dog Trainer Academy

**Price:** $397 (one-time) · **Category:** Pet Products & Pet Business · **SKU:** PET-03

A complete dog training education programme: obedience, behaviour, puppy foundations, and how to turn training skill into paid client work. 16 modules, 120 lessons, humane positive-reinforcement methods only.

## Files

| File | Description |
|---|---|
| `content.md` | The full course — 16 modules, 120 lessons, with worked examples, session plans, behaviour cases, and appendices |
| `workbook.md` | Companion workbook — 11 worksheets (reward ranking, session plans, behaviour assessment, DS/CC plan, puppy socialisation, handling, client intake, skills tracker, business tracker, certificate checklist) |
| `templates/training-progress-tracker.csv` | Session-by-session progress log (CSV) |
| `templates/skills-tracker.csv` | Skills tracker for all 16 modules (CSV) |
| `templates/training-session-plan-template.md` | One-page session plan template |
| `templates/behaviour-assessment-form.md` | Behaviour assessment form with ABC log |
| `templates/client-intake-pack.md` | Client intake form, service agreement template, referral letter template, session notes template |
| `certificate.md` | Certificate of completion template (fill in on completing the Module 16 project) |
| `sales-page.md` | Full sales page: headline, problem, solution, module list, who it is for / not for, price, FAQ, disclaimers |
| `listing.json` | Marketplace listing data (SKU, price, headline, description, delivery note, SEO keywords, refund policy, support) |
| `cover.md` | Cover design brief (black-and-gold luxury branding) |
| `cover.png` | Generated cover image (1280 × 1920 px) |
| `onboarding.md` | Customer onboarding guide: first steps, equipment, suggested 16-week schedule, support |
| `README.md` | This index |

## Start here
Read `onboarding.md`, then Module 1 of `content.md`. Print the worksheets you need from `workbook.md` and save copies of the CSV templates before your first session.
