# The Professional Dog Trainer Academy

## Obedience, Behaviour & Client-Ready Skills in One Academy

**EightyTwenty Academy — PET-03**

---

## Important Disclaimer — Please Read First

This programme teaches humane, positive-reinforcement dog training methods only. It does not use, recommend, or endorse aversive or punishment-based methods, including but not limited to shock collars, prong collars, choke chains used for correction, physical punishment, intimidation, flooding, or alpha/dominance-based confrontation.

This programme is an educational course. It is not a substitute for veterinary care, veterinary behaviourist care, or advice from a qualified animal behaviour professional. If a dog shows signs of illness, pain, sudden behaviour change, severe fear, or aggression that risks injury to people or animals, stop training exercises for that behaviour and seek help from a licensed veterinarian first, and a qualified veterinary behaviourist or certified behaviour consultant where appropriate. Never attempt to work through a bite-risk behaviour alone, and never place yourself, a client, or a dog in an unsafe situation to complete an exercise in this course.

No outcome is guaranteed. Every dog learns at a different pace, and results depend on the dog, the handler, consistency, environment, and health. This course does not confer a regulated professional qualification, licence, or certification, and it does not claim to. The certificate of completion included with this programme records that you completed the curriculum; it is not a licence to practise and does not replace any local legal, insurance, or professional-body requirements in your area. Check the rules where you live and work before taking paying clients.

Always train in a safe environment, keep dogs on lead where required by law, respect local leash and licensing laws, and carry appropriate insurance before working with other people's dogs.

---

## How to Use This Academy

This is a complete self-paced programme of 16 modules and 120 lessons. Work through the modules in order — each one builds on the last. A lesson takes 10–20 minutes to read, and most include a practical exercise to try with a dog the same day.

**Suggested pace:** one module per week over 16 weeks, with 3–5 short training sessions per week (5–15 minutes each). If you already train dogs, you may move faster through Modules 1–4 and spend longer on Modules 9–16, which cover behaviour cases and client work.

**What you need:** a dog to practise with (your own, or a friend's or family member's dog with the owner's permission), high-value treats cut small, a treat pouch, a standard flat collar or harness, a 1.8 m (6 ft) lead, a long line (5–10 m), a clicker or a consistent marker word, a mat or bed, and the workbook that comes with this programme. No special equipment is required, and no aversive equipment is used at any point.

**How the programme is organised:**

- **Foundations (Modules 1–4):** how dogs learn, communication, safety, and your training toolkit.
- **Core Skills (Modules 5–8):** obedience, recall, loose-lead walking, and puppy foundations.
- **Behaviour (Modules 9–12):** fear, reactivity, separation-related behaviour, and behaviour assessment.
- **Professional Practice (Modules 13–16):** session planning, client work, business basics, and your certificate project.

At the end of each module you will find a **Module Check** — a short list of skills you should be able to demonstrate before moving on. Use the Skills Tracker in the workbook to record your progress.

---

## Table of Contents

- Module 1 — How Dogs Learn: The Science in Plain English (Lessons 1–7)
- Module 2 — Reading the Dog: Body Language, Stress & Safety (Lessons 8–14)
- Module 3 — The Trainer's Toolkit: Rewards, Markers & Equipment (Lessons 15–22)
- Module 4 — Setting Up for Success: Environment, Management & Prevention (Lessons 23–29)
- Module 5 — Core Obedience I: Sit, Down, Stay & Release (Lessons 30–38)
- Module 6 — Core Obedience II: Recall, Leave It & Drop It (Lessons 39–46)
- Module 7 — Loose-Lead Walking & Polite Greetings (Lessons 47–54)
- Module 8 — Puppy Foundations: Socialisation, Toilet Training & Early Manners (Lessons 55–62)
- Module 9 — Understanding Behaviour Problems: Assessment Before Action (Lessons 63–70)
- Module 10 — Fear, Anxiety & Reactivity: Desensitisation & Counter-Conditioning (Lessons 71–79)
- Module 11 — Separation-Related Behaviour, Barking & Destructive Behaviour (Lessons 80–87)
- Module 12 — Aggression & Bite Risk: Recognition, Safety & Referral (Lessons 88–94)
- Module 13 — Designing Training Plans & Running a Session (Lessons 95–102)
- Module 14 — Working with Clients: Intake, Communication & Coaching People (Lessons 103–110)
- Module 15 — Turning Skill into Paid Work: Pricing, Packages & Business Basics (Lessons 111–116)
- Module 16 — Your Certificate Project: Assessment, Portfolio & Next Steps (Lessons 117–120)
- Appendix A — Training Session Plan Library
- Appendix B — Behaviour Case Examples
- Appendix C — Quick-Reference Cue Library
- Appendix D — Recommended Further Learning & Professional Bodies

---

# MODULE 1 — How Dogs Learn: The Science in Plain English

## Lesson 1 — Why Training Works at All

Dogs repeat behaviour that works for them. That single sentence is the foundation of everything in this academy. When a dog sits and a treat follows, sitting becomes more likely. When a dog jumps up and gets attention — even shouting counts as attention — jumping becomes more likely. Your job as a trainer is to arrange the world so that the behaviour you want is the behaviour that works best for the dog, and to make that arrangement clear, consistent, and kind.

Training is not about dominance, and it is not about the dog "respecting" you. Dogs do not form a hierarchy with people in the way old dominance theories claimed; that idea came from misread observations of captive wolves and has been widely corrected by the researchers who first popularised it. What dogs actually do is learn from consequences. That is good news: it means you can change behaviour without force, fear, or confrontation, and the change lasts because the dog has genuinely learned, not because it is afraid.

**Exercise:** For one day, keep a small notebook. Every time your practice dog does something, note what happened immediately afterwards. Did the behaviour get a reward (food, attention, access to something, freedom)? You will start to see the pattern within hours.

## Lesson 2 — Classical Conditioning: Associations Matter

Classical conditioning is learning by association. A dog hears the lead clip and gets excited because the lead predicts a walk. A dog hears the doorbell and barks because the doorbell predicts a stranger. You did not teach either of those responses directly — the dog's brain linked two things together.

Trainers use classical conditioning deliberately. Pair something a dog is unsure about — a stranger, a loud noise, a vet's waiting room — with something wonderful, like chicken, and over time the dog's emotional response to that thing changes. This is called counter-conditioning, and it is the engine of Module 10. The key rules are: the good thing must follow the scary thing (never the other way around), it must be genuinely good from the dog's point of view, and you must work at a distance and intensity the dog can cope with.

**Worked example:** A dog is nervous about the vacuum cleaner. You place the vacuum, switched off, 5 metres away. Each time the dog looks at it, you deliver a treat. After several sessions the dog sees the vacuum and looks to you happily — the association has changed. Only then do you move the vacuum 30 cm closer, or switch it on for two seconds at a distance. Rushing this step is the most common mistake in behaviour work.

## Lesson 3 — Operant Conditioning: The Four Consequences

Operant conditioning describes how consequences change behaviour. There are four types:

1. **Positive reinforcement** — add something good to increase a behaviour (treat for sitting). This is the academy's main tool.
2. **Negative reinforcement** — remove something unpleasant to increase a behaviour (releasing leash pressure when the dog moves toward you). Used carefully and gently, mainly in the form of removing mild pressure; never used as punishment.
3. **Positive punishment** — add something unpleasant to decrease a behaviour. **Not used in this programme.**
4. **Negative punishment** — remove something good to decrease a behaviour (turning away and removing attention when a dog jumps). Used sparingly and calmly.

Positive reinforcement is the most effective and the most humane route to reliable behaviour, and it is the method used throughout this course. It also builds a dog that enjoys working with you, which matters enormously when you are asking a dog to choose your instructions over a squirrel.

## Lesson 4 — Reinforcement Schedules: From Every Time to Real Life

When you first teach a behaviour, reward it every single time it happens. This is a continuous schedule, and it builds learning fast. Once the dog knows the behaviour well, move gradually to rewarding the best responses — the fastest sit, the straightest recall — and then to rewarding intermittently. A behaviour rewarded on a variable, unpredictable schedule is the most resistant to extinction; this is why a dog that is sometimes rewarded for coming when called keeps coming.

Never stop rewarding altogether. "He should do it because I said so" is not a training plan. Even well-trained dogs need maintenance rewards, especially for difficult behaviours like recall away from distractions. In real life, the reward does not always have to be food: access to the garden, a thrown ball, permission to greet a friend, and a sniff of an interesting lamppost are all powerful real-life rewards. Lesson 15 covers how to choose and rank them.

**Common mistake:** Moving to intermittent reinforcement too early. If the dog's success rate drops below about 80%, go back to rewarding every time and make the exercise easier.

## Lesson 5 — Timing, Criteria & Rate of Reinforcement

Three things decide whether a training session works:

- **Timing:** The reward or marker must land within about one second of the behaviour you want. Late rewards teach the wrong thing — you reward the dog for standing up after the sit, and you have just reinforced standing up.
- **Criteria:** Decide in advance exactly what earns the reward. For a sit, is it any sit, or a fast, square sit with the dog looking at you? Raise criteria in small steps only, and only when the dog is succeeding at the current level at least 8 times out of 10.
- **Rate of reinforcement:** In early learning, aim for a high rate — a reward every few seconds. A low rate in early learning means frustration and disengagement. If you find yourself waiting a long time between rewards, the exercise is too hard. Split it into smaller steps.

## Lesson 6 — Shaping, Luring & Capturing

There are three main ways to get a new behaviour started:

- **Luring:** Use a treat in your hand to guide the dog into position — for example, moving a treat over the dog's head so its bottom drops into a sit. Lures are a great starting tool, but fade them quickly (within a few sessions) or the dog will only perform when it can see food.
- **Shaping:** Reward successive small steps toward the final behaviour. To teach a dog to go to its mat, you might first reward looking at the mat, then stepping toward it, then one paw on it, then two paws, then lying down on it. Shaping builds creative, thinking dogs and is excellent for complex behaviours.
- **Capturing:** Reward a behaviour the dog offers naturally. See the dog lie down calmly? Mark and reward it. Over time the dog offers it more often, and you can add a cue. Capturing is the gentlest way to teach settle and calm behaviour, and it is underused by most trainers.

**Exercise:** Teach a simple new behaviour using shaping only — for example, touching your hand with its nose (a hand target). Break it into at least five steps, and write down each step before you start. Note how many repetitions each step took.

## Lesson 7 — Extinction, Spontaneous Recovery & the Extinction Burst

When a previously rewarded behaviour stops being rewarded, it fades — this is extinction. Two things surprise new trainers. First, the **extinction burst**: the behaviour often gets worse before it gets better. A dog that used to get attention for barking may bark louder and longer for a few days when the attention stops. This is normal and does not mean the approach is failing — but everyone in the household must be consistent, because rewarding the behaviour during a burst teaches the dog to bark louder next time. Second, **spontaneous recovery**: an extinguished behaviour can reappear briefly after a break. Stay calm, stay consistent, and it fades again faster each time.

Never use extinction alone for a behaviour driven by fear or anxiety — ignoring a frightened dog does not make it less frightened. Extinction is a tool for attention-seeking and learned behaviours, used alongside teaching an alternative behaviour the dog can do instead.

**Module 1 Check:** You can explain classical and operant conditioning in plain language; you can name the four consequences and explain why this course uses only reinforcement; you can describe timing, criteria, and rate of reinforcement; you have shaped one new behaviour and recorded the steps.

---

# MODULE 2 — Reading the Dog: Body Language, Stress & Safety

## Lesson 8 — The Dog's Vocabulary

Dogs communicate constantly, mostly with their bodies. A trainer who cannot read a dog is working blind. The main channels are: ears (forward, back, pinned), eyes (soft, hard stare, whale eye — the whites showing), mouth (relaxed open, closed tight, lip licking, yawning when not tired), tail (height, speed, stiffness — a wagging tail does not always mean a happy dog; a high, stiff, fast wag can signal arousal or threat), posture (weight forward or back, height, crouching), and movement (loose and wiggly versus stiff and still).

Learn to read the whole dog, not one signal in isolation. A loose body with a low, wide wag and soft eyes is a relaxed dog. A stiff body with a hard stare, closed mouth, and weight forward is a dog that needs space now.

## Lesson 9 — The Ladder of Communication

Dogs escalate in a predictable sequence when they are uncomfortable: yawning, lip licking, turning the head away, moving away, showing the whites of the eyes, freezing, growling, snapping, and finally biting. Growling is communication, not defiance — a dog that growls is telling you it is uncomfortable and asking for space. Never punish a growl: a dog that learns growling is punished may skip the warning and go straight to a bite.

Your job is to notice the early rungs of the ladder and change the situation before the dog needs to climb higher. If you see lip licking and head turns, increase distance, remove the trigger, or give the dog an easy, rewarded alternative. The earlier you act, the less the dog has to shout.

## Lesson 10 — Stress Signals & the Stress Bucket

Stress accumulates. A dog that had a stressful vet visit in the morning, a loud building site at lunch, and a crowded park in the afternoon has a full "stress bucket" — and the next small thing may tip it over into a reaction that seems out of proportion. This is called trigger stacking. A good trainer checks what else has happened in the dog's day before judging a reaction, and schedules rest and decompression (a sniffy walk, a chew, quiet time) after stressful events.

Signs of stress include panting when not hot or exercised, pacing, inability to settle, dilated pupils, shedding more than usual, digestive upset, and a sudden drop in appetite for treats the dog normally loves. If a dog will not take treats, it is too stressed to learn — reduce the difficulty immediately.

## Lesson 11 — Arousal: Too Much of a Good Thing

Arousal is intensity of emotion, and it can be positive (excitement about a ball) or negative (frustration at a barrier). An over-aroused dog cannot think, cannot hear cues it knows well, and makes poor choices. Signs include jumping, mouthing, spinning, vocalising, and an inability to eat or focus. The fix is not more excitement — it is calm structure: lower the intensity, increase distance from the trigger, ask for a simple known behaviour, reward calm, and give the dog a break.

Teach an "off switch" early: a mat or bed where the dog learns to settle (Module 5), and a routine of calm behaviour earning calm rewards. Dogs that only ever practise at high arousal never learn to settle.

## Lesson 12 — Safe Handling: Approach, Touch & Restraint

Approach a new dog from the side, not head-on, at a relaxed pace, and let the dog choose to come closer. Crouch sideways rather than looming over the dog. Offer the back of your hand low for a sniff — or better, do not reach out at all and let the dog investigate you. Never hug a dog you do not know well, never reach over its head as a first greeting, and never corner a dog that is trying to move away.

For handling exercises (touching ears, paws, collar), pair every touch with a treat — this is cooperative care, covered further in Module 8 — and stop the moment the dog shows discomfort. A dog that trusts handling is a dog that is safe at the vet and the groomer.

## Lesson 13 — Safety in Sessions: Leashes, Space & Other Dogs

Golden rules for every session: check equipment before you start (a frayed lead or loose clip can end a session badly); keep a safe distance from other dogs until you know both dogs; never allow on-lead greetings with unknown dogs — lead tension plus a face-to-face meeting is a recipe for a bad interaction; carry a plan for what to do if a loose dog approaches (body-block calmly, use a treat scatter on the ground to distract, and move away); and always have an exit route.

With children present, supervise every interaction, teach children to be calm and still around dogs, and never leave a child and a dog unsupervised together, however friendly the dog is.

## Lesson 14 — When to Stop: Reading the Session

End a session while the dog is still succeeding — a good last repetition is better than a long session that ends in failure. Watch for signs the dog is done: slower responses, looking away, sniffing the ground excessively, lying down, or refusing treats. Keep sessions short (5–15 minutes), finish with something easy and fun, and always end with a play or a chew so the dog remembers training as a good thing.

**Module 2 Check:** You can read the whole dog — ears, eyes, mouth, tail, posture, movement; you can describe the escalation ladder and explain why a growl is never punished; you can recognise trigger stacking and over-arousal; you can approach and handle a new dog safely.

---

# MODULE 3 — The Trainer's Toolkit: Rewards, Markers & Equipment

## Lesson 15 — Finding What a Dog Values

Every dog has a reward hierarchy, and it is personal. For most dogs, food sits at the top — but not all food is equal. Rank your practice dog's rewards by testing: offer two treats and see which the dog chooses first, repeated several times. Typical rankings run from everyday kibble (low value), to commercial treats (medium), to real meat, cheese, or hot dog pieces (high value). Use low-value rewards for easy, known behaviours and high-value rewards for hard or new ones. Toys, play, sniffing, and freedom are also rewards — a ball-crazy dog may work harder for a throw than for any treat.

Keep a reward list in the workbook for every dog you work with. What a dog values changes with context: a treat that works in the kitchen may be worthless in the park when a squirrel is present. Always bring rewards that beat the environment you are training in.

## Lesson 16 — The Marker: Clicker or Word

A marker is a short, consistent signal that tells the dog "that exact behaviour earned a reward, and the reward is coming." A clicker gives a precise, unique sound; a marker word such as "Yes!" works just as well if you say it the same way every time. Pick one and be consistent.

Charge the marker first: click (or say your word), then deliver a treat, 15–20 times, with no behaviour required. The dog quickly learns the sound predicts food. From then on, mark the behaviour the instant it happens, then deliver the treat within a few seconds. Never click without following with a reward — a marker that stops predicting food stops working.

## Lesson 17 — Treat Delivery: Where the Food Lands Matters

Where you deliver the treat teaches the dog where to be. Deliver low and between the dog's front paws to encourage a sit or down to hold still; deliver at your side to encourage heel position; toss a treat away from you to reset the dog for the next repetition; scatter treats on the ground to lower arousal and encourage sniffing, which is calming. Delivering treats from your hand at chest height teaches jumping — a common beginner error. Think about delivery position every single time.

Cut treats small — pea-sized for a medium dog, smaller for a toy breed. A dog that has to chew a large biscuit for thirty seconds is not training; it is eating. And watch total intake: use part of the dog's daily food allowance as training rewards where possible, and reduce meal sizes on heavy training days.

## Lesson 18 — Equipment: What to Use and What to Avoid

**Use:** a flat collar or a well-fitted front-clip harness, a standard 1.8 m lead, a long line for recall training, a treat pouch, a clicker, a mat, and enrichment items such as Kongs and lick mats. A head halter can be a useful management tool for strong pullers while training progresses, fitted correctly and introduced gradually with food — it is not a training method by itself.

**Avoid in this programme:** shock collars, prong collars, choke chains used for corrections, spray collars, and anything designed to cause pain, fear, or discomfort. These tools suppress behaviour without teaching an alternative, risk injury and fear, damage trust, and are unnecessary — the methods in this course achieve reliable results without them.

## Lesson 19 — The Training Environment: Start Easy, Add Difficulty Gradually

Dogs do not generalise well. A sit learned in the kitchen is not a sit learned in the park — to the dog, these are different behaviours in different contexts. The professional approach is to train each behaviour in many places, adding one difficulty at a time: first duration, then distance, then distraction — never all three at once. This is the "three Ds" rule, and it applies to every behaviour in Modules 5–7.

Start each new behaviour in the easiest place possible: a quiet room with no distractions. When the dog succeeds at 8 out of 10 repetitions, add a small challenge — a slightly busier room, a longer stay, one step back. If success falls below 80%, you added too much. Go back a step.

## Lesson 20 — Session Structure: Warm-Up, Work, Cool-Down

A good session has a shape: 1–2 minutes of warm-up with easy, well-known behaviours the dog can succeed at (this builds confidence and engagement); 5–10 minutes of focused work on the new skill, broken into short sets of 3–5 repetitions with play or sniff breaks between sets; and a cool-down with something easy and fun, ending on a success. Never drill one behaviour for the whole session — dogs, like people, learn better with variety and breaks.

**Session template (10 minutes):** 0:00–1:30 warm-up (hand targets, sits); 1:30–4:00 new skill, set 1 (4 reps); 4:00–5:00 play/sniff break; 5:00–7:30 new skill, set 2 (4 reps); 7:30–9:00 known behaviour the dog loves; 9:00–10:00 free play or chew, session ends.

## Lesson 21 — Recording Progress: Data Beats Memory

Professional trainers keep records. For every session, note the date, the behaviour, the step you worked on, the number of successful repetitions out of the total, the environment, and any observations (the dog was tired, the distraction was a cat, the treat value was too low). The Training Progress Tracker in the templates folder gives you a ready-made format. Records show you whether a dog is improving, stuck, or going backwards — and they are essential evidence when you work with clients (Module 14) and for your certificate project (Module 16).

## Lesson 22 — Common Beginner Errors (and Fixes)

- **Repeating the cue:** Saying "sit, sit, SIT!" teaches the dog to wait for the third repetition. Say the cue once, wait three seconds, and if nothing happens, help the dog succeed (lure or prompt) and try again. If it keeps happening, the dog does not know the behaviour yet — go back a step.
- **Training when frustrated:** Dogs read your tension. If you feel frustrated, end the session with something easy and walk away. Training through frustration teaches the dog that training is stressful.
- **Bribing instead of rewarding:** A lure held in front of the dog's nose on every repetition is a bribe. Fade the lure within a few sessions so the cue, not the sight of food, drives the behaviour.
- **Training too long:** Ten focused minutes beats thirty distracted ones.

**Module 3 Check:** You have ranked a dog's rewards; charged a marker; can explain why delivery position matters; can set up a session with a warm-up, work sets, and cool-down; and you have started a training log.

---

# MODULE 4 — Setting Up for Success: Environment, Management & Prevention

## Lesson 23 — Management First: Prevent the Behaviour You Do Not Want

The fastest way to reduce an unwanted behaviour is to make it impossible or unrewarding while you train an alternative. A dog that counter-surfs cannot practise counter-surfing if food is never left within reach and the dog is behind a baby gate during cooking. A dog that jumps on visitors cannot practise it if it is behind a gate with a chew when the doorbell rings. Management is not cheating — it is good training. Every repetition of an unwanted behaviour strengthens it, so preventing repetitions while you build the alternative is essential.

**Exercise:** List the three most common unwanted behaviours in your practice dog's home. For each, write one management step that prevents the behaviour this week, and one alternative behaviour you will train instead.

## Lesson 24 — The Home Setup: Zones, Gates & Safe Spaces

Set up the home in zones: a rest zone (a quiet corner with a bed where the dog is never disturbed), a training zone (a low-distraction room), and a managed zone for times when the dog cannot be supervised (a pen or a gated room with water, a chew, and a toilet option for puppies). Baby gates are a trainer's best friend — they prevent rehearsal of unwanted behaviour without isolating the dog. A crate can be a safe den if introduced gradually with food and the door left open, but it must never be used as punishment, and a dog should never be crated for long periods.

## Lesson 25 — Enrichment: A Tired Brain Is a Calm Dog

Many "behaviour problems" are enrichment problems. A bored, under-stimulated dog will find its own entertainment — chewing, barking, digging. Enrichment means giving the dog appropriate outlets: food puzzles and Kongs, scatter feeding (throwing kibble into grass for the dog to find), snuffle mats, long sniffy walks where the dog chooses the route, digging in a designated sandpit, and short training games. Aim for at least two enrichment activities a day in addition to walks. A 15-minute sniffy walk often tires a dog more than a 30-minute march on a tight lead.

## Lesson 26 — Exercise: The Right Kind, the Right Amount

Exercise needs vary enormously by breed, age, and health — a working border collie and an elderly pug have very different needs, and puppies need short, frequent activity rather than long forced exercise (a common guideline is about five minutes of structured exercise per month of age, twice a day, but always follow your vet's advice for your dog). Mental exercise counts: ten minutes of scent games can be as tiring as a much longer walk. Never exercise a dog to exhaustion to "tire it out" — an over-tired dog is often more reactive, not less.

## Lesson 27 — Routine & Predictability

Dogs thrive on routine. Regular feeding times, walk times, rest times, and training times reduce anxiety because the dog can predict what happens next. This is especially important for anxious dogs and new rescues, who may need several weeks to learn the household routine. Keep a written daily routine for the first month with any new dog — the Daily Routine template in the workbook helps.

## Lesson 28 — Preventing Problems Before They Start

Prevention is cheaper than cure. For a new puppy or rescue, the first two weeks should focus on: a safe space and routine; gentle handling paired with treats (ears, paws, collar, mouth); short, positive introductions to household sounds and visitors at the dog's pace; toilet training with a consistent schedule and generous rewards; and teaching the dog that being alone is safe, starting with seconds (Module 8). Rushing introductions and socialisation is the single most common cause of fear problems later — go at the dog's pace, not yours.

## Lesson 29 — When Management Is Not Enough: Knowing Your Limits

Management and foundation training solve many problems. But if a behaviour involves aggression, biting, severe fear, self-harm, or a sudden change, that is beyond foundation training and beyond this course's scope. Lesson 88–94 covers exactly how to recognise those cases, keep everyone safe, and refer to a veterinarian and a qualified behaviour professional. Knowing when to refer is a professional skill, not a failure.

**Module 4 Check:** You have written a management plan for three unwanted behaviours; set up zones in a home; planned a week's enrichment; and can explain why routine and prevention matter.

---

# MODULE 5 — Core Obedience I: Sit, Down, Stay & Release

## Lesson 30 — The Four Foundation Behaviours

Sit, down, stay, and a release cue are the foundation of everything else. They teach the dog to offer stillness, to wait, and to listen — and they give the handler a polite alternative to jumping, rushing, and barging in almost any situation. Teach them in this order: sit first (easiest to lure), then down, then stay built onto both, then a release word that tells the dog the exercise is over. A release cue matters: without one, the dog decides for itself when the stay ends.

## Lesson 31 — Teaching Sit

**Method (lure, then fade):** Hold a treat at the dog's nose, move it slowly up and back over the head. As the nose follows, the bottom drops. The instant the bottom touches the floor, mark ("Yes!") and deliver the treat low, between the paws. Repeat 5 times. On the sixth repetition, say "Sit" once, just before you move the lure. After 3–5 successful repetitions with the cue, start fading the lure: make the hand movement smaller each time until it is just a small upward flick of an empty hand, then no hand movement at all — just the word. **Progression:** sit in the kitchen (10 reps, 8/10 success) → sit in the hallway → sit in the garden → sit at the front door → sit on a walk with mild distractions. **Troubleshooting:** If the dog jumps for the treat, your hand is too high — hold the lure closer to the nose. If the dog backs up instead of sitting, lure against a wall or in a corner so backing up is blocked.

## Lesson 32 — Teaching Down

From a sit, hold a treat at the dog's nose and lower it slowly to the floor between the front paws, then slide it slightly forward along the ground. Mark the instant the elbows touch the floor and deliver the treat on the floor between the paws. Add the cue "Down" once the movement is reliable, then fade the lure as with sit. **Common error:** Lifting the treat up again, which pulls the dog back into a sit. Keep the treat on the floor. Some dogs find down harder because it is a vulnerable position — be patient, keep sessions short, and never push the dog's shoulders down. **Progression:** down from a sit → down from standing → down at 2 metres distance → down with a 5-second wait before the reward.

## Lesson 33 — Stay: Duration First

Stay is not a separate behaviour — it is sit or down held for longer. Teach it by asking for a sit, pausing one second, then marking and rewarding. Build duration in tiny steps: 1 second, 2 seconds, 3 seconds, 5 seconds, 10 seconds. If the dog breaks, you went too far — go back to the last duration that worked and rebuild more slowly. Use a flat palm as a visual signal and the word "Stay" or "Wait" (pick one and keep it). **The three Ds, one at a time:** build duration first, then distance (one step back, then two), then distraction (a dropped pen, a person walking past). Never add two Ds at once.

## Lesson 34 — The Release Cue

Choose a release word — "Okay!", "Free!", or "Break!" — and use it every time an exercise ends. Teach it by asking for a sit, pausing two seconds, saying the release word in an upbeat tone, and tossing a treat away from the dog so it moves. The dog learns the release word means "you may move now, and something good happens over there." Without a release, dogs learn to break stays whenever they feel like it, because no clear signal ever told them the stay was over.

## Lesson 35 — Mat Training: The Portable Settle

Mat training gives the dog a place to go and settle anywhere — at a café, at a friend's house, at the vet. **Steps:** (1) Put the mat on the floor; mark and reward any look at it. (2) Reward a step toward it, then one paw on it, then two paws. (3) Reward lying down on it. (4) Add the cue "Mat" or "Place". (5) Build duration: reward the dog for staying on the mat for 2, 5, 10, 30 seconds, delivering treats on the mat so the dog stays there. (6) Move the mat to new rooms, then new locations. A dog with a solid mat behaviour has a portable calm skill for life.

## Lesson 36 — Proofing: Making Behaviours Reliable

Proofing means practising a known behaviour under gradually harder conditions. Use the three Ds deliberately: this week, practise sit-stay with duration (up to 30 seconds); next week, with distance (up to 5 metres); the week after, with distractions (a ball rolling past, a family member walking by). Record success rates in the tracker. A behaviour is "proofed" when the dog succeeds at 8 out of 10 repetitions in a given environment — and remember, proofing in one place does not transfer automatically to another. Practise in at least five different locations before calling a behaviour reliable.

## Lesson 37 — Chaining: Sit-Stay-Recall Sequences

Once the individual behaviours are solid, chain them: sit → stay while you walk 3 metres away → recall → sit in front → release. Reward the whole chain, with the biggest reward at the end. Chaining teaches the dog to work through a sequence and builds the foundation for the more advanced work in Module 13. If a link in the chain breaks, go back and practise that link alone before rejoining the chain.

## Lesson 38 — Worked Example: A 10-Minute Sit-Stay Session Plan

**Dog:** Milo, 2-year-old Labrador, knows sit and down. **Goal:** 10-second sit-stay at 2 metres. **Warm-up (2 min):** 5 hand targets, 5 sits, all rewarded. **Set 1 (3 min):** Sit, 3-second stay, mark and reward (4 reps); sit, 5-second stay (4 reps). **Break (1 min):** sniff and play. **Set 2 (3 min):** Sit, 5-second stay at 1 step back (4 reps); sit, 5-second stay at 2 steps back (4 reps). **Cool-down (1 min):** Down on the mat, jackpot of three treats, free play. **Result recorded:** 14/16 successful — ready to try 8-second stays next session.

**Module 5 Check:** The dog sits and lies down on cue in at least three locations; holds a 10-second stay at 2 metres; goes to its mat on cue; and you can describe the three Ds and how to fade a lure.

---

# MODULE 6 — Core Obedience II: Recall, Leave It & Drop It

## Lesson 39 — Recall: The Most Important Cue You Will Ever Teach

Recall — the dog coming when called — is a safety behaviour. A reliable recall can save a dog's life near a road or livestock. It is also the behaviour most often damaged by poor training, usually because owners call the dog to do something unpleasant (a bath, leaving the park, nail trims) or repeat the cue until the dog learns to ignore it. The rules: recall must always predict something wonderful; never call a dog to punish it or to end fun unless you have a high-value reward ready; and never repeat the cue — say it once.

## Lesson 40 — Teaching Recall from Scratch

**Steps:** (1) Indoors, with the dog 1 metre away, say its name and the recall cue ("Come!") in a happy voice, then run backwards a few steps. Mark and reward with a jackpot (3–4 treats, one at a time) when the dog reaches you. (2) Increase distance gradually — across the room, then from another room, then in the garden. (3) Add a long line outdoors so the dog cannot practise ignoring you, and reward every recall generously. (4) Practise with mild distractions at distance before trying closer ones. (5) Only remove the long line when recall is reliable at 9 out of 10 in that environment. **Never** call a dog away from something exciting until you have built up to it in small steps — set the dog up to succeed.

## Lesson 41 — Recall Games That Build Reliability

- **Ping-pong recall:** Two people stand 5 metres apart, take turns calling the dog, and reward each arrival. The dog learns that coming to a person is a game.
- **Hide and seek:** Hide behind a tree or a door and call the dog — the dog learns to search for you and to come quickly.
- **The jackpot recall:** Once a week, make one recall in a session pay a huge jackpot — ten treats, a game of tug, a thrown ball. The dog never knows which recall will be the jackpot, so every recall is worth running for.
- **Whistle recall:** A whistle carries further than a voice and sounds the same whoever blows it. Charge it like a marker (whistle → treat, 20 times), then use it exactly as you would a voice recall.

## Lesson 42 — Troubleshooting Recall

**"He comes at home but not at the park."** The park is a different context with bigger distractions. Go back to the long line, increase reward value, and rebuild distance and distraction gradually. **"He comes halfway and runs off."** You probably rewarded too early or the environment beat your reward. Reward only on arrival at you, and make the reward better than the distraction. **"He ignores the cue completely."** The cue has been poisoned by repetition or by bad associations. Retire the word, choose a new cue (for example, switch from "Come" to "Here"), and retrain from scratch with a new, positive history.

## Lesson 43 — Leave It: Impulse Control in One Cue

"Leave it" tells the dog to disengage from something it wants. **Steps:** (1) Hold a treat in a closed fist. When the dog sniffs and then turns away even slightly, mark and reward with a *different, better* treat from your other hand. Never give the dog the treat in the closed fist — the lesson is that ignoring something earns something better. (2) Repeat until the dog turns away immediately. (3) Put a treat on the floor and cover it with your hand; same rule. (4) Put a treat on the floor uncovered, with your foot ready to cover it if needed; reward turning away. (5) Add the cue "Leave it" just before presenting the item. (6) Practise with real-life items: dropped food, a wrapper, another dog's toy. **Progression:** food on the floor → food on a walk → a moving item → a food bowl placed down with a wait.

## Lesson 44 — Drop It: Trading Up, Never Taking

A dog that will drop an item on cue is safer and easier to live with — and the skill prevents resource guarding from developing (see Lesson 64). **Steps:** (1) Give the dog a low-value toy. Offer a high-value treat near its nose; when it drops the toy, mark, give the treat, then give the toy back. The dog learns dropping an item is not losing it. (2) Add the cue "Drop it" or "Give" as the dog starts to release. (3) Gradually use lower-value trades and practise with different items. (4) Always trade up in the early stages, and sometimes return the item after the trade so the dog never assumes "drop it" means "goodbye forever."

## Lesson 45 — Emergency Recall & Emergency Stop

Teach one emergency recall word that is used rarely and always pays a jackpot — a word the dog never hears in ordinary training, such as "Now!" or a specific whistle pattern. Use it only in genuine need, and always follow it with the best reward you have. An emergency stop (the dog stopping and lying down at distance) is an advanced skill taught by building a strong down-stay at increasing distance with a long line, and it is covered in the advanced progression in Module 13. Both skills are worth the investment for any dog that is ever off lead.

## Lesson 46 — Worked Example: A 4-Week Recall Plan

**Dog:** Bella, 1-year-old spaniel, recall reliable indoors only. **Week 1:** Garden on a long line, 10 recalls a day, jackpot every third recall; success 9/10. **Week 2:** Quiet field on a long line, 5-metre recalls, high-value treats (chicken), success 8/10. **Week 3:** Same field, 10-metre recalls with a helper as a mild distraction standing 10 metres away, success 8/10. **Week 4:** Same field off the long line for the first 5 minutes only, recalling every 60 seconds; long line back on for the rest of the walk. **Rule:** If success drops below 8/10 at any step, stay at that step for another week — do not push on.

**Module 6 Check:** Recall is reliable on a long line in a distracting environment at 8/10; the dog leaves food on cue and drops a toy on cue; you can explain why a recall cue becomes poisoned and how to fix it.

---

# MODULE 7 — Loose-Lead Walking & Polite Greetings

## Lesson 47 — Why Dogs Pull (and Why Punishing It Fails)

Dogs pull because pulling works: it gets them to the interesting thing faster. Every step forward while the lead is tight rewards pulling. Punishing pulling with leash jerks or aversive collars may suppress it temporarily, but it does not teach the dog what to do instead, and it risks pain, fear, and damage to the neck and trachea. The humane solution is to make loose-lead walking pay and pulling not pay — the dog learns that a slack lead is the fastest route to everything it wants.

## Lesson 48 — Teaching Loose-Lead Walking

**Method (reward position, stop the pull):** (1) In a quiet area, walk with treats in your pouch. Every time the dog is beside you with a slack lead, mark and deliver a treat at your side, at the dog's nose height. Reward every few steps at first — a high rate of reinforcement. (2) The instant the lead goes tight, stop walking. Stand still like a tree. Wait for the dog to turn back or for the lead to slacken, then mark and walk on. The dog learns tight lead = the walk stops; slack lead = the walk continues. (3) Practise in short sessions (5–10 minutes) and in easy places first. (4) Change direction often in early training — every time the dog forges ahead, turn and walk the other way, rewarding the dog for catching up and walking beside you. **Do not** drag the dog, yank the lead, or shout. Patience here pays for years.

## Lesson 49 — The 300-Peck Method

For dogs that need structure, the 300-peck method builds duration systematically: reward after 1 step of loose-lead walking, then 2, then 3, then 5, then 8, then 12, then 20, and so on, increasing the target number of steps before the next reward. If the dog pulls before reaching the target, go back to the previous number that worked. This method gives you a clear, measurable progression and prevents the common error of jumping from rewarding every step to rewarding almost never.

## Lesson 50 — Walking Past Distractions

Build a distraction hierarchy: a quiet street → a street with a person 20 metres away → a person 10 metres away → another dog across the road → another dog on the same pavement. At each level, increase your rate of reinforcement and treat value, keep moving, and increase distance from the distraction whenever you can. If the dog fixates (stiff body, hard stare, stopped eating treats), you are too close — increase distance immediately and try again from further away. Crossing the road is a legitimate training tool, not a failure.

## Lesson 51 — Polite Greetings: Four Paws on the Floor

Jumping up is reinforced by attention. Teach the alternative: all four paws on the floor earns attention; jumping earns the removal of attention (turn away calmly, hands folded, no eye contact) until all four paws are down, then reward. Practise with a helper: the helper approaches, and if the dog jumps, the helper turns away; when all four paws are on the floor, the helper greets calmly and the dog is rewarded. **Household rule:** Everyone must follow the same rule, including visitors — one person who rewards jumping undoes the work of everyone else. For dogs that jump on children or elderly visitors, use management (a baby gate or a lead) until the behaviour is reliable.

## Lesson 52 — Greeting Other Dogs Politely

On-lead greetings are high-risk and often unnecessary. Teach the dog that other dogs are a cue to look at you, not to rush in: when another dog appears at a distance, mark and reward the dog for looking at you; gradually decrease distance over many sessions. If a greeting does happen, keep it short (3 seconds), on a loose lead, with both dogs free to move away, and call the dog away with a treat before tension builds. A dog that has good off-lead social skills with familiar dogs still does not need to greet every dog it meets.

## Lesson 53 — Door Manners & Thresholds

Teach the dog to wait at doors and gates: ask for a sit at the threshold, open the door a crack, and if the dog moves, close the door calmly and try again. When the dog waits, release with your release word and walk through together. This prevents bolting into roads and teaches impulse control at exactly the moment excitement is highest. Practise at the front door, the garden gate, and the car boot.

## Lesson 54 — Worked Example: A 6-Week Loose-Lead Plan

**Dog:** Rocky, 3-year-old Staffy mix, strong puller. **Weeks 1–2:** Garden and quiet street, stop-start method, 10-minute sessions, success = lead slack for 5 steps. **Weeks 3–4:** 300-peck method on a quiet street, target 20 steps; front-clip harness introduced for management on busy days. **Weeks 5–6:** Busy street at quiet times, high-value treats, crossing the road to manage distance from other dogs. **Result:** Rocky walks on a loose lead for 15 minutes on a quiet street and 5 minutes on a busy street — realistic, measurable progress, with a plan to keep building.

**Module 7 Check:** The dog walks 20 steps on a loose lead in a low-distraction area; greets a helper with four paws on the floor; waits at a door on cue; and you can explain the stop-start method and the distraction hierarchy.

---

# MODULE 8 — Puppy Foundations: Socialisation, Toilet Training & Early Manners

## Lesson 55 — The Socialisation Window

Puppies have a sensitive period for socialisation roughly between 3 and 14 weeks of age, when positive experiences shape how they respond to the world as adults. The goal is not to meet as many things as possible as fast as possible — it is to give the puppy many *positive, controlled* experiences at the puppy's pace: different people (hats, uniforms, children, elderly people), sounds (traffic, vacuum, thunder recordings at low volume), surfaces (grass, gravel, wood, metal grates), places (vet waiting room for a treat visit, a quiet café), and gentle handling. One frightening experience during this window can have lasting effects, so quality and the puppy's comfort matter far more than quantity. After 14 weeks, socialisation continues — it just takes more repetitions.

## Lesson 56 — Socialisation Done Right: The Checklist Approach

Use the Puppy Socialisation Checklist in the workbook. For each item, record the puppy's response (relaxed, curious, unsure, frightened) and what you did. Rules: keep sessions short (5–10 minutes); let the puppy approach new things rather than forcing it; pair every new experience with treats; watch body language and retreat if the puppy shows stress; and never flood a frightened puppy by forcing it to stay near something scary. A puppy that is unsure needs distance and treats, not exposure therapy.

## Lesson 57 — Toilet Training: Schedule, Supervision & Reward

Toilet training is a management and scheduling task, not a discipline problem. **Schedule:** Take the puppy out first thing in the morning, after every meal, after every nap, after play, and every 1–2 hours during the day (a rough guide is that a puppy can hold on for about one hour per month of age). **Supervision:** When the puppy is awake and loose in the house, watch it constantly; if you cannot watch, use a pen or crate. Learn the pre-toilet signals: circling, sniffing the ground intently, squatting. **Reward:** The instant the puppy finishes toileting outside, mark and reward with a treat and praise — the reward must happen outside, within seconds, or the puppy will not connect it with toileting. **Accidents:** Clean up without fuss and without punishment — never rub a puppy's nose in it, and never shout. Punishment teaches the puppy to hide when toileting, which makes training far harder. Ask: was the schedule too long, or was supervision lost? Fix that.

## Lesson 58 — Crate Training & Alone Time

Introduce the crate gradually: door open, treats tossed inside, meals fed inside, short periods with the door closed while you sit nearby, then brief absences. Build alone time in seconds, not hours: leave the room for 5 seconds and return before the puppy gets upset, then 10, then 30, then a minute — always returning before distress, and always leaving the puppy with something good (a Kong, a chew). Never use the crate as punishment and never leave a young puppy alone for long periods. If the puppy panics when alone, go back to shorter absences — separation problems are covered in depth in Module 11.

## Lesson 59 — Bite Inhibition & Mouthing

Puppies explore with their mouths and need to learn how hard is too hard. When a puppy mouths too hard, give a short, calm yelp or say "Ouch" in a normal voice, withdraw your hand, and pause play for a few seconds. When the puppy is calm, resume play. Redirect mouthing onto a toy every time — keep a toy within reach in every room. If mouthing escalates, end the interaction calmly and give the puppy a chew or a rest — overtired puppies mouth more, and a nap often fixes what discipline cannot. Never hit a puppy for mouthing, and never play wrestling games that reward rough mouthing.

## Lesson 60 — Handling & Cooperative Care

Pair every handling experience with food from the start: touch an ear, treat; lift a paw, treat; look at the teeth, treat; touch the collar, treat. Build up to nail trims, ear checks, and vet examinations in small steps, always at the puppy's pace. A puppy that has learned handling predicts treats is a dog that is safe and calm at the vet for life. Record handling progress in the workbook's Handling Checklist.

## Lesson 61 — Puppy Biting, Chewing & Jumping: Prevention

Puppies chew because they are teething and exploring. Provide appropriate chews and rotate them; manage the environment (shoes away, cables protected, valuables out of reach); redirect every inappropriate chew onto an appropriate one and reward the puppy for chewing it. For jumping, use the same four-paws-on-the-floor rule as Lesson 51, starting from day one — it is far easier to prevent jumping than to fix it in an adult dog.

## Lesson 62 — The First Two Weeks: A New Puppy Plan

**Days 1–3:** Safe space, routine, toilet schedule, gentle handling, short garden play, sleep. **Days 4–7:** First vet visit (treats only, no procedures if possible), first short car ride, first visitors (calm adults, treats). **Week 2:** Puppy class (a well-run, small, positive-reinforcement class — visit first and check the trainer uses reward-based methods), first new surfaces and sounds, start of alone-time training in seconds. **Throughout:** Keep a daily log of toileting, sleep, socialisation, and training, and keep sessions to 2–3 minutes, several times a day.

**Module 8 Check:** You can explain the socialisation window and its rules; run a toilet schedule; teach bite inhibition and handling; and write a two-week plan for a new puppy.

---

# MODULE 9 — Understanding Behaviour Problems: Assessment Before Action

## Lesson 63 — Why Assessment Comes First

Most behaviour problems are misdiagnosed by well-meaning owners. A dog that "ignores" its owner may be frightened, in pain, over-aroused, or simply never taught the behaviour properly in that environment. A dog that "is being stubborn" is almost always a dog that does not understand, cannot cope, or is not motivated. The professional habit is to assess before acting: gather history, observe the dog, rule out medical causes, and only then design a plan. A plan built on a wrong diagnosis wastes weeks and can make the problem worse.

## Lesson 64 — The Behaviour Assessment: History, Observation & Medical Rule-Out

A full assessment has four parts. **(1) History:** When did the behaviour start? What changed at that time? How often does it happen, and in what contexts? What has been tried already, and what happened? Use the Behaviour Assessment Form in the templates folder — it prompts for all of this. **(2) Observation:** Watch the dog in the problem context (safely, and from a distance if needed). Record exactly what happens before, during, and after the behaviour — the ABCs: Antecedent, Behaviour, Consequence. **(3) Medical rule-out:** Pain, thyroid problems, neurological issues, urinary infections, dental pain, and many other medical conditions change behaviour. Any sudden behaviour change, any behaviour that appears in an older dog, and any behaviour involving self-harm or aggression must be checked by a veterinarian before training begins. **(4) Functional assessment:** What does the dog get from the behaviour? Attention, escape, access to something, or relief from fear? The function tells you what to change.

## Lesson 65 — The ABCs: Antecedent, Behaviour, Consequence

For every problem behaviour, write down: **A** — what happened immediately before (doorbell rang, another dog appeared, owner left the room); **B** — exactly what the dog did (barked for 3 minutes, lunged, chewed the door frame); **C** — what happened immediately after (owner came back, the other dog moved away, the owner shouted). The consequence is usually what keeps the behaviour going. A dog that barks at the window and the "threat" walks away learns barking works. A dog that jumps and gets picked up learns jumping works. Change the consequence and you change the behaviour — but first you must see it clearly. Keep an ABC log for at least a week before designing a plan.

## Lesson 66 — Functions of Behaviour: What Is the Dog Getting?

Behaviour serves a function. The main ones are: **attention** (jumping, barking, pawing); **escape or avoidance** (running away, hiding, snapping when cornered); **access to something** (stealing food, pulling toward other dogs); **sensory or self-soothing** (chewing, licking, spinning); and **fear or anxiety relief** (barking at a stranger until the stranger leaves). Two dogs can show the same behaviour for different reasons — one barks at visitors for attention, another barks from fear. The plans are different, which is why assessment matters. Teach an alternative behaviour that serves the same function: a fearful dog needs distance and safety, not a sit; an attention-seeking dog needs attention for calm behaviour, not for barking.

## Lesson 67 — Setting Realistic Goals & Baselines

Measure before you intervene. How many times a day does the behaviour happen? How long does it last? How close can the trigger get before the dog reacts? Record a baseline for a week — this is your "before" measurement, and it is how you and the client will know the plan is working. Then set a specific, measurable goal: not "stop barking" but "barking at the postman reduces from 3 minutes to under 30 seconds within 6 weeks, with the dog able to settle on its mat." Goals should be realistic and time-bound, and you should review progress every two weeks and adjust the plan if it is not working.

## Lesson 68 — The Behaviour Plan: Structure That Works

A good behaviour plan has: a clear description of the problem and its function; management steps to prevent rehearsal; a desensitisation and counter-conditioning programme (Module 10) where relevant; an alternative behaviour to teach; a training schedule; criteria for progressing to the next step; a plan for setbacks; and a review date. Write it down, share it with everyone in the household, and keep it to one page where possible — a plan nobody reads is not a plan.

## Lesson 69 — Working Within Your Competence

Foundation trainers can help with many common problems: jumping, pulling, recall, toilet training, mild fear, and basic manners. Cases involving aggression, biting, severe fear, separation anxiety that does not improve, self-harm, or any behaviour with a medical component are beyond foundation level and must be referred to a veterinarian and a qualified behaviour professional. Referral is a professional skill. This course teaches you to recognise those cases (Module 12) and to refer confidently and without shame — to the client or to yourself.

## Lesson 70 — Worked Example: An ABC Assessment

**Dog:** Daisy, 4-year-old terrier, barks at visitors. **ABC log (one week):** Antecedent — doorbell rings; Behaviour — Daisy runs to the door barking, jumps at the door, continues for 2–3 minutes; Consequence — visitor enters, Daisy is put in the kitchen, barking stops. **Function:** Barking is partly fear-based (strangers at the door) and partly attention-based (the excitement of arrivals). **Baseline:** 3 minutes of barking, 4–5 visitors a week. **Plan:** Management — Daisy behind a baby gate with a Kong when the doorbell rings; training — desensitisation to the doorbell sound at low volume paired with treats (Module 10), plus mat training so Daisy has a job to do when visitors arrive; goal — barking under 30 seconds within 6 weeks. **Review:** Fortnightly, with the ABC log repeated.

**Module 9 Check:** You can complete a behaviour assessment form; write an ABC log; identify the likely function of a behaviour; set a measurable goal and a baseline; and explain when a case must be referred.

---

# MODULE 10 — Fear, Anxiety & Reactivity: Desensitisation & Counter-Conditioning

## Lesson 71 — What Fear Looks Like (and What It Is Not)

Fear in dogs looks like freezing, fleeing, hiding, crouching, tucked tail, flattened ears, yawning, lip licking, and — when escape is blocked — growling, snapping, and biting. Fear is not disobedience, stubbornness, or dominance. A frightened dog cannot learn a new cue in that moment; its brain is in survival mode. The only useful response to fear is to increase distance, reduce intensity, and help the dog feel safe. Punishing a frightened dog makes the fear worse and teaches the dog that its warnings will be punished — which leads to bites without warning.

## Lesson 72 — Desensitisation: Gradual Exposure at the Dog's Pace

Desensitisation means exposing the dog to a trigger at such a low intensity that it causes no fear response, and increasing the intensity in tiny steps over many sessions. Intensity can be adjusted by distance (further is easier), duration (shorter is easier), volume (quieter is easier), or number (one person is easier than a crowd). The rule is: if the dog shows fear, the step was too big. Go back to the last step where the dog was relaxed and rebuild more slowly. A desensitisation plan that moves too fast is worse than no plan at all.

## Lesson 73 — Counter-Conditioning: Changing How the Dog Feels

Counter-conditioning changes the dog's emotional response: the trigger predicts something wonderful. The sequence matters — trigger first, then the wonderful thing, within a second or two. If the wonderful thing comes first, it predicts nothing. Use the highest-value food the dog loves, and only use it for this work so it stays special. Over many repetitions, the dog's response to the trigger changes from fear to happy anticipation — you will see the dog look at the trigger and then turn to you expectantly. That look is the goal.

## Lesson 74 — Combining Them: The DS/CC Programme

In practice, desensitisation and counter-conditioning are used together: at a distance where the dog notices the trigger but is relaxed, the trigger appears and treats follow. This is the core protocol for fear of strangers, other dogs, noises, and novel objects. **Session structure:** 5–10 minutes, 10–15 repetitions, in a controlled environment, ending while the dog is still relaxed. **Progression criteria:** The dog is relaxed and takes treats eagerly at the current step for three consecutive sessions before you make the step slightly harder. **What to record:** distance, the dog's body language, whether it took treats, and any signs of stress.

## Lesson 75 — Reactivity on Lead: The Most Common Client Problem

Lead reactivity — barking, lunging, and pulling toward other dogs or people — is the most common reason owners seek a trainer. It is usually driven by frustration (the dog wants to greet but cannot) or fear (the dog wants the other dog to go away). Both are addressed the same way: management (distance, avoiding on-lead greetings, crossing the road), DS/CC at a distance the dog can cope with, and teaching an alternative behaviour — looking at the owner, turning away, or moving to the side. The "Look at That" game (Lesson 76) is the centrepiece. Progress is measured in metres: a dog that could cope at 30 metres last month and can cope at 15 metres this month has made real progress, even if it still reacts at 5 metres.

## Lesson 76 — The "Look at That" Game

Teach the dog to look at a trigger and then look back at you for a reward. **Steps:** (1) With the trigger far away, wait for the dog to look at it. The instant it does, mark ("Yes!") and reward. (2) After several repetitions, the dog will look at the trigger and then turn to you — mark and reward the turn. (3) Add the cue "Look at that" as the dog turns toward the trigger. (4) Gradually decrease distance over many sessions. The dog learns that noticing a trigger is a cue to check in with you — a skill that transfers to every trigger, not just the one you trained with.

## Lesson 77 — Noise Sensitivity: Thunder, Fireworks & Household Sounds

Noise sensitivity is common and often worsens with age. **Prevention:** Play recordings of thunder and fireworks at very low volume during the puppy socialisation window, paired with treats and play, increasing volume in tiny steps over weeks. **Management for an already fearful dog:** Create a safe den (a covered crate or a quiet interior room), use background noise or music, close curtains, provide a long-lasting chew, and stay calm yourself. Never force a frightened dog outside during fireworks. **Training:** A DS/CC programme using recordings, starting at a volume so low the dog barely notices it, building over weeks. **Veterinary note:** For severe noise phobia, a veterinarian may prescribe short-term medication to use alongside training — this is a veterinary decision, and a trainer should always suggest the owner discuss it with their vet rather than suggesting any specific product or dose.

## Lesson 78 — Fear of People & Handling

Some dogs fear strangers, men, children, or people in uniforms — often because of limited or frightening early experiences. The DS/CC approach is the same: the person appears at a distance, treats follow, and the person never approaches the dog — the dog chooses to approach. Rules for helpers: ignore the dog completely, avoid eye contact, stay sideways, toss treats on the ground *away* from themselves (never lure the dog close to take food from a hand, which traps the dog between fear and food), and let the dog retreat at any time. Progress is measured in the dog choosing to move closer, never in the person moving closer.

## Lesson 79 — Setbacks, Regression & When to Refer

Behaviour work is rarely a straight line. A dog can be fine for weeks and then react after a bad experience, illness, or a stressful day (trigger stacking, Lesson 10). A setback is not a failure — go back two steps in the plan, rebuild, and carry on. But if a dog is not improving after 4–6 weeks of consistent work, if the behaviour is getting worse, or if there is any bite risk, refer to a veterinarian and a qualified behaviour professional. Record everything: your records are what a behaviour professional needs to help.

**Module 10 Check:** You can design a DS/CC programme with a distance hierarchy; run the "Look at That" game; explain trigger stacking and setbacks; and write a noise-sensitivity management plan.

---

# MODULE 11 — Separation-Related Behaviour, Barking & Destructive Behaviour

## Lesson 80 — Separation-Related Behaviour: What It Is

Separation-related behaviour includes vocalising, destruction (especially around doors and windows), toileting, pacing, drooling, and self-harm when the owner leaves or is out of sight. It is driven by distress, not spite — a dog that destroys the door while you are out is panicking, not punishing you. It is also one of the most commonly misdiagnosed problems: a dog that chews furniture when alone may be bored and under-enriched, not distressed. The assessment (Module 9) and, where needed, video of the dog alone are essential before choosing a plan.

## Lesson 81 — Graduated Departures: Building Alone Time

The core treatment is graduated departures: teaching the dog that departures predict good things and that the owner always returns. **Steps:** (1) Desensitise departure cues — pick up keys, put on shoes, and then sit down again, so those cues stop predicting departure. (2) Leave the room for 2–5 seconds, return calmly before the dog gets distressed, and reward calm behaviour. (3) Increase duration in tiny increments — seconds, then a minute, then 5 minutes — always staying below the dog's distress threshold. (4) Add real departures: step outside the front door for 10 seconds, then 30, then a minute. **Rules:** Never return while the dog is distressed if you can avoid it (wait for a pause), keep arrivals and departures low-key (no big hellos or goodbyes), and leave the dog with a long-lasting enrichment item. If the dog panics at any step, go back to a shorter duration. Severe cases need veterinary involvement and a qualified behaviour professional — this is a referral case, not a foundation-training case.

## Lesson 82 — Barking: Finding the Cause First

Barking has many causes: alarm (a noise or a person at the door), attention-seeking, boredom, frustration, fear, and separation distress. Each needs a different plan, so the ABC log (Lesson 65) comes first. **General principles:** Never shout at a barking dog (it sounds like joining in); reward quiet behaviour generously; teach an alternative (going to a mat when the doorbell rings); and manage the trigger where possible (frosted window film for a dog that barks at passers-by, for example). **Alarm barking:** DS/CC to the trigger sound plus a mat behaviour. **Attention barking:** Remove attention calmly and reward quiet. **Boredom barking:** More enrichment and exercise. If barking is driven by fear or separation distress, treat the underlying cause — the barking is a symptom.

## Lesson 83 — Teaching "Quiet" (and When Not To)

"Quiet" is taught by rewarding the absence of barking: when the dog stops barking for a moment, mark and reward. Add the cue "Quiet" just before you expect the pause, and build duration gradually. Do not teach "quiet" by punishing barking, and do not expect a dog to be silent — barking is normal dog communication, and the goal is reasonable control, not silence. For a dog that barks at the doorbell, combine "quiet" with the mat behaviour from Lesson 35: the doorbell becomes the cue to go to the mat.

## Lesson 84 — Destructive Behaviour: Chewing, Digging & Scratching

Destructive behaviour in adult dogs is usually boredom, anxiety, or a lack of appropriate outlets. **Steps:** (1) Rule out separation distress (video the dog alone). (2) Increase enrichment — food puzzles, chews, sniffy walks, training games. (3) Manage the environment — remove or protect valued items, use bitter-tasting deterrent sprays on furniture if appropriate, and confine the dog to a safe, enriched area when unsupervised. (4) Teach and reward chewing appropriate items: when the dog chews its own toy, reward it; when it chews something else, redirect calmly to a toy and reward that. Never punish a dog for destruction you discover hours later — the dog cannot connect the punishment with the act, and it only learns to fear you.

## Lesson 85 — Digging: Give the Dog a Legal Place to Dig

Digging is a natural behaviour, especially for terriers and other breeds bred to dig. Rather than trying to eliminate it, give the dog a designated digging area — a sandpit with buried toys and treats — and reward digging there. Manage the rest of the garden with barriers and supervision, and increase enrichment so the dog has other outlets. A dog that digs from boredom needs more to do; a dog that digs to escape needs a secure fence and a behaviour assessment.

## Lesson 86 — Night-Time Settling & Sleep

Adult dogs need roughly 12–14 hours of sleep a day, and puppies need more. A dog that will not settle at night may be under-exercised, over-tired, anxious, or in pain. Establish a calm evening routine: a last toilet break, a chew or a lick mat, lights low, and a consistent sleeping place. Avoid exciting play in the last hour before bed. If a puppy cries at night, check the basics first — toilet, hunger, temperature, comfort — and respond calmly without making night-time exciting. Persistent night-time distress should be discussed with a veterinarian.

## Lesson 87 — Worked Example: A Separation Plan

**Dog:** Max, 2-year-old rescue, howls and scratches the door when left. **Assessment:** Video shows distress starting 2 minutes after departure; not boredom (enrichment ignored). **Plan:** Vet check first (ruled out pain). Management — never left alone for more than 10 minutes while training; a dog sitter or daycare used for longer absences. Training — departure-cue desensitisation (keys, shoes) for one week; graduated departures from 30 seconds, increasing by 30 seconds every two successful sessions; Kong given on departure, collected on return. **Goal:** 30 minutes alone without distress in 8 weeks. **Review:** Weekly video check. **Referral note:** If no progress in 4 weeks, refer to a veterinary behaviourist.

**Module 11 Check:** You can explain separation-related behaviour and graduated departures; design a barking plan based on its cause; and write a management and enrichment plan for destructive behaviour.

---

# MODULE 12 — Aggression & Bite Risk: Recognition, Safety & Referral

## Lesson 88 — What Aggression Is (and Is Not)

Aggression is a behaviour — a dog threatening or harming another individual — not a personality trait or a moral failing. It is almost always driven by fear, pain, frustration, or resource defence, and it is communication that has escalated because earlier signals were missed or punished. Labels like "aggressive breed" or "dominant dog" are unhelpful: any dog can show aggression in the right circumstances, and the trainer's job is to understand the context, keep everyone safe, and refer appropriately.

## Lesson 89 — Types of Aggression You May Encounter

- **Fear-based:** The dog threatens to create distance. Body language: crouched, ears back, tail tucked, weight shifting away, then lunging when escape is blocked.
- **Resource guarding:** The dog threatens when a person or another animal approaches food, a toy, a resting place, or a person. Often starts subtly — eating faster, stiffening over an item, a hard stare.
- **Frustration-based (including lead reactivity):** The dog cannot reach something it wants and redirects the frustration into threatening behaviour.
- **Pain-related:** A dog in pain may snap when touched. Any sudden aggression must be checked by a veterinarian first.
- **Territorial:** Threatening behaviour toward people or animals entering what the dog considers its space.
- **Predatory:** Silent, focused chasing of small animals. This is a different behaviour from social aggression and is managed, not "trained out" — it requires secure fencing, leads, and management, and professional advice.

## Lesson 90 — Reading the Warning Signs

The escalation ladder from Lesson 9 applies here with higher stakes: freezing is the most important warning sign of all — a dog that goes suddenly still, with a hard stare, is a dog about to act. Other red flags: a stiff body with weight forward, a high stiff tail, a closed mouth with lips pushed forward, a direct hard stare, and growling that suddenly stops. If you see freezing, stop what you are doing, avoid eye contact, move away slowly and sideways, and do not reach for the dog. Never corner a dog that is showing these signs.

## Lesson 91 — Immediate Safety: What to Do in the Moment

If a dog is threatening: stay calm; avoid direct eye contact; turn sideways; move away slowly without running; do not reach for the dog's collar; put a barrier (a bag, a jacket, a gate) between you and the dog if you can. If a dog fight breaks out, never put your hands between the dogs — use a loud noise, a spray of water, or a barrier to interrupt, and separate the dogs once they disengage. If someone is bitten, prioritise first aid, seek medical attention promptly (dog bites can cause serious infection), and report the incident as required by local law. Record exactly what happened while it is fresh.

## Lesson 92 — Resource Guarding: Prevention & Early Intervention

**Prevention (puppies and new rescues):** Teach the dog that people approaching its food or toys predicts *better* things — walk past at a distance and toss a high-value treat, gradually decreasing distance over many sessions. Practise trading games (Lesson 44) so the dog learns giving things up is safe and rewarding. **Early signs:** Eating faster when approached, stiffening, a hard stare over a bowl. **What not to do:** Never take food away to "show the dog who is boss", never punish growling over food, and never force the dog to give up items. These approaches increase guarding. **When it is established or severe:** This is a referral case — a veterinary behaviourist or certified behaviour consultant should design the plan, and the trainer's role is management and safety in the meantime.

## Lesson 93 — The Referral Process: How to Refer Well

A good referral is specific and supportive, never a dismissal. Steps: (1) Explain to the owner, plainly and kindly, why the case needs specialist help — for example, "This behaviour involves bite risk, and that is outside what foundation training can safely address." (2) Recommend a veterinary check first. (3) Suggest a qualified professional — a veterinary behaviourist (a vet with specialist behaviour training) or a certified behaviour consultant accredited by a recognised professional body in your country. (4) Share your assessment notes and ABC logs (with the owner's permission) so the specialist does not start from scratch. (5) Offer to support the specialist's plan with foundation training once it is in place. Keep a referral template in your client pack (see the templates folder).

## Lesson 94 — Legal & Insurance Duties

Before working with any dog, check the law where you live: dangerous-dog legislation, leash laws, breed-specific rules, and reporting duties after a bite vary by country and region. Carry professional indemnity and public liability insurance before taking paying clients, keep written records of every session and every incident, and have a written incident procedure. If a dog in your care bites someone, follow your incident procedure, seek medical help for the person, inform your insurer, and record everything. Never promise a client that a dog is "safe" or "cured" — no trainer can guarantee that.

**Module 12 Check:** You can name the main types of aggression and their likely drivers; recognise freezing and other high-risk signals; describe immediate safety actions; explain how to prevent and refer resource guarding; and describe your legal and insurance duties.

---

# MODULE 13 — Designing Training Plans & Running a Session

## Lesson 95 — From Goal to Plan: The Training Plan Framework

Every training plan, whether for your own dog or a client's, follows the same framework: (1) **Goal** — one specific, measurable behaviour in one context (for example, "sit-stay for 30 seconds at 3 metres in the garden"). (2) **Starting point** — what the dog can do now, measured honestly. (3) **Steps** — the behaviour broken into small, sequential steps, each with a clear success criterion (usually 8 out of 10). (4) **Schedule** — how many sessions per week, how long, and where. (5) **Reinforcement plan** — what rewards, what value, what schedule. (6) **Review points** — when you will measure progress and adjust. Write it on one page using the Training Plan template in the workbook. A plan that fits on one page gets used; a ten-page plan does not.

## Lesson 96 — Breaking Behaviour Down: Task Analysis

Task analysis means listing every small step between where the dog is and where you want it to be. For a reliable recall in the park, the steps might be: recall in the kitchen (1 m) → recall across the house → recall in the garden (5 m) → recall in the garden with a mild distraction → recall on a long line in a quiet field (5 m) → recall on a long line with a distraction at 20 m → recall off lead in a quiet field → recall off lead with a distraction at 20 m. Each step is a training session or two, not a single repetition. Write the steps down before you start — it stops you jumping ahead, which is the most common cause of failure.

## Lesson 97 — Running a One-to-One Session: A Professional Structure

A professional one-to-one session (typically 45–60 minutes) follows this shape: **(1) Check-in (5 min):** How has the dog been since last time? Any changes, any problems, any vet visits? Review the homework log. **(2) Warm-up (5 min):** Easy behaviours the dog knows, to build engagement. **(3) Teach (20 min):** The new skill, in short sets with breaks, demonstrating first and then coaching the owner to do it. **(4) Practise in context (10 min):** The skill in a slightly harder setting — a different room, the garden, the front door. **(5) Homework and summary (10 min):** Write down exactly what to practise, how often, and what success looks like. Give the owner a written handout — people forget most of what they hear within a day. **(6) Notes:** Write your session notes before the next client arrives, while they are fresh.

## Lesson 98 — Running a Group Class

Group classes need structure, space, and safety. Keep classes small (4–6 dogs maximum for a foundation class), use barriers or spacing so dogs cannot reach each other, and never allow on-lead greetings between class dogs. A typical 6-week foundation class: Week 1 — orientation (no dogs), markers, rewards, and handling; Week 2 — sit, down, and name response; Week 3 — recall and leave it; Week 4 — loose-lead walking; Week 5 — stay, mat, and polite greetings; Week 6 — assessment and next steps. Give every owner a written handout each week, keep the atmosphere supportive, and have a plan for a dog that cannot cope in the group — a quiet corner, a barrier, or a suggestion to switch to one-to-one sessions.

## Lesson 99 — Coaching People, Not Just Dogs

Most of your time as a professional trainer is spent teaching people. Adults learn by doing, not by listening: demonstrate briefly, then hand the lead to the owner and coach them through it. Use plain language — avoid jargon, or explain it the first time you use it. Give one correction at a time, and always pair it with something the owner did well. Check understanding by asking the owner to explain the exercise back to you in their own words. And remember: the owner's confidence matters as much as the dog's. A nervous owner makes a nervous dog, so build the owner's confidence with easy wins first.

## Lesson 100 — Handling Difficult Sessions: When the Dog (or Owner) Struggles

Sometimes a session goes wrong: the dog will not engage, the owner is frustrated, the environment is too distracting. The professional response is to make it easier, not to push harder. Drop back to a behaviour the dog knows well, reward generously, and end on a success. If the owner is upset, acknowledge it ("This is genuinely hard — most owners find this week the toughest"), normalise it, and simplify the homework. Never blame the owner or the dog, in the session or afterwards. If a session is not working at all, it is better to stop early, reset, and plan a different approach than to grind through a failing session.

## Lesson 101 — Measuring Progress: Data, Not Feelings

Review progress every two to three weeks against the baseline you recorded in Module 9. Has the success rate improved? Has the distance the dog can cope with increased? Has the duration of the behaviour increased? Use the Training Progress Tracker to compare numbers, not impressions. If the numbers are not moving after three weeks of consistent practice, change something — the reward value, the step size, the environment, or the schedule — and record what you changed. Progress in behaviour work is often slow and non-linear; honest data keeps you and the client grounded.

## Lesson 102 — Worked Example: A 6-Week Plan for a Pulling Dog with a Nervous Owner

**Client:** Sarah and Biscuit, a 1-year-old cocker spaniel that pulls hard; Sarah is nervous about being pulled over. **Week 1:** Orientation, equipment check (front-clip harness), marker training, reward ranking, and the stop-start method in the garden. Homework: 5 minutes a day in the garden. **Week 2:** Stop-start on a quiet street, 300-peck to 5 steps. Homework: two 5-minute walks a day. **Week 3:** 300-peck to 10 steps, first distraction (a person at 20 m). **Week 4:** 300-peck to 20 steps, walking past a calm dog across the road. **Week 5:** Busy street at a quiet time, high-value treats. **Week 6:** Assessment — 20 steps loose lead on a quiet street, 10 steps on a busy street; next-steps plan. **Notes:** Sarah's confidence was the limiting factor in week 2, so the trainer spent extra time coaching her timing and gave her a written script for the walk.

**Module 13 Check:** You can write a one-page training plan with steps and success criteria; run a 60-minute one-to-one session; outline a 6-week group class; and explain how to coach an owner and handle a difficult session.

---

# MODULE 14 — Working with Clients: Intake, Communication & Coaching People

## Lesson 103 — The Client Intake Process

Professional client work starts before you meet the dog. Send the client an intake form (in the templates folder) asking for: the dog's age, breed, sex, neuter status, health history, and veterinary details; the problem or goal in the owner's words; when it started and what has changed; what has been tried; the household (adults, children, other animals); the dog's daily routine, exercise, and enrichment; and any bite history — ask directly and plainly. Review the form before the first session, and flag any bite history or medical red flags for a vet check before training begins. A thorough intake prevents surprises and protects everyone.

## Lesson 104 — The First Consultation

The first consultation is mostly listening. Let the owner tell the story in their own words before you ask questions. Observe the dog in its normal environment. Ask about the owner's goals — and check whether they are realistic. Agree on a plan together, in writing, with a clear price, a clear number of sessions, and clear homework. End by summarising what you agreed and sending it in writing the same day. First impressions matter: arrive on time, dress professionally, bring your own equipment, and leave the space as you found it.

## Lesson 105 — Communicating with Clients: Clear, Honest & Kind

Three rules: **be clear** (plain language, written summaries, one instruction at a time); **be honest** (about progress, about timelines, about what you cannot fix — never promise a cure); and **be kind** (owners of dogs with behaviour problems often feel ashamed and judged; your job is to make them feel supported, not lectured). Follow up between sessions with a short message checking on homework — it improves compliance more than anything else. And document everything: every session, every recommendation, every incident, in writing.

## Lesson 106 — Setting Expectations & Boundaries

Agree expectations in writing at the start: how many sessions, what they cost, what happens if a session is cancelled, what homework is expected, and what the limits of your work are (for example, that you will refer behaviour cases beyond foundation level). Set boundaries for yourself too: working hours, response times, and how clients can contact you. A trainer who answers messages at midnight burns out fast. A written service agreement protects both sides and is included in the Client Intake Pack template.

## Lesson 107 — Homework That Gets Done

Homework fails when it is too long, too vague, or too hard. Make it specific and small: "Practise 5 recalls in the garden, twice a day, for 5 minutes, and record the results in the tracker." Give a written handout, demonstrate the exercise, watch the owner do it once, and check it next session. Celebrate homework that gets done — even partial homework is progress. If homework consistently does not get done, the plan is wrong, not the client: simplify it.

## Lesson 108 — Difficult Conversations: Bad News, Referrals & Ending a Relationship

Sometimes you must tell a client something hard: that their dog needs a vet check, that the case needs a specialist, that progress will be slow, or that you cannot help them further. Be direct, kind, and specific: explain what you observed, why it matters, and what the next step is. Offer the referral as a positive step, not a rejection. If a client is abusive, unsafe, or asks you to use methods you do not use, you may end the relationship politely and in writing, with a referral to another professional where appropriate. Your safety and your professional standards are not negotiable.

## Lesson 109 — Working with Children, Elderly Owners & Vulnerable Clients

Adapt your coaching to the person in front of you. With children, keep instructions short and fun, supervise every interaction with the dog, and teach the child the same safety rules as the adult. With elderly owners, consider physical limitations — a strong dog may need a different management plan, and equipment such as a front-clip harness or a waist-attached lead may help. With any client, be patient, check understanding, and never make anyone feel foolish for not knowing something. You are the professional; teaching is your job.

## Lesson 110 — Worked Example: A Client Intake in Practice

**Client:** The Patel family, two children (6 and 9), rescue dog Milo, 3 years old, jumps on the children and steals food. **Intake findings:** Milo was rehomed 2 months ago; no bite history; jumps most when the children come home from school; steals food from low tables. **Plan agreed:** 4 one-to-one sessions; management — baby gate at the front door, food kept out of reach, children taught to stand still and fold their arms when Milo jumps; training — four-paws-on-the-floor (Lesson 51), mat training (Lesson 35), leave it (Lesson 43); homework — 5 minutes a day, children involved in treat delivery under supervision. **Outcome after 4 sessions:** Jumping reduced from every greeting to occasional, food stealing stopped with management in place, children confident in the "be a tree" response. **Note:** Milo's case stayed within foundation level throughout; no referral needed.

**Module 14 Check:** You can run a full intake, conduct a first consultation, write a service agreement, set homework that gets done, and handle a difficult conversation professionally.

---

# MODULE 15 — Turning Skill into Paid Work: Pricing, Packages & Business Basics

## Lesson 111 — What to Charge: Pricing Your Services

Pricing is a business decision, not a guess. Research what trainers in your area charge for one-to-one sessions, group classes, and puppy packages, and position yourself honestly for your experience level. A common starting structure is a single one-to-one session at a set rate, a package of 4–6 sessions at a modest discount, and a 6-week group class at a per-dog rate. **Worked pricing example:** If a single session is $75, a 4-session package might be $270 (a 10% discount), and a 6-week group class might be $180 per dog for 6 dogs — $1,080 per class. Work out your costs first: travel, insurance, equipment, and your time (including preparation and notes, not just the session hour). Never undercharge to win clients — it attracts clients who do not value the work and it makes the business unsustainable. Review your prices every six months.

## Lesson 112 — Packages & Services: What to Offer

Start narrow and do it well. A sensible first menu is: (1) a one-to-one foundation package (4 sessions, covering Modules 5–7 skills); (2) a puppy package (4 sessions, covering Module 8); (3) a 6-week group foundation class; and (4) a single consultation for owners who need a plan, not ongoing coaching. Add behaviour support only when you have the training and the referral network to do it safely — and price it accordingly, because behaviour cases take more time, more notes, and more follow-up. Say no to services you cannot deliver well; a small, excellent menu beats a large, mediocre one.

## Lesson 113 — The Business Basics: Legal Form, Insurance & Records

Before taking paying clients: choose a legal structure for your business (the right form depends on your country and circumstances — take professional advice); register as required locally; take out public liability and professional indemnity insurance; open a separate bank account for the business; keep records of every payment and expense; and check whether you need any local licence or registration to work with dogs. Keep client records securely and in line with local data-protection law, and never share a client's details without permission. These steps are not glamorous, but they are what separates a professional from a hobbyist.

## Lesson 114 — Finding Clients: Ethical Marketing

Your best marketing is results and word of mouth. Other honest routes: a simple website or profile page with your services, prices, and methods stated clearly; a social media presence showing real training (with the owner's permission, and never showing a dog in distress); partnerships with vets, groomers, pet shops, and rescues; and free introductory talks or demonstrations for community groups. State your methods clearly — "positive reinforcement only" — so clients who want aversive methods go elsewhere. Never use before-and-after claims you cannot support, never use another trainer's testimonials, and never promise outcomes you cannot guarantee. Your marketing must be as honest as your training.

## Lesson 115 — Managing Your Time & Avoiding Burnout

Training is physical, emotional, and often solitary work. Protect your diary: limit the number of sessions per day (four one-to-one sessions is a full day when you count travel, preparation, and notes); keep one day a week free of clients; take proper breaks between sessions; and keep learning — attend workshops, read, and find a mentor or a peer group. If you feel frustrated with a dog or a client, that is a sign to pause, not to push through. A tired trainer makes poor decisions, and dogs notice.

## Lesson 116 — Worked Example: A First-Year Plan

**Goal:** 10 regular clients and one group class per term by the end of year one. **Months 1–3:** Complete this academy and your certificate project; get insurance; set up a simple website and social profiles; offer 5 free or low-cost practice sessions to friends and family in exchange for honest feedback and (with permission) photos. **Months 4–6:** Launch a 6-week group class (4–6 dogs); take on 3–4 one-to-one clients; join a local vet and groomer referral network. **Months 7–12:** Two group classes per term; 6–8 one-to-one clients; first price review; start a waiting list. **Budget:** Track income and expenses monthly using the Business Tracker in the workbook. **Note:** This is an illustrative example, not a guarantee — your local market, experience, and effort will shape your actual results.

**Module 15 Check:** You can price a session, a package, and a class using a worked example; list the legal, insurance, and record-keeping steps before taking clients; and write a first-year plan.

---

# MODULE 16 — Your Certificate Project: Assessment, Portfolio & Next Steps

## Lesson 117 — The Certificate Project: What It Is

To earn your certificate of completion, you will complete a project that proves you can do the work, not just read about it. The project has three parts: **(A)** a training case study — choose one dog, assess it using the Behaviour Assessment Form, write a one-page training plan, run at least 6 training sessions over at least 3 weeks, and record the results in the Training Progress Tracker; **(B)** a session demonstration — a written plan and a reflective note for a 30-minute session you ran (one-to-one or with your own dog), including what went well and what you would change; and **(C)** a short written reflection (500–1,000 words) on what you learned, your strengths, and what you will keep working on. Keep all three parts together as your portfolio.

## Lesson 118 — Case Study: A Worked Example

**Dog:** Luna, 8-month-old rescue mixed breed, pulls on the lead and jumps on visitors. **Assessment:** No bite history; vet check clear; jumps for attention; pulls because pulling gets her to things faster. **Plan:** Management (baby gate at the door, front-clip harness); training — loose-lead stop-start method (Lessons 47–48) and four-paws-on-the-floor (Lesson 51); schedule — 5-minute sessions, twice a day, 6 weeks. **Results:** Loose-lead walking improved from 0 steps to 15 steps on a quiet street; jumping reduced from every greeting to 2 out of 5 greetings; owner confidence improved. **Reflection:** The biggest lesson was patience — progress was slower in week 3 when Luna was overtired after a house move, and the plan had to be simplified for a week. That is normal, and adjusting the plan is part of the job.

## Lesson 119 — Self-Assessment: Are You Ready for Clients?

Before taking paying clients, check yourself honestly against this list: Can you read a dog's body language and recognise stress? Can you teach sit, down, stay, recall, leave it, and loose-lead walking? Can you write a training plan and run a session? Can you complete an intake and explain your methods clearly? Do you know when to refer, and do you have a vet and a behaviour professional to refer to? Do you have insurance and a service agreement? If any answer is no, work on that area first — with a mentor, a peer, or further study — before charging for it. Competence and honesty are the foundation of a good reputation.

## Lesson 120 — Next Steps: Continuing Your Education

This academy is a foundation, not a finish line. Next steps include: gaining supervised experience with a mentor or an experienced trainer; studying for a recognised qualification in your country (research the professional bodies listed in Appendix D and choose one that fits your goals — requirements and costs vary, and you should verify them directly with the body); attending workshops on behaviour, puppy development, and client coaching; joining a professional association; and keeping a reflective log of your sessions. The best trainers are the ones who never stop learning.

**Module 16 Check:** You have completed a case study, a session demonstration, and a reflection; you can assess your own readiness for clients; and you have a plan for continuing education. When all three parts are complete, fill in the certificate template (certificate.md) with your name and the completion date.

---

# APPENDIX A — Training Session Plan Library

**Plan 1 — First Sit Session (10 min):** Warm-up: hand targets (5 reps). Teach: lure sit, 5 reps, then add the cue, 5 reps. Cool-down: free play. Success: 8/10 sits on cue.

**Plan 2 — Recall in the Garden (10 min):** Warm-up: 3 recalls at 1 m. Teach: recall at 3 m, then 5 m, on a long line, jackpot every third recall. Cool-down: scatter feed. Success: 8/10 recalls at 5 m.

**Plan 3 — Loose-Lead Walking (10 min):** Warm-up: 5 sits. Teach: stop-start on a quiet street, reward every 3 steps of slack lead. Cool-down: sniff break. Success: 10 steps of loose lead.

**Plan 4 — Mat Settle (10 min):** Warm-up: 3 downs. Teach: shape going to the mat, build to lying down for 10 seconds. Cool-down: chew on the mat. Success: dog lies on the mat for 10 seconds.

**Plan 5 — Leave It (10 min):** Warm-up: hand target. Teach: closed-fist leave it, 5 reps; treat on the floor covered, 5 reps. Cool-down: scatter feed. Success: dog turns away from the closed fist immediately.

**Plan 6 — Polite Greetings (15 min, with a helper):** Warm-up: 5 sits. Teach: helper approaches, dog keeps four paws on the floor; helper retreats if the dog jumps. Cool-down: calm petting for four paws on the floor. Success: 3 out of 5 greetings with four paws on the floor.

# APPENDIX B — Behaviour Case Examples

**Case 1 — Fear of the Vacuum Cleaner (DS/CC):** Dog: Rosie, 5-year-old collie, hides and shakes when the vacuum runs. Plan: vacuum off at 5 m, treats for looking; vacuum on for 2 seconds at 5 m, treats; increase duration and decrease distance over 4 weeks. Outcome: Rosie stays in the room, lying on her mat, while the vacuum runs in the next room. Management used throughout: Rosie in another room with a Kong during vacuuming until training progressed.

**Case 2 — Lead Reactivity to Other Dogs:** Dog: Bruno, 2-year-old German shepherd, lunges and barks at dogs within 10 m. Plan: management (cross the road, avoid narrow paths), DS/CC at 20 m with the "Look at That" game, building to 10 m over 8 weeks. Outcome: Bruno can pass a calm dog at 10 m with treats and a check-in, and at 15 m without a reaction. Owner now plans routes to maintain distance.

**Case 3 — Puppy Toilet Training:** Puppy: Pip, 10-week-old cockapoo, toileting indoors 4–5 times a day. Plan: schedule (out every hour, after meals, naps, and play), supervision, reward outside within seconds, crate/pen when unsupervised. Outcome: accidents reduced to 1 a day by week 3, none by week 5. No punishment used at any point.

**Case 4 — Resource Guarding a Chew (Early, Referred):** Dog: Teddy, 1-year-old terrier, stiffens and growls when approached while chewing. Plan: management (give chews in a safe, undisturbed place, do not approach); referral to a veterinary behaviourist for a structured programme; owner taught trading games only under the behaviourist's guidance. Outcome: guarding reduced under specialist care. This case illustrates the referral boundary — the trainer's role was safety, management, and referral, not treatment.

# APPENDIX C — Quick-Reference Cue Library

| Cue | Behaviour | Teaching method |
|---|---|---|
| Sit | Bottom on the floor | Lure over the head, fade the lure |
| Down | Elbows on the floor | Lure from a sit to the floor |
| Stay / Wait | Hold a position | Build duration in seconds, then distance |
| Come / Here | Return to the handler | Run backwards, jackpot on arrival |
| Leave it | Disengage from an item | Closed fist, reward turning away with a better treat |
| Drop it / Give | Release an item | Trade up, sometimes return the item |
| Mat / Place | Go to a mat and settle | Shape steps onto the mat, build duration |
| Quiet | Stop barking briefly | Mark and reward pauses in barking |
| Look at that | Look at a trigger, then check in | Mark the look, reward the turn back |
| Okay / Free | Release from an exercise | Upbeat word, toss a treat away |

# APPENDIX D — Recommended Further Learning & Professional Bodies

Professional standards and qualifications vary by country, and they change over time. Before choosing a qualification, verify the current requirements directly with the organisation. Bodies to research in your country include: in the UK, the Association of Pet Behaviour Counsellors (APBC), the Institute of Modern Dog Trainers (IMDT), and the Animal Behaviour and Training Council (ABTC); in the US, the Certification Council for Professional Dog Trainers (CCPDT), the International Association of Animal Behavior Consultants (IAABC), and the Association of Professional Dog Trainers (APDT); in Australia, the Association of Pet Dog Trainers Australia (APDT Australia) and the Delta Institute; and in Canada, the Canadian Association of Professional Dog Trainers (CAPDT). Look for organisations that require assessed competence, continuing education, and a code of ethics based on humane, reward-based methods. Books and further reading: look for works on learning theory, body language, and behaviour by recognised, science-based authors, and check publication dates — the field moves quickly. Your local library and your veterinarian are good starting points for recommendations.

---

*End of The Professional Dog Trainer Academy (PET-03). Good luck — train kindly, keep records, and never stop learning.*
